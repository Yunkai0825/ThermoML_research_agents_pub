"""ThermoML numerical evaluation counts by agent, mutation and value type.

Reads saved eval/evaluation.json files in directories or ZIP archives without
extraction or model calls. ARCHIVES.json maps ZIP parts to their logical source
paths. Each answer is counted once; unpacked copies take precedence.

The default cohort is declared in ROOT/_eval_stats/selection.json when present.
Its answer and evaluation hashes must match; a missing or changed selected file
stops the run. Use --selection for another explicit cohort, or --all-answers to
scan all saved answers. --newest-only additionally selects the newest dated run
per question/mutation, retaining same-time replicates. Superseded runs are listed;
an older evaluation never substitutes for a newer unevaluated answer.

Both ThermoML archive observations and fixed-tool artifacts are included by
default. --archive-only excludes artifacts; --artifacts explicitly retains them.
Pipeline artifacts remain a separate native category and also enter the displayed
property row once. All types sums native property values, pipeline artifacts
(fitting), and measurement conditions once each. Stored uncertainties and any
other native type retain their own rows outside All types.
Outside values are excluded; misassigned is a subset flag, not a fourth outcome.
Zero compared values have undefined accuracy. Comparisons are read from accepted
evaluations, never rejudged by this statistics script.

Query Q1.7, Q1.8 and Q6.5 under test_run_r1_1_20261020 belong to
full_capability. Q1.7 and Q1.8 are the only gated answers to those prompts;
the campaign identifier does not create a separate mutation chart.
Current question IDs and logical paths are retained independently of ZIP names.

Writes one CSV/PNG pair per agent/mutation, plus summary.csv and summary.png.
Recounted native, source and property-rollup totals must match each evaluation
before writing. Existing unrelated output files are preserved and listed.

Usage: python eval_stats.py [--root ROOT] [--out DIR]
       [--selection FILE | --all-answers] [--newest-only]
       [--artifacts | --archive-only]
"""
from __future__ import annotations

import argparse
import collections
import csv
import json
import hashlib
import os
import re
import sys
from pathlib import Path, PurePosixPath, PureWindowsPath
from zipfile import BadZipFile

# Resolve only this checkout; direct invocation works from any working directory.
_REPO_ROOT = Path(__file__).resolve().parents[2]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))
from ThermoML_results_browser.helpers.benchmark_zip import ZipPath  # noqa: E402

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

RESULT_FILE = "result.md"
EVALUATION = "eval/evaluation.json"
OUTCOMES = ("exact", "near_miss", "miss")  # rubric C: Exact, Near, otherwise Miss
OUTCOME_LABELS = {"exact": "Exact", "near_miss": "Near miss", "miss": "Miss"}
OUTSIDE = "outside"
ALL_TYPES = "all_types"
PROPERTY_VALUE = "property_value"
PIPELINE_ARTIFACT = "pipeline_artifact"
TYPE_ORDER = (PROPERTY_VALUE, PIPELINE_ARTIFACT, "measurement_condition", "stored_uncertainty")
ALL_TYPES_MEMBERS = (PROPERTY_VALUE, PIPELINE_ARTIFACT, "measurement_condition")  # property + fitting + conditions
SOURCE_LABELS = {"thermoml_archive": "ThermoML archive", "hardcoded_artifact": "Fixed-tool artifacts"}
TYPE_LABELS = {PROPERTY_VALUE: "Property incl. artifacts",
               PIPELINE_ARTIFACT: "Pipeline artifact",
               "measurement_condition": "Measurement condition",
               "stored_uncertainty": "Stored uncertainty", "artifact_count": "Artifact count",
               "artifact_metadata": "Artifact metadata", "fit_statistic": "Fit statistic",
               "model_parameter": "Model parameter", "model_uncertainty": "Model uncertainty", ALL_TYPES: "All types"}
STAMP = re.compile(r"_?\d{8}(?:_\d{4,6})?(?:_r\d+)?$")

# Answer folders left out of the counts, by their parts below the root. None.
EXCLUDED_ANSWER_FOLDERS: set[tuple[str, ...]] = set()
RUN_GROUPING_ALIASES = {
    ("test_run_full_capability", "test_run_r1_1_20261020"): ("test_run_full_capability",),
}
COLUMNS = ("agent", "mutation", "arm", "gate_mode", "source_kind", "question", "answer_folder", "type", "exact", "near_miss", "miss",
           "total", "misassigned", "exact_pct", "near_miss_pct", "miss_pct")

# Chart colours: the outcomes are a status (good / warning / critical), always shown with their labels.
SURFACE, INK, INK_2, MUTED, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#898781", "#e1e0d9"
STATUS = {"exact": "#0ca30c", "near_miss": "#fab219", "miss": "#d03b3b"}
RULE = "Exact: display tolerance or fitting 4 s.f. · Near: otherwise <1% · Miss: other disagreement or missing evidence"
plt.rcParams["font.family"] = ["Segoe UI", "Arial", "DejaVu Sans"]  # the system sans that is there


class StatsError(Exception):
    pass


def _relative_name(value: str, field: str) -> PurePosixPath:
    """Validate a manifest path without normalizing away unsafe components."""
    if (not isinstance(value, str) or not value or "\\" in value or "\x00" in value
            or PureWindowsPath(value).drive or value.startswith("/")
            or any(part in {"", ".", ".."} for part in value.split("/"))):
        raise StatsError(f"Invalid {field}: {value!r}")
    return PurePosixPath(value)


def archive_collections(root: Path) -> dict[str, PurePosixPath]:
    """Map each published archive to its original logical collection directory."""
    manifest = root / "ARCHIVES.json"
    if not manifest.is_file():
        return {}
    try:
        document = json.loads(manifest.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        raise StatsError(f"{manifest}: cannot read archive manifest: {exc}") from exc
    if not isinstance(document, dict) or not isinstance(document.get("archives"), list):
        raise StatsError(f"{manifest}: expected an archives list")
    mappings = {}
    for record in document["archives"]:
        if not isinstance(record, dict):
            raise StatsError(f"{manifest}: archive records must be objects")
        archive = _relative_name(record.get("path"), "path")
        collection = _relative_name(record.get("source_collection"), "source_collection")
        if archive.suffix.lower() != ".zip":
            raise StatsError(f"{manifest}: archive path must end in .zip: {archive}")
        if archive.as_posix() in mappings and mappings[archive.as_posix()] != collection:
            raise StatsError(f"{manifest}: conflicting source collections for {archive}")
        mappings[archive.as_posix()] = collection
    return mappings


def answer_relative(root: Path, folder: Path | ZipPath,
                    mappings: dict[str, PurePosixPath] | None = None) -> PurePosixPath:
    """An answer's original path, independent of compression and split filenames."""
    if not isinstance(folder, ZipPath):
        return PurePosixPath(folder.relative_to(root).as_posix())
    mappings = archive_collections(root) if mappings is None else mappings
    archive = PurePosixPath(folder.archive.relative_to(root).as_posix())
    collection = mappings.get(archive.as_posix())
    if collection is None:
        # Multipart suffixes describe packaging, never an evaluation cohort.
        stem = re.sub(r"__part\d+(?:__.*)?$", "", archive.stem, flags=re.IGNORECASE)
        collection = archive.parent if archive.parent.name == stem else archive.parent / stem
    return collection / folder.member


def answer_folders(root: Path, mappings: dict[str, PurePosixPath] | None = None) -> list[Path | ZipPath]:
    """Every logical answer once, preferring an unpacked copy over its ZIP copy.

    ZIPs are visited through their central directory and streamed members; no
    extraction is needed. Stop at result.md so descendant worker answers never
    enter the numerical cohorts. Hidden/auxiliary folders and symlinks are skipped.
    """
    root = root.resolve()
    mappings = archive_collections(root) if mappings is None else mappings
    found: dict[str, Path | ZipPath] = {}

    def walk(folder: Path | ZipPath) -> None:
        if folder != root and (folder / RESULT_FILE).is_file():
            relative = answer_relative(root, folder, mappings)
            if relative.parts in EXCLUDED_ANSWER_FOLDERS:
                return
            logical = relative.as_posix()
            previous = found.get(logical)
            if previous is None or (isinstance(previous, ZipPath) and not isinstance(folder, ZipPath)):
                found[logical] = folder
            return
        if isinstance(folder, ZipPath):
            children = sorted((entry for entry in folder.iterdir()
                               if entry.is_dir() and not entry.name.startswith(("_", "."))),
                              key=lambda entry: entry.name)
        else:
            with os.scandir(folder) as entries:
                children = sorted((folder / entry.name for entry in entries
                                   if not entry.name.startswith(("_", ".")) and not entry.is_symlink()
                                   and (entry.is_dir() or (entry.is_file() and entry.name.lower().endswith(".zip")))),
                                  key=lambda entry: entry.name)
        for child in children:
            if not isinstance(child, ZipPath) and child.is_file():
                try:
                    walk(ZipPath(child))
                except (OSError, ValueError, BadZipFile) as exc:
                    raise StatsError(f"{child}: cannot read benchmark archive: {exc}") from exc
            else:
                walk(child)

    walk(root)
    return [found[key] for key in sorted(found)]


def mutation_of(grouping: list[str]) -> str:
    """The mutation named by the folders between the level and the answer folder (see the module docstring)."""
    labels: list[str] = []
    for name in RUN_GROUPING_ALIASES.get(tuple(grouping), grouping):
        label = STAMP.sub("", re.sub(r"^test_run_?", "", name)).strip("_")
        if label and (not labels or labels[-1] != label):
            labels.append(label)
    return "/".join(labels) or "(none)"


def selected_answer_folders(root: Path, selection: Path | None) -> list[Path | ZipPath]:
    """Read the declared cohort and verify its saved answer/evaluation identities."""
    folders = answer_folders(root)
    if selection is None:
        return folders
    try:
        document = json.loads(selection.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as exc:
        raise StatsError(f"{selection}: cannot read selection: {exc}") from exc
    if (not isinstance(document, dict) or document.get("schema") != "thermoml-evaluation-selection/1"
            or not isinstance(document.get("answers"), list) or not document["answers"]):
        raise StatsError(f"{selection}: expected a nonempty thermoml-evaluation-selection/1 answers list")
    mappings = archive_collections(root)
    available = {answer_relative(root, folder, mappings).as_posix(): folder for folder in folders}
    selected, seen = [], set()
    for record in document["answers"]:
        if not isinstance(record, dict):
            raise StatsError(f"{selection}: answer records must be objects")
        name = _relative_name(record.get("answer_folder"), "answer_folder").as_posix()
        if name in seen:
            raise StatsError(f"{selection}: duplicate answer: {name}")
        seen.add(name)
        folder = available.get(name)
        if folder is None:
            raise StatsError(f"{selection}: selected answer missing: {name}")
        for filename, key in ((RESULT_FILE, "source_sha256"), (EVALUATION, "evaluation_sha256")):
            expected = record.get(key)
            if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
                raise StatsError(f"{selection}: invalid {key} for {name}")
            file = folder / filename
            if not file.is_file():
                raise StatsError(f"{selection}: selected file missing: {name}/{filename}")
            if hashlib.sha256(file.read_bytes()).hexdigest() != expected:
                raise StatsError(f"{selection}: selected file changed: {name}/{filename}")
        selected.append(folder)
    if document.get("selected_answers") != len(selected):
        raise StatsError(f"{selection}: selected_answers does not match the answers list")
    return selected


def counted_answer_folders(root: Path, newest_only: bool = False,
                           selection: Path | None = None) -> tuple[list[Path | ZipPath], list[dict]]:
    """The non-obsolete answer folders to count: every run per agent, mutation and prompt, or with ``newest_only`` the
    newest run with all its same-day replicates (the older runs are returned as superseded)."""
    groups = collections.defaultdict(list)
    for folder in selected_answer_folders(root, selection):
        rel = answer_relative(root, folder).parts
        question = re.match(r"Q\d+(?:\.\d+)*", rel[-1])
        if not question:
            raise StatsError(f"Cannot identify prompt from answer folder: {folder}")
        groups[(rel[0], mutation_of(list(rel[1:-1])), question.group())].append(folder)
    selected, superseded = [], []
    for key, members in sorted(groups.items()):
        if len(members) == 1 or not newest_only:
            selected += members
            continue
        def dated_rank(folder):
            stamps = []
            for part in answer_relative(root, folder).parts:
                for match in re.finditer(r"(?<!\d)(20\d{6})(?:_(\d{6}))?(?:_r(\d+))?(?!\d)", part):
                    stamps.append((match.group(1), match.group(2) or '000000', int(match.group(3) or 0)))
            if not stamps:
                raise StatsError(f"Repeated answer has no run date: {folder}")
            return max(stamps)
        ranked = sorted(((dated_rank(folder), folder) for folder in members),
                        key=lambda item: (item[0], answer_relative(root, item[1]).as_posix()))
        newest = ranked[-1][0][:2]  # the run's date and time; an _rN suffix marks a replicate of that run
        chosen = [(rank, folder) for rank, folder in ranked if rank[:2] == newest]
        stamps = collections.Counter(rank for rank, _ in chosen)
        if max(stamps.values()) > 1:
            raise StatsError(f"Repeated answers have ambiguous latest dates: {key}: {members}")
        selected += [folder for _, folder in chosen]
        names = ", ".join(answer_relative(root, folder).as_posix() for _, folder in chosen)
        superseded += [{"agent": key[0], "mutation": key[1], "question": key[2], "selected": names,
                        "superseded": answer_relative(root, folder).as_posix()}
                       for rank, folder in ranked if rank[:2] != newest]
    return sorted(selected, key=lambda folder: answer_relative(root, folder).as_posix()), superseded


def type_key(name: str) -> tuple:
    return (TYPE_ORDER.index(name), "") if name in TYPE_ORDER else (len(TYPE_ORDER), name)


def question_key(question: str) -> tuple:
    return tuple(int(number) for number in re.findall(r"\d+", question)), question


def read_answer(root: Path, folder: Path | ZipPath) -> dict:
    """One answer's counts by type, recounted from its values and checked against the evaluation's own counts."""
    path = folder / EVALUATION
    document = json.loads(path.read_text(encoding="utf-8"))
    answer = document["answer"]
    relative = answer_relative(root, folder).parts
    if answer.get("level") != relative[0]:
        raise StatsError(f"{path}: level {answer.get('level')!r} but the answer sits under {relative[0]!r}")
    counts: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    by_source = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
    for excerpt in document["excerpts"]:
        for value in excerpt["values"]:
            kind = value["group"]
            if kind == OUTSIDE:
                continue
            outcome = value.get("outcome")
            if outcome not in OUTCOMES:
                raise StatsError(f"{path}: value {value.get('token_id')} has outcome {outcome!r}")
            source = value.get("source_kind", "thermoml_archive")
            if source not in SOURCE_LABELS:
                raise StatsError(f"{path}: scored token {value.get('token_id')} has unsupported source_kind {source!r}")
            misassigned = str(value.get("misassigned", "")).strip().lower() == "true"
            for counter in (counts[kind], by_source[source][kind]):
                counter[outcome] += 1
                counter["misassigned"] += misassigned
    own = document["counts"]["numeric"]["by_group"]
    for kind in sorted(set(own) | set(counts)):
        mine = {key: counts[kind][key] for key in (*OUTCOMES, "misassigned")}
        mine["total"] = sum(counts[kind][key] for key in OUTCOMES)
        theirs = {key: int((own.get(kind) or {}).get(key, 0)) for key in mine}
        if mine != theirs:
            raise StatsError(f"{path}: {kind} recounted {mine}, the evaluation says {theirs}")
    recorded_rollup = document["counts"]["numeric"].get("property_rollup")
    if document.get("schema") == "thermoml-benchmark-eval/3" and recorded_rollup is None:
        raise StatsError(f"{path}: v3 evaluation missing property_rollup")
    if recorded_rollup is not None:
        rolled = counts[PROPERTY_VALUE] + counts[PIPELINE_ARTIFACT]
        actual = {key: rolled[key] for key in (*OUTCOMES, "misassigned")}
        actual["total"] = sum(actual[key] for key in OUTCOMES)
        expected = {key: int(recorded_rollup.get(key, 0)) for key in actual}
        if actual != expected:
            raise StatsError(f"{path}: property rollup mismatch: {actual} vs {expected}")
    recorded_origins = document["counts"]["numeric"].get("by_source_kind_and_group")
    if recorded_origins is not None:
        for source in set(recorded_origins) | set(by_source):
            recorded = recorded_origins.get(source, {})
            for kind in set(recorded) | set(by_source[source]):
                actual = {k: by_source[source][kind][k] for k in (*OUTCOMES, "misassigned")}
                actual["total"] = sum(actual[k] for k in OUTCOMES)
                expected = {k: int((recorded.get(kind) or {}).get(k, 0)) for k in actual}
                if actual != expected:
                    raise StatsError(f"{path}: {source}/{kind} count mismatch: {actual} vs {expected}")
    return {"agent": relative[0], "mutation": mutation_of(list(relative[1:-1])), "arm": answer.get("arm", ""),
            "gate_mode": answer.get("gate_mode", ""), "question": answer.get("question", relative[-1]),
            "answer_folder": "/".join(relative), "counts": counts, "counts_by_source_kind": dict(by_source)}


def row(base: dict, kind: str, counts: collections.Counter) -> dict:
    total = sum(counts[key] for key in OUTCOMES)
    pct = {f"{key}_pct": f"{100 * counts[key] / total:.1f}" if total else "" for key in OUTCOMES}
    return {**base, "type": kind, **{key: counts[key] for key in OUTCOMES}, "total": total,
            "misassigned": counts["misassigned"], **pct}


def add_up(answers: list[dict], kinds: list[str]) -> dict[str, collections.Counter]:
    """Keep native artifact counts separate; roll them into displayed property counts once."""
    totals: dict[str, collections.Counter] = {kind: collections.Counter() for kind in (*kinds, ALL_TYPES)}
    for answer in answers:
        for kind, counter in answer["counts"].items():
            if kind in ALL_TYPES_MEMBERS:  # native groups only; never add the display rollup here
                totals[ALL_TYPES].update(counter)
            if kind in totals:
                totals[kind].update(counter)
    if PIPELINE_ARTIFACT in kinds:
        totals[PROPERTY_VALUE].update(totals[PIPELINE_ARTIFACT])
    return totals


def joined(answers: list[dict], key: str) -> str:
    return "+".join(sorted({answer[key] for answer in answers if answer[key]}))


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:  # with a byte-order mark, for Excel
        writer = csv.DictWriter(handle, fieldnames=COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


# --- Charts -----------------------------------------------------------------------------------------------------------

def _axes(ax) -> None:
    ax.set_facecolor(SURFACE)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(colors=MUTED, labelcolor=INK_2, length=0, labelsize=9)
    ax.grid(axis="x", color=GRID, linewidth=0.6)
    ax.set_axisbelow(True)


def _legend(fig, top: float) -> None:
    handles = [Patch(facecolor=STATUS[key], edgecolor="none", label=OUTCOME_LABELS[key]) for key in OUTCOMES]
    fig.legend(handles=handles, loc="upper left", bbox_to_anchor=(0.012, top), ncol=3, frameon=False, fontsize=9,
               labelcolor=INK_2, handlelength=1.2, handleheight=0.9, columnspacing=1.4)


def _share_bars(ax, bars: list[tuple[str, collections.Counter]]) -> None:
    """One 100 %-stacked bar per row; a share is written in its segment when it fits, and n with the near-miss and
    miss shares after the bar."""
    for y, (label, counts) in enumerate(bars):
        total = sum(counts[key] for key in OUTCOMES)
        if not total:
            ax.text(0.5, y, "no compared values", va="center", fontsize=8.5, color=MUTED)
            continue
        left = 0.0
        for key in OUTCOMES:
            width = 100 * counts[key] / total
            if width:
                ax.barh(y, width, left=left, height=0.64, color=STATUS[key], edgecolor=SURFACE, linewidth=1.2)
                if width >= 9:
                    ax.text(left + width / 2, y, f"{width:.0f} %", ha="center", va="center", fontsize=8, color=INK)
            left += width
        ax.annotate(f"n = {total:,} · near {100 * counts['near_miss'] / total:.1f} % · miss "
                    f"{100 * counts['miss'] / total:.1f} %", xy=(1.01, y), xycoords=("axes fraction", "data"),
                    va="center", fontsize=8.5, color=INK_2)
    ax.set_yticks(range(len(bars)), [label for label, _ in bars])
    ax.set_ylim(len(bars) - 0.5, -0.5)
    ax.set_xlim(0, 100)
    ax.set_xticks(range(0, 101, 25), [f"{tick} %" for tick in range(0, 101, 25)])


def _count_bars(ax, bars: list[tuple[str, collections.Counter]]) -> None:
    """One stacked bar of counts per row, n after the bar."""
    for y, (label, counts) in enumerate(bars):
        left = 0
        for key in OUTCOMES:
            if counts[key]:
                ax.barh(y, counts[key], left=left, height=0.64, color=STATUS[key], edgecolor=SURFACE, linewidth=1.0)
            left += counts[key]
        ax.text(left, y, f"  {left:,}", va="center", fontsize=8, color=INK_2)
    ax.set_yticks(range(len(bars)), [label for label, _ in bars])
    ax.set_ylim(len(bars) - 0.5, -0.5)
    ax.set_xlim(0, max([sum(counts[key] for key in OUTCOMES) for _, counts in bars] + [1]) * 1.1)
    ax.set_xlabel("compared values (all types)", fontsize=9, color=INK_2)


WIDTH, LEFT, RIGHT = 11.0, 0.3, 0.74  # inches; the plot area's left and right edges as figure fractions
HEADER = 1.25  # inches: title, subtitle, rule and legend


def _figure(title: str, subtitle: str, height: float):
    fig = plt.figure(figsize=(WIDTH, height), facecolor=SURFACE)
    fig.text(0.012, 1 - 0.3 / height, title, fontsize=13, weight="bold", color=INK, va="top")
    fig.text(0.012, 1 - 0.6 / height, subtitle, fontsize=9, color=INK_2, va="top")
    fig.text(0.012, 1 - 0.84 / height, RULE, fontsize=8, color=MUTED, va="top")
    _legend(fig, 1 - 0.98 / height)
    return fig


def _panel(fig, height: float, top: float, rows_height: float, title: str):
    """An axes ``rows_height`` inches tall whose title starts ``top`` inches below the figure's top edge."""
    ax = fig.add_axes((LEFT, 1 - (top + 0.3 + rows_height) / height, RIGHT - LEFT, rows_height / height))
    _axes(ax)
    ax.set_title(title, loc="left", fontsize=10, color=INK, pad=6)
    return ax


def _save(fig, path: Path) -> None:
    fig.savefig(path, dpi=150, facecolor=SURFACE, metadata={"Software": None})
    plt.close(fig)


def mutation_chart(path: Path, agent: str, mutation: str, answers: list[dict], kinds: list[str], scope: str) -> None:
    totals = add_up(answers, kinds)
    shares = [(TYPE_LABELS.get(kind, kind.replace("_", " ")), totals[kind]) for kind in (*kinds, ALL_TYPES)]
    repeated = collections.Counter(answer["question"] for answer in answers)
    per_answer = []
    for answer in answers:
        label = answer["question"]
        if repeated[label] > 1:  # the same question in another run of this mutation: name its run
            parts = answer["answer_folder"].split("/")
            stamp = next((match for part in reversed(parts) if (match := STAMP.search(part))), None)
            label += " · " + (stamp.group().lstrip("_") if stamp else parts[-2])
        per_answer.append((label, add_up([answer], kinds)[ALL_TYPES]))
    share_height, count_height = 0.36 * len(shares), 0.24 * len(per_answer)
    height = HEADER + 0.3 + share_height + 0.75 + 0.3 + count_height + 0.65
    fig = _figure(f"{agent} agent · {mutation.replace('_', ' ').replace('/', ' / ')}",
                  f"{scope} · {len(answers)} answers · arm {joined(answers, 'arm')} ({joined(answers, 'gate_mode')}) · "
                  f"{totals[ALL_TYPES]['misassigned']:,} misassigned (a subset flag) · source: each answer's "
                  "eval/evaluation.json", height)
    _share_bars(_panel(fig, height, HEADER, share_height, "Outcome share by value type"), shares)
    _count_bars(_panel(fig, height, HEADER + 0.3 + share_height + 0.75, count_height, "Compared values by answer"),
                per_answer)
    _save(fig, path)


def summary_chart(path: Path, groups: dict[tuple[str, str], list[dict]], kinds: list[str], scope: str) -> None:
    panels = []
    for agent in dict.fromkeys(agent for agent, _ in groups):
        bars = []
        for kind in (*kinds, ALL_TYPES):
            for (other, mutation), answers in groups.items():
                if other == agent:
                    bars.append((f"{TYPE_LABELS.get(kind, kind)} · {mutation.replace('_', ' ')}",
                                 add_up(answers, kinds)[kind]))
        panels.append((agent, bars))
    height = HEADER + sum(0.3 + 0.3 * len(bars) + 0.5 for _, bars in panels) + 0.1
    included = [answer for answers in groups.values() for answer in answers]
    with_values = sum(any(sum(c[o] for o in OUTCOMES) for c in a["counts"].values()) for a in included)
    fig = _figure(f"Numerical validation · {scope}",
                  f"{with_values} answers with comparisons; {len(included)} in included configurations · "
                  "unweighted · source: eval/evaluation.json", height)
    top = HEADER
    for agent, bars in panels:
        _share_bars(_panel(fig, height, top, 0.3 * len(bars), f"{agent} agent"), bars)
        top += 0.3 + 0.3 * len(bars) + 0.5
    _save(fig, path)


# --- Run ----------------------------------------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    here = Path(__file__).resolve().parent
    benchmark = here.parent
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--root", type=Path, default=benchmark, help="the benchmark root (default: %(default)s)")
    parser.add_argument("--out", type=Path, default=benchmark / "_eval_stats" / "numeric_outcomes",
                        help="the output folder (default: %(default)s)")
    source_choice = parser.add_mutually_exclusive_group()
    source_choice.add_argument("--artifacts", action="store_true",
                               help="include fixed-tool artifacts (now the default; retained for compatibility)")
    source_choice.add_argument("--archive-only", action="store_true",
                               help="count only archive observations, excluding fixed-tool artifacts")
    parser.add_argument("--newest-only", action="store_true",
                        help="count only the newest run of each question with its same-day replicates "
                             "(default: every run)")
    cohort = parser.add_mutually_exclusive_group()
    cohort.add_argument("--selection", type=Path, help="accepted-cohort manifest (default: ROOT/_eval_stats/selection.json if present)")
    cohort.add_argument("--all-answers", action="store_true", help="ignore the accepted cohort and scan all saved answers")
    args = parser.parse_args(argv)
    root, out = args.root.resolve(), args.out.resolve()
    default_selection = root / "_eval_stats" / "selection.json"
    selection = None if args.all_answers else (
        args.selection.resolve() if args.selection else default_selection if default_selection.is_file() else None
    )
    sources = ("thermoml_archive",) if args.archive_only else tuple(SOURCE_LABELS)
    scope = " + ".join(SOURCE_LABELS[source] for source in sources)

    answers, not_validated = [], collections.Counter()
    selected_folders, superseded = counted_answer_folders(root, newest_only=args.newest_only, selection=selection)
    for folder in selected_folders:
        if (folder / EVALUATION).is_file():
            answers.append(read_answer(root, folder))
        else:
            relative = answer_relative(root, folder).parts
            why = "eval/ holds no evaluation.json" if (folder / "eval").is_dir() else "no eval/ folder"
            not_validated[(f"{relative[0]} · {mutation_of(list(relative[1:-1]))}", why)] += 1
    if not answers:
        raise StatsError(f"no eval/evaluation.json under {root}")
    left_out = collections.Counter()  # values of the sources not counted, by answer
    for answer in answers:
        counts: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
        for source, by_kind in answer["counts_by_source_kind"].items():
            for kind, counter in by_kind.items():
                if source in sources:
                    counts[kind].update(counter)
                else:
                    left_out[answer["answer_folder"]] += sum(counter[key] for key in OUTCOMES)
        answer["counts"], answer["source_kind"] = dict(counts), "+".join(sources)
    native_kinds = {kind for answer in answers for kind in answer["counts"]}
    kinds = sorted(native_kinds | ({PROPERTY_VALUE} if PIPELINE_ARTIFACT in native_kinds else set()), key=type_key)
    groups: dict[tuple[str, str], list[dict]] = collections.defaultdict(list)
    for answer in sorted(answers, key=lambda a: (a["agent"], a["mutation"], question_key(a["question"]),
                                                 a["answer_folder"])):
        groups[(answer["agent"], answer["mutation"])].append(answer)
    level_order = {name: index for index, name in enumerate(("Query", "Analysis", "Main"))}
    groups = dict(sorted(groups.items(), key=lambda item: (level_order.get(item[0][0], 9), item[0])))

    out.mkdir(parents=True, exist_ok=True)
    written, summary, empty_groups = [], [], []
    for (agent, mutation), members in groups.items():
        # Retain empty-answer rows inside active groups, without inventing comparisons.
        if not any(a["counts"] for a in members):
            empty_groups.append(f"{agent} · {mutation} ({len(members)} answers)")
            continue
        base = {"agent": agent, "mutation": mutation, "arm": joined(members, "arm"),
                "gate_mode": joined(members, "gate_mode"), "source_kind": "+".join(sources),
                "question": "ALL", "answer_folder": ""}
        totals = add_up(members, kinds)
        rows = [row(base, kind, totals[kind]) for kind in (*kinds, ALL_TYPES)]
        summary += [{**item, "answer_folder": f"{len(members)} answers"} for item in rows]
        for answer in members:
            own = add_up([answer], kinds)
            answer_base = {key: answer[key] for key in ("agent", "mutation", "arm", "gate_mode",
                                                       "source_kind", "question", "answer_folder")}
            rows += [row(answer_base, kind, own[kind]) for kind in (*kinds, ALL_TYPES)]
        stem = f"{agent}__{mutation.replace('/', '-')}"
        write_csv(out / f"{stem}.csv", rows)
        mutation_chart(out / f"{stem}.png", agent, mutation, members, kinds, scope)
        written += [f"{stem}.csv", f"{stem}.png"]
    chart_groups = {key: members for key, members in groups.items() if any(a["counts"] for a in members)}
    summary_chart(out / "summary.png", chart_groups, kinds, scope)
    write_csv(out / "summary.csv", summary)
    written += ["summary.png", "summary.csv"]

    if selection is not None:
        print(f"accepted cohort: {selection}")
    print(f"{len(answers)} answers with a numerical validation under {root}; counted: {scope}")
    print(f"{'agent':9} {'mutation':22} {'source':18} {'type':22} {'exact':>6} {'near':>5} {'miss':>5} {'total':>6} {'misas.':>6}")
    for item in summary:
        print(f"{item['agent']:9} {item['mutation']:22} {item['source_kind']:18} {item['type']:22} {item['exact']:>6} {item['near_miss']:>5} "
              f"{item['miss']:>5} {item['total']:>6} {item['misassigned']:>6}")
    if left_out:
        print(f"not counted, non-archive source values (--archive-only): {sum(left_out.values())} values "
              f"in {len(left_out)} answers")
    for name in empty_groups:
        print(f"not written, no compared value in any answer: {name}")
    for (name, why), count in sorted(not_validated.items()):
        print(f"not counted, no numerical validation ({why}): {count} answers of {name}")
    runs = collections.defaultdict(list)
    for answer in answers:
        runs[(answer["agent"], answer["mutation"], re.match(r"Q\d+(?:\.\d+)*", answer["answer_folder"].split("/")[-1])
              .group())].append(answer["answer_folder"])
    for (agent, mutation, question), folders in runs.items():
        if len(folders) > 1:
            print(f"counted, {len(folders)} runs of {agent} · {mutation} · {question}: {', '.join(sorted(folders))}")
    for entry in superseded:
        print(f"not counted, superseded run: {entry['superseded']} -> {entry['selected']}")
    stale = sorted(path.name for path in out.iterdir() if path.is_file() and path.name not in written)
    if stale:
        print("in the output folder but not written by this run (left as they are):", ", ".join(stale))
    print(f"wrote {len(written)} files to {out}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except StatsError as error:
        sys.exit(f"stopped: {error}")
