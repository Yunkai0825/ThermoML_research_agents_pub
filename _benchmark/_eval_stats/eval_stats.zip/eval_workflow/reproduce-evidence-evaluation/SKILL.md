---
name: reproduce-evidence-evaluation
description: Evaluate answers against source evidence with numerical grounding, orchestrator guidance, configurable reconciliation groups and reproducible publication. Use when auditing answer collections against a database or archive.
---

# Reproduce evidence evaluation

Assume this folder is the only supplied workflow. Obtain the answers, original questions, source data and publication requirements. Build missing source adapters from [the source contract](references/source-profile-contract.md). ThermoML supplies its [profile](ThermoML/profile.md), numerical rubric, tools and synthetic tests.


For an explicitly requested correction using existing reports, follow [the one-answer correction contract](ThermoML/tools/CORRECTION_SCHEMA.md). Use one correction agent per answer, actual inspected pipeline artifacts and final orchestrator acceptance; do not apply the fresh grouped-review sequence to that mode.

For a full fresh evaluation, start with [intake](references/intake.md). Ask whether reconciliation should merge answers to the same original question across conditions or keep them separate, and ask for the maximum number of concurrent worker agents. Reuse an explicit current user choice without asking again. Neither setting has an implicit default. Read the chosen formation rule: [merged groups](modes/merged_recon/workflow_merged_recon.md) or [individual groups](modes/indiv_recon/workflow_indiv_recon.md). Both use one adapter: individual reconciliation passes a one-element members list. Different original questions require an explicit user-authorized exception with separate member scopes and actual question hashes; record it at intake.

Apply [blind-input preparation](references/blind-inputs.md) before any worker receives an answer. Each initial numerical reviewer sees one clean answer. The orchestrator validates its return, runs the full deterministic quality screen, inspects evidence, resolves supported issues and writes [guidance](references/orchestrator-guidance.md). A fresh reconciliation agent receives one declared group and audits every member separately. The orchestrator checks each returned report and evidence before canonical publication. Follow [execution](references/execution.md), [stage/cache contracts](references/stage-contracts.md), [prompt dispatch](references/dispatch-contracts.md) and [build validation](references/build-pipeline.md).

Use [classification rules](references/decision-rules.md) before scoring. Keep raw measurements, derived outputs, factual counts and irrelevant numbers distinct. Fixed pipeline artifacts supply scored numeric evidence under the selected source profile. Scientific claim analysis is a separate fresh-or-bypass choice; bypass creates no new scientific review and preserves existing results.

The shared concurrency limit covers all initial, reconciliation and enabled scientific workers. A group uses one worker slot regardless of its size. Keep runtime packets, caches, private identities and logs outside publication. Publish separate accepted reports for every answer; aggregate only the explicitly selected accepted reports. See [runtime layout](references/runtime-layout.md) and the shared ThermoML [tool interface](ThermoML/tools/INTERFACE.md).


For fixed solver/pipeline outputs, read [the pipeline artifact contract](ThermoML/tools/PIPELINE_ARTIFACT_SCHEMA.md) before mapping, screening, reconciliation or publishing.

Use [numerical precision and human context](references/numerical-precision.md): continuous fitting outputs default to four-significant-digit matching in addition to the existing display tolerance. Agents may seek human-expert context for consequential unresolved values or precision edge cases; record scoped decisions before accepting dependent judgments.
