# End-to-end stages and returns

The numerical/factual workflow has three worker or deterministic stages before final orchestrator acceptance: isolated initial review per answer, deterministic quality screening with orchestrator evidence/guidance per answer, and fresh reconciliation per declared group. The group contains one answer in indiv_recon or eligible answers to the same original question across conditions in merged_recon. Both modes use the same checks and publication path. Scientific claim analysis is an independent branch selected as fresh or bypass. Bypass creates no new scientific review or re-audit and preserves existing published scientific output. A mechanical PASS proves structure and binding, never source truth.

| Step | Executor and allowed input | Required return | Advancement check |
|---|---|---|---|
| Preparation | Orchestrator; user scope, original questions, private source answers and source description | Run contract with explicit reconciliation mode and positive max_workers, clean-copy policy, private source/packet hashes and line receipts, source bindings, templates and readiness receipt | Source access/tests pass; each clean packet and support allowlist isolated and leak-audited |
| Initial review | One fresh reviewer per answer; only that clean answer and authorized source/method context | Complete numeric mapping, factual ledger, inventory, evidence, questions and immutable initial receipt | Identity, token/claim coverage, schema, source locators, scope and questions |
| Quality screening | Deterministic code; one immutable initial report at a time | Neutral lead list, including [] when none, and input/rule/code receipt | Every claim scanned; current hashes; no verdict edits; exact cache verification if reused |
| Orchestrator evidence and guidance | Final orchestrator; each answer, initial return, screen and raw source evidence | Per-answer GUIDANCE.json with findings, user decisions, recheck requests and pending questions | Guidance hashes match packet/initial/screen; source evidence checked; complete and ready for reconciliation |
| Group formation | Orchestrator; eligible clean packets, original-question hashes, units and selected mode | Declared groups and a public group manifest per group | Every unit covered exactly once; indiv groups singleton; merged members share identical original-question hash; all member inputs valid |
| Reconciliation | One fresh worker per declared group; only member packets/reports/screens/guidance and authorized source evidence | Distinct per-answer reconciliation decisions, responses to every lead/request, group return binding each decision, unaccepted provisional drafts when enabled | Group return and each member decision validate; no foreign answer or pooled verdict; pending questions linked |
| Fresh scientific branch | Independent reviewer per answer; only that answer and primary evidence | Scientific assertion ledger, categories, rationale and unresolved assertions | Scientific method and exact answer/source binding; no automatic translation from numerical labels |
| Final evidence acceptance | Final orchestrator; group returns, per-answer decisions, raw source and enabled scientific reviews | Per-answer evidence audit, accepted numerical/factual report and accepted scientific report only when fresh; resolved questions or scoped blocks | Recheck disputed/recovered/excluded claims, relevant inventories and exact claims across property/source groups; whole-answer coverage |
| Canonical export | Deterministic serializer; frozen accepted per-answer reports | Required canonical files and export receipt for each answer | Same schema/code in both modes; spans, counts, locators and allowlist verified |
| Statistics | Deterministic reader; explicitly selected accepted files | Requested tables/figures and denominator reconciliation | Selection/exclusions explicit; zero denominator transparent; no judgment changes |

The final orchestrator checks every return before advancing. The [orchestrator guidance contract](orchestrator-guidance.md) makes the pre-reconciliation evidence check concrete. User questions retain exact answer excerpts, source evidence, alternatives and affected claims. Independent work continues while a dependent decision awaits the user.

## Cache declarations

A published workflow states eligibility but contains no cached report or execution history. Runtime cache paths, statuses and receipts remain private.

| Stage | Reuse rule |
|---|---|
| Prepared input | Identical clean answer, original question, transform, private source-to-packet receipt and source bindings |
| Initial numerical/factual review | Only if user scope allows and exact identity, method, completeness, isolated authorship and evidence availability are proven; group mode does not change eligibility |
| Quality screen | Only if user scope allows, immutable initial inputs and rules match, and the complete output equals the current deterministic screen |
| Scientific claim analysis | Explicit fresh or bypass; fresh uses a separate one-answer worker, bypass creates no new review |
| Reconciliation | Fresh worker for every declared group, including singleton groups |
| Orchestrator evidence and acceptance | Fresh per-answer source check; existing scores do not authorize acceptance |
| Export/statistics | Regenerate from currently frozen accepted reports with validated code and explicit selection |

User-designated fresh answers bypass initial and screening cache reuse as specified in the run contract. Excluding generated diagnostics does not itself require rerunning otherwise compatible initial reports; decide per answer. Distinguish not_found, incompatible, eligible, reused and fresh_required. Preserve original cache bytes and method hashes; a reconstructed task from saved evidence is corroborated, never exact submitted bytes.

## Provisional and final ownership

The reconciler returns answer-specific decisions and any unaccepted provisional drafts for its declared group. Drafts use opaque IDs, exclude private treatment maps and independent scientific conclusions, and remain under runtime storage. An unresolved draft remains blocked. Its manifest and filenames cannot enter accepted statistics. The final orchestrator checks the group return and per-answer evidence, freezes every enabled layer, then invokes gated export and publication. A draft build does not constitute acceptance.

If final evidence review requires correction, preserve the worker's original return, group manifest/return, provisional draft and instruction receipt in private runtime history. Record an orchestrator correction receipt with original and accepted SHA256 values, affected claim/token IDs, source evidence and reasons. Revalidate the accepted working decision before freeze. Never describe an orchestrator correction as a new worker decision. In fresh scientific mode, preserve original and accepted reviews with evidence; bypass creates no scientific correction.

For compatible initial ThermoML reuse, the [cache receipt contract](../ThermoML/tools/CACHE_COMPATIBILITY.md) records immutable cached files and the final-orchestrator compatibility decision. Reuse replaces only the initial review submission record. Screening, guidance, fresh reconciliation, final source acceptance, freeze, export and statistics still pass current gates.

Fixed pipeline outputs are first-class pipeline_artifact numerical evidence. Compare their actual saved artifact values and keep full units/basis/state/session/source provenance; ordinary derived arithmetic is separate. In explicitly selected one-answer correction mode, use the existing report and actual artifacts through ThermoML/tools/CORRECTION_SCHEMA.md, preserving valid findings and requiring final orchestrator acceptance. Historical fit-exclusion policy is superseded without rewriting scoped user interpretations.

Primary numerical evidence: use fixed saved data/plots or the separately prepared fitting_tool_calls_verbatim.md containing physically extracted deterministic fitting-tool arguments and outputs. The dedicated fitting-call artifact is an eligible source for outputs such as BIC that are absent from CSVs. General run_history_verbatim.md, Completed Fits/working-memory summaries, and authored/delegated narrative are context/provenance only, never numerical primary sources. Private fixed-return extracts are eligible only when hash/locator-bound to the dedicated fitting-call artifact. For every saved numerical reference provide generating_call with path, tool, fit_session and an exact arguments_excerpt from the generating call; link CSV/plot identity, source inputs and basis to those arguments. Independent reviewer calculations and database searches are allowed and should be recorded with their source inputs and method; they do not become original saved pipeline outputs merely by being calculated during review.
