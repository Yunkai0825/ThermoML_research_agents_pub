# Build a source profile from scratch

Do not assume database-specific code exists. Start from user-supplied schema/documentation and a small read-only sample. Ask for missing facts below and record answers in the runtime contract before scoring.

| Required decision | What to obtain or implement |
|---|---|
| Identity | Stable record, publication, block and point identifiers where available; aliases; component and property registries; private mapping from original identities to opaque worker IDs |
| Physical meaning | Property definitions, phase, composition basis, state variables, units, uncertainty type and stored digit semantics |
| Scope | Exact system membership, pure-component endpoints, state filtering, property availability, counts and absence-search boundaries |
| Retrieval | Read-only inventory, block metadata, point lookup and query evidence log; preserve raw field locators and digits |
| Comparison | User-approved exact/near/miss thresholds, rounding rules, unit conversions and separate source/state judgments |
| Derived quantities | What counts as measured data, which outputs are derived, whether calculations are scored, and required input provenance; solver files remain evidence unless explicitly eligible |
| Scientific claims | Whether enabled; substantive assertion unit, categories, evidence standards and uncertainty handling |
| Blind input | Authored-response boundary, generated-diagnostic sections, deterministic cleaning transform, private line/removal receipt, worker-visible artifact audit |
| Serialization | Required canonical schemas, clean-copy span representation, source reference format, output allowlist and statistics denominators |
| Runtime | Supported model/CLI, tool permissions, isolation, recorded prompt placement and environment dependencies |

Implement a tokenizer with stable answer spans and a complete mapping schema. Implement the adapter using the real raw schema, never a synthetic approximation of it. Validate unit/state/source boundaries on small known records. Implement isolated per-answer initial validators, a deterministic per-answer screen, orchestrator guidance checks and a shared 1..N group reconciliation validator before dispatch. The screen flags possible inconsistencies without changing verdicts. indiv_recon forms singleton groups; merged_recon groups answers with identical original-question hashes across conditions. Support a question-scope exception only when the user explicitly authorizes the particular members: retain actual per-member hashes and validate that exact authorization at dispatch and acceptance. Both modes return distinct per-answer decisions and use the same acceptance/export path. Implement a deterministic exporter and statistics reader against the selected schema; test with meaningful fixtures.

Reuse the generic role templates by binding method, source, schema and command paths. Add an answer-producer supplement only when retrieval, analysis or synthesis changes evidence handling; it must not silently alter the numerical method. Require explicit reconciliation_mode and positive max_workers at intake; optional stage limits are positive and no greater than the global cap. Adapt profile-specific filenames and bindings in one documented interface. All required evaluation code must be contained in the published skill or generated from these contracts in the new runtime; no external evaluation repository is a prerequisite.

ThermoML has a complete supplied adapter/profile. For another archive, its exact fields and scripts are examples of interfaces, not assumptions about that archive's schema. A missing DOI or block convention should produce the user's chosen equivalent locator or an explicit NA reason, never an invented identifier.


Fixed pipeline outputs are first-class pipeline_artifact numerical evidence. Compare their actual saved artifact values and keep full units/basis/state/session/source provenance; ordinary derived arithmetic is separate. In explicitly selected one-answer correction mode, use the existing report and actual artifacts through ThermoML/tools/CORRECTION_SCHEMA.md, preserving valid findings and requiring final orchestrator acceptance. Historical fit-exclusion policy is superseded without rewriting scoped user interpretations.

Primary numerical evidence: use fixed saved data/plots or the separately prepared fitting_tool_calls_verbatim.md containing physically extracted deterministic fitting-tool arguments and outputs. The dedicated fitting-call artifact is an eligible source for outputs such as BIC that are absent from CSVs. General run_history_verbatim.md, Completed Fits/working-memory summaries, and authored/delegated narrative are context/provenance only, never numerical primary sources. Private fixed-return extracts are eligible only when hash/locator-bound to the dedicated fitting-call artifact. For every saved numerical reference provide generating_call with path, tool, fit_session and an exact arguments_excerpt from the generating call; link CSV/plot identity, source inputs and basis to those arguments. Independent reviewer calculations and database searches are allowed and should be recorded with their source inputs and method; they do not become original saved pipeline outputs merely by being calculated during review.
