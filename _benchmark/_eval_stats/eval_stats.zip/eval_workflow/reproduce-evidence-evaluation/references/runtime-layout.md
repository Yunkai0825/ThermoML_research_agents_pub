# Publication and runtime separation

The reusable skill contains instructions, templates, source profiles, schemas, deterministic tools and synthetic tests. It contains no answer corpus, evaluation, model transcript, dispatch receipt, source database copy, cached report, rerun directory or campaign record.

The user chooses separate runtime and publication roots. Reject a runtime root inside the published skill or statistics folder. The run contract may declare cache eligibility, but actual cache paths, hashes, statuses and receipts belong under runtime storage.

Suggested runtime structure, outside publication:

    RUNTIME_ROOT/
      control/                       private identity/corpus manifest, contract, source/packet receipts, questions
      public/
        maps/OPAQUE_ID/              one clean answer, original question, tokens, immutable initial report
        tools/lookups/               answer-specific read-only source lookup logs
        RUBRIC.txt, QUALITY_CHECKS.txt, SCREEN_RULES.txt
      instructions/                  rendered role instructions, exact submission records and responses
      screening/REVIEW_UNIT_ID/      per-answer CHECK_REQUESTS.json and SCREENING_CHECK.json
      guidance/OPAQUE_ID/            per-answer GUIDANCE.json after orchestrator evidence check
      reconciliation/
        units.json                   declared answer/review-unit identities
        groups.json                  group IDs covering every review unit exactly once
        REVIEW_UNIT_ID/             per-answer reconciliation.json
      groups/GROUP_ID/
        group.json                   scoped members and shared question hash or explicit per-member exception
        GROUP_RETURN.json            sealed return binding every member decision
      scientific/                    independent per-answer fresh review when selected
      private/                       original source, cleaning receipts, cache compatibility and identity map
      results/                       final evidence acceptance and judgment freeze
      staging/                       validated per-answer canonical files before publication

The layout is illustrative; the selected adapter's interface controls exact runtime paths. Keep the public group manifest and per-answer receipts free of private identities. A merged group shares the original-question SHA256 unless the user explicitly authorizes a recorded exception with actual per-member hashes and separate question scopes. An indiv_recon group has one member. Do not place a corpus-wide group index in the reconciler's read allowlist. Group output is provenance and completeness evidence; the accepted report remains per answer.

Keep original solver sessions linked by an explicit per-answer manifest, and copy only permitted support files. Evaluator working data is never a solver artifact. Shared source access remains read-only; lookup logs remain answer-specific. Record the runtime's actual read and write isolation limits.

Publication contains the reusable skill, selected canonical answer reports in their designated locations, and requested aggregate products. Raw data, private identities, group manifests, screens, guidance, provisional drafts, transcripts and caches remain in runtime storage. The selected source profile defines its exact per-answer publication allowlist.