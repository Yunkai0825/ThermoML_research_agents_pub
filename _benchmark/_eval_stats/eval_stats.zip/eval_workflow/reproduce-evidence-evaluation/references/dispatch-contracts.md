# Authored prompts and dispatch records

Every role has an authored system template. Initial numerical and fresh scientific workers compose common.system.md, their role system template and their single answer-type supplement, then render the role task. Reconciliation composes reconciler.system.md with the required member-scoped answer-type supplements and reconciler.task.md; it does not include the single-answer common.system.md. The orchestrator uses its own system and task templates. Group reconciliation applies the correct supplement to every declared member, including groups with different answer types. Bind literal UPPER_SNAKE markers and fail on missing or unexpanded bindings; do not interpret JSON braces as template fields.

| Role | System template | Task | Answer scope |
|---|---|---|---|
| Final orchestrator | orchestrator.system.md | orchestrator.task.md | Private run control and corpus inventory |
| Numerical/factual reviewer | numerical-reviewer.system.md | numerical-reviewer.task.md | One clean answer |
| Scientific reviewer, fresh mode | scientific-reviewer.system.md | scientific-reviewer.task.md | One clean answer and primary evidence |
| Reconciler | reconciler.system.md | reconciler.task.md | One declared clean group of 1..N members |

ThermoML supplements are ThermoML/templates/Query.system.md, Analysis.system.md and Main.system.md. They describe the answer producer and evidence handling; they never change the common numerical rubric.

Save for every dispatch: immutable template bytes/hashes; bindings; rendered system and task; exact effective submitted text; model and reasoning/runtime settings; allowed input paths and write destinations; source/helper command argument arrays; submission timestamp/runtime identifier; and actual instruction transport/placement. Preserve worker responses and first returns unchanged. A prepared instruction record is not evidence of dispatch; the launcher records the exact bytes actually submitted.

Authored system templates do not expose hidden platform instructions. If the runtime supports a separate system/developer message, record its actual placement. If it accepts only task text, submit the composed instructions there and record task_text placement. A file named system.md alone does not establish system-role delivery. Never fabricate settings, isolation or effective prompts.

## Input and write scope

Every initial numerical and fresh scientific worker starts with fresh context and one opaque answer ID. Its answer input is the validated clean packet, not the source original or removed diagnostics. Audit allowed reads, support files, rendered prompts and tool outputs for answer copies, private identities and evaluator verdicts before dispatch. Do not fork conversation history containing other answers. The initial worker may read its answer, original question, method, source adapter, raw source data and that answer's audited support. Scientific review is independent of numerical conclusions.

The reconciliation worker starts fresh for one group manifest. The shared adapter accepts 1..N members. indiv_recon forms singleton groups; merged_recon permits members with the same original-question SHA256 across conditions or an explicitly authorized question exception bound to each member's actual question hash. The dispatcher verifies the exception against the run contract before launch; a worker never invents authorization. The group manifest is its complete answer/review read allowlist: each declared clean packet, its immutable initial report, deterministic screen, [orchestrator guidance](orchestrator-guidance.md), matching interpretations and linked support. Raw source access remains authorized. Exclude other groups, global corpus/group indexes, treatment maps, private source answers, removed diagnostics, scoreboards and scientific-review conclusions. Verify that every group member is declared and all per-answer inputs are hash-bound before dispatch. One group reconciler occupies one parallelism slot.

A group member may inform a new source check but cannot supply another member's verdict or stored number. The worker writes only declared per-answer reconciliation outputs, authorized source lookup logs, and a group return binding every member decision. It must preserve per-answer judgments, question scopes and denominators. No group average is a canonical answer result.

Use filesystem-enforced read restrictions when available; otherwise record that reads are instruction-only and audit the precise submitted allowlist. Record write restrictions separately. Do not claim sandbox isolation that the actual runtime does not provide.

The orchestrator may inventory all answers and form groups, but must keep initial packets independent. Screening leads identify claim-specific rechecks without prescribing outcomes. Guidance records the orchestrator's source findings and user decisions with evidence, but the reconciler must verify the target answer against raw source records rather than adopt a conclusion merely because guidance says so.

The ThermoML packet renderer and launcher bindings are in [its interface](../ThermoML/tools/INTERFACE.md) and [dispatch contract](../ThermoML/tools/dispatch_contract.md). The deterministic quality screen records rules, code, argument arrays and input/output hashes; it has no LLM prompt. The final orchestrator has separate RUN_CONTRACT_PATH, SOURCE_PROFILE_PATH, RUNTIME_ROOT, PUBLICATION_ROOT and READINESS_RECEIPT_PATH bindings and is not a group worker.

## Mode and concurrency binding

The run contract must contain explicit method.reconciliation_mode and execution.parallelism.max_workers, a positive integer. Optional stage limits initial, reconciliation and scientific are positive integers at most max_workers. The scheduler enforces the global cap across stages; every worker process, including a grouped reconciler, consumes one slot. The orchestrator consumes none. Group size does not create extra worker slots. Record the actual selected mode and settings in the dispatch receipt. Reconciliation remains fresh for every declared group; only eligible initial and deterministic screening returns may be reused.

The reconciler task includes the scoped group manifest, exact per-answer output destinations, validation/seal command and unaccepted provisional-build command. Its return is group-bound and contains a distinct decision for every member. The final orchestrator alone accepts evidence, freezes judgments, restores identities and publishes canonical files.