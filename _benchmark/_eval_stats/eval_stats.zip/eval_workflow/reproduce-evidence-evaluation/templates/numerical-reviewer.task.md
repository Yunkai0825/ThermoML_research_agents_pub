Evaluate answer {{ANSWER_ID}} independently.

Answer: {{ANSWER_PATH}}
Original question: {{QUESTION_PATH}}
Owned packet/output directory: {{PACKET_DIR}}
Numerical rubric: {{NUMERICAL_METHOD_PATH}}
Quality checks: {{QUALITY_CHECKS_PATH}}
Mapping contract: {{MAPPING_CONTRACT_PATH}}
Applicable user interpretations: {{INTERPRETATIONS_PATH}}
Source bindings: {{SOURCE_BINDINGS_PATH}}
Package tools: {{TOOLS_DIR}}
Output schema: {{OUTPUT_SCHEMA_PATH}}
Support artifact manifest: {{ARTIFACT_MANIFEST_PATH}}
Support artifact directory: {{ARTIFACT_DIR}}

Read the sanitized answer.md, annotated.txt and tokens.json. The private source and cleaning receipt are outside your read allowlist. Apply the rubric in source order. Inspect raw source metadata and records and save an exact-system/property/state inventory where the scope requires it. Write mapping.json, claims.jsonl, coverage.json, questions.json and final_review.json; save source evidence under your packet. The mapping contract specifies the resolver schema. Do not insert source values into selectors in place of raw lookups.

Read-only source command prefix: {{SOURCE_COMMAND_PREFIX}}
Resolve mapped numbers: {{RESOLVE_COMMAND}}
Validate this initial packet: {{INITIAL_CHECK_COMMAND}}

Execute commands using their recorded argument arrays. Inspect resolver findings for semantic errors; make any correction evidence-backed. Assign every lexical number, check all factual count/absence/coverage claims, and leave only genuine unresolved interpretations in questions.json. Apply the pipeline_artifact contract to fixed solver outputs; inventory every reported occurrence and inspect its artifact before scoring. Run the initial validator and repair defects. Finish with output paths, check status and unresolved question IDs; do not publish.

Primary numerical evidence: use fixed saved data/plots or the separately prepared fitting_tool_calls_verbatim.md containing physically extracted deterministic fitting-tool arguments and outputs. The dedicated fitting-call artifact is an eligible source for outputs such as BIC that are absent from CSVs. General run_history_verbatim.md, Completed Fits/working-memory summaries, and authored/delegated narrative are context/provenance only, never numerical primary sources. Private fixed-return extracts are eligible only when hash/locator-bound to the dedicated fitting-call artifact. For every saved numerical reference provide generating_call with path, tool, fit_session and an exact arguments_excerpt from the generating call; link CSV/plot identity, source inputs and basis to those arguments. Independent reviewer calculations and database searches are allowed and should be recorded with their source inputs and method; they do not become original saved pipeline outputs merely by being calculated during review.
