Evaluate scientific assertions in answer {{ANSWER_ID}} independently.

Answer: {{ANSWER_PATH}}
Original question: {{QUESTION_PATH}}
Owned scientific output directory: {{SCIENTIFIC_REVIEW_DIR}}
Scientific method: {{SCIENTIFIC_METHOD_PATH}}
Output schema: {{OUTPUT_SCHEMA_PATH}}
Applicable user interpretations: {{INTERPRETATIONS_PATH}}
Source bindings: {{SOURCE_BINDINGS_PATH}}
Package tools: {{TOOLS_DIR}}
Support artifact manifest: {{ARTIFACT_MANIFEST_PATH}}
Support artifact directory: {{ARTIFACT_DIR}}
Read-only source command prefix: {{SOURCE_COMMAND_PREFIX}}
Validate this scientific packet: {{SCIENTIFIC_CHECK_COMMAND}}

Read the complete clean packet answer and method. The review-copy boundary marker is the end of scope; do not seek later private source sections. Inventory substantive assertions, preserving exact excerpts and context. Follow the schema for review.json and its question/evidence files. Assign a resolved scientific category only when established by the supplied method and evidence. Keep unresolved assertions explicitly uncategorized. Save source traces and rationale for every judgment. Do not read a numerical review or infer categories from its labels. Run the scientific validator and repair defects. Finish with output paths, check status and unresolved question IDs; do not publish.

A numerical-scoring exclusion alone does not prohibit scientific conversion/calculation checks expressly authorized by the scientific method. Independent calculations and database searches are allowed; distinguish reviewer calculations from original saved fixed outputs and retain the calculation method and source inputs. Inspect original solver artifacts for lineage and reported outputs; artifact agreement alone does not prove calculation correctness. Resolve the scientific assertion from permitted evidence or record consequential uncertainty. Simple dimensional/conversion validation remains permitted when the scientific method allows it.