"""Read fixed pipeline values from this answer's hashed, sanitized artifact allowlist."""
from __future__ import annotations
import csv
import hashlib
import io
import json
import re
from decimal import Decimal
from pathlib import Path
from filesystem_paths import io_path
from compare_core import compare, convert
from fitting_precision import compare_fitting, precision_role

CLASSIFICATION = 'pipeline_artifact'
SOURCE = 'hardcoded_artifact'
GROUP = 'pipeline_artifact'

def sha(path):
    return hashlib.sha256(io_path(path).read_bytes()).hexdigest()

def load(path):
    return json.loads(io_path(path).read_text(encoding='utf-8-sig'))

def artifact_bytes(packet, relative):
    relative = str(relative)
    p = Path(relative)
    if p.is_absolute() or '..' in p.parts:
        raise ValueError('artifact path must remain within this answer allowlist')
    manifest=load(Path(packet)/'BLIND_INPUT.json')
    entries = manifest.get('artifact_files', [])
    allowed = {entry['path']:entry['sha256'] for entry in entries}
    normalized = p.as_posix()
    path = (io_path(packet)/'artifacts'/p).resolve(strict=True)
    if not path.is_relative_to((io_path(packet)/'artifacts').resolve()) or normalized not in allowed:
        raise ValueError('artifact is not in this answer allowlist')
    if True:  # Every pipeline source must satisfy the published-only eligibility contract.
        entry=next(item for item in entries if item['path']==normalized);origin=entry.get('eligibility',{})
        if origin.get('root')!='own_answer/eval/artifacts' or origin.get('owner_answer_id')!=manifest.get('answer_id'):
            raise ValueError('pipeline source must originate in own answer eval/artifacts')
        source_path=Path(origin.get('source_path',''))
        if not origin.get('source_path') or source_path.is_absolute() or '..' in source_path.parts or not re.fullmatch('[0-9a-f]{64}',origin.get('source_sha256','')):
            raise ValueError('pipeline source lacks an eligible published-file hash/locator')
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != allowed[normalized]:
        raise ValueError('artifact hash changed')
    return data, digest

def primary_source_entry(packet, relative):
    manifest=load(Path(packet)/'BLIND_INPUT.json')
    entry=next((item for item in manifest['artifact_files'] if item['path']==Path(relative).as_posix()),None)
    if entry is None or entry.get('numeric_primary_eligible') is not True:
        raise ValueError('artifact is context/provenance only, not a numeric primary source')
    origin=entry.get('eligibility',{});source=Path(origin.get('source_path',''))
    if source.suffix.lower()=='.md' and (source.name!='fitting_tool_calls_verbatim.md' or origin.get('source_role')!='deterministic_fitting_tool_calls'):
        raise ValueError('general history and authored Markdown are context only; use deterministic fitting-call artifact or saved data')
    if 'completed_fits' in str(relative).lower() or source.name in {'_working_memory.md','run_history.md','run_history_verbatim.md'}:
        raise ValueError('Completed Fits and general history cannot be numeric primary sources')
    return entry


def locate(packet, spec):
    primary_source_entry(packet,spec['path'])
    data, digest = artifact_bytes(packet, spec['path'])
    text = data.decode('utf-8-sig')
    fmt = spec['format']
    if fmt == 'csv':
        rows = list(csv.DictReader(io.StringIO(text)))
        row = spec['row']
        if type(row) is not int or row < 1:
            raise ValueError('CSV row must be one-based data row (header excluded)')
        value = rows[row-1][spec['field']]
        if spec.get('key') is not None and rows[row-1].get(spec.get('key_field','key')) != spec['key']:
            raise ValueError('CSV row key mismatch')
    elif fmt == 'json':
        value = json.loads(text, parse_float=str, parse_int=str)
        pointer = spec['pointer']
        if not isinstance(pointer,str) or not pointer.startswith('/'):
            raise ValueError('JSON pointer required')
        for item in pointer[1:].split('/'):
            item = item.replace('~1','/').replace('~0','~')
            value = value[int(item)] if isinstance(value,list) else value[item]
    elif fmt == 'text':
        line = spec['line']
        if type(line) is not int or line < 1:
            raise ValueError('one-based text line required')
        source = text.splitlines()[line-1]
        if spec.get('excerpt') != source:
            raise ValueError('text line excerpt changed')
        matches = list(re.finditer(spec['pattern'],source))
        if len(matches)!=1 or 'value' not in matches[0].groupdict():
            raise ValueError('text selector must locate exactly one named value')
        value=matches[0]['value']
    else:
        raise ValueError('unsupported artifact selector format')
    Decimal(str(value))
    return str(value), digest

def context_evidence(packet, ref):
    for name in ('stored_unit','claimed_unit','basis','claimed_basis','fit_session','source_inputs','state','source_context'):
        if not ref.get(name):
            raise ValueError('artifact reference lacks '+name)
    if not isinstance(ref['source_inputs'],list) or not isinstance(ref['source_context'],list):
        raise ValueError('artifact source_inputs and source_context must be nonempty lists')
    receipts=[]
    for spec in ref['source_context']:
        data,digest=artifact_bytes(packet,spec['path'])
        text=data.decode('utf-8-sig').replace('\r\n','\n').replace('\r','\n')
        if not spec.get('excerpt') or spec['excerpt'] not in text:
            raise ValueError('artifact context excerpt absent from inspected file')
        if not spec.get('supports') or set(spec['supports'])-{'stored_unit','basis','fit_session','source_inputs','state'}:
            raise ValueError('context must identify metadata fields it supports')
        receipts.append({**spec,'sha256':digest})
    supported={name for row in receipts for name in row['supports']}
    if supported != {'stored_unit','basis','fit_session','source_inputs','state'}:
        raise ValueError('artifact context does not cover unit/basis/session/input/state evidence')
    return receipts

def inspect_generating_call(packet, ref):
    call=ref.get('generating_call')
    if not isinstance(call,dict) or not all(call.get(key) for key in ('path','tool','fit_session','arguments_excerpt')):
        raise ValueError('fixed pipeline source requires exact generating tool arguments and session locator')
    if call['fit_session']!=ref.get('fit_session'):
        raise ValueError('generating call and numeric artifact session differ')
    manifest=load(Path(packet)/'BLIND_INPUT.json')
    entry=next((item for item in manifest['artifact_files'] if item['path']==Path(call['path']).as_posix()),{})
    origin=entry.get('eligibility',{})
    if Path(origin.get('source_path','')).name!='fitting_tool_calls_verbatim.md' or origin.get('source_role')!='deterministic_fitting_tool_calls':
        raise ValueError('generating arguments must originate in the dedicated deterministic fitting-call artifact')
    numeric_entry=next((item for item in manifest['artifact_files'] if item['path']==Path(ref['path']).as_posix()),{})
    numeric_origin=numeric_entry.get('eligibility',{})
    numeric_identity=numeric_origin.get('call_identity');argument_identity=origin.get('call_identity')
    if numeric_identity is not None and (numeric_identity!=argument_identity or numeric_origin.get('source_path')!=origin.get('source_path')):
        raise ValueError('numeric fixed return and generating arguments identify different original calls')
    if argument_identity is not None and argument_identity.get('tool')!=call['tool']:
        raise ValueError('declared generating tool differs from actual original call')
    data,digest=artifact_bytes(packet,call['path'])
    if call['arguments_excerpt'].replace('\r\n','\n') not in data.decode('utf-8-sig').replace('\r\n','\n'):
        raise ValueError('generating call argument excerpt is not present in eligible provenance')
    return {**call,'sha256':digest,'inspected':True}


def inspect_reference(packet, ref):
    stored,digest=locate(packet,ref)
    generating_call=inspect_generating_call(packet,ref)
    context=context_evidence(packet,ref)
    try:
        converted=str(convert(stored,ref['stored_unit'],ref['claimed_unit']))
        unit_error=None
    except ValueError as exc:
        converted=None;unit_error=str(exc)
    manifest=load(Path(packet)/'BLIND_INPUT.json')
    origin=next(item['eligibility'] for item in manifest['artifact_files'] if item['path']==Path(ref['path']).as_posix())
    return {**ref,'sha256':digest,'generating_call':generating_call,'eligible_artifact_origin':origin,'stored_value':stored,'converted_stored_value':converted,
            'source_context':context,'unit_error':unit_error,'inspected':True}

def inspect_population_interpretation(packet, ref, spec):
    """User-scoped R-K population; retain native n_points and real component values."""
    registry_path=Path(__file__).resolve().parents[1]/'user-interpretations.json'
    decision=next((x for x in load(registry_path)['entries'] if x['id']==spec.get('decision_id')),None)
    if not decision or decision.get('id')!='H72' or decision.get('status')!='active' or spec.get('user_reply_exact')!=decision['user_reply_exact']:
        raise ValueError('population interpretation needs confirmed active H72 exact reply')
    if spec.get('population')!='mixtures_plus_pure_references' or not spec.get('reason'):
        raise ValueError('explicit population and contextual reason required')
    answer=(io_path(packet)/'answer.md').read_text(encoding='utf-8-sig');quotes=spec.get('answer_context',[])
    if not quotes or any(not q or q not in answer for q in quotes):raise ValueError('population answer context absent')
    if ref.get('key')!='n_points' or ref['stored_unit']!='1' or ref['claimed_unit']!='1':raise ValueError('native dimensionless n_points required')
    pure=spec.get('pure_references',[])
    if not pure or len({x.get('component') for x in pure})!=len(pure) or any(not x.get('component') for x in pure):raise ValueError('distinct pure reference components required')
    receipts=[]
    for item in pure:
        if item['path'] not in {x['path'] for x in ref['source_context']}:raise ValueError('pure references must belong to inspected fit source context')
        value,digest=locate(packet,item)
        if item['component'] not in item.get('excerpt','') or Decimal(value)<=0:raise ValueError('actual positive pure reference source row required')
        receipts.append({**item,'stored_value':value,'sha256':digest})
    if len({(x['path'],x.get('line'),x.get('pattern')) for x in receipts})!=len(receipts):raise ValueError('pure references double counted')
    total=Decimal(ref['stored_value'])+len(receipts)
    return {**spec,'pure_references':receipts,'native_mixture_count':ref['stored_value'],'pure_reference_count':len(receipts),'interpreted_count':str(total),'derivation':f"{ref['stored_value']} + {len(receipts)} = {total}",'native_basis':ref['basis'],'registry_sha256':sha(registry_path)}


def shared_range_scale(token):
    """Read a low range endpoint's explicit shared scientific multiplier."""
    suffix=token.get('line_text','')[token['end_column']-1:]
    match=re.match(r'^\s*[–—]\s*(?P<high>[0-9]+(?:\.[0-9]+)?)\s*×\s*10(?P<exponent>[⁻⁺⁰¹²³⁴⁵⁶⁷⁸⁹]+)',suffix)
    if not match or not re.fullmatch(r'[+−-]?[0-9]+(?:\.[0-9]+)?',token['text']):return None
    if Decimal(token['parsed_value'])>Decimal(match['high']):return None
    exponent=match['exponent'].translate(str.maketrans('⁻⁺⁰¹²³⁴⁵⁶⁷⁸⁹','-+0123456789'))
    if not re.fullmatch(r'[+-]?[0-9]+',exponent):return None
    factor=Decimal(10)**int(exponent)
    return {'value':str(Decimal(token['parsed_value'])*factor),'tolerance':str(Decimal(token['display_tolerance'])*factor),'factor':str(factor),'reason':'The low endpoint shares the explicit scientific multiplier printed after the high endpoint of this en/em-dash range; original lexical token/span retained.'}



def inspect_magnitude_interpretation(packet, ref, spec):
    """Interpret the signed extremum printed in a Max |excess| field as a magnitude."""
    context=spec.get('answer_context','')
    answer=(io_path(packet)/'answer.md').read_text(encoding='utf-8-sig')
    if not context or context not in answer or not re.search(r'magnitude|Max(?:imum)?\s*\\?\|',context,re.I) or not spec.get('reason'):
        raise ValueError('magnitude interpretation requires exact explicit answer magnitude context and reason')
    if ref.get('format')!='text' or ref.get('unit_error'):
        raise ValueError('magnitude interpretation requires compatible units and a fixed Max |excess| text field')
    data,_=artifact_bytes(packet,ref['path']);line=data.decode('utf-8-sig').splitlines()[ref['line']-1]
    if not re.search(r'Max\s*\|excess\|',line,re.I):raise ValueError('selected fixed field is not Max |excess|')
    return {**spec,'operation':'absolute_magnitude','native_stored_value':ref['stored_value'],'native_converted_value':ref['converted_stored_value'],'interpreted_value':str(abs(Decimal(ref['converted_stored_value']))),'native_basis':ref['basis'],'claimed_basis':ref['claimed_basis'],'source_field_excerpt':line}


def resolve_artifact(packet, token, check):
    if check.get('classification') != CLASSIFICATION or check.get('source_kind') != SOURCE or check.get('quantity',{}).get('kind') != 'property':
        raise ValueError('fixed pipeline output requires pipeline_artifact category with property quantity and hardcoded_artifact source')
    row={**token,'classification':CLASSIFICATION,'source_kind':SOURCE,'group':GROUP,
         'unit':check.get('unit'),'role':check['role'],'property':check.get('property'),
         'out_of_scope_reason':None,'flags':[],'lookup_ids':[],'candidate_records':[],
         'n_candidates':0,'viable_candidate_ids':[],'artifact_inspected':False}
    if 'artifact_reference' not in check:
        manifest=load(Path(packet)/'BLIND_INPUT.json')
        if manifest.get('source_pool_audit_required'):
            audit=load(Path(packet)/'SOURCE_POOL_AUDIT.json')
            if audit.get('complete') is not True or audit.get('artifact_manifest_sha256')!=sha(Path(packet)/'BLIND_INPUT.json'):
                raise ValueError('missing artifact cannot be accepted before complete answer-bound source pool audit')
        search=check.get('artifact_search',{})
        if search.get('complete') is not True or not search.get('reason') or not search.get('search_boundary'):
            raise ValueError('missing pipeline artifact requires completed explicit negative search')
        files=search.get('inspected_files')
        if not isinstance(files,list):
            raise ValueError('negative artifact search needs inspected_files list')
        receipts=[]
        for name in files:
            _,digest=artifact_bytes(packet,name);receipts.append({'path':name,'sha256':digest})
        allowed={entry['path'] for entry in load(Path(packet)/'BLIND_INPUT.json').get('artifact_files',[])}
        if set(files)!=allowed:
            raise ValueError('negative search must inspect every allowed artifact')
        return {**row,'category':'miss','numeric_outcome':'miss','source_outcome':'miss',
                'condition_outcome':'not_applicable','stored_value':None,'stored_unit':None,
                'converted_stored_value':None,'artifact_search':{**search,'receipts':receipts},
                'artifact_inspected':True,'reason_code':'evidence_gap','reason':search['reason'],
                'flags':['artifact_not_found']}
    ref=inspect_reference(packet,check['artifact_reference'])
    if check.get('curve_verification'):
        from curve_reference import resolve as resolve_curve
        return resolve_curve(packet,token,check,ref,row)
    if check.get('unit')!=ref['claimed_unit']:
        raise ValueError('artifact claimed unit conflicts with mapped answer unit')
    comparison_value=token['parsed_value'];sign_interpretation=None
    prefix=token.get('line_text','')[:token['column']-1]
    if check.get('integer_output') and 'order' in check.get('property','').lower() and re.fullmatch(r'-[0-9]+',token['text']) and re.search(r'\border$',prefix,re.I):
        comparison_value=str(abs(Decimal(token['parsed_value'])))
        sign_interpretation='The literal ASCII hyphen in order-N joins the noun to a nonnegative polynomial order; original token text/span and lexical parsed value are retained.'
    if check.get('equation_sign_interpretation'):
        spec=check['equation_sign_interpretation']
        if spec.get('operation')!='preceding_subtraction' or not spec.get('reason'):
            raise ValueError('equation sign interpretation requires explicit subtraction operation and reason')
        if 'coefficient' not in check.get('property','').lower() or not re.search(r'[-−]\s+$',prefix) or Decimal(token['parsed_value'])<0 or token['text'].startswith(('-', '−', '+')):
            raise ValueError('equation sign interpretation requires unsigned coefficient immediately following a subtraction operator')
        if '=' not in token.get('line_text','') or token.get('line_text','')[token['column']-1:token['end_column']-1]!=token['text']:
            raise ValueError('equation sign interpretation requires an exact token span within an equation')
        comparison_value=str(-Decimal(token['parsed_value']))
        sign_interpretation='The displayed equation subtraction operator applies to this coefficient; original unsigned token/span and lexical parsed value are retained. '+spec['reason']
    scale=shared_range_scale(token)
    comparison_tolerance=token['display_tolerance']
    if scale:comparison_value=scale['value'];comparison_tolerance=scale['tolerance']
    if ref['unit_error']:
        comparison=compare(comparison_value,ref['stored_value'],comparison_tolerance)
        raw_numeric=comparison['category'];numeric='miss';comparison['flags'].append('unit_mismatch')
    else:
        tolerance='0' if check.get('integer_output') else comparison_tolerance
        comparison=compare_fitting(comparison_value,ref['converted_stored_value'],tolerance,precision_role(check,ref))
        numeric=comparison['category']
        if check.get('integer_output') and Decimal(comparison_value) != Decimal(ref['converted_stored_value']):
            comparison['category']=numeric='miss'
    magnitude=None;magnitude_raw=None
    if check.get('magnitude_interpretation'):
        magnitude=inspect_magnitude_interpretation(packet,ref,check['magnitude_interpretation'])
        magnitude_raw=numeric
        comparison=compare_fitting(comparison_value,magnitude['interpreted_value'],comparison_tolerance,precision_role(check,ref));numeric=comparison['category']
        ref['magnitude_interpretation']=magnitude
    population=None
    if check.get('population_interpretation'):
        if ref['unit_error']:raise ValueError('population interpretation cannot repair incompatible units')
        population=inspect_population_interpretation(packet,ref,check['population_interpretation'])
        comparison=compare(comparison_value,population['interpreted_count'],'0');numeric=comparison['category']
        if Decimal(comparison_value)!=Decimal(population['interpreted_count']):numeric=comparison['category']='miss'
    basis='exact' if population or magnitude or ref['basis']==ref['claimed_basis'] else 'miss'
    # The semantic reviewer must check source/session/state independently; this
    # reader certifies located bytes and unit/basis comparison, not scientific truth.
    return {**row,**comparison,'category':'miss' if basis=='miss' or ref['unit_error'] else numeric,
            'comparison_value':comparison_value,'lexical_sign_interpretation':sign_interpretation,'population_interpretation':population,'magnitude_interpretation':magnitude,'lexical_scale_interpretation':scale,'comparison_tolerance':comparison_tolerance,
            'unit_outcome':'miss' if ref['unit_error'] else 'exact',
            'raw_numeric_outcome':magnitude_raw if magnitude else comparison['category'] if ref['unit_error'] else numeric,
            'numeric_outcome':numeric,'basis_outcome':basis,'artifact_reference':ref,
            'artifact_inspected':True,'stored_value':ref['stored_value'],'stored_unit':ref['stored_unit'],
            'converted_stored_value':ref['converted_stored_value'],'n_candidates':1,
            'reason':'Inspected fixed pipeline output; retain independent source/state review.'}

def inventory_errors(packet, mapping, rows, final=False):
    errors=[]; inventory=mapping.get('pipeline_inventory')
    if not isinstance(inventory,dict) or inventory.get('complete') is not True or inventory.get('answer_sha256')!=sha(Path(packet)/'answer.md'):
        return ['missing, incomplete or stale pipeline_inventory']
    entries=inventory.get('occurrences',[])
    ids=[x.get('token_id') for x in entries]
    if len(ids)!=len(set(ids)) or any(x.get('classification')!=CLASSIFICATION or not x.get('reason') for x in entries):
        errors.append('pipeline inventory contains duplicate or unclassified occurrences')
    checks={x['token_id']:x for x in mapping.get('checks',[])}
    declared={tid for tid,x in checks.items() if x.get('classification')==CLASSIFICATION or x.get('source_kind')==SOURCE}
    if set(ids)!=declared:
        errors.append('pipeline inventory and mapped artifact checks differ')
    rowmap={x.get('token_id'):x for x in rows}
    for tid in ids:
        check=checks.get(tid,{})
        row=rowmap.get(tid,{})
        if row.get('classification')!=CLASSIFICATION or row.get('source_kind')!=SOURCE:
            errors.append(tid+': pipeline output excluded or mislabeled')
            continue
        if final and row.get('group')!=GROUP:
            errors.append(tid+': pipeline output must use first-class pipeline_artifact group')
        try:
            tokens={t['token_id']:t for t in load(Path(packet)/'tokens.json')}
            inspected=resolve_artifact(packet,tokens[tid],check)
            if not final:
                for key in ('category','stored_value','stored_unit','converted_stored_value','artifact_inspected'):
                    if row.get(key)!=inspected.get(key):
                        errors.append(tid+': stored artifact comparison differs: '+key)
            else:
                if row.get('numeric_outcome')!=inspected['numeric_outcome']:
                    errors.append(tid+': final numeric comparison lacks inspected artifact support')
                if (inspected.get('basis_outcome')=='miss' or inspected.get('unit_outcome')=='miss') and row.get('outcome')!='miss':
                    errors.append(tid+': basis mismatch concealed')
                if inspected.get('reason_code')=='evidence_gap' and (row.get('outcome')!='miss' or row.get('reason_code')!='evidence_gap'):
                    errors.append(tid+': missing artifact must remain evidence-gap Miss')
                if row.get('artifact_inspected') is not True:
                    errors.append(tid+': final artifact inspection not confirmed')
        except (ValueError,KeyError,IndexError,OSError,TypeError) as exc:
            errors.append(tid+': artifact inspection failed: '+str(exc))
    return errors


PIPELINE_TERMS = re.compile(r"\b(?:RMSE|RMSD|BIC|AICc?|R-squared|r_squared|fit(?:ted|ting)?|coefficients?|polynomial order)\b|R[²2]|A[₀₁₂₃₄₅₆₇₈₉]", re.I)
BLANKET_EXCLUSION = re.compile(r"(?:not[_ ]recomputed|outside.*(?:fit|model)|(?:fit|model).*outside|provenance[_ ]only|input[_ ]lineage[_ ]only)", re.I)


def chemical_locant(token):
    # Chemical-name position numerals are lexical labels, not fitted outputs.
    text=token.get('text','');line=token.get('line_text','');end=token.get('end_column',0)
    return bool(re.fullmatch(r'[1-9][0-9]*',text) and re.match(r'[-‑](?:propan|butan|pentan|hexan|pyrrolid|ethan)[A-Za-z-]*',line[max(0,end-1):]))


def exclusion_errors(packet, mapping, claims):
    """Catch known pipeline-as-derived failures without scoring equation exponents."""
    errors=[]
    tokens={t['token_id']:t for t in load(Path(packet)/'tokens.json')}
    inventory={x.get('token_id') for x in mapping.get('pipeline_inventory',{}).get('occurrences',[])}
    for exclusion in mapping.get('exclusions',[]):
        reason=exclusion.get('reason','')
        detail=exclusion.get('detail','')
        for tid in exclusion.get('tokens',[]):
            t=tokens.get(tid,{})
            context=t.get('line_text','')+' '+detail
            if reason=='label' and (t.get('lexical_kind') in {'superscript','subscript'} or 'exponent' in detail.lower() or 'index' in detail.lower()):
                continue
            if tid in inventory:
                errors.append(tid+': inventoried pipeline output excluded')
            elif reason in {'derived','fit_statistic','artifact_metadata'} and PIPELINE_TERMS.search(context) and BLANKET_EXCLUSION.search(detail):
                errors.append(tid+': fixed pipeline output cannot use derived/metadata exclusion')
    for claim in claims:
        text=claim.get('quote','')+' '+claim.get('reason','')
        actual=[tid for tid in claim.get('token_ids',[]) if tokens.get(tid,{}).get('lexical_kind') not in {'superscript','subscript'} and not chemical_locant(tokens.get(tid,{}))]
        if actual and claim.get('verdict')=='outside' and PIPELINE_TERMS.search(text) and BLANKET_EXCLUSION.search(claim.get('reason','')):
            errors.append(str(claim.get('claim_id'))+': fitted output blanket exclusion is a failed review')
    return errors
