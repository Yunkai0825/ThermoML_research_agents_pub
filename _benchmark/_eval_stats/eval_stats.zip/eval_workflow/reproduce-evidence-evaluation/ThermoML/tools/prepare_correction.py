"""Prepare and record one-answer correction inputs; never launches a worker."""
import argparse
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path
from filesystem_paths import io_path
from tokenize_numbers import tokenize
from sanitize_answer import assert_clean, check_artifact, _embedded_flag_ranges
from canonical_export import _counts, _claim_counts
from artifact_source import sha
from native_tool_returns import extract as extract_native_returns, artifact_stem
from artifact_preparation_gate import ensure_for_answer

TOOLS=Path(__file__).parent
WORKFLOW=TOOLS.parent.parent

def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def sanitized_existing(document):
    """Keep this answer's findings while withholding treatment and foreign review identities."""
    document=json.loads(json.dumps(document))
    own_ids={str(document.get("answer",{}).get(k)) for k in ("answer_id","blind_id")}
    claim_ids=[str(c['claim_id']) for c in document.get('factual_claims',[]) if c.get('claim_id')]
    if len(claim_ids)!=len(set(claim_ids)):raise ValueError('existing same-answer claim IDs are not unique')
    protected={f'OWNCLAIMIDENTITY{i}END':cid for i,cid in enumerate(claim_ids)}
    forbidden={"arm","gate_mode","folder","paired_answer_id","paired_folder","pair_id","treatment","condition_label"}
    def clean(node):
        if isinstance(node,dict):
            return {key:clean(value) for key,value in node.items() if key not in forbidden}
        if isinstance(node,list):return [clean(value) for value in node]
        if isinstance(node,str):
            for marker,cid in protected.items():node=node.replace(cid,marker)
            node=re.sub(r"(?<![A-Za-z0-9])[AFGC]\d{3,}(?![A-Za-z0-9])",lambda m:m.group() if m.group() in own_ids else '[foreign review identity removed]',node)
            node=re.sub(r"(?<![A-Za-z0-9])(?:test_run_)?(?:full_capability(?:-r1_1)?|no_ledger|ablation|ungated|gated)(?![A-Za-z0-9])", '[treatment removed]',node,flags=re.I)
            for marker,cid in protected.items():node=node.replace(marker,cid)
            return node
        return node
    document=clean(document)
    if [c.get('claim_id') for c in document.get('factual_claims',[])]!=claim_ids:raise ValueError('sanitization changed own claim identity')
    document['sources']={"prior_same_answer_evaluation":"source bindings withheld from worker; exact original preserved privately"}
    document['evaluation']={"mode":"sanitized_existing_same_answer_report"}
    document['answer']['paired_answer_id']=None;document['answer']['paired_folder']=None
    return document



def mask_embedded_verdict_clauses(text):
    """Mask generated provenance verdict clauses without moving authored spans."""
    patterns=[r'; however, these specific [^;\n]*? are flagged as (?:UNVERIFIED|UNGROUNDED) against the source database',
              r'- Several quoted values carry unresolved UNVERIFIED/AMBIGUOUS flags, reducing confidence in ancillary numerical details though ',
              r'; numerous UNGROUNDED DATA FLAGS were raised for these derived numbers',
              r' flagged as UNVERIFIED',
              r'Confidence reduced to medium because the first subagent run \(run_5\) failed to produce verified fit_block output per its verdict, and while the second subagent run \(run_6\) shows a successful fit_block call returning numerical coefficients, the identical numerical values across both runs warrant caution\.']
    pattern='|'.join('(?:'+item+')' for item in patterns)
    replacements=[]
    def mask(match):
        if re.search(r'\d',re.sub(r'run_[56]', '', match.group())):raise ValueError('diagnostic clause contains numeric content; inspect before sanitation')
        replacements.append({'text':match.group(),'start':match.start(),'end':match.end()})
        return ' '*len(match.group())
    return re.sub(pattern,mask,text),replacements


def clean_existing_inputs(document, data):
    """Remove only recognized generated diagnostics, keeping authored spans/IDs."""
    document=json.loads(json.dumps(document))
    text=data.decode('utf-8-sig');lines=text.splitlines();ranges=_embedded_flag_ranges(lines)
    for i,line in enumerate(lines):
        if (line.startswith(('- Several quoted values carry ', '- Several quoted values (including ', '- Several quoted block-scope boundary values ', '- Many specific numerical ranges and composition limits quoted ')) and re.search(r'\b(?:UNVERIFIED|MISATTRIBUTED|UNGROUNDED)\b',line) and 'flags' in line) or line.startswith(('- Multiple data blocks cited in the answer were flagged as UNINSPECTED, meaning the quoted numerical values could not be fully verified against verbatim data inspection during the analysis run.', '- Multiple data blocks cited in the analysis were flagged as UNINSPECTED, meaning many quoted numerical values could not be verified against verbatim database inspection.', '- Multiple source data blocks quoted in the answer were flagged as UNINSPECTED, meaning the underlying data values could not be fully verified against the database within the analysis run.')):
            if re.search(r'\d',line):
                if 'though the primary' in line:continue  # only its nonnumeric verdict prefix is masked below
                raise ValueError('diagnostic-only summary has numeric content; inspect before sanitation')
            if not any(a<=i<z for a,z in ranges):ranges.append((i,i+1))
    removed={i+1 for start,stop in ranges for i in range(start,stop)}
    if ranges:
        for start,stop in ranges:lines[start:stop]=['']*(stop-start)
        data=('\n'.join(lines)+'\n').encode('utf-8')
    masked,inline_diagnostics=mask_embedded_verdict_clauses(data.decode('utf-8-sig'))
    if inline_diagnostics:
        data=masked.encode('utf-8')
        def mask_report(node):
            if isinstance(node,dict):return {k:mask_report(v) for k,v in node.items()}
            if isinstance(node,list):return [mask_report(v) for v in node]
            if isinstance(node,str):
                for item in inline_diagnostics:node=node.replace(item['text'],' '*len(item['text']))
            return node
        document=mask_report(document)
    assert_clean(data)
    original_rows=[{**v,'line':e['line']} for e in document['excerpts'] for v in e['values']]
    by_span={(r['line'],r['column'],r['end_column'],r['text']):r for r in original_rows}
    tokens=tokenize(data.decode('utf-8-sig'),document['answer'].get('blind_id') or document['answer']['answer_id'])
    for token in tokens:
        key=(token['line'],token['column'],token['end_column'],token['text'])
        if key not in by_span:raise ValueError('cleaned token lacks exact existing span')
        token['token_id']=by_span[key]['token_id']
    retained={t['token_id'] for t in tokens}
    if len(retained)!=len(tokens):raise ValueError('cleaned token IDs collide')
    removed_ids={r['token_id'] for r in original_rows if r['token_id'] not in retained}
    line_starts=[];position=0
    for line in data.decode('utf-8-sig').splitlines(keepends=True):
        line_starts.append(position);position+=len(line)
    def inside_mask(row):
        start=line_starts[row['line']-1]+row['column']-1
        end=line_starts[row['line']-1]+row['end_column']-1
        return any(item['start']<=start and end<=item['end'] for item in inline_diagnostics)
    if any(r['line'] not in removed and not inside_mask(r) for r in original_rows if r['token_id'] in removed_ids):raise ValueError('sanitization removed authored token')
    document['excerpts']=[{**e,'values':[v for v in e['values'] if v['token_id'] in retained]} for e in document['excerpts'] if e['line'] not in removed]
    document['excerpts']=[e for e in document['excerpts'] if e['values']]
    dropped_claims=[];claims=[]
    for claim in document.get('factual_claims',[]):
        ids=set(claim.get('token_ids',[]));quote=claim.get('quote','')
        bounds=claim.get('lines',[])
        generated_lines=bool(bounds and len(bounds)==2 and all(i in removed for i in range(bounds[0],bounds[1]+1)))
        generated_clause=bool(len(quote.strip())>=20 and any(quote.strip() in item['text'] for item in inline_diagnostics))
        if generated_lines or generated_clause or (ids and ids<=removed_ids) or '[UNGROUNDED DATA FLAGS]' in quote or '[POSTANSWER DATA FLAGS]' in quote:
            dropped_claims.append(claim['claim_id']);continue
        claim['token_ids']=[tid for tid in claim.get('token_ids',[]) if tid in retained]
        claims.append(claim)
    document['factual_claims']=claims
    if ranges or inline_diagnostics:
        rows=[v for e in document['excerpts'] for v in e['values']]
        document['counts']['numeric']=_counts(rows);document['counts']['factual_claims']=_claim_counts(claims);document['counts']['excerpts']=len(document['excerpts'])
        document['answer']['evaluated_answer_sha256']=hashlib.sha256(data).hexdigest();document['answer']['token_count']=len(tokens)
    receipt={'masked_diagnostic_clauses':inline_diagnostics,'removed_line_ranges':[[a+1,z] for a,z in ranges],'removed_diagnostic_token_ids':sorted(removed_ids),'removed_diagnostic_claim_ids':dropped_claims,
             'retained_span_bijection':[{'token_id':t['token_id'],'line':t['line'],'column':t['column'],'end_column':t['end_column']} for t in tokens],
             'retained_numeric_findings_unchanged':True,'clean_answer_sha256':hashlib.sha256(data).hexdigest()}
    return document,data,tokens,receipt


def prepare(folder,packet,python=sys.executable,interpretations=None):
    folder=io_path(folder).resolve(strict=True);packet=io_path(packet).resolve()
    if packet.exists():raise ValueError('correction packet already exists; do not overwrite frozen inputs')
    old=json.loads((folder/'eval/evaluation.json').read_text(encoding='utf-8-sig'))
    level=old['answer']['level']
    if level not in {'Analysis','Main'}:raise ValueError('this correction mode requires Analysis or Main')
    preparation=ensure_for_answer(folder/'result.md',level,packet.parent.parent/'artifact_preparation')
    old,answer,tokens,cleaning=clean_existing_inputs(old,(folder/'eval/evaluated_answer.md').read_bytes())
    packet.mkdir(parents=True)
    save(packet.parent/(packet.name+'_artifact_preparation.json'),preparation)
    (packet/'answer.md').write_bytes(answer)
    save(packet/'existing_evaluation.json',sanitized_existing(old))
    private_original=packet.parent/(packet.name+'_original_evaluation.json')
    private_original.write_bytes((folder/'eval/evaluation.json').read_bytes())
    save(packet.parent/(packet.name+'_sanitization.json'),cleaning)
    save(packet/'tokens.json',tokens)
    sessions=[folder]+sorted(p for p in (folder/'analysis_runs').glob('run_*') if p.is_dir())
    artifacts=[];private=[]
    for index,session in enumerate(sessions):
        published_session=folder/'eval/artifacts' if index==0 else folder/'eval/artifacts/analysis_runs'/session.name
        if not (published_session/'run_history_verbatim.md').is_file():
            if index==0 and level=='Main':continue
            raise ValueError('required prepared eval/artifacts source-session history missing')
        prefix=Path('source_session/main') if index==0 else Path('analysis_runs')/session.name
        for source in sorted((published_session/'data').rglob('*')) if (published_session/'data').is_dir() else []:
            if not source.is_file() or source.suffix.lower() not in {'.csv','.json','.txt','.py'}:continue
            check_artifact(source)
            rel=prefix/'data'/source.relative_to(published_session/'data');target=packet/'artifacts'/rel
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
            artifacts.append({'path':rel.as_posix(),'sha256':sha(target),'use':'pipeline_artifact_and_source_evidence'})
            private.append({'artifact':rel.as_posix(),'source':str(source),'source_sha256':sha(source),'transform':'identity'})
        for source in sorted((published_session/'plots').rglob('*')) if (published_session/'plots').is_dir() else []:
            if not source.is_file() or source.suffix.lower() not in {'.png','.pdf','.svg'}:continue
            check_artifact(source)
            rel=prefix/'plots'/source.relative_to(published_session/'plots');target=packet/'artifacts'/rel
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
            artifacts.append({'path':rel.as_posix(),'sha256':sha(target),'use':'pipeline_artifact_and_source_evidence'})
            private.append({'artifact':rel.as_posix(),'source':str(source),'source_sha256':sha(source),'transform':'identity'})
        history=published_session/'run_history_verbatim.md'
        if not history.is_file():raise ValueError('prepared native session history missing: '+str(history))
        fixed_calls=published_session/'fitting_tool_calls_verbatim.md'
        if fixed_calls.is_file():
            for returned in extract_native_returns(fixed_calls.read_text(encoding='utf-8-sig'), include_argument_only=True):
                stem=artifact_stem(returned)
                identity={'tool':returned['tool'],'step':returned['step'],'occurrence':returned['occurrence']}
                # Complete arguments can bind saved CSVs even when only a limited result preview survives.
                # Never fabricate or promote that preview to a numerical Result.
                if returned['text'] is not None:
                    rel=prefix/'fixed_tool_returns'/(stem+'.txt');target=packet/'artifacts'/rel
                    target.parent.mkdir(parents=True,exist_ok=True);target.write_text(returned['text'],encoding='utf-8')
                    check_artifact(target)
                    artifacts.append({'path':rel.as_posix(),'sha256':sha(target),'use':'pipeline_artifact_and_source_evidence'})
                    private.append({'artifact':rel.as_posix(),'source':str(fixed_calls),'source_sha256':sha(fixed_calls),
                                    'source_lines':returned['source_lines'],'source_span':returned['result_source_span'],
                                    'source_fragment_sha256':returned['result_sha256'],'call_identity':identity,
                                    'tool':returned['tool'],'step':returned['step'],
                                    'transform':'literal native executed numerical Result section; no authored answer or validation block'})
                if returned['arguments'] is not None:
                    rel=prefix/'fixed_tool_returns'/(stem+'_arguments.json');target=packet/'artifacts'/rel
                    target.parent.mkdir(parents=True,exist_ok=True)
                    save(target,returned['arguments']);check_artifact(target)
                    artifacts.append({'path':rel.as_posix(),'sha256':sha(target),'use':'pipeline_artifact_and_source_evidence'})
                    private.append({'artifact':rel.as_posix(),'source':str(fixed_calls),'source_sha256':sha(fixed_calls),
                                    'step':returned['step'],'tool':returned['tool'],'call_identity':identity,
                                    'source_span':returned['arguments_source_span'],
                                    'source_fragment_sha256':returned['arguments_sha256'],
                                    'transform':'native call arguments minus authored purpose/tasks'})
        memory=history  
        if memory.is_file():
            lines=memory.read_text(encoding='utf-8-sig').splitlines()
            archive_state=next((i for i,line in enumerate(lines) if line=='## Saved pipeline state: Completed Fits'),None)
            begins=[i for i,line in enumerate(lines) if line=='### Completed Fits' and archive_state is not None and i>archive_state]
            if len(begins)>1:raise ValueError('ambiguous deterministic Completed Fits boundary')
            if begins:
                start=begins[0]+1;end=next((i for i in range(start,len(lines)) if lines[i].startswith('#') or lines[i]=='~~~~'),len(lines))
                kept=[]
                for line in lines[start:end]:
                    if not line.strip():continue
                    if line.lstrip().startswith('- ') and 'RK order=' in line:
                        kept.append(line)
                    elif line.startswith('      response:'):
                        kept.append(line)
                    elif line.startswith('      route:'):
                        kept.append(line.replace(', exact pointwise', ', pointwise'))
                    elif 'Composition axis converted to mole fraction of ' in line and line.startswith('      '):
                        kept.append(line.replace('⚠ ', '').replace('[exact (molar masses from block formulas)]', '[molar masses from block formulas]'))
                    elif line.startswith('      pure refs:'):
                        # Preserve fixed input numbers; omit quality/gate annotations.
                        kept.append(line.split(' [',1)[0])
                    elif re.match(r'^      (fit_csv|excess_csv|fit_plot|excess_plot):',line):
                        kept.append(line)
                    else:raise ValueError('unrecognized deterministic fit summary line; manual source inspection required')
                if kept:
                    rel=prefix/'completed_fits.txt';target=packet/'artifacts'/rel
                    target.parent.mkdir(parents=True,exist_ok=True);target.write_text('\n'.join(kept)+'\n',encoding='utf-8')
                    check_artifact(target)
                    artifacts.append({'path':rel.as_posix(),'sha256':sha(target),'use':'pipeline_artifact_and_source_evidence'})
                    private.append({'artifact':rel.as_posix(),'source':str(memory),'source_sha256':sha(memory),
                                    'source_lines':[start+1,end],'transform':'deterministic Completed Fits section; pure-reference quality annotations removed'})
    # Include the entire published native artifact pool, including files absent
    # from native data folders. Authored answers/evaluator reports stay excluded.
    published=folder/'eval/artifacts'
    copied_hashes={entry['sha256'] for entry in artifacts}
    for source in sorted(published.rglob('*')) if published.is_dir() else []:
        if not source.is_file():continue
        if source.suffix.lower() not in {'.csv','.json','.txt','.py','.png','.pdf','.svg'}:continue
        if source.name.lower() in {'answer_envelope.json','result.md','evaluation.json','claim_review.json','grounding_evidence.json'}:continue
        check_artifact(source)
        digest=sha(source)
        if digest in copied_hashes:continue
        rel=Path('published_native')/source.relative_to(published);target=packet/'artifacts'/rel
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        artifacts.append({'path':rel.as_posix(),'sha256':digest,'use':'pipeline_artifact_and_source_evidence'})
        private.append({'artifact':rel.as_posix(),'source':str(source),'source_sha256':digest,'transform':'identity'})
        copied_hashes.add(digest)
    # Search all answer-bound files, not just the exported CSV pool. This receipt
    # records candidates for orchestrator inspection; it never turns authored
    # answers into authoritative solver evidence or auto-accepts a negative search.
    candidates=[]
    for source in sorted(folder.rglob('*')):
        if not source.is_file() or source.suffix.lower() not in {'.json','.jsonl','.md','.txt','.csv','.log','.py'}:continue
        relative=source.relative_to(folder)
        if relative.parts[0]=='eval' and 'artifacts' not in relative.parts:continue
        data=source.read_bytes();text=data.decode('utf-8-sig',errors='replace')
        hits=[]
        for number,line in enumerate(text.splitlines(),1):
            if re.search(r'\b(?:bic|rmse|r_squared|rk_order|fit_results|tool_history|raw_result)\b',line,re.I):hits.append(number)
        if not hits:continue
        authored=source.name in {'answer_envelope.json','result.md','final_full_context.md'}
        candidates.append({'relative_path':relative.as_posix(),'sha256':hashlib.sha256(data).hexdigest(),
                           'matching_lines':hits,'source_role':'authored_or_mixed_not_authoritative' if authored else 'requires_native_source_classification'})
    source_search={'scope':'all text/machine files recursively within this answer folder; evaluator outputs excluded',
                   'candidate_files':candidates,'orchestrator_semantic_review_required':True,
                   'artifact_selection_complete':False,'reason':'Source candidates must be classified before absence verdict acceptance.'}
    save(packet.parent/(packet.name+'_pool_search.json'),source_search)
    public_root=(folder/'eval/artifacts').resolve()
    visibility=[]
    benchmark=next(p.parent for p in folder.parents if p.name==level)
    for record in preparation['sessions']:
        archived=io_path(benchmark/record['target']).resolve()
        if not archived.is_relative_to(public_root):raise ValueError('preparation visibility record belongs to another answer')
        visibility.append({'history_path':(archived.relative_to(public_root)/'run_history_verbatim.md').as_posix(),
                           'archive_sha256':record.get('archive_sha256'),
                           'visible_context_limitations':record.get('visible_context_limitations',[]),
                           'source_gaps':record.get('gaps',[]),
                           'steps':[{'step':item.get('step'), **{key:value for key,value in item.items() if key in {'result_visibility','arguments_source','arguments_visible_call_source','result_source'}}} for item in record.get('steps',[])]})
    sources_by_artifact={item['artifact']:item for item in private}
    for entry in artifacts:
        provenance=sources_by_artifact[entry['path']];source=io_path(provenance['source']).resolve(strict=True)
        if not source.is_relative_to(public_root):raise ValueError('pipeline evidence is not from own answer eval/artifacts')
        entry['eligibility']={'root':'own_answer/eval/artifacts','owner_answer_id':old['answer']['answer_id'],
                              'source_path':source.relative_to(public_root).as_posix(),'source_sha256':sha(source),
                              'transform':provenance['transform'],'source_lines':provenance.get('source_lines'),
                              'source_span':provenance.get('source_span'),
                              'source_fragment_sha256':provenance.get('source_fragment_sha256'),
                              'call_identity':provenance.get('call_identity'),
                              'source_role':('deterministic_fitting_tool_calls' if source.name=='fitting_tool_calls_verbatim.md' else 'context_only' if source.suffix.lower()=='.md' or 'completed_fits' in entry['path'] else 'fixed_saved_data_or_plot')}
        entry['numeric_primary_eligible']=entry['eligibility']['source_role']!='context_only' and source.suffix.lower()!='.py' and not entry['path'].endswith('_arguments.json')
        from native_tool_returns import has_numeric_result
        if entry['path'].endswith('.txt') and not has_numeric_result((packet/'artifacts'/entry['path']).read_text(encoding='utf-8-sig')):
            entry['numeric_primary_eligible']=False;entry['use']='failed_execution_context_only'
    save(packet/'BLIND_INPUT.json',{'answer_id':old['answer']['answer_id'],'level':level,'artifact_files':artifacts,
                                  'require_eval_artifact_origin':True,'source_visibility':visibility,
                                  'mode':'one_answer_existing_report_correction','isolation':'instruction_only','source_pool_audit_required':True})
    # Provenance stays outside worker input allowlist; used by the orchestrator.
    provenance=packet.parent/(packet.name+'_source_provenance.json');save(provenance,{'original_evaluation':str(private_original),'original_evaluation_sha256':sha(private_original),'sanitized_evaluation_sha256':sha(packet/'existing_evaluation.json'),'one_answer_boundary':True,'artifact_sources':private})
    paths={'answer':str(packet/'answer.md'),'existing_report':str(packet/'existing_evaluation.json'),
           'tokens':str(packet/'tokens.json'),'artifact_manifest':str(packet/'BLIND_INPUT.json'),
           'artifacts':str(packet/'artifacts'),'mapping':str(TOOLS.parent/'instructions/MAPPING.md'),
           'rubric':str(TOOLS.parent/'instructions/RUBRIC.txt'),'quality':str(TOOLS.parent/'instructions/QUALITY_CHECKS.txt'),
           'schema':str(TOOLS/'CORRECTION_SCHEMA.md'),'artifact_schema':str(TOOLS/'PIPELINE_ARTIFACT_SCHEMA.md'),
           'tools':str(TOOLS),'interpretations':str(interpretations) if interpretations else None,
           'output':str(packet/'correction.json'),
           'check_argv':[str(python),str(TOOLS/'correct_artifacts.py'),'check','--packet',str(packet),'--report',str(packet/'correction.json')]}
    sources=[WORKFLOW/'templates/artifact-corrector.system.md',TOOLS.parent/'templates'/f'{level}.system.md']
    system='\n\n'.join(p.read_text(encoding='utf-8-sig') for p in sources)
    task=(WORKFLOW/'templates/artifact-corrector.task.md').read_text(encoding='utf-8-sig')+'\n\nExact task bindings:\n'+json.dumps(paths,ensure_ascii=False,indent=2)+'\n'
    instructions=packet/'instructions';instructions.mkdir()
    (instructions/'rendered_system.md').write_text(system,encoding='utf-8')
    (instructions/'rendered_task.md').write_text(task,encoding='utf-8')
    effective=(instructions/'rendered_system.md').read_bytes()+b'\n'+(instructions/'rendered_task.md').read_bytes()
    (instructions/'effective_instruction.md').write_bytes(effective)
    record={'role':'artifact-corrector','answer_id':old['answer']['answer_id'],'level':level,
            'method':'one_answer_existing_report_plus_actual_artifacts','read_isolation':'instruction_only',
            'input_allowlist':paths,'template_sha256':{str(p.relative_to(WORKFLOW)):sha(p) for p in sources+[WORKFLOW/'templates/artifact-corrector.task.md']},
            'rendered_sha256':{p.name:sha(p) for p in instructions.iterdir()},
            'model':'not_submitted','settings':{},'transport':'prepared_not_submitted'}
    save(instructions/'instruction_record.json',record)
    receipt={'status':'PREPARED','answer_id':old['answer']['answer_id'],'packet':str(packet),'artifact_count':len(artifacts),
             'instruction_sha256':hashlib.sha256(effective).hexdigest(),'existing_evaluation_sha256':sha(packet/'existing_evaluation.json')}
    return receipt

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--answer-folder',type=Path,required=True)
    ap.add_argument('--packet',type=Path,required=True);ap.add_argument('--interpretations',type=Path)
    args=ap.parse_args();print(json.dumps(prepare(args.answer_folder,args.packet,interpretations=args.interpretations),indent=2))
