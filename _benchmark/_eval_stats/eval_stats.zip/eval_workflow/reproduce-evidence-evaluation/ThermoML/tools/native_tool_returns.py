"""Extract fixed numerical tool returns from native execution histories."""
import json
import re
import hashlib

STEP=re.compile(r'^### Step (?P<step>\d+)[^\n]*: `(?P<tool>[^`]+)`[^\n]*$',re.M)
NUMERICAL=re.compile(r'^(?:fit_|predict_|compute_|calculate_|derive_|analyze_)')
SECTION=re.compile(r'<details><summary>(?P<kind>Arguments|Result)(?:[^<]*)</summary>\s*\n\s*(?P<fence>```|~~~~)(?:json|text)?\s*\n(?P<body>.*?)\n(?P=fence)\s*\n</details>',re.S)

def extract(text, *, include_argument_only=False):
    steps=list(STEP.finditer(text));returns=[]
    seen={}
    for index,match in enumerate(steps):
        tool=match['tool']
        key=(int(match['step']),tool)
        seen[key]=seen.get(key,0)+1
        occurrence=seen[key]
        if not NUMERICAL.match(tool) or 'VALIDATION BLOCKED' in match.group():continue
        block=text[match.end():steps[index+1].start() if index+1<len(steps) else len(text)]
        # A blocked execution or validation detail is never a solver output.
        sections={m['kind']:m for m in SECTION.finditer(block)}
        result_section=sections.get('Result')
        if result_section is None and (not include_argument_only or 'Arguments' not in sections or '**Status:** blocked' in block):continue
        result=result_section['body'] if result_section is not None else None
        if result is not None and result.lstrip().startswith(('**✗','TOOL_ARGUMENT_REFINEMENT_REQUIRED','{"error"')):continue
        start=text[:match.end()+result_section.start('body')].count('\n')+1 if result_section is not None else None
        arguments=sections.get('Arguments')
        args=None
        argument_span=None
        argument_sha256=None
        if arguments:
            try:args=json.loads(arguments['body'])
            except json.JSONDecodeError:raise ValueError('unparseable native numerical call arguments')
            argument_span=[match.end()+arguments.start('body'),match.end()+arguments.end('body')]
            argument_sha256=hashlib.sha256(arguments['body'].encode('utf-8')).hexdigest()
            # Purpose/tasks are authored intention, not solver evidence.
            if isinstance(args,dict):args={k:v for k,v in args.items() if k not in {'purpose','tasks'}}
        result_span=[match.end()+result_section.start('body'),match.end()+result_section.end('body')] if result_section is not None else None
        returns.append({'step':int(match['step']),'tool':tool,'occurrence':occurrence,'text':result+'\n' if result is not None else None,
                        'result_availability':'complete_result' if result is not None else 'no_complete_result_section',
                        'result_source_span':result_span,'result_sha256':hashlib.sha256(result.encode('utf-8')).hexdigest() if result is not None else None,
                        'arguments_source_span':argument_span,'arguments_sha256':argument_sha256,
                        'source_lines':[start,start+result.count('\n')] if result is not None else None, 'arguments':args})
    counts={}
    for item in returns:
        key=(item['step'],item['tool'])
        counts[key]=counts.get(key,0)+1
    for item in returns:
        item['extracted_same_step_tool_count']=counts[(item['step'],item['tool'])]
    return returns


def artifact_stem(returned):
    stem=f"tool_step_{returned['step']:03d}_{returned['tool']}"
    if returned['extracted_same_step_tool_count']>1:
        stem+=f"_call_{returned['occurrence']:03d}"
    return stem


def has_numeric_result(text):
    """All-failed fits are execution context; retain successful rows in mixed returns."""
    # Parallel-call wrappers are renderer headings, not a successful result.
    text=re.sub(r'^\s*###\s+[A-Za-z_][A-Za-z_0-9]*\s*\n', '', text, count=1)
    if text.lstrip().startswith('**Fit error**'):return False
    if text.lstrip().startswith('**Multi-system RK Fit**'):
        for line in text.splitlines():
            cells=[x.strip() for x in line.split('|')]
            if len(cells)>=10 and re.fullmatch(r'[0-9]+',cells[5]):return True
        return False
    return True
