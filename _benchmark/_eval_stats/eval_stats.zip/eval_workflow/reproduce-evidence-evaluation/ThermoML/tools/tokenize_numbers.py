"""Numeric lexer: one lexical occurrence, source spans and Decimal display precision."""
import json,re
from decimal import Decimal
from pathlib import Path
SUP='⁰¹²³⁴⁵⁶⁷⁸⁹'; SUB='₀₁₂₃₄₅₆₇₈₉'
TRANSLATE=str.maketrans(SUP+SUB+'⁻⁺₋₊−','0123456789'*2+'-+-+-')
MANT=r'(?:\d{1,3}(?:[,\u00a0\u202f]\d{3})+(?:\.\d*)?|\d+(?:\.\d*)?|\.\d+)'
EXP=r'(?:[eE][+−-]?\d+|\s*(?:×|\*|\\times)\s*10\s*(?:[⁺⁻]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+|\^\s*\{?[+−-]?\d+\}?))'
TEN_POWER=r'10(?:[⁺⁻]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+|\^\{?[+−-]?\d+\}?)'
PAT=re.compile(TEN_POWER+r'|[+−-]?'+MANT+r'(?:'+EXP+r')?|[⁺⁻]?[⁰¹²³⁴⁵⁶⁷⁸⁹]+|[₊₋]?[₀₁₂₃₄₅₆₇₈₉]+')
SCI=re.compile(r'^(?P<m>.*?)\s*(?:×|\*|\\times)\s*10\s*(?P<e>.*)$')
def parsed(text):
    if re.fullmatch(TEN_POWER,text):
        exponent=int(text[2:].translate(TRANSLATE).replace('^','').replace('{','').replace('}',''))
        value=Decimal(10)**exponent
        return {'parsed_value':str(value),'display_quantum':str(value),'display_tolerance':str(value/2),'significant_digits':1}
    normalized=text.translate(TRANSLATE).replace(',','').replace('\u00a0','').replace('\u202f','')
    mm=SCI.match(normalized)
    if mm:
        mant=mm['m']; exp=int(mm['e'].replace('^','').replace('{','').replace('}','').strip())
        value=Decimal(mant)*(Decimal(10)**exp)
    elif re.search('[eE]',normalized):
        mant,ex=re.split('[eE]',normalized); exp=int(ex); value=Decimal(normalized)
    else:
        mant=normalized; exp=0; value=Decimal(normalized)
    places=len(mant.split('.')[1]) if '.' in mant else 0
    quantum=Decimal(10)**(exp-places)
    significant=mant.lstrip('+-').replace('.','').lstrip('0')
    digits=len(significant) if significant else max(1,places)
    return {'parsed_value':str(value),'display_quantum':str(quantum),'display_tolerance':str(quantum/2),'significant_digits':digits}
def tokenize(text,aid):
    rows=[]
    for ln,line in enumerate(text.splitlines(),1):
        for m in PAT.finditer(line):
            start,end=m.span(); raw=m.group()
            # Hyphen between numeric endpoints is a range separator, not a sign.
            if raw.startswith('-') and re.search(r'\d(?:\.\d*)?-to$',line[:start],re.I):
                start+=1; raw=raw[1:]
            if raw.startswith('-') and start and (line[start-1].isdigit() or line[start-1] in '%⁰¹²³⁴⁵⁶⁷⁸⁹'):
                start+=1; raw=raw[1:]
            if raw.startswith('-') and start and line[start-1].isspace():
                prev=line[:start].rstrip()
                if prev and (prev[-1].isdigit() or prev[-1]=='%'):
                    # A spaced hyphen is a range delimiter; mathematical subtraction is an operator too.
                    start+=1; raw=raw[1:]
            kind='subscript' if any(c in SUB for c in raw) else 'superscript' if all(c in SUP+'⁻⁺' for c in raw) else 'number'
            rows.append({'answer_id':aid,'token_id':f'n{len(rows)+1:04d}','line':ln,'column':start+1,'end_column':end+1,'text':raw,'lexical_kind':kind,'line_text':line,**parsed(raw)})
    return rows

def self_check():
    cases=[('−5.101 × 10⁻⁶',['-0.000005101']),('1.2e-5',['0.000012']),('943.94–997.02',['943.94','997.02']),('1-2',['1','2']),('-2--1',['-2','-1']),('1 to 2',['1','2']),('1,234.50 ± 0.02',['1234.50','0.02']),('1.2 × 10⁻³',['0.0012']),('m³ x₁',['3','1']),('−0.1–−0.02',['-0.1','-0.02']),('5 %',['5']),('1.2 × 10^{−3}',['0.0012']),('10⁻⁵',['0.00001']),('10^{-5}',['0.00001']),('0-to-1',['0','1']),('0-to--1',['0','-1'])]
    for text,want in cases:
        got=tokenize(text,'fixture')
        assert [Decimal(t['parsed_value']) for t in got]==list(map(Decimal,want)),(text,got)
        assert all(text[t['column']-1:t['end_column']-1]==t['text'] for t in got)
    assert tokenize('1.2 × 10⁻³','x')[0]['display_tolerance']=='0.00005'
    return len(cases)

def main():
    import argparse
    import hashlib
    ap=argparse.ArgumentParser(description="Tokenize one rendered ThermoML answer.")
    ap.add_argument("--run-root", type=Path, required=True)
    ap.add_argument("--answer-id", required=True)
    args=ap.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", args.answer_id):
        ap.error("answer id must contain only letters, digits, underscore, period or hyphen")
    folder=args.run_root.resolve()/"public"/"maps"/args.answer_id
    source=folder/"answer.md"
    content=source.read_text(encoding="utf-8-sig")
    tokens=tokenize(content,args.answer_id)
    lines=content.splitlines()
    for token in tokens:
        line=lines[token["line"]-1]
        if line[token["column"]-1:token["end_column"]-1] != token["text"]:
            raise ValueError("Token span mismatch: "+token["token_id"])
    out=folder/"tokens.json"
    out.write_text(json.dumps(tokens,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"answer_id":args.answer_id,"answer_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),"tokens":len(tokens),"output":str(out)}))
if __name__=="__main__":main()
