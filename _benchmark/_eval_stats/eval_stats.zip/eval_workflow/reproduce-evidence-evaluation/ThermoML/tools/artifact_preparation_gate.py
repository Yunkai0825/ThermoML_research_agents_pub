"""Verify automatic before-evaluation assembly; reuse current receipts without rebuilding."""
import importlib.util
import hashlib
import json
from pathlib import Path
from filesystem_paths import io_path

_PREPARED={}
_INVALID_RECEIPTS=set()
VALID={'COMPLETE','COMPLETE_WITH_VISIBLE_LIMITS','SOURCE_GAPS'}

def ensure_for_answer(answer_path, level, private_root):
    if level not in {'Analysis','Main'}:return {'stage':'before_evaluation','status':'NOT_APPLICABLE','records':[]}
    answer_path=io_path(answer_path).resolve()
    level_root=next((p for p in answer_path.parents if p.name==level),None)
    if level_root is None:raise ValueError('Analysis/Main packet requires an original benchmark source path')
    benchmark=level_root.parent;key=str(benchmark);assembled=False
    if key not in _PREPARED and key not in _INVALID_RECEIPTS:
        receipt=benchmark/'__obsolete__/eval_artifact_assembly/receipt_applied.json'
        if receipt.is_file():
            candidate=json.loads(receipt.read_text(encoding='utf-8-sig'))
            if candidate.get('stage')=='before_evaluation' and candidate.get('applied') is True and candidate.get('status') in VALID:
                _PREPARED[key]=candidate
    if key not in _PREPARED:
        module_path=Path(__file__).resolve().parent.parent/'prepare_artifacts.py'
        spec=importlib.util.spec_from_file_location('thermoml_pre_evaluation_artifacts',module_path)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        report=module.ensure_prepared(benchmark,io_path(private_root),apply=True);assembled=True
        if report.get('stage')!='before_evaluation' or report.get('status') not in VALID or report.get('applied') is not True:
            raise ValueError('automatic source artifact preparation did not run')
        _PREPARED[key]=report
    report=_PREPARED[key];relative=answer_path.parent.relative_to(benchmark).as_posix()
    selected=[r for r in report.get('records',[]) if r['source'].replace('\\','/').rstrip('/')==relative or r['source'].replace('\\','/').startswith(relative+'/analysis_runs/')]
    expected={relative} if level=='Analysis' else set()
    expected.update(relative+'/analysis_runs/'+p.name for p in (answer_path.parent/'analysis_runs').glob('run_*') if p.is_dir())
    found={r['source'].replace('\\','/').rstrip('/') for r in selected}
    valid=found==expected
    for record in selected:
        checks=[(benchmark/record['source']/name,digest) for name,digest in record.get('source_hashes',{}).items()]
        checks += [(benchmark/record['target']/'run_history_verbatim.md',record.get('archive_sha256')),
                   (benchmark/record['target']/record.get('fitting_archive_relative_path','fitting_tool_calls_verbatim.md'),record.get('fitting_archive_sha256'))]
        checks += [(benchmark/record['target']/item['path'],item['sha256']) for item in record.get('files',[])]
        for file,digest in checks:
            if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest()!=digest:valid=False;break
    if not valid:
        if assembled:raise ValueError('automatic preparation did not produce a complete current own-session binding')
        _PREPARED.pop(key,None);_INVALID_RECEIPTS.add(key)
        return ensure_for_answer(answer_path,level,private_root)
    return {'stage':'before_evaluation','status':('SOURCE_GAPS' if any(r.get('gaps') for r in selected) else 'COMPLETE_WITH_VISIBLE_LIMITS' if any(r.get('visible_context_limitations') for r in selected) else 'COMPLETE'),
            'receipt':report.get('receipt'),'sessions':selected,'automatic_assembly_invoked':assembled,
            'automatic_preparation_verified':True,'verified_existing_receipt_reused':not assembled,
            'dispatch_requirement':'Source gaps require explicit relevance inspection; no missing numerical output may be silently excluded.'}
