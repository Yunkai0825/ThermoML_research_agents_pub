import unittest
from decimal import Decimal
from compare_core import compare,convert
from fitting_precision import rounded_four,compare_fitting,precision_role
class FittingPrecisionTests(unittest.TestCase):
 def test_half_up_sign_zero_and_tiny(self):
  for a,b in [('1.2345','1.235'),('-1.2345','-1.235'),('9.9995','10.00'),('1.2345e-40','1.235e-40'),('-0','0')]:self.assertEqual(rounded_four(a),Decimal(b))
 def test_boundary_not_relative_shortcut(self):
  self.assertEqual(compare_fitting('1.23449','1.23451','0')['category'],'near_miss')
  self.assertEqual(compare_fitting('2.5715296891028707','2.5715296891','5e-17')['category'],'exact')
 def test_old_exact_preserved(self):
  self.assertEqual(compare_fitting('2.6','2.5715296891','.05')['category'],'exact')
 def test_unit_conversion_first(self):
  reference=convert('0.00123456','Pa*s','mPa*s')
  self.assertEqual(compare_fitting('1.23457',reference,'0')['category'],'exact')
 def test_ineligible_and_integer_stay_strict(self):
  for role in ['input_reference','input_coordinate','not_applicable']:
   self.assertEqual(compare_fitting('1.23456','1.23457','0',role)['category'],'near_miss')
  self.assertEqual(compare_fitting('10001','10000','1','integer_output')['category'],'miss')
  self.assertEqual(compare('1.23456','1.23457','0')['category'],'near_miss')
 def test_selected_field_roles(self):
  cases=[({'property':'BIC for RK order 4'},'continuous_fitted_output'),({'property':'R squared for RK order 0'},'continuous_fitted_output'),({'property':'pure water density used in RK fit'},'input_reference'),({'property':'predictor endpoint x=0'},'continuous_fitted_output'),({'property':'saved RK viscosity at stated model grid coordinate'},'continuous_fitted_output'),({'property':'grid point','integer_output':True},'integer_output')]
  for check,want in cases:self.assertEqual(precision_role(check,{'format':'text','pattern':'(?P<value>1)'}),want)
  self.assertEqual(precision_role({'property':'prediction coordinate'},{'pattern':r'Y\(x=(?P<value>0\.5)\)'}),'input_coordinate')
 def test_max_suffix_is_output_not_x_coordinate(self):
  self.assertEqual(precision_role({'property':'predicted viscosity maximum'},{'pattern':r'Y_max = (?P<value>[0-9.]+)'}),'continuous_fitted_output')
  self.assertEqual(precision_role({'property':'approximate contraction magnitude'},{'generating_call':{'tool':'predict_from_rk'},'excerpt':'Max |excess| = -9.56597e-07'}),'continuous_fitted_output')
 def test_curve_role_uses_calculation_not_coefficient(self):
  self.assertEqual(precision_role({'curve_verification':{'output':'coordinate'}},{'key':'A0'}),'continuous_fitted_output')
  self.assertEqual(precision_role({'curve_verification':{'evaluation':'ideal_baseline_at_reported_coordinate'}},{'key':'A0'}),'input_reference')
 def test_missing_not_eligible(self):
  self.assertEqual(precision_role({'property':'RK coefficient'}),'not_applicable')
class ReapplicationTests(unittest.TestCase):
 def test_semantic_miss_raw_rows_and_missing_evidence_preserved(self):
  import copy
  from unittest.mock import patch
  from tokenize_numbers import tokenize
  from reapply_fitting_precision import reapply
  text='1.23456 1.23456 1.23456 1.23456';ts=tokenize(text,'fixture')
  ref={'key':'A0','stored_value':'1.23457','converted_stored_value':'1.23457','stored_unit':'1','claimed_unit':'1'}
  rows=[];checks=[]
  for i,t in enumerate(ts):
   rows.append({'token_id':t['token_id'],'text':t['text'],'column':t['column'],'end_column':t['end_column'],'group':'property_value' if i==2 else 'pipeline_artifact','outcome':'miss' if i in (1,3) else 'near_miss','numeric_outcome':'miss' if i==3 else 'near_miss','source_outcome':'miss' if i==3 else 'exact','condition_outcome':'exact','basis_outcome':'miss' if i==1 else 'exact','unit_outcome':'exact','raw_numeric_outcome':'near_miss','misassigned':False,'reported_value':t['parsed_value'],'reason':'old Near','property':'RK coefficient','artifact_reference':copy.deepcopy(ref) if i!=3 else None})
   if i!=2:checks.append({'token_id':t['token_id'],'property':'RK coefficient','artifact_reference':copy.deepcopy(ref) if i!=3 else None})
  doc={'answer':{'answer_id':'fixture'},'excerpts':[{'line':1,'excerpt':text,'values':rows}],'factual_claims':[],'counts':{},'columns':{},'pipeline_artifact_review':{},'how_to_read':[]}
  with patch('reapply_fitting_precision.verify_reference'):
   out,receipt=reapply(doc,{'token_checks':checks},text,'.')
  got=out['excerpts'][0]['values']
  self.assertEqual(got[0]['outcome'],'exact');self.assertEqual(got[1]['outcome'],'miss');self.assertEqual(got[1]['numeric_outcome'],'exact')
  self.assertEqual(got[2],rows[2]);self.assertEqual(got[3],rows[3]);self.assertEqual(got[0]['artifact_reference'],ref)
class PrecisionPublicationTests(unittest.TestCase):
 def test_preserved_claims_are_validated_in_actual_mode(self):
  import tempfile,hashlib,json
  from pathlib import Path
  from unittest.mock import patch
  from precision_publication import publish
  with tempfile.TemporaryDirectory() as folder:
   base=Path(folder);stage=base/'stage';dest=base/'dest';stage.mkdir();dest.mkdir()
   for p in [stage,dest]:(p/'evaluated_answer.md').write_text('same answer')
   (dest/'evaluation.json').write_text('old');(stage/'evaluation.json').write_text('new');(dest/'claim_review.json').write_text('preserved claims')
   digest=hashlib.sha256((dest/'evaluation.json').read_bytes()).hexdigest()
   with patch('precision_publication.validate_package') as validator:
    receipt=publish(stage,dest,base/'backup',base,digest)
   self.assertEqual(validator.call_count,3);self.assertTrue(all(call.args[1] is True for call in validator.call_args_list))
   self.assertEqual((dest/'claim_review.json').read_text(),'preserved claims');self.assertFalse(receipt['scientific_generation'])
   self.assertEqual((base/'backup/evaluation.json').read_text(),'old')
if __name__=='__main__':unittest.main()
