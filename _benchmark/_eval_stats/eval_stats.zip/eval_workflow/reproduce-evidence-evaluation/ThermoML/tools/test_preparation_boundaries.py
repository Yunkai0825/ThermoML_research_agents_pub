"""Regression checks for prepared-source eligibility and repeated fitting calls."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from artifact_source import primary_source_entry, sha
from native_tool_returns import artifact_stem, extract, has_numeric_result
from packet import prepare_packet
from rebind_artifacts import rebind


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def fitting_step(value, *, doi="10.1/example"):
    return ("### Step 12: `fit_block`\n\n"
            "<details><summary>Arguments</summary>\n\n```json\n"
            + json.dumps({"doi": doi, "block_number": "1", "purpose": "fit"})
            + "\n```\n\n</details>\n\n"
            "<details><summary>Result</summary>\n\n~~~~text\n"
            + value + "\n~~~~\n\n</details>\n\n")


class PreparationBoundaryTests(unittest.TestCase):
    def test_fresh_packet_marks_only_fixed_primary_sources(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            folder = base / "Analysis" / "run_1"
            pool = folder / "eval" / "artifacts"
            (pool / "data").mkdir(parents=True)
            (pool / "data" / "fit.csv").write_text("value\n1.25\n", encoding="utf-8")
            (pool / "fitting_tool_calls_verbatim.md").write_text(fitting_step("**RK Fit** 1.25"), encoding="utf-8")
            (pool / "run_history_verbatim.md").write_text("# Context only\n", encoding="utf-8")
            answer = folder / "result.md"
            answer.write_text("A measured value is 1.25.\n", encoding="utf-8")
            question = base / "question.md"
            question.write_text("What is the measured value?\n", encoding="utf-8")
            packet = base / "packet"
            with patch("packet.ensure_for_answer", return_value={"stage":"before_evaluation","status":"COMPLETE","sessions":[]}):
                prepare_packet("A1", answer, packet, base / "private" / "provenance.json",
                               artifact_dir=pool,
                               artifact_files=["data/fit.csv", "fitting_tool_calls_verbatim.md", "run_history_verbatim.md"],
                               question_path=question, level="Analysis")
            manifest = json.loads((packet / "BLIND_INPUT.json").read_text(encoding="utf-8"))
            entries = {item["path"]: item for item in manifest["artifact_files"]}
            self.assertEqual(entries["data/fit.csv"]["eligibility"]["source_role"], "fixed_saved_data_or_plot")
            self.assertTrue(entries["data/fit.csv"]["numeric_primary_eligible"])
            self.assertEqual(entries["fitting_tool_calls_verbatim.md"]["eligibility"]["source_role"], "deterministic_fitting_tool_calls")
            self.assertTrue(entries["fitting_tool_calls_verbatim.md"]["numeric_primary_eligible"])
            self.assertFalse(entries["run_history_verbatim.md"]["numeric_primary_eligible"])
            primary_source_entry(packet, "data/fit.csv")
            primary_source_entry(packet, "fitting_tool_calls_verbatim.md")
            with self.assertRaisesRegex(ValueError, "context/provenance only"):
                primary_source_entry(packet, "run_history_verbatim.md")

    def make_rebind_packet(self, base, values, *, legacy=False):
        public = base / "public"
        public.mkdir()
        source = public / "fitting_tool_calls_verbatim.md"
        source.write_text("# Fitting calls\n\n" + "".join(fitting_step(v) for v in values), encoding="utf-8")
        text = source.read_text(encoding="utf-8")
        returns = extract(text)
        self.assertEqual(len(returns), len(values))
        packet = base / "packet"
        entries = []
        for item in returns if not legacy else returns[:1]:
            stem = artifact_stem(item) if not legacy else "tool_step_012_fit_block"
            identity = {"tool": item["tool"], "step": item["step"], "occurrence": item["occurrence"]}
            for suffix, contents, span, fragment in (
                (".txt", item["text"], item["result_source_span"], item["result_sha256"]),
                ("_arguments.json", json.dumps(item["arguments"]), item["arguments_source_span"], item["arguments_sha256"]),
            ):
                relative = "source_session/main/fixed_tool_returns/" + stem + suffix
                destination = packet / "artifacts" / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_text(contents, encoding="utf-8")
                eligibility = {"root":"own_answer/eval/artifacts", "owner_answer_id":"A1",
                               "source_path":"fitting_tool_calls_verbatim.md", "source_sha256":sha(source)}
                if not legacy:
                    eligibility.update(call_identity=identity, source_span=span, source_fragment_sha256=fragment)
                entries.append({"path":relative, "sha256":sha(destination), "eligibility":eligibility})
        save_json(packet / "BLIND_INPUT.json", {"answer_id":"A1", "artifact_files":entries})
        return packet, public, returns

    def test_repeated_call_results_and_arguments_rebind_by_exact_occurrence(self):
        with tempfile.TemporaryDirectory() as tmp:
            packet, public, returns = self.make_rebind_packet(Path(tmp), ["**RK Fit** first=1", "**RK Fit** second=2"])
            _, receipt = rebind({"excerpts":[]}, packet, public)
            bindings = receipt["published_artifact_bindings"]
            self.assertEqual(len(bindings), 4)
            for item in returns:
                stem = artifact_stem(item)
                key = "source_session/main/fixed_tool_returns/" + stem + ".txt"
                self.assertEqual(bindings[key]["call_identity"]["occurrence"], item["occurrence"])
                self.assertEqual(bindings[key]["source_span"], item["result_source_span"])
                self.assertEqual(bindings[key]["source_fragment_sha256"], item["result_sha256"])
            self.assertNotEqual(artifact_stem(returns[0]), artifact_stem(returns[1]))

    def test_identical_returns_require_occurrence_or_explicit_ambiguity(self):
        with tempfile.TemporaryDirectory() as tmp:
            packet, public, returns = self.make_rebind_packet(Path(tmp), ["**RK Fit** same=1", "**RK Fit** same=1"])
            _, receipt = rebind({"excerpts":[]}, packet, public)
            self.assertEqual(len(receipt["published_artifact_bindings"]), 4)
            self.assertNotEqual(returns[0]["result_source_span"], returns[1]["result_source_span"])
        with tempfile.TemporaryDirectory() as tmp:
            packet, public, _ = self.make_rebind_packet(Path(tmp), ["**RK Fit** same=1", "**RK Fit** same=1"], legacy=True)
            with self.assertRaisesRegex(ValueError, "public fixed result binding ambiguous"):
                rebind({"excerpts":[]}, packet, public)

    def test_result_trailing_newlines_are_preserved_exactly(self):
        with tempfile.TemporaryDirectory() as tmp:
            packet, public, returns = self.make_rebind_packet(Path(tmp), ["**RK Fit** value=1\n\n"])
            _, receipt = rebind({"excerpts":[]}, packet, public)
            self.assertEqual(len(receipt["published_artifact_bindings"]),2)
            result=next((packet/'artifacts').rglob('*.txt'))
            result.write_text(result.read_text(encoding='utf-8').rstrip('\n')+'\n',encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'Result differs'):
                rebind({"excerpts":[]},packet,public)

    def test_complete_arguments_survive_limited_result_without_numeric_promotion(self):
        limited=fitting_step("**RK Fit** preview only...").replace("<summary>Result</summary>","<summary>Preview</summary>")
        self.assertEqual(extract(limited),[])
        item=extract(limited,include_argument_only=True)[0]
        self.assertIsNone(item['text'])
        self.assertIsNone(item['result_source_span'])
        self.assertEqual(item['arguments']['doi'],'10.1/example')
        self.assertEqual(item['result_availability'],'no_complete_result_section')
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);public=base/'public';public.mkdir();source=public/'fitting_tool_calls_verbatim.md';source.write_text(limited,encoding='utf-8')
            packet=base/'packet';relative='source_session/main/fixed_tool_returns/'+artifact_stem(item)+'_arguments.json'
            destination=packet/'artifacts'/relative;save_json(destination,item['arguments'])
            eligibility={'root':'own_answer/eval/artifacts','owner_answer_id':'A1','source_path':source.name,'source_sha256':sha(source),'source_role':'deterministic_fitting_tool_calls','call_identity':{'tool':item['tool'],'step':item['step'],'occurrence':item['occurrence']},'source_span':item['arguments_source_span'],'source_fragment_sha256':item['arguments_sha256']}
            save_json(packet/'BLIND_INPUT.json',{'answer_id':'A1','artifact_files':[{'path':relative,'sha256':sha(destination),'numeric_primary_eligible':False,'eligibility':eligibility}]})
            _,receipt=rebind({'excerpts':[]},packet,public)
            self.assertEqual(len(receipt['published_artifact_bindings']),1)
            with self.assertRaisesRegex(ValueError,'context/provenance only'):
                primary_source_entry(packet,relative)

    def test_argument_only_occurrences_do_not_collide_with_complete_calls(self):
        limited=fitting_step('preview').replace('<summary>Result</summary>','<summary>Preview</summary>')
        items=extract(limited+fitting_step('**RK Fit** complete'),include_argument_only=True)
        self.assertEqual([item['occurrence'] for item in items],[1,2])
        self.assertEqual(len({artifact_stem(item) for item in items}),2)
        blocked=limited.replace('<details><summary>Preview','- **Status:** blocked\n<details><summary>Preview')
        self.assertEqual(extract(blocked,include_argument_only=True),[])

    def test_parallel_wrapped_fit_error_is_not_numeric_primary(self):
        self.assertFalse(has_numeric_result('### fit_block\n**Fit error** Only0mixturepoints'))
        self.assertFalse(has_numeric_result('### fit_multi_system\n**Multi-system RK Fit** —2systems\nErrors:bothfailed'))
        self.assertTrue(has_numeric_result('### fit_block\n**RK Fit** R2=0.9'))

    def test_single_call_keeps_legacy_filename(self):
        item = extract("# Fitting calls\n\n" + fitting_step("**RK Fit** 1"))[0]
        self.assertEqual(artifact_stem(item), "tool_step_012_fit_block")


if __name__ == "__main__":
    unittest.main()


class SanitizerWordBoundaries(unittest.TestCase):
    def test_treatment_words_do_not_change_authored_words(self):
        from prepare_correction import sanitized_existing
        d={'answer':{'answer_id':'F026'},'factual_claims':[],'text':'Investigated and delegated evidence; gated / ungated / test_run_no_ledger'}
        r=sanitized_existing(d)
        self.assertEqual(r['text'],'Investigated and delegated evidence; [treatment removed] / [treatment removed] / [treatment removed]')


class EmbeddedVerdictClauses(unittest.TestCase):
    def test_mask_preserves_all_numeric_positions(self):
        from prepare_correction import mask_embedded_verdict_clauses
        text='Peak 1.034 at 293.15 K; however, these specific max |V| values are flagged as UNVERIFIED against the source database. Tail 12.'
        clean,receipt=mask_embedded_verdict_clauses(text)
        self.assertEqual(len(clean),len(text))
        self.assertEqual(clean.index('12'),text.index('12'))
        self.assertNotIn('UNVERIFIED',clean)
        self.assertEqual(len(receipt),1)
        self.assertIn('Peak 1.034 at 293.15 K',clean)


class DiagnosticSummaryCleaning(unittest.TestCase):
    def test_diagnostic_only_core_claim_is_removed_without_numeric_change(self):
        from prepare_correction import clean_existing_inputs
        line='- Several quoted values carry UNVERIFIED or MISATTRIBUTED flags due to block-attribution discrepancies.'
        doc={'answer':{'answer_id':'F034'},'excerpts':[],'factual_claims':[{'claim_id':'Cflag','lines':[1,1],'quote':line,'token_ids':[],'type':'diagnostic','verdict':'outside'}],'counts':{}}
        cleaned,data,tokens,receipt=clean_existing_inputs(doc,(line+'\n').encode())
        self.assertEqual(tokens,[])
        self.assertEqual(cleaned['factual_claims'],[])
        self.assertEqual(receipt['removed_diagnostic_claim_ids'],['Cflag'])
        self.assertNotIn('UNVERIFIED',data.decode());self.assertNotIn('UNINSPECTED',data.decode())


class MixedDiagnosticClauses(unittest.TestCase):
    def test_preserves_numeric_statement_and_removes_only_generated_verdict(self):
        from prepare_correction import mask_embedded_verdict_clauses
        lines=[
            '- Several quoted values carry unresolved UNVERIFIED/AMBIGUOUS flags, reducing confidence in ancillary numerical details though the primary 348.15 K fit parameters are internally consistent.',
            '- All derived quantities are computed values, not directly inspected database entries; numerous UNGROUNDED DATA FLAGS were raised for these derived numbers.',
            '- Density 992.083 kg/m³ at x₁ = 0 is an extrapolated value flagged as UNVERIFIED; the block contains no measurement at x₁ = 0.'
        ]
        for text in lines:
            clean,receipt=mask_embedded_verdict_clauses(text)
            self.assertEqual(len(clean),len(text))
            self.assertTrue(receipt)
            self.assertNotIn('UNVERIFIED',clean)
            self.assertNotIn('UNGROUNDED',clean)
            for idx,char in enumerate(text):
                if char.isnumeric():self.assertEqual(clean[idx],char)
        self.assertIn('not directly inspected database entries',mask_embedded_verdict_clauses(lines[1])[0])


class DiagnosticBoundarySummaries(unittest.TestCase):
    def test_both_legacy_flag_summaries_removed(self):
        from prepare_correction import clean_existing_inputs
        lines=['- Multiple data blocks cited in the answer were flagged as UNINSPECTED, meaning the quoted numerical values could not be fully verified against verbatim data inspection during the analysis run.', '- Multiple source data blocks quoted in the answer were flagged as UNINSPECTED, meaning the underlying data values could not be fully verified against the database within the analysis run.', '- Multiple data blocks cited in the analysis were flagged as UNINSPECTED, meaning many quoted numerical values could not be verified against verbatim database inspection.','- Several quoted block-scope boundary values (temperature and composition ranges) remain unverified against direct data inspection and carry UNVERIFIED flags.','- Many specific numerical ranges and composition limits quoted in the answer for blocks not directly inspected (including density, viscosity, permittivity, speed of sound, and heat capacity blocks) carry UNVERIFIED flags and could not be confirmed against verbatim data inspection.']
        for line in lines:
            doc={'answer':{'answer_id':'F021'},'excerpts':[],'factual_claims':[{'claim_id':'Cflag','lines':[1,1],'quote':line,'token_ids':[],'type':'diagnostic','verdict':'outside'}],'counts':{}}
            cleaned,data,tokens,receipt=clean_existing_inputs(doc,(line+'\n').encode())
            self.assertEqual(tokens,[])
            self.assertEqual(cleaned['factual_claims'],[])
            self.assertNotIn('UNVERIFIED',data.decode());self.assertNotIn('UNINSPECTED',data.decode())


class LegacySourceCategory(unittest.TestCase):
    def test_raw_locator_makes_legacy_category_explicit_without_judgment_change(self):
        from correct_artifacts import normalize_legacy_source
        row={'token_id':'n1','group':'property_value','outcome':'miss','numeric_outcome':'exact','final_reference':[{'doi':'10.1/example','block':2,'stored_value':'2.5'}]}
        original=dict(row)
        receipt=normalize_legacy_source(row,'thermoml-benchmark-eval/2')
        self.assertEqual(row.pop('source_kind'),'thermoml_archive')
        self.assertEqual(row,original)
        self.assertEqual(receipt['field'],'source_kind')
    def test_no_inference_for_missing_locator_or_artifact(self):
        from correct_artifacts import normalize_legacy_source
        for row in ({'token_id':'n1','group':'property_value'}, {'token_id':'n1','group':'pipeline_artifact','artifact_reference':{'path':'fit.csv'}}):
            with self.assertRaises(ValueError):normalize_legacy_source(row,'thermoml-benchmark-eval/2')
        row={'token_id':'n1','group':'property_value'}
        self.assertIsNone(normalize_legacy_source(row,'thermoml-benchmark-eval/3'))
