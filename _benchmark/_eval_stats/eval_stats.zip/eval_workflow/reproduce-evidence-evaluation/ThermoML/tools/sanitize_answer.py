"""Prepare and verify the ThermoML authored-answer input for blind review."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path
from tokenize_numbers import tokenize

PROFILE = "thermoml-authored-answer/1"
SCHEMA = "thermoml-blind-input/1"
CUT = re.compile(r"^## (ID Catalog Snapshot|Data Inspections|Verdict|Output Files)")
STATS = re.compile(r"^\*\*(Tool calls|Time):\*\*")
STAMP = re.compile(r"\d{8}_\d{6}")
END = "<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->"
LEVELS = ("Query", "Analysis", "Main")
FLAGS_HEADER = ("[UNGROUNDED DATA FLAGS] The following quoted values could not be "
                "verified against any verbatim data inspection in this run and must "
                "be treated as UNVERIFIED:")
FLAG_ROW = re.compile(r"^- \*\*(UNINSPECTED_BLOCK|UNINSPECTED_VALUE|MISATTRIBUTED_VALUE|"
                      r"AMBIGUOUS_VALUE|UNGROUNDED_LITERAL|AMBIGUOUS_DOI_SCOPE|"
                      r"UNINSPECTED_DOI_SCOPE)\*\* .+: .+$")
OVERFLOW = re.compile(r"^- … and [1-9]\d* more of the same kinds — .+: .+$")
INSPECTED = re.compile(r"^Inspected so far: \S.*$")
FIX_PREFIX = {
    "UNINSPECTED_BLOCK": "  fix (required — this region quotes data from cited database blocks): \x60",
    "UNINSPECTED_VALUE": "  fix (required — this value IS in the cited block's database table): \x60",
    "MISATTRIBUTED_VALUE": "  fix (required — this IS a database value, under a different block): \x60",
}
CONDITIONAL_FIX = "  fix (ONLY if this is meant to be a database datum): \x60"
CONDITIONAL_END = ("\x60 — if it is a value you computed or an external reference, "
                   "keep it and label its provenance instead")
SCOPE_FIX = "  fix (required — source scope is unresolved): "

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def _generated_fix(kind: str, line: str) -> bool:
    if kind in {"AMBIGUOUS_DOI_SCOPE", "UNINSPECTED_DOI_SCOPE"}:
        return line.startswith(SCOPE_FIX) and bool(line[len(SCOPE_FIX):].strip())
    if kind == "MISATTRIBUTED_VALUE" and line.startswith("  fix: \x60"):
        # Historical September gate emitted this shorter re-anchor form.
        return line.startswith("  fix: \x60re-anchor ") and line.endswith("\x60")
    if kind in FIX_PREFIX:
        return (line.startswith(FIX_PREFIX[kind]) and line.endswith("\x60")
                and len(line) > len(FIX_PREFIX[kind]) + 1)
    return (line.startswith(CONDITIONAL_FIX) and line.endswith(CONDITIONAL_END)
            and len(line) > len(CONDITIONAL_FIX) + len(CONDITIONAL_END))

def _embedded_flag_ranges(lines: list[str]) -> list[list[int]]:
    """Recognize only complete gate reports; ranges are zero-based, end exclusive."""
    ranges = []
    for header, line in enumerate(lines):
        if "[UNGROUNDED DATA FLAGS]" not in line:
            continue
        if line != FLAGS_HEADER or header == 0 or lines[header - 1] != "---":
            raise ValueError("malformed embedded grounding diagnostic header")
        pos = header + 1
        count = 0
        while pos < len(lines) and (match := FLAG_ROW.fullmatch(lines[pos])):
            if pos + 1 >= len(lines) or not _generated_fix(match[1], lines[pos + 1]):
                raise ValueError("malformed embedded grounding diagnostic fix")
            pos += 2
            count += 1
        if not 1 <= count <= 8:
            raise ValueError("embedded grounding diagnostic has invalid row count")
        if pos < len(lines) and lines[pos].startswith("- … and "):
            if count != 8 or not OVERFLOW.fullmatch(lines[pos]):
                raise ValueError("malformed embedded grounding diagnostic overflow")
            pos += 1
        if pos < len(lines) and lines[pos].startswith("Inspected so far:"):
            if not INSPECTED.fullmatch(lines[pos]):
                raise ValueError("malformed embedded grounding diagnostic inspection list")
            pos += 1
        boundary = pos
        while boundary < len(lines) and not lines[boundary]:
            boundary += 1
        if boundary < len(lines) and not re.match(r"^#{1,6} ", lines[boundary]):
            raise ValueError("unrecognized embedded grounding diagnostic payload")
        ranges.append([header - 1, pos])
    for previous, current in zip(ranges, ranges[1:]):
        if current[0] < previous[1]:
            raise ValueError("overlapping embedded grounding diagnostics")
    return ranges

def sanitize_bytes(data: bytes, level: str) -> dict:
    """Return review text and private source-position provenance."""
    if level not in LEVELS:
        raise ValueError("level must be Query, Analysis or Main")
    lines = data.decode("utf-8-sig").splitlines()
    if not lines:
        raise ValueError("answer is empty")
    out = list(lines)
    replaced = {}
    if level in ("Analysis", "Main") and STAMP.search(out[0]):
        replaced[1] = out[0]
        out[0] = STAMP.sub("[run id removed]", out[0])
    index = next((i for i, line in enumerate(out[:12]) if STATS.match(line)), None)
    if index is not None:
        replaced[index + 1] = out[index]
        out[index] = "**[run statistics removed]**"
    cut = next((i for i, line in enumerate(out) if CUT.match(line)), len(out))
    embedded = _embedded_flag_ranges(out[:cut])
    for start, stop in embedded:
        out[start:stop] = [""] * (stop - start)
    if not any(line.strip() for line in out[:cut]):
        raise ValueError("answer has no authored body before generated sections")
    text = "\n".join(out[:cut] + [END]) + "\n"
    result = {
        "schema": SCHEMA, "profile": PROFILE, "level": level, "text": text,
        "source_answer_sha256": digest(data),
        "packet_answer_sha256": digest(text.encode("utf-8")),
        "source_lines": len(lines), "kept_lines": cut,
        "cut_heading": lines[cut] if cut < len(lines) else None,
        "removed_line_range": [cut + 1, len(lines)] if cut < len(lines) else None,
        "replaced_lines": replaced,
        "line_map": [{"packet_start": 1, "source_start": 1, "count": cut}],
        "generated_end_line": cut + 1,
    }
    if embedded:
        result["removed_embedded_line_ranges"] = [[start + 1, stop] for start, stop in embedded]
    assert_clean(text.encode("utf-8"))
    return result

def assert_clean(data: bytes, *, answer: bool = False, level: str | None = None) -> None:
    """Reject generated sections, including escaped text in solver logs."""
    text = data.decode("utf-8-sig")
    scan = text.replace("\\r\\n", "\n").replace("\\n", "\n")
    scan = re.sub(r"\\+u005[bB]", "[", scan)
    scan = re.sub(r"\\+u005[dD]", "]", scan)
    if ("[UNGROUNDED DATA FLAGS]" in scan or "[POSTANSWER DATA FLAGS]" in scan
            or "[POSTANSWER FIELD:" in scan):
        raise ValueError("worker input contains a grounding diagnostic")
    if any(CUT.match(line) for line in scan.splitlines()):
        raise ValueError("worker input contains a generated section")
    if answer:
        lines = text.splitlines()
        if not lines or lines[-1] != END or lines.count(END) != 1:
            raise ValueError("worker answer lacks its sanitization boundary")
        if any(STATS.match(line) for line in lines[:12]):
            raise ValueError("worker answer contains run statistics")
        if level in ("Analysis", "Main") and STAMP.search(lines[0]):
            raise ValueError("worker answer contains a run identifier")

def check_artifact(path: Path, source_bytes: bytes | None = None) -> None:
    """Check text in an explicitly allowed solver artifact."""
    if path.name.lower() in {
        "result.md", "answer.md", "evaluation.json", "evaluated_answer.md",
        "claim_review.json", "verdict.md", "verdict.json",
    }:
        raise ValueError("answer or evaluation output is not a solver artifact")
    data = path.read_bytes()
    if source_bytes is not None and data == source_bytes:
        raise ValueError("solver artifact duplicates the original answer")
    try:
        assert_clean(data)
    except UnicodeDecodeError:
        if path.suffix.lower() in {".md", ".txt", ".json", ".jsonl", ".csv", ".py", ".log"}:
            raise ValueError("text artifact must have an auditable UTF-8 representation")

def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def annotated_text(text: str, tokens: list[dict]) -> str:
    """Bind review line excerpts to exactly the same clean tokenization."""
    lines = []
    by_line = {}
    for token in tokens:
        by_line.setdefault(token["line"], []).append(token)
    for number, line in enumerate(text.splitlines(), 1):
        lines.append(f"{number:04d} | {line}")
        if number in by_line:
            lines.append("     TOKENS: " + "; ".join(
                f"{t['token_id']}@{t['column']}={t['text']}" for t in by_line[number]))
    return "\n".join(lines) + "\n"

def public_receipt(answer_id: str, result: dict, packet_dir: Path, artifacts: list,
                   question_sha256: str) -> dict:
    return {
        "schema": SCHEMA, "profile": PROFILE, "answer_id": answer_id,
        "level": result["level"], "packet_answer_sha256": result["packet_answer_sha256"],
        "tokens_sha256": digest((packet_dir / "tokens.json").read_bytes()),
        "annotated_sha256": digest((packet_dir / "annotated.txt").read_bytes()),
        "question_sha256": question_sha256,
        "artifact_files": artifacts,
    }

def validate_packet(packet_dir: Path, answer_id: str, private_provenance: Path) -> dict:
    """Check source provenance without supplying source bytes to a worker."""
    receipt_path = packet_dir / "BLIND_INPUT.json"
    if not receipt_path.is_file() or not private_provenance.is_file():
        raise ValueError("blind input sanitization receipt is required")
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    private = json.loads(private_provenance.read_text(encoding="utf-8"))
    data = (packet_dir / "answer.md").read_bytes()
    question = (packet_dir / "question.md").read_bytes()
    try:
        question.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("packet question is not UTF-8") from exc
    if not question:
        raise ValueError("packet question is empty")
    assert_clean(question)
    assert_clean(data, answer=True, level=receipt.get("level"))
    if (receipt.get("schema") != SCHEMA or receipt.get("profile") != PROFILE
            or receipt.get("answer_id") != answer_id
            or receipt.get("packet_answer_sha256") != digest(data)
            or receipt.get("tokens_sha256") != digest((packet_dir / "tokens.json").read_bytes())
            or receipt.get("annotated_sha256") != digest((packet_dir / "annotated.txt").read_bytes())
            or receipt.get("question_sha256") != digest(question)
            or private.get("question_sha256") != digest(question)
            or private.get("answer_id") != answer_id
            or private.get("packet_source_mode") != "sanitized_authored_answer"
            or private.get("packet_answer_sha256") != digest(data)):
        raise ValueError("blind input identity or bytes changed")
    source_path = Path(private["source_answer_path"]).resolve(strict=True)
    question_source = Path(private["question_source_path"]).resolve(strict=True)
    if (source_path.is_relative_to(packet_dir.resolve())
            or question_source.is_relative_to(packet_dir.resolve())
            or question_source == source_path):
        raise ValueError("original answer or question is inside worker packet")
    if question_source.read_bytes() != question:
        raise ValueError("packet question changed from its original source")
    source_bytes = source_path.read_bytes()
    expected_tokens = tokenize(data.decode("utf-8"), answer_id)
    if json.loads((packet_dir / "tokens.json").read_text(encoding="utf-8")) != expected_tokens:
        raise ValueError("tokens do not match the clean answer")
    if (packet_dir / "annotated.txt").read_bytes() != annotated_text(data.decode("utf-8"), expected_tokens).encode("utf-8"):
        raise ValueError("annotations do not match the clean answer")
    expected = sanitize_bytes(source_bytes, receipt.get("level"))
    # JSON object keys are strings after serialization.
    detail = json.loads(json.dumps({k: v for k, v in expected.items() if k != "text"}))
    if (expected["text"].encode("utf-8") != data
            or private.get("source_answer_sha256") != expected["source_answer_sha256"]
            or private.get("sanitization") != detail):
        raise ValueError("blind input does not match its source sanitization")
    files = receipt.get("artifact_files", [])
    if files != private.get("artifact_files", []):
        raise ValueError("blind artifact manifest differs")
    artifact_root = packet_dir / "artifacts"
    declared = set()
    for item in files:
        relative = Path(item["path"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("blind artifact path is invalid")
        artifact = artifact_root / relative
        if not artifact.resolve().is_relative_to(artifact_root.resolve()):
            raise ValueError("blind artifact escapes its packet")
        if digest(artifact.read_bytes()) != item["sha256"]:
            raise ValueError("blind artifact changed")
        check_artifact(artifact, source_bytes)
        declared.add(relative.as_posix())
    actual = {p.relative_to(artifact_root).as_posix() for p in artifact_root.rglob("*") if p.is_file()}
    if actual != declared:
        raise ValueError("undeclared worker artifact")
    for extra in packet_dir.rglob("*"):
        if not extra.is_file() or extra.name in {"answer.md", "question.md", "tokens.json", "annotated.txt", "BLIND_INPUT.json"} or extra.is_relative_to(artifact_root):
            continue
        extra_bytes = extra.read_bytes()
        if extra_bytes == source_bytes:
            raise ValueError("worker packet contains an original answer copy")
        try:
            assert_clean(extra_bytes)
        except UnicodeDecodeError:
            if extra.suffix.lower() in {".md", ".txt", ".json", ".jsonl", ".csv", ".py", ".log"}:
                raise ValueError("worker text must have an auditable UTF-8 representation")
    return {
        "receipt_sha256": digest(receipt_path.read_bytes()),
        "private_provenance_sha256": digest(private_provenance.read_bytes()),
        "packet_answer_sha256": digest(data), "tokens_sha256": receipt["tokens_sha256"],
        "annotated_sha256": receipt["annotated_sha256"],
        "question_sha256": receipt["question_sha256"],
    }

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--level", choices=LEVELS, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--private-receipt", type=Path, required=True)
    args = parser.parse_args()
    source, output, receipt = args.source.resolve(strict=True), args.output.resolve(), args.private_receipt.resolve()
    if source == output or source == receipt or output == receipt:
        raise ValueError("source, review output and private receipt must be separate")
    if "private" not in {part.lower() for part in receipt.parts}:
        raise ValueError("sanitization receipt belongs in private storage")
    if receipt.is_relative_to(output.parent):
        raise ValueError("private receipt cannot be in the worker input directory")
    if output.exists() or receipt.exists():
        raise ValueError("refusing to overwrite sanitization outputs")
    result = sanitize_bytes(source.read_bytes(), args.level)
    assert_clean(result["text"].encode("utf-8"), answer=True, level=args.level)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(result["text"], encoding="utf-8", newline="\n")
    write_json(receipt, {**{k: v for k, v in result.items() if k != "text"}, "source_answer_path": str(source)})
    print(json.dumps({"output": str(output), "kept_lines": result["kept_lines"],
                      "packet_answer_sha256": result["packet_answer_sha256"]}))

if __name__ == "__main__":
    main()
