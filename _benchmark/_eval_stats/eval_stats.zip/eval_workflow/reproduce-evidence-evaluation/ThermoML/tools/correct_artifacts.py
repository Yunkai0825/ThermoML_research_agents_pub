"""One-answer report correction: inspect fixed artifacts, preserve unaffected findings."""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import re
from pathlib import Path
from filesystem_paths import io_path
from artifact_source import resolve_artifact, inventory_errors, exclusion_errors, sha, load
from canonical_export import _counts, _claim_counts, _excerpts, boolean
from tokenize_numbers import tokenize
from sanitize_answer import assert_clean

SCHEMA='thermoml-artifact-correction/1'
OUTCOMES={'exact','near_miss','miss'}

def save(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def flatten(doc):
    return [{**value,'line':item['line'],'context_excerpt':item['excerpt']} for item in doc['excerpts'] for value in item['values']]

def worst(values):
    if any(x not in OUTCOMES|{'not_applicable'} for x in values):
        raise ValueError('unresolved or invalid comparison dimension')
    return 'miss' if 'miss' in values else 'near_miss' if 'near_miss' in values else 'exact'

def normalize_legacy_source(row, schema):
    """Make a legacy raw-archive source tag explicit without changing judgment."""
    if schema != 'thermoml-benchmark-eval/2' or row.get('source_kind') is not None or row.get('group') == 'outside':
        return None
    if row.get('group') not in {'property_value','measurement_condition','stored_uncertainty'} or row.get('artifact_reference'):
        raise ValueError('cannot infer legacy source category')
    refs=json.dumps([row.get('final_reference'),row.get('initial_reference')])
    if not any(marker in refs for marker in ('GLOBlit_','PROPblock_','"doi"')):
        raise ValueError('legacy raw source category lacks an archive locator')
    row['source_kind']='thermoml_archive'
    return {'token_id':row['token_id'],'field':'source_kind','from':None,'to':'thermoml_archive','reason':'Schema /2 raw category with explicit archive locator; existing comparison and verdict unchanged'}


def normalize_legacy_claim_flags(claims):
    """Decode exact legacy Boolean strings without changing factual judgments."""
    records=[]
    for claim in claims:
        if 'misassigned' not in claim:
            continue
        before=claim['misassigned'];after=boolean(before)
        if type(before) is not bool:
            records.append({'claim_id':claim['claim_id'],'field':'misassigned','from':before,'to':after})
        claim['misassigned']=after
    return records


def no_output_requested_condition(claim, by_token, answer):
    """Preserve feasibility type only for explicit refusal with requested temperature."""
    if claim.get('final_type',claim.get('type'))!='prediction_feasibility':return False
    quote=re.sub(r'[*_`]', '', claim.get('quote',''))
    if not re.search(r'\bno\s+(?:[A-Za-z-]+\s+){0,3}prediction\s+can\s+be\s+made\b',quote,re.I):return False
    question=' '.join(line for line in answer.splitlines() if re.match(r'\*?\*?Question:',line))
    ids=claim.get('token_ids',[])
    if not ids:return False
    for t in [by_token.get(tid,{}) for tid in ids]+tokenize(quote,'scope'):
        tail=t.get('line_text','')[max(0,t.get('end_column',0)-1):]
        unit=re.match(r'\s*(°\s*C|K)\b',tail)
        if not unit:return False
        pattern=r'(?<![\d.])'+re.escape(t.get('text',''))+r'\s*'+re.escape(unit.group(1))+r'\b'
        if not re.search(pattern,question):return False
    return True


def preserve_existing_outside(claim, update, outside_ids, corrected_ids):
    """Repair stale rationale without changing an unrelated existing judgment/type."""
    if update.get('preserve_existing_outside') is not True:return False
    if update.get('final_verdict')!='outside' or claim.get('final_verdict',claim.get('verdict'))!='outside':return False
    if update.get('final_type')!=claim.get('final_type',claim.get('type')) or 'token_ids' in update:return False
    owned=set(claim.get('token_ids',[]))
    return bool(owned) and owned<=set(outside_ids) and not owned&set(corrected_ids)


def clear_nonnumeric_quote_ownership(claim, update, by_token, answer):
    """Remove broad legacy line links only from a verbatim, wholly nonnumeric outside quote."""
    if update.get('clear_spurious_numeric_ownership') is not True:return False
    if update.get('token_ids')!=[] or update.get('final_verdict')!='outside':return False
    if claim.get('final_verdict',claim.get('verdict'))!='outside' or update.get('final_type')!=claim.get('final_type',claim.get('type')):return False
    quote=claim.get('quote','')
    if not quote or tokenize(quote,'ownership'):return False
    bounds=claim.get('lines',[])
    if len(bounds)!=2:return False
    matches=[(i+1,line.index(quote),line.index(quote)+len(quote)) for i,line in enumerate(answer.splitlines()) if bounds[0]<=i+1<=bounds[1] and line.count(quote)==1]
    if len(matches)!=1:return False
    lineno,start,end=matches[0];owned=claim.get('token_ids',[])
    if not owned:return False
    for tid in owned:
        t=by_token.get(tid,{})
        if t.get('line')!=lineno:return False
        if max(t['column']-1,start)<min(t['end_column']-1,end):return False
    return True


def correct(packet:Path,report:dict):
    packet=io_path(packet)
    old=load(packet/'existing_evaluation.json')
    answer=(packet/'answer.md').read_text(encoding='utf-8-sig')
    assert_clean(answer.encode('utf-8'))
    if report.get('schema')!=SCHEMA or report.get('answer_id')!=old['answer']['answer_id']:
        raise ValueError('correction must bind exactly this one existing answer')
    for key,name in [('existing_evaluation_sha256','existing_evaluation.json'),('answer_sha256','answer.md'),('artifact_manifest_sha256','BLIND_INPUT.json')]:
        if report.get(key)!=sha(packet/name):raise ValueError('stale correction input '+name)
    for key in ['complete','entire_answer_read','all_pipeline_outputs_inventoried','all_artifacts_inspected']:
        if report.get(key) is not True:raise ValueError('correction incomplete: '+key)
    if report.get('unresolved_questions')!=[]:raise ValueError('unresolved interpretation prevents acceptance')
    tokens=load(packet/'tokens.json');by_token={t['token_id']:t for t in tokens}
    oldrows=flatten(old);normalizations=[]
    for row in oldrows:
        source_normalization=normalize_legacy_source(row,old.get('schema'))
        if source_normalization:normalizations.append(source_normalization)
        before=row.get('misassigned',False);after=boolean(before)
        if type(before) is not bool:normalizations.append({'token_id':row['token_id'],'field':'misassigned','from':before,'to':after})
        row['misassigned']=after
    oldmap={x['token_id']:x for x in oldrows}
    if set(oldmap)!=set(by_token):raise ValueError('existing report and clean answer lexical tokens differ')
    for tid,t in by_token.items():
        if any(oldmap[tid].get(k)!=t[k] for k in ['text','line','column','end_column']):
            raise ValueError('existing report token span differs: '+tid)
        context=answer.splitlines()[t['line']-1]
        if oldmap[tid]['context_excerpt']!=context:
            normalizations.append({'token_id':tid,'field':'context_excerpt','from':oldmap[tid]['context_excerpt'],'to':context,'reason':'Restore exact verified answer context; lexical token span unchanged'})
            oldmap[tid]['context_excerpt']=context
    checks=report.get('token_checks',[]);ids=[x.get('token_id') for x in checks]
    inventory=report.get('pipeline_inventory',{})
    if len(ids)!=len(set(ids)) or set(ids)!=set(x.get('token_id') for x in inventory.get('occurrences',[])):
        raise ValueError('one artifact comparison required for each inventoried output occurrence')
    if set(ids)-set(by_token):raise ValueError('unknown corrected token')
    exclusion_updates={}
    for update in report.get('exclusion_updates',[]):
        tid=update.get('token_id'); kind=update.get('kind')
        if tid not in oldmap or oldmap[tid]['group']!='outside' or tid in ids or tid in exclusion_updates:
            raise ValueError('exclusion repair must identify one unchanged outside token')
        if kind not in {'label','ordinary_arithmetic'} or not update.get('reason') or not update.get('evidence'):
            raise ValueError('exclusion repair needs concrete non-pipeline semantic evidence')
        oldmap[tid]['scope_exclusion']={'reason':kind,'detail':update['reason']}
        oldmap[tid]['reason']=update['reason'];oldmap[tid]['evidence']=update['evidence']
        exclusion_updates[tid]=update
    changes={};resolved=[]
    for check in checks:
        tid=check['token_id'];token=by_token[tid]
        if token.get('lexical_kind') in {'subscript','superscript'}:
            raise ValueError('equation/unit exponent cannot count as pipeline output')
        row=resolve_artifact(packet,token,check);resolved.append(row)
        evidence=check.get('evidence');reason=check.get('reason')
        if not isinstance(evidence,list) or not evidence or not reason:
            raise ValueError('artifact comparison requires explicit evidence and reason')
        source=check.get('source_outcome');condition=check.get('condition_outcome')
        if row.get('reason_code')=='evidence_gap':source='miss'
        dims=[row['numeric_outcome'],source,condition,row.get('basis_outcome','not_applicable'),row.get('unit_outcome','not_applicable')]
        outcome=worst(dims)
        if check.get('numeric_outcome')!=row['numeric_outcome'] or check.get('outcome')!=outcome:
            raise ValueError('declared numeric/final verdict disagrees with inspected artifact '+tid)
        new={**oldmap[tid], 'group':'pipeline_artifact','category':'pipeline_artifact','classification':'pipeline_artifact',
             'source_kind':'hardcoded_artifact','artifact_inspected':True,'outcome':outcome,
             'numeric_outcome':row['numeric_outcome'],'source_outcome':source,'condition_outcome':condition,
             'unit_outcome':row.get('unit_outcome','not_applicable'),'basis_outcome':row.get('basis_outcome','not_applicable'),
             'precision_policy':row.get('precision_policy'),'precision_role':row.get('precision_role'),'raw_numeric_outcome':row.get('raw_numeric_outcome'),'misassigned':boolean(check.get('misassigned',False)),
             'reason':reason,'evidence':evidence,'property':check.get('property'),'claimed_unit':check.get('unit'),
             'reported_value':row.get('comparison_value',token['parsed_value']),'lexical_parsed_value':token['parsed_value'],'lexical_sign_interpretation':row.get('lexical_sign_interpretation'),'artifact_reference':row.get('artifact_reference'),
             'curve_verification':row.get('curve_verification'),'calculated_reference_value':row.get('calculated_reference_value'),'artifact_search':row.get('artifact_search'),'population_interpretation':row.get('population_interpretation'),'magnitude_interpretation':row.get('magnitude_interpretation'),'lexical_scale_interpretation':row.get('lexical_scale_interpretation'),'reason_code':row.get('reason_code'),
             'final_reference':row.get('artifact_reference') or ('NA; '+row['reason']),
             'scope_exclusion':None,'reference_role':'fixed_pipeline_output',
             'prior_outcome':oldmap[tid]['outcome'],'prior_group':oldmap[tid]['group']}
        if new['misassigned'] and outcome=='exact':raise ValueError('misassignment cannot be Exact')
        changes[tid]={k:v for k,v in new.items() if v is not None}
    mapping={'checks':checks,'exclusions':[],'pipeline_inventory':inventory}
    for tid,row in oldmap.items():
        if tid not in changes and row['group']=='outside':
            exclusion=row.get('scope_exclusion') or {}
            mapping['exclusions'].append({'tokens':[tid],'reason':exclusion.get('reason','outside'),'detail':row.get('reason','')})
    errors=inventory_errors(packet,mapping,resolved)
    if errors:raise ValueError('; '.join(errors))
    claims=copy.deepcopy(old.get('factual_claims',[]))
    normalizations.extend(normalize_legacy_claim_flags(claims))
    claimmap={c['claim_id']:c for c in claims}
    if len(claimmap)!=len(claims):raise ValueError('existing factual claim IDs must be unique')
    updates=report.get('claim_updates',[]);updated=[];ownership_repairs=[]
    for update in updates:
        cid=update.get('claim_id')
        if cid not in claimmap or cid in updated:raise ValueError('unknown or duplicate updated claim')
        claim=claimmap[cid]
        preserved_feasibility=(update.get('final_type')=='prediction_feasibility' and no_output_requested_condition(claim,by_token,answer) and 'token_ids' not in update)
        preserved_outside=preserve_existing_outside(claim,update,{tid for tid,row in oldmap.items() if row['group']=='outside'},ids)
        cleared_nonnumeric=clear_nonnumeric_quote_ownership(claim,update,by_token,answer)
        if cleared_nonnumeric:ownership_repairs.append({'claim_id':cid,'removed_token_ids':list(claim['token_ids']),'reason':update['reason']})
        legitimate_outside=update.get('final_verdict')=='outside' and (update.get('final_type') in {'label','ordinary_arithmetic'} or preserved_feasibility or preserved_outside or cleared_nonnumeric)
        if (update.get('final_verdict') not in OUTCOMES and not legitimate_outside) or not update.get('reason') or not update.get('evidence'):
            raise ValueError('pipeline factual claim needs concrete outcome and source evidence')
        claim=claimmap[cid]
        if 'token_ids' in update:
            if not isinstance(update['token_ids'],list) or set(update['token_ids'])-set(by_token):raise ValueError('invalid corrected owner token links')
            claim.setdefault('initial_token_ids',copy.deepcopy(claim.get('token_ids',[])))
            claim['token_ids']=update['token_ids']
        if legitimate_outside and set(claim.get('token_ids',[]))&set(ids):raise ValueError('pipeline owner cannot remain outside')
        for key in ('type','verdict','reason','evidence'):
            if key in claim:claim.setdefault('initial_'+key,copy.deepcopy(claim[key]))
        claim.update(type=update.get('final_type','pipeline_artifact'),verdict=update['final_verdict'],reason=update['reason'],evidence=update['evidence'])
        claim.update(final_type=update.get('final_type','pipeline_artifact'),final_verdict=update['final_verdict'],
                     final_reason=update['reason'],final_evidence=update['evidence'],
                     scope_reclassification_reason=('Preserved legitimate outside scope with explicit semantic evidence.' if legitimate_outside else 'Inspected fixed pipeline artifact under current numerical category policy.'),
                     adjudication_action='artifact_correction')
        updated.append(cid)
    for repair in ownership_repairs:
        for tid in set(repair['removed_token_ids'])&set(ids):
            if not any(c['claim_id']!=repair['claim_id'] and tid in c.get('token_ids',[]) for c in claims):raise ValueError('ownership repair would orphan a corrected pipeline token')
    affected={c['claim_id'] for c in claims if set(c.get('token_ids',[]))&set(ids)}
    if affected-set(updated):raise ValueError('artifact token owners lack corrected factual verdicts')
    effective_claims=[{**c,'type':c.get('final_type',c.get('type')),'verdict':c.get('final_verdict'),
                       'reason':c.get('final_reason',c.get('reason',''))} for c in claims]
    errors=exclusion_errors(packet,mapping,effective_claims)
    if errors:raise ValueError('; '.join(errors))
    rows=[changes.get(r['token_id'],r) for r in oldrows]
    # Preserve every unrelated numeric row exactly; no mechanical rewrite of raw findings.
    if any(r!=oldmap[r['token_id']] for r in rows if r['token_id'] not in changes):
        raise ValueError('unaffected numeric finding changed')
    for row in rows:
        owners=[c for c in claims if row['token_id'] in c.get('token_ids',[])]
        if any(c['claim_id'] in updated for c in owners):
            row['claim_provenance']=[{'claim_id':c['claim_id'],'type':c.get('final_type',c.get('type')),
                                     'verdict':c.get('final_verdict',c.get('verdict')),
                                     'reason':c.get('final_reason',c.get('reason')),
                                     'evidence':c.get('final_evidence',c.get('evidence'))} for c in owners]
            row['related_claim_ids']=[c['claim_id'] for c in owners]
    doc=copy.deepcopy(old);doc['schema']='thermoml-benchmark-eval/3'
    doc['excerpts']=_excerpts(rows);doc['factual_claims']=claims
    doc['counts']['numeric']=_counts(rows);doc['counts']['factual_claims']=_claim_counts(claims)
    doc['counts']['excerpts']=len(doc['excerpts'])
    doc['columns']['factual_claims']=list(dict.fromkeys(k for c in claims for k in c))
    doc['columns']['values']=list(dict.fromkeys(k for r in rows for k in r if k not in ('line','context_excerpt')))
    doc['pipeline_artifact_review']={'category':'pipeline_artifact','counts':doc['counts']['numeric']['by_group']['pipeline_artifact'],
        'property_rollup':doc['counts']['numeric']['property_rollup'],'token_ids':ids,
        'existing_evaluation_sha256':report['existing_evaluation_sha256'],
        'comparison_scope':'actual inspected fixed pipeline outputs; ordinary derived arithmetic remains separate'}
    doc['how_to_read']=[x.replace('scored raw archive occurrences','scored archive and pipeline-artifact occurrences') for x in doc.get('how_to_read',[]) if 'provenance only' not in x]
    from fitting_precision import METHOD_TEXT
    doc['how_to_read'].append(METHOD_TEXT)
    doc['how_to_read'].append('pipeline_artifact is a first-class numerical category with its own Exact/Near/Miss subtotal; combined property statistics include property_value plus pipeline_artifact exactly once.')
    doc['sources']['artifact_correction.json']=hashlib.sha256(json.dumps(report,sort_keys=True,ensure_ascii=False).encode('utf-8')).hexdigest()
    receipt={'status':'PASS','answer_id':report['answer_id'],'pipeline_outputs':len(ids),'unaffected_numeric_rows':len(rows)-len(ids),
             'pipeline_artifact_counts':doc['counts']['numeric']['by_group']['pipeline_artifact'],
             'property_rollup':doc['counts']['numeric']['property_rollup'],'all_pipeline_outputs_inspected':True,
             'existing_report_sha256':report['existing_evaluation_sha256'],'nonnumeric_ownership_repairs':ownership_repairs,'legacy_typed_normalizations':normalizations,'exclusion_repairs':list(exclusion_updates.values())}
    return doc,receipt

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('command',choices=['check','stage'])
    ap.add_argument('--packet',type=Path,required=True);ap.add_argument('--report',type=Path,required=True)
    ap.add_argument('--acceptance',type=Path);ap.add_argument('--out',type=Path);ap.add_argument('--original-evaluation',type=Path)
    args=ap.parse_args();doc,receipt=correct(args.packet,load(args.report));receipt['correction_sha256']=sha(args.report)
    if args.command=='stage':
        if not args.acceptance or not args.out:ap.error('stage requires --acceptance and --out')
        accepted=load(args.acceptance)
        if accepted.get('correction_sha256')!=sha(args.report) or accepted.get('answer_id')!=receipt['answer_id']:
            raise ValueError('orchestrator acceptance does not bind this correction')
        for key in ['complete','entire_answer_inventory_checked','all_artifact_sources_inspected','units_basis_state_session_checked','unaffected_findings_preserved']:
            if accepted.get(key) is not True:raise ValueError('orchestrator source acceptance incomplete: '+key)
        if not accepted.get('source_evidence'):raise ValueError('orchestrator source evidence required')
        if doc.get('evaluation',{}).get('mode') == 'sanitized_existing_same_answer_report':
            if not args.original_evaluation:raise ValueError('orchestrator must supply private original evaluation for identity restoration')
            if accepted.get('original_evaluation_sha256') != sha(args.original_evaluation):raise ValueError('private original identity hash mismatch')
            original=load(args.original_evaluation)
            if original['answer']['answer_id'] != receipt['answer_id']:raise ValueError('private original answer identity differs')
            clean_identity=doc['answer']
            doc['answer']=original['answer'];doc['evaluation']=original['evaluation']
            doc['answer']['evaluated_answer_sha256']=sha(args.packet/'answer.md')
            doc['answer']['token_count']=len(load(args.packet/'tokens.json'))
            correction_source=doc['sources']['artifact_correction.json'];doc['sources']=original['sources'];doc['sources']['artifact_correction.json']=correction_source
        args.out.mkdir(parents=True,exist_ok=True);save(args.out/'evaluation.json',doc)
        (args.out/'evaluated_answer.md').write_bytes((args.packet/'answer.md').read_bytes())
        import shutil
        for entry in load(args.packet/'BLIND_INPUT.json').get('artifact_files',[]):
            source=args.packet/'artifacts'/entry['path']
            if sha(source)!=entry['sha256']:raise ValueError('artifact changed before staging')
            target=args.out/'artifacts'/entry['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
