import copy,json,tempfile,unittest
from pathlib import Path
from curve_reference import extremum,half_last_place
from artifact_source import resolve_artifact,sha
from tokenize_numbers import tokenize

class CurveVerificationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.p=Path(self.temp.name);(self.p/'artifacts').mkdir()
        self.answer='The saved excess curve minimum lies near x_ethanol = 0.4–0.5.'
        (self.p/'answer.md').write_text(self.answer,encoding='utf8');self.tokens=tokenize(self.answer,'fixture');(self.p/'tokens.json').write_text(json.dumps(self.tokens))
        vals=['-141.9293356139','-39.6407632174','42.9829398856','31.7647617660','-121.8397268585','-113.8374234268']
        (self.p/'artifacts/summary.csv').write_text('key,value\n'+''.join('A%d,%s\n'%(i,v) for i,v in enumerate(vals))+'rk_order,5\n',encoding='utf8')
        (self.p/'artifacts/plot.png').write_bytes(b'fixture plot, synthetic transport only')
        args='fit_block: density versus water at308.15K, linear mixing'
        (self.p/'artifacts/args.txt').write_text(args,encoding='utf8')
        self.files=[]
        for name in ['summary.csv','plot.png','args.txt']:
            origin={'root':'own_answer/eval/artifacts','owner_answer_id':'fixture','source_path':name if name!='args.txt' else 'fitting_tool_calls_verbatim.md','source_sha256':sha(self.p/'artifacts'/name),'source_role':'fixed_saved_data_or_plot' if name!='args.txt' else 'deterministic_fitting_tool_calls'}
            self.files.append({'path':name,'sha256':sha(self.p/'artifacts'/name),'numeric_primary_eligible':True,'eligibility':origin})
        (self.p/'BLIND_INPUT.json').write_text(json.dumps({'answer_id':'fixture','artifact_files':self.files}))
        selector=lambda i,key:{'path':'summary.csv','format':'csv','row':i,'field':'value','key':key}
        ref={**selector(1,'A0'),'stored_unit':'kg/m3','claimed_unit':'kg/m3','basis':'excess density','claimed_basis':'excess density','fit_session':'fit1','source_inputs':['fixture native density'],'state':'308.15K','source_context':[{'path':'args.txt','excerpt':args,'supports':['stored_unit','basis','fit_session','source_inputs','state']}],'generating_call':{'path':'args.txt','tool':'fit_block','fit_session':'fit1','arguments_excerpt':args}}
        reg=json.loads((Path(__file__).parent.parent/'user-interpretations.json').read_text(encoding='utf8'));reply=next(x['user_reply_exact'] for x in reg['entries'] if x['id']=='H73')
        spec={'decision_id':'H73','user_reply_exact':reply,'answer_context':self.answer,'plot':{'path':'plot.png','x_axis':'water mole fraction','y_axis':'excess density kg/m3','inspection':'Synthetic plot binding fixture; real C033 saved coefficients below.'},'coefficients':[selector(i+1,'A'+str(i)) for i in range(6)],'rk_order':selector(7,'rk_order'),'coordinate_basis':'water mole fraction','claimed_coordinate_basis':'ethanol mole fraction','coordinate_transform':'one_minus','coordinate_transform_reason':'Binary ethanol-water, x_ethanol=1-x_water.','curve_basis':'excess density','claimed_curve_basis':'excess density','curve_quantity':'excess','value_unit':'kg/m3','selection':'minimum','output':'coordinate','generation_link_reason':'Fixture binds original coefficient summary and plot to same fit arguments.','reported_interval':{'low_token_id':self.tokens[0]['token_id'],'high_token_id':self.tokens[1]['token_id']}}
        self.check={'classification':'pipeline_artifact','source_kind':'hardcoded_artifact','quantity':{'kind':'property'},'role':'value','unit':'1','property':'saved curve minimum coordinate','artifact_reference':ref,'curve_verification':spec}
    def tearDown(self):self.temp.cleanup()
    def test_real_c033_coefficients_interval_and_native_value_preserved(self):
        r=resolve_artifact(self.p,self.tokens[0],self.check)
        self.assertEqual(r['category'],'exact');self.assertEqual(r['stored_value'],'-141.9293356139');self.assertAlmostEqual(float(r['calculated_reference_value']),.448411406,places=7)
        self.assertEqual(r['curve_verification']['reference_role'],'reviewer_calculated_verification_of_saved_curve_not_native_scalar')
    def test_missing_coefficient_rejected(self):
        bad=copy.deepcopy(self.check);bad['curve_verification']['coefficients'].pop()
        with self.assertRaisesRegex(ValueError,'native RK order'):resolve_artifact(self.p,self.tokens[0],bad)
    def test_wrong_decision_and_ineligible_plot_rejected(self):
        bad=copy.deepcopy(self.check);bad['curve_verification']['decision_id']='H72'
        with self.assertRaisesRegex(ValueError,'H73'):resolve_artifact(self.p,self.tokens[0],bad)
        self.files[1]['numeric_primary_eligible']=False;(self.p/'BLIND_INPUT.json').write_text(json.dumps({'answer_id':'fixture','artifact_files':self.files}))
        with self.assertRaisesRegex(ValueError,'context/provenance'):resolve_artifact(self.p,self.tokens[0],self.check)
    def test_source_precision_boundary_rejected(self):
        bad=copy.deepcopy(self.check);bad['curve_verification'].pop('reported_interval');token=copy.deepcopy(self.tokens[0]);token['parsed_value']='0.4484114060468661';token['display_tolerance']='1e-15'
        self.assertEqual(resolve_artifact(self.p,token,bad)['category'],'exact')
        from fitting_precision import compare_curve_precision
        with self.assertRaisesRegex(ValueError,'precision crosses'):
            compare_curve_precision('0.4484','0.44844','0',['0.44844','0.44846'])
    def test_precision_envelope_contains_perturbed_extrema(self):
        a=[-141.9293356139,-39.6407632174,42.9829398856,31.764761766,-121.8397268585,-113.8374234268];e=[1e-6]*6;r=extremum(a,e,'minimum');lo,hi=r['coordinate_interval']
        for signs in range(64):
            pert=[v+e[i]*(1 if signs&(1<<i) else -1) for i,v in enumerate(a)];x=extremum(pert,[0]*6,'minimum')['coordinate'];self.assertLessEqual(lo,x);self.assertLessEqual(x,hi)
    def test_saved_baseline_at_bound_reported_coordinate(self):
        answer='At x = 0.4000, the saved curve ideal density is 1.400 kg/m3.'
        (self.p/'answer.md').write_text(answer,encoding='utf8');tokens=tokenize(answer,'fixture');(self.p/'tokens.json').write_text(json.dumps(tokens))
        path=self.p/'artifacts/summary.csv';path.write_text(path.read_text()+'zero,1.000000\none,2.000000\n');self.files[0]['sha256']=sha(path);self.files[0]['eligibility']['source_sha256']=sha(path)
        (self.p/'BLIND_INPUT.json').write_text(json.dumps({'answer_id':'fixture','artifact_files':self.files}))
        check=copy.deepcopy(self.check);check['unit']='kg/m3';sp=check['curve_verification'];sp.pop('reported_interval');sp.update(answer_context=answer,evaluation='ideal_baseline_at_reported_coordinate',output='value',curve_quantity='property',value_unit='kg/m3',coordinate_transform='identity',claimed_coordinate_basis='water mole fraction',coordinate_input={'token_id':tokens[0]['token_id']},baseline={'mixing_rule':'linear'})
        for name,row in [('zero',8),('one',9)]:sp['baseline'][name]={'path':'summary.csv','format':'csv','row':row,'field':'value','key':name,'stored_unit':'kg/m3'}
        result=resolve_artifact(self.p,tokens[1],check)
        self.assertEqual(result['category'],'exact');self.assertEqual(result['stored_value'],'-141.9293356139');self.assertAlmostEqual(float(result['calculated_reference_value']),1.4)
        sp['coordinate_input']['token_id']='missing'
        with self.assertRaisesRegex(ValueError,'same-line'):resolve_artifact(self.p,tokens[1],check)

    def test_saved_point_bound_token_and_native_coefficient_preserved(self):
        answer='At x = 0.50, the saved excess density is -35.482 kg/m3.'
        (self.p/'answer.md').write_text(answer,encoding='utf8');tokens=tokenize(answer,'fixture');(self.p/'tokens.json').write_text(json.dumps(tokens))
        check=copy.deepcopy(self.check);check['unit']='kg/m3';sp=check['curve_verification'];sp.pop('reported_interval');sp.update(answer_context=answer,evaluation='saved_curve_at_reported_coordinate',output='value',coordinate_transform='identity',claimed_coordinate_basis='water mole fraction',coordinate_input={'token_id':tokens[0]['token_id'],'role':'fixed_evaluation_coordinate','reason':'Table specifies this model evaluation point, not an observed uncertain location.'})
        result=resolve_artifact(self.p,tokens[1],check)
        self.assertEqual(result['category'],'exact');self.assertEqual(result['stored_value'],'-141.9293356139')
        self.assertAlmostEqual(float(result['calculated_reference_value']),-141.9293356139/4)
        self.assertEqual(result['curve_verification']['coordinate_input_receipt']['propagated_coordinate_tolerance'],0.)
        sp['coordinate_input'].pop('reason')
        with self.assertRaisesRegex(ValueError,'contextual reason'):resolve_artifact(self.p,tokens[1],check)

    def test_arrhenius_property_and_source_units(self):
        r=extremum([1.0],[1e-10],'maximum',{'mixing_rule':'arrhenius','zero':.001,'one':.001,'zero_error':1e-10,'one_error':1e-10});self.assertAlmostEqual(r['coordinate'],.5);self.assertAlmostEqual(r['value'],.0012840254167)
        bad=copy.deepcopy(self.check);bad['curve_verification']['coordinate_basis']='ethanol mole fraction'
        with self.assertRaisesRegex(ValueError,'distinct component'):resolve_artifact(self.p,self.tokens[0],bad)

if __name__=='__main__':unittest.main()


class SavedCurvePointVerification(unittest.TestCase):
    def test_real_enthalpy_curve_point_preserves_coefficient_precision(self):
        from curve_reference import value_at_coordinate,half_last_place
        a=['-1.60102','1.73493','-3.19748','3.11326','-2.36171']
        r=value_at_coordinate([float(v) for v in a],[half_last_place(v) for v in a],.1)
        expected=.1*.9*sum(float(v)*(-.8)**k for k,v in enumerate(a))
        self.assertAlmostEqual(r['value'],expected,12)
        self.assertLess(r['value_interval'][0],expected)
        self.assertGreater(r['value_interval'][1],expected)
        wide=value_at_coordinate([float(v) for v in a],[half_last_place(v) for v in a],.1,.005)
        self.assertLess(wide['value_interval'][0],r['value_interval'][0])
        self.assertGreater(wide['value_interval'][1],r['value_interval'][1])
    def test_point_interval_includes_interior_extremum_and_rejects_outside(self):
        from curve_reference import value_at_coordinate
        r=value_at_coordinate([4.],[0.],.5,.1)
        self.assertGreaterEqual(r['value_interval'][1],1.)
        self.assertLessEqual(r['value_interval'][0],.96)
        with self.assertRaises(ValueError):value_at_coordinate([4.],[0.],1.1)
