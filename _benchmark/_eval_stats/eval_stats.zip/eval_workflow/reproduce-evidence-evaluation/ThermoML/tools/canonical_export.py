"""Build canonical per-answer files from one accepted reconciliation per answer.

The caller supplies all paths. This module neither launches reviewers nor writes
into answer folders; it stages files beneath --out for separate publication.
"""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
import re
from pathlib import Path
from sanitize_answer import validate_packet
from review_contract import read, claim_rows, sha, initial_check, reconciliation_check, scientific_check, OUTCOMES, GROUPS
from group_contract import validate_group, validate_groups
from cache_compatibility import receipt_path as cache_receipt_path, validate as validate_cache

SCHEMA = "thermoml-benchmark-eval/3"
CLAIM_SCHEMA = "thermoml-benchmark-claim-review/1"

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")

def _span(lines, row):
    try:
        line, col, end = (int(row[key]) for key in ("line", "column", "end_column"))
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("invalid numeric token position") from exc
    if not 1 <= line <= len(lines) or not 1 <= col < end:
        raise ValueError("numeric token position out of range")
    return lines[line - 1][col - 1:end - 1]

def boolean(value):
    if type(value) is bool:return value
    if value == "False":return False
    if value == "True":return True
    raise ValueError("misassigned requires Boolean or exact legacy True/False string")

def _counts(rows):
    by_group = {group: {**{o: 0 for o in ("exact", "near_miss", "miss")},
                        "total": 0, "misassigned": 0}
                for group in ("measurement_condition", "property_value", "stored_uncertainty", "pipeline_artifact")}
    outside_roles = collections.Counter()
    dimensions = {key: collections.Counter() for key in ("numeric_outcome", "condition_outcome", "source_outcome")}
    bands = set()
    band_rows = 0
    for row in rows:
        if row.get("band_id"):
            bands.add(row["band_id"]); band_rows += 1
        if row["group"] == "outside":
            outside_roles[row.get("reference_role") or ""] += 1
            continue
        if row["group"] not in GROUPS or row["outcome"] not in OUTCOMES:
            raise ValueError("unresolved or invalid scored numeric row")
        group = by_group[row["group"]]
        group[row["outcome"]] += 1
        group["total"] += 1
        group["misassigned"] += boolean(row["misassigned"])
        for key in dimensions:
            dimensions[key][row.get(key) or ""] += 1
    totals = {key: sum(row[key] for row in by_group.values()) for key in
              ("exact", "near_miss", "miss", "total", "misassigned")}
    return {"lexical_tokens": len(rows), "outside": sum(outside_roles.values()),
            "outside_by_role": dict(sorted(outside_roles.items())), "scored": totals["total"],
            "by_group": by_group, "totals": totals,
            "property_rollup": {k: by_group["property_value"][k] + by_group["pipeline_artifact"][k] for k in by_group["property_value"]},
            "dimensions": {k: dict(sorted(v.items())) for k, v in dimensions.items()},
            "peak_bands": {"bands": len(bands), "rows": band_rows}}

def _claim_counts(rows):
    verdicts = collections.Counter(c["final_verdict"] for c in rows)
    types = collections.Counter(c.get("final_type") or c.get("type") or "" for c in rows)
    return {"total": len(rows), "scored": sum(verdicts[o] for o in ("exact", "near_miss", "miss")),
            "by_verdict": {k: verdicts[k] for k in ("exact", "near_miss", "miss", "outside")},
            "by_type": dict(sorted(types.items())),
            "misassigned": sum(boolean(c.get("misassigned", False)) for c in rows)}

def _source_refs(resolved):
    selected = set(resolved.get("selected_record_ids") or [])
    if not selected and resolved.get("matched_record"):
        selected = {resolved["matched_record"]}
    refs = []
    for candidate in resolved.get("candidate_records") or []:
        if candidate.get("matched_record") in selected:
            ref = {k: candidate.get(k) for k in ("doi", "block", "point", "matched_record", "source_field",
                                                "stored_value", "stored_unit", "converted_stored_value",
                                                "state_evidence", "phase") if candidate.get(k) is not None}
            if ref not in refs:
                refs.append(ref)
    if selected and {x.get("matched_record") for x in refs} != selected:
        raise ValueError("selected raw reference missing candidate evidence")
    return refs

def _numeric_rows(packet, decision):
    tokens = read(packet / "tokens.json")
    mapping = read(packet / "mapping.json")
    resolved = {r["token_id"]: r for r in read(packet / "resolved.json")["rows"]}
    checks = {r["token_id"]: r for r in mapping["checks"]}
    exclusions = {tid: e for e in mapping["exclusions"] for tid in e["tokens"]}
    judged = {r["token_id"]: r for r in decision["numeric_results"]}
    rows = []
    for token in tokens:
        tid = token["token_id"]
        m = checks.get(tid, {})
        r = resolved[tid]
        d = judged.get(tid)
        if d is None:
            if tid not in exclusions:
                raise ValueError("unjudged direct numeric token " + tid)
            exclusion = exclusions[tid]
            d = {"group": "outside", "outcome": "outside",
                 "numeric_outcome": "outside", "condition_outcome": "outside", "source_outcome": "outside",
                 "misassigned": False, "reason": exclusion.get("detail") or exclusion["reason"],
                 "evidence": ["mapping.json#" + tid]}
        if d["outcome"] == "needs_decision" or d["group"] != "outside" and d["outcome"] not in OUTCOMES:
            raise ValueError("unresolved numeric decision " + tid)
        refs = ([r["artifact_reference"]] if r.get("artifact_reference") else _source_refs(r))
        final_ref = ("NA; " + d["missing_reference"]["reason"]
                     if "missing_reference" in d else d.get("corrected_reference") or refs)
        if d["group"] != "outside" and not final_ref:
            final_ref = "NA; see evidence and search boundary"
        role = d.get("reference_role")
        if d["group"] == "outside" and not role:
            role = "derived_input_provenance" if exclusions.get(tid, {}).get("reason") == "derived" else "non_measurement_context"
        row = {"token_id": tid, "text": token["text"], "line": token["line"], "column": token["column"],
               "end_column": token["end_column"], "context_excerpt": token["line_text"],
               "group": d["group"], "outcome": d["outcome"],
               "numeric_outcome": d.get("numeric_outcome", "outside"),
               "condition_outcome": d.get("condition_outcome", "outside"),
               "source_outcome": d.get("source_outcome", "outside"),
               "misassigned": d.get("misassigned", False),
               "reason": d["reason"], "evidence": d.get("evidence", []),
               "property": d.get("property") or m.get("property") or r.get("property"),
               "claimed_unit": d.get("claimed_unit") or m.get("unit") or r.get("unit"),
               "final_reference": final_ref, "initial_reference": refs,
               "initial_resolver_outcome": r.get("category"),
               "initial_stored_value": r.get("stored_value"), "initial_stored_unit": r.get("stored_unit"),
               "initial_cited_records": m.get("records", []),
               "reference_role": role, "scope_exclusion": (None if "missing_reference" in d else d.get("scope_exclusion") or exclusions.get(tid)),
               "source_kind": (d.get("source_kind") or r.get("source_kind") or "thermoml_archive") if d["group"] != "outside" else None,
               "classification": d.get("classification") or m.get("classification"),
               "category": d.get("classification") or m.get("classification"),
               "artifact_inspected": d.get("artifact_inspected"),
               "artifact_reference": r.get("artifact_reference"),
               "artifact_search": r.get("artifact_search"),
               "population_interpretation": r.get("population_interpretation"),
               "magnitude_interpretation": r.get("magnitude_interpretation"),
               "curve_verification": r.get("curve_verification"),
               "calculated_reference_value": r.get("calculated_reference_value"),
               "lexical_scale_interpretation": r.get("lexical_scale_interpretation"),
               "reported_value": r.get("comparison_value", token.get("parsed_value")),
               "lexical_parsed_value": token.get("parsed_value"),
               "lexical_sign_interpretation": r.get("lexical_sign_interpretation"),
               "raw_numeric_outcome": r.get("raw_numeric_outcome"),
               "precision_policy": r.get("precision_policy"), "precision_role": r.get("precision_role"),
               "unit_outcome": r.get("unit_outcome"), "basis_outcome": r.get("basis_outcome")}
        for key in ("missing_reference", "reason_code", "comparison_kind", "band_id", "band_check", "corrected_quantity_kind",
                    "scope_reclassification_reason", "scope_reclassification_evidence"):
            if key in d:
                row[key] = d[key]
        rows.append({k: v for k, v in row.items() if v is not None})
    return rows

def _claim_rows(packet, decision):
    judged = {c["claim_id"]: c for c in decision["claim_decisions"]}
    rows = []
    for initial in claim_rows(packet / "claims.jsonl"):
        d = judged[initial["claim_id"]]
        if d["final_verdict"] == "needs_decision":
            raise ValueError("unresolved factual decision")
        row = {**initial, "initial_quote": initial["quote"],
               "quote": d.get("final_quote", initial["quote"]),
               "lines": d.get("final_lines", initial["lines"]),
               "initial_type": initial.get("type"),
               "type": d.get("final_type", initial.get("type")),
               "initial_verdict": initial["verdict"], "final_verdict": d["final_verdict"],
               "adjudication_action": d["action"], "final_reason": d["reason"],
               "final_evidence": d["evidence"]}
        if d.get("scope_reclassification_reason"):
            row["scope_reclassification_reason"] = d["scope_reclassification_reason"]
        rows.append(row)
    for added in decision.get("added_claims", []):
        if added["final_verdict"] == "needs_decision":
            raise ValueError("unresolved added factual decision")
        rows.append({**added, "initial_verdict": "not_in_initial_ledger",
                     "adjudication_action": "added", "final_reason": added["reason"],
                     "final_evidence": added["evidence"]})
    return rows

def _excerpts(rows):
    excerpts, index = [], {}
    for row in rows:
        key = (row["line"], row["context_excerpt"])
        if key not in index:
            index[key] = len(excerpts)
            excerpts.append({"line": row["line"], "excerpt": row["context_excerpt"], "values": []})
        value = {k: v for k, v in row.items() if k not in ("line", "context_excerpt")}
        excerpts[index[key]]["values"].append(value)
    return excerpts

def numeric_document(packet: Path, unit: dict, decision: dict, identity: dict, result: Path,
                     run_root: Path, benchmark_root: Path | None = None) -> tuple[dict, bytes]:
    """Return canonical schema-3 JSON and exact evaluated bytes, without writing."""
    from fitting_precision import METHOD_TEXT
    answer = (packet / "answer.md").read_bytes()
    lines = answer.decode("utf-8-sig").splitlines()
    result_bytes = result.read_bytes()
    result_lines = result_bytes.decode("utf-8-sig").splitlines()
    rows = _numeric_rows(packet, decision)
    if len(rows) != len(read(packet / "tokens.json")):
        raise ValueError("lexical token count changed")
    for row in rows:
        if _span(lines, row) != row["text"]:
            raise ValueError("evaluated answer position mismatch " + row["token_id"])
        if row["group"] != "outside" and _span(result_lines, row) != row["text"]:
            raise ValueError("original answer scored position mismatch " + row["token_id"])
    claims = _claim_rows(packet, decision)
    by_token = collections.defaultdict(list)
    for claim in claims:
        for tid in claim.get("token_ids", []):
            by_token[tid].append({"claim_id": claim["claim_id"], "type": claim.get("type"),
                                  "verdict": claim["final_verdict"], "reason": claim.get("final_reason"),
                                  "evidence": claim.get("final_evidence")})
    for row in rows:
        row["related_claim_ids"] = [c["claim_id"] for c in by_token[row["token_id"]]]
        row["claim_provenance"] = by_token[row["token_id"]]
    coverage = {**read(packet / "coverage.json"), **decision["omission_result"]}
    for item in ("relevant_items", "present_items", "omitted_items"):
        if not isinstance(coverage[item], list):
            raise ValueError("coverage item list invalid")
    excerpts = _excerpts(rows)
    counts = {"numeric": _counts(rows), "factual_claims": _claim_counts(claims),
              "coverage": {"relevant": len(coverage["relevant_items"]),
                           "present": len(coverage["present_items"]),
                           "omitted": len(coverage["omitted_items"]),
                           "diagnostic_alternatives": len(coverage.get("diagnostic_alternative_sources", []))},
              "excerpts": len(excerpts), "grouped_display_rows": 0}
    if counts["numeric"]["scored"] != sum(1 for r in rows if r["group"] != "outside"):
        raise ValueError("numeric scored count mismatch")
    source_files = [packet / name for name in ("answer.md", "tokens.json", "annotated.txt", "BLIND_INPUT.json", "mapping.json", "resolved.json",
                                              "claims.jsonl", "coverage.json", "questions.json", "final_review.json")]
    source_files.append(run_root / "reconciliation" / unit["review_unit_id"] / "reconciliation.json")
    source_files.extend(run_root / "public" / name for name in
                        ("RUBRIC.txt", "HUMAN_INTERPRETATIONS.txt", "QUALITY_CHECKS.txt"))
    sources = {str(path.relative_to(run_root)).replace("\\", "/"): sha(path) for path in source_files}
    answer_id = identity["answer_id"]
    doc = {"schema": SCHEMA,
           "evaluation": {"id": run_root.name, "folder": str(run_root), "created_utc": decision.get("completed_utc")},
           "answer": {"answer_id": answer_id, "level": identity["level"], "arm": identity["arm"],
                      "question": identity["question"], "blind_id": unit["blind_id"],
                      "pair_id": unit["review_unit_id"],
                      "gate_mode": {"gated": "Gated", "no_ledger": "Ungated"}.get(identity["arm"], identity["arm"]),
                      "paired_answer_id": None, "paired_folder": None,
                      "folder": (result.parent.relative_to(benchmark_root).as_posix() if benchmark_root
                                 else str(result.parent)), "result_file": "../result.md",
                      "result_sha256": hashlib.sha256(result_bytes).hexdigest(),
                      "evaluated_answer_file": "evaluated_answer.md",
                      "evaluated_answer_sha256": hashlib.sha256(answer).hexdigest(),
                      "token_count": len(rows)},
           "how_to_read": [
               "Each lexical number appears in excerpts; scored archive and pipeline_artifact occurrences have Exact, Near or Miss.",
               "Token positions index evaluated_answer.md and scored positions also index ../result.md.",
               "Misassigned is an overlapping subset, not a fourth outcome.", METHOD_TEXT,
               "Factual claims and coverage use separate denominators; pipeline_artifact values carry hardcoded_artifact source and have a separate category subtotal and count once in combined property totals."],
           "counts": counts,
           "columns": {"values": list(dict.fromkeys(k for r in rows for k in r if k not in ("line", "context_excerpt"))),
                       "factual_claims": list(dict.fromkeys(k for r in claims for k in r)),
                       "coverage": list(coverage)},
           "sources": sources, "display_source": {"status": "PASS", "scope": "one_answer", "adapter_sha256": None},
           "coverage": coverage, "excerpts": excerpts, "factual_claims": claims}
    return doc, answer

def scientific_document(review: dict, result: Path, review_sha: str, root_sha: str | None = None,
                        excerpt_source: Path | None = None) -> dict:
    """One accepted scientific review; root provenance is explicit if supplied."""
    body = result.read_text(encoding="utf-8-sig")
    lines = body.splitlines()
    reviewed_lines = (excerpt_source or result).read_text(encoding="utf-8-sig").splitlines()
    claims = []
    categories = collections.Counter()
    for item in review.get("claims", []):
        line = item["line"]; text = item["text"]
        if (not 1 <= line <= min(len(lines), len(reviewed_lines))
                or lines[line-1].count(text) != 1 or reviewed_lines[line-1].count(text) != 1
                or lines[line-1].index(text) != reviewed_lines[line-1].index(text)):
            raise ValueError("scientific claim excerpt is not aligned with current result")
        col = lines[line-1].index(text) + 1
        category = item["category"]
        if category not in {"database_verified", "domain_knowledge", "incorrect"}:
            raise ValueError("invalid scientific category")
        categories[category] += 1
        claims.append({**item, "status": "resolved", "column": col, "end_column": col + len(text)})
    for item in review.get("unresolved_claims", []):
        line = item["line"]; text = item["text"]
        if (not 1 <= line <= min(len(lines), len(reviewed_lines))
                or lines[line-1].count(text) != 1 or reviewed_lines[line-1].count(text) != 1
                or lines[line-1].index(text) != reviewed_lines[line-1].index(text)):
            raise ValueError("unresolved scientific excerpt is not aligned with current result")
        col = lines[line-1].index(text) + 1
        claims.append({**item, "claim_id": item["unresolved_id"], "status": "unresolved",
                       "column": col, "end_column": col + len(text)})
    provenance = {"source_review_sha256": review_sha}
    if root_sha:
        provenance["root_review_sha256"] = root_sha
    return {"schema": CLAIM_SCHEMA,
            "review": {"schema_version": "claim-verification-1.0", "provenance": provenance},
            "answer": {"answer_id": review["answer_id"], "result_file": "../result.md",
                       "result_sha256": hashlib.sha256(result.read_bytes()).hexdigest()},
            "how_to_read": ["Resolved scientific claims have one category; unresolved empirical assertions have none.",
                            "This scientific layer is independent of numeric Exact/Near/Miss."],
            "counts": {"resolved": sum(categories.values()), "unresolved": len(review.get("unresolved_claims", [])),
                       "by_category": dict(categories)},
            "review_notes": review.get("review_notes", {}), "claims": claims}

def compatibility_receipt_path(run_root: Path, blind_id: str) -> Path | None:
    path = run_root / "private" / "initial_compatibility" / (blind_id + ".json")
    return path if path.is_file() else None

def review_layers(run_root: Path) -> dict:
    path = run_root / "public" / "REVIEW_LAYERS.json"
    if not path.is_file():
        raise ValueError("missing explicit REVIEW_LAYERS.json")
    layers = read(path)
    if not isinstance(layers, dict):
        raise ValueError("REVIEW_LAYERS.json must declare a scientific mode")
    if set(layers) == {"scientific_enabled"} and type(layers["scientific_enabled"]) is bool:
        # Historical run packets remain valid; false is the explicit bypass.
        mode = "fresh" if layers["scientific_enabled"] else "bypass"
    elif set(layers) == {"scientific_mode"} and layers["scientific_mode"] in {"fresh", "bypass"}:
        mode = layers["scientific_mode"]
    else:
        raise ValueError("REVIEW_LAYERS.json must declare scientific_mode fresh/bypass or legacy scientific_enabled boolean")
    return {"scientific_mode": mode, "scientific_enabled": mode == "fresh"}

def validate_instruction_records(run_root: Path, units: list[dict]) -> None:
    folder = run_root / "instructions"
    records = sorted(folder.rglob("INSTRUCTION_RECORD.json")) if folder.is_dir() else []
    for name in ("rendered_system.md", "rendered_task.md", "effective_instruction.md"):
        for rendered_path in folder.rglob(name) if folder.is_dir() else []:
            if not (rendered_path.parent / "INSTRUCTION_RECORD.json").is_file():
                raise ValueError("orphan rendered instruction lacks a role record")
    layers = review_layers(run_root)
    groups = validate_groups(run_root, units)
    roles = ("numerical-reviewer",)
    if layers["scientific_enabled"]:
        roles += ("scientific-reviewer",)
    expected = {(role, unit["blind_id"]) for unit in units for role in roles}
    expected.update(("reconciler", gid) for gid in groups)
    expected.add(("orchestrator", None))
    cached = set()
    for unit in units:
        blind = unit["blind_id"]
        for role in ("numerical-reviewer", "scientific-reviewer"):
            receipt = cache_receipt_path(run_root, role, blind)
            if receipt.is_file():
                if (role, blind) not in expected:
                    raise ValueError("historical cache receipt for disabled or foreign role")
                cached.add((role, blind))
    cache_root = run_root / "private" / "cache_compatibility"
    allowed_receipts = {cache_receipt_path(run_root, role, blind).resolve()
                        for role, blind in cached}
    for path in cache_root.rglob("*.json") if cache_root.is_dir() else []:
        if path.resolve() not in allowed_receipts:
            raise ValueError("foreign or unexpected historical cache receipt")
    if cached:
        root = read(run_root / "results" / "ROOT_ACCEPTANCE.json")
        audits = {row.get("blind_id"): row for row in root.get("unit_audits", [])
                  if isinstance(row, dict)}
        for role, blind in cached:
            packet = run_root / "public" / "maps" / blind
            current_report = (packet / "final_review.json" if role == "numerical-reviewer"
                              else run_root / "scientific" / blind / "review.json")
            current_method = (run_root / "public" / "RUBRIC.txt" if role == "numerical-reviewer"
                              else run_root / "public" / "SCIENTIFIC_METHOD.md")
            validate_cache(run_root, role, blind, packet / "answer.md",
                           current_report, current_method, audits.get(blind))
    actual = set()
    for path in records:
        row = read(path)
        role = row.get("role")
        if role == "orchestrator":
            key = (role, None)
        elif role == "reconciler":
            gid = row.get("group_id")
            key = (role, gid)
            bound = groups.get(gid)
            expected_folder = folder / "reconciler" / str(gid)
            member_levels = ({
                blind: read(run_root / "public" / "maps" / blind / "BLIND_INPUT.json").get("level")
                for blind in bound["member_ids"]
            } if bound is not None else None)
            if (bound is None or path.parent.resolve() != expected_folder.resolve()
                    or "answer_id" in row or row.get("member_ids") != bound["member_ids"]
                    or row.get("member_levels") != member_levels
                    or row.get("group_manifest_sha256") != bound["group_manifest_sha256"]
                    or row.get("member_input_sha256") != bound["member_input_sha256"]):
                raise ValueError("group reconciler instruction identity or inputs changed")
        else:
            key = (role, row.get("answer_id"))
        if key not in expected or key in actual or key in cached:
            raise ValueError("instruction record has duplicate, cached, foreign or unknown role/answer")
        actual.add(key)
        if not isinstance(row.get("input_allowlist"), list):
            raise ValueError("instruction record input allowlist invalid")
        loaded_mode = role == "orchestrator" and row.get("instruction_mode") == "loaded_workflow_files"
        if not loaded_mode and (
                not row.get("model") or not isinstance(row.get("settings"), dict)
                or row.get("transport") in (None, "prepared_not_submitted")
                or row.get("placement") in (None, "pending_dispatch_record")):
            raise ValueError("instruction record lacks actual submitted settings/placement")
        if role != "orchestrator" and row.get("instruction_mode") == "loaded_workflow_files":
            raise ValueError("worker cannot use orchestrator workflow ingestion mode")
        effective = path.parent / "effective_instruction.md"
        system = path.parent / "rendered_system.md"
        task = path.parent / "rendered_task.md"
        if not all(p.is_file() for p in (effective, system, task)):
            raise ValueError("instruction record lacks rendered bytes")
        expected_effective = system.read_bytes() + b"\n" + task.read_bytes()
        if effective.read_bytes() != expected_effective:
            raise ValueError("effective instruction does not compose rendered system and task")
        actual_hashes = {p.name: sha(p) for p in (effective, system, task)}
        if row.get("rendered_sha256") != actual_hashes:
            raise ValueError("rendered instruction hash mismatch")
        if loaded_mode:
            if (row.get("transport") != "loaded_workflow_files"
                    or row.get("placement") != "active_orchestrator_context"
                    or row.get("submitted_effective_sha256") is not None
                    or row.get("model_availability") not in {"known", "unavailable"}
                    or row.get("settings_availability") not in {"known", "unavailable"}
                    or row.get("model") is None or not isinstance(row.get("settings"), dict)):
                raise ValueError("orchestrator ingestion incorrectly claims submission or settings")
            activation = row.get("activation")
            if not isinstance(activation, dict) or not activation.get("loaded_at") or not activation.get("evidence_path"):
                raise ValueError("orchestrator ingestion lacks activation evidence")
            evidence_path = Path(activation["evidence_path"])
            if not evidence_path.is_file() or sha(evidence_path) != activation.get("evidence_sha256"):
                raise ValueError("orchestrator activation evidence missing or changed")
            evidence = read(evidence_path)
            if (evidence.get("kind") not in {"tool_read_record", "explicit_invocation"}
                    or evidence.get("loaded_files_sha256") != actual_hashes):
                raise ValueError("orchestrator activation evidence does not bind loaded files")
        elif row.get("submitted_effective_sha256") != actual_hashes["effective_instruction.md"]:
            raise ValueError("submitted instruction bytes differ from frozen rendered bytes")
    if actual != expected - cached:
        raise ValueError("submitted instruction records or accepted cache receipts do not cover every required role")

def public_hashes(run_root: Path, units: list[dict]) -> dict[str, str]:
    """All public judgments, rules, tools and the root audit frozen before identity keys."""
    paths = [run_root / "public" / name for name in
             ("RUBRIC.txt", "HUMAN_INTERPRETATIONS.txt", "QUALITY_CHECKS.txt",
              "SCREEN_RULES.txt", "REVIEW_LAYERS.json")]
    paths.append(run_root / "public" / "tools" / "screen.py")
    if review_layers(run_root)["scientific_enabled"]:
        paths.append(run_root / "public" / "SCIENTIFIC_METHOD.md")
    paths.append(run_root / "results" / "ROOT_ACCEPTANCE.json")
    groups = validate_groups(run_root, units)
    paths.append(run_root / "reconciliation" / "groups.json")
    for gid in groups:
        manifest = run_root / "groups" / gid / "group.json"
        validate_group(run_root, manifest, require_returns=True)
        paths.extend((manifest, run_root / "groups" / gid / "GROUP_RETURN.json"))
    for unit in units:
        packet = run_root / "public" / "maps" / unit["blind_id"]
        paths.extend((packet / "question.md",
                      run_root / "guidance" / unit["blind_id"] / "GUIDANCE.json"))
        paths.extend(packet / name for name in
                     ("answer.md", "tokens.json", "annotated.txt", "BLIND_INPUT.json", "mapping.json", "resolved.json",
                      "claims.jsonl", "coverage.json", "questions.json", "final_review.json"))
        paths.append(run_root / "reconciliation" / unit["review_unit_id"] / "reconciliation.json")
        paths.append(run_root / "screening" / unit["review_unit_id"] / "SCREENING_CHECK.json")
        paths.append(run_root / "screening" / unit["review_unit_id"] / "CHECK_REQUESTS.json")
        paths.append(run_root / "private" / "packets" / (unit["blind_id"] + ".json"))
        transform_path = run_root / "private" / "transforms" / (unit["blind_id"] + ".json")
        if transform_path.is_file():
            paths.append(transform_path)
        receipt = compatibility_receipt_path(run_root, unit["blind_id"])
        if receipt is not None:
            paths.append(receipt)
        if review_layers(run_root)["scientific_enabled"]:
            science_dir = run_root / "scientific" / unit["blind_id"]
            paths.extend(science_dir / name for name in
                         ("review.json", "accepted_review.json", "ROOT_EVIDENCE.json"))
    result = {path.relative_to(run_root).as_posix(): sha(path) for path in paths}
    for folder in (run_root / "private" / "cache_compatibility",
                   run_root / "private" / "cache_sources"):
        for path in sorted(folder.rglob("*")) if folder.is_dir() else []:
            if path.is_file():
                result["historical_cache/" + path.relative_to(run_root).as_posix()] = sha(path)
    instruction_dir = run_root / "instructions"
    for path in sorted(instruction_dir.rglob("*")) if instruction_dir.is_dir() else []:
        if path.is_file():
            result["run_instruction/" + path.relative_to(instruction_dir).as_posix()] = sha(path)
    for suffix in ("*.py", "*.md"):
        for path in sorted(Path(__file__).parent.glob(suffix)):
            result["package_tool/" + path.name] = sha(path)
    package = Path(__file__).parent.parent
    for folder, label in ((package.parent / "templates", "package_template"),
                          (package / "templates", "package_profile"),
                          (package / "instructions", "package_instruction")):
        for path in sorted(folder.glob("*")):
            if path.is_file():
                result[label + "/" + path.name] = sha(path)
    return dict(sorted(result.items()))

def export(run_root: Path, benchmark_root: Path, out: Path):
    """Validate all public reviews and freeze before opening any private answer key."""
    units = read(run_root / "reconciliation" / "units.json")
    public = read(run_root / "public" / "manifest.json")
    public_ids = [entry["blind_id"] for entry in public]
    unit_ids = [unit["review_unit_id"] for unit in units]
    blind_ids = [unit["blind_id"] for unit in units]
    if (not units or any(set(unit) != {"review_unit_id", "blind_id"} for unit in units)
            or len(unit_ids) != len(set(unit_ids)) or len(blind_ids) != len(set(blind_ids))
            or len(public_ids) != len(set(public_ids)) or set(public_ids) != set(blind_ids)):
        raise ValueError("public answers and singleton reconciliation units are not bijective")
    groups = validate_groups(run_root, units)
    for gid in groups:
        validate_group(run_root, run_root / "groups" / gid / "group.json",
                       require_returns=True)
    rules = run_root / "public"
    for unit in units:
        blind = unit["blind_id"]
        packet = run_root / "public" / "maps" / blind
        decision = read(run_root / "reconciliation" / unit["review_unit_id"] / "reconciliation.json")
        receipt = compatibility_receipt_path(run_root, blind)
        initial = initial_check(packet, blind, rules / "RUBRIC.txt", receipt)
        screen_dir = run_root / "screening" / unit["review_unit_id"]
        final = reconciliation_check(packet, unit, decision, rules / "RUBRIC.txt",
                                     rules / "HUMAN_INTERPRETATIONS.txt", rules / "QUALITY_CHECKS.txt",
                                     screen_dir / "CHECK_REQUESTS.json", screen_dir / "SCREENING_CHECK.json",
                                     rules / "SCREEN_RULES.txt", rules / "tools" / "screen.py")
        if initial["status"] not in {"PASS", "PASS_WITH_QUESTIONS"} or final["status"] != "PASS":
            raise ValueError("one-answer review is not publishable: " + blind + " " + str((initial, final)))
    validate_instruction_records(run_root, units)
    layers = review_layers(run_root)
    if layers["scientific_enabled"]:
        methods = rules / "SCIENTIFIC_METHOD.md"
        for unit in units:
            blind = unit["blind_id"]
            science_dir = run_root / "scientific" / blind
            answer_path = run_root / "public" / "maps" / blind / "answer.md"
            initial_path = science_dir / "review.json"
            accepted_path = science_dir / "accepted_review.json"
            evidence_path = science_dir / "ROOT_EVIDENCE.json"
            cache_path = cache_receipt_path(run_root, "scientific-reviewer", blind)
            if cache_path.is_file():
                old = read(cache_path)
                old_method = (run_root / old["evidence"]["historical_method"]["path"])
                initial_science = scientific_check(science_dir, old["historical_id"], old_method,
                                                   answer_path, initial_path, allow_missing_methods=True)
            else:
                initial_science = scientific_check(science_dir, blind, methods, answer_path, initial_path)
            accepted_science = scientific_check(science_dir, blind, methods, answer_path, accepted_path)
            if initial_science["status"] not in {"PASS", "PASS_WITH_QUESTIONS"} or accepted_science["status"] not in {"PASS", "PASS_WITH_QUESTIONS"}:
                raise ValueError("scientific review invalid before identity join for " + blind)
            evidence = read(evidence_path)
            if (evidence.get("source_review_sha256") != sha(initial_path)
                    or evidence.get("accepted_review_sha256") != sha(accepted_path)
                    or evidence.get("complete_source_and_claims_reviewed") is not True
                    or (cache_path.is_file() and
                        evidence.get("cache_compatibility_receipt_sha256") != sha(cache_path))):
                raise ValueError("scientific root evidence incomplete before identity join for " + blind)
    root_audit = read(run_root / "results" / "ROOT_ACCEPTANCE.json")
    if (root_audit.get("complete") is not True
            or root_audit.get("unresolved_decisions") != 0
            or set(root_audit.get("reviewed_unit_ids", [])) != set(unit_ids)):
        raise ValueError("root evidence audit is incomplete")
    unit_audits = root_audit.get("unit_audits", [])
    if not isinstance(unit_audits, list) or len(unit_audits) != len(units):
        raise ValueError("root evidence audit lacks one record per answer")
    audit_by_id = {row.get("review_unit_id"): row for row in unit_audits if isinstance(row, dict)}
    if len(audit_by_id) != len(units) or set(audit_by_id) != set(unit_ids):
        raise ValueError("root evidence audit unit identities differ")
    for unit in units:
        uid, blind = unit["review_unit_id"], unit["blind_id"]
        audit = audit_by_id[uid]
        decision_path = run_root / "reconciliation" / uid / "reconciliation.json"
        receipt = compatibility_receipt_path(run_root, blind)
        expected_receipt_hash = sha(receipt) if receipt else None
        if audit.get("initial_compatibility_receipt_sha256") != expected_receipt_hash:
            raise ValueError("root audit does not bind initial compatibility receipt for " + uid)
        screen_receipt = run_root / "screening" / uid / "SCREENING_CHECK.json"
        if audit.get("screening_check_sha256") != sha(screen_receipt):
            raise ValueError("root audit does not bind full screening receipt for " + uid)
        if (audit.get("blind_id") != blind or audit.get("decision_sha256") != sha(decision_path)
                or not isinstance(audit.get("source_evidence"), list) or not audit["source_evidence"]
                or any(not isinstance(item, str) or not item for item in audit["source_evidence"])
                or any(audit.get(key) is not True for key in (
                    "claims_checked", "source_constraints_checked", "omissions_checked",
                    "representative_exact_checked"))):
            raise ValueError("root source evidence audit incomplete for " + uid)
    root_audit_by_id = audit_by_id
    frozen = read(run_root / "results" / "JUDGMENT_FREEZE.json")
    hashes = public_hashes(run_root, units)
    if (frozen.get("complete") is not True
            or frozen.get("treatment_keys_not_yet_opened") is not True
            or frozen.get("sha256") != hashes):
        raise ValueError("public judgments, rules or tools are not frozen at current hashes")
    manifest = read(run_root / "private" / "manifest.json")
    by_blind = {m["blind_id"]: m for m in manifest}
    if len(by_blind) != len(manifest) or set(by_blind) != set(blind_ids):
        raise ValueError("private answer identities do not match public blind IDs")
    staged = []
    for unit in units:
        blind = unit["blind_id"]; meta = by_blind[blind]
        packet = run_root / "public" / "maps" / blind
        decision = read(run_root / "reconciliation" / unit["review_unit_id"] / "reconciliation.json")
        result = Path(meta["source_path"]).resolve()
        if benchmark_root.resolve() not in result.parents or result.name != "result.md":
            raise ValueError("source answer escapes benchmark root")
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", meta["answer_id"]):
            raise ValueError("unsafe answer_id for staged output")
        provenance = read(run_root / "private" / "packets" / (blind + ".json"))
        if (provenance.get("answer_id") != blind
                or Path(provenance.get("source_answer_path", "")).resolve() != result
                or provenance.get("source_answer_sha256") != sha(result)
                or provenance.get("packet_answer_sha256") != sha(packet / "answer.md")):
            raise ValueError("full source or packet provenance changed for " + blind)
        validate_packet(packet, blind, run_root / "private" / "packets" / (blind + ".json"))
        document, answer = numeric_document(packet, unit, decision, meta, result, run_root, benchmark_root)
        staged.append((out / meta["answer_id"], document, answer))
    for target, document, answer in staged:
        target.mkdir(parents=True, exist_ok=True)
        (target / "evaluation.json").write_bytes(encoded(document))
        (target / "evaluated_answer.md").write_bytes(answer)
    return {"status": "STAGED", "answers": len(staged), "out": str(out),
            "judgment_freeze_sha256": sha(run_root / "results" / "JUDGMENT_FREEZE.json")}

if __name__ == "__main__":
    arg = argparse.ArgumentParser()
    arg.add_argument("--run-root", type=Path, required=True)
    arg.add_argument("--benchmark-root", type=Path, required=True)
    arg.add_argument("--out", type=Path, required=True)
    args = arg.parse_args()
    print(json.dumps(export(args.run_root, args.benchmark_root, args.out), indent=2))



