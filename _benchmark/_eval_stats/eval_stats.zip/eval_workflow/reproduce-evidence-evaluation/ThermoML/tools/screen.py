"""Screen one initial numerical packet for neutral review leads."""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
import re
from pathlib import Path
from review_contract import claim_rows, initial_check, read

INITIAL_FILES = ("answer.md", "tokens.json", "mapping.json", "resolved.json",
                 "claims.jsonl", "coverage.json", "questions.json", "final_review.json")
REQUEST_ID = "manual_comparison_role_screen_001"
REQUEST_CHECK = (
    "Independently resolve every listed review lead under the same frozen rubric "
    "for this answer. Numerical conditions in a negative statement can still "
    "describe genuine measurements; exclude only absent/search targets rather "
    "than all numbers in negative prose. Preserve actual stored conditions, "
    "separate numeric/source/state outcomes, and verify every manual numerical "
    "override with the stored-reference denominator. A source-only or qualitative "
    "relational claim can legitimately differ from a scalar comparison; explain "
    "its scope. Near needs a quantified numerical comparison, not merely partial "
    "qualitative truth. Shared count excerpts may contain distinct count units; "
    "preserve them. Alternative scopes or incidental archive matches do not "
    "create extra assertions, and fit-selection counts remain outside archive-total "
    "validation unless the answer actually asserts a raw total. Fixed fit-selection "
    "counts are nevertheless pipeline_artifact outputs checked against the solver artifact. "
    "Audit every reported pipeline output and repeat against inspected fixed evidence; "
    "derived exclusions cannot conceal a fit coefficient, metric or prediction. Do not treat "
    "these flags as predetermined errors. Use current QUALITY_CHECKS and binding "
    "human interpretations."
)

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def encoded(value) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8")

def scan_claims(packet: Path, blind_id: str) -> list[dict]:
    """Apply the four screening flags and their precedence to every claim."""
    mapping = read(packet / "mapping.json")
    direct = {item["token_id"] for item in mapping["checks"]}
    resolved = {item["token_id"]: item for item in read(packet / "resolved.json")["rows"]}
    claims = claim_rows(packet / "claims.jsonl")
    count_groups = collections.defaultdict(list)
    for claim in claims:
        if "count" in claim.get("type", "").lower():
            count_groups[(tuple(claim.get("lines", [])), claim.get("quote", ""))].append(claim)
    count_related = {}
    for group in count_groups.values():
        if len(group) > 1 and len({c.get("verdict") for c in group}) > 1:
            for c in group:
                count_related[c["claim_id"]] = [x["claim_id"] for x in group
                                                if x["claim_id"] != c["claim_id"]]
    candidates = []
    for claim in claims:
        if claim.get("blind_id", blind_id) != blind_id or claim.get("answer_id", blind_id) != blind_id:
            raise ValueError("foreign claim identity")
        raw = [x for x in claim.get("token_ids", []) if x in direct]
        verdict = claim.get("verdict")
        cid = claim["claim_id"]
        if not raw and verdict != "near_miss" and cid not in count_related:
            continue
        outcomes = {x: resolved[x].get("category") for x in raw}
        flag = None
        if verdict == "near_miss" and "near_miss" not in outcomes.values():
            flag = "claim_near_without_a_near_resolver_token"
        elif verdict == "exact" and any(v not in ["exact"] for v in outcomes.values()):
            flag = "claim_exact_with_nonexact_resolver_token"
        negative = bool("absence" in claim.get("type", "").lower() or re.search(
            r"\b(?:no|not|never|without|missing|unavailable|absent|lacks?|lacking)\b",
            claim.get("quote", ""), re.I))
        if cid in count_related and not flag:
            flag = "shared_count_excerpt_with_different_roles_or_verdicts"
        if negative and raw and not flag:
            flag = "negative_assertion_with_raw_tokens_review_roles"
        if flag:
            candidates.append({
                "blind_id": blind_id, "claim_id": cid, "flag": flag,
                "claim_type": claim.get("type"), "related_count_claim_ids": count_related.get(cid, []),
                "negative_role_review": negative, "quote": claim.get("quote"),
                "lines": claim.get("lines"), "initial_claim_verdict": verdict,
                "direct_token_resolver_outcomes": outcomes, "reason": claim.get("reason"),
                "evidence": claim.get("evidence"),
                "interpretation": "Review lead only: source-only claims, aggregation, or valid nearby-state comparisons may explain the difference. Independently check arithmetic, scope, polarity and source dimensions; no automatic verdict change. In a negative statement, some numbers may still describe real measurements (for example, no uncertainty for measurements at a stated T); distinguish those from the absent/search target itself."
            })
    return candidates

def requests_for(candidates: list[dict], blind_id: str) -> list[dict]:
    if not candidates:
        return []
    items = [{
        "check_id": blind_id + ":" + c["claim_id"], "blind_id": blind_id,
        "claim_id": c["claim_id"], "quote": c["quote"], "lines": c["lines"],
        "initial_claim_type": c["claim_type"],
        "related_count_claim_ids": c["related_count_claim_ids"],
        "review_lead": c["flag"], "negative_role_review": c["negative_role_review"],
        "direct_token_resolver_outcomes": c["direct_token_resolver_outcomes"],
        "initial_reason": c["reason"],
        "source_ledger": f"public/maps/{blind_id}/claims.jsonl#{c['claim_id']}"
    } for c in candidates]
    return [{"request_id": REQUEST_ID, "kind": "screening_leads_not_verdicts",
             "check": REQUEST_CHECK, "items": items}]

def screen(packet: Path, blind_id: str, review_unit_id: str, rubric: Path,
           quality: Path, rules: Path, out_dir: Path,
           compatibility_receipt: Path | None = None) -> dict:
    for name, value in (("answer-id", blind_id), ("review-unit-id", review_unit_id)):
        if not re.fullmatch(r"[A-Za-z0-9_-]+", value):
            raise ValueError(f"invalid {name}")
    if packet.name != blind_id:
        raise ValueError("packet directory does not match answer-id")
    for path in (rubric, quality, rules):
        if not path.is_file() or not path.read_bytes().strip():
            raise ValueError(f"missing or empty frozen input: {path}")
    checked = initial_check(packet, blind_id, rubric, compatibility_receipt)
    if checked["status"] not in {"PASS", "PASS_WITH_QUESTIONS"} or checked["errors"]:
        raise ValueError("initial review failed: " + json.dumps(checked, sort_keys=True))
    candidates = scan_claims(packet, blind_id)
    requests = requests_for(candidates, blind_id)
    request_bytes = encoded(requests)
    receipt = {
        "blind_id": blind_id, "review_unit_id": review_unit_id, "status": "PASS",
        "complete": True, "initial_check_status": checked["status"],
        "claims_scanned": checked["claims"], "candidate_count": len(candidates),
        "flag_counts": dict(collections.Counter(c["flag"] for c in candidates)),
        "verdicts_modified": False,
        "initial_file_sha256": {name: sha(packet / name) for name in INITIAL_FILES},
        "quality_checks_sha256": sha(quality), "screen_rules_sha256": sha(rules),
        "screen_code_sha256": sha(Path(__file__)),
        "requests_sha256": hashlib.sha256(request_bytes).hexdigest()
    }
    outputs = {out_dir / "CHECK_REQUESTS.json": request_bytes,
               out_dir / "SCREENING_CHECK.json": encoded(receipt)}
    for path, data in outputs.items():
        if path.exists() and path.read_bytes() != data:
            raise FileExistsError(f"immutable screening output differs: {path}")
    out_dir.mkdir(parents=True, exist_ok=True)
    for path, data in outputs.items():
        if not path.exists():
            path.write_bytes(data)
    return receipt

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    for name in ("packet-dir", "answer-id", "review-unit-id", "rubric",
                 "quality", "rules", "out-dir"):
        ap.add_argument("--" + name, required=True)
    ap.add_argument("--compatibility-receipt")
    args = ap.parse_args(argv)
    result = screen(Path(args.packet_dir), args.answer_id, args.review_unit_id,
                    Path(args.rubric), Path(args.quality), Path(args.rules),
                    Path(args.out_dir), Path(args.compatibility_receipt)
                    if args.compatibility_receipt else None)
    print(json.dumps(result, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

