"""H73: verify an existing saved RK curve; no new fit or fabricated native scalar."""
from decimal import Decimal
from pathlib import Path
import math
import numpy as np
from numpy.polynomial import Polynomial as P
from compare_core import compare, convert


def half_last_place(value):
    return float(Decimal(5).scaleb(Decimal(str(value)).as_tuple().exponent-1))


def extremum(coefficients, errors, selection, baseline=None):
    """Uniform input-rounding bound confines every possible true extremizer.

    Each RK term has magnitude <=1/4 on [0,1]. With uniform error E,
    every possible maximizer satisfies nominal(x)>=nominal_max-2E.
    This is a conservative precision envelope, not fitted uncertainty.
    """
    if selection not in {'minimum','maximum'}:raise ValueError('minimum or maximum required')
    if not coefficients or len(coefficients)!=len(errors):raise ValueError('coefficient precision missing')
    x=P([0.,1.]);q=x*(1-x)*sum((float(a)*(2*x-1)**k for k,a in enumerate(coefficients)),P([0.]))
    error=sum(errors)/4.;exponential=False
    if baseline:
        zero,one=baseline['zero'],baseline['one'];ez,eo=baseline['zero_error'],baseline['one_error']
        if baseline['mixing_rule']=='arrhenius':
            if min(zero-ez,one-eo)<=0:raise ValueError('positive pure-reference precision required')
            q+=P([math.log(zero),math.log(one)-math.log(zero)])
            error+=max(abs(math.log((zero-ez)/zero)),abs(math.log((zero+ez)/zero)),abs(math.log((one-eo)/one)),abs(math.log((one+eo)/one)));exponential=True
        elif baseline['mixing_rule']=='linear':q+=P([zero,one-zero]);error+=max(ez,eo)
        else:raise ValueError('unsupported baseline')
    sign=1 if selection=='maximum' else -1;signed=sign*q
    roots=[float(z.real) for z in signed.deriv().roots() if abs(z.imag)<1e-8 and 0<z.real<1]
    position=max([0.,1.]+roots,key=signed);peak=float(signed(position))
    margin=max(1e-14,64*np.finfo(float).eps*sum(abs(float(a)) for a in q.coef));error+=margin
    cuts=sorted(set([0.,1.]+[float(z.real) for z in (signed-P([peak-2*error])).roots() if abs(z.imag)<1e-7 and 0<z.real<1]))
    regions=[(a,b) for a,b in zip(cuts,cuts[1:]) if signed((a+b)/2)>=peak-2*error-margin]
    if not regions:raise ValueError('source-precision localization failed')
    position_interval=[max(0.,min(a for a,b in regions)-1e-9),min(1.,max(b for a,b in regions)+1e-9)]
    value=float(q(position));value_interval=[value-error,value+error]
    if exponential:value=math.exp(value);value_interval=[math.exp(a) for a in value_interval]
    return {'coordinate':position,'value':value,'coordinate_interval':position_interval,'value_interval':value_interval,'uniform_polynomial_error':error,'floating_point_margin':margin,'precision_method':'Half-last-place saved-input bounds; uniform polynomial error; all extrema confined by nominal extremum minus twice that bound. No refitting.'}


def value_at_coordinate(coefficients, errors, coordinate, coordinate_error=0., baseline=None):
    """Evaluate the saved polynomial with bounded input and coordinate precision."""
    if not coefficients or len(coefficients)!=len(errors):raise ValueError('complete coefficient precision required')
    if not 0<=coordinate<=1 or coordinate_error<0:raise ValueError('coordinate outside saved curve domain')
    x=P([0.,1.]);q=x*(1-x)*sum((float(a)*(2*x-1)**k for k,a in enumerate(coefficients)),P([0.]))
    error=sum(errors)/4.;exponential=False
    if baseline:
        zero,one=baseline['zero'],baseline['one'];ez,eo=baseline['zero_error'],baseline['one_error']
        if baseline['mixing_rule']=='arrhenius':
            if min(zero-ez,one-eo)<=0:raise ValueError('positive pure-reference precision required')
            q+=P([math.log(zero),math.log(one)-math.log(zero)])
            error+=max(abs(math.log((zero-ez)/zero)),abs(math.log((zero+ez)/zero)),abs(math.log((one-eo)/one)),abs(math.log((one+eo)/one)));exponential=True
        elif baseline['mixing_rule']=='linear':q+=P([zero,one-zero]);error+=max(ez,eo)
        else:raise ValueError('unsupported baseline')
    margin=max(1e-14,64*np.finfo(float).eps*sum(abs(float(a)) for a in q.coef));error+=margin
    lo=max(0.,coordinate-coordinate_error);hi=min(1.,coordinate+coordinate_error)
    points=[lo,hi]+[float(z.real) for z in q.deriv().roots() if abs(z.imag)<1e-8 and lo<z.real<hi]
    value=float(q(coordinate));bounds=[min(float(q(c)) for c in points)-error,max(float(q(c)) for c in points)+error]
    if exponential:value=math.exp(value);bounds=[math.exp(v) for v in bounds]
    return {'coordinate':coordinate,'value':value,'coordinate_interval':[lo,hi],'value_interval':bounds,'uniform_polynomial_error':error,'floating_point_margin':margin,'precision_method':'Saved polynomial evaluated at stated coordinate; derivative roots bound any coordinate interval; half-last-place coefficient and pure-reference precision propagated. No refitting.'}


def resolve(packet, token, check, ref, row):
    from fitting_precision import compare_fitting, compare_curve_precision, precision_role
    precision_kind=precision_role(check,ref)
    from artifact_source import load,sha,locate,primary_source_entry,artifact_bytes
    from filesystem_paths import io_path
    spec=check['curve_verification'];registry=Path(__file__).resolve().parents[1]/'user-interpretations.json'
    decision=next((d for d in load(registry)['entries'] if d['id']=='H73'),None)
    if not decision or decision.get('status')!='active' or spec.get('decision_id')!='H73' or spec.get('user_reply_exact')!=decision['user_reply_exact']:raise ValueError('confirmed H73 exact reply required')
    answer=(io_path(packet)/'answer.md').read_text(encoding='utf-8-sig')
    if not spec.get('answer_context') or spec['answer_context'] not in answer:raise ValueError('exact saved-curve answer context required')
    for key in ['coordinate_basis','claimed_coordinate_basis','curve_basis','claimed_curve_basis','generation_link_reason']:
        if not spec.get(key):raise ValueError('curve verification lacks '+key)
    plot=spec.get('plot',{});primary_source_entry(packet,plot.get('path',''));data,digest=artifact_bytes(packet,plot['path'])
    if Path(plot['path']).suffix.lower() not in {'.png','.svg','.pdf'} or not all(plot.get(k) for k in ['inspection','x_axis','y_axis']):raise ValueError('saved plot and inspected axes required')
    plot={**plot,'sha256':digest};inputs=spec.get('coefficients',[]);values=[];errors=[];receipts=[]
    for k,item in enumerate(inputs):
        if item.get('path')!=ref['path'] or item.get('key')!='A'+str(k):raise ValueError('ordered A0..An coefficients in same native summary required')
        value,d=locate(packet,item);values.append(float(value));errors.append(half_last_place(value));receipts.append({**item,'stored_value':value,'sha256':d,'half_last_place':str(errors[-1])})
    if not values or inputs[0].get('row')!=ref.get('row') or ref.get('key')!='A0':raise ValueError('native reference must retain actual A0 field')
    order_spec=spec.get('rk_order',{})
    if order_spec.get('path')!=ref['path'] or order_spec.get('key')!='rk_order':raise ValueError('native RK order selector required')
    order,order_hash=locate(packet,order_spec)
    if Decimal(order)!=len(values)-1:raise ValueError('coefficient inventory does not match native RK order')
    order_receipt={**order_spec,'stored_value':order,'sha256':order_hash}
    baseline=None;pure=[]
    if spec.get('curve_quantity')=='property':
        base=spec.get('baseline',{});baseline={'mixing_rule':base.get('mixing_rule')}
        expected_unit='1' if baseline['mixing_rule']=='arrhenius' else spec['value_unit']
        if ref['stored_unit']!=expected_unit:raise ValueError('native coefficient unit does not match saved curve equation')
        for name in ['zero','one']:
            item=base[name];value,d=locate(packet,item);converted=float(convert(value,item['stored_unit'],spec['value_unit']));err=float(convert(str(half_last_place(value)),item['stored_unit'],spec['value_unit'],uncertainty=True))
            baseline[name]=converted;baseline[name+'_error']=err;pure.append({**item,'stored_value':value,'sha256':d,'converted_value':str(converted),'half_last_place_converted':str(err)})
    elif spec.get('curve_quantity')!='excess':raise ValueError('saved excess or property curve required')
    elif ref['stored_unit']!=spec['value_unit']:raise ValueError('coefficient unit and excess curve unit differ')
    point_receipt=None
    if spec.get('evaluation')=='ideal_baseline_at_reported_coordinate':
        if baseline is None or spec.get('output')!='value':raise ValueError('saved property baseline and value output required')
        coordinate_spec=spec.get('coordinate_input',{});tokens_by_id={t['token_id']:t for t in load(Path(packet)/'tokens.json')}
        coordinate=tokens_by_id.get(coordinate_spec.get('token_id'),{})
        if coordinate.get('line')!=token.get('line') or not coordinate:raise ValueError('baseline coordinate must be a bound same-line answer token')
        x=float(coordinate['parsed_value']);dx=float(coordinate['display_tolerance'])
        if not 0<=x<=1:raise ValueError('baseline coordinate outside saved curve domain')
        lo=max(0.,x-dx);hi=min(1.,x+dx)
        def ideal(z,o,c):return math.exp((1-c)*math.log(z)+c*math.log(o)) if baseline['mixing_rule']=='arrhenius' else (1-c)*z+c*o
        value=ideal(baseline['zero'],baseline['one'],x)
        lows=[ideal(baseline['zero']-baseline['zero_error'],baseline['one']-baseline['one_error'],c) for c in [lo,hi]]
        highs=[ideal(baseline['zero']+baseline['zero_error'],baseline['one']+baseline['one_error'],c) for c in [lo,hi]]
        point_receipt={**coordinate_spec,'reported_coordinate':coordinate['parsed_value'],'coordinate_display_tolerance':coordinate['display_tolerance'],'coordinate_interval':[lo,hi]}
        result={'coordinate':x,'value':value,'coordinate_interval':[lo,hi],'value_interval':[min(lows),max(highs)],'precision_method':'Exact saved ideal-baseline equation; monotone endpoint bounds for pure-input last-place precision and reported-coordinate display interval. No refit.'}
    elif spec.get('evaluation')=='saved_curve_at_reported_coordinate':
        if spec.get('output')!='value':raise ValueError('saved curve point requires value output')
        coordinate_spec=spec.get('coordinate_input',{});tokens_by_id={t['token_id']:t for t in load(Path(packet)/'tokens.json')};coordinate=tokens_by_id.get(coordinate_spec.get('token_id'),{})
        if not coordinate or coordinate.get('line')!=token.get('line'):raise ValueError('curve coordinate must be a bound same-line answer token')
        x=float(coordinate['parsed_value']);dx=float(coordinate['display_tolerance']);role=coordinate_spec.get('role','rounded_coordinate')
        if role=='fixed_evaluation_coordinate':
            if not coordinate_spec.get('reason'):raise ValueError('exact evaluation coordinate requires contextual reason')
            dx=0.
        elif role!='rounded_coordinate':raise ValueError('unsupported coordinate precision role')
        if spec.get('coordinate_transform','identity')=='one_minus':x=1-x
        result=value_at_coordinate(values,errors,x,dx,baseline)
        point_receipt={**coordinate_spec,'reported_coordinate':coordinate['parsed_value'],'native_coordinate':x,'coordinate_display_tolerance':coordinate['display_tolerance'],'propagated_coordinate_tolerance':dx,'coordinate_interval':result['coordinate_interval']}
    elif spec.get('evaluation') not in {None,'extremum'}:raise ValueError('unsupported saved-curve evaluation')
    else:result=extremum(values,errors,spec['selection'],baseline)
    output=spec.get('output')
    if output not in {'coordinate','value'}:raise ValueError('coordinate or value output required')
    calculated=result[output];bounds=result[output+'_interval'];unit=('1' if check['unit']=='1' else 'fraction') if output=='coordinate' else spec['value_unit'];transform=spec.get('coordinate_transform','identity')
    if transform not in {'identity','one_minus'}:raise ValueError('unsupported coordinate transformation')
    if transform=='one_minus' and (spec['coordinate_basis']==spec['claimed_coordinate_basis'] or not spec.get('coordinate_transform_reason')):raise ValueError('coordinate reversal requires distinct component bases and source-backed reason')
    if output=='coordinate' and transform=='one_minus':calculated=1-calculated;bounds=[1-bounds[1],1-bounds[0]]
    basis='miss' if transform=='identity' and spec['coordinate_basis']!=spec['claimed_coordinate_basis'] else 'exact'
    if spec['curve_basis']!=spec['claimed_curve_basis']:basis='miss'
    calculated=str(convert(str(calculated),unit,check['unit']));bounds=sorted([str(convert(str(v),unit,check['unit'])) for v in bounds],key=Decimal)
    interval=spec.get('reported_interval')
    if interval:
        tokens={t['token_id']:t for t in load(Path(packet)/'tokens.json')};low=tokens[interval['low_token_id']];high=tokens[interval['high_token_id']]
        if token['token_id'] not in {low['token_id'],high['token_id']} or low['line']!=high['line']:raise ValueError('interval endpoints must be exact same-line answer tokens')
        lo=Decimal(low['parsed_value'])-Decimal(low['display_tolerance']);hi=Decimal(high['parsed_value'])+Decimal(high['display_tolerance'])
        if lo>hi:raise ValueError('reported interval reversed')
        def evaluate(v):
            d=Decimal(v)
            return 'exact' if lo<=d<=hi else compare(str(lo if d<lo else hi),v,'0')['category']
        outcomes=[evaluate(v) for v in bounds+[calculated]];comparison={'absolute_difference':None,'relative_difference':None,'tolerance_used':None,'flags':[],'category':outcomes[0]}
        interval={**interval,'reported_low':low['parsed_value'],'reported_high':high['parsed_value'],'display_expanded_interval':[str(lo),str(hi)]}
    else:
        comparison=compare_curve_precision(token['parsed_value'],calculated,token['display_tolerance'],bounds,precision_kind);outcomes=[comparison['category']]
    if len(set(outcomes))!=1:raise ValueError('source precision crosses verdict boundary; cannot accept calculated extremum at requested precision')
    receipt={**spec,'plot':plot,'coefficients':receipts,'rk_order':order_receipt,'pure_references':pure,'method':(('Saved ideal-baseline equation' if spec.get('evaluation')=='ideal_baseline_at_reported_coordinate' else 'Saved RK curve equation')+' at bound reported coordinate; no new fit' if point_receipt else 'Analytic derivative roots of saved RK polynomial on [0,1], endpoints included; no new fit'),'coordinate_input_receipt':point_receipt,'native_formula':'x*(1-x)*sum(Ak*(2*x-1)**k)','domain':[0,1],'calculated_reference_value':calculated,'calculated_reference_unit':check['unit'],'source_precision_interval':bounds,'precision_check':result,'reported_interval':interval,'registry_sha256':sha(registry),'reference_role':'reviewer_calculated_verification_of_saved_curve_not_native_scalar'}
    ref={**ref,'curve_verification':receipt,'reference_role':'native_coefficient_input_to_saved_curve_verification'}
    return {**row,**comparison,'category':'miss' if basis=='miss' else comparison['category'],'numeric_outcome':comparison['category'],'raw_numeric_outcome':comparison['category'],'unit_outcome':'exact','basis_outcome':basis,'artifact_reference':ref,'curve_verification':receipt,'calculated_reference_value':calculated,'artifact_inspected':True,'stored_value':ref['stored_value'],'stored_unit':ref['stored_unit'],'converted_stored_value':ref['converted_stored_value'],'comparison_value':token['parsed_value'],'n_candidates':1,'reason':'Reviewer-calculated verification of saved curve; native coefficient values unchanged and source-precision interval supports verdict.'}
