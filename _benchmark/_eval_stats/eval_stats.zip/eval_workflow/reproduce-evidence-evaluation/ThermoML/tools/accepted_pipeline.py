"""Final orchestrator pipeline: gated staging, publication, and accepted statistics.

All mutable runtime files live under run_root outside benchmark publication.
The private manifest explicitly selects answers; no corpus discovery is performed.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
from canonical_export import export, encoded, review_layers
from scientific_export import stage_scientific
from review_contract import read, sha
from runtime_location import inside_skill_or_statistics

FILES = {'evaluation.json', 'evaluated_answer.md', 'claim_review.json'}

def _io_path(path: Path) -> Path:
    """Use Windows extended paths only for filesystem operations, never receipts."""
    path = Path(path)
    if os.name != 'nt':
        return path
    if not path.is_absolute():
        raise ValueError('long-path I/O requires an absolute path')
    value = str(path)
    if value.startswith('\\\\?\\'):
        return path
    if value.startswith('\\\\'):
        return Path('\\\\?\\UNC\\' + value[2:])
    return Path('\\\\?\\' + value)

def _canonical_path(path: Path) -> Path:
    """Resolve symlinks with long-path I/O, then return a normal comparison path."""
    value = str(_io_path(path).resolve(strict=True))
    if os.name == 'nt':
        if value.startswith('\\\\?\\UNC\\'):
            value = '\\\\' + value[len('\\\\?\\UNC\\'):]
        elif value.startswith('\\\\?\\'):
            value = value[4:]
    return Path(value)

def runtime_paths(run_root: Path, benchmark_root: Path, stage: Path):
    run_root = run_root.resolve(strict=True)
    benchmark_root = benchmark_root.resolve(strict=True)
    stage = stage.resolve()
    if (run_root.is_relative_to(benchmark_root) or benchmark_root.is_relative_to(run_root)
            or inside_skill_or_statistics(run_root)):
        raise ValueError('runtime and benchmark publication roots must be separate')
    if not stage.is_relative_to(run_root / 'staging'):
        raise ValueError('accepted staging must be inside run_root/staging')
    if stage.exists():
        for child in stage.iterdir():
            if not child.is_dir() or any(x.name not in FILES or not x.is_file() for x in child.iterdir()):
                raise ValueError('unexpected file in accepted staging; use a clean stage directory')
    return run_root, benchmark_root, stage

def stage_accepted(run_root: Path, benchmark_root: Path, stage: Path) -> dict:
    run_root, benchmark_root, stage = runtime_paths(run_root, benchmark_root, stage)
    result = export(run_root, benchmark_root, stage)
    manifest = read(run_root / 'private' / 'manifest.json')
    expected = {m['answer_id'] for m in manifest}
    if len(expected) != len(manifest):
        raise ValueError('canonical answer IDs are not unique')
    if {p.name for p in stage.iterdir()} != expected:
        raise ValueError('staging contains answers outside the explicit manifest')
    science = review_layers(run_root)['scientific_enabled']
    for meta in manifest:
        target = stage / meta['answer_id']
        if science:
            source = run_root / 'scientific' / meta['blind_id']
            stage_scientific(source / 'review.json', source / 'accepted_review.json',
                             Path(meta['source_path']), target / 'claim_review.json',
                             source / 'ROOT_EVIDENCE.json', run_root / 'public' / 'SCIENTIFIC_METHOD.md',
                             target / 'evaluation.json')
        allowed = FILES if science else FILES - {'claim_review.json'}
        if {p.name for p in target.iterdir()} != allowed:
            raise ValueError('staged package file allowlist mismatch')
    from accepted_stats import summarize
    summary = summarize([stage / x for x in sorted(expected)], science, benchmark_root)
    receipt = {'status': 'ACCEPTED_STAGED', 'scientific_enabled': science,
               'judgment_freeze_sha256': result['judgment_freeze_sha256'],
               'root_acceptance_sha256': sha(run_root / 'results' / 'ROOT_ACCEPTANCE.json'),
               'packages': {m['answer_id']: {f.name: sha(f) for f in sorted((stage / m['answer_id']).iterdir())}
                            for m in manifest}}
    (run_root / 'results' / 'ACCEPTED_STAGE_RECEIPT.json').write_bytes(encoded(receipt))
    return {'receipt': receipt, 'summary': summary}

def _selected(manifest: list[dict], selection: dict) -> list[dict]:
    if not isinstance(selection, dict) or set(selection) != {'answer_ids', 'excluded_answer_ids'}:
        raise ValueError('selection must declare answer_ids and excluded_answer_ids')
    selected, excluded = selection['answer_ids'], selection['excluded_answer_ids']
    if (not isinstance(selected, list) or not isinstance(excluded, list)
            or any(not isinstance(x, str) for x in selected + excluded)
            or len(selected) != len(set(selected)) or len(excluded) != len(set(excluded))
            or set(selected) & set(excluded)):
        raise ValueError('invalid or overlapping answer selection')
    known = {m['answer_id'] for m in manifest}
    if not set(selected) <= known:
        raise ValueError('statistics selection contains an unaccepted answer')
    return [m for m in manifest if m['answer_id'] in selected]

PRESERVATION_SCHEMA = 'thermoml-preexisting-artifact-preservation/1'
PRESERVATION_FILE = 'PREEXISTING_ARTIFACT_PRESERVATION.json'

def _preservation(run_root: Path, manifest: list[dict]) -> tuple[dict, str | None]:
    """Root-authorized byte preservation, separate from the scientific review layer."""
    path = run_root / 'private' / PRESERVATION_FILE
    if not path.exists():
        return {}, None
    receipt = read(path)
    if (not isinstance(receipt, dict)
            or set(receipt) != {'schema', 'authorized_by', 'artifacts'}
            or receipt['schema'] != PRESERVATION_SCHEMA
            or receipt['authorized_by'] != 'final_orchestrator'
            or not isinstance(receipt['artifacts'], list)):
        raise ValueError('invalid preexisting artifact preservation receipt')
    known = {m['answer_id'] for m in manifest}
    entries = {}
    for item in receipt['artifacts']:
        if (not isinstance(item, dict)
                or set(item) != {'answer_id', 'source_answer_sha256', 'relative_path', 'sha256'}
                or item.get('answer_id') not in known
                or item.get('answer_id') in entries
                or item.get('relative_path') != 'claim_review.json'
                or not all(isinstance(item.get(k), str) and len(item[k]) == 64
                           and all(c in '0123456789abcdef' for c in item[k])
                           for k in ('source_answer_sha256', 'sha256'))):
            raise ValueError('invalid preexisting artifact preservation entry')
        entries[item['answer_id']] = item
    return entries, sha(path)


SOLVER_PRESERVATION_FILE = 'PREEXISTING_SOLVER_ARTIFACT_PRESERVATION.json'
SOLVER_PRESERVATION_SCHEMA = 'thermoml-preexisting-solver-artifact-preservation/1'

def _solver_preservation(run_root: Path, manifest: list[dict]) -> tuple[dict, str | None]:
    """Explicit hash-bound original solver files; never evaluator caches or inferred files."""
    path = run_root / 'private' / SOLVER_PRESERVATION_FILE
    if not path.exists():
        return {}, None
    receipt = read(path)
    if (not isinstance(receipt, dict) or set(receipt) != {'schema', 'authorized_by', 'artifacts'}
            or receipt['schema'] != SOLVER_PRESERVATION_SCHEMA
            or receipt['authorized_by'] != 'final_orchestrator'
            or not isinstance(receipt['artifacts'], list)):
        raise ValueError('invalid original solver preservation receipt')
    known = {m['answer_id']: m for m in manifest}
    entries = {}
    for item in receipt['artifacts']:
        if (not isinstance(item, dict)
                or set(item) != {'answer_id', 'source_answer_sha256', 'files'}
                or item.get('answer_id') not in known or item['answer_id'] in entries
                or known[item['answer_id']]['level'] not in {'Analysis', 'Main'}
                or not isinstance(item.get('files'), dict) or not item['files']):
            raise ValueError('invalid original solver preservation entry')
        values = [item.get('source_answer_sha256'), *item['files'].values()]
        if any(not isinstance(v, str) or len(v) != 64
               or any(c not in '0123456789abcdef' for c in v) for v in values):
            raise ValueError('invalid original solver preservation hash')
        for relative in item['files']:
            if (not isinstance(relative, str) or not relative or '\\' in relative
                    or ':' in relative or relative.startswith('/')
                    or any(part in {'', '.', '..'} for part in relative.split('/'))):
                raise ValueError('invalid original solver preservation path')
        entries[item['answer_id']] = item
    return entries, sha(path)

def _verify_solver_tree(target: Path, entry: dict, benchmark_root: Path) -> dict:
    base = target / 'artifacts'
    io_base = _io_path(base)
    if not io_base.is_dir() or io_base.is_symlink():
        raise ValueError('preserved solver artifacts directory absent or linked')
    canonical_base = _canonical_path(base)
    if not canonical_base.is_relative_to(benchmark_root):
        raise ValueError('preserved solver artifacts escape benchmark root')
    actual = {}
    expected_dirs = {str(Path(name).parent).replace('\\', '/') for name in entry['files']}
    expected_dirs |= {str(parent).replace('\\', '/') for name in entry['files']
                      for parent in Path(name).parents if str(parent) != '.'}
    for child in io_base.rglob('*'):
        if child.is_symlink() or not _canonical_path(child).is_relative_to(canonical_base):
            raise ValueError('preserved solver artifact is linked or escapes directory')
        relative = child.relative_to(io_base).as_posix()
        if child.is_file():
            actual[relative] = sha(child)
        elif not child.is_dir() or relative not in expected_dirs:
            raise ValueError('unexpected preserved solver directory or file type')
    if actual != entry['files']:
        raise ValueError('preserved solver artifact files or hashes changed')
    return {str((base / name).relative_to(benchmark_root)): digest
            for name, digest in actual.items()}

def publish(run_root: Path, benchmark_root: Path, stage: Path) -> dict:
    built = stage_accepted(run_root, benchmark_root, stage)
    run_root, benchmark_root, stage = runtime_paths(run_root, benchmark_root, stage)
    manifest = read(run_root / 'private' / 'manifest.json')
    preservation, preservation_sha = _preservation(run_root, manifest)
    solver_preservation, solver_preservation_sha = _solver_preservation(run_root, manifest)
    if preservation and review_layers(run_root)['scientific_enabled']:
        raise ValueError('preexisting claim preservation requires scientific bypass')
    copies = []
    preserved = {}
    for meta in manifest:
        source = _canonical_path(Path(meta['source_path']))
        if not source.is_relative_to(benchmark_root) or source.name != 'result.md':
            raise ValueError('publication source escapes benchmark root')
        target = source.parent / 'eval'
        io_target = _io_path(target)
        entry = preservation.get(meta['answer_id'])
        solver_entry = solver_preservation.get(meta['answer_id'])
        if io_target.exists():
            if not io_target.is_dir() or not _canonical_path(target).is_relative_to(benchmark_root):
                raise ValueError('publication target escapes benchmark root')
            existing = list(io_target.iterdir())
            expected_names = ({'claim_review.json'} if entry is not None else set())
            expected_names |= ({'artifacts'} if solver_entry is not None else set())
            if {p.name for p in existing} != expected_names:
                raise ValueError('existing eval lacks exact authorized preservation receipt')
            if entry is not None:
                claim = io_target / 'claim_review.json'
                if (not claim.is_file() or claim.is_symlink()
                        or sha(claim) != entry['sha256']):
                    raise ValueError('existing eval lacks exact authorized preservation receipt')
                if sha(_io_path(source)) != entry['source_answer_sha256']:
                    raise ValueError('preserved claim answer source hash mismatch')
                preserved[str((target / 'claim_review.json').relative_to(benchmark_root))] = entry['sha256']
            if solver_entry is not None:
                if sha(_io_path(source)) != solver_entry['source_answer_sha256']:
                    raise ValueError('preserved solver answer source hash mismatch')
                preserved.update(_verify_solver_tree(target, solver_entry, benchmark_root))
        elif entry is not None or solver_entry is not None:
            raise ValueError('preservation receipt names absent eval directory')
        files = [(f, target / f.name) for f in _io_path(stage / meta['answer_id']).iterdir()]
        if entry is not None and any(f.name == 'claim_review.json' for f, _ in files):
            raise ValueError('staged claim conflicts with preserved claim')
        provenance = read(run_root / 'private' / 'packets' / (meta['blind_id'] + '.json'))
        artifacts = provenance.get('artifact_files', [])
        if artifacts and meta['level'] not in {'Analysis', 'Main'}:
            raise ValueError('support artifacts require Analysis or Main answer')
        for item in artifacts:
            relative = Path(item['path'])
            base = _canonical_path(run_root / 'public' / 'maps' / meta['blind_id'] / 'artifacts')
            if relative.is_absolute() or '..' in relative.parts:
                raise ValueError('support artifact provenance invalid')
            artifact = _canonical_path(base / relative)
            if (not artifact.is_relative_to(base)
                    or item.get('use') != 'pipeline_artifact_and_source_evidence'
                    or sha(_io_path(artifact)) != item['sha256']):
                raise ValueError('support artifact provenance invalid')
            destination = target / 'artifacts' / relative
            saved_digest = (solver_entry or {}).get('files', {}).get(relative.as_posix())
            if saved_digest is not None:
                if saved_digest != item['sha256']:
                    raise ValueError('packet artifact conflicts with preserved original solver file')
                continue
            files.append((artifact, destination))
        copies.extend(files)
    destinations = set()
    for _, dst in copies:
        key = os.path.normcase(str(dst))
        if key in destinations or _io_path(dst).exists():
            raise ValueError('publication destination duplicates or conflicts with existing file')
        destinations.add(key)
    for src, dst in copies:
        io_src, io_dst = _io_path(src), _io_path(dst)
        io_dst.parent.mkdir(parents=True, exist_ok=True)
        with io_dst.open('xb') as stream:
            stream.write(io_src.read_bytes())
        if sha(io_src) != sha(io_dst):
            raise ValueError('published file verification failed')
    for relative, digest in preserved.items():
        if sha(_io_path(benchmark_root / relative)) != digest:
            raise ValueError('preserved artifact changed during publication')
    receipt = {'status': 'PUBLISHED', 'answer_ids': [m['answer_id'] for m in manifest],
               'accepted_stage': built['receipt'],
               'preservation_receipt_sha256': preservation_sha,
               'solver_preservation_receipt_sha256': solver_preservation_sha,
               'preserved_files': preserved,
               'files': {str(dst.relative_to(benchmark_root)): sha(_io_path(dst)) for _, dst in copies}}
    (run_root / 'results' / 'PUBLICATION_RECEIPT.json').write_bytes(encoded(receipt))
    return receipt

def statistics(run_root: Path, benchmark_root: Path, stage: Path, selection: dict) -> dict:
    stage_accepted(run_root, benchmark_root, stage)
    manifest = read(run_root / 'private' / 'manifest.json')
    selected = _selected(manifest, selection)
    from accepted_stats import summarize
    result = summarize([stage / m['answer_id'] for m in selected],
                       review_layers(run_root)['scientific_enabled'], benchmark_root)
    result['selection'] = selection
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['stage', 'publish', 'stats'])
    parser.add_argument('--run-root', type=Path, required=True)
    parser.add_argument('--benchmark-root', type=Path, required=True)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--selection', type=Path)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.command == 'stats':
        if args.selection is None or args.out is None:
            parser.error('stats requires --selection and --out')
        result = statistics(args.run_root, args.benchmark_root, args.stage, read(args.selection))
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_bytes(encoded(result))
        print(json.dumps({'status': 'STATS_WRITTEN', 'out': str(args.out)}, indent=2))
    else:
        result = (publish if args.command == 'publish' else stage_accepted)(args.run_root, args.benchmark_root, args.stage)
        print(json.dumps(result, indent=2))
