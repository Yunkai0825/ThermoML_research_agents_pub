"""Validate user-selected reconciliation mode and worker limits."""
from __future__ import annotations

import json
from pathlib import Path

MODES = {"merged_recon", "indiv_recon"}
STAGES = {"initial", "reconciliation", "scientific"}


def _positive_int(value: object, name: str) -> int:
    if type(value) is not int or value <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return value


def validate_settings(contract: dict) -> dict:
    """Return normalized settings without inventing mode or worker defaults."""
    if not isinstance(contract, dict):
        raise ValueError("run contract must be a JSON object")
    method = contract.get("method")
    execution = contract.get("execution")
    if not isinstance(method, dict) or not isinstance(execution, dict):
        raise ValueError("method and execution objects are required")
    mode = method.get("reconciliation_mode")
    if not isinstance(mode, str) or mode not in MODES:
        raise ValueError("method.reconciliation_mode must be explicitly merged_recon or indiv_recon")
    parallelism = execution.get("parallelism")
    if not isinstance(parallelism, dict):
        raise ValueError("execution.parallelism is required")
    maximum = _positive_int(parallelism.get("max_workers"), "execution.parallelism.max_workers")
    limits = parallelism.get("stage_limits", {})
    if not isinstance(limits, dict) or set(limits) - STAGES:
        raise ValueError("execution.parallelism.stage_limits has unknown stages or is not an object")
    normalized_limits = {}
    for stage, value in limits.items():
        count = _positive_int(value, f"execution.parallelism.stage_limits.{stage}")
        if count > maximum:
            raise ValueError(f"execution.parallelism.stage_limits.{stage} exceeds max_workers")
        normalized_limits[stage] = count
    return {"reconciliation_mode": mode,
            "parallelism": {"max_workers": maximum, "stage_limits": normalized_limits}}


def read_settings(run_root: Path) -> dict:
    path = Path(run_root) / "control" / "RUN_CONTRACT.json"
    if not path.is_file():
        raise ValueError(f"run contract missing: {path}")
    try:
        contract = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"run contract invalid: {path}") from exc
    return validate_settings(contract)
