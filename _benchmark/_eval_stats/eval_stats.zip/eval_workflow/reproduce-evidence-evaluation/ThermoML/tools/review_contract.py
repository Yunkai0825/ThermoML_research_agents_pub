"""Mechanical contracts for one initial review and one independent reconciliation."""
from __future__ import annotations
import collections
from artifact_source import inventory_errors, exclusion_errors
import hashlib
import json
from pathlib import Path
from decimal import Decimal, InvalidOperation

OUTCOMES = {"exact", "near_miss", "miss"}
DECISIONS = OUTCOMES | {"outside", "needs_decision"}
GROUPS = {"measurement_condition", "property_value", "stored_uncertainty", "pipeline_artifact"}
QUANTITY_GROUP = {"property": "property_value", "uncertainty": "stored_uncertainty",
                  "coordinate": "measurement_condition"}
DIMENSIONS = DECISIONS | {"not_applicable"}

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def claim_rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]

def quoted(lines: list[str], quote: str, span) -> bool:
    return (isinstance(span, list) and len(span) == 2 and all(isinstance(n, int) for n in span)
            and 1 <= span[0] <= span[1] <= len(lines) and isinstance(quote, str)
            and bool(quote) and quote in "\n".join(lines[span[0]-1:span[1]]))

def _unique_cover(actual, expected, label, errors):
    if len(actual) != len(set(actual)) or set(actual) != set(expected):
        errors.append(label + " does not cover expected IDs exactly once")

def initial_check(packet: Path, blind_id: str, rubric: Path,
                  compatibility_receipt: Path | None = None) -> dict:
    errors = []
    names = ("answer.md", "tokens.json", "mapping.json", "resolved.json", "claims.jsonl",
             "coverage.json", "questions.json", "final_review.json")
    for name in names:
        if not (packet / name).is_file():
            errors.append("missing " + name)
    if errors:
        return {"blind_id": blind_id, "status": "INCOMPLETE", "errors": errors}
    body = (packet / "answer.md").read_text(encoding="utf-8-sig")
    lines = body.splitlines()
    tokens, mapping, resolved = (read(packet / name) for name in ("tokens.json", "mapping.json", "resolved.json"))
    claims, coverage, questions, final = (claim_rows(packet / "claims.jsonl"), read(packet / "coverage.json"),
                                          read(packet / "questions.json"), read(packet / "final_review.json"))
    tids = [t.get("token_id") for t in tokens]
    if len(tids) != len(set(tids)) or any(t.get("answer_id") != blind_id for t in tokens):
        errors.append("token IDs duplicate or belong to another answer")
    for token in tokens:
        line, col, end = token.get("line"), token.get("column"), token.get("end_column")
        if not isinstance(line, int) or not isinstance(col, int) or not isinstance(end, int):
            errors.append("token position is not integer")
        elif not 1 <= line <= len(lines) or lines[line-1][col-1:end-1] != token.get("text"):
            errors.append("token position mismatch " + str(token.get("token_id")))
    if mapping.get("answer_id") != blind_id or resolved.get("answer_id") != blind_id:
        errors.append("mapping/resolver identity mismatch")
    direct = mapping.get("checks", [])
    exclusions = mapping.get("exclusions", [])
    assigned = [x.get("token_id") for x in direct] + [tid for e in exclusions for tid in e.get("tokens", [])]
    if collections.Counter(assigned) != collections.Counter(tids):
        errors.append("every lexical token must be assigned exactly once")
    rrows = resolved.get("rows", [])
    _unique_cover([r.get("token_id") for r in rrows], tids, "resolver rows", errors)
    if any(r.get("answer_id") != blind_id for r in rrows):
        errors.append("resolver contains foreign answer")
    inputs = resolved.get("input_sha256", {})
    for name in ("mapping.json", "tokens.json"):
        if inputs and inputs.get(name) != sha(packet / name):
            errors.append("resolver input changed: " + name)
    errors.extend(inventory_errors(packet, mapping, rrows))
    errors.extend(exclusion_errors(packet, mapping, claims))
    cids = [c.get("claim_id") for c in claims]
    if len(cids) != len(set(cids)) or not claims:
        errors.append("claims are empty or duplicate")
    owners = {tid for c in claims for tid in c.get("token_ids", [])}
    count_ids = {tid for item in exclusions if item.get("reason") == "count" for tid in item.get("tokens", [])}
    scored_claim_ids = {tid for claim in claims if claim.get("verdict") != "outside" for tid in claim.get("token_ids", [])}
    if count_ids - scored_claim_ids:
        errors.append("count tokens lack scored factual claim")
    if {x.get("token_id") for x in direct} - owners:
        errors.append("direct numeric tokens lack factual claim owner")
    for claim in claims:
        if not quoted(lines, claim.get("quote"), claim.get("lines")):
            errors.append("claim quote/line mismatch " + str(claim.get("claim_id")))
        if set(claim.get("token_ids", [])) - set(tids):
            errors.append("claim has unknown token ID")
        if claim.get("verdict") not in DECISIONS or not claim.get("reason"):
            errors.append("claim lacks valid verdict/reason")
        if claim.get("type") in {"count", "coverage", "absence", "source_attribution", "metadata"} and claim.get("verdict") == "outside":
            errors.append("factual claim excluded")
        if claim.get("verdict") in OUTCOMES and not claim.get("evidence"):
            errors.append("scored claim lacks evidence")
    for key in ("prompt_scope", "search_queries", "inventory", "omissions", "absence_claim_ids",
                "search_complete", "limitations"):
        if key not in coverage:
            errors.append("coverage missing " + key)
    if coverage.get("search_complete") is not True:
        errors.append("coverage search incomplete")
    if set(coverage.get("absence_claim_ids", [])) - set(cids):
        errors.append("coverage cites missing absence claim")
    if not isinstance(questions, list):
        errors.append("questions must be a list")
    if final.get("blind_id") != blind_id or final.get("answer_sha256") != sha(packet / "answer.md"):
        errors.append("final answer identity/hash mismatch")
    current_rubric_hash = sha(rubric)
    if final.get("rubric_sha256") != current_rubric_hash:
        if compatibility_receipt is None or not compatibility_receipt.is_file():
            errors.append("rubric hash mismatch without compatibility receipt")
        else:
            receipt = read(compatibility_receipt)
            names_bound = ("answer.md", "tokens.json", "mapping.json", "resolved.json",
                           "claims.jsonl", "coverage.json", "questions.json", "final_review.json")
            expected_hashes = {name: sha(packet / name) for name in names_bound}
            if (receipt.get("blind_id") != blind_id
                    or receipt.get("answer_sha256") != expected_hashes["answer.md"]
                    or receipt.get("source_rubric_sha256") != final.get("rubric_sha256")
                    or receipt.get("current_rubric_sha256") != current_rubric_hash
                    or receipt.get("initial_file_sha256") != expected_hashes
                    or receipt.get("semantic_scope") != "initial_only"
                    or receipt.get("method_sections") != list("ABCDEFG")
                    or receipt.get("root_reviewed") is not True
                    or not isinstance(receipt.get("semantic_equivalence_evidence"), list)
                    or not receipt["semantic_equivalence_evidence"]):
                errors.append("initial compatibility receipt invalid or stale")
    elif compatibility_receipt is not None:
        errors.append("unexpected initial compatibility receipt for current rubric")
    for key in ("complete", "pipeline_artifacts_inspected", "all_pipeline_outputs_inventoried", "all_claims_read", "all_numeric_tokens_assigned",
                "all_count_and_absence_claims_checked", "coverage_search_completed", "numeric_resolver_run"):
        if final.get(key) is not True:
            errors.append("final review missing " + key)
    status = "FAIL" if errors else ("PASS_WITH_QUESTIONS" if questions or
            any(c.get("verdict") == "needs_decision" for c in claims) else "PASS")
    return {"blind_id": blind_id, "status": status, "errors": errors,
            "numeric_tokens": len(tokens), "direct_checks": len(direct), "claims": len(claims),
            "question_count": len(questions) if isinstance(questions, list) else None,
            "answer_sha256": sha(packet / "answer.md"), "rubric_sha256": sha(rubric)}

def _peak_band_errors(row: dict, token_by_id: dict[str, dict]) -> list[str]:
    """Whole-band containment, using the lexical endpoint display tolerances."""
    errors = []
    band = row.get("band_check")
    ids = band.get("token_ids") if isinstance(band, dict) else None
    if not row.get("band_id") or not isinstance(ids, list) or len(ids) != 2 or len(set(ids)) != 2:
        return ["peak band requires one ID and two distinct endpoint token IDs"]
    if row.get("token_id") not in ids or any(tid not in token_by_id for tid in ids):
        errors.append("peak band references unknown or foreign endpoint")
        return errors
    if token_by_id[ids[0]]["line"] != token_by_id[ids[1]]["line"]:
        errors.append("peak band endpoints are on different lines")
    for key in ("source_refs", "raw_evidence", "role_note", "measured_peak_coordinates"):
        if not band.get(key):
            errors.append("peak band lacks " + key)
    if not isinstance(band.get("contained"), bool) or band.get("interval_outcome") not in {"exact", "miss"}:
        errors.append("peak band lacks containment decision")
    if errors:
        return errors
    names = ("nominal_lower", "nominal_upper", "lower_display_tolerance",
             "upper_display_tolerance", "effective_lower", "effective_upper")
    try:
        lo, hi, lt, ht, elo, ehi = [Decimal(str(band[name])) for name in names]
        measured = [Decimal(str(x)) for x in band["measured_peak_coordinates"]]
        if not all(v.is_finite() for v in (lo, hi, lt, ht, elo, ehi, *measured)):
            raise InvalidOperation("nonfinite peak coordinate")
        if lo != Decimal(str(token_by_id[ids[0]]["parsed_value"])) or hi != Decimal(str(token_by_id[ids[1]]["parsed_value"])):
            errors.append("peak band nominal endpoints differ from lexical tokens")
        if lt != Decimal(str(token_by_id[ids[0]]["display_tolerance"])) or ht != Decimal(str(token_by_id[ids[1]]["display_tolerance"])):
            errors.append("peak band display tolerances differ from tokens")
        if lo > hi or lt < 0 or ht < 0 or elo != lo - lt or ehi != hi + ht:
            errors.append("peak band effective bounds invalid")
        expected = band.get("peak_exists", True) and all(elo <= x <= ehi for x in measured)
        if band["contained"] != expected or band["interval_outcome"] != ("exact" if expected else "miss"):
            errors.append("peak band containment/outcome mismatch")
        if row.get("numeric_outcome") != band["interval_outcome"]:
            errors.append("numeric dimension differs from peak band")
    except (KeyError, InvalidOperation, ValueError, TypeError):
        errors.append("peak band has invalid Decimal evidence")
    return errors
def _raw_reference_complete(ref) -> bool:
    if not isinstance(ref, dict):
        return False
    locator = bool(ref.get("doi") or ref.get("DOI")) and ref.get("block") is not None
    locator = locator and (ref.get("point") is not None or ref.get("constraint") is not None)
    value = bool(ref.get("raw_field") or ref.get("source_field"))
    value = value and ref.get("stored_value") is not None and bool(ref.get("stored_unit"))
    value = value and ref.get("converted_stored_value") is not None and bool(ref.get("claimed_unit"))
    return locator and value
def _missing_reference_valid(row) -> bool:
    """An explicit completed negative search supports an evidence-gap Miss only."""
    ref = row.get("missing_reference")
    if not isinstance(ref, dict) or set(ref) != {"status", "search_boundary", "evidence", "reason"}:
        return False
    if ref.get("status") != "not_found":
        return False
    if any(not isinstance(ref.get(k), str) or not ref[k].strip() for k in ("search_boundary", "reason")):
        return False
    evidence = ref.get("evidence")
    if not isinstance(evidence, list) or not evidence or any(not isinstance(x, str) or not x.strip() for x in evidence):
        return False
    return (row.get("group") in GROUPS and row.get("outcome") == "miss"
            and row.get("numeric_outcome") == "miss" and row.get("source_outcome") == "miss"
            and row.get("condition_outcome") in {"miss", "not_applicable"}
            and row.get("misassigned") is False and row.get("reason_code") == "evidence_gap"
            and row.get("source_kind") == "thermoml_archive"
            and all(isinstance(row.get(k), str) and row[k].strip() for k in ("property", "claimed_unit"))
            and "corrected_reference" not in row and "corrected_quantity_kind" not in row
            and row.get("comparison_kind") is None)

def reconciliation_check(packet: Path, unit: dict, decision: dict, rubric: Path,
                         interpretations: Path, quality: Path, requests: Path,
                         screening_check: Path, screen_rules: Path, screen_code: Path) -> dict:
    """Validate one final decision against its immutable initial packet."""
    blind, uid = unit["blind_id"], unit["review_unit_id"]
    errors = []
    if set(unit) != {"blind_id", "review_unit_id"}:
        errors.append("unit has more than one answer input")
    if decision.get("blind_id") != blind or decision.get("review_unit_id") != uid:
        errors.append("reconciliation identity mismatch")
    if any(key in decision for key in ("answers", "paired_answer_id", "paired_folder")):
        errors.append("multi-answer input forbidden")
    for key, path in (("rubric_sha256", rubric), ("human_interpretations_sha256", interpretations),
                      ("quality_checks_sha256", quality)):
        if decision.get(key) != sha(path):
            errors.append("instruction hash mismatch " + key)
    if decision.get("initial_review_sha256") != sha(packet / "final_review.json"):
        errors.append("initial review changed")
    if not all(path.is_file() for path in (requests, screening_check, screen_rules, screen_code)):
        errors.append("mandatory full screening files missing")
        return {"review_unit_id": uid, "blind_id": blind, "status": "FAIL", "errors": errors}
    if decision.get("requests_sha256") != sha(requests):
        errors.append("screening requests changed")
    screen = read(screening_check)
    initial_names = ("answer.md", "tokens.json", "mapping.json", "resolved.json",
                     "claims.jsonl", "coverage.json", "questions.json", "final_review.json")
    expected_initial_hashes = {name: sha(packet / name) for name in initial_names}
    if (screen.get("blind_id") != blind or screen.get("review_unit_id") != uid
            or screen.get("status") != "PASS" or screen.get("complete") is not True
            or screen.get("initial_file_sha256") != expected_initial_hashes
            or screen.get("quality_checks_sha256") != sha(quality)
            or screen.get("screen_rules_sha256") != sha(screen_rules)
            or screen.get("screen_code_sha256") != sha(screen_code)
            or screen.get("requests_sha256") != sha(requests)):
        errors.append("full screening receipt invalid or stale")
    claims = claim_rows(packet / "claims.jsonl")
    mapping, tokens = read(packet / "mapping.json"), read(packet / "tokens.json")
    body = (packet / "answer.md").read_text(encoding="utf-8-sig").splitlines()
    errors.extend(exclusion_errors(packet, mapping, claims))
    initial_claims = [c["claim_id"] for c in claims]
    initial_types = {c["claim_id"]: c.get("type") for c in claims}
    direct_ids = {c["token_id"] for c in mapping["checks"]}
    direct_by_id = {c["token_id"]: c for c in mapping["checks"]}
    token_ids = {t["token_id"] for t in tokens}
    token_by_id = {t["token_id"]: t for t in tokens}
    final_claims = decision.get("claim_decisions", [])
    final_numeric = decision.get("numeric_results", [])
    errors.extend(inventory_errors(packet, mapping, final_numeric, final=True))
    _unique_cover([c.get("claim_id") for c in final_claims], initial_claims, "claim decisions", errors)
    nums = [n.get("token_id") for n in final_numeric]
    if len(nums) != len(set(nums)) or not direct_ids.issubset(nums) or not set(nums).issubset(token_ids):
        errors.append("numeric decisions omit, duplicate or invent tokens")
    if decision.get("cross_answer_comparisons") != []:
        errors.append("cross-answer comparisons forbidden")
    omission = decision.get("omission_result")
    if not isinstance(omission, dict) or omission.get("blind_id") != blind:
        errors.append("one omission result for assigned answer required")
    elif not all(k in omission for k in ("relevant_items", "present_items", "omitted_items")):
        errors.append("omission fields missing")
    for claim in final_claims:
        if claim.get("blind_id") != blind or claim.get("final_verdict") not in DECISIONS:
            errors.append("foreign or invalid claim decision")
        final_type = claim.get("final_type", initial_types.get(claim.get("claim_id")))
        if final_type != initial_types.get(claim.get("claim_id")) and not claim.get("scope_reclassification_reason"):
            errors.append("changed factual type lacks scope reason")
        if final_type in {"count", "absence"} and claim.get("final_verdict") == "near_miss":
            errors.append("integer count/absence cannot be Near")
        if final_type in {"count", "coverage", "absence", "source_attribution", "metadata"} and claim.get("final_verdict") == "outside":
            errors.append("factual claim incorrectly excluded")
        if claim.get("action") not in {"accept", "revise", "needs_decision"}:
            errors.append("claim action missing")
        if not claim.get("reason") or not claim.get("evidence"):
            errors.append("claim reason/evidence missing")
        if "final_quote" in claim or "final_lines" in claim:
            if not quoted(body, claim.get("final_quote"), claim.get("final_lines")):
                errors.append("corrected claim excerpt invalid")
    for row in final_numeric:
        if row.get("blind_id") != blind or row.get("group") not in GROUPS | {"outside"} or row.get("outcome") not in DECISIONS:
            errors.append("foreign or invalid numeric decision")
        if (row.get("group") == "outside") != (row.get("outcome") == "outside"):
            errors.append("outside group/outcome mismatch")
        source_check = direct_by_id.get(row.get("token_id"), {})
        quantity = source_check.get("quantity")
        original_kind = quantity.get("kind") if isinstance(quantity, dict) else None
        expected_group = "pipeline_artifact" if source_check.get("source_kind") == "hardcoded_artifact" else QUANTITY_GROUP.get(original_kind)
        if expected_group and row.get("group") in GROUPS and row.get("group") != expected_group:
            corrected_kind = row.get("corrected_quantity_kind")
            reclassification_evidence = row.get("scope_reclassification_evidence")
            if (corrected_kind not in QUANTITY_GROUP or corrected_kind == original_kind
                    or row.get("group") != QUANTITY_GROUP.get(corrected_kind)
                    or not isinstance(row.get("scope_reclassification_reason"), str)
                    or not row["scope_reclassification_reason"].strip()
                    or not isinstance(reclassification_evidence, list) or not reclassification_evidence
                    or any(not isinstance(item, str) or not item.strip() for item in reclassification_evidence)
                    or not _raw_reference_complete(row.get("corrected_reference"))):
                errors.append("numeric group conflicts with mapping quantity.kind without supported reclassification")
        elif row.get("corrected_quantity_kind") is not None:
            errors.append("unexpected corrected quantity kind without numeric group change")
        dims = [row.get(key) for key in ("numeric_outcome", "condition_outcome", "source_outcome")]
        if any(v not in DIMENSIONS for v in dims):
            errors.append("missing or invalid numeric dimension")
        if row.get("outcome") == "exact" and any(v != "exact" and v != "not_applicable" for v in dims):
            errors.append("overall Exact conceals failed dimension")
        if row.get("outcome") == "near_miss" and (any(v in {"miss", "needs_decision", "outside"} for v in dims)
                or "near_miss" not in dims):
            errors.append("overall Near inconsistent with dimensions")
        if any(v == "miss" for v in dims) and row.get("outcome") not in {"miss", "outside", "needs_decision"}:
            errors.append("dimension Miss lost")
        if any(v == "needs_decision" for v in dims) and row.get("outcome") != "needs_decision":
            errors.append("pending dimension concealed by resolved outcome")
        if not isinstance(row.get("misassigned"), bool):
            errors.append("misassigned requires boolean")
        if row.get("misassigned") is True and row.get("outcome") == "exact":
            errors.append("misassigned Exact is inconsistent")
        if not row.get("reason") or not row.get("evidence"):
            errors.append("numeric reason/evidence missing")
        if row.get("source_kind", "thermoml_archive") not in {"thermoml_archive", "hardcoded_artifact"} and row.get("group") != "outside":
            errors.append("scored value has unsupported evidence source")
        if row.get("source_kind") == "hardcoded_artifact" and (row.get("classification") != "pipeline_artifact" or row.get("group") != "pipeline_artifact"):
            errors.append("artifact must retain pipeline_artifact classification and first-class pipeline_artifact group")
        if row.get("comparison_kind") not in (None, "peak_interval_containment"):
            errors.append("unknown comparison kind")
        if row.get("comparison_kind") == "peak_interval_containment":
            errors.extend(_peak_band_errors(row, token_by_id))
        if "raw_reference" in row:
            errors.append("unsupported raw_reference; use corrected_reference")
        if "corrected_reference" in row and not _raw_reference_complete(row["corrected_reference"]):
            errors.append("corrected raw reference lacks source/value fields")
        missing_valid = _missing_reference_valid(row)
        if "missing_reference" in row and not missing_valid and row.get("source_kind") != "hardcoded_artifact":
            errors.append("invalid missing-reference evidence-gap decision")
        if row.get("token_id") not in direct_ids and not row.get("corrected_reference") and not missing_valid:
            errors.append("recovered token lacks corrected raw reference or explicit evidence-gap search")
    bands = {}
    for row in final_numeric:
        if row.get("comparison_kind") == "peak_interval_containment":
            bands.setdefault(row.get("band_id"), []).append(row)
    for band_id, rows in bands.items():
        if len(rows) != 2 or {r.get("token_id") for r in rows} != set(rows[0].get("band_check", {}).get("token_ids", [])):
            errors.append("peak band must have exactly both endpoint decisions")
            continue
        if any(r.get("band_check") != rows[0].get("band_check") or
               r.get("numeric_outcome") != rows[0].get("numeric_outcome") for r in rows[1:]):
            errors.append("peak band endpoints have inconsistent evidence or outcome")
    added = decision.get("added_claims", [])
    added_ids = []
    for claim in added:
        added_ids.append(claim.get("claim_id"))
        if claim.get("blind_id") != blind or not quoted(body, claim.get("quote"), claim.get("lines")):
            errors.append("added claim identity/quote invalid")
        if claim.get("type") in {"count", "absence"} and claim.get("final_verdict") == "near_miss":
            errors.append("added integer count/absence cannot be Near")
        if claim.get("type") in {"count", "coverage", "absence", "source_attribution", "metadata"} and claim.get("final_verdict") == "outside":
            errors.append("added factual claim incorrectly excluded")
        if claim.get("final_verdict") not in DECISIONS or not claim.get("reason") or not claim.get("evidence"):
            errors.append("added claim verdict/evidence invalid")
    if len(added_ids) != len(set(added_ids)) or set(added_ids) & set(initial_claims):
        errors.append("added claim IDs duplicate initial claims")
    questions = decision.get("unresolved_questions")
    if not isinstance(questions, list):
        errors.append("unresolved_questions must be list")
        questions = []
    pending_refs = {blind + ":" + c.get("claim_id") for c in final_claims + added
                    if c.get("final_verdict") == "needs_decision" and c.get("claim_id")}
    pending_refs.update(blind + ":" + n.get("token_id") for n in final_numeric
                        if n.get("outcome") == "needs_decision" and n.get("token_id"))
    linked_refs = set()
    for question in questions:
        refs = question.get("decision_refs", []) if isinstance(question, dict) else None
        if not isinstance(refs, list) or any(not isinstance(ref, str) for ref in refs):
            errors.append("unresolved question decision_refs invalid")
        else:
            linked_refs.update(refs)
    if pending_refs and not questions:
        errors.append("pending decision lacks question")
    if pending_refs - linked_refs:
        errors.append("pending decision lacks linked question reference")
    known_refs = {blind + ":" + x for x in (set(initial_claims) | set(nums) | set(added_ids)) if x}
    if linked_refs - known_refs:
        errors.append("unresolved question cites foreign/unknown decision")
    initial_questions = read(packet / "questions.json")
    if not isinstance(initial_questions, list):
        errors.append("initial questions must be list")
        initial_questions = []
    responses = decision.get("initial_question_responses", [])
    if not isinstance(responses, list) or len(responses) != len(initial_questions):
        errors.append("initial questions not answered exactly once")
    else:
        indices = [r.get("question_index") for r in responses]
        if set(indices) != set(range(1, len(initial_questions) + 1)) or len(indices) != len(set(indices)):
            errors.append("initial question response indices invalid")
        for response in responses:
            if response.get("status") not in {"resolved", "needs_decision"} or not response.get("reason") or not response.get("evidence"):
                errors.append("initial question response lacks status/reason/evidence")
            if response.get("status") == "needs_decision" and not any(
                    q.get("initial_question_index") == response.get("question_index") for q in questions if isinstance(q, dict)):
                errors.append("pending initial question lacks linked unresolved question")
    leads = read(requests)
    if not isinstance(leads, list):
        errors.append("screening requests must be a list")
    else:
        expected = [lead.get("request_id") for lead in leads]
        responses = decision.get("check_responses", [])
        actual = [response.get("request_id") for response in responses]
        if len(expected) != len(set(expected)) or len(actual) != len(set(actual)) or set(expected) != set(actual):
            errors.append("screening leads not answered exactly once")
        by_request = {lead["request_id"]: lead for lead in leads if lead.get("request_id")}
        valid_refs = {blind + ":" + x for x in (set(initial_claims) | set(nums) | set(added_ids)) if x}
        for response in responses:
            rid = response.get("request_id")
            if response.get("status") not in {"resolved", "needs_decision"} or not response.get("reason") or not response.get("evidence"):
                errors.append("screening response lacks status/reason/evidence")
            required_items = {x.get("check_id") for x in by_request.get(rid, {}).get("items", [])}
            results = response.get("item_results", [])
            item_ids = [item.get("check_id") for item in results]
            if len(item_ids) != len(set(item_ids)) or set(item_ids) != required_items:
                errors.append("screening lead items not answered exactly once")
            for item in results:
                if item.get("status") not in {"resolved", "needs_decision"} or not item.get("reason") or not item.get("evidence"):
                    errors.append("screening item lacks status/reason/evidence")
                if not item.get("decision_refs") or not set(item["decision_refs"]).issubset(valid_refs):
                    errors.append("screening item has foreign/unknown decision reference")
                if item.get("status") == "needs_decision" and not questions:
                    errors.append("screening item pending without question")
            if response.get("status") == "needs_decision" and not questions:
                errors.append("screening response pending without question")
    if decision.get("complete") is not True:
        errors.append("reconciliation incomplete")
    for key in ("all_claims_reviewed", "all_counts_absences_checked", "omitted_items_searched",
                "source_constraints_checked", "pipeline_artifacts_inspected", "all_pipeline_outputs_inventoried", "same_frozen_rules_applied"):
        if decision.get("checks", {}).get(key) is not True:
            errors.append("semantic check missing " + key)
    status = "FAIL" if errors else ("PASS_WITH_QUESTIONS" if questions else "PASS")
    return {"review_unit_id": uid, "blind_id": blind, "status": status, "errors": errors,
            "claim_decisions": len(final_claims), "numeric_results": len(final_numeric),
            "unresolved_questions": len(questions)}

def scientific_check(packet: Path, answer_id: str, methods: Path,
                     answer_path: Path | None = None,
                     review_path: Path | None = None,
                     allow_missing_methods: bool = False) -> dict:
    """Mechanical check for the separate initial scientific reviewer."""
    errors = []
    review_path = review_path or packet / "review.json"
    answer_path = answer_path or packet / "answer.md"
    if not review_path.is_file():
        return {"answer_id": answer_id, "status": "INCOMPLETE", "errors": ["missing review.json"]}
    review = read(review_path)
    source = answer_path.read_text(encoding="utf-8-sig")
    lines = source.splitlines()
    if review.get("answer_id") != answer_id or review.get("source_sha256") != sha(answer_path):
        errors.append("scientific answer identity/hash mismatch")
    if (review.get("methods_sha256") != sha(methods)
            and not (allow_missing_methods and "methods_sha256" not in review)):
        errors.append("scientific methods hash mismatch")
    resolved = review.get("claims", [])
    unresolved = review.get("unresolved_claims", [])
    ids = [c.get("claim_id") for c in resolved] + [c.get("unresolved_id") for c in unresolved]
    if len(ids) != len(set(ids)):
        errors.append("scientific claim IDs duplicate")
    categories = collections.Counter()
    for claim in resolved:
        line, text = claim.get("line"), claim.get("text")
        if not isinstance(line, int) or not 1 <= line <= len(lines) or not isinstance(text, str) or lines[line-1].count(text) != 1:
            errors.append("scientific excerpt is not unique on its line")
        category = claim.get("category")
        if category not in {"database_verified", "domain_knowledge", "incorrect"}:
            errors.append("scientific category invalid")
        else:
            categories[category] += 1
        if claim.get("incorrect") != (category == "incorrect"):
            errors.append("scientific incorrect flag/category mismatch")
        if not claim.get("reason") or not claim.get("evidence"):
            errors.append("scientific evidence missing")
    for claim in unresolved:
        line, text = claim.get("line"), claim.get("text")
        if not isinstance(line, int) or not 1 <= line <= len(lines) or not isinstance(text, str) or lines[line-1].count(text) != 1:
            errors.append("unresolved scientific excerpt is not unique")
        if "category" in claim or "claim_id" in claim or not claim.get("reason") or not claim.get("evidence"):
            errors.append("unresolved scientific assertion has category or lacks evidence")
    if review.get("resolved_claim_count") != len(resolved) or review.get("unresolved_claim_count") != len(unresolved):
        errors.append("scientific claim counts mismatch")
    if {k: int(v) for k, v in review.get("claim_counts", {}).items() if int(v)} != dict(categories):
        errors.append("scientific category counts mismatch")
    scientific_questions = read(packet / "questions.json") if (packet / "questions.json").is_file() else []
    if not isinstance(scientific_questions, list):
        errors.append("scientific questions must be a list")
        scientific_questions = []
    status = "FAIL" if errors else ("PASS_WITH_QUESTIONS" if unresolved or scientific_questions else "PASS")
    return {"answer_id": answer_id, "status": status, "errors": errors,
            "resolved": len(resolved), "unresolved": len(unresolved),
            "review_sha256": sha(review_path)}

def main():
    import argparse
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="kind", required=True)
    initial = sub.add_parser("initial")
    initial.add_argument("--packet-dir", type=Path, required=True)
    initial.add_argument("--answer-id", required=True)
    initial.add_argument("--rubric", type=Path, required=True)
    initial.add_argument("--compatibility-receipt", type=Path)
    scientific = sub.add_parser("scientific")
    scientific.add_argument("--packet-dir", type=Path, required=True)
    scientific.add_argument("--answer-id", required=True)
    scientific.add_argument("--methods", type=Path, required=True)
    recon = sub.add_parser("reconciliation")
    recon.add_argument("--packet-dir", type=Path, required=True)
    recon.add_argument("--unit-json", type=Path, required=True)
    recon.add_argument("--decision-json", type=Path, required=True)
    recon.add_argument("--rubric", type=Path, required=True)
    recon.add_argument("--interpretations", type=Path, required=True)
    recon.add_argument("--quality", type=Path, required=True)
    recon.add_argument("--requests", type=Path, required=True)
    recon.add_argument("--screen-check", type=Path, required=True)
    recon.add_argument("--screen-rules", type=Path, required=True)
    recon.add_argument("--screen-code", type=Path, required=True)
    for command in (initial, scientific, recon):
        command.add_argument("--out", type=Path)
    args = parser.parse_args()
    if args.kind == "initial":
        result = initial_check(args.packet_dir, args.answer_id, args.rubric, args.compatibility_receipt)
    elif args.kind == "scientific":
        result = scientific_check(args.packet_dir, args.answer_id, args.methods)
    else:
        result = reconciliation_check(args.packet_dir, read(args.unit_json), read(args.decision_json),
                                      args.rubric, args.interpretations, args.quality, args.requests,
                                      args.screen_check, args.screen_rules, args.screen_code)
        result["output_sha256"] = sha(args.decision_json)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {"PASS", "PASS_WITH_QUESTIONS"} else 1

if __name__ == "__main__":
    raise SystemExit(main())






