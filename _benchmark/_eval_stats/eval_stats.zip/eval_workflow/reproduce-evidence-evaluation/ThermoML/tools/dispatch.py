"""Gate and launch one prepared reviewer packet through Codex CLI."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from packet import ROLES, GROUP_BINDINGS, GROUP_INPUT_KEYS, GROUP_COMMAND_KEYS, record_submission
from worker_slots import acquire_slot
from sanitize_answer import validate_packet
from canonical_export import review_layers

SCHEMA = "thermoml-dispatch-intent/1"
GATE_SCHEMA = "thermoml-dispatch-gate/1"
DEFAULT_REASONING_EFFORT = "high"
REASONING_EFFORTS = frozenset(("none", "minimal", "low", "medium", "high", "xhigh", "max", "ultra"))
MODEL_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]*(?:/[A-Za-z0-9][A-Za-z0-9._-]*)*")
OUTPUTS = ("DISPATCH_STATUS.json", "dispatch_events.jsonl", "dispatch_stderr.txt",
           "dispatch_final.txt", "submitted_task_text.md")

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def read_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError("expected JSON object: " + str(path))
    return value

def same_path(a, b) -> bool:
    return os.path.normcase(str(Path(a).resolve())) == os.path.normcase(str(Path(b).resolve()))

def settings(write_dirs: list[Path], reasoning_effort: str = DEFAULT_REASONING_EFFORT) -> dict:
    if not isinstance(reasoning_effort, str) or reasoning_effort not in REASONING_EFFORTS:
        raise ValueError("invalid model reasoning effort")
    return {"model_reasoning_effort": reasoning_effort, "approval_mode": "approve-for-me",
            "sandbox": "workspace-write", "ephemeral": True, "skip_git_repo_check": True,
            "json": True, "allowed_write_dirs": [str(p) for p in write_dirs]}

def cli_help(cli: Path) -> None:
    if not cli.is_file():
        raise ValueError("explicit Codex CLI executable does not exist")
    result = subprocess.run([str(cli), "exec", "--help"], capture_output=True,
                            text=True, encoding="utf-8", errors="replace", timeout=20,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                            check=False)
    help_text = result.stdout + result.stderr
    flags = ("--approve-for-me", "--ephemeral", "--skip-git-repo-check", "--json",
             "--model", "--cd", "--add-dir", "--config", "--output-last-message")
    if result.returncode != 0 or any(flag not in help_text for flag in flags):
        raise ValueError("installed Codex CLI does not confirm required exec flags")
    approval_semantics = (r"--approve-for-me\s+Route\s+approval\s+requests\s+through\s+"
                          r"automatic\s+review\s+using\s+the\s+workspace-write\s+sandbox")
    if re.search(approval_semantics, help_text) is None:
        raise ValueError("installed Codex CLI does not confirm approve-for-me workspace-write semantics")

SCREEN_INPUTS = ("answer.md", "tokens.json", "mapping.json", "resolved.json",
                 "claims.jsonl", "coverage.json", "questions.json", "final_review.json")

def frozen_screen(run_root: Path, answer_id: str, review_unit_id: str) -> dict:
    if not review_unit_id or any(c not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-" for c in review_unit_id):
        raise ValueError("invalid scalar review unit ID")
    units = json.loads((run_root / "reconciliation" / "units.json").read_text(encoding="utf-8-sig"))
    if not isinstance(units, list) or units.count({"review_unit_id": review_unit_id, "blind_id": answer_id}) != 1:
        raise ValueError("review unit does not bind exactly this one answer")
    screening_dir = run_root / "screening" / review_unit_id
    check_path = screening_dir / "SCREENING_CHECK.json"
    requests_path = screening_dir / "CHECK_REQUESTS.json"
    check = read_json(check_path)
    requests_bytes = requests_path.read_bytes()
    requests = json.loads(requests_bytes.decode("utf-8-sig"))
    if check.get("blind_id") != answer_id or check.get("review_unit_id") != review_unit_id or check.get("status") != "PASS" or check.get("complete") is not True:
        raise ValueError("reconciliation requires a passing complete screen for this one answer")
    if not isinstance(requests, list) or len(requests) > 1:
        raise ValueError("screen requests must be an array of at most one one-answer request")
    if requests:
        req = requests[0]
        if not isinstance(req, dict) or req.get("request_id") != "manual_comparison_role_screen_001" or req.get("kind") != "screening_leads_not_verdicts" or not isinstance(req.get("check"), str) or not isinstance(req.get("items"), list):
            raise ValueError("screen request shape invalid")
        if req.get("blind_id", answer_id) != answer_id or any(isinstance(item, dict) and item.get("blind_id", answer_id) != answer_id for item in req["items"]):
            raise ValueError("screen request refers to another answer")
    initial_dir = run_root / "public" / "maps" / answer_id
    actual_initial = {name: sha((initial_dir / name).read_bytes()) for name in SCREEN_INPUTS}
    if check.get("initial_file_sha256") != actual_initial:
        raise ValueError("screen receipt is stale against current initial review files")
    expected = {"quality_checks_sha256": run_root / "public" / "QUALITY_CHECKS.txt",
                "screen_rules_sha256": run_root / "public" / "SCREEN_RULES.txt",
                "screen_code_sha256": run_root / "public" / "tools" / "screen.py"}
    for field, path in expected.items():
        if check.get(field) != sha(path.read_bytes()):
            raise ValueError("screen receipt is stale against " + field)
    if check.get("requests_sha256") != sha(requests_bytes):
        raise ValueError("screen receipt requests hash mismatch")
    return {"review_unit_id": review_unit_id, "screen_check_path": str(check_path),
            "screen_check_sha256": sha(check_path.read_bytes()),
            "screen_requests_path": str(requests_path),
            "screen_requests_sha256": sha(requests_bytes)}

def blind_input(run_root: Path, packet_dir: Path, answer_id: str,
                record: dict | None = None, effective: bytes | None = None) -> dict:
    """Validate the one-answer review copy and its private source provenance."""
    private_path = run_root / "private" / "packets" / (answer_id + ".json")
    digests = validate_packet(packet_dir, answer_id, private_path)
    if record is not None:
        bindings = record.get("bindings")
        if not isinstance(bindings, dict) or not same_path(
                bindings.get("ANSWER_PATH", ""), packet_dir / "answer.md"):
            raise ValueError("ANSWER_PATH must bind the sanitized packet answer.md")
        allowed = record.get("input_allowlist")
        if not isinstance(allowed, list) or not allowed or any(
                not isinstance(entry, str) or not entry for entry in allowed):
            raise ValueError("reviewer input allowlist is required")
        provenance = read_json(private_path)
        source = Path(provenance["source_answer_path"]).resolve(strict=True)
        private_root = run_root / "private"
        source_bytes = source.read_bytes()
        if effective is not None:
            prompt = effective.decode("utf-8-sig")
            path_spellings = {
                str(source), str(source).replace("\\", "/"),
                str(private_path), str(private_path).replace("\\", "/"),
            }
            if source_bytes in effective or any(path in prompt for path in path_spellings):
                raise ValueError("rendered reviewer prompt exposes original source or private provenance")
        for entry in allowed:
            candidate = Path(entry).resolve()
            if (source == candidate or source.is_relative_to(candidate)
                    or candidate.is_relative_to(private_root)
                    or private_path == candidate or private_path.is_relative_to(candidate)):
                raise ValueError("input allowlist exposes original source or private provenance")
            if candidate.is_file() and candidate.read_bytes() == source_bytes:
                raise ValueError("input allowlist exposes a copy of the original source")
    return digests

def scientific_role_allowed(run_root: Path, role: str) -> None:
    if role == "scientific-reviewer" and not review_layers(run_root)["scientific_enabled"]:
        raise ValueError("scientific reviewer is disabled in bypass mode")

def prepare_intent(*, run_root: Path, answer_id: str, role: str, packet_dir: Path,
                   instruction_dir: Path, cli: Path, write_dirs: list[Path], model: str,
                   review_unit_id: str | None = None,
                   inspect_cli: bool = True,
                   reasoning_effort: str = DEFAULT_REASONING_EFFORT) -> tuple[dict, bytes]:
    run_root = run_root.resolve(strict=True)
    packet_dir = packet_dir.resolve(strict=True)
    instruction_dir = instruction_dir.resolve(strict=True)
    cli = cli.resolve(strict=True)
    write_dirs = [p.resolve(strict=True) for p in write_dirs]
    if not all(p.is_dir() for p in (run_root, packet_dir, instruction_dir)):
        raise ValueError("run root, packet and instruction directories must exist")
    if not isinstance(model, str) or len(model) > 128 or MODEL_NAME.fullmatch(model) is None:
        raise ValueError("invalid model name")
    if role not in ROLES:
        raise ValueError("unsupported reviewer role")
    if role == "reconciler":
        raise ValueError("reconciliation uses one group adapter for one or more answers; use check-group or run-group")
    scientific_role_allowed(run_root, role)
    runtime_settings = settings(write_dirs, reasoning_effort)
    if (role == "reconciler") != (review_unit_id is not None):
        raise ValueError("review unit ID is required for reconciler only")
    if not answer_id or any(c not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_.-" for c in answer_id):
        raise ValueError("invalid scalar answer ID")
    if not packet_dir.is_relative_to(run_root) or not instruction_dir.is_relative_to(run_root):
        raise ValueError("packet and instruction directory must be inside run root")
    if len(set(map(str, write_dirs))) != len(write_dirs) or packet_dir in write_dirs:
        raise ValueError("write directories must be unique and exclude packet root")
    lookup_dir = run_root / "public" / "tools" / "lookups"
    if any(p != lookup_dir for p in write_dirs):
        raise ValueError("only the run's shared lookup directory may be an extra write root")
    record_path = instruction_dir / "INSTRUCTION_RECORD.json"
    effective_path = instruction_dir / "effective_instruction.md"
    record = read_json(record_path)
    effective = effective_path.read_bytes()
    if record.get("role") != role or record.get("answer_id") != answer_id:
        raise ValueError("prepared role or answer identity mismatch")
    if record.get("model") != model or record.get("settings") != runtime_settings:
        raise ValueError("prepared model or execution settings mismatch")
    if record.get("transport") != "prepared_not_submitted" or record.get("submitted_effective_sha256") is not None:
        raise ValueError("instruction already submitted; fresh process only")
    bindings = record.get("bindings")
    if not isinstance(bindings, dict) or bindings.get("ANSWER_ID") != answer_id or not same_path(bindings.get("PACKET_DIR", ""), packet_dir):
        raise ValueError("instruction binding does not identify this packet")
    rendered = record.get("rendered_sha256")
    if not isinstance(rendered, dict) or rendered.get("effective_instruction.md") != sha(effective):
        raise ValueError("effective instruction hash mismatch")
    for name in ("rendered_system.md", "rendered_task.md"):
        if rendered.get(name) != sha((instruction_dir / name).read_bytes()):
            raise ValueError("rendered instruction component hash mismatch: " + name)
    if effective != (instruction_dir / "rendered_system.md").read_bytes() + b"\n" + (instruction_dir / "rendered_task.md").read_bytes():
        raise ValueError("effective instruction differs from recorded composition")
    templates = record.get("template_sha256")
    if not isinstance(templates, dict) or "common.system.md" not in templates or role + ".system.md" not in templates or role + ".task.md" not in templates or len(templates) != 4:
        raise ValueError("all role and profile system templates must be recorded")
    if any(not isinstance(v, str) or len(v) != 64 for v in templates.values()):
        raise ValueError("invalid template hash record")
    blind = blind_input(run_root, packet_dir, answer_id, record, effective)
    if inspect_cli:
        cli_help(cli)

    argv = [str(cli), "exec", "--approve-for-me",
            "--skip-git-repo-check", "--ephemeral", "--json", "--model", model,
            "-c", f'model_reasoning_effort="{reasoning_effort}"', "--cd", str(packet_dir)]
    for path in write_dirs:
        argv.extend(("--add-dir", str(path)))
    argv.extend(("--output-last-message", str(packet_dir / "dispatch_final.txt"), "-"))
    screen = frozen_screen(run_root, answer_id, review_unit_id) if review_unit_id else None
    if screen and (not same_path(bindings.get("SCREENING_CHECK_PATH", ""), screen["screen_check_path"])
                   or not same_path(bindings.get("CHECK_REQUESTS_PATH", ""), screen["screen_requests_path"])):
        raise ValueError("reconciler instruction screen paths differ from frozen one-answer screen")
    intent = {"schema_version": SCHEMA, "answer_id": answer_id, "role": role,
              "screen": screen, "blind_input": blind,
              "run_root": str(run_root), "packet_dir": str(packet_dir),
              "instruction_dir": str(instruction_dir), "codex_cli": str(cli),
              "codex_cli_sha256": sha(cli.read_bytes()), "model": model,
              "settings": runtime_settings,
              "isolation": {"read": "instruction_only", "write": "workspace_write_packet_plus_explicit_lookup"},
              "effective_instruction_sha256": sha(effective),
              "instruction_record_sha256": sha(record_path.read_bytes()), "command_argv": argv}
    return intent, effective

def prepare_group_intent(*, run_root: Path, group_manifest: Path,
                         instruction_dir: Path, cli: Path, write_dirs: list[Path],
                         model: str, max_workers: int, inspect_cli: bool = True,
                         reasoning_effort: str = DEFAULT_REASONING_EFFORT) -> tuple[dict, bytes]:
    """Prepare the same reconciler dispatch for a group of any positive size."""
    from group_contract import validate_question_authorization
    from run_settings import read_settings
    if isinstance(max_workers, bool) or not isinstance(max_workers, int) or max_workers < 1:
        raise ValueError("max_workers must be a positive integer")
    run_root = run_root.resolve(strict=True)
    selected = read_settings(run_root)
    if max_workers != selected["parallelism"]["max_workers"]:
        raise ValueError("max_workers differs from the accepted run contract")
    group_manifest = group_manifest.resolve(strict=True)
    instruction_dir = instruction_dir.resolve(strict=True)
    cli = cli.resolve(strict=True)
    write_dirs = [p.resolve(strict=True) for p in write_dirs]
    if not isinstance(model, str) or len(model) > 128 or MODEL_NAME.fullmatch(model) is None:
        raise ValueError("invalid model name")
    group = validate_question_authorization(run_root, group_manifest)
    group_id, member_ids = group["group_id"], group["member_ids"]
    if selected["reconciliation_mode"] == "indiv_recon" and len(member_ids) != 1:
        raise ValueError("individual reconciliation mode requires a singleton group")
    expected_manifest = run_root / "groups" / group_id / "group.json"
    if group_manifest != expected_manifest.resolve(strict=True):
        raise ValueError("group manifest is outside its scoped runtime directory")
    work_dir = (run_root / "groups" / group_id / "work").resolve(strict=True)
    if not work_dir.is_dir() or not instruction_dir.is_relative_to(run_root):
        raise ValueError("group work or instruction directory is outside run root")
    lookup_dir = run_root / "public" / "tools" / "lookups"
    if (len(set(map(str, write_dirs))) != len(write_dirs)
            or any(p != lookup_dir for p in write_dirs)):
        raise ValueError("only the run's shared lookup directory may be an extra write root")
    manifest = json.loads(group_manifest.read_text(encoding="utf-8"))
    members = manifest["members"]
    question_exception = manifest.get("question_exception")
    question_exception_id = (question_exception["id"]
                             if question_exception is not None else None)
    group_dir = (run_root / "groups" / group_id).resolve(strict=True)
    decision_dirs = [(run_root / "reconciliation" / member["review_unit_id"]).resolve(strict=True)
                     for member in members]
    group_write_dirs = [group_dir, *decision_dirs, *write_dirs]
    runtime_settings = settings(group_write_dirs, reasoning_effort)
    record_path = instruction_dir / "INSTRUCTION_RECORD.json"
    effective_path = instruction_dir / "effective_instruction.md"
    record = read_json(record_path)
    effective = effective_path.read_bytes()
    if (record.get("role") != "reconciler" or record.get("group_id") != group_id
            or record.get("member_ids") != member_ids
            or record.get("group_manifest_sha256") != group["group_manifest_sha256"]
            or record.get("member_input_sha256") != group["member_input_sha256"]
            or record.get("question_exception_id") != question_exception_id
            or "answer_id" in record):
        raise ValueError("prepared group reconciler identity or inputs mismatch")
    if record.get("model") != model or record.get("settings") != runtime_settings:
        raise ValueError("prepared group model or execution settings mismatch")
    if (record.get("transport") != "prepared_not_submitted"
            or record.get("submitted_effective_sha256") is not None):
        raise ValueError("group instruction already submitted; fresh process only")
    bindings = record.get("bindings")
    if (not isinstance(bindings, dict) or set(bindings) != set(GROUP_BINDINGS)
            or bindings.get("GROUP_ID") != group_id
            or not same_path(bindings.get("GROUP_MANIFEST_PATH", ""), group_manifest)
            or not same_path(bindings.get("RUN_ROOT", ""), run_root)):
        raise ValueError("group instruction binding mismatch")
    commands = record.get("command_argv")
    if (not isinstance(commands, dict) or set(commands) != set(GROUP_COMMAND_KEYS)
            or any(not isinstance(commands[key], list)
                   or not commands[key]
                   or bindings[key] != subprocess.list2cmdline(commands[key])
                   for key in GROUP_COMMAND_KEYS)):
        raise ValueError("group instruction command binding mismatch")
    rendered = record.get("rendered_sha256")
    if not isinstance(rendered, dict) or rendered.get("effective_instruction.md") != sha(effective):
        raise ValueError("effective group instruction hash mismatch")
    for name in ("rendered_system.md", "rendered_task.md"):
        if rendered.get(name) != sha((instruction_dir / name).read_bytes()):
            raise ValueError("rendered group instruction component hash mismatch: " + name)
    if effective != ((instruction_dir / "rendered_system.md").read_bytes() + b"\n"
                     + (instruction_dir / "rendered_task.md").read_bytes()):
        raise ValueError("effective group instruction differs from recorded composition")
    member_levels = {}
    for member in members:
        blind = member["blind_id"]
        receipt = read_json(run_root / "public" / "maps" / blind / "BLIND_INPUT.json")
        level = receipt.get("level")
        if level not in {"Query", "Analysis", "Main"}:
            raise ValueError("unknown answer level for group member " + blind)
        member_levels[blind] = level
    if record.get("member_levels") != member_levels:
        raise ValueError("group member level bindings changed")
    templates = record.get("template_sha256")
    expected_templates = {"reconciler.system.md", "reconciler.task.md"}
    expected_templates.update(level + ".system.md" for level in member_levels.values())
    if (not isinstance(templates, dict)
            or set(templates) != expected_templates
            or not all(isinstance(value, str) and len(value) == 64
                       for value in templates.values())):
        raise ValueError("group reconciler template set does not match member levels")
    allowed = record.get("input_allowlist")
    required_inputs = [bindings[key] for key in GROUP_INPUT_KEYS
                       if bindings[key] != "not applicable"]
    for member in members:
        blind, unit = member["blind_id"], member["review_unit_id"]
        required_inputs.extend((
            str(run_root / "public" / "maps" / blind),
            str(run_root / "guidance" / blind / "GUIDANCE.json"),
            str(run_root / "screening" / unit / "SCREENING_CHECK.json"),
            str(run_root / "screening" / unit / "CHECK_REQUESTS.json")))
    if allowed != list(dict.fromkeys(required_inputs)):
        raise ValueError("group reconciler input allowlist differs from scoped member evidence")
    blind_inputs = {}
    for member in members:
        blind, unit = member["blind_id"], member["review_unit_id"]
        blind_inputs[blind] = blind_input(run_root, run_root / "public" / "maps" / blind, blind)
        for required in (run_root / "public" / "maps" / blind,
                         run_root / "guidance" / blind / "GUIDANCE.json",
                         run_root / "screening" / unit / "SCREENING_CHECK.json",
                         run_root / "screening" / unit / "CHECK_REQUESTS.json"):
            if str(required) not in allowed:
                raise ValueError("group reconciler input allowlist lacks member evidence")
        provenance_path = run_root / "private" / "packets" / (blind + ".json")
        provenance = read_json(provenance_path)
        source = Path(provenance["source_answer_path"]).resolve(strict=True)
        source_bytes = source.read_bytes()
        prompt = effective.decode("utf-8-sig")
        private_names = (str(source), str(source).replace("\\", "/"),
                         str(provenance_path), str(provenance_path).replace("\\", "/"))
        if source_bytes in effective or any(name in prompt for name in private_names):
            raise ValueError("group instruction exposes original source or private provenance")
        for entry in allowed:
            candidate = Path(entry).resolve()
            if (source == candidate or source.is_relative_to(candidate)
                    or candidate.is_relative_to(run_root / "private")
                    or (candidate.is_file() and candidate.read_bytes() == source_bytes)):
                raise ValueError("group input allowlist exposes original or private source")
    if inspect_cli:
        cli_help(cli)
    argv = [str(cli), "exec", "--approve-for-me", "--skip-git-repo-check",
            "--ephemeral", "--json", "--model", model,
            "-c", f'model_reasoning_effort="{reasoning_effort}"',
            "--cd", str(work_dir)]
    for extra in group_write_dirs:
        argv.extend(("--add-dir", str(extra)))
    argv.extend(("--output-last-message", str(work_dir / "dispatch_final.txt"), "-"))
    intent = {"schema_version": SCHEMA, "role": "reconciler",
              "group_id": group_id, "member_ids": member_ids,
              "group_manifest_path": str(group_manifest),
              "group_manifest_sha256": group["group_manifest_sha256"],
              "member_input_sha256": group["member_input_sha256"],
              "question_exception_id": question_exception_id,
              "blind_inputs": blind_inputs,
              "max_workers": max_workers,
              "reconciliation_stage_limit": selected["parallelism"]["stage_limits"].get("reconciliation", max_workers),
              "reconciliation_mode": selected["reconciliation_mode"],
              "run_root": str(run_root),
              "packet_dir": str(work_dir), "instruction_dir": str(instruction_dir),
              "codex_cli": str(cli), "codex_cli_sha256": sha(cli.read_bytes()),
              "model": model, "settings": runtime_settings,
              "isolation": {"read": "instruction_only",
                            "write": "workspace_write_group_and_member_decision_dirs"},
              "effective_instruction_sha256": sha(effective),
              "instruction_record_sha256": sha(record_path.read_bytes()),
              "command_argv": argv}
    return intent, effective

def intent_sha256(intent: dict) -> str:
    return sha(canonical(intent))

def check_gate(gate_path: Path, intent: dict) -> dict:
    run_root = Path(intent["run_root"]).resolve(strict=True)
    scientific_role_allowed(run_root, intent["role"])
    record_path = Path(intent["instruction_dir"]) / "INSTRUCTION_RECORD.json"
    if sha(record_path.read_bytes()) != intent["instruction_record_sha256"]:
        raise ValueError("instruction record changed since dispatch intent preparation")
    effective = (Path(intent["instruction_dir"]) / "effective_instruction.md").read_bytes()
    if sha(effective) != intent["effective_instruction_sha256"]:
        raise ValueError("effective instruction changed since dispatch intent preparation")
    if "group_id" in intent:
        from group_contract import validate_question_authorization
        from run_settings import read_settings
        selected = read_settings(run_root)
        if (selected["parallelism"]["max_workers"] != intent["max_workers"]
                or selected["parallelism"]["stage_limits"].get("reconciliation", intent["max_workers"])
                    != intent["reconciliation_stage_limit"]
                or selected["reconciliation_mode"] != intent["reconciliation_mode"]):
            raise ValueError("group run settings changed since dispatch intent preparation")
        current_group = validate_question_authorization(run_root, Path(intent["group_manifest_path"]))
        manifest = read_json(Path(intent["group_manifest_path"]))
        exception = manifest.get("question_exception")
        if intent.get("question_exception_id") != (
                exception["id"] if exception is not None else None):
            raise ValueError("question exception changed since dispatch intent preparation")
        current_blind_inputs = {
            member["blind_id"]: blind_input(
                run_root, run_root / "public" / "maps" / member["blind_id"],
                member["blind_id"])
            for member in manifest["members"]}
        if current_blind_inputs != intent.get("blind_inputs"):
            raise ValueError("group clean packets changed since dispatch intent preparation")
        if (current_group["group_id"] != intent["group_id"]
                or current_group["member_ids"] != intent["member_ids"]
                or current_group["group_manifest_sha256"] != intent["group_manifest_sha256"]
                or current_group["member_input_sha256"] != intent["member_input_sha256"]):
            raise ValueError("group inputs changed since dispatch intent preparation")
    else:
        current_blind = blind_input(run_root, Path(intent["packet_dir"]).resolve(strict=True),
                                    intent["answer_id"], read_json(record_path), effective)
        if current_blind != intent.get("blind_input"):
            raise ValueError("blind input changed since dispatch intent preparation")
    gate_path = gate_path.resolve(strict=True)
    write_roots = [Path(intent["packet_dir"])]
    allowed_write_dirs = intent.get("settings", {}).get("allowed_write_dirs")
    if not isinstance(allowed_write_dirs, list):
        raise ValueError("dispatch settings lack writable-root declaration")
    write_roots.extend(Path(path) for path in allowed_write_dirs)
    if (not gate_path.is_relative_to(Path(intent["run_root"]))
            or any(gate_path.is_relative_to(root.resolve(strict=True))
                   for root in write_roots)):
        raise ValueError("dispatch gate must be inside run root and outside every writable worker root")
    gate = read_json(gate_path)
    if gate.get("schema_version") != GATE_SCHEMA or gate.get("ready") is not True or gate.get("evaluation_dispatch_allowed") is not True or gate.get("workflow_ready") is not True or gate.get("workflow_accepted") is not True:
        raise ValueError("accepted workflow dispatch gate is not ready")
    scope = gate.get("scope")
    if "group_id" in intent:
        if (scope != "reconciliation_group"
                or gate.get("group_scope") != {
                    "group_id": intent["group_id"], "member_ids": intent["member_ids"]}):
            raise ValueError("group dispatch gate must bind this exact reconciliation group")
    elif scope == "blind_trial":
        if gate.get("trial_scope") != {"answer_id": intent["answer_id"], "role": intent["role"]}:
            raise ValueError("trial scope does not match this one answer and role")
    elif scope == "one_answer":
        if gate.get("answer_scope") != {"answer_id": intent["answer_id"], "role": intent["role"]}:
            raise ValueError("one-answer scope does not match this answer and role")
    else:
        raise ValueError("only an explicit one-answer scope is authorized")
    if gate.get("intent_sha256") != intent_sha256(intent):
        raise ValueError("gate intent hash mismatch: instruction, packet, model, settings or CLI changed")
    return gate

def write_status(path: Path, value: dict) -> None:
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    os.replace(temporary, path)

def launch(intent: dict, effective: bytes, instruction_dir: Path, gate_path: Path) -> dict:
    packet_dir = Path(intent["packet_dir"])
    if any((packet_dir / name).exists() for name in OUTPUTS):
        raise ValueError("dispatch output already exists; no automatic retry or resume")
    check_gate(gate_path, intent)
    stage = {"numerical-reviewer": "initial", "scientific-reviewer": "scientific",
             "reconciler": "reconciliation"}.get(intent["role"])
    if stage is None:
        raise ValueError("unknown worker role for slot accounting")
    with acquire_slot(Path(intent["run_root"]), stage) as lease:
        status_path = packet_dir / "DISPATCH_STATUS.json"
        identity = ({"group_id": intent["group_id"], "member_ids": intent["member_ids"]}
                    if "group_id" in intent else {"answer_id": intent["answer_id"]})
        status = {"schema_version": "thermoml-dispatch-status/1", **identity,
                  "role": intent["role"], "state": "starting",
                  "started_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                  "intent_sha256": intent_sha256(intent),
                  "gate_path": str(gate_path.resolve()), "gate_sha256": sha(gate_path.read_bytes()),
                  "command_argv": intent["command_argv"], "settings": intent["settings"],
                  "isolation": intent["isolation"], "lease_id": lease.lease_id,
                  "actual_task_text_path": str(packet_dir / "submitted_task_text.md"),
                  "actual_task_text_sha256": sha(effective), "pid": None, "exit_code": None}
        with status_path.open("x", encoding="utf-8") as stream:
            json.dump(status, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
        with (packet_dir / "submitted_task_text.md").open("xb") as stream:
            stream.write(effective)
        env = os.environ.copy()
        env["PYTHONUTF8"] = "1"
        proc = None
        try:
            with (packet_dir / "dispatch_events.jsonl").open("xb") as out, (packet_dir / "dispatch_stderr.txt").open("xb") as err:
                proc = subprocess.Popen(intent["command_argv"], stdin=subprocess.PIPE,
                                        stdout=out, stderr=err, cwd=str(packet_dir), env=env,
                                        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                status.update(state="running", pid=proc.pid)
                try:
                    lease.mark_pid(proc.pid)
                except Exception:
                    proc.communicate(input=effective)
                    raise
                write_status(status_path, status)
                proc.communicate(input=effective)
                status.update(state="process_completed" if proc.returncode == 0 else "process_failed",
                              exit_code=proc.returncode)
                record_submission(instruction_dir, effective, "codex_exec_stdin_prompt",
                                  "subprocess_stdin_exact_bytes")
        except Exception as exc:
            if proc is not None and proc.poll() is None:
                try:
                    proc.terminate()
                    try:
                        proc.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.wait(timeout=10)
                except Exception as stop_exc:
                    lease.retain()
                    status["lease_retained"] = True
                    status["stop_error"] = f"{type(stop_exc).__name__}: {stop_exc}"
            status.update(state="launcher_failed", error=f"{type(exc).__name__}: {exc}")
            raise
        finally:
            status["finished_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
            write_status(status_path, status)
        return status

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("check", "run"):
        p = sub.add_parser(name)
        p.add_argument("--run-root", type=Path, required=True)
        p.add_argument("--answer-id", required=True)
        p.add_argument("--role", choices=sorted(ROLES - {"reconciler"}), required=True)
        p.add_argument("--packet-dir", type=Path, required=True)
        p.add_argument("--instruction-dir", type=Path, required=True)
        p.add_argument("--codex-cli", type=Path, required=True)
        p.add_argument("--model", required=True)
        p.add_argument("--reasoning-effort", default=DEFAULT_REASONING_EFFORT,
                       choices=sorted(REASONING_EFFORTS))
        p.add_argument("--allow-write-dir", type=Path, action="append", default=[])
        p.add_argument("--gate", type=Path, required=name == "run")
    for name in ("check-group", "run-group"):
        p = sub.add_parser(name)
        p.add_argument("--run-root", type=Path, required=True)
        p.add_argument("--group-manifest", type=Path, required=True)
        p.add_argument("--instruction-dir", type=Path, required=True)
        p.add_argument("--codex-cli", type=Path, required=True)
        p.add_argument("--model", required=True)
        p.add_argument("--max-workers", type=int, required=True)
        p.add_argument("--reasoning-effort", default=DEFAULT_REASONING_EFFORT,
                       choices=sorted(REASONING_EFFORTS))
        p.add_argument("--allow-write-dir", type=Path, action="append", default=[])
        p.add_argument("--gate", type=Path, required=name == "run-group")
    args = parser.parse_args(argv)
    try:
        if args.command.endswith("-group"):
            intent, effective = prepare_group_intent(
                run_root=args.run_root, group_manifest=args.group_manifest,
                instruction_dir=args.instruction_dir, cli=args.codex_cli,
                write_dirs=args.allow_write_dir, model=args.model,
                max_workers=args.max_workers,
                reasoning_effort=args.reasoning_effort)
        else:
            intent, effective = prepare_intent(
                run_root=args.run_root, answer_id=args.answer_id,
                role=args.role, packet_dir=args.packet_dir,
                instruction_dir=args.instruction_dir,
                cli=args.codex_cli, write_dirs=args.allow_write_dir,
                model=args.model, reasoning_effort=args.reasoning_effort)
        if args.command in {"check", "check-group"}:
            gate_state = "not_checked"
            if args.gate:
                try:
                    check_gate(args.gate, intent)
                    gate_state = "ready"
                except (ValueError, OSError) as exc:
                    gate_state = f"denied: {exc}"
            print(json.dumps({"intent_sha256": intent_sha256(intent), "intent": intent,
                              "gate_state": gate_state}, indent=2, ensure_ascii=False))
            return 0
        status = launch(intent, effective, args.instruction_dir.resolve(strict=True), args.gate)
        print(json.dumps(status, indent=2, ensure_ascii=False))
        return int(status["exit_code"] or 0)
    except (ValueError, OSError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        print(f"dispatch refused: {exc}", file=sys.stderr)
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
