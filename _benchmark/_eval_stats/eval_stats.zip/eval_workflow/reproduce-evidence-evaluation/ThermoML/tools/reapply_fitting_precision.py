"""Reapply the default fitting precision method to accepted canonical evidence.
No source mapping, native artifact, semantic dimension or raw measurement changes.
"""
import copy,csv,hashlib,io,json,re
from decimal import Decimal
from pathlib import Path
from filesystem_paths import io_path
from compare_core import convert
from fitting_precision import POLICY,METHOD_TEXT,precision_role,compare_fitting,compare_curve_precision
from tokenize_numbers import tokenize
from canonical_export import _counts,_claim_counts,_excerpts


def verify_reference(folder,ref,cache):
    def checked(spec):
        rel=Path(spec['path'])
        if rel.is_absolute() or '..' in rel.parts:raise ValueError('reference escapes own artifact folder')
        p=io_path(folder)/'artifacts'/rel;k=str(p)
        if k not in cache:cache[k]=p.read_bytes()
        data=cache[k]
        if hashlib.sha256(data).hexdigest()!=spec['sha256']:raise ValueError('accepted source hash changed '+str(p))
        return data
    data=checked(ref);text=data.decode('utf-8-sig')
    if ref['format']=='csv':
        row=list(csv.DictReader(io.StringIO(text)))[ref['row']-1]
        if ref.get('key') is not None and row[ref.get('key_field','key')]!=ref['key']:raise ValueError('source row key changed')
        value=row[ref['field']]
    elif ref['format']=='text':
        line=text.splitlines()[ref['line']-1]
        if line!=ref['excerpt']:raise ValueError('source excerpt changed')
        hits=list(re.finditer(ref['pattern'],line))
        if len(hits)!=1:raise ValueError('source selector ambiguous')
        value=hits[0]['value']
    elif ref['format']=='json':
        value=json.loads(text,parse_float=str,parse_int=str)
        for part in ref['pointer'][1:].split('/'):
            part=part.replace('~1','/').replace('~0','~');value=value[int(part)] if isinstance(value,list) else value[part]
    else:raise ValueError('unsupported accepted numeric selector')
    if str(value)!=ref['stored_value']:raise ValueError('accepted native value differs from actual source')
    if not ref.get('unit_error') and Decimal(str(convert(value,ref['stored_unit'],ref['claimed_unit'])))!=Decimal(ref['converted_stored_value']):raise ValueError('accepted conversion differs')
    call=ref['generating_call'];calltext=checked(call).decode('utf-8-sig').replace('\r\n','\n')
    if call['arguments_excerpt'].replace('\r\n','\n') not in calltext:raise ValueError('generating argument excerpt changed')
    for spec in ref.get('source_context',[]):checked(spec)
    curve=ref.get('curve_verification')
    if curve:
        checked(curve['plot'])
        for spec in curve.get('coefficients',[])+curve.get('pure_references',[]):checked(spec)

def reapply(doc,accepted_report,evaluated_answer,eval_folder):
    """Return canonical document and complete per-occurrence transition audit."""
    out=copy.deepcopy(doc);checks={c['token_id']:c for c in accepted_report['token_checks']}
    tokens={t['token_id']:t for t in tokenize(evaluated_answer,doc['answer']['answer_id'])}
    rows=[dict(v,line=e['line'],context_excerpt=e['excerpt']) for e in out['excerpts'] for v in e['values']]
    before={v['token_id']:copy.deepcopy(v) for v in rows};audit=[];cache={};changed=set()
    for row in rows:
        if row['group']!='pipeline_artifact':continue
        tid=row['token_id'];check=checks[tid];ref=row.get('artifact_reference');role=precision_role(check,ref)
        oldnum=row['numeric_outcome'];old=row['outcome'];newnum=oldnum;comparison=None
        if ref:verify_reference(eval_folder,ref,cache)
        if ref and role=='continuous_fitted_output' and row.get('unit_outcome')!='miss' and not ref.get('unit_error'):
            reference=row.get('calculated_reference_value') or ref['converted_stored_value']
            if row.get('magnitude_interpretation'):reference=row['magnitude_interpretation']['interpreted_value']
            token=tokens[tid];tolerance=token['display_tolerance']
            if row.get('lexical_scale_interpretation'):tolerance=row['lexical_scale_interpretation']['tolerance']
            curve=row.get('curve_verification')
            if curve and curve.get('reported_interval'):
                role_note='Accepted interval containment and source-precision envelope retained; no scalar rounding of interval endpoints.'
            else:
                comparison=(compare_curve_precision(row['reported_value'],reference,tolerance,curve['source_precision_interval'],role) if curve else compare_fitting(row['reported_value'],reference,tolerance,role))
                newnum=comparison['category']
                if oldnum=='exact':newnum='exact' # Preserve accepted coarser/contextual display precision.
                if oldnum=='miss' and newnum=='near_miss':newnum='miss' # This method adds Exact eligibility only.
                row['precision_role']=role;row['precision_policy']=comparison['precision_policy']
                row['precision_policy']['accepted_previous_numeric_outcome']=oldnum
                if newnum!=oldnum:
                    row['numeric_outcome']=newnum
                    if row.get('raw_numeric_outcome')==oldnum:row['raw_numeric_outcome']=newnum
                    dims=[newnum]+[row.get(k,'not_applicable') for k in ['source_outcome','condition_outcome','unit_outcome','basis_outcome']]
                    final='miss' if 'miss' in dims else 'near_miss' if 'near_miss' in dims else 'exact'
                    # A prior final Miss not explained by the numeric dimension is semantic.
                    if old=='miss' and oldnum!='miss':final='miss'
                    row['outcome']=final
                    row['precision_previous_reason']=row['reason']
                    row['reason']=('Numerical Exact under default four-significant-digit fitting policy: reported '+row['reported_value']+' and unit-converted reference '+reference+' both round to '+comparison['precision_policy']['rounded_reference_value']+' (ROUND_HALF_UP). Native reference precision is retained. Source/state/unit/basis verdicts remain '+', '.join(k+'='+str(row.get(k)) for k in ['source_outcome','condition_outcome','unit_outcome','basis_outcome'])+'. Final verdict: '+final+'.')
                    changed.add(tid)
        audit.append({'answer_id':doc['answer']['answer_id'],'token_id':tid,'role':role,'property':row.get('property'),'old_numeric':oldnum,'new_numeric':row['numeric_outcome'],'old_outcome':old,'new_outcome':row['outcome'],'reported_value':row.get('reported_value'),'reference_value':row.get('calculated_reference_value') or (ref or {}).get('converted_stored_value'),'native_reference_unchanged':row.get('artifact_reference')==before[tid].get('artifact_reference'),'precision_policy':row.get('precision_policy')})
    claim_changes=[]
    for claim in out.get('factual_claims',[]):
        owned=[r for r in rows if r['token_id'] in claim.get('token_ids',[]) and r['group']!='outside']
        if not any(r['token_id'] in changed for r in owned):continue
        current=claim.get('final_verdict',claim.get('verdict'))
        if current not in {'exact','near_miss'}:continue
        # Only numeric owning claims can be mechanically summarized; broader
        # semantic findings and non-pipeline claims retain their judgments.
        if claim.get('final_type',claim.get('type'))!='pipeline_artifact':continue
        prior=copy.deepcopy(claim);verdict=current
        if current=='near_miss' and owned and all(r['outcome']=='exact' for r in owned):verdict='exact'
        counts={k:sum(r['outcome']==k for r in owned) for k in ['exact','near_miss','miss']}
        reason='Accepted source, state, unit and basis findings retained; linked numerical occurrences recomputed with default four-significant-digit fitting precision: '+', '.join(f'{n} {k}' for k,n in counts.items())+'. This numerical owning claim is '+verdict+'. Previous precision wording is retained in precision_previous_reason.'
        claim['precision_previous_reason']=claim.get('final_reason',claim.get('reason'));claim['precision_previous_verdict']=current
        claim.update(verdict=verdict,final_verdict=verdict,reason=reason,final_reason=reason)
        claim_changes.append({'claim_id':claim['claim_id'],'prior':prior,'new_verdict':verdict})
    claimmap={c['claim_id']:c for c in out.get('factual_claims',[])};changedclaims={c['claim_id'] for c in claim_changes}
    for row in rows:
        # Non-artifact numeric findings stay byte-content identical, including provenance.
        if row['group']!='pipeline_artifact':continue
        for owner in row.get('claim_provenance',[]):
            if owner['claim_id'] in changedclaims:
                c=claimmap[owner['claim_id']];owner.update(verdict=c['final_verdict'],reason=c['final_reason'])
    for r in rows:
        old=before[r['token_id']]
        if r['group']!='pipeline_artifact' and r!=old:raise ValueError('unrelated numeric finding changed')
        if old['outcome']=='exact' and r['outcome']!='exact':raise ValueError('old Exact downgraded')
        for k in ['artifact_reference','source_outcome','condition_outcome','unit_outcome','basis_outcome','misassigned']:
            if r.get(k)!=old.get(k):raise ValueError('evidence/semantic finding changed '+k)
    out['excerpts']=_excerpts(rows);out['counts']['numeric']=_counts(rows);out['counts']['factual_claims']=_claim_counts(out.get('factual_claims',[]))
    out['columns']['values']=list(dict.fromkeys(k for r in rows for k in r if k not in ('line','context_excerpt')))
    out['columns']['factual_claims']=list(dict.fromkeys(k for c in out.get('factual_claims',[]) for k in c))
    out['pipeline_artifact_review']['counts']=out['counts']['numeric']['by_group']['pipeline_artifact'];out['pipeline_artifact_review']['property_rollup']=out['counts']['numeric']['property_rollup']
    out['method_policies']={'fitting_precision':{'id':POLICY,'significant_digits':4,'rounding':'ROUND_HALF_UP','default':True,'rule':METHOD_TEXT,'interval_semantics':'unchanged source-precision interval containment'}}
    out['how_to_read']=[x.replace('scored raw archive occurrences','scored archive and pipeline-artifact occurrences') for x in out.get('how_to_read',[]) if 'significant digits' not in x]+[METHOD_TEXT]
    receipt={'answer_id':doc['answer']['answer_id'],'policy':POLICY,'occurrences':audit,'claim_changes':claim_changes,'native_files_verified':{k:hashlib.sha256(v).hexdigest() for k,v in cache.items()},'unaffected_numeric_rows_unchanged':True,'old_exact_not_downgraded':True,'semantic_dimensions_unchanged':True}
    return out,receipt
