"""Atomic worker leases shared by all review stages in one runtime.

A lease or lock left by a crashed parent is never removed automatically. An
operator must inspect the recorded process before manual recovery.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import secrets
import time

from run_settings import read_settings

STAGES = {"initial", "scientific", "reconciliation"}
LOCK_ATTEMPTS = 50
LOCK_PAUSE_SECONDS = 0.05


def _encoded(value: dict) -> bytes:
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode("utf-8")


def _read(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("invalid worker lease: " + str(path))
    return value


@contextmanager
def _locked(root: Path):
    lock = root / ".lock"
    token = secrets.token_hex(16)
    for _ in range(LOCK_ATTEMPTS):
        try:
            lock.mkdir()
            break
        except FileExistsError:
            time.sleep(LOCK_PAUSE_SECONDS)
    else:
        raise ValueError("worker slot lock is held; inspect before manual recovery")
    owner = lock / "owner.json"
    try:
        with owner.open("xb") as stream:
            stream.write(_encoded({"token": token, "pid": os.getpid()}))
        yield
    finally:
        if owner.is_file() and _read(owner).get("token") == token:
            owner.unlink()
            lock.rmdir()
        elif not owner.exists():
            # The lock was created by this process but owner creation failed.
            lock.rmdir()
        else:
            raise ValueError("worker slot lock owner changed; inspect before manual recovery")


@dataclass
class SlotLease:
    root: Path
    lease_id: str
    stage: str
    retained: bool = False

    def retain(self) -> None:
        """Keep the lease when a child may still be running after launcher failure."""
        self.retained = True

    @property
    def path(self) -> Path:
        return self.root / "leases" / (self.lease_id + ".json")

    def mark_pid(self, pid: int) -> None:
        if type(pid) is not int or pid <= 0:
            raise ValueError("worker PID must be a positive integer")
        with _locked(self.root):
            lease = _read(self.path)
            if lease.get("lease_id") != self.lease_id or lease.get("stage") != self.stage:
                raise ValueError("worker lease changed before PID recording")
            if lease.get("pid") is not None:
                raise ValueError("worker PID was already recorded")
            lease["pid"] = pid
            temporary = self.path.with_suffix(".tmp")
            with temporary.open("xb") as stream:
                stream.write(_encoded(lease))
            os.replace(temporary, self.path)

    def release(self) -> None:
        with _locked(self.root):
            lease = _read(self.path)
            if lease.get("lease_id") != self.lease_id or lease.get("stage") != self.stage:
                raise ValueError("worker lease changed before release")
            self.path.unlink()


def _active(leases: Path) -> list[dict]:
    rows = []
    for path in leases.iterdir():
        if not path.is_file() or path.suffix != ".json":
            raise ValueError("unexpected worker slot entry: " + str(path))
        row = _read(path)
        if (row.get("lease_id") != path.stem or row.get("stage") not in STAGES
                or type(row.get("parent_pid")) is not int):
            raise ValueError("invalid worker lease: " + str(path))
        rows.append(row)
    return rows


@contextmanager
def acquire_slot(run_root: Path, stage: str):
    """Reserve a slot until the launched process has ended or launch has failed."""
    if stage not in STAGES:
        raise ValueError("unknown worker stage")
    run_root = Path(run_root).resolve(strict=True)
    root = run_root / "control" / "worker-slots"
    leases = root / "leases"
    leases.mkdir(parents=True, exist_ok=True)
    lease_id = secrets.token_hex(16)
    with _locked(root):
        selected = read_settings(run_root)["parallelism"]
        maximum = selected["max_workers"]
        stage_maximum = selected["stage_limits"].get(stage, maximum)
        active = _active(leases)
        if len(active) >= maximum:
            raise ValueError("maximum concurrent workers reached")
        if sum(row["stage"] == stage for row in active) >= stage_maximum:
            raise ValueError("stage concurrent worker limit reached: " + stage)
        value = {"lease_id": lease_id, "stage": stage, "pid": None,
                 "parent_pid": os.getpid(),
                 "acquired_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        with (leases / (lease_id + ".json")).open("xb") as stream:
            stream.write(_encoded(value))
    lease = SlotLease(root, lease_id, stage)
    try:
        yield lease
    finally:
        if not lease.retained:
            lease.release()
