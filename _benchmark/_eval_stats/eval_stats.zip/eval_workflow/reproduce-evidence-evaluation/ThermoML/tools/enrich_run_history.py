from __future__ import annotations
import argparse, difflib, hashlib, json, os, re, shutil
from pathlib import Path

BASE = Path.cwd() / "_outputs_user/Benchmark/ThermoML"
PRIVATE = BASE / "__obsolete__" / "eval_artifact_assembly"
STEP = re.compile(r"(?m)^### Step (\d+).*?: "+chr(96)+r"([^"+chr(96)+r"]+)"+chr(96)+r"[^\n]*$")
ARG = re.compile(r"<details><summary>Arguments</summary>\s*"+chr(96)*3+r"json\s*\n(.*?)\n"+chr(96)*3, re.S)
RES = re.compile(r"<details><summary>Result</summary>\s*"+chr(96)*3+r"[^\n]*\r?\n(.*)\r?\n"+chr(96)*3+r"\r?\n</details>", re.S)
PREVIEW = re.compile(r"<details><summary>Preview</summary>.*?</details>", re.S)
VALIDATION = re.compile(r"<details><summary>Validation detail</summary>.*?</details>", re.S)
ERROR = re.compile(r"- \*\*Error:\*\* "+chr(96)+r"(.*?)"+chr(96), re.S)
CALL = re.compile(r"<tool_call>(.*?)</tool_call>", re.S)
RESULT = re.compile(r"<tool_result>\s*\r?\n(.*?)\r?\n</tool_result>", re.S)
LENGTH = re.compile(r"- \*\*Result:\*\* ([\d,]+) chars")
TRUNC = re.compile(r"(?:…|\.\.\.)\s*[\d,]+\s+tokens?\s+truncated",re.I)
FIT_TOOLS = frozenset(("fit_block","fit_block_derived","fit_multi_system","compute_ideal_baseline","predict_from_rk","propose_fitting_plan"))

def digest(b): return hashlib.sha256(b).hexdigest()
def extended_path(path):
    absolute=Path(path).resolve()
    if os.name!="nt": return absolute
    value=str(absolute)
    if value.startswith("\\\\?\\"): return absolute
    if value.startswith("\\"): return Path("\\\\?\\UNC\\"+value[2:])
    return Path("\\\\?\\"+value)
def safe(p): return p.resolve().is_relative_to(BASE.resolve())
def source(p):
    b=p.read_bytes()
    return b,b.decode("utf-8")
def sessions():
    a=[]
    for h in (BASE/"Analysis").rglob("run_history.md"):
        if any(x in h.parts for x in ("eval","query_runs","query_worker_runs","__obsolete__")) or any("temp" in x.lower() for x in h.relative_to(BASE/"Analysis").parts): continue
        s=h.parent
        a.append((s/"eval/artifacts",s))
    for h in (BASE/"Main").rglob("run_history.md"):
        if h.parent.name.startswith("run_") and h.parent.parent.name=="analysis_runs" and "eval" not in h.parts and "__obsolete__" not in h.parts and not any("temp" in x.lower() for x in h.relative_to(BASE/"Main").parts):
            s=h.parent
            a.append((s.parent.parent/"eval/artifacts/analysis_runs"/s.name,s))
    return sorted(a,key=lambda x:str(x[0]).lower())
def transcript(text):
    first_match=re.search(r"(?m)^## User\r?$",text)
    if first_match is None: return []
    first=first_match.start()
    body=text[first:]
    turns=list(re.finditer(r"(?m)^## (Assistant|User)\s*$",body))
    out=[]
    for i,t in enumerate(turns):
        if t.group(1)!="Assistant": continue
        end=turns[i+1].start() if i+1<len(turns) else len(body)
        if i+1<len(turns) and turns[i+1].group(1)=="User":
            uend=turns[i+2].start() if i+2<len(turns) else len(body)
            result=RESULT.search(body[end:uend])
        else: result=None
        turn_calls=list(CALL.finditer(body[t.end():end]))
        for batch_index,c in enumerate(turn_calls):
            m=re.match(r"\s*([\w<>]+)\s*\(",c.group(1))
            if m: out.append((m.group(1),result.group(1) if result else None,(first+end+result.start(1),first+end+result.end(1)) if result else None,c.group(1),len(turn_calls),batch_index,(first+t.end()+c.start(1),first+t.end()+c.end(1))))
    return out
def open_visible_calls(text):
    first=re.search(r"(?m)^## User\r?$",text)
    if first is None: return []
    body=text[first.start():]
    turns=list(re.finditer(r"(?m)^## (Assistant|User)\s*$",body))
    found=[]
    for i,turn in enumerate(turns):
        if turn.group(1)!="Assistant": continue
        stop=turns[i+1].start() if i+1<len(turns) else len(body)
        segment=body[turn.end():stop]
        wait=segment.find("<wait/>")
        before_wait=segment if wait<0 else segment[:wait]
        for match in re.finditer("<tool_call>",before_wait):
            close=segment.find("</tool_call>",match.end())
            if close>=0 and (wait<0 or close<wait): continue
            end=close+len("</tool_call>") if close>=0 else (wait+len("<wait/>") if wait>=0 else len(segment))
            start_abs=first.start()+turn.end()+match.start()
            end_abs=first.start()+turn.end()+end
            found.append({"span":[start_abs,end_abs],"text":text[start_abs:end_abs],"parser_cut_at_wait":wait>=0})
    return found

def json_validation(content, block_index):
    body=content.strip()
    try:
        obj=json.loads(body)
    except json.JSONDecodeError as exc:
        return f"block {block_index}: invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}"
    if not isinstance(obj,dict): return f"block {block_index}: the JSON value must be an object"
    keys=set(obj); required={"arguments","name"}
    if keys!=required:
        return f"block {block_index}: tool-call objects require exactly ['arguments', 'name']; missing={sorted(required-keys)}, extra={sorted(keys-required)}"
    if not isinstance(obj["name"],str) or not obj["name"].strip():
        return f"block {block_index}: 'name' must be a non-empty string"
    if not isinstance(obj["arguments"],dict):
        return f"block {block_index}: 'arguments' must be a JSON object"
    return ""

def closed_visible_invalid_calls(text):
    first=re.search(r"(?m)^## User\r?$",text)
    if first is None: return []
    body=text[first.start():]
    turns=list(re.finditer(r"(?m)^## (Assistant|User)\s*$",body))
    found=[]
    for i,turn in enumerate(turns):
        if turn.group(1)!="Assistant": continue
        stop=turns[i+1].start() if i+1<len(turns) else len(body)
        segment=body[turn.end():stop].split("<wait/>",1)[0]
        for block_index,match in enumerate(CALL.finditer(segment),1):
            error=json_validation(match.group(1),block_index)
            if error:
                start_abs=first.start()+turn.end()+match.start()
                end_abs=first.start()+turn.end()+match.end()
                found.append({"span":[start_abs,end_abs],"text":text[start_abs:end_abs],"error":error})
    return found

def raw_calls(path):
    if not path.is_file(): return [],None
    raw=path.read_bytes()
    found=[]
    for line_number,line in enumerate(raw.decode("utf-8").splitlines(),1):
        record=json.loads(line)
        timestamp=str(record.get("ts",""))
        for content_index,block in enumerate(record.get("response",{}).get("content",[])):
            value=block.get("text","") if isinstance(block,dict) else ""
            starts=[m.start() for m in re.finditer("<tool_call>",value)]
            for index,start in enumerate(starts):
                end=value.find("</tool_call>",start)
                end=end+len("</tool_call>") if end>=0 else len(value)
                if index+1<len(starts): end=min(end,starts[index+1])
                found.append({"time":timestamp[11:19],"timestamp":timestamp[11:23],"seq":record.get("seq"),"line":line_number,
                              "content_index":content_index,"span":[start,end],"text":value[start:end]})
    return found,digest(raw)

def raw_matches_native(fragment, expected, validation):
    body=fragment.split("<tool_call>",1)[-1].split("</tool_call>",1)[0].strip()
    function=re.match(r"([A-Za-z_][A-Za-z_0-9]*)\s*\(",body)
    object_name=re.search(r'"name"\s*:\s*"([^"]+)"',body)
    name=function.group(1) if function else (object_name.group(1) if object_name else None)
    if not expected.startswith("<malformed"):
        return name==expected
    detail=validation or ""
    return ("invalid JSON" in detail and not body.startswith("{")) or (
        "tool-call objects require" in detail and body.startswith("{"))

def link_fit_files(record, history, context):
    """Link copied files only to one source-backed successful fit naming key."""
    candidates=[]
    for call_index,call in enumerate(record["fitting_calls"]):
        if call["name"] not in ("fit_block","fit_block_derived","fit_multi_system"): continue
        if not call["result_complete_saved_body"] or call.get("arguments_source")!="run_history.md": continue
        if "VALIDATION BLOCKED" in call["header"] or "ERROR" in call["header"]: continue
        span=call.get("arguments_source_span")
        if not span: continue
        try: arguments=json.loads(history[span[0]:span[1]])
        except (ValueError,TypeError): continue
        result_source=call.get("result_source")
        result_span=call.get("result_source_span") if result_source=="run_history.md" else call.get("result_span")
        result_text=(history if result_source=="run_history.md" else context)[slice(*result_span)] if result_span else ""
        if not any(marker in result_text for marker in ("**RK Fit**","BIC-selected order","selected_order")): continue
        systems=arguments.get("systems") if call["name"]=="fit_multi_system" else [arguments]
        if not isinstance(systems,list): continue
        for system in systems:
            if not isinstance(system,dict): continue
            doi=system.get("doi"); block=system.get("block_number")
            if not isinstance(doi,str) or not isinstance(block,str): continue
            if doi not in result_text or block not in result_text: continue
            prefix=doi.replace("/","_").replace(".","_")[:40]+"_B"+block+"_"
            candidates.append((prefix,call_index,result_text))
    linked=derived=ambiguous=0
    for file in record["files"]:
        basename=Path(file["path"]).name
        matches=sorted({index for prefix,index,_ in candidates if basename.startswith(prefix)})
        if len(matches)==1:
            call=record["fitting_calls"][matches[0]]
            provenance={"step":call["step"],"header":call["header"],"name":call["name"],"arguments_source":call["arguments_source"],"arguments_source_span":call["arguments_source_span"],"arguments_sha256":call["arguments_sha256"],"result_source":call["result_source"],"result_sha256":call["result_sha256"]}
            exact=any(index==matches[0] and basename in result for _,index,result in candidates)
            if exact:
                provenance["rule"]="exact copied basename in complete fixed-tool Result"
                file["generating_fit_call"]=provenance
                call.setdefault("linked_copied_files",[]).append({"path":file["path"],"sha256":file["sha256"]})
                linked+=1
            else:
                provenance["rule"]="derived unique DOI/block match to registered _save_fit_outputs basename; file creation by this call is not asserted"
                file["unique_fit_call_by_code_naming_rule"]=provenance
                call.setdefault("candidate_copied_files",[]).append({"path":file["path"],"sha256":file["sha256"]})
                derived+=1
        elif matches:
            file["generating_fit_call_status"]="ambiguous_multiple_successful_calls"
            ambiguous+=1
        else:
            file["generating_fit_call_status"]="not_source_linked"
    record["file_linkage_summary"]={"linked_exact_result":linked,"derived_unique_candidate":derived,"ambiguous":ambiguous,"not_source_linked":len(record["files"])-linked-derived-ambiguous}

def run(target,src,apply):
    if not safe(target) or not safe(src): raise ValueError("source or target outside supplied benchmark base")
    original,h=source(src/"run_history.md")
    cb,ct=source(src/"final_full_context.md")
    memfile=src/"_working_memory.md"
    mb,mem=source(memfile) if memfile.is_file() else (None,None)
    markers=list(STEP.finditer(h))
    pieces=[h[:markers[0].start()] if markers else h]
    fitting_pieces=["# Registered deterministic fitting tool calls — verbatim\n\nThis archive contains only calls to the six registered fitting tools. Native tool arguments, fixed-tool results, validation failures, and exact saved agent-visible result bodies appear below. A Preview or compacted summary is labeled as such and is not a complete numeric result. The full run history is context and provenance only.\n"]
    native=[m.group(2) for m in markers]
    context=transcript(ct)
    captured,capture_hash=raw_calls(src/"anthropic_raw_capture.jsonl")
    visible_open=open_visible_calls(ct)
    visible_closed=closed_visible_invalid_calls(ct)
    held_count=sum(m.group(2).startswith("<malformed") for m in markers)
    held_index=0
    native_error_groups={}
    for position,mark in enumerate(markers):
        if not mark.group(2).startswith("<malformed"): continue
        section=h[mark.start():(markers[position+1].start() if position+1<len(markers) else len(h))]
        error=re.search(r"block \d+:[^\r\n]+",section)
        if error: native_error_groups.setdefault(error.group(0),[]).append(position)
    closed_mapping={}
    for error,positions in native_error_groups.items():
        candidates=[entry for entry in visible_closed if entry["error"]==error]
        if len(candidates)==len(positions):
            closed_mapping.update(zip(positions,candidates))
    ordered=[closed_mapping[i]["span"][0] for i in sorted(closed_mapping)]
    if ordered!=sorted(ordered): closed_mapping={}
    mapping={}
    for kind,a,b,c,d in difflib.SequenceMatcher(None,native,[x[0] for x in context],autojunk=False).get_opcodes():
        if kind=="equal": mapping.update(zip(range(a,b),range(c,d)))
    rec={"target":str(target.relative_to(BASE)),"source":str(src.relative_to(BASE)),"source_hashes":{"run_history.md":digest(original),"final_full_context.md":digest(cb)},"steps":[],"gaps":[],"visible_context_limitations":[],"files":[],"fitting_calls":[]}
    if mb is not None: rec["source_hashes"]["_working_memory.md"]=digest(mb)
    if capture_hash: rec["source_hashes"]["anthropic_raw_capture.jsonl"]=capture_hash
    child_paths=sorted((src/"query_runs").glob("run_*/run_history.md"),key=lambda q:int(q.parent.name.split("_")[-1]))
    child_index=0
    for i,m in enumerate(markers):
        end=markers[i+1].start() if i+1<len(markers) else len(h)
        full=h[m.start():end]
        num=int(m.group(1)); arg=ARG.search(full); nr=RES.search(full); vr=VALIDATION.search(full); er=ERROR.search(full); length=LENGTH.search(full)
        declared=int(length.group(1).replace(",","")) if length else None
        item={"step":num,"name":m.group(2),"header":m.group(0).strip(),"declared_result_chars":declared}
        held_fragment=visible_open[held_index] if m.group(2).startswith("<malformed") and visible_open and len(visible_open)==held_count else None
        closed_fragment=closed_mapping.get(i)
        if m.group(2).startswith("<malformed"): held_index+=1
        matched=context[mapping[i]] if i in mapping else None
        call_literal=matched[3].strip() if matched else None
        started=re.search(r"Started:\*\*\s*(\d{2}:\d{2}:\d{2})",full)
        def seconds(value):
            parts=value.split(":")
            return int(parts[0])*3600+int(parts[1])*60+float(parts[2])
        near=[x for x in captured if started and abs(seconds(x["timestamp"])-seconds(started.group(1)))<=0.51 and raw_matches_native(x["text"],m.group(2),vr.group(0) if vr else None)]
        tag=re.search(r"\bc(\d+)\]",m.group(0))
        tagged=[x for x in near if tag and x["seq"]==int(tag.group(1))]
        if len(tagged)==1:
            raw_arg=tagged[0]
            raw_binding="canonical_id_and_name"
        elif len(near)==1 and m.group(2).startswith("<malformed") and vr is not None:
            raw_arg=near[0]
            raw_binding="unique_subsecond_time_and_matching_validation_syntax"
        else:
            raw_arg=None
            raw_binding=None
        native_validation=re.search(r"block \d+:[^\r\n]+",vr.group(0)) if vr else None
        if raw_arg is None and m.group(2).startswith("<malformed") and native_validation and started:
            block_number=int(re.match(r"block (\d+):",native_validation.group(0)).group(1))
            exact_near=[]
            for candidate in captured:
                if abs(seconds(candidate["timestamp"])-seconds(started.group(1)))>1.0: continue
                fragment=candidate["text"]
                if "<tool_call>" not in fragment: continue
                body=fragment.split("<tool_call>",1)[1].split("</tool_call>",1)[0].split("<wait/>",1)[0]
                if json_validation(body,block_number)==native_validation.group(0): exact_near.append(candidate)
            if len(exact_near)==1:
                raw_arg=exact_near[0]
                raw_binding="unique_one_second_time_and_exact_parser_validation"
        if raw_arg is None and m.group(2).startswith("<malformed") and vr is not None and "unclosed or structurally invalid" in vr.group(0) and started:
            def unclosed_raw(fragment):
                if "<tool_call>" not in fragment: return False
                body=fragment.split("<tool_call>",1)[1].split("<wait/>",1)[0]
                return "</tool_call>" not in body
            held_near=[x for x in captured if abs(seconds(x["timestamp"])-seconds(started.group(1)))<=1.0 and unclosed_raw(x["text"])]
            if len(held_near)==1:
                raw_arg=held_near[0]
                raw_binding="unique_one_second_time_and_matching_unclosed_validation"
        child_arg=None
        if m.group(2)=="run_query_agent" and matched and matched[1] and "<subagent_answer>" in matched[1]:
            if child_index<len(child_paths):
                child_path=child_paths[child_index]
                child_raw,child_text=source(child_path)
                pm=re.search(r"(?ms)^\*\*Prompt:\*\* .*?(?=^\*\*Started:)",child_text)
                if pm: child_arg=(child_path,child_raw,pm)
            child_index+=1
        if arg is None and call_literal==m.group(2)+"()":
            item["arguments_source"]="final_full_context.md:zero_argument_call"
            item["arguments_call_literal"]=call_literal
            full+="\n**Original call literal:** "+chr(96)+call_literal+chr(96)+" (zero arguments).\n"
        elif raw_arg is not None and (arg is None or "..." in arg.group(1) or "…" in arg.group(1)):
            fragment=raw_arg["text"]
            item["arguments_source"]="anthropic_raw_capture.jsonl:response.content[].text"
            item["arguments_raw_capture"]={k:raw_arg[k] for k in ("seq","line","content_index","span")}
            item["arguments_raw_capture"]["binding"]=raw_binding
            item["arguments_raw_capture"]["time_delta_seconds"]=round(seconds(raw_arg["timestamp"])-seconds(started.group(1)),3)
            item["arguments_sha256"]=digest(fragment.encode())
            full+="\n**Original raw model tool-call fragment:** The syntax is preserved exactly. For a validation-blocked call this is the attempted fragment, not parsed or executed tool arguments.\n\n~~~~text\n"+fragment+"\n~~~~\n"
        elif held_fragment is not None and vr is not None and "unclosed or structurally invalid" in vr.group(0):
            fragment=held_fragment["text"]
            item["arguments_source"]="final_full_context.md:malformed_attempted_call_fragment"
            item["arguments_source_span"]=held_fragment["span"]
            item["arguments_sha256"]=digest(fragment.encode())
            item["arguments_parser_cut_at_wait"]=held_fragment["parser_cut_at_wait"]
            full+="\n**Agent-visible attempted call fragment (validation blocked):** This exact source fragment was held by the batch parser; no parsed tool arguments were executed. The parser cut the message at the first wait marker.\n\n~~~~text\n"+fragment+"\n~~~~\n"
        elif closed_fragment is not None and vr is not None:
            fragment=closed_fragment["text"]
            item["arguments_source"]="final_full_context.md:malformed_attempted_call_fragment"
            item["arguments_source_span"]=closed_fragment["span"]
            item["arguments_sha256"]=digest(fragment.encode())
            item["arguments_validation_binding"]="exact_parser_validation_and_source_order"
            full+="\n**Agent-visible attempted call fragment (validation blocked):** This exact source fragment failed the saved parser validation; no parsed tool arguments were executed.\n\n~~~~text\n"+fragment+"\n~~~~\n"
        elif child_arg is not None and (arg is None or "..." in arg.group(1) or "…" in arg.group(1)):
            child_path,child_raw,pm=child_arg
            prompt=pm.group(0)
            item["arguments_source"]=str(child_path.relative_to(src))
            item["arguments_source_span"]=[pm.start(),pm.end()]
            item["arguments_sha256"]=digest(prompt.encode())
            rec["source_hashes"][str(child_path.relative_to(src))]=digest(child_raw)
            full+="\n**Original delegated argument values from child-session prompt:** The saved prompt preserves Purpose, question, Tasks, and Context verbatim; original parent JSON serialization is unavailable.\n\n~~~~text\n"+prompt+"~~~~\n"
        elif arg is None or "..." in arg.group(1) or "…" in arg.group(1):
            if matched and "..." not in matched[3] and "…" not in matched[3]:
                visible=matched[3]
                item["arguments_source"]="final_full_context.md:complete_agent_visible_call_literal"
                item["arguments_source_span"]=matched[6]
                item["arguments_sha256"]=digest(visible.encode())
                full+="\n**Complete agent-visible call literal from saved context:**\n\n~~~~text\n"+visible+"\n~~~~\n"
            else:
                if matched:
                    visible=matched[3]
                    item["arguments_visible_call_source"]="final_full_context.md:compressed_agent_visible_call_literal"
                    item["arguments_visible_call_span"]=matched[6]
                    item["arguments_visible_call_sha256"]=digest(visible.encode())
                    rec["visible_context_limitations"].append({"step":num,"header":item["header"],"field":"arguments","kind":"compressed_call_literal","source":"final_full_context.md","span":matched[6],"sha256":digest(visible.encode()),"explanation":"saved agent context contains this compressed call literal; omitted argument text is not present in the saved visible context"})
                    full+="\n**Agent-visible context limit — arguments:** The saved call literal is compressed. The exact visible literal follows; native excerpt above remains as recorded.\n\n~~~~text\n"+visible+"\n~~~~\n"
                else:
                    rec["gaps"].append({"step":num,"field":"arguments","reason":"no matching agent-visible call in saved context; native arguments missing or shortened"})
                    full+="\n**Archival gap — arguments:** No matching call was saved in the available agent context; the native excerpt above is retained exactly as recorded.\n"
        else:
            item["arguments_source"]="run_history.md"
            item["arguments_source_span"]=[m.start()+arg.start(1),m.start()+arg.end(1)]
            item["arguments_sha256"]=digest(arg.group(1).encode())
        if nr is not None and (declared is None or declared in (len(nr.group(1).replace("\r\n","\n")),len(nr.group(1).replace("\r\n","\n").rstrip("\r")))) and not TRUNC.search(nr.group(1)):
            item["result_source"]="run_history.md"
            item["result_verified_complete"]=True
            item["result_source_span"]=[m.start()+nr.start(1),m.start()+nr.end(1)]
            item["result_sha256"]=digest(nr.group(1).encode())
        elif vr is not None:
            item["result_source"]="run_history.md:Validation detail"
            item["result_source_span"]=[m.start()+vr.start(0),m.start()+vr.end(0)]
            item["result_sha256"]=digest(vr.group(0).encode())
        elif er is not None:
            item["result_source"]="run_history.md:Error"
            item["result_source_span"]=[m.start()+er.start(1),m.start()+er.end(1)]
            item["result_sha256"]=digest(er.group(1).encode())
        else:
            c=context[mapping[i]] if i in mapping else None
            result=c[1] if c else None
            if not result or result.lstrip().startswith("(validation blocked"):
                preview=PREVIEW.search(full)
                if preview:
                    fence=re.search(chr(96)*3+r"[^\n]*\n(.*?)\n"+chr(96)*3,preview.group(0),re.S)
                    preview_text=fence.group(1) if fence else ""
                    preview_text=re.sub(r"\s+"," ",preview_text).strip()
                    prefix=preview_text[:90]
                    candidates=[entry for entry in context if entry[1] and re.sub(r"\s+"," ",entry[1]).strip().startswith(prefix)]
                    if len(candidates)==1:
                        c=candidates[0]
                        result=c[1]
            if result and result.lstrip().startswith("**Parallel batch:") and "inspect_batch_result" in result:
                item["result_source"]="final_full_context.md:compacted_batch_summary"
                item["result_span"]=c[2]
                item["result_sha256"]=digest(result.encode())
                item["result_visibility"]="agent_visible_compacted_batch_summary"
                rec["visible_context_limitations"].append({"step":num,"header":item["header"],"field":"result","kind":"compacted_batch_summary","source":"final_full_context.md","span":c[2],"sha256":digest(result.encode()),"explanation":"saved agent context shows this exact compacted batch summary; individual tool output is not present in the saved visible context"})
                replacement="<details><summary>Agent-visible compacted batch summary — saved verbatim</summary>\n\n~~~~text\n"+result+"\n~~~~\n\n</details>"
                full+="\n"+replacement+"\n"
            elif result and not result.lstrip().startswith("(validation blocked"):
                result_span=c[2]
                batch_note=""
                if len(c)>4 and c[4]>1:
                    heads=list(re.finditer(r"(?m)^### ([A-Za-z_][A-Za-z_0-9]*)\r?$",result))
                    if len(heads)==c[4] and heads[c[5]].group(1)==m.group(2):
                        start=heads[c[5]].start()
                        stop=heads[c[5]+1].start() if c[5]+1<len(heads) else len(result)
                        result_span=[c[2][0]+start,c[2][0]+stop]
                        result=result[start:stop]
                        item["result_batch_section"]={"call_index":c[5]+1,"batch_size":c[4]}
                        batch_note="Exact headed section from saved combined batch result"
                    else:
                        item["result_batch_shared"]={"call_index":c[5]+1,"batch_size":c[4]}
                        rec["gaps"].append({"step":num,"field":"result_attribution","reason":"saved result is combined batch without separable per-call headings"})
                        batch_note="Full combined batch result shared by "+str(c[4])+" calls; individual output boundary is not saved"
                normalized=result.replace("\r\n","\n").rstrip("\r")
                incomplete=bool(TRUNC.search(result)) or bool(declared and declared>1000 and len(normalized)<declared*0.9)
                item["result_verified_complete"]=not incomplete
                if incomplete:
                    rec["gaps"].append({"step":num,"field":"result","reason":"saved result has explicit truncation or is materially shorter than declared original output"})
                    item["result_source"]="final_full_context.md:partial"
                    batch_note="Saved partial result — complete original output unavailable"
                else:
                    item["result_source"]="final_full_context.md"
                item["result_span"]=result_span
                item["result_sha256"]=digest(result.encode())
                replacement="<details><summary>Result — "+(batch_note or "full saved tool_result body")+"</summary>\n\n~~~~text\n"+result+"\n~~~~\n\n</details>"
                if incomplete:
                    full+="\n"+replacement+"\n"
                elif PREVIEW.search(full):
                    full=PREVIEW.sub(lambda _:replacement,full,count=1)
                else:
                    full+="\n"+replacement+"\n"
            elif vr is not None:
                item["result_source"]="run_history.md:Validation detail"
                item["result_sha256"]=digest(vr.group(0).encode())
            elif er is not None:
                item["result_source"]="run_history.md:Error"
                item["result_sha256"]=digest(er.group(1).encode())
            elif nr is not None:
                item["result_source"]="run_history.md"
                item["result_sha256"]=digest(nr.group(1).encode())
                if TRUNC.search(nr.group(1)):
                    rec["gaps"].append({"step":num,"field":"result","reason":"native Result contains an explicit truncation marker"})
                    full+="\n**Archival gap — result:** The saved native Result contains an explicit truncation marker; full original output is unavailable.\n"
                elif declared is not None and declared not in (len(nr.group(1).replace("\r\n","\n")),len(nr.group(1).replace("\r\n","\n").rstrip("\r"))):
                    rec["gaps"].append({"step":num,"field":"result","reason":"native result length differs from declared length"})
                    full+="\n**Archival gap — result:** Saved result length differs from declared original length.\n"
            else:
                rec["gaps"].append({"step":num,"field":"result","reason":"no complete matching saved result"})
                full+="\n**Archival gap — result:** Exact complete original result was not saved in the available history/transcript.\n"
        pieces.append(full)
        if item["name"] in FIT_TOOLS:
            source_block=h[m.start():end]
            footer=re.search(r"(?m)^## (?:Compaction Summary|Stage Compaction Summary|Subagent Summary|Errors|Nested tool calls|Tool Compaction Pipeline)\b",source_block)
            footer_text=source_block[footer.start():] if footer else ""
            native_step=source_block[:footer.start()] if footer else source_block
            fit_full=full.replace(footer_text,"",1) if footer else full
            fit_item=dict(item)
            fit_item["native_source"]="run_history.md"
            fit_item["native_source_span"]=[m.start(),m.start()+len(native_step)]
            fit_item["native_source_sha256"]=digest(native_step.encode())
            fit_item["archived_section_sha256"]=digest(fit_full.encode())
            fit_item["result_complete_saved_body"]=bool(item.get("result_verified_complete"))
            result_source=item.get("result_source","")
            fit_item["recorded_outcome_kind"]=("complete_result" if fit_item["result_complete_saved_body"] else "complete_validation" if result_source=="run_history.md:Validation detail" else "complete_error" if result_source=="run_history.md:Error" else "agent_visible_compacted_summary" if result_source.endswith(":compacted_batch_summary") else "partial_or_missing_result")
            rec["fitting_calls"].append(fit_item)
            fitting_pieces.append("\n\n"+fit_full)
        rec["steps"].append(item)
    if mem is not None:
        fm=re.search(r"(?m)^### Completed Fits[^\n]*\n",mem)
        if fm:
            nexthead=re.search(r"(?m)^#{1,3} [^\n]+",mem[fm.end():])
            stop=fm.end()+nexthead.start() if nexthead else len(mem)
            fit=mem[fm.start():stop]
            rec["completed_fits"]={"span":[fm.start(),stop],"sha256":digest(fit.encode())}
            pieces.append("\n\n## Saved pipeline state: Completed Fits\n\nThe section below is copied verbatim from _working_memory.md; it is saved pipeline state.\n\n~~~~text\n"+fit+"~~~~\n")
        else: rec["completed_fits"]=None
    payload="".join(pieces).encode("utf-8")
    rec["archive_sha256"]=digest(payload)
    fitting_payload="".join(fitting_pieces).encode("utf-8")
    rec["fitting_archive_relative_path"]="fitting_tool_calls_verbatim.md"
    rec["fitting_archive_sha256"]=digest(fitting_payload)
    rec["fit_call_count"]=len(rec["fitting_calls"])
    backup=PRIVATE/"backups"/digest(target.relative_to(BASE).as_posix().encode("utf-8"))
    rec["backup_dir"]=str(backup)
    rec["backup_sources"]=[]
    old=target/"run_history.md"; out=target/"run_history_verbatim.md"
    if apply:
        for p in (src/"run_history.md",src/"final_full_context.md",memfile if mb is not None else None,old if old.is_file() else None):
            if p is None: continue
            dest=backup/("artifact_run_history.md" if p==old else p.name)
            dest.parent.mkdir(parents=True,exist_ok=True)
            raw=p.read_bytes()
            if dest.is_file() and dest.read_bytes()!=raw: raise ValueError("backup mismatch: "+str(dest))
            dest.write_bytes(raw)
            if digest(dest.read_bytes())!=digest(raw): raise ValueError("backup failed: "+str(dest))
            rec["backup_sources"].append({"source":str(p),"backup":str(dest),"sha256":digest(raw)})
    for name in ("data","plots"):
        if apply: (target/name).mkdir(parents=True,exist_ok=True)
        folder=src/name
        if not folder.is_dir():
            rec.setdefault("no_native_outputs",[]).append(name)
            if apply: (target/name).mkdir(parents=True,exist_ok=True)
            continue
        for p in folder.rglob("*"):
            if not p.is_file(): continue
            rel=p.relative_to(folder); dest=target/name/rel
            check=digest(p.read_bytes())
            rec["files"].append({"path":str(Path(name)/rel),"sha256":check})
            if apply:
                dest.parent.mkdir(parents=True,exist_ok=True)
                if dest.is_file() and digest(dest.read_bytes())!=check: raise ValueError("existing file differs: "+str(dest))
                shutil.copyfile(p,dest)
                if digest(dest.read_bytes())!=check: raise ValueError("copy failed: "+str(dest))
    link_fit_files(rec,h,ct)
    if apply:
        target.mkdir(parents=True,exist_ok=True)
        if out.is_file() and digest(out.read_bytes())!=digest(payload):
            prior=out.read_bytes()
            prior_backup=backup/("archive_prior_"+digest(prior)[:16]+".md")
            prior_backup.parent.mkdir(parents=True,exist_ok=True)
            if prior_backup.is_file() and prior_backup.read_bytes()!=prior: raise ValueError("prior archive backup differs")
            prior_backup.write_bytes(prior)
            if digest(prior_backup.read_bytes())!=digest(prior): raise ValueError("prior archive backup failed")
        if not out.is_file() or digest(out.read_bytes())!=digest(payload):
            temporary=out.with_name(".run_history_verbatim.tmp")
            temporary.write_bytes(payload)
            os.replace(temporary,out)
        if digest(out.read_bytes())!=rec["archive_sha256"]: raise ValueError("archive write failed")
        fitting_out=target/"fitting_tool_calls_verbatim.md"
        if fitting_out.is_file() and digest(fitting_out.read_bytes())!=digest(fitting_payload):
            prior=fitting_out.read_bytes()
            saved=backup/("fitting_archive_prior_"+digest(prior)[:16]+".md")
            saved.parent.mkdir(parents=True,exist_ok=True)
            if saved.is_file() and saved.read_bytes()!=prior: raise ValueError("prior fitting archive backup differs")
            saved.write_bytes(prior)
            if digest(saved.read_bytes())!=digest(prior): raise ValueError("prior fitting archive backup failed")
        if not fitting_out.is_file() or digest(fitting_out.read_bytes())!=digest(fitting_payload):
            temporary=fitting_out.with_name(".fitting_tool_calls_verbatim.tmp")
            temporary.write_bytes(fitting_payload)
            os.replace(temporary,fitting_out)
        if digest(fitting_out.read_bytes())!=rec["fitting_archive_sha256"]: raise ValueError("fitting archive write failed")
        if old.is_file(): old.unlink()
        legacy=target/"result.md"
        if legacy.is_file():
            raw=legacy.read_bytes()
            saved=backup/"legacy_artifact_result.md"
            saved.parent.mkdir(parents=True,exist_ok=True)
            if saved.is_file() and saved.read_bytes()!=raw: raise ValueError("legacy result backup differs")
            saved.write_bytes(raw)
            if digest(saved.read_bytes())!=digest(raw): raise ValueError("legacy result backup failed")
            rec["removed_legacy_artifact"]={"name":"result.md","sha256":digest(raw)}
            legacy.unlink()
        extras=[x.name for x in target.iterdir() if x.name not in ("data","plots","run_history_verbatim.md","fitting_tool_calls_verbatim.md")]
        if extras: raise ValueError("unexpected session artifacts: "+str(target)+" "+repr(extras))
    return rec
def assemble_all(base: Path, private: Path, apply: bool=True) -> dict:
    """Assemble every active direct Analysis and Main nested Analysis archive."""
    global BASE, PRIVATE
    previous=(BASE,PRIVATE)
    BASE=extended_path(base)
    PRIVATE=extended_path(private)
    try:
        records=[run(t,s,apply) for t,s in sessions()]
        report={"applied":apply,"sessions":len(records),"steps":sum(len(r["steps"]) for r in records),
                "gaps":sum(len(r["gaps"]) for r in records),"records":records}
        PRIVATE.mkdir(parents=True,exist_ok=True)
        receipt=PRIVATE/("receipt_applied.json" if apply else "receipt_dry_run.json")
        receipt.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
        report["receipt"]=str(receipt)
        return report
    finally:
        BASE,PRIVATE=previous

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--base",type=Path,default=BASE)
    ap.add_argument("--private",type=Path,default=PRIVATE)
    ap.add_argument("--apply",action="store_true")
    a=ap.parse_args()
    r=assemble_all(a.base,a.private,a.apply)
    print(json.dumps({k:r[k] for k in ("sessions","steps","gaps","receipt")}))

if __name__=="__main__": main()
