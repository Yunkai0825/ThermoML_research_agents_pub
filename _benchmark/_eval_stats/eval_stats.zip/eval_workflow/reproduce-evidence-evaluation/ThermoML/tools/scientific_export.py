"""Stage one canonical scientific claim_review.json with truthful review provenance."""
from __future__ import annotations
import argparse
import collections
import json
from pathlib import Path
from canonical_export import encoded, scientific_document
from review_contract import read, sha
from cache_compatibility import receipt_path as cache_receipt_path, validate as validate_cache

def stage_scientific(original_review: Path, accepted_review: Path, result: Path,
                     out: Path, root_evidence: Path, methods: Path,
                     numeric_evaluation: Path):
    if not numeric_evaluation.is_file():
        raise ValueError("frozen canonical numeric evaluation required before scientific identity join")
    numeric = read(numeric_evaluation)
    if numeric.get("schema") not in {"thermoml-benchmark-eval/2", "thermoml-benchmark-eval/3"}:
        raise ValueError("numeric evaluation schema invalid")
    answer_meta = numeric.get("answer", {})
    blind_id = answer_meta.get("blind_id")
    canonical_id = answer_meta.get("answer_id")
    if not blind_id or not canonical_id or answer_meta.get("result_sha256") != sha(result):
        raise ValueError("numeric identity/result binding invalid")
    evaluated_name = answer_meta.get("evaluated_answer_file")
    if evaluated_name != "evaluated_answer.md":
        raise ValueError("numeric evaluated source file binding invalid")
    evaluated_answer = numeric_evaluation.parent / evaluated_name
    if not evaluated_answer.is_file() or answer_meta.get("evaluated_answer_sha256") != sha(evaluated_answer):
        raise ValueError("numeric evaluated source bytes invalid")
    if out.name != "claim_review.json" or out.parent.resolve() != numeric_evaluation.parent.resolve():
        raise ValueError("scientific output must share canonical numeric staging folder")
    if original_review.parent.resolve() != accepted_review.parent.resolve() or root_evidence.parent.resolve() != original_review.parent.resolve():
        raise ValueError("scientific review and root evidence must share one opaque answer directory")
    original = read(original_review)
    run_root = original_review.resolve().parents[2]
    cache_path = cache_receipt_path(run_root, "scientific-reviewer", blind_id)
    if cache_path.is_file():
        root_run = read(run_root / "results" / "ROOT_ACCEPTANCE.json")
        audits = [a for a in root_run.get("unit_audits", [])
                  if isinstance(a, dict) and a.get("blind_id") == blind_id]
        if len(audits) != 1:
            raise ValueError("cached scientific review lacks one root unit audit")
        cache = validate_cache(run_root, "scientific-reviewer", blind_id,
                               evaluated_answer, original_review, methods, audits[0])
        if (original.get("answer_id") != cache["historical_id"]
                or original.get("source_sha256") != sha(evaluated_answer)):
            raise ValueError("historical scientific original does not match accepted answer bytes")
    elif (original.get("answer_id") != blind_id
          or original.get("source_sha256") != sha(evaluated_answer)
          or original.get("methods_sha256") != sha(methods)):
        raise ValueError("initial scientific review does not match numeric blind answer/method")
    source_hash = sha(original_review)
    accepted_hash = sha(accepted_review)
    root = read(root_evidence)
    root_hash = sha(root_evidence)
    if root.get("source_review_sha256") != source_hash:
        raise ValueError("root evidence does not identify initial scientific review")
    if root.get("accepted_review_sha256") != accepted_hash:
        raise ValueError("root evidence does not identify accepted scientific review")
    if cache_path.is_file() and root.get("cache_compatibility_receipt_sha256") != sha(cache_path):
        raise ValueError("scientific root evidence does not bind historical cache receipt")
    if root.get("complete_source_and_claims_reviewed") is not True:
        raise ValueError("root scientific evidence review incomplete")
    review = read(accepted_review)
    if review.get("answer_id") != blind_id:
        raise ValueError("accepted scientific review does not match numeric blind answer")
    if review.get("source_sha256") != sha(evaluated_answer):
        raise ValueError("scientific review answer hash differs from evaluated_answer.md")
    if review.get("methods_sha256") != sha(methods):
        raise ValueError("accepted scientific methods hash mismatch")
    resolved = review.get("claims", [])
    unresolved = review.get("unresolved_claims", [])
    if not isinstance(resolved, list) or not isinstance(unresolved, list):
        raise ValueError("accepted scientific claim ledgers must be lists")
    if review.get("resolved_claim_count") != len(resolved) or review.get("unresolved_claim_count") != len(unresolved):
        raise ValueError("accepted scientific claim counts mismatch")
    categories = collections.Counter()
    identifiers = []
    for claim in resolved:
        category = claim.get("category")
        if category not in {"database_verified", "domain_knowledge", "incorrect"}:
            raise ValueError("accepted scientific category invalid")
        if claim.get("incorrect") != (category == "incorrect") or not claim.get("reason") or not claim.get("evidence"):
            raise ValueError("accepted scientific claim lacks category/evidence consistency")
        categories[category] += 1
        identifiers.append(claim.get("claim_id"))
    for claim in unresolved:
        if "category" in claim or "claim_id" in claim or not claim.get("reason") or not claim.get("evidence"):
            raise ValueError("unresolved scientific assertion has fabricated category or lacks evidence")
        identifiers.append(claim.get("unresolved_id"))
    if any(not value for value in identifiers) or len(identifiers) != len(set(identifiers)):
        raise ValueError("scientific claim identifiers missing or duplicate")
    try:
        claimed_counts = {k: int(v) for k, v in review.get("claim_counts", {}).items() if int(v)}
    except (ValueError, TypeError):
        raise ValueError("accepted scientific category counts invalid")
    if claimed_counts != dict(categories):
        raise ValueError("accepted scientific category counts mismatch")
    doc = scientific_document({**review, "answer_id": canonical_id}, result, source_hash,
                              root_hash, evaluated_answer)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(encoded(doc))
    return {"status": "STAGED", "claim_review": str(out), "source_review_sha256": source_hash,
            "root_review_sha256": root_hash, "accepted_review_sha256": accepted_hash}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--original-review", type=Path, required=True)
    parser.add_argument("--accepted-review", type=Path, required=True)
    parser.add_argument("--root-evidence", type=Path, required=True)
    parser.add_argument("--methods", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--numeric-evaluation", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(stage_scientific(args.original_review, args.accepted_review, args.result,
                                      args.out, args.root_evidence, args.methods,
                                      args.numeric_evaluation), ensure_ascii=False, indent=2))

