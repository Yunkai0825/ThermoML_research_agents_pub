"""Rebind accepted private inspection locators to published native session artifacts."""
import argparse,copy,csv,io,json,re,hashlib
from pathlib import Path
from filesystem_paths import io_path
from artifact_source import sha

def rebind(document, packet, public_artifacts):
    packet=io_path(packet);public_artifacts=io_path(public_artifacts); mappings={};cache={}
    manifest=json.loads((packet/'BLIND_INPUT.json').read_text(encoding='utf-8-sig'))
    entries={item['path']:item for item in manifest['artifact_files']}
    if len(entries)!=len(manifest['artifact_files']):raise ValueError('duplicate inspected artifact paths')
    def target(relative):
        if relative.startswith('source_session/main/'):return relative[len('source_session/main/'):]
        if relative.startswith('published_native/'):return relative[len('published_native/'):] 
        return relative
    def binding(relative):
        if relative in cache:return cache[relative]
        old=packet/'artifacts'/relative;new_relative=target(relative)
        if '/fixed_tool_returns/' not in relative and not relative.endswith('/completed_fits.txt'):
            new=public_artifacts/new_relative
            if sha(old)!=sha(new):raise ValueError('published native artifact bytes differ: '+relative)
            value={'path':new_relative,'sha256':sha(new),'text':new.read_text(encoding='utf-8-sig') if new.suffix.lower() not in {'.png','.pdf'} else None,'start':1,'end':None}
        else:
            parent=Path(new_relative).parent
            if parent.name=='fixed_tool_returns':parent=parent.parent
            new_relative=(parent/('run_history_verbatim.md' if relative.endswith('/completed_fits.txt') else 'fitting_tool_calls_verbatim.md')).as_posix();new=public_artifacts/new_relative;text=new.read_text(encoding='utf-8-sig')
            oldtext=old.read_text(encoding='utf-8-sig')
            match=re.search(r'tool_step_(\d+)_(.+?)(?:_call_(\d+))?(_arguments)?\.(?:txt|json)$',old.name)
            origin=entries[relative].get('eligibility',{})
            identity=origin.get('call_identity')
            if identity is not None:
                if not match or int(match[1])!=identity.get('step') or match[2]!=identity.get('tool'):
                    raise ValueError('fixed-return filename and call identity differ: '+relative)
                if match[3] is not None and int(match[3])!=identity.get('occurrence'):
                    raise ValueError('fixed-return occurrence filename and source identity differ: '+relative)
                span=origin.get('source_span');fragment_hash=origin.get('source_fragment_sha256')
                if (not isinstance(span,list) or len(span)!=2 or any(type(v) is not int for v in span)
                        or span[0]<0 or span[1]<=span[0] or span[1]>len(text)):
                    raise ValueError('fixed-return source span missing or invalid: '+relative)
                body=text[span[0]:span[1]]
                if hashlib.sha256(body.encode('utf-8')).hexdigest()!=fragment_hash or sha(new)!=origin.get('source_sha256'):
                    raise ValueError('fixed-return source hash differs: '+relative)
                headers=list(re.finditer(r'^### Step (\d+)[^\n]*: `([^`]+)`[^\n]*$',text,re.M))
                matches=[(i,h) for i,h in enumerate(headers) if int(h[1])==identity['step'] and h[2]==identity['tool']]
                occurrence=identity.get('occurrence')
                if type(occurrence) is not int or occurrence<1 or occurrence>len(matches):
                    raise ValueError('fixed-return source occurrence missing: '+relative)
                index,header=matches[occurrence-1]
                stop=headers[index+1].start() if index+1<len(headers) else len(text)
                if not header.end()<=span[0]<span[1]<=stop:
                    raise ValueError('fixed-return source span belongs to another call: '+relative)
                if old.suffix=='.json':
                    actual=json.loads(body);wanted=json.loads(oldtext)
                    if not isinstance(actual,dict) or not isinstance(wanted,dict) or any(actual.get(k)!=v for k,v in wanted.items()):
                        raise ValueError('fixed-return arguments differ from bound call: '+relative)
                elif oldtext!=body+'\n':
                    raise ValueError('fixed-return Result differs from bound call: '+relative)
                offset=span[0]
            elif old.suffix=='.json' and match:
                wanted=json.loads(oldtext);found=[]
                headers=list(re.finditer(r'^### Step (\d+)[^\n]*: `([^`]+)`[^\n]*$',text,re.M))
                for i,h in enumerate(headers):
                    if int(h[1])!=int(match[1]) or h[2]!=match[2]:continue
                    block=text[h.end():headers[i+1].start() if i+1<len(headers) else len(text)]
                    a=re.search(r'<details><summary>Arguments</summary>\s*\n\s*```json\s*\n(.*?)\n```',block,re.S)
                    if not a:continue
                    try:actual=json.loads(a[1])
                    except ValueError:continue
                    if all(actual.get(k)==v for k,v in wanted.items()):found.append((h.end()+a.start(1),a[1]))
                if len(found)!=1:raise ValueError('public argument binding ambiguous: '+relative)
                offset,body=found[0]
            elif relative.endswith('/completed_fits.txt'):
                offset=text.index('### Completed Fits',text.index('## Saved pipeline state: Completed Fits'));body=text[offset:];body=body.split('\n~~~~',1)[0]
            else:
                body=oldtext.rstrip('\n');positions=[m.start() for m in re.finditer(re.escape(body),text)]
                if match:
                    headers=list(re.finditer(r'^### Step (\d+)[^\n]*: `([^`]+)`[^\n]*$',text,re.M))
                    windows=[(h.end(),headers[i+1].start() if i+1<len(headers) else len(text)) for i,h in enumerate(headers) if int(h[1])==int(match[1]) and h[2]==match[2] and 'VALIDATION BLOCKED' not in h.group()]
                    positions=[pos for pos in positions if any(lo<=pos<hi for lo,hi in windows)]
                if len(positions)!=1:raise ValueError('public fixed result binding ambiguous: '+relative)
                offset=positions[0]
            start=text[:offset].count('\n')+1
            value={'path':new_relative,'sha256':sha(new),'text':text,'body':body,'start':start,'end':start+body.count('\n')}
            if identity is not None:
                value.update(call_identity=identity,source_span=span,source_fragment_sha256=fragment_hash)
        mappings[relative]={k:v for k,v in value.items() if k not in {'text','body'}};cache[relative]=value;return value
    # Bind every inspected file so textual evidence and plot locators can also resolve.
    for entry in manifest['artifact_files']:binding(entry['path'])
    def walk(node):
        if isinstance(node,list):return [walk(x) for x in node]
        if isinstance(node,dict):
            out={k:walk(v) for k,v in node.items()}
            relative=node.get('path')
            if relative in cache:
                b=cache[relative];out['path']=b['path'];out['sha256']=b['sha256']
                if 'arguments_excerpt' in node:
                    excerpt=node['arguments_excerpt']
                    if excerpt not in b['text']:
                        if relative.endswith('_arguments.json'):out['arguments_excerpt']=b['body']
                        else:raise ValueError('generating call arguments absent from public source')
                    out['line_start']=b['start'];out['line_end']=b['end']
                if node.get('format')=='text':
                    line=node['excerpt'];matches=[i+1 for i,s in enumerate(b['text'].splitlines()) if s==line and b['start']<=i+1<=(b['end'] or 10**9)]
                    original_lines=(packet/'artifacts'/relative).read_text(encoding='utf-8-sig').splitlines()
                    occurrence=sum(1 for value in original_lines[:node['line']] if value==line)-1
                    if occurrence<0 or occurrence>=len(matches):raise ValueError('text numeric locator absent in bound source')
                    if len(matches)>1 and not relative.endswith('/completed_fits.txt'):raise ValueError('text numeric locator ambiguous in bound source')
                    out['line']=matches[occurrence];out['excerpt']=line
                elif 'excerpt' in node:
                    if node['excerpt'] not in b['text']:
                        if relative.endswith('_arguments.json'):out['excerpt']=b['body']
                        else:raise ValueError('metadata excerpt absent from public source: '+relative)
                    out['line_start']=b['start'];out['line_end']=b['end']
                elif node.get('format')=='json' and b.get('body'):
                    raise ValueError('numeric JSON selector into archived arguments requires explicit text binding')
                if node.get('stored_value') is not None:
                    if out['format']=='csv':stored=list(csv.DictReader(io.StringIO(b['text'])))[out['row']-1][out['field']]
                    elif out['format']=='text':
                        line=b['text'].splitlines()[out['line']-1];hits=list(re.finditer(out['pattern'],line));assert len(hits)==1;stored=hits[0]['value']
                    else:raise ValueError('unsupported published numerical selector')
                    if str(stored)!=str(node['stored_value']):raise ValueError('public locator changed inspected stored value')
            return out
        if isinstance(node,str):
            hits=[p for p in cache if p in node]
            if hits and any('/fixed_tool_returns/' in p or p.endswith('/completed_fits.txt') for p in hits):
                return '; '.join(f"{cache[p]['path']} lines {cache[p]['start']}-{cache[p]['end']}; SHA256 {cache[p]['sha256']}; original inspected source {Path(p).name}" for p in hits)
            for p in sorted(hits,key=len,reverse=True):node=node.replace(p,cache[p]['path'])
            return node
        return node
    result=walk(copy.deepcopy(document))
    for e in result['excerpts']:
        for row in e['values']:
            if row.get('group')=='pipeline_artifact' and row.get('artifact_reference'):
                for context in row['artifact_reference'].get('source_context',[]):
                    text=(public_artifacts/context['path']).read_text(encoding='utf-8-sig')
                    if context['excerpt'] not in text:raise ValueError('public context excerpt failed')
    return result,{'status':'PASS','published_artifact_bindings':mappings,'numeric_values_unchanged':True}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--evaluation',type=Path,required=True);p.add_argument('--packet',type=Path,required=True);p.add_argument('--public-artifacts',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--receipt',type=Path,required=True);a=p.parse_args()
    d,r=rebind(json.loads(a.evaluation.read_text(encoding='utf-8-sig')),a.packet,a.public_artifacts)
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');a.receipt.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'status':r['status'],'bindings':len(r['published_artifact_bindings'])}))
