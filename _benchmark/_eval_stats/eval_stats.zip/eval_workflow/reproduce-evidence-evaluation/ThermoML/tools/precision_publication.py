"""Publish a precision-only canonical package while preserving existing evidence."""
from pathlib import Path
import hashlib,os
from filesystem_paths import io_path
from accepted_stats import validate_package

def publish(staged,destination,backup,benchmark_root,expected_before_sha256):
    staged,destination,backup=map(io_path,(staged,destination,backup))
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    if sha(destination/'evaluation.json')!=expected_before_sha256:raise ValueError('live evaluation changed since acceptance')
    if (staged/'evaluated_answer.md').read_bytes()!=(destination/'evaluated_answer.md').read_bytes():raise ValueError('precision update cannot change evaluated answer')
    present=(destination/'claim_review.json').is_file()
    if present:
        preserved=(destination/'claim_review.json').read_bytes()
        if (staged/'claim_review.json').exists() and (staged/'claim_review.json').read_bytes()!=preserved:raise ValueError('scientific review changed')
        (staged/'claim_review.json').write_bytes(preserved)
    # This mode validates existing claims structurally; it never dispatches a
    # scientific reviewer or creates new scientific content.
    validate_package(staged,present,benchmark_root)
    validate_package(destination,present,benchmark_root)
    before={p.name:sha(p) for p in destination.iterdir() if p.is_file()}
    backup.mkdir(parents=True,exist_ok=True)
    for p in destination.iterdir():
        if p.is_file():
            target=backup/p.name
            if target.exists() and target.read_bytes()!=p.read_bytes():raise ValueError('backup already binds different bytes')
            target.write_bytes(p.read_bytes())
    temp=destination/'.evaluation.precision.tmp'
    if temp.exists():raise ValueError('unfinished publication temporary file')
    temp.write_bytes((staged/'evaluation.json').read_bytes());os.replace(temp,destination/'evaluation.json')
    validate_package(destination,present,benchmark_root)
    after={p.name:sha(p) for p in destination.iterdir() if p.is_file()}
    if set(before)!=set(after) or any(after[k]!=v for k,v in before.items() if k!='evaluation.json'):raise ValueError('preserved package changed')
    return {'before':before,'after':after,'preserved_scientific_package_validated':present,'scientific_generation':False}
