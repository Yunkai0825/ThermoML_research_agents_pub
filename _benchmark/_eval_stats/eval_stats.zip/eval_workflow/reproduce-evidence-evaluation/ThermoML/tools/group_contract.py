"""Public-only group validation for both singleton and multi-answer reconciliation.

A group is a read allowlist and a return binder. This module does not choose
verdicts, inspect private source identities, dispatch workers, or accept output.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

from review_contract import reconciliation_check
from run_settings import read_settings
from screen import INITIAL_FILES

GROUP_SCHEMA = "evidence-evaluation-group/1"
RETURN_SCHEMA = "evidence-evaluation-group-return/1"
GUIDANCE_SCHEMA = "evidence-evaluation-guidance/1"
ID = re.compile(r"[A-Za-z0-9_-]+\Z")
SHA = re.compile(r"[0-9a-f]{64}\Z")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _digest(value: object) -> str:
    data = json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def _unique_pairs(pairs: list[tuple]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _read(path: Path):
    if not path.is_file():
        raise ValueError(f"required file missing: {path}")
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"),
                          object_pairs_hook=_unique_pairs)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid JSON: {path}") from exc


def _id(value: object, kind: str) -> str:
    if not isinstance(value, str) or not ID.fullmatch(value):
        raise ValueError(f"invalid {kind}: {value!r}")
    return value


def _sha(value: object, kind: str) -> str:
    if not isinstance(value, str) or not SHA.fullmatch(value):
        raise ValueError(f"invalid {kind} SHA256")
    return value


def _exact(obj: object, fields: set[str], kind: str) -> dict:
    if not isinstance(obj, dict) or set(obj) != fields:
        raise ValueError(f"{kind} must have exactly {sorted(fields)}")
    return obj


def _scoped_file(path: Path, expected: Path) -> Path:
    """Reject symlinked manifests/inputs that escape the declared read slot."""
    try:
        actual = path.resolve(strict=True)
    except OSError as exc:
        raise ValueError(f"required file missing: {path}") from exc
    if actual != expected.absolute():
        raise ValueError(f"scoped path changed or escapes its slot: {path}")
    return actual


def _units(run_root: Path) -> list[dict]:
    units_path = run_root / "reconciliation" / "units.json"
    units = _read(_scoped_file(units_path, units_path))
    if not isinstance(units, list) or not units:
        raise ValueError("reconciliation/units.json must be a nonempty array")
    seen_ids, seen_units = set(), set()
    for unit in units:
        _exact(unit, {"blind_id", "review_unit_id"}, "review unit")
        bid = _id(unit["blind_id"], "blind_id")
        uid = _id(unit["review_unit_id"], "review_unit_id")
        if bid in seen_ids or uid in seen_units:
            raise ValueError("duplicate blind or review unit ID")
        seen_ids.add(bid)
        seen_units.add(uid)
    return units


def _question_hashes(manifest: dict, members: list[dict]) -> dict[str, str]:
    """Bind each member to its own original question, with an optional exception."""
    bids = [member["blind_id"] for member in members]
    if "question_exception" not in manifest:
        _exact(manifest, {"schema", "group_id", "question_sha256", "members"},
               "group manifest")
        question_sha = _sha(manifest["question_sha256"], "question")
        return {bid: question_sha for bid in bids}
    _exact(manifest, {"schema", "group_id", "question_sha256", "question_exception",
                      "members"}, "exception group manifest")
    if manifest["question_sha256"] is not None:
        raise ValueError("exception group question_sha256 must be null")
    exception = _exact(
        manifest["question_exception"],
        {"id", "authorization_source", "authorization_quote", "reason",
         "member_question_sha256"}, "question exception")
    _id(exception["id"], "question exception ID")
    for field in ("authorization_source", "authorization_quote", "reason"):
        value = exception[field]
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"question exception {field} must be nonempty")
    hashes = exception["member_question_sha256"]
    if not isinstance(hashes, dict) or set(hashes) != set(bids):
        raise ValueError("question exception must bind every declared member exactly")
    return {bid: _sha(hashes[bid], f"question exception member {bid}")
            for bid in bids}


def validate_question_authorization(run_root: Path,
                                    group_manifest_path: Path) -> dict:
    """Orchestrator gate: require the exact exception in the run contract."""
    run_root = Path(run_root).resolve(strict=True)
    checked = validate_group(run_root, group_manifest_path)
    manifest = _read(Path(group_manifest_path))
    exception = manifest.get("question_exception")
    if exception is None:
        return checked
    contract_path = run_root / "control" / "RUN_CONTRACT.json"
    contract = _read(_scoped_file(contract_path, contract_path))
    groups = contract.get("groups") if isinstance(contract, dict) else None
    authorized = groups.get("authorized_question_exceptions") if isinstance(groups, dict) else None
    if (not isinstance(authorized, dict)
            or authorized.get(exception["id"]) != exception):
        raise ValueError("question exception lacks exact run-contract authorization")
    return checked


def _member_inputs(run_root: Path, member: dict, question_sha: str) -> str:
    bid, uid = member["blind_id"], member["review_unit_id"]
    packet = run_root / "public" / "maps" / bid
    screen_dir = run_root / "screening" / uid
    question_path = _scoped_file(packet / "question.md", packet / "question.md")
    if sha(question_path) != question_sha:
        raise ValueError(f"mixed original questions in group: {bid}")
    hashes = {name: sha(_scoped_file(packet / name, packet / name))
              for name in INITIAL_FILES}
    receipt_path = _scoped_file(packet / "BLIND_INPUT.json",
                                packet / "BLIND_INPUT.json")
    receipt = _read(receipt_path)
    if not isinstance(receipt, dict) or not isinstance(receipt.get("schema"), str):
        raise ValueError(f"invalid public clean-packet receipt: {bid}")
    if (receipt.get("answer_id") != bid
            or receipt.get("packet_answer_sha256") != hashes["answer.md"]
            or receipt.get("question_sha256") != sha(question_path)
            or receipt.get("tokens_sha256") != hashes["tokens.json"]
            or receipt.get("annotated_sha256") != sha(_scoped_file(
                packet / "annotated.txt", packet / "annotated.txt"))):
        raise ValueError(f"stale clean-packet receipt: {bid}")
    artifacts = receipt.get("artifact_files")
    if not isinstance(artifacts, list):
        raise ValueError(f"invalid support artifact list: {bid}")
    seen_artifacts = set()
    for item in artifacts:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            raise ValueError(f"invalid support artifact: {bid}")
        relative = Path(item["path"])
        if (relative.is_absolute() or not relative.parts
                or any(part in {".", ".."} for part in relative.parts)
                or relative.as_posix() in seen_artifacts):
            raise ValueError(f"invalid support artifact path: {bid}")
        seen_artifacts.add(relative.as_posix())
        artifact = packet / "artifacts" / relative
        resolved = artifact.resolve(strict=True)
        if not resolved.is_relative_to((packet / "artifacts").resolve()):
            raise ValueError(f"support artifact escapes packet: {bid}")
        if item.get("use") != "pipeline_artifact_and_source_evidence" or item.get("sha256") != sha(artifact):
            raise ValueError(f"stale support artifact: {bid}")
    check_path = _scoped_file(screen_dir / "SCREENING_CHECK.json",
                              screen_dir / "SCREENING_CHECK.json")
    requests_path = _scoped_file(screen_dir / "CHECK_REQUESTS.json",
                                 screen_dir / "CHECK_REQUESTS.json")
    check = _read(check_path)
    requests = _read(requests_path)
    if not isinstance(requests, list):
        raise ValueError(f"screen requests must be an array: {bid}")
    public = run_root / "public"
    quality = _scoped_file(public / "QUALITY_CHECKS.txt", public / "QUALITY_CHECKS.txt")
    rules = _scoped_file(public / "SCREEN_RULES.txt", public / "SCREEN_RULES.txt")
    code = _scoped_file(public / "tools" / "screen.py", public / "tools" / "screen.py")
    if (not isinstance(check, dict) or check.get("blind_id") != bid
            or check.get("review_unit_id") != uid
            or check.get("status") != "PASS" or check.get("complete") is not True
            or check.get("initial_check_status") not in {"PASS", "PASS_WITH_QUESTIONS"}
            or check.get("verdicts_modified") is not False
            or check.get("initial_file_sha256") != hashes
            or check.get("quality_checks_sha256") != sha(quality)
            or check.get("screen_rules_sha256") != sha(rules)
            or check.get("screen_code_sha256") != sha(code)
            or check.get("requests_sha256") != sha(requests_path)):
        raise ValueError(f"stale or incomplete screen receipt: {bid}")
    guidance_path = _scoped_file(run_root / "guidance" / bid / "GUIDANCE.json",
                                 run_root / "guidance" / bid / "GUIDANCE.json")
    guidance = _read(guidance_path)
    if (not isinstance(guidance, dict)
            or guidance.get("schema") != GUIDANCE_SCHEMA
            or guidance.get("answer_id") != bid
            or guidance.get("answer_sha256") != hashes["answer.md"]
            or guidance.get("initial_file_sha256") != hashes
            or guidance.get("screen_sha256") != sha(check_path)
            or guidance.get("requests_sha256") != sha(requests_path)
            or guidance.get("complete") is not True
            or guidance.get("ready_for_reconciliation") is not True
            or guidance.get("evidence_checked") is not True):
        raise ValueError(f"stale or incomplete orchestrator guidance: {bid}")
    guidance_ids = set()
    for key in ("findings", "user_decisions", "recheck_requests", "pending_questions"):
        if not isinstance(guidance.get(key), list):
            raise ValueError(f"invalid guidance {key}: {bid}")
        for item in guidance[key]:
            evidence = item.get("evidence") if isinstance(item, dict) else None
            valid_evidence = ((isinstance(evidence, str) and bool(evidence.strip()))
                              or (isinstance(evidence, list) and bool(evidence)
                                  and all(isinstance(x, str) and x.strip()
                                          for x in evidence)))
            if (not isinstance(item, dict)
                    or not isinstance(item.get("id"), str)
                    or not item["id"].strip() or item["id"] in guidance_ids
                    or not valid_evidence):
                raise ValueError(f"guidance entries need unique IDs and evidence: {bid}")
            guidance_ids.add(item["id"])
    for question in guidance["pending_questions"]:
        if (not isinstance(question, dict)
                or not all(isinstance(question.get(key), str) and question[key].strip()
                           for key in ("id", "quote", "evidence"))
                or not isinstance(question.get("options"), list)
                or len(question["options"]) < 2
                or not all(isinstance(option, str) and option.strip()
                           for option in question["options"])):
            raise ValueError(f"invalid pending user question: {bid}")
    # Hash exact bytes, not parsed semantics: a changed packet/screen/guidance
    # cannot silently reuse a sealed group return.
    inputs = {"blind_input_sha256": sha(receipt_path),
              "annotated_sha256": sha(packet / "annotated.txt"),
              "initial_file_sha256": hashes,
              "question_sha256": sha(question_path),
              "screen_sha256": sha(check_path),
              "requests_sha256": sha(requests_path),
              "guidance_sha256": sha(guidance_path)}
    return _digest(inputs)


def _guidance_response_check(guidance: dict, decision: dict, bid: str) -> None:
    entries = [item for key in ("findings", "user_decisions", "recheck_requests",
                                "pending_questions") for item in guidance[key]]
    expected = {item["id"] for item in entries}
    responses = decision.get("guidance_responses", [])
    if not isinstance(responses, list):
        raise ValueError(f"guidance responses must be an array: {bid}")
    actual = []
    for row in responses:
        if (not isinstance(row, dict) or not isinstance(row.get("id"), str)
                or row.get("status") not in {"resolved", "needs_decision"}
                or not isinstance(row.get("reason"), str) or not row["reason"].strip()
                or not isinstance(row.get("evidence"), list) or not row["evidence"]
                or not all(isinstance(x, str) and x.strip()
                           for x in row["evidence"])):
            raise ValueError(f"invalid guidance response: {bid}")
        actual.append(row["id"])
    if len(actual) != len(set(actual)) or set(actual) != expected:
        raise ValueError(f"guidance responses omit, duplicate or invent IDs: {bid}")
    pending = {row["id"] for row in responses if row["status"] == "needs_decision"}
    unresolved = decision.get("unresolved_questions", [])
    if not isinstance(unresolved, list):
        raise ValueError(f"invalid unresolved questions: {bid}")
    linked = {row.get("guidance_id") for row in unresolved
              if isinstance(row, dict) and isinstance(row.get("guidance_id"), str)}
    if not pending.issubset(linked):
        raise ValueError(f"pending guidance response lacks unresolved question link: {bid}")


def _check_decision(run_root: Path, member: dict) -> str:
    bid, uid = member["blind_id"], member["review_unit_id"]
    packet = run_root / "public" / "maps" / bid
    decision_path = _scoped_file(
        run_root / "reconciliation" / uid / "reconciliation.json",
        run_root / "reconciliation" / uid / "reconciliation.json")
    decision = _read(decision_path)
    guidance = _read(run_root / "guidance" / bid / "GUIDANCE.json")
    _guidance_response_check(guidance, decision, bid)
    public = run_root / "public"
    screen_dir = run_root / "screening" / uid
    result = reconciliation_check(
        packet, member, decision, public / "RUBRIC.txt",
        public / "HUMAN_INTERPRETATIONS.txt", public / "QUALITY_CHECKS.txt",
        screen_dir / "CHECK_REQUESTS.json", screen_dir / "SCREENING_CHECK.json",
        public / "SCREEN_RULES.txt", public / "tools" / "screen.py")
    if result.get("status") not in {"PASS", "PASS_WITH_QUESTIONS"} or result.get("errors"):
        raise ValueError(f"reconciliation check failed: {bid}: {result.get('errors')}")
    return sha(decision_path)


def validate_group(run_root: Path, group_manifest_path: Path,
                   require_returns: bool = False) -> dict:
    """Validate a public-only group; the same path accepts one or many members."""
    run_root = Path(run_root).resolve(strict=True)
    manifest_path = Path(group_manifest_path)
    candidate = manifest_path.resolve(strict=True)
    group_root = run_root / "groups"
    if (not candidate.is_relative_to(group_root) or candidate.name != "group.json"
            or not ID.fullmatch(candidate.parent.name)):
        raise ValueError("group manifest is outside a scoped group directory")
    manifest = _read(candidate)
    fields = ({"schema", "group_id", "question_sha256", "question_exception",
               "members"} if isinstance(manifest, dict)
               and "question_exception" in manifest else
              {"schema", "group_id", "question_sha256", "members"})
    _exact(manifest, fields, "group manifest")
    if manifest["schema"] != GROUP_SCHEMA:
        raise ValueError("group manifest schema mismatch")
    gid = _id(manifest["group_id"], "group_id")
    _scoped_file(manifest_path, run_root / "groups" / gid / "group.json")
    members = manifest["members"]
    if not isinstance(members, list) or not members:
        raise ValueError("group must contain at least one member")
    # This worker-scoped gate reads only the declared group, its member packets,
    # screens, guidance and frozen public methods. Global partition checks belong
    # to validate_groups, which only the orchestrator/export calls.
    seen_ids, seen_units = set(), set()
    for member in members:
        _exact(member, {"blind_id", "review_unit_id"}, "group member")
        bid = _id(member["blind_id"], "blind_id")
        uid = _id(member["review_unit_id"], "review_unit_id")
        if bid in seen_ids or uid in seen_units:
            raise ValueError("duplicate group member or review unit")
        seen_ids.add(bid)
        seen_units.add(uid)
    question_hashes = _question_hashes(manifest, members)
    input_hashes = {
        member["blind_id"]: _member_inputs(
            run_root, member, question_hashes[member["blind_id"]])
        for member in members
    }
    result = {"group_id": gid, "member_ids": [m["blind_id"] for m in members],
              "group_manifest_sha256": sha(manifest_path),
              "member_input_sha256": input_hashes}
    if require_returns:
        return_path = _scoped_file(
            run_root / "groups" / gid / "GROUP_RETURN.json",
            run_root / "groups" / gid / "GROUP_RETURN.json")
        returned = _read(return_path)
        _exact(returned, {"schema", "group_id", "group_manifest_sha256",
                          "member_input_sha256", "decisions", "complete"},
               "group return")
        if (returned["schema"] != RETURN_SCHEMA or returned["group_id"] != gid
                or returned["group_manifest_sha256"] != result["group_manifest_sha256"]
                or returned["member_input_sha256"] != input_hashes
                or returned["complete"] is not True):
            raise ValueError("group return identity or input hash mismatch")
        decisions = returned["decisions"]
        if not isinstance(decisions, list) or len(decisions) != len(members):
            raise ValueError("group return decision coverage mismatch")
        for member, row in zip(members, decisions):
            _exact(row, {"blind_id", "review_unit_id", "decision_sha256"},
                   "group decision")
            if (row["blind_id"] != member["blind_id"]
                    or row["review_unit_id"] != member["review_unit_id"]
                    or row["decision_sha256"] != _check_decision(run_root, member)):
                raise ValueError(f"group decision changed or reordered: {member['blind_id']}")
        result["group_return_sha256"] = sha(return_path)
    return result


def validate_groups(run_root: Path, units: list[dict]) -> dict:
    """Require exact one-time coverage of the run's units by declared groups."""
    run_root = Path(run_root).resolve(strict=True)
    stored_units = _units(run_root)
    if not isinstance(units, list) or units != stored_units:
        raise ValueError("supplied units differ from reconciliation/units.json")
    groups_path = run_root / "reconciliation" / "groups.json"
    declared = _read(_scoped_file(groups_path, groups_path))
    if not isinstance(declared, list) or not declared:
        raise ValueError("reconciliation/groups.json must be a nonempty array")
    if not all(isinstance(g, str) and ID.fullmatch(g) for g in declared):
        raise ValueError("groups.json must contain group IDs")
    if len(declared) != len(set(declared)):
        raise ValueError("duplicate group ID")
    group_root = run_root / "groups"
    existing = {path.name for path in group_root.iterdir()
                if path.is_dir() and (path / "group.json").is_file()} if group_root.is_dir() else set()
    if existing != set(declared):
        raise ValueError("group index omits or invents a scoped group manifest")
    settings = read_settings(run_root)
    expected_pairs = {(u["blind_id"], u["review_unit_id"]) for u in stored_units}
    results, covered, question_groups = {}, [], {}
    for gid in declared:
        manifest = run_root / "groups" / gid / "group.json"
        group = _read(manifest)
        members = group.get("members", []) if isinstance(group, dict) else []
        if (not isinstance(members, list)
                or any(not isinstance(m, dict)
                       or (m.get("blind_id"), m.get("review_unit_id")) not in expected_pairs
                       for m in members)):
            raise ValueError("foreign review unit in group")
        result = validate_question_authorization(run_root, manifest)
        if result["group_id"] != gid:
            raise ValueError("group ID/path mismatch")
        if settings["reconciliation_mode"] == "indiv_recon" and len(result["member_ids"]) != 1:
            raise ValueError("individual mode requires singleton groups")
        results[gid] = result
        question_hashes = set(_question_hashes(group, group["members"]).values())
        if settings["reconciliation_mode"] == "merged_recon":
            for question_sha in question_hashes:
                if question_sha in question_groups:
                    raise ValueError("merged mode split one original question across groups")
                question_groups[question_sha] = gid
        covered.extend((m["blind_id"], m["review_unit_id"]) for m in group["members"])
    expected = [(u["blind_id"], u["review_unit_id"]) for u in stored_units]
    if len(covered) != len(expected) or set(covered) != set(expected):
        raise ValueError("groups do not cover each review unit exactly once")
    return results


def seal_return(run_root: Path, manifest: Path | dict) -> dict:
    """Seal currently valid per-answer decisions; make no evidence judgment."""
    run_root = Path(run_root).resolve(strict=True)
    if isinstance(manifest, dict):
        gid = _id(manifest.get("group_id"), "group_id")
        path = run_root / "groups" / gid / "group.json"
        if _read(path) != manifest:
            raise ValueError("supplied manifest differs from scoped manifest bytes")
    else:
        path = Path(manifest)
    checked = validate_group(run_root, path)
    group = _read(path)
    decisions = []
    for member in group["members"]:
        decisions.append({"blind_id": member["blind_id"],
                          "review_unit_id": member["review_unit_id"],
                          "decision_sha256": _check_decision(run_root, member)})
    value = {"schema": RETURN_SCHEMA, "group_id": checked["group_id"],
             "group_manifest_sha256": checked["group_manifest_sha256"],
             "member_input_sha256": checked["member_input_sha256"],
             "decisions": decisions, "complete": True}
    out = run_root / "groups" / checked["group_id"] / "GROUP_RETURN.json"
    data = (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2)
            + "\n").encode("utf-8")
    if out.exists():
        if out.read_bytes() != data:
            raise ValueError("existing group return differs; refusing overwrite")
    else:
        with out.open("xb") as stream:
            stream.write(data)
    return validate_group(run_root, path, require_returns=True)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("check", "seal-return"):
        item = sub.add_parser(name)
        item.add_argument("--run-root", type=Path, required=True)
        item.add_argument("--group-manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    result = (validate_group(args.run_root, args.group_manifest,
                             require_returns=True)
              if args.command == "check" else
              seal_return(args.run_root, args.group_manifest))
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
