"""General, logged, Decimal-only ThermoML numeric resolution."""
import argparse
import csv
import hashlib
import io
import json
import re
import sqlite3
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal, localcontext
from pathlib import Path

import tml
from artifact_source import resolve_artifact
from compare_core import compare, convert, UNITS
from tokenize_numbers import parsed as parse_display

D = Decimal
def dump(value):
    return json.dumps(value, ensure_ascii=False, default=str, sort_keys=True)

def is_discovery_scope(scope):
    """Discovery records identify search candidates, not mandatory citations."""
    return scope.get('uncited') is True or 'system' in scope

class Archive:
    """Each physical archive/registry read has its complete returned bytes logged."""
    def __init__(self, tag, run_root):
        self.tag = re.sub(r'[^A-Za-z0-9_.-]', '_', tag)
        self.path = run_root / 'public' / 'tools' / 'lookups' / (self.tag + '.jsonl')
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.counter = sum(1 for _ in self.path.open(encoding='utf-8')) if self.path.exists() else 0
        self.lookup_ids = []
        self.papers = {}
        self.registries = {}
        self.reference_index = None
        self.comp_key_cache = {}
        self.system_scope_cache = {}
        self.connection = sqlite3.connect(tml.readonly_uri(tml.RAW), uri=True)
        self.connection.execute('PRAGMA query_only=ON')
        self.query('PRAGMA query_only', [])

    def logged(self, argv, read):
        start = time.perf_counter()
        status = 0
        try:
            result = read()
            output = dump(result)
        except BaseException as exc:
            status = 1
            output = dump({'error': type(exc).__name__, 'message': str(exc)})
            raise
        finally:
            self.counter += 1
            lid = f'{self.tag}-L{self.counter}'
            record = {'id': lid, 'ts': datetime.now(timezone.utc).isoformat(), 'argv': argv,
                      'status': status, 'seconds': time.perf_counter()-start,
                      'output_sha256': hashlib.sha256(output.encode('utf-8')).hexdigest(), 'output': output}
            with self.path.open('a', encoding='utf-8', newline='\n') as handle:
                handle.write(dump(record) + '\n')
            self.lookup_ids.append(lid)
        return result

    def query(self, sql, params):
        return self.logged(['sqlite', str(tml.RAW), sql, *map(str, params)],
                           lambda: self.connection.execute(sql, params).fetchall())

    def registry(self, name):
        if name not in self.registries:
            self.registries[name] = self.logged(['registry', str(tml.REG / name)], lambda: tml.reg(name))
        return self.registries[name]

    def paper(self, reference):
        reference = re.sub(r'^(?:https?://(?:dx\.)?doi\.org/|doi:)', '', reference.strip(), flags=re.I)
        if self.reference_index is None:
            # Index only the normal complete registry schema. On malformed rows,
            # retain the old scan path and its branch-specific failure behavior.
            reg = self.registry('reference_ids.csv')
            by_lit, by_doi = {}, {}
            for row in reg:
                if (not isinstance(row, dict) or not isinstance(row.get('doi'), str)
                        or not isinstance(row.get('lit_num_id'), str)):
                    self.reference_index = False
                    break
                # Both old scans selected the first matching registry row.
                by_lit.setdefault(row['lit_num_id'], row['doi'])
                by_doi.setdefault(row['doi'].casefold(), (row['doi'], row['lit_num_id']))
            else:
                self.reference_index = by_lit, by_doi
        if self.reference_index is False:
            reg = self.registry('reference_ids.csv')
            if reference.startswith('GLOBlit_'):
                matches = [r for r in reg if r['lit_num_id'] == reference]
            else:
                matches = [r for r in reg if r['doi'].casefold() == reference.casefold()]
            doi = matches[0]['doi'] if matches else reference
        else:
            by_lit, by_doi = self.reference_index
            if reference.startswith('GLOBlit_'):
                doi = by_lit.get(reference, reference)
            else:
                match = by_doi.get(reference.casefold())
                doi = match[0] if match is not None else reference
        if doi not in self.papers:
            rows = self.query('SELECT doi, json_data FROM papers WHERE lower(doi) = lower(?)', [doi])
            self.papers[doi] = [(r[0], json.loads(r[1], parse_float=D, parse_int=D)) for r in rows]
        papers = self.papers[doi]
        if not papers:
            return None
        if len(papers) != 1:
            raise ValueError('Multiple archive papers for reference ' + reference)
        doi, data = papers[0]
        if self.reference_index is False:
            lit = next((r['lit_num_id'] for r in reg if r['doi'].casefold() == doi.casefold()), None)
        else:
            match = by_doi.get(doi.casefold())
            lit = match[1] if match is not None else None
        return {'doi': doi, 'paper_id': lit or doi, 'data': data}

    def comp_keys(self, name):
        q = name.strip().casefold()
        if q in self.comp_key_cache:
            return set(self.comp_key_cache[q])
        rows = self.registry('compound_ids.csv')
        keys = {r['inchi_key'] for r in rows if q in {str(r.get(k, '')).casefold() for k in ('comp_num_id','comp_id','common_name','inchi_key')}}
        if not keys:
            keys = {r[0] for r in self.query('SELECT DISTINCT standard_inchi_key FROM compounds WHERE lower(common_name) = ?', [q]) if r[0]}
        self.comp_key_cache[q] = frozenset(keys)
        return set(keys)

    def system_scopes(self, names):
        cache_key = tuple(sorted(name.strip().casefold() for name in names))
        if cache_key in self.system_scope_cache:
            return [dict(scope, blocks=list(scope['blocks'])) for scope in self.system_scope_cache[cache_key]]
        targets = [self.comp_keys(n) for n in names]
        if not names or any(not t for t in targets):
            self.system_scope_cache[cache_key] = []
            return []
        per = []
        for keys in targets:
            found = {}
            for key in sorted(keys):
                for doi, org in self.query('SELECT doi, org_num FROM compounds WHERE standard_inchi_key = ?', [key]):
                    found.setdefault(doi, set()).add(int(org))
            per.append(found)
        papers = set(per[0]).intersection(*(set(p) for p in per[1:]))
        scopes = []
        for doi in sorted(papers):
            selected = []
            for bn, kind, count, orgs_json in self.query('SELECT block_number, block_type, n_components, component_org_nums FROM blocks WHERE doi = ?', [doi]):
                orgs = set(json.loads(orgs_json or '[]'))
                if kind == 'PureOrMixtureData' and len(orgs) == len(names) and all(orgs & p[doi] for p in per):
                    selected.append(int(bn))
            if selected:
                scopes.append({'paper': doi, 'blocks': selected, 'uncited': True})
        self.system_scope_cache[cache_key] = [dict(scope, blocks=list(scope['blocks'])) for scope in scopes]
        return scopes

    def corpus_blocks(self, n_components, property_name):
        # The metadata query is an exact selector and logs every eligible block.
        return self.query('SELECT DISTINCT b.doi, b.block_number, b.n_datapoints, p.prop_number '
                          'FROM blocks b JOIN block_properties p ON p.doi=b.doi AND p.block_number=b.block_number '
                          'AND p.block_type=b.block_type WHERE b.block_type=? AND b.n_components=? AND p.prop_name=? '
                          'ORDER BY b.doi, b.block_number, p.prop_number',
                          ['PureOrMixtureData', n_components, property_name])

    def corpus_blocks_containing(self, component_count, component, property_name, exact=False):
        # Resolve the component through the same canonical InChI-key registry
        # used for exact-system scopes. Match only org numbers actually present
        # in each block, not merely elsewhere in the paper.
        keys = sorted(self.comp_keys(component))
        if not keys:
            return []
        marks = ','.join('?' for _ in keys)
        size_operator = '=' if exact else '>='
        sql = ('SELECT DISTINCT b.doi, b.block_number, b.n_datapoints, p.prop_number '
               'FROM blocks b JOIN block_properties p ON p.doi=b.doi AND p.block_number=b.block_number '
               'AND p.block_type=b.block_type '
               f'WHERE b.block_type=? AND b.n_components{size_operator}? AND p.prop_name=? '
               "AND EXISTS (SELECT 1 FROM json_each(COALESCE(b.component_org_nums,'[]')) org "
               'JOIN compounds c ON c.doi=b.doi AND c.org_num=CAST(org.value AS INTEGER) '
               f'WHERE c.standard_inchi_key IN ({marks})) '
               'ORDER BY b.doi, b.block_number, p.prop_number')
        return self.query(sql, ['PureOrMixtureData', component_count, property_name, *keys])

    def corpus_headers(self, doi, block_numbers):
        marks = ','.join('?' for _ in block_numbers)
        sql = f"""SELECT CAST(json_extract(b.value,'$.nPureOrMixtureDataNumber') AS INTEGER),
                     json_extract(b.value,'$.Variable'), json_extract(b.value,'$.Constraint'),
                     json_extract(b.value,'$.Property')
                  FROM papers paper JOIN json_each(CASE json_type(paper.json_data,'$.PureOrMixtureData')
                         WHEN 'array' THEN json_extract(paper.json_data,'$.PureOrMixtureData')
                         WHEN 'object' THEN json_array(json_extract(paper.json_data,'$.PureOrMixtureData'))
                         ELSE '[]' END) b
                  WHERE paper.doi=? AND CAST(json_extract(b.value,'$.nPureOrMixtureDataNumber') AS INTEGER) IN ({marks})
                  ORDER BY 1"""
        return self.query(sql, [doi, *block_numbers])

    def corpus_points(self, doi, block_numbers):
        marks = ','.join('?' for _ in block_numbers)
        # JSON objects are returned as text, so Python can parse every numeric
        # lexeme with Decimal. No SQLite REAL conversion enters the comparison.
        sql = f"""SELECT CAST(json_extract(b.value,'$.nPureOrMixtureDataNumber') AS INTEGER),
                     CAST(point.key AS INTEGER)+1, json_extract(point.value,'$.VariableValue'),
                     json_extract(point.value,'$.PropertyValue')
                  FROM papers paper JOIN json_each(CASE json_type(paper.json_data,'$.PureOrMixtureData')
                         WHEN 'array' THEN json_extract(paper.json_data,'$.PureOrMixtureData')
                         WHEN 'object' THEN json_array(json_extract(paper.json_data,'$.PureOrMixtureData'))
                         ELSE '[]' END) b
                  JOIN json_each(CASE json_type(b.value,'$.NumValues')
                         WHEN 'array' THEN json_extract(b.value,'$.NumValues')
                         WHEN 'object' THEN json_array(json_extract(b.value,'$.NumValues'))
                         ELSE '[]' END) point
                  WHERE paper.doi=? AND CAST(json_extract(b.value,'$.nPureOrMixtureDataNumber') AS INTEGER) IN ({marks})
                  ORDER BY 1,2"""
        return self.query(sql, [doi, *block_numbers])


UNIT_ALIASES = {'m^2/s':'m2/s', 'm²/s':'m2/s', 'cm^2/s':'cm2/s', 'mm^2/s':'mm2/s', 'J/K/mol': 'J/(mol*K)', 'J/mol/K': 'J/(mol*K)', 'g/cm^3': 'g/cm3', 'kg/m^3': 'kg/m3',
                'm^3/mol': 'm3/mol', 'cm^3/mol': 'cm3/mol', 'mPa s': 'mPa*s', 'Pa s': 'Pa*s',
                'C': 'degC', '°C': 'degC', 'dimensionless': '1', 'mole fraction': 'fraction', 'mass fraction': 'fraction', 'volume fraction': 'fraction'}
UNCERTAINTY_FIELDS = {'nCombExpandUncertValue', 'nCombStdUncertValue', 'nCombUncertValue',
                      'nExpandUncertValue', 'nStdUncertValue', 'nPropRepeatValue', 'nPropDeviceSpecValue'}

def norm_unit(unit):
    return UNIT_ALIASES.get(unit, unit)

def source_unit(name):
    if ',' in name:
        return norm_unit(name.rsplit(',', 1)[1].strip())
    lower = name.casefold()
    if 'fraction' in lower:
        return 'fraction'
    if any(term in lower for term in ('activity', 'coefficient', 'compressibility factor', 'refractive index', 'permittivity', 'equilibrium constant')):
        return '1'
    return None

def frequency_unit(kind, name):
    if kind != 'eMiscellaneous':
        return None
    match = re.fullmatch(r'Frequency,\s*(Hz|kHz|MHz)', str(name or '').strip())
    return match.group(1) if match else None

def numeric(value):
    return value is not None and isinstance(value, (str, int, D)) and bool(re.fullmatch(r'[+\-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+\-]?\d+)?', str(value)))

def org_num(value):
    return None if value is None else int(value)

def digits_of(raw, reported=None):
    if reported is not None:
        return int(reported)
    if not numeric(raw):
        return None
    return len(D(str(raw)).as_tuple().digits)

def property_definitions(block):
    result = []
    for prop in tml.arr(block.get('Property')):
        _, group = tml.one_key(prop.get('Property-MethodID', {}).get('PropertyGroup', {}))
        group = group or {}
        name = group.get('ePropName') or group.get('sPropName') or ''
        result.append({'number': int(prop['nPropNumber']), 'name': name, 'unit': source_unit(name),
                       'phase': prop.get('PropPhaseID', {}).get('ePropPhase'),
                       'presentation': prop.get('ePresentation'),
                       'component_org': org_num(prop.get('Property-MethodID', {}).get('RegNum', {}).get('nOrgNum')),
                       'raw_definition': prop})
    return result

def corpus_phase_matches(requested, stored):
    # ThermoML distinguishes the liquid family from Gas, Glass and Fluid.
    return requested == 'Liquid' and bool(stored) and (stored == 'Liquid' or bool(re.fullmatch(r'Liquid mixture [1-9]\d*', stored)))

def property_matches(definitions, quantity, fallback=None, component_orgs=None):
    wanted = quantity.get('name_contains') or fallback
    selected = [p for p in definitions if not wanted or wanted.casefold() in p['name'].casefold()]
    if quantity.get('property_number') is not None:
        selected = [p for p in selected if p['number'] == int(quantity['property_number'])]
    if quantity.get('phase'):
        selected = [p for p in selected if p['phase'] == quantity['phase']]
    if quantity.get('phase_family'):
        selected = [p for p in selected if corpus_phase_matches(quantity['phase_family'], p['phase'])]
    if quantity.get('presentation'):
        selected = [p for p in selected if p['presentation'] == quantity['presentation']]
    if quantity.get('component') is not None:
        if component_orgs is None:
            raise ValueError('A property component selector requires canonical component org numbers')
        selected = [p for p in selected if p['component_org'] is not None and p['component_org'] in component_orgs]
    return selected

GROUPED_THOUSANDS = re.compile(r'[+\-]?\d{1,3}(?:[ \u00a0\u202f]\d{3})+(?:\.\d+)?')

def grouped_source(tokens, source_token_ids):
    """Recover one grouped-thousands literal from ordered lexical source spans."""
    by_id = {t['token_id']: t for t in tokens}
    if len(source_token_ids) < 2 or len(source_token_ids) != len(set(source_token_ids)):
        raise ValueError('Grouped source requires distinct primary and continuation token IDs')
    if any(tid not in by_id for tid in source_token_ids):
        raise ValueError('Grouped source references an unknown token')
    parts = [by_id[tid] for tid in source_token_ids]
    line = parts[0]['line']
    source = parts[0]['line_text']
    if any(t['line'] != line or t['line_text'] != source for t in parts):
        raise ValueError('Grouped source tokens must share one original line')
    start = int(parts[0]['column']) - 1
    end = int(parts[-1]['end_column']) - 1
    if start < 0 or end > len(source) or any(source[int(t['column'])-1:int(t['end_column'])-1] != t['text'] for t in parts):
        raise ValueError('Grouped source token span disagrees with source text')
    spans = [(int(t['column'])-1, int(t['end_column'])-1) for t in parts]
    if any(left_end >= right_start for (_,left_end),(right_start,_) in zip(spans,spans[1:])):
        raise ValueError('Grouped source tokens are not ordered and space-separated')
    if any(t['line'] == line and start <= int(t['column'])-1 < end and t['token_id'] not in source_token_ids for t in tokens):
        raise ValueError('Grouped source omitted a token inside the literal')
    literal = source[start:end]
    if not GROUPED_THOUSANDS.fullmatch(literal):
        raise ValueError('Source span is not a grouped-thousands numeric literal')
    compact = re.sub(r'[ \u00a0\u202f]', '', literal)
    return {**parse_display(compact), 'source_literal': literal, 'source_token_ids': list(source_token_ids)}

class ResolutionError(Exception):
    pass

class Resolver:
    def __init__(self, archive, tokens, mapping=None):
        self.archive = archive
        self.tokens = {t['token_id']: t for t in tokens}
        self.groups = {c['token_id']: grouped_source(tokens, c['source_token_ids']) for c in (mapping or {}).get('checks', []) if c.get('source_token_ids')}
        self.block_cache = {}
        self.component_cache = {}
        self.corpus_cache = {}

    def effective_token(self, token_id):
        group = self.groups.get(token_id)
        return {**self.tokens[token_id], **group, 'text': group['source_literal']} if group else self.tokens[token_id]

    def target(self, token_id):
        tok = self.effective_token(token_id)
        return D(tok['parsed_value']), D(tok['display_tolerance'])

    def component_orgs(self, paper, component):
        if component is None:
            return None
        key = (paper['doi'], component)
        if key in self.component_cache:
            return self.component_cache[key]
        comps = tml.compounds_of(paper['data'])
        direct = {int(org) for org, data in comps.items() if component.casefold() in
                  {str(n).casefold() for n in [data.get('name'), data.get('inchikey'), *data.get('names', [])] if n}}
        if not direct:
            keys = self.archive.comp_keys(component)
            direct = {int(org) for org, data in comps.items() if data.get('inchikey') in keys}
        self.component_cache[key] = direct
        return direct

    def block_context(self, paper, block):
        key = (paper['doi'], int(block['nPureOrMixtureDataNumber']))
        if key in self.block_cache:
            return self.block_cache[key]
        components = {int(c['RegNum']['nOrgNum']) for c in tml.arr(block.get('Component'))}
        compounds = {int(k): v for k, v in tml.compounds_of(paper['data']).items()}
        coords = []
        for source, elements, idkey, typekey, valuekey, digitskey, numberkey in (
                ('variable', block.get('Variable'), 'VariableID', 'VariableType', 'nVarValue', 'nVarDigits', 'nVarNumber'),
                ('constraint', block.get('Constraint'), 'ConstraintID', 'ConstraintType', 'nConstraintValue', 'nConstrDigits', None)):
            for index, element in enumerate(tml.arr(elements), 1):
                identifier = element.get(idkey, {})
                kind, name = tml.one_key(identifier.get(typekey, {}))
                lower = str(name or '').casefold()
                coordinate = 'T' if kind == 'eTemperature' else 'P' if kind == 'ePressure' else 'x' if lower.startswith('mole fraction') else 'w' if lower.startswith('mass fraction') else 'phi' if kind == 'eComponentComposition' and name == 'Volume fraction' else 'mass_ratio' if kind == 'eComponentComposition' and name == 'Mass ratio of solute to solvent' else 'm' if lower.startswith('molality') else 'c' if 'amount concentration (molarity)' in lower else 'frequency' if frequency_unit(kind, name) else None
                if not coordinate:
                    continue
                unit = 'K' if coordinate == 'T' else 'kPa' if coordinate == 'P' else '1' if coordinate == 'mass_ratio' else 'mol/kg' if coordinate == 'm' else 'mol/dm3' if coordinate == 'c' else frequency_unit(kind, name) if coordinate == 'frequency' else 'fraction'
                phase_id = element.get('VarPhaseID') or element.get('ConstraintPhaseID') or {}
                phase = phase_id.get('eVarPhase') or phase_id.get('eConstraintPhase')
                coords.append({'kind': coordinate, 'name': name, 'org': org_num(identifier.get('RegNum', {}).get('nOrgNum')),
                               'unit': unit, 'source': source, 'number': int(element[numberkey]) if numberkey else index,
                               'valuekey': valuekey, 'digitskey': digitskey, 'raw': element, 'phase': phase})
        context = {'block': block, 'number': key[1], 'components': components, 'compounds': compounds,
                   'properties': property_definitions(block), 'coordinates': coords}
        self.block_cache[key] = context
        return context

    def coordinate_values(self, paper, context, point, spec):
        kind = spec.get('name') or spec.get('kind')
        component = spec.get('component')
        requested = self.component_orgs(paper, component)
        if component is not None and not requested:
            raise ResolutionError('Requested coordinate component is not identified in the cited paper: ' + component)
        relevant = [c for c in context['coordinates'] if c['kind'] == kind and (not spec.get('phase') or c['phase'] == spec['phase'])]
        if kind in ('x','w','phi','mass_ratio','m','c') and component is None and len({c['org'] for c in relevant}) > 1:
            raise ResolutionError('Composition component is unspecified and multiple components are stored')
        direct = [c for c in relevant if requested is None or c['org'] in requested]
        complement = False
        if not direct and requested and len(context['components']) == 2 and len(requested & context['components']) == 1 and kind in ('x','w'):
            direct = [c for c in relevant if c['org'] in context['components'] and c['org'] not in requested]
            complement = True
        result = []
        for coordinate in direct:
            if coordinate['source'] == 'constraint':
                raw = coordinate['raw']
                field = 'Constraint[' + str(coordinate['number']) + '].nConstraintValue'
            else:
                raw = next((v for v in tml.arr(point.get('VariableValue')) if int(v['nVarNumber']) == coordinate['number']), None)
                field = 'VariableValue[nVarNumber=' + str(coordinate['number']) + '].nVarValue'
            if not raw or not numeric(raw.get(coordinate['valuekey'])):
                continue
            value = raw[coordinate['valuekey']]
            oriented = D(1) - D(str(value)) if complement else D(str(value))
            result.append({'stored_value': str(value), 'stored_unit': coordinate['unit'], 'oriented_value': str(oriented),
                           'reported_digits': digits_of(value, raw.get(coordinate['digitskey'])), 'source_digits_field': coordinate['digitskey'],
                           'source_field': field, 'coordinate_kind': kind, 'component_org': coordinate['org'],
                           'requested_component': component, 'component_name': context['compounds'].get(coordinate['org'], {}).get('name'),
                           'phase': coordinate['phase'], 'flags': ['binary_complement'] if complement else []})
        # Multiple phases/orientations are a semantic ambiguity, regardless of their magnitudes.
        if len({(r['component_org'], r['phase'], r['oriented_value']) for r in result}) > 1:
            raise ResolutionError('Multiple distinct stored coordinates match the requested coordinate')
        return result

    def pure_molality_match(self, context, point, requested, phase=None):
        """Identify a pure solvent only from exact-zero molality of every solute."""
        components = context['components']
        selected = requested & components
        others = components - selected
        if len(selected) != 1 or not others:
            return False, []
        all_m = [c for c in context['coordinates'] if c['kind'] == 'm']
        # A molality coordinate describes a solute, never the pure identity of
        # that same component. Require a single consistent coordinate phase.
        if any(c['org'] in selected for c in all_m):
            return False, []
        relevant = [c for c in all_m if c['org'] in others and (phase is None or c['phase'] == phase)]
        if {c['org'] for c in relevant} != others or len({c['phase'] for c in relevant}) != 1:
            return False, []
        tested = []
        for coordinate in relevant:
            if coordinate['source'] == 'constraint':
                raw = coordinate['raw']
                field = 'Constraint[' + str(coordinate['number']) + '].nConstraintValue'
            else:
                raw = next((v for v in tml.arr(point.get('VariableValue')) if int(v['nVarNumber']) == coordinate['number']), None)
                field = 'VariableValue[nVarNumber=' + str(coordinate['number']) + '].nVarValue'
            value = raw.get(coordinate['valuekey']) if raw else None
            if not numeric(value):
                return False, tested
            exact_zero = D(str(value)) == 0
            tested.append({'component_org': coordinate['org'], 'phase': coordinate['phase'],
                           'source_field': field, 'stored_value': str(value), 'stored_unit': 'mol/kg',
                           'matches': exact_zero})
        return bool(tested) and all(c['matches'] for c in tested), tested

    def state_match(self, paper, context, point, states, checked_token, ignore_identity=False):
        evidence = []
        matched = True
        required_semantic = True
        for state in states:
            if state.get('kind') == 'interior':
                if state.get('basis') not in ('x', 'w'):
                    raise ResolutionError('Interior-component state requires explicit x or w basis')
                requested = self.component_orgs(paper, state.get('component'))
                selected = requested & context['components'] if requested else set()
                if len(selected) != 1:
                    raise ResolutionError('Interior-component state does not identify one component of this block')
                # Keep only direct stored coordinates; no other-component complement.
                direct_context = {**context, 'coordinates': [c for c in context['coordinates'] if c['org'] in selected]}
                values = self.coordinate_values(paper, direct_context, point,
                    {'kind': state['basis'], 'component': state['component'], 'phase': state.get('phase')}) if len(context['components']) == 2 else []
                tested = [{**value, 'matches': D(0) < D(value['stored_value']) < D(1)} for value in values]
                ok = any(value['matches'] for value in tested)
                evidence.append({'token_id': None, 'kind': 'interior', 'component': state['component'],
                                 'basis': state['basis'], 'phase': state.get('phase'), 'unit': 'fraction',
                                 'matches': ok, 'candidates': tested})
                matched &= ok
                required_semantic &= ok
                continue
            if state.get('kind') == 'absent':
                requested = self.component_orgs(paper, state.get('component'))
                if not requested or not (requested & context['components']):
                    raise ResolutionError('Absent-component state does not identify a component of this block')
                if state.get('basis') not in ('x', 'w'):
                    raise ResolutionError('Absent-component state requires explicit x or w basis')
                values = self.coordinate_values(paper, context, point,
                    {'kind': state['basis'], 'component': state['component'], 'phase': state.get('phase')})
                target, tolerance = D(0), D(0)
                state = {**state, 'token_id': None, 'unit': 'fraction'}
            elif state.get('kind') == 'pure':
                requested = self.component_orgs(paper, state.get('component'))
                if not requested:
                    raise ResolutionError('Pure-component state does not identify an archive component')
                if len(context['components']) == 1:
                    ok = bool(requested & context['components'])
                    evidence.append({'token_id': None, 'kind': 'pure', 'component': state.get('component'), 'matches': ok, 'basis': 'single_component_block'})
                    matched &= ok
                    continue
                values = []
                for basis in ('x','w'):
                    values.extend(self.coordinate_values(paper, context, point, {'kind':basis, 'component':state.get('component'),
                                                                                'phase':state.get('phase')}))
                if not values:
                    ok, tested = self.pure_molality_match(context, point, requested, state.get('phase'))
                    evidence.append({'token_id': None, 'kind': 'pure', 'component': state.get('component'),
                                     'matches': ok, 'basis': 'exact_zero_other_component_molality', 'candidates': tested})
                    matched &= ok
                    continue
                target, tolerance = D(1), D(0)
                state = {**state, 'token_id':None, 'unit':'fraction'}
            else:
                if state['token_id'] == checked_token:
                    continue
                values = self.coordinate_values(paper, context, point, state)
                target, tolerance = self.target(state['token_id'])
            tested = []
            for value in values:
                if not state.get('unit'):
                    raise ResolutionError('State coordinate has no answer unit')
                try:
                    converted = convert(value['oriented_value'], value['stored_unit'], norm_unit(state['unit']))
                except ValueError as exc:
                    raise ResolutionError(str(exc)) from exc
                tested.append({**value, 'converted_stored_value': str(converted), 'absolute_difference': str(abs(converted-target)),
                               'tolerance_used': str(tolerance), 'matches': abs(converted-target) <= tolerance})
            ok = any(v['matches'] for v in tested)
            evidence.append({'token_id': state['token_id'], 'kind': state.get('kind'), 'unit': state.get('unit'), 'matches': ok, 'candidates': tested})
            matched &= ok
            if state.get('kind') == 'absent':
                required_semantic &= ok
        return required_semantic and (True if ignore_identity else matched), evidence

    def uncertainty_values(self, raw, selected_field=None):
        output = []
        def walk(node, path):
            if isinstance(node, dict):
                for key, value in node.items():
                    if key == 'tml_elements':
                        continue
                    current = path + '.' + key if path else key
                    if key in UNCERTAINTY_FIELDS and numeric(value) and (not selected_field or selected_field in (key, current)):
                        output.append((current, value, node))
                    elif isinstance(value, (dict, list)):
                        walk(value, current)
            elif isinstance(node, list):
                for i, item in enumerate(node):
                    walk(item, path + '[' + str(i) + ']')
        walk(raw, '')
        return output

    def matched_property_definitions(self, paper, context, selector, fallback=None):
        component = selector.get('component')
        orgs = None if component is None else self.component_orgs(paper, component)
        if component is not None and not orgs:
            raise ResolutionError('Requested property component is not identified in the cited paper: ' + component)
        return property_matches(context['properties'], selector, fallback, orgs)

    def select_scope(self, check, scope, alternate=False):
        if 'system' in scope:
            if alternate:
                raise ResolutionError('Alternative-block search is unsupported for a system scope')
            system_scopes = self.archive.system_scopes(scope['system'])
            binding = {'scope': scope, 'candidate_records': [], 'errors': [], 'missing': [],
                       'state_rejected_count': 0, 'system_bindings': []}
            if not system_scopes:
                binding['missing'].append('exact_system_not_found')
            inherited = {key:value for key,value in scope.items() if key != 'system'}
            for paper_scope in system_scopes:
                child_scope = {**paper_scope, **inherited}
                child = self.select_scope(check, child_scope)
                binding['system_bindings'].append(child)
                binding['candidate_records'].extend(child['candidate_records'])
                binding['errors'].extend(child['errors'])
                binding['missing'].extend(child['missing'])
                binding['state_rejected_count'] += child['state_rejected_count']
            binding['errors'] = sorted(set(binding['errors']))
            binding['missing'] = sorted(set(binding['missing']))
            if not binding['candidate_records'] and not binding['errors']:
                binding['missing'].append('no_property_or_coordinate_at_stated_state')
            return binding
        quantity = check['quantity']
        scoped = {**check, **{key: scope[key] for key in ('state','selector_property','selector_presentation','selector_phase','selector_phase_family','selector_component','component','select_extremum') if key in scope}}
        q = {**quantity}
        if 'component' in scope:
            q['component'] = scope['component']
        paper = self.archive.paper(scope['paper'])
        binding = {'scope': scope, 'candidate_records': [], 'errors': [], 'missing': [], 'state_rejected_count': 0}
        if not paper:
            binding['missing'].append('paper_not_found')
            return binding
        all_blocks = tml.arr(paper['data'].get('PureOrMixtureData'))
        named = set(map(int, scope.get('blocks', [])))
        selected_blocks = [b for b in all_blocks if not named or (int(b['nPureOrMixtureDataNumber']) not in named if alternate else int(b['nPureOrMixtureDataNumber']) in named)]
        if not selected_blocks:
            binding['missing'].append('block_not_found')
        states = scoped.get('state', [])
        for block in selected_blocks:
            context = self.block_context(paper, block)
            if check.get('system'):
                sets = [self.component_orgs(paper, name) for name in check['system']]
                if len(context['components']) != len(sets) or any(not (s & context['components']) for s in sets):
                    continue
            if scope.get('required_system'):
                sets = [self.component_orgs(paper, name) for name in scope['required_system']]
                if len(context['components']) != len(sets) or any(not (s & context['components']) for s in sets):
                    continue
            try:
                properties = self.matched_property_definitions(paper, context, q, check.get('property')) if q['kind'] != 'coordinate' else []
                selector_properties = []
                if q['kind'] == 'coordinate' and scoped.get('selector_property'):
                    selector_properties = self.matched_property_definitions(paper, context,
                        {'name_contains': scoped['selector_property'],
                         'presentation': scoped.get('selector_presentation'),
                         'phase': scoped.get('selector_phase'),
                         'phase_family': scoped.get('selector_phase_family'),
                         'component': scoped.get('selector_component')})
                    if not selector_properties:
                        continue
            except ResolutionError as exc:
                binding['errors'].append(str(exc))
                continue
            if q['kind'] != 'coordinate' and not properties:
                binding['missing'].append('property_not_found')
                continue
            if len({p['name'] for p in properties}) > 1:
                binding['errors'].append('Multiple distinct property definitions match the semantic selector')
                continue
            points = set(map(int, scope.get('points', []))) if not alternate else set()
            data_points = tml.arr(block.get('NumValues'))
            if points and not points.issubset(set(range(1, len(data_points)+1))):
                binding['missing'].append('point_not_found')
            for pn, point in enumerate(data_points, 1):
                if points and pn not in points:
                    continue
                try:
                    matches, state_evidence = self.state_match(paper, context, point, states, check['token_id'], bool(points))
                except ResolutionError as exc:
                    binding['errors'].append(str(exc))
                    continue
                if not matches:
                    binding['state_rejected_count'] += 1
                    continue
                active_selector_properties = [prop for prop in selector_properties
                    if any(int(pv.get('nPropNumber', -1)) == prop['number'] and numeric(pv.get('nPropValue'))
                           for pv in tml.arr(point.get('PropertyValue')))]
                if selector_properties and not active_selector_properties:
                    continue
                selection = {}
                if scoped.get('select_extremum'):
                    try:
                        definition = self.matched_property_definitions(paper, context, scoped['select_extremum'])
                    except ResolutionError as exc:
                        binding['errors'].append(str(exc))
                        continue
                    if len(definition) != 1:
                        binding['errors'].append('Extremum-selection property is absent or not uniquely identified')
                        continue
                    prop = definition[0]
                    selection_raw = next((pv for pv in tml.arr(point.get('PropertyValue')) if int(pv['nPropNumber']) == prop['number'] and numeric(pv.get('nPropValue'))), None)
                    if selection_raw is None:
                        continue
                    selection = {'selection_value': str(selection_raw['nPropValue']), 'selection_unit': prop['unit'],
                                 'selection_property': prop['name'], 'selection_property_number': prop['number'],
                                 'selection_property_component_org': prop['component_org']}
                record = {'doi': paper['doi'], 'paper_id': paper['paper_id'], 'block': context['number'], 'point': pn,
                          'matched_record': f"{paper['paper_id']}::PROPblock_{context['number']}::BLKpoint_{pn}",
                          'state_evidence': state_evidence, 'explicit_point': bool(points),
                          'selector_property_definitions': [{'number': p['number'], 'name': p['name'],
                              'presentation': p['presentation'], 'phase': p['phase'],
                              'component_org': p['component_org']}
                              for p in active_selector_properties], **selection}
                flags = ['cited_point_state_conflict'] if points and any(not s['matches'] for s in state_evidence) else []
                sources = []
                if q['kind'] == 'coordinate':
                    try:
                        sources = self.coordinate_values(paper, context, point, q)
                    except ResolutionError as exc:
                        binding['errors'].append(str(exc))
                        continue
                    if active_selector_properties:
                        selected_phases = {prop['phase'] for prop in active_selector_properties}
                        sources = [source for source in sources
                            if source.get('phase') is None or None in selected_phases
                            or source['phase'] in selected_phases]
                else:
                    for prop in properties:
                        for pv in tml.arr(point.get('PropertyValue')):
                            if int(pv['nPropNumber']) != prop['number']:
                                continue
                            base = {'stored_unit': prop['unit'], 'property_number': prop['number'], 'property_name': prop['name'],
                                    'property_phase': prop['phase'], 'property_presentation': prop['presentation'],
                                    'property_component_org': prop['component_org'],
                                    'uncertainty_source_fields': self.uncertainty_values(pv)}
                            if q['kind'] == 'property' and numeric(pv.get('nPropValue')):
                                sources.append({**base, 'stored_value': str(pv['nPropValue']), 'oriented_value': str(pv['nPropValue']),
                                                'reported_digits': digits_of(pv['nPropValue'], pv.get('nPropDigits')),
                                                'source_digits_field': 'nPropDigits', 'source_field': f"PropertyValue[nPropNumber={prop['number']}].nPropValue", 'flags': []})
                            elif q['kind'] == 'uncertainty':
                                uncertainties = self.uncertainty_values(pv, q.get('field'))
                                if len({field for field, value, raw in uncertainties}) > 1:
                                    binding['errors'].append('Uncertainty type is unspecified and multiple uncertainty fields are present')
                                    continue
                                for field, value, raw in uncertainties:
                                    sources.append({**base, 'stored_value': str(value), 'oriented_value': str(value), 'reported_digits': digits_of(value),
                                                    'source_digits_field': None, 'source_field': f"PropertyValue[nPropNumber={prop['number']}].{field}",
                                                    'uncertainty_field': field, 'uncertainty_source': raw, 'flags': []})
                for source in sources:
                    if source['stored_unit'] is None or not check.get('unit'):
                        binding['errors'].append('Stored or answer unit is not specified')
                        continue
                    try:
                        converted = convert(source['oriented_value'], source['stored_unit'], norm_unit(check['unit']), uncertainty=q['kind']=='uncertainty')
                    except ValueError as exc:
                        binding['errors'].append(str(exc))
                        continue
                    token = self.effective_token(check['token_id'])
                    source_flags = flags + source['flags']
                    if source['reported_digits'] is not None and token['significant_digits'] > source['reported_digits']:
                        source_flags.append('digits_beyond_source')
                    if source['stored_unit'] != norm_unit(check['unit']):
                        source_flags.append('unit_converted')
                    sources_entry = {**record, **source, 'converted_stored_value': str(converted), 'flags': sorted(set(source_flags))}
                    binding['candidate_records'].append(sources_entry)
        binding['errors'] = sorted(set(binding['errors']))
        binding['missing'] = sorted(set(binding['missing']))
        if not binding['candidate_records'] and not binding['errors']:
            binding['missing'].append('no_property_or_coordinate_at_stated_state')
        return binding

    def corpus_extrema(self, scope):
        key = tuple(sorted(scope.items()))
        if key in self.corpus_cache:
            return self.corpus_cache[key]
        if 'contains_component' in scope:
            exact_size = 'n_components' in scope
            size = scope['n_components'] if exact_size else scope['min_components']
            metadata = self.archive.corpus_blocks_containing(size, scope['contains_component'],
                                                             scope['property_name'], exact=exact_size)
        else:
            metadata = self.archive.corpus_blocks(scope['n_components'], scope['property_name'])
        blocks = {}
        by_doi = {}
        for doi, block_number, npoints, prop_number in metadata:
            block_key = (doi, int(block_number))
            entry = blocks.setdefault(block_key, {'n_datapoints': int(npoints or 0), 'property_numbers': set()})
            if entry['n_datapoints'] != int(npoints or 0):
                raise ResolutionError('Conflicting point counts in corpus block metadata')
            entry['property_numbers'].add(int(prop_number))
            by_doi.setdefault(doi, set()).add(int(block_number))
        outcome = {'scope': dict(scope), 'metadata_blocks': len(blocks), 'metadata_papers': len(by_doi),
                   'metadata_points': sum(x['n_datapoints'] for x in blocks.values()),
                   'phase_family': ('Liquid includes literal Liquid and Liquid mixture N; excludes Gas, Glass, Fluid and unknown'
                                    if scope.get('phase') == 'Liquid' else 'all property phases, including unknown'),
                   'property_phase_definition_counts': {}, 'property_presentation_definition_counts': {},
                   'phase_eligible_blocks': 0, 'phase_excluded_blocks': 0,
                   'presentation_excluded_blocks': 0, 'selection_eligible_blocks': 0,
                   'phase_excluded_points': 0, 'presentation_excluded_points': 0,
                   'enumerated_points': 0, 'property_numeric_points': 0, 'missing_property_points': 0,
                   'coordinate_numeric_values': {'T': 0, 'P': 0},
                   'coordinate_absent_points': {'T': 0, 'P': 0},
                   'phase_rejected_values': {'T': 0, 'P': 0},
                   'extrema': {kind: {'min': [], 'max': []} for kind in ('T','P')}}
        if not blocks:
            self.corpus_cache[key] = outcome
            return outcome
        reference_ids = {r['doi'].casefold(): r['lit_num_id'] for r in self.archive.registry('reference_ids.csv') if r.get('doi')}
        def parse_json(value):
            return json.loads(value, parse_float=D, parse_int=D) if value is not None else None
        for doi, block_numbers in sorted(by_doi.items()):
            ordered = sorted(block_numbers)
            headers = {}
            for bn, variables_json, constraints_json, properties_json in self.archive.corpus_headers(doi, ordered):
                bn = int(bn)
                if bn in headers or (doi,bn) not in blocks:
                    raise ResolutionError('Corpus block header mismatch or duplicate')
                definitions = property_definitions({'Property': parse_json(properties_json)})
                named = {p['number']: p for p in definitions if p['number'] in blocks[(doi,bn)]['property_numbers']
                         and p['name'] == scope['property_name']}
                if set(named) != blocks[(doi,bn)]['property_numbers']:
                    raise ResolutionError('Corpus metadata property does not match raw block definition')
                counts = outcome['property_phase_definition_counts']
                for definition in named.values():
                    label = definition['phase'] if definition['phase'] is not None else '<missing>'
                    counts[label] = counts.get(label, 0) + 1
                    presentations = outcome['property_presentation_definition_counts']
                    presentation = definition['presentation'] if definition['presentation'] is not None else '<missing>'
                    presentations[presentation] = presentations.get(presentation, 0) + 1
                phase_selected = {number:definition for number,definition in named.items()
                                  if scope.get('phase') is None or corpus_phase_matches(scope['phase'], definition['phase'])}
                selected = {number:definition for number,definition in phase_selected.items()
                            if scope.get('presentation') is None or definition['presentation'] == scope['presentation']}
                outcome['phase_eligible_blocks' if phase_selected else 'phase_excluded_blocks'] += 1
                if phase_selected and not selected:
                    outcome['presentation_excluded_blocks'] += 1
                if selected:
                    outcome['selection_eligible_blocks'] += 1
                coordinates = {'T': [], 'P': []}
                for source, elements, idkey, typekey, numberkey in (
                        ('variable', parse_json(variables_json), 'VariableID', 'VariableType', 'nVarNumber'),
                        ('constraint', parse_json(constraints_json), 'ConstraintID', 'ConstraintType', None)):
                    for index, element in enumerate(tml.arr(elements), 1):
                        identifier = element.get(idkey, {})
                        kind, _ = tml.one_key(identifier.get(typekey, {}))
                        coordinate_kind = 'T' if kind == 'eTemperature' else 'P' if kind == 'ePressure' else None
                        if not coordinate_kind:
                            continue
                        phase_id = element.get('VarPhaseID') or element.get('ConstraintPhaseID') or {}
                        phase = phase_id.get('eVarPhase') or phase_id.get('eConstraintPhase')
                        coordinates[coordinate_kind].append({'source': source,
                            'number': int(element[numberkey]) if numberkey else index,
                            'phase': phase, 'raw': element})
                headers[bn] = {'properties': selected, 'phase_selected': bool(phase_selected),
                               'coordinates': coordinates}
            if set(headers) != block_numbers:
                raise ResolutionError('Corpus metadata block absent from raw paper JSON')
            seen_points = Counter()
            for bn, point_number, variables_json, properties_json in self.archive.corpus_points(doi, ordered):
                bn = int(bn); point_number = int(point_number)
                if bn not in headers:
                    raise ResolutionError('Corpus point belongs to unselected block')
                seen_points[bn] += 1
                outcome['enumerated_points'] += 1
                header = headers[bn]
                if not header['properties']:
                    outcome['phase_excluded_points' if not header['phase_selected']
                            else 'presentation_excluded_points'] += 1
                    continue
                prop_values = tml.arr(parse_json(properties_json))
                valid_prop = [pv for pv in prop_values if int(pv.get('nPropNumber', -1)) in header['properties']
                              and numeric(pv.get('nPropValue'))]
                if not valid_prop:
                    outcome['missing_property_points'] += 1
                    continue
                outcome['property_numeric_points'] += 1
                phases = {header['properties'][int(pv['nPropNumber'])]['phase'] for pv in valid_prop}
                var_values = {int(v['nVarNumber']): v for v in tml.arr(parse_json(variables_json))
                              if v.get('nVarNumber') is not None}
                for coordinate_kind in ('T','P'):
                    found = False
                    for coordinate in header['coordinates'][coordinate_kind]:
                        if coordinate['phase'] is not None and None not in phases and coordinate['phase'] not in phases:
                            outcome['phase_rejected_values'][coordinate_kind] += 1
                            continue
                        if coordinate['source'] == 'variable':
                            raw = var_values.get(coordinate['number'])
                            field = 'VariableValue[nVarNumber=' + str(coordinate['number']) + '].nVarValue'
                            valuekey, digitskey = 'nVarValue', 'nVarDigits'
                        else:
                            raw = coordinate['raw']
                            field = 'Constraint[' + str(coordinate['number']) + '].nConstraintValue'
                            valuekey, digitskey = 'nConstraintValue', 'nConstrDigits'
                        value = raw.get(valuekey) if raw else None
                        if not numeric(value):
                            continue
                        found = True
                        outcome['coordinate_numeric_values'][coordinate_kind] += 1
                        value = D(str(value))
                        record = {'doi': doi, 'paper_id': reference_ids.get(doi.casefold()) or doi,
                                  'block': bn, 'point': point_number,
                                  'matched_record': (reference_ids.get(doi.casefold()) or doi) + '::PROPblock_' + str(bn) + '::BLKpoint_' + str(point_number),
                                  'stored_value': str(value), 'stored_unit': 'K' if coordinate_kind == 'T' else 'kPa',
                                  'reported_digits': digits_of(value, raw.get(digitskey)),
                                  'source_field': field, 'source_digits_field': digitskey,
                                  'coordinate_phase': coordinate['phase'],
                                  'property_numbers': sorted({int(pv['nPropNumber']) for pv in valid_prop}),
                                  'selected_property_definitions': [
                                      {'number': header['properties'][int(pv['nPropNumber'])]['number'],
                                       'name': header['properties'][int(pv['nPropNumber'])]['name'],
                                       'phase': header['properties'][int(pv['nPropNumber'])]['phase'],
                                       'presentation': header['properties'][int(pv['nPropNumber'])]['presentation'],
                                       'component_org': header['properties'][int(pv['nPropNumber'])]['component_org']}
                                      for pv in valid_prop],
                                  'flags': []}
                        for endpoint, better in (('min', lambda a,b:a<b), ('max', lambda a,b:a>b)):
                            selected = outcome['extrema'][coordinate_kind][endpoint]
                            if not selected or better(value, D(selected[0]['stored_value'])):
                                outcome['extrema'][coordinate_kind][endpoint] = [record]
                            elif value == D(selected[0]['stored_value']):
                                if not any(r['matched_record']==record['matched_record'] and r['source_field']==field for r in selected):
                                    selected.append(record)
                    if not found:
                        outcome['coordinate_absent_points'][coordinate_kind] += 1
            for bn in ordered:
                if seen_points[bn] != blocks[(doi,bn)]['n_datapoints']:
                    raise ResolutionError('Corpus point count disagrees with block metadata')
        self.corpus_cache[key] = outcome
        return outcome

    def resolve_corpus(self, check, row, flags):
        scope = check['corpus_scope']
        corpus = self.corpus_extrema(scope)
        kind = check['quantity']['name']
        endpoint = check['endpoint']
        selected = corpus['extrema'][kind][endpoint]
        row['scope_mode'] = 'corpus'
        row['cited_record'] = [{'corpus_scope': scope}]
        row['corpus_scope_evidence'] = {k:v for k,v in corpus.items() if k != 'extrema'}
        if not selected:
            flags.append('not_found')
            row.update(category='miss', reason='No numeric '+kind+' coordinate at a selected property point',
                       selected_record_ids=[], candidate_records=[])
            return
        converted = []
        for record in selected:
            value = convert(record['stored_value'], record['stored_unit'], norm_unit(check['unit']))
            source_flags = ['unit_converted'] if record['stored_unit'] != norm_unit(check['unit']) else []
            if self.effective_token(check['token_id'])['significant_digits'] > record['reported_digits']:
                source_flags.append('digits_beyond_source')
            converted.append({**record, 'converted_stored_value': str(value), 'flags': source_flags})
        token = self.effective_token(check['token_id'])
        comparisons = [compare(token['parsed_value'], r['converted_stored_value'], token['display_tolerance']) for r in converted]
        categories = {x['category'] for x in comparisons}
        category = next(iter(categories)) if len(categories)==1 else 'ambiguous'
        flags.extend(f for c, comparison in zip(converted, comparisons) for f in c['flags']+comparison['flags'])
        ids = sorted({r['matched_record'] for r in converted})
        if len(ids)>1:
            flags.extend(['n_candidates','multiple_candidates','tied_candidates'])
        binding = {'scope': {'corpus_scope': scope}, 'category': category, 'candidate_records': converted,
                   'eligible_candidate_records': converted, 'selected_records': converted, 'comparisons': comparisons,
                   'n_candidates': len(ids), 'viable_candidate_ids': ids,
                   'flags': sorted(set(flags)), 'reason': None}
        row.update(category=category, bindings=[binding], range_union=binding, candidate_records=converted,
                   selected_record_ids=ids, viable_candidate_ids=ids, n_candidates=len(ids))
        if len({D(r['converted_stored_value']) for r in converted})==1:
            representative = sorted(converted, key=lambda r:(r['matched_record'],r['source_field']))[0]
            for field in ('matched_record','stored_value','stored_unit','reported_digits','converted_stored_value','source_field','source_digits_field'):
                row[field] = representative[field]
            row.update({k:v for k,v in comparisons[0].items() if k not in ('category','flags')})
        else:
            flags.append('multiple_stored_values')

    def independently_bound_coordinate(self, check, candidate):
        """Return a different-unit state token binding this exact stored coordinate."""
        kind = check['quantity'].get('name')
        answer_unit = norm_unit(check.get('unit'))
        for state in candidate.get('state_evidence', []):
            if (not state.get('token_id') or state['token_id'] == check['token_id']
                    or state.get('kind') != kind or not state.get('matches')
                    or not state.get('unit') or norm_unit(state['unit']) == answer_unit):
                continue
            for value in state.get('candidates', []):
                if (value.get('matches') and value.get('coordinate_kind') == candidate.get('coordinate_kind')
                        and value.get('component_org') == candidate.get('component_org')
                        and value.get('phase') == candidate.get('phase')
                        and value.get('source_field') == candidate.get('source_field')
                        and ('binary_complement' in value.get('flags', [])) == ('binary_complement' in candidate.get('flags', []))):
                    return state['token_id']
        return None

    def summarize_binding(self, check, binding):
        target, tolerance = self.target(check['token_id'])
        candidates = binding['candidate_records']
        binding.update(n_candidates=0, viable_candidate_ids=[], eligible_candidate_records=[])
        if not candidates:
            binding.update(category='ambiguous' if binding['errors'] else 'miss', flags=[] if binding['errors'] else ['not_found'],
                           selected_records=[], reason='; '.join(binding['errors'] or binding['missing']))
            return binding
        selection = binding.get('scope', {}).get('select_extremum') or check.get('select_extremum')
        if selection:
            if selection.get('endpoint') not in ('min','max'):
                raise ResolutionError('select_extremum endpoint must be min or max')
            unit = next((c.get('selection_unit') for c in candidates if c.get('selection_unit')), None)
            if unit is None or any('selection_value' not in c for c in candidates):
                raise ResolutionError('Extremum-selection property has no value or unit')
            converted_selection = [(c, convert(c['selection_value'], c['selection_unit'], unit)) for c in candidates]
            extreme = (min if selection['endpoint']=='min' else max)(v for c,v in converted_selection)
            candidates = [c for c,v in converted_selection if v == extreme]
            binding['extremum_selection'] = {'selector': selection, 'value': str(extreme), 'unit': unit, 'candidate_records': candidates}
        if check['quantity']['kind'] == 'coordinate' and check.get('role') != 'range_end':
            rejected = []
            kept = []
            independently_bound = {}
            for candidate in candidates:
                outside = abs(D(candidate['converted_stored_value'])-target) > tolerance
                state_token = self.independently_bound_coordinate(check, candidate) if outside and not candidate.get('explicit_point') else None
                if state_token:
                    candidate['flags'] = sorted(set(candidate['flags'] + ['independently_bound_coordinate']))
                    independently_bound[candidate['matched_record']] = state_token
                if outside and not candidate.get('explicit_point') and not state_token:
                    rejected.append(candidate)
                else:
                    kept.append(candidate)
            candidates = kept
            binding['self_coordinate_filter'] = {'tolerance_used': str(tolerance),
                                                 'rejected_record_ids': sorted({c['matched_record'] for c in rejected}),
                                                 'independently_bound_state_tokens': independently_bound}
            if not candidates:
                binding['missing'] = sorted(set(binding['missing'] + ['checked_coordinate_not_found_at_display_precision']))
                binding.update(category='ambiguous' if binding['errors'] else 'miss', flags=[] if binding['errors'] else ['not_found'],
                               selected_records=[], reason='; '.join(binding['errors'] or binding['missing']))
                return binding
        binding['viable_candidate_ids'] = sorted({c['matched_record'] for c in candidates})
        binding['n_candidates'] = len(binding['viable_candidate_ids'])
        binding['eligible_candidate_records'] = candidates
        if check.get('role') == 'range_end':
            endpoint = check.get('endpoint')
            if endpoint not in ('min', 'max'):
                raise ResolutionError('Range endpoint must explicitly be min or max')
            extreme = (min if endpoint == 'min' else max)(D(c['converted_stored_value']) for c in candidates)
            selected = [c for c in candidates if D(c['converted_stored_value']) == extreme]
        else:
            distance = min(abs(D(c['converted_stored_value']) - target) for c in candidates)
            selected = [c for c in candidates if abs(D(c['converted_stored_value']) - target) == distance]
        results = [compare(target, c['converted_stored_value'], tolerance) for c in selected]
        category = results[0]['category'] if len({r['category'] for r in results}) == 1 else 'ambiguous'
        flags = sorted({flag for c, r in zip(selected, results) for flag in c['flags'] + r['flags']})
        if binding['n_candidates'] > 1:
            flags.extend(['n_candidates', 'multiple_candidates'])
        if len(selected) > 1:
            flags.append('tied_candidates')
        # An unresolvable semantic branch must remain visible instead of choosing the supported branch silently.
        if binding['errors']:
            category = 'ambiguous'
            flags.append('semantic_ambiguity')
        binding.update(category=category, flags=sorted(set(flags)), selected_records=selected,
                       comparisons=results, reason='; '.join(binding['errors']) or None)
        return binding

    def resolve(self, check):
        token = self.effective_token(check['token_id'])
        row = {**token, 'unit': check.get('unit'), 'role': check['role'], 'out_of_scope_reason': None,
               'property': check.get('property'), 'cited_record': check.get('records', []), 'matched_record': None,
               'stored_value': None, 'stored_unit': None, 'reported_digits': None, 'converted_stored_value': None,
               'absolute_difference': None, 'relative_difference': None, 'tolerance_used': token['display_tolerance'],
               'category': None, 'flags': [], 'lookup_ids': [], 'n_candidates': 0, 'viable_candidate_ids': [], 'mapping_detail': check.get('detail'), 'bindings': []}
        flags = ['approximate'] if check.get('approximate') else []
        try:
            if check.get('corpus_scope'):
                flags.append('uncited')
                self.resolve_corpus(check, row, flags)
                row['flags'] = sorted(set(flags))
                row['lookup_ids'] = list(self.archive.lookup_ids)
                return row
            scopes = check.get('records') or self.archive.system_scopes(check.get('system', []))
            if check['role'] != 'range_end' and check.get('records'):
                scopes = [part for scope in scopes for part in ([dict(scope, blocks=[block]) for block in scope['blocks']] if scope.get('blocks') else [scope])]
            if not check.get('records') or any(is_discovery_scope(scope) for scope in scopes):
                flags.append('uncited')
            if not scopes:
                row.update(category='miss', reason='No cited record or same-system archive block found')
                flags.append('not_found')
            else:
                bindings = [self.summarize_binding(check, self.select_scope(check, scope)) for scope in scopes]
                row['bindings'] = bindings
                if check['role'] == 'range_end' or not check.get('records'):
                    named_scope_missing = bool(check.get('records') and check['role'] == 'range_end'
                                               and any(not b['candidate_records'] and not is_discovery_scope(b['scope'])
                                                       for b in bindings))
                    union = {'scope': {'union': scopes}, 'candidate_records': [c for b in bindings for c in b.get('extremum_selection', {}).get('candidate_records', b['candidate_records'])],
                             'errors': [error for b in bindings for error in b['errors']],
                             'missing': [m for b in bindings for m in b['missing']]}
                    aggregate = self.summarize_binding(check, union)
                    if named_scope_missing and aggregate['category'] != 'ambiguous':
                        aggregate['category'] = 'miss'
                        aggregate['flags'] = sorted(set(aggregate['flags'] + ['not_found', 'named_range_scope_missing']))
                        aggregate['reason'] = '; '.join(filter(None, [aggregate.get('reason'),
                                                   'One or more named range scopes has no matching record']))
                    row['range_union'] = aggregate
                    effective = bindings if check.get('scope_mode') == 'shared' else [aggregate]
                    scope_categories = {b['category'] for b in bindings}
                    if check.get('records') and len(scope_categories) > 1:
                        flags.append('shared_scope_conflict')
                else:
                    effective = bindings
                categories = {b['category'] for b in effective}
                row['category'] = next(iter(categories)) if len(categories) == 1 else 'ambiguous'
                row['scope_mode'] = check.get('scope_mode','union')
                if check.get('scope_mode') == 'shared' and categories <= {'exact','near_miss','miss'}:
                    row['category'] = 'miss' if 'miss' in categories else 'near_miss' if 'near_miss' in categories else 'exact'
                    row['comparison_rule'] = 'all_required_scopes'
                    flags.append('shared_scope_required')
                if len(categories) > 1:
                    flags.append('shared_scope_conflict')
                flags.extend(flag for b in effective for flag in b['flags'])
                row['viable_candidate_ids'] = sorted({rid for b in effective for rid in b['viable_candidate_ids']})
                row['n_candidates'] = len(row['viable_candidate_ids'])
                if row['n_candidates'] > 1:
                    flags.extend(['n_candidates','multiple_candidates'])
                selected = [c for b in effective for c in b['selected_records']]
                row['selected_record_ids'] = sorted({c['matched_record'] for c in selected})
                row['candidate_records'] = [c for b in bindings for c in b['candidate_records']]
                row['reason'] = '; '.join(sorted({b['reason'] for b in effective if b.get('reason')})) or None
                if selected:
                    # Single representative scalar only when every selected scope agrees numerically.
                    values = {c['converted_stored_value'] for c in selected}
                    if len({D(v) for v in values}) == 1:
                        representative = sorted(selected, key=lambda c:(c['matched_record'], c['source_field']))[0]
                        for key in ('matched_record','stored_value','stored_unit','reported_digits','converted_stored_value','source_field','source_digits_field'):
                            row[key] = representative.get(key)
                        row.update({key: value for key, value in compare(token['parsed_value'], representative['converted_stored_value'], token['display_tolerance']).items() if key not in ('category','flags')})
                    else:
                        flags.append('multiple_stored_values')
                # Search only other blocks of the same cited paper; never substitute their verdict.
                if row['category'] in ('miss','ambiguous'):
                    other = []
                    for scope in scopes:
                        if scope.get('blocks') and not scope.get('uncited'):
                            alternative = self.summarize_binding(check, self.select_scope(check, scope, alternate=True))
                            if alternative['category'] == 'exact':
                                other.append(alternative)
                    if other:
                        row['in_other_block_evidence'] = other
                        flags.append('in_other_block')
        except (ResolutionError, ValueError, KeyError) as exc:
            row.update(category='ambiguous', reason=str(exc))
            flags.append('semantic_ambiguity')
        row['flags'] = sorted(set(flags))
        row['lookup_ids'] = list(self.archive.lookup_ids)
        return row


def validate_mapping(mapping, tokens):
    allowed_roles = {'value', 'coordinate', 'uncertainty', 'range_end'}
    allowed_exclusions = {'derived','count','outside','not_block','label','other','ambiguous'}
    token_ids = {t['token_id'] for t in tokens}
    memberships = Counter()
    for exclusion in mapping.get('exclusions', []):
        if exclusion['reason'] not in allowed_exclusions:
            raise ValueError('Invalid exclusion reason ' + exclusion['reason'])
        memberships.update(exclusion['tokens'])
    for check in mapping.get('checks', []):
        memberships.update([check['token_id']])
        if check['role'] not in allowed_roles or check['quantity']['kind'] not in {'coordinate','property','uncertainty'}:
            raise ValueError('Invalid check role or quantity kind')
        if check.get('corpus_scope') is not None:
            scope = check['corpus_scope']
            allowed = {'n_components','min_components','contains_component','property_name',
                       'block_type','phase','presentation'}
            if (not isinstance(scope, dict) or set(scope)-allowed
                    or not isinstance(scope.get('property_name'), str) or not scope['property_name'].strip()
                    or scope.get('block_type','PureOrMixtureData') != 'PureOrMixtureData'
                    or (scope.get('phase') is not None and scope['phase'] != 'Liquid')
                    or (scope.get('presentation') is not None and
                        (not isinstance(scope['presentation'], str) or not scope['presentation'].strip()))):
                raise ValueError('Invalid exact property, block type, phase or presentation in corpus scope')
            containing = 'contains_component' in scope
            if containing:
                size_fields = {'min_components','n_components'} & set(scope)
                if (set(('contains_component','block_type'))-set(scope)
                        or len(size_fields) != 1
                        or any(type(scope[field]) is not int or scope[field] < 2 for field in size_fields)
                        or not isinstance(scope['contains_component'], str)
                        or not scope['contains_component'].strip()):
                    raise ValueError('Component corpus scope requires canonical component, one valid exact/minimum mixture size and explicit block type')
            elif ('min_components' in scope or type(scope.get('n_components')) is not int
                    or scope['n_components'] < 1 or scope.get('phase') != 'Liquid'):
                raise ValueError('Corpus scope requires exact component count and Liquid phase')
            if (check['role'] != 'range_end' or check['quantity'].get('kind') != 'coordinate'
                    or set(check['quantity']) != {'kind','name'}
                    or check['quantity'].get('name') not in ('T','P') or check.get('endpoint') not in ('min','max')
                    or not check.get('unit') or check.get('records') or check.get('system') or check.get('state')
                    or check.get('select_extremum') or check.get('selector_property') or check.get('selector_presentation')
                    or check.get('selector_phase') or check.get('selector_phase_family')
                    or check.get('selector_component')
                    or check.get('component')
                    or check.get('scope_mode','union') != 'union'):
                raise ValueError('Corpus scope supports only unconditioned global T/P range endpoints')
        if check.get('scope_mode','union') not in ('union','shared'):
            raise ValueError('scope_mode must be union or shared')
        if 'required_system' in check:
            raise ValueError('required_system is supported only inside a named record scope')
        for scope in check.get('records', []):
            if 'required_system' in scope:
                names = scope['required_system']
                if ('system' in scope or not isinstance(scope.get('paper'), str) or not scope['paper'].strip()
                        or not isinstance(names, list) or not names
                        or any(not isinstance(name, str) or not name.strip() for name in names)
                        or len({name.strip().casefold() for name in names}) != len(names)):
                    raise ValueError('required_system requires a named paper and distinct compound names, and cannot mix discovery system')
            if 'system' in scope:
                if (any(key in scope for key in ('paper','blocks','points')) or
                        not isinstance(scope['system'], list) or not scope['system'] or
                        any(not isinstance(name, str) or not name.strip() for name in scope['system'])):
                    raise ValueError('A system record scope requires compound names and cannot mix paper/block/point selectors')
            elif not scope.get('paper'):
                raise ValueError('Each record scope requires paper or exact system')
        quantity = check['quantity']
        if quantity['kind'] in ('property','uncertainty') and quantity.get('component') is not None:
            if not isinstance(quantity['component'], str) or not quantity['component'].strip():
                raise ValueError('Property component must be a nonempty compound name')
        for extremum in [check.get('select_extremum', {}),
                         *(scope.get('select_extremum', {}) for scope in check.get('records', []))]:
            if extremum.get('component') is not None:
                if not isinstance(extremum['component'], str) or not extremum['component'].strip():
                    raise ValueError('Extremum property component must be a nonempty compound name')
        if quantity.get('presentation') is not None:
            if (quantity['kind'] not in ('property','uncertainty') or
                    not isinstance(quantity['presentation'], str) or not quantity['presentation'].strip()):
                raise ValueError('quantity.presentation requires a property or uncertainty and a nonempty exact label')
        if quantity.get('phase_family') is not None:
            if (quantity['kind'] not in ('property','uncertainty') or quantity.get('phase') is not None
                    or quantity['phase_family'] != 'Liquid'):
                raise ValueError('quantity.phase_family supports Liquid property/uncertainty only and excludes exact phase')
        for scoped in [check, *check.get('records', [])]:
            effective = {**check, **scoped}
            selector_phase = effective.get('selector_phase')
            selector_phase_family = effective.get('selector_phase_family')
            if selector_phase is not None or selector_phase_family is not None:
                if (quantity['kind'] != 'coordinate' or not effective.get('selector_property')
                        or (selector_phase is not None and (not isinstance(selector_phase, str) or not selector_phase.strip()))
                        or (selector_phase_family is not None and selector_phase_family != 'Liquid')
                        or (selector_phase is not None and selector_phase_family is not None)):
                    raise ValueError('Coordinate selector phase requires selector_property and one exact or Liquid-family phase')
            selector_component = effective.get('selector_component')
            if selector_component is not None:
                if (quantity['kind'] != 'coordinate' or not effective.get('selector_property')
                        or not isinstance(selector_component, str) or not selector_component.strip()):
                    raise ValueError('selector_component requires a coordinate, selector_property and compound name')
            presentation = scoped.get('selector_presentation')
            if presentation is not None:
                selector_property = scoped.get('selector_property', check.get('selector_property'))
                if (quantity['kind'] != 'coordinate' or not selector_property or
                        not isinstance(presentation, str) or not presentation.strip()):
                    raise ValueError('selector_presentation requires a coordinate and selector_property')
        # Reject scientific mapper literals rather than silently using or ignoring them.
        for obj in [check, check['quantity'], check.get('select_extremum', {}), *check.get('state', []), *check.get('records', []), *(s for scope in check.get('records', []) for s in scope.get('state', [])), *(scope.get('select_extremum', {}) for scope in check.get('records', []))]:
            for key in ('value','parsed_value','stored_value','target','tolerance','display_tolerance'):
                if key in obj:
                    raise ValueError('Mapper scientific literal is prohibited: ' + key)
        for state in [*check.get('state', []), *(s for scope in check.get('records', []) for s in scope.get('state', []))]:
            if state.get('kind') == 'interior':
                if (set(state) - {'kind', 'component', 'basis', 'phase'}
                        or not isinstance(state.get('component'), str) or not state['component'].strip()
                        or state.get('basis') not in ('x', 'w')
                        or ('phase' in state and (not isinstance(state['phase'], str) or not state['phase'].strip()))):
                    raise ValueError('Interior-component state requires component, x/w basis, optional exact phase and no numeric token or other fields')
            elif state.get('kind') in ('pure', 'absent'):
                if (not isinstance(state.get('component'), str) or not state['component'].strip()
                        or state.get('token_id') is not None):
                    raise ValueError('Semantic identity state requires a nonempty component name and no numeric token')
                if state.get('kind') == 'absent' and state.get('basis') not in ('x', 'w'):
                    raise ValueError('Absent-component state requires explicit x or w basis')
            elif state.get('token_id') not in token_ids:
                raise ValueError('State must refer to a known numeric token')
    grouped_continuations = {}
    for check in mapping.get('checks', []):
        source_ids = check.get('source_token_ids')
        if source_ids is None:
            continue
        if not isinstance(source_ids, list) or len(source_ids) < 2 or source_ids[0] != check['token_id']:
            raise ValueError('Grouped source_token_ids must begin with the primary check token')
        grouped_source(tokens, source_ids)
        for tid in source_ids[1:]:
            if tid in grouped_continuations:
                raise ValueError('Grouped continuation token belongs to multiple measurements')
            grouped_continuations[tid] = check['token_id']
    linked = {}
    for exclusion in mapping.get('exclusions', []):
        if 'continuation_of' not in exclusion:
            continue
        if exclusion['reason'] != 'label' or len(exclusion['tokens']) != 1 or 'continuation' not in exclusion.get('detail', '').casefold():
            raise ValueError('Grouped continuation requires one explicit label exclusion with a continuation explanation')
        tid = exclusion['tokens'][0]
        linked[tid] = exclusion['continuation_of']
    if linked != grouped_continuations:
        raise ValueError('Every grouped continuation must link exactly once to its checked primary')
    for check in mapping.get('checks', []):
        for state in [*check.get('state', []), *(st for scope in check.get('records', []) for st in scope.get('state', []))]:
            if state.get('token_id') in grouped_continuations:
                raise ValueError('Grouped state must refer to the primary token, not its continuation')
    if set(memberships) != token_ids or any(count != 1 for count in memberships.values()):
        raise ValueError('Every lexical token must be mapped exactly once: ' + dump({'missing': sorted(token_ids-set(memberships)), 'extra': sorted(set(memberships)-token_ids), 'duplicates': [k for k,v in memberships.items() if v!=1]}))


def run_answer(answer_id, run_root, raw_db, registry_dir):
    if not re.fullmatch(r'[A-Za-z0-9_.-]+', answer_id):
        raise ValueError('Invalid neutral answer id')
    run_root = Path(run_root).resolve(strict=True)
    tml.configure(raw_db, registry_dir, run_root)
    folder = run_root / 'public' / 'maps' / answer_id
    tokens = json.loads((folder/'tokens.json').read_text(encoding='utf-8-sig'))
    mapping = json.loads((folder/'mapping.json').read_text(encoding='utf-8-sig'))
    if mapping['answer_id'] != answer_id or any(t['answer_id'] != answer_id for t in tokens):
        raise ValueError('Answer id mismatch')
    validate_mapping(mapping, tokens)
    archive = Archive('resolver_' + answer_id, run_root)
    resolver = Resolver(archive, tokens, mapping)
    checked = {c['token_id']: c for c in mapping.get('checks', [])}
    exclusions = {tid: e for e in mapping.get('exclusions', []) for tid in e['tokens']}
    grouped_continuations = {tid: (check['token_id'], resolver.groups[check['token_id']]) for check in mapping.get('checks', []) if check.get('source_token_ids') for tid in check['source_token_ids'][1:]}
    rows = []
    with localcontext() as context:
        context.prec = 80
        for token in tokens:
            tid = token['token_id']
            if tid in checked:
                rows.append(resolve_artifact(folder, token, checked[tid]) if checked[tid].get('classification') == 'pipeline_artifact' or checked[tid].get('source_kind') == 'hardcoded_artifact' else resolver.resolve(checked[tid]))
            else:
                exclusion = exclusions[tid]
                continuation = grouped_continuations.get(tid)
                rows.append({**token, **({'continuation_of': continuation[0], 'source_token_ids': continuation[1]['source_token_ids'], 'source_literal': continuation[1]['source_literal']} if continuation else {}), 'unit': None, 'role': None, 'out_of_scope_reason': exclusion['reason'],
                             'property': None, 'cited_record': None, 'matched_record': None, 'stored_value': None,
                             'stored_unit': None, 'reported_digits': None, 'converted_stored_value': None,
                             'absolute_difference': None, 'relative_difference': None, 'tolerance_used': None,
                             'category': 'ambiguous' if exclusion['reason']=='ambiguous' else 'excluded',
                             'reason': exclusion.get('detail'), 'flags': [], 'lookup_ids': [], 'n_candidates': 0, 'viable_candidate_ids': []})
    categories = Counter(r['category'] for r in rows)
    result = {'schema_version': 1, 'answer_id': answer_id, 'rows': rows,
              'summary': {'total_tokens': len(rows), 'checked_tokens': len(checked), 'categories': dict(categories),
                          'not_found': sum('not_found' in r['flags'] for r in rows),
                          'exclusion_reasons': dict(Counter(r['out_of_scope_reason'] for r in rows if r['out_of_scope_reason']))},
              'lookup_ids': archive.lookup_ids, 'lookup_log': str(archive.path), 'mapping_notes': mapping.get('notes', []),
              'input_sha256': {name: hashlib.sha256((folder/name).read_bytes()).hexdigest() for name in ('mapping.json','tokens.json')},
              'resolver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'compare_core_sha256': hashlib.sha256((Path(__file__).parent/'compare_core.py').read_bytes()).hexdigest(),
              'tokenizer_sha256': hashlib.sha256((Path(__file__).parent/'tokenize_numbers.py').read_bytes()).hexdigest()}
    path = folder / 'resolved.json'
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str) + '\n', encoding='utf-8')
    print(dump({'answer_id': answer_id, 'summary': result['summary'], 'output': str(path)}))


def main():
    parser = argparse.ArgumentParser(description="Resolve one ThermoML answer mapping against a read-only raw archive.")
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--answer-id", required=True)
    parser.add_argument("--raw-db", type=Path, required=True)
    parser.add_argument("--registry-dir", type=Path, required=True)
    args = parser.parse_args()
    run_answer(args.answer_id, args.run_root, args.raw_db, args.registry_dir)

if __name__ == "__main__":
    main()
