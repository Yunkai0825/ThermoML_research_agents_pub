"""Recognize forbidden runtime locations independently of tool-copy layout."""
from pathlib import Path


def inside_skill_or_statistics(run_root: Path) -> bool:
    """A runtime may contain a frozen skill copy, but cannot live inside a skill."""
    run_root = Path(run_root).resolve(strict=True)
    if any(part.lower() == "_eval_stats" for part in run_root.parts):
        return True
    return any((parent / "SKILL.md").is_file()
               and (parent / "ThermoML" / "tools" / "provisional_export.py").is_file()
               for parent in (run_root, *run_root.parents))
