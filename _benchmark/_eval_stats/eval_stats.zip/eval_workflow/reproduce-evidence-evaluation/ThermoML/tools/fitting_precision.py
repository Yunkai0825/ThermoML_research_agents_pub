"""Default precision for continuous fitted outputs; raw measurements unchanged."""
from decimal import Decimal, ROUND_HALF_UP, localcontext
import re
from compare_core import compare
POLICY = 'continuous-fitting-4sf/1'
METHOD_TEXT='Exact denotes agreement within half the last displayed digit after exact unit conversion; continuous fitting outputs also qualify as Exact when the reported and reference values agree after rounding to four significant digits (ROUND_HALF_UP). Integer counts and model orders require exact equality. Source, state, unit, basis, missing-evidence and saved-curve precision checks remain enforced.'
ROLES = {'continuous_fitted_output','integer_output','input_reference','input_coordinate','not_applicable'}
def rounded_four(value):
    value=Decimal(str(value))
    if not value.is_finite():raise ValueError('finite fitted values required')
    if not value:return Decimal(0)
    with localcontext() as ctx:
        ctx.prec=max(34,len(value.as_tuple().digits)+8)
        return value.quantize(Decimal(1).scaleb(value.adjusted()-3),rounding=ROUND_HALF_UP)
def precision_role(check,ref=None):
    """Actual selected field/function determines eligibility, never condition/arm.
    Explicit roles are evidence-bearing semantic mapping decisions. Counts and
    population interpretations cannot be overridden. Unknown fields stay strict.
    """
    ref=ref or check.get('artifact_reference') or {};key=ref.get('key','')
    if check.get('integer_output') or key in {'n_points','rk_order'} or check.get('population_interpretation'):return 'integer_output'
    explicit=check.get('precision_role')
    if explicit is not None:
        if explicit not in ROLES:raise ValueError('unknown fitting precision role')
        return explicit
    if not ref:return 'not_applicable'
    curve=check.get('curve_verification') or ref.get('curve_verification')
    if curve:return 'input_reference' if curve.get('evaluation')=='ideal_baseline_at_reported_coordinate' else 'continuous_fitted_output'
    if re.fullmatch(r'A[0-9]+',key) or key in {'r_squared','rmse','bic','aic'}:return 'continuous_fitted_output'
    prop=check.get('property','').lower();pattern=ref.get('pattern','')
    if re.search(r'(?<![A-Za-z_])x\s*=\s*\(\?P<value>',pattern):return 'input_coordinate'
    if any(s in prop for s in ('pure-reference','pure reference','pure-density','pure density','pure-component molar','pure molar','ideal baseline')):return 'input_reference'
    if re.search(r'\bpure\b',prop) and not re.search(r'predict|fitted|curve',prop):return 'input_reference'
    if ref.get('generating_call',{}).get('tool')=='predict_from_rk' and ref.get('excerpt','').startswith('Max |excess| = '):return 'continuous_fitted_output'
    if 'Coefficients:' in pattern or 'Max' in pattern or re.search(r'Y.*=\s*\(\?P<value>',pattern):return 'continuous_fitted_output'
    if re.search(r'coefficient|r[ -]squared|r_squared|r²|bayesian information|residual|grid peak|\br2\b|rmse|\bbic\b|\baic\b|predict|extrem|maximum|minimum|fitted|fit result|model-selection metric|saved rk|rk curve|fitting',prop):return 'continuous_fitted_output'
    return 'not_applicable'
def compare_fitting(answer,stored,tolerance,role='continuous_fitted_output'):
    if role not in ROLES:raise ValueError('unknown fitting precision role')
    result=compare(answer,stored,'0' if role=='integer_output' else tolerance);original=result['category']
    if role=='integer_output' and Decimal(str(answer))!=Decimal(str(stored)):result['category']='miss'
    a=s=None
    if role=='continuous_fitted_output':
        a,s=rounded_four(answer),rounded_four(stored)
        if a==s:result['category']='exact'
    result['precision_role']=role
    result['precision_policy']={'id':POLICY,'role':role,'significant_digits':4,'rounding':'ROUND_HALF_UP','legacy_numeric_outcome':original,'rounded_reported_value':None if a is None else str(a),'rounded_reference_value':None if s is None else str(s),'applied':role=='continuous_fitted_output','matched_by':'display_tolerance' if original=='exact' else 'four_significant_digits' if result['category']=='exact' else 'unchanged_comparator'}
    return result


def compare_curve_precision(answer, stored, tolerance, bounds, role='continuous_fitted_output'):
    """Retain source-precision gating against every saved-curve uncertainty bound."""
    result=compare_fitting(answer,stored,tolerance,role)
    outcomes=[compare_fitting(answer,v,tolerance,role)['category'] for v in bounds]+[result['category']]
    if len(set(outcomes)) != 1:
        raise ValueError('source precision crosses verdict boundary; human context or stronger evidence required')
    result['precision_policy']['source_precision_interval']=list(bounds)
    return result
