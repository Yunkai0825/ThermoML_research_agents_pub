"""Prepare one-answer packets and render recorded reviewer instructions.

This module prepares files only. It never starts a reviewer process.
"""
from __future__ import annotations
import argparse
from datetime import datetime
import hashlib
import json
import re
import shutil
import subprocess
from pathlib import Path
from filesystem_paths import io_path
from tokenize_numbers import tokenize
from artifact_preparation_gate import ensure_for_answer
from sanitize_answer import sanitize_bytes, check_artifact, public_receipt, annotated_text

PLACEHOLDER = re.compile(r"\{\{([A-Z][A-Z0-9_]*)\}\}")
ROLES = {"numerical-reviewer", "scientific-reviewer", "reconciler"}
BINDINGS = ("ANSWER_ID", "ANSWER_PATH", "QUESTION_PATH", "PACKET_DIR", "INITIAL_REVIEW_DIR",
            "RECONCILIATION_DIR", "SCIENTIFIC_REVIEW_DIR", "NUMERICAL_METHOD_PATH",
            "QUALITY_CHECKS_PATH", "MAPPING_CONTRACT_PATH", "SCIENTIFIC_METHOD_PATH",
            "INTERPRETATIONS_PATH", "SOURCE_BINDINGS_PATH", "TOOLS_DIR", "PYTHON",
            "ARTIFACT_MANIFEST_PATH", "ARTIFACT_DIR", "OUTPUT_SCHEMA_PATH",
            "SOURCE_COMMAND_PREFIX", "RESOLVE_COMMAND", "INITIAL_CHECK_COMMAND",
            "SCIENTIFIC_CHECK_COMMAND", "RECONCILIATION_CHECK_COMMAND",
            "SCREENING_CHECK_PATH", "CHECK_REQUESTS_PATH", "PROVISIONAL_BUILD_COMMAND", "PROVISIONAL_DIR")
ORCHESTRATOR_BINDINGS = ("RUN_CONTRACT_PATH", "SOURCE_PROFILE_PATH", "RUNTIME_ROOT",
                         "PUBLICATION_ROOT", "READINESS_RECEIPT_PATH")
COMMAND_KEYS = ("SOURCE_COMMAND_PREFIX", "RESOLVE_COMMAND", "INITIAL_CHECK_COMMAND",
                "SCIENTIFIC_CHECK_COMMAND", "RECONCILIATION_CHECK_COMMAND", "PROVISIONAL_BUILD_COMMAND")
GROUP_BINDINGS = ("GROUP_ID", "GROUP_MANIFEST_PATH", "RUN_ROOT", "RECONCILIATION_DIR",
                  "NUMERICAL_METHOD_PATH", "QUALITY_CHECKS_PATH", "MAPPING_CONTRACT_PATH",
                  "INTERPRETATIONS_PATH", "SOURCE_BINDINGS_PATH", "TOOLS_DIR", "PYTHON",
                  "GROUP_CHECK_COMMAND", "PROVISIONAL_BUILD_COMMAND", "PROVISIONAL_DIR")
GROUP_COMMAND_KEYS = ("GROUP_CHECK_COMMAND", "PROVISIONAL_BUILD_COMMAND")
GROUP_INPUT_KEYS = ("GROUP_MANIFEST_PATH", "NUMERICAL_METHOD_PATH", "QUALITY_CHECKS_PATH",
                    "MAPPING_CONTRACT_PATH", "INTERPRETATIONS_PATH", "SOURCE_BINDINGS_PATH",
                    "TOOLS_DIR")
ROLE_SCHEMA = {"numerical-reviewer": "INITIAL_REVIEW_SCHEMA.md",
               "scientific-reviewer": "SCIENTIFIC_REVIEW_SCHEMA.md",
               "reconciler": "RECONCILIATION_SCHEMA.md"}
ROLE_INPUT_KEYS = {
    "numerical-reviewer": ("PACKET_DIR", "ANSWER_PATH", "QUESTION_PATH", "NUMERICAL_METHOD_PATH",
                            "QUALITY_CHECKS_PATH", "MAPPING_CONTRACT_PATH", "INTERPRETATIONS_PATH",
                            "SOURCE_BINDINGS_PATH", "TOOLS_DIR", "ARTIFACT_MANIFEST_PATH", "ARTIFACT_DIR",
                            "OUTPUT_SCHEMA_PATH"),
    "scientific-reviewer": ("PACKET_DIR", "ANSWER_PATH", "QUESTION_PATH", "SCIENTIFIC_METHOD_PATH",
                            "INTERPRETATIONS_PATH", "SOURCE_BINDINGS_PATH", "TOOLS_DIR",
                            "ARTIFACT_MANIFEST_PATH", "ARTIFACT_DIR",
                            "OUTPUT_SCHEMA_PATH"),
    "reconciler": ("PACKET_DIR", "ANSWER_PATH", "QUESTION_PATH", "INITIAL_REVIEW_DIR",
                   "SCREENING_CHECK_PATH", "CHECK_REQUESTS_PATH", "NUMERICAL_METHOD_PATH", "QUALITY_CHECKS_PATH",
                   "MAPPING_CONTRACT_PATH", "INTERPRETATIONS_PATH", "SOURCE_BINDINGS_PATH",
                   "TOOLS_DIR", "ARTIFACT_MANIFEST_PATH", "ARTIFACT_DIR", "OUTPUT_SCHEMA_PATH"),
}

def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()

def sha(path: Path) -> str:
    return sha_bytes(path.read_bytes())

def json_bytes(value) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")

def prepare_packet(answer_id: str, answer_path: Path, packet_dir: Path,
                   private_provenance: Path, source_text: Path | None = None,
                   artifact_dir: Path | None = None, artifact_files: list[str] | None = None,
                   transform_provenance: Path | None = None, level: str | None = None,
                   *, question_path: Path | None = None):
    if question_path is None:
        raise ValueError("original question path is required")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", answer_id):
        raise ValueError("invalid one-answer ID")
    packet_dir = io_path(packet_dir).resolve()
    if packet_dir.exists() and any(packet_dir.iterdir()):
        raise ValueError("packet directory is not empty; refusing to overwrite review inputs")
    private_provenance = io_path(private_provenance).resolve()
    if "private" not in {part.lower() for part in private_provenance.parts}:
        raise ValueError("source provenance must be in a private directory")
    if private_provenance.is_relative_to(packet_dir):
        raise ValueError("source provenance cannot be in worker packet")
    if private_provenance.exists():
        raise ValueError("refusing to overwrite private packet provenance")
    answer_path = io_path(answer_path).resolve(strict=True)
    question_path = io_path(question_path).resolve(strict=True)
    if answer_path.is_relative_to(packet_dir):
        raise ValueError("original answer must remain outside worker packet")
    if (question_path == answer_path or question_path.is_relative_to(packet_dir)
            or not question_path.is_file()):
        raise ValueError("original question must be a separate file outside worker packet")
    question = question_path.read_bytes()
    if not question or question == answer_path.read_bytes():
        raise ValueError("original question must be nonempty and distinct from the answer")
    try:
        question.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ValueError("original question must be UTF-8") from exc
    if level is None:
        level = next((part for part in reversed(answer_path.parts) if part in ("Query", "Analysis", "Main")), "Query")
    preparation = ensure_for_answer(answer_path, level, private_provenance.parent / 'artifact_preparation')
    original = answer_path.read_bytes()
    result = sanitize_bytes(original, level)
    data = result["text"].encode("utf-8")
    if source_text is not None and source_text.read_bytes() != data:
        raise ValueError("supplied review copy must match the deterministic sanitization")
    if transform_provenance is not None:
        transform = json.loads(transform_provenance.read_text(encoding="utf-8-sig"))
        if (transform.get("source_answer_sha256") != result["source_answer_sha256"]
                or transform.get("packet_answer_sha256") != result["packet_answer_sha256"]):
            raise ValueError("supplied transform receipt does not match sanitization")
    selected = []
    if artifact_dir is None and artifact_files:
        raise ValueError("artifact files require an artifact directory")
    if artifact_dir is not None:
        artifact_dir = io_path(artifact_dir).resolve(strict=True)
        if not artifact_dir.is_dir() or not artifact_files:
            raise ValueError("explicit artifact file allowlist required")
        if len(artifact_files) != len(set(artifact_files)):
            raise ValueError("duplicate artifact allowlist entry")
        for rel in artifact_files:
            relative = Path(rel)
            if relative.is_absolute() or ".." in relative.parts or "." in relative.parts:
                raise ValueError("artifact allowlist path must be relative and normalized")
            if any(part.lower() in {"eval", "_eval_stats", "reconciliation", "review"} for part in relative.parts):
                raise ValueError("evaluation or review artifact cannot be copied")
            if relative.name.lower() in {"evaluation.json", "evaluated_answer.md", "claim_review.json"}:
                raise ValueError("evaluation output cannot be copied")
            src = (artifact_dir / relative).resolve(strict=True)
            if not src.is_relative_to(artifact_dir) or not src.is_file():
                raise ValueError("artifact must be a regular file under artifact directory")
            public_root=(answer_path.parent/'eval/artifacts').resolve()
            if not src.is_relative_to(public_root):raise ValueError('artifact allowlist must select own answer prepared eval/artifacts files')
            check_artifact(src, original)
            selected.append((relative, src))
    tokens = tokenize(result["text"], answer_id)
    private_provenance.parent.mkdir(parents=True, exist_ok=True)
    private_provenance.with_name(private_provenance.stem + '_artifact_preparation.json').write_bytes(json_bytes(preparation))
    packet_dir.mkdir(parents=True, exist_ok=True)
    (packet_dir / "answer.md").write_bytes(data)
    (packet_dir / "question.md").write_bytes(question)
    (packet_dir / "tokens.json").write_bytes(json_bytes(tokens))
    (packet_dir / "annotated.txt").write_bytes(annotated_text(result["text"], tokens).encode("utf-8"))
    artifacts = []
    for relative, src in selected:
        dst = packet_dir / "artifacts" / relative
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        role=('deterministic_fitting_tool_calls' if src.name=='fitting_tool_calls_verbatim.md' else 'context_only' if src.suffix.lower()=='.md' or 'completed_fits' in src.name.lower() else 'fixed_saved_data_or_plot')
        primary=role!='context_only' and src.suffix.lower()!='.py' and not src.name.endswith('_arguments.json')
        artifacts.append({"path":relative.as_posix(),"sha256":sha(dst),"numeric_primary_eligible":primary,
                          "use":"pipeline_artifact_and_source_evidence" if primary else "context_only",
                          "eligibility":{"root":"own_answer/eval/artifacts","owner_answer_id":answer_id,
                              "source_path":src.relative_to((answer_path.parent/"eval/artifacts").resolve()).as_posix(),
                              "source_sha256":sha(src),"transform":"identity copy","source_role":role}})
    provenance = {"answer_id": answer_id, "source_answer_path": str(answer_path),
                  "source_answer_sha256": result["source_answer_sha256"],
                  "packet_source_path": str(packet_dir / "answer.md"),
                  "packet_source_mode": "sanitized_authored_answer",
                  "packet_answer_sha256": result["packet_answer_sha256"], "token_count": len(tokens),
                  "question_source_path": str(question_path),
                  "question_sha256": sha_bytes(question),
                  "artifact_files": artifacts, "artifact_scoring_allowed": True,
                  "sanitization": {k: v for k, v in result.items() if k != "text"}}
    private_provenance.parent.mkdir(parents=True, exist_ok=True)
    private_provenance.write_bytes(json_bytes(provenance))
    (packet_dir / "BLIND_INPUT.json").write_bytes(json_bytes(
        public_receipt(answer_id, result, packet_dir, artifacts, sha_bytes(question))))
    return provenance

def render_template(source: str, bindings: dict[str, str],
                    allowed: tuple[str, ...] = BINDINGS) -> str:
    unknown = set(bindings) - set(allowed)
    if unknown:
        raise ValueError("unknown bindings: " + ", ".join(sorted(unknown)))
    required = set(PLACEHOLDER.findall(source))
    missing = required - set(bindings)
    if missing:
        raise ValueError("missing bindings: " + ", ".join(sorted(missing)))
    rendered = PLACEHOLDER.sub(lambda match: str(bindings[match.group(1)]), source)
    if PLACEHOLDER.search(rendered) or "{{" in rendered or "}}" in rendered:
        raise ValueError("unexpanded instruction placeholder")
    return rendered

def _other_id(text: str, own: str, all_ids: list[str]) -> str | None:
    for other in all_ids:
        if other != own and re.search(r"(?<![A-Za-z0-9_])" + re.escape(other) + r"(?![A-Za-z0-9_])", text):
            return other
    return None

def render_instructions(template_dir: Path, profile_template: Path, role: str,
                        bindings: dict[str, str], all_ids: list[str], output_dir: Path,
                        model: str, settings: dict, command_argv: dict[str, list[str]]) -> dict:
    if role == "reconciler":
        raise ValueError("reconciliation uses the group adapter for one or more answers; use render-group")
    if role not in ROLES or set(bindings) != set(BINDINGS):
        raise ValueError("role or complete binding set invalid")
    if set(command_argv) != set(COMMAND_KEYS) or any(not isinstance(v, list) or not v or not all(isinstance(x, str) and x for x in v) for v in command_argv.values()):
        raise ValueError("all executable command argv arrays required")
    for key in COMMAND_KEYS:
        if bindings[key] != subprocess.list2cmdline(command_argv[key]):
            raise ValueError("rendered command differs from executable argv: " + key)
    answer_id = bindings["ANSWER_ID"]
    if answer_id not in all_ids or len(all_ids) != len(set(all_ids)):
        raise ValueError("answer ID not in unique input inventory")
    if Path(bindings["OUTPUT_SCHEMA_PATH"]).name != ROLE_SCHEMA[role]:
        raise ValueError("reviewer output schema does not match role")
    if role == "reconciler" and any(bindings[key] == "not applicable" for key in
                                    ("INITIAL_REVIEW_DIR", "SCREENING_CHECK_PATH", "CHECK_REQUESTS_PATH", "PROVISIONAL_BUILD_COMMAND", "PROVISIONAL_DIR")):
        raise ValueError("reconciliation requires assigned initial review, full screening and provisional build")
    system_sources = [template_dir / "common.system.md",
                      template_dir / (role + ".system.md"), profile_template]
    task_source = template_dir / (role + ".task.md")
    for path in [*system_sources, task_source]:
        if not path.is_file():
            raise ValueError("missing instruction template " + str(path))
    system = "\n\n".join(render_template(p.read_text(encoding="utf-8"), bindings) for p in system_sources) + "\n"
    task = render_template(task_source.read_text(encoding="utf-8"), bindings) + "\n"
    foreign = _other_id(system + task + json.dumps(bindings), answer_id, all_ids)
    if foreign:
        raise ValueError("instruction refers to another answer ID " + foreign)
    effective = system + "\n" + task
    output_dir.mkdir(parents=True, exist_ok=True)
    files = {"rendered_system.md": system.encode("utf-8"), "rendered_task.md": task.encode("utf-8"),
             "effective_instruction.md": effective.encode("utf-8")}
    for name, data in files.items():
        (output_dir / name).write_bytes(data)
    record = {"role": role, "answer_id": answer_id, "model": model, "settings": settings,
              "transport": "prepared_not_submitted", "placement": "pending_dispatch_record",
              "submitted_effective_sha256": None,
              "input_allowlist": list(dict.fromkeys(
                  bindings[k] for k in ROLE_INPUT_KEYS[role] if bindings[k] != "not applicable")),
              "template_sha256": {p.name: sha(p) for p in [*system_sources, task_source]},
              "rendered_sha256": {name: sha_bytes(data) for name, data in files.items()},
              "bindings": bindings, "command_argv": command_argv}
    (output_dir / "INSTRUCTION_RECORD.json").write_bytes(json_bytes(record))
    return record

def render_group_reconciler(template_dir: Path, profile_template: Path,
                            bindings: dict[str, str], all_ids: list[str], output_dir: Path,
                            model: str, settings: dict,
                            command_argv: dict[str, list[str]]) -> dict:
    """Render one reconciler context for a validated group of one or more answers."""
    from group_contract import validate_question_authorization
    if set(bindings) != set(GROUP_BINDINGS):
        raise ValueError("group reconciler binding set invalid")
    if (set(command_argv) != set(GROUP_COMMAND_KEYS)
            or any(not isinstance(v, list) or not v
                   or not all(isinstance(x, str) and x for x in v)
                   for v in command_argv.values())):
        raise ValueError("group check and provisional build argv arrays required")
    for key in GROUP_COMMAND_KEYS:
        if bindings[key] != subprocess.list2cmdline(command_argv[key]):
            raise ValueError("rendered command differs from executable argv: " + key)
    run_root = Path(bindings["RUN_ROOT"]).resolve(strict=True)
    manifest_path = Path(bindings["GROUP_MANIFEST_PATH"]).resolve(strict=True)
    group = validate_question_authorization(run_root, manifest_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    question_exception = manifest.get("question_exception")
    group_id = group["group_id"]
    member_ids = group["member_ids"]
    if (bindings["GROUP_ID"] != group_id or not member_ids
            or len(all_ids) != len(set(all_ids))
            or not set(member_ids).issubset(set(all_ids))):
        raise ValueError("group identity or answer inventory mismatch")
    if manifest_path != (run_root / "groups" / group_id / "group.json").resolve():
        raise ValueError("group manifest is outside its scoped runtime directory")
    system_source = template_dir / "reconciler.system.md"
    task_source = template_dir / "reconciler.task.md"
    if not system_source.is_file() or not task_source.is_file():
        raise ValueError("missing group reconciler instruction template")
    members = json.loads(manifest_path.read_text(encoding="utf-8"))["members"]
    member_levels = {}
    profile_sources = {}
    supplements = []
    for member in members:
        blind = member["blind_id"]
        receipt_path = run_root / "public" / "maps" / blind / "BLIND_INPUT.json"
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        level = receipt.get("level")
        if level not in {"Query", "Analysis", "Main"}:
            raise ValueError("unknown answer level for group member " + blind)
        supplement_path = profile_template.parent / (level + ".system.md")
        if not supplement_path.is_file():
            raise ValueError("missing group member profile template " + str(supplement_path))
        if blind == member_ids[0] and profile_template.resolve(strict=True) != supplement_path.resolve(strict=True):
            raise ValueError("profile template must match the first group member's level")
        member_levels[blind] = level
        profile_sources[level] = supplement_path
        supplement = render_template(
            supplement_path.read_text(encoding="utf-8"), bindings,
            GROUP_BINDINGS)
        supplements.append(f"Answer {blind} ({level}) only:\n{supplement}")
    system = render_template(system_source.read_text(encoding="utf-8"),
                             bindings, GROUP_BINDINGS)
    if question_exception is not None:
        system += ("\n\nThis group's different original questions have an explicit "
                   "authorization. For each member, use that member's own chemical "
                   "system, requested conditions, and coverage scope. Group membership "
                   "does not establish a shared source inventory or measurement "
                   "denominator. Verify each member against its own question and raw evidence.")
    system += "\n\n" + "\n\n".join(supplements) + "\n"
    task = render_template(task_source.read_text(encoding="utf-8"), bindings,
                           GROUP_BINDINGS) + "\n"
    # Every listed member is permitted; reject an ID outside the declared group.
    for other in all_ids:
        if other not in member_ids and re.search(
                r"(?<![A-Za-z0-9_])" + re.escape(other) + r"(?![A-Za-z0-9_])",
                system + task + json.dumps(bindings)):
            raise ValueError("group instruction refers to another answer ID " + other)
    effective = system + "\n" + task
    output_dir.mkdir(parents=True, exist_ok=True)
    files = {"rendered_system.md": system.encode("utf-8"),
             "rendered_task.md": task.encode("utf-8"),
             "effective_instruction.md": effective.encode("utf-8")}
    for name, data in files.items():
        (output_dir / name).write_bytes(data)
    member_paths = []
    for member in json.loads(manifest_path.read_text(encoding="utf-8"))["members"]:
        blind, unit = member["blind_id"], member["review_unit_id"]
        member_paths.extend((run_root / "public" / "maps" / blind,
                             run_root / "guidance" / blind / "GUIDANCE.json",
                             run_root / "screening" / unit / "SCREENING_CHECK.json",
                             run_root / "screening" / unit / "CHECK_REQUESTS.json"))
    inputs = [bindings[key] for key in GROUP_INPUT_KEYS
              if bindings[key] != "not applicable"]
    inputs.extend(str(path) for path in member_paths)
    record = {"role": "reconciler", "group_id": group_id,
              "member_ids": member_ids, "member_levels": member_levels,
              "question_exception_id": (question_exception["id"]
                                        if question_exception is not None else None),
              "group_manifest_sha256": group["group_manifest_sha256"],
              "member_input_sha256": group["member_input_sha256"],
              "model": model, "settings": settings,
              "transport": "prepared_not_submitted",
              "placement": "pending_dispatch_record",
              "submitted_effective_sha256": None,
              "input_allowlist": list(dict.fromkeys(inputs)),
              "template_sha256": {p.name: sha(p)
                                  for p in [system_source, task_source,
                                            *profile_sources.values()]},
              "rendered_sha256": {name: sha_bytes(data)
                                  for name, data in files.items()},
              "bindings": bindings, "command_argv": command_argv}
    (output_dir / "INSTRUCTION_RECORD.json").write_bytes(json_bytes(record))
    return record

def render_orchestrator(template_dir: Path, output_dir: Path, model: str,
                        settings: dict, input_allowlist: list[str],
                        bindings: dict[str, str]) -> dict:
    """Record authored run-level system and task bytes without one-answer common text."""
    if set(bindings) != set(ORCHESTRATOR_BINDINGS):
        raise ValueError("orchestrator binding set invalid")
    sources = [template_dir / "orchestrator.system.md", template_dir / "orchestrator.task.md"]
    if not all(path.is_file() for path in sources):
        raise ValueError("missing orchestrator instruction template")
    if not isinstance(input_allowlist, list) or not all(isinstance(x, str) and x for x in input_allowlist):
        raise ValueError("orchestrator input allowlist must list paths")
    if any(value != "not applicable" and value not in input_allowlist for value in bindings.values()):
        raise ValueError("orchestrator binding missing from input allowlist")
    system = render_template(sources[0].read_text(encoding="utf-8"), bindings,
                             ORCHESTRATOR_BINDINGS) + "\n"
    task = render_template(sources[1].read_text(encoding="utf-8"), bindings,
                           ORCHESTRATOR_BINDINGS) + "\n"
    files = {"rendered_system.md": system.encode("utf-8"),
             "rendered_task.md": task.encode("utf-8"),
             "effective_instruction.md": (system + "\n" + task).encode("utf-8")}
    output_dir.mkdir(parents=True, exist_ok=True)
    for name, data in files.items():
        (output_dir / name).write_bytes(data)
    record = {"role": "orchestrator", "model": model, "settings": settings,
              "transport": "prepared_not_submitted", "placement": "pending_dispatch_record",
              "submitted_effective_sha256": None, "input_allowlist": input_allowlist,
              "template_sha256": {p.name: sha(p) for p in sources},
              "rendered_sha256": {name: sha_bytes(data) for name, data in files.items()},
              "bindings": bindings, "command_argv": {}}
    (output_dir / "INSTRUCTION_RECORD.json").write_bytes(json_bytes(record))
    return record

def record_orchestrator_ingestion(instruction_dir: Path, evidence_path: Path,
                                   loaded_at: str) -> dict:
    """Record workflow files loaded into an interactive orchestrator context."""
    record_path = instruction_dir / "INSTRUCTION_RECORD.json"
    record = json.loads(record_path.read_text(encoding="utf-8"))
    if record.get("role") != "orchestrator" or record.get("transport") != "prepared_not_submitted":
        raise ValueError("only a prepared orchestrator record can be ingested")
    try:
        timestamp = datetime.fromisoformat(loaded_at.replace("Z", "+00:00"))
        if timestamp.tzinfo is None:
            raise ValueError("timezone required")
    except ValueError as exc:
        raise ValueError("loaded_at must be a timezone-aware ISO timestamp") from exc
    rendered = {name: sha(instruction_dir / name) for name in (
        "rendered_system.md", "rendered_task.md", "effective_instruction.md")}
    if rendered != record.get("rendered_sha256"):
        raise ValueError("rendered orchestrator files changed")
    evidence_path = evidence_path.resolve(strict=True)
    evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
    if (evidence.get("kind") not in {"tool_read_record", "explicit_invocation"}
            or evidence.get("loaded_files_sha256") != rendered):
        raise ValueError("activation evidence does not bind loaded workflow files")
    record.update(instruction_mode="loaded_workflow_files",
                  transport="loaded_workflow_files",
                  placement="active_orchestrator_context",
                  submitted_effective_sha256=None,
                  model_availability=("unavailable" if record.get("model") == "unavailable" else "known"),
                  settings_availability=("unavailable" if record.get("settings") == {"availability": "unavailable"} else "known"),
                  activation={"loaded_at": loaded_at, "evidence_path": str(evidence_path),
                              "evidence_sha256": sha(evidence_path)})
    record_path.write_bytes(json_bytes(record))
    return record

def record_submission(instruction_dir: Path, submitted_bytes: bytes, placement: str, transport: str):
    """Record actual submitted text after an external launcher returns its transport evidence."""
    path = instruction_dir / "INSTRUCTION_RECORD.json"
    record = json.loads(path.read_text(encoding="utf-8"))
    if record.get("instruction_mode") == "loaded_workflow_files":
        raise ValueError("loaded orchestrator instructions were not a submitted worker message")
    expected = (instruction_dir / "effective_instruction.md").read_bytes()
    if submitted_bytes != expected:
        raise ValueError("submitted instruction differs from rendered effective instruction")
    if not placement or not transport or transport == "prepared_not_submitted":
        raise ValueError("actual placement and transport required")
    record.update(transport=transport, placement=placement,
                  submitted_effective_sha256=sha_bytes(submitted_bytes))
    path.write_bytes(json_bytes(record))
    return record

if __name__ == "__main__":
    arg = argparse.ArgumentParser()
    sub = arg.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("--answer-id", required=True)
    prep.add_argument("--level", choices=("Query", "Analysis", "Main"), required=True)
    prep.add_argument("--answer-path", type=Path, required=True)
    prep.add_argument("--question-path", type=Path, required=True)
    prep.add_argument("--packet-dir", type=Path, required=True)
    prep.add_argument("--packet-source", type=Path)
    prep.add_argument("--artifact-dir", type=Path)
    prep.add_argument("--artifact-file", action="append", default=[])
    prep.add_argument("--private-provenance", type=Path, required=True)
    prep.add_argument("--transform-provenance", type=Path)
    render = sub.add_parser("render")
    render.add_argument("--templates", type=Path, required=True)
    render.add_argument("--profile-template", type=Path, required=True)
    render.add_argument("--role", choices=sorted(ROLES), required=True)
    render.add_argument("--bindings-json", type=Path, required=True)
    render.add_argument("--all-ids-json", type=Path, required=True)
    render.add_argument("--out", type=Path, required=True)
    render.add_argument("--model", required=True)
    render.add_argument("--settings-json", type=Path, required=True)
    render.add_argument("--argv-json", type=Path, required=True)
    group_render = sub.add_parser("render-group")
    group_render.add_argument("--templates", type=Path, required=True)
    group_render.add_argument("--profile-template", type=Path, required=True)
    group_render.add_argument("--bindings-json", type=Path, required=True)
    group_render.add_argument("--all-ids-json", type=Path, required=True)
    group_render.add_argument("--out", type=Path, required=True)
    group_render.add_argument("--model", required=True)
    group_render.add_argument("--settings-json", type=Path, required=True)
    group_render.add_argument("--argv-json", type=Path, required=True)
    orch = sub.add_parser("render-orchestrator")
    orch.add_argument("--templates", type=Path, required=True)
    orch.add_argument("--out", type=Path, required=True)
    orch.add_argument("--model", required=True)
    orch.add_argument("--settings-json", type=Path, required=True)
    orch.add_argument("--input-allowlist-json", type=Path, required=True)
    orch.add_argument("--bindings-json", type=Path, required=True)
    ingest = sub.add_parser("record-orchestrator-ingestion")
    ingest.add_argument("--instruction-dir", type=Path, required=True)
    ingest.add_argument("--evidence", type=Path, required=True)
    ingest.add_argument("--loaded-at", required=True)
    args = arg.parse_args()
    if args.command == "prepare":
        result = prepare_packet(args.answer_id, args.answer_path, args.packet_dir,
                                args.private_provenance, args.packet_source,
                                args.artifact_dir, args.artifact_file,
                                args.transform_provenance, args.level,
                                question_path=args.question_path)
    elif args.command == "record-orchestrator-ingestion":
        result = record_orchestrator_ingestion(args.instruction_dir, args.evidence,
                                               args.loaded_at)
    elif args.command == "render-orchestrator":
        settings = json.loads(args.settings_json.read_text(encoding="utf-8-sig"))
        allowlist = json.loads(args.input_allowlist_json.read_text(encoding="utf-8-sig"))
        bindings = json.loads(args.bindings_json.read_text(encoding="utf-8-sig"))
        result = render_orchestrator(args.templates, args.out, args.model, settings,
                                     allowlist, bindings)
    elif args.command == "render-group":
        bindings = json.loads(args.bindings_json.read_text(encoding="utf-8-sig"))
        ids = json.loads(args.all_ids_json.read_text(encoding="utf-8-sig"))
        settings = json.loads(args.settings_json.read_text(encoding="utf-8-sig"))
        command_argv = json.loads(args.argv_json.read_text(encoding="utf-8-sig"))
        result = render_group_reconciler(args.templates, args.profile_template,
                                          bindings, ids, args.out, args.model,
                                          settings, command_argv)
    else:
        bindings = json.loads(args.bindings_json.read_text(encoding="utf-8-sig"))
        ids = json.loads(args.all_ids_json.read_text(encoding="utf-8-sig"))
        settings = json.loads(args.settings_json.read_text(encoding="utf-8-sig"))
        command_argv = json.loads(args.argv_json.read_text(encoding="utf-8-sig"))
        result = render_instructions(args.templates, args.profile_template, args.role,
                                     bindings, ids, args.out, args.model, settings, command_argv)
    print(json.dumps(result, ensure_ascii=False, indent=2))

