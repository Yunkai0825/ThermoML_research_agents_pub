"""Filesystem-only Windows extended paths; evidence locators remain relative."""
import os
from pathlib import Path

def io_path(value):
    path=Path(value)
    if os.name!='nt':
        return path
    text=os.path.abspath(str(path))
    if text.startswith('\\\\?\\'):
        return Path(text)
    if text.startswith('\\\\'):
        return Path('\\\\?\\UNC\\'+text[2:])
    return Path('\\\\?\\'+text)
