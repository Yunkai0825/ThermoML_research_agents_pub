"""Validate explicit, immutable provenance for historical one-answer review reuse."""
from __future__ import annotations

import json
import re
from pathlib import Path

from review_contract import read, sha

SCHEMA = "thermoml-historical-review-compatibility/1"
ROLES = {"numerical-reviewer", "scientific-reviewer"}
EVIDENCE = ("original_report", "historical_method", "original_task",
            "run_status", "session_events", "launcher")


def receipt_path(run_root: Path, role: str, blind_id: str) -> Path:
    if role not in ROLES or not re.fullmatch(r"[A-Za-z0-9_.-]+", blind_id):
        raise ValueError("historical cache role or blind ID invalid")
    return run_root / "private" / "cache_compatibility" / role / (blind_id + ".json")


def _source(run_root: Path, role: str, blind_id: str, entry: dict) -> Path:
    if not isinstance(entry, dict) or set(entry) != {"path", "sha256"}:
        raise ValueError("historical evidence entry invalid")
    path = (run_root / entry["path"]).resolve(strict=True)
    allowed = (run_root / "private" / "cache_sources" / role / blind_id).resolve(strict=True)
    if not path.is_relative_to(allowed) or not path.is_file() or sha(path) != entry["sha256"]:
        raise ValueError("historical evidence missing, outside scoped cache or changed")
    return path


def validate(run_root: Path, role: str, blind_id: str, answer_path: Path,
             current_report: Path, current_method: Path, root_audit: dict | None = None) -> dict:
    """Return verified receipt and evidence paths; never infer root approval."""
    run_root = run_root.resolve(strict=True)
    path = receipt_path(run_root, role, blind_id)
    receipt = read(path)
    original_id = receipt.get("historical_id")
    if (receipt.get("schema") != SCHEMA or receipt.get("role") != role
            or receipt.get("current_blind_id") != blind_id
            or not isinstance(original_id, str) or not re.fullmatch(r"[A-Za-z0-9_.-]+", original_id)
            or receipt.get("answer_sha256") != sha(answer_path)
            or receipt.get("current_report_sha256") != sha(current_report)
            or receipt.get("current_method_sha256") != sha(current_method)
            or receipt.get("root_accepted") is not True
            or receipt.get("isolated_one_answer") is not True
            or not isinstance(receipt.get("semantic_equivalence_evidence"), list)
            or not receipt["semantic_equivalence_evidence"]
            or any(not isinstance(x, str) or not x for x in receipt["semantic_equivalence_evidence"])):
        raise ValueError("historical cache acceptance, role, identity, answer or method binding invalid")
    evidence = receipt.get("evidence")
    if not isinstance(evidence, dict) or set(evidence) != set(EVIDENCE):
        raise ValueError("historical cache evidence manifest incomplete")
    files = {name: _source(run_root, role, blind_id, evidence[name]) for name in EVIDENCE}
    if sha(files["original_report"]) != receipt.get("original_report_sha256"):
        raise ValueError("historical original report hash mismatch")
    if sha(files["historical_method"]) != receipt.get("historical_method_sha256"):
        raise ValueError("historical method hash mismatch")
    source_report = read(files["original_report"])
    if (source_report.get("answer_id", source_report.get("blind_id")) != original_id
            or source_report.get("source_sha256", source_report.get("answer_sha256")) != receipt["answer_sha256"]):
        raise ValueError("historical original report belongs to another answer")
    if role == "numerical-reviewer" and source_report.get("rubric_sha256") != sha(files["historical_method"]):
        raise ValueError("historical numerical report method differs from saved method")
    if sha(current_report) != sha(files["original_report"]):
        raise ValueError("historical initial review bytes were rewritten")
    if role == "scientific-reviewer":
        if source_report.get("methods_sha256") not in (None, sha(files["historical_method"])):
            raise ValueError("historical scientific report method differs from saved method")
    task = files["original_task"].read_text(encoding="utf-8-sig")
    if original_id not in task:
        raise ValueError("historical task does not identify one original answer")
    run_status = read(files["run_status"])
    if (run_status.get("state") != "process_completed" or run_status.get("exit_code") != 0
            or run_status.get("blind_id", run_status.get("answer_id")) != original_id):
        raise ValueError("historical session did not complete for original answer")
    event_types = [json.loads(line).get("type") for line in
                   files["session_events"].read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    if "thread.started" not in event_types or "turn.completed" not in event_types:
        raise ValueError("historical session event record incomplete")
    if not files["launcher"].read_bytes() or not receipt.get("launcher_evidence_note"):
        raise ValueError("historical launcher evidence incomplete")
    binding = receipt.get("submission_binding")
    if binding == "exact_submitted_bytes":
        if (receipt.get("submitted_task_sha256") != sha(files["original_task"])
                or run_status.get("submitted_task_sha256") != sha(files["original_task"])):
            raise ValueError("exact historical submission bytes not independently bound")
    elif binding == "corroborated_not_exact":
        if receipt.get("submitted_task_sha256") is not None or not receipt.get("submission_limitation"):
            raise ValueError("historical submission certainty overstated")
    else:
        raise ValueError("historical submission binding invalid")
    if root_audit is None or root_audit.get("cache_compatibility_sha256", {}).get(role) != sha(path):
        raise ValueError("root audit does not bind historical cache receipt")
    return {"receipt": receipt, "receipt_path": path, "files": files,
            "historical_id": original_id}
