"""Build a blind, one-answer canonical preview outside publication."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from canonical_export import encoded, numeric_document
from review_contract import initial_check, read, reconciliation_check, sha
from group_contract import validate_group
from runtime_location import inside_skill_or_statistics

DRAFT_SCHEMA = "thermoml-benchmark-eval-provisional/1"
MANIFEST_SCHEMA = "thermoml-provisional-build/1"
DRAFT_FILES = ("draft_evaluation.json", "evaluated_answer.md")


def _group_unit(run_root: Path, review_unit_id: str, group: dict, member: dict) -> dict:
    """Use the validated scoped manifest as the sole source of member identity."""
    gid = group["group_id"]
    manifest_path = run_root / "groups" / gid / "group.json"
    if sha(manifest_path) != group["group_manifest_sha256"]:
        raise ValueError("scoped group manifest changed after validation")
    manifest = read(manifest_path)
    if (not isinstance(member, dict)
            or set(member) != {"review_unit_id", "blind_id"}
            or member["review_unit_id"] != review_unit_id
            or member["blind_id"] not in group["member_ids"]
            or member not in manifest["members"]):
        raise ValueError("provisional unit is outside its validated group")
    return member


def _instruction_identity(run_root: Path, blind: str, group: dict) -> dict | None:
    """Bind a preview only to the currently validated scoped group."""
    gid = group["group_id"]
    if blind not in group["member_ids"]:
        raise ValueError("provisional answer is outside its declared group")
    folder = run_root / "instructions" / "reconciler" / gid
    path = folder / "INSTRUCTION_RECORD.json"
    if not path.is_file():
        return None
    row = read(path)
    effective = folder / "effective_instruction.md"
    member_levels = {
        member: read(run_root / "public" / "maps" / member / "BLIND_INPUT.json").get("level")
        for member in group["member_ids"]
    }
    if (row.get("role") != "reconciler" or row.get("group_id") != gid
            or "answer_id" in row
            or row.get("member_ids") != group["member_ids"]
            or row.get("member_levels") != member_levels
            or row.get("group_manifest_sha256") != group["group_manifest_sha256"]
            or row.get("member_input_sha256") != group["member_input_sha256"]
            or row.get("rendered_sha256", {}).get("effective_instruction.md") != sha(effective)):
        raise ValueError("group reconciler instruction identity or bytes changed")
    return {"path": path.relative_to(run_root).as_posix(), "sha256": sha(path),
            "group_id": gid, "member_ids": group["member_ids"],
            "transport": row.get("transport"),
            "submission_complete": row.get("transport") != "prepared_not_submitted"}

def _clear_draft(out: Path) -> None:
    for name in (*DRAFT_FILES, "PROVISIONAL_MANIFEST.json"):
        (out / name).unlink(missing_ok=True)


def build_provisional(run_root: Path, review_unit_id: str, out: Path,
                      *, group_context: dict, group_member: dict) -> dict:
    """Build one member preview inside an already validated scoped group."""
    run_root = run_root.resolve(strict=True)
    if inside_skill_or_statistics(run_root):
        raise ValueError("run root must be outside installed skill and statistics publication")
    unit = _group_unit(run_root, review_unit_id, group_context, group_member)
    blind = unit["blind_id"]
    expected = run_root / "reconciliation" / review_unit_id / "provisional"
    if not expected.resolve().is_relative_to(run_root) or out.resolve() != expected.resolve():
        raise ValueError("provisional output must be this unit's runtime reconciliation folder")
    _clear_draft(out)
    packet = run_root / "public" / "maps" / blind
    rules = run_root / "public"
    decision_path = run_root / "reconciliation" / review_unit_id / "reconciliation.json"
    decision = read(decision_path)
    screen_dir = run_root / "screening" / review_unit_id
    scoped_compatibility = packet / "INITIAL_COMPATIBILITY.json"
    initial = initial_check(packet, blind, rules / "RUBRIC.txt",
                            scoped_compatibility if scoped_compatibility.is_file() else None)
    final = reconciliation_check(packet, unit, decision, rules / "RUBRIC.txt",
                                 rules / "HUMAN_INTERPRETATIONS.txt", rules / "QUALITY_CHECKS.txt",
                                 screen_dir / "CHECK_REQUESTS.json", screen_dir / "SCREENING_CHECK.json",
                                 rules / "SCREEN_RULES.txt", rules / "tools" / "screen.py")
    if initial["status"] not in {"PASS", "PASS_WITH_QUESTIONS"} or final["status"] == "FAIL":
        _clear_draft(out)
        raise ValueError("one-answer reconciliation is not ready for a provisional build: "
                         + str((initial, final)))
    instruction = _instruction_identity(run_root, blind, group_context)
    base = {"schema": MANIFEST_SCHEMA, "blind_id": blind, "review_unit_id": review_unit_id,
            "stats_eligible": False, "publication_eligible": False,
            "decision_sha256": sha(decision_path),
            "screening_check_sha256": sha(screen_dir / "SCREENING_CHECK.json"),
            "packet_answer_sha256": sha(packet / "answer.md"),
            "instruction": instruction}
    if final["status"] == "PASS_WITH_QUESTIONS":
        # A prior preview of this unit must not survive a new unresolved decision.
        out.mkdir(parents=True, exist_ok=True)
        _clear_draft(out)
        manifest = {**base, "status": "BLOCKED_UNACCEPTED",
                    "questions": decision.get("unresolved_questions", []), "files": {}}
        (out / "PROVISIONAL_MANIFEST.json").write_bytes(encoded(manifest))
        return {"status": "BLOCKED_UNACCEPTED", "stats_eligible": False,
                "review_unit_id": review_unit_id, "blind_id": blind, "out": str(out),
                "manifest": str(out / "PROVISIONAL_MANIFEST.json")}
    # This preview deliberately never opens private identity or source provenance.
    # Accepted export independently checks those, root acceptance and judgment freeze.
    identity = {"answer_id": blind, "level": "blind", "arm": "blind", "question": ""}
    document, answer = numeric_document(packet, unit, decision, identity,
                                        packet / "answer.md", run_root)
    document["schema"] = DRAFT_SCHEMA
    document["answer"]["folder"] = str(out)
    document["answer"]["result_file"] = "evaluated_answer.md"
    document["how_to_read"].append(
        "Provisional blind preview only; no root acceptance, identity join or statistics eligibility.")
    draft_bytes = encoded(document)
    manifest = {**base, "status": "UNACCEPTED", "questions": [], 
                "files": {"draft_evaluation.json": hashlib.sha256(draft_bytes).hexdigest(),
                          "evaluated_answer.md": hashlib.sha256(answer).hexdigest()}}
    out.mkdir(parents=True, exist_ok=True)
    (out / "draft_evaluation.json").write_bytes(draft_bytes)
    (out / "evaluated_answer.md").write_bytes(answer)
    (out / "PROVISIONAL_MANIFEST.json").write_bytes(encoded(manifest))
    return {"status": "UNACCEPTED", "stats_eligible": False,
            "review_unit_id": review_unit_id, "blind_id": blind, "out": str(out),
            "manifest": str(out / "PROVISIONAL_MANIFEST.json")}


def build_group_provisional(run_root: Path, group_manifest: Path) -> dict:
    """Run the same one-answer preview primitive for every sealed group member."""
    run_root = run_root.resolve(strict=True)
    validated = validate_group(run_root, group_manifest, require_returns=True)
    manifest = read(group_manifest)
    outputs = []
    for member in manifest["members"]:
        uid = member["review_unit_id"]
        out = run_root / "reconciliation" / uid / "provisional"
        outputs.append(build_provisional(run_root, uid, out,
                                         group_context=validated,
                                         group_member=member))
    return {"group_id": validated["group_id"],
            "group_return_sha256": validated["group_return_sha256"],
            "members": outputs, "stats_eligible": False}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--group-manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    print(json.dumps(build_group_provisional(args.run_root, args.group_manifest),
                     indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
