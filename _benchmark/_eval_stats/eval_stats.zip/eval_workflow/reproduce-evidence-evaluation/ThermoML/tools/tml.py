"""tml.py -- read-only lookups over the raw ThermoML archive for claim review.

The archive is ThermoML v2020-09-30 as stored verbatim in thermoml_raw.db (one JSON document per paper),
plus the canonical ID registries (GLOBlit_N, GLOBcomp_N, GLOBprop_N, GLOBmeas_N, ...).
Nothing is written anywhere except the lookup log.

Every call needs explicit runtime bindings. The call and its full output are appended to public/tools/lookups/tml_<answer-id>.jsonl, and the
first output line names the lookup id (<TAG>-L<n>) that a judgement cites as evidence.

Commands (REF = a DOI or GLOBlit_N; C = a compound name, GLOBcomp_N or InChIKey):
  paper REF [--abstract]           citation, compounds with sample purity, every block in one line
  block REF BLOCK                  one block's definition and value ranges
  points REF BLOCK [filters]       data points; BLKpoint numbers are 1-based positions in the block
      --T v [--Ttol 0.051]  --P v [--Ptol 0.6]  --x v [--xtol 0.0011] [--xorg ORGNUM]
      --nearest v (sort by |x - v|)  --points 1,5,10-20  --limit 80
  find REF VALUE [--tol t | --rel r] [--scale s] [--block N]
                                   where a number occurs in one paper (properties, variables, constraints);
                                   default tolerance = half a unit of the last digit typed; --scale multiplies
                                   VALUE first (e.g. mPa*s -> Pa*s: --scale 0.001)
  compound QUERY                   canonical compounds by name, synonym, formula, InChIKey or GLOBcomp id
  blocks --comp C [--comp C ...] [--contains] [--prop S] [--method S] [--ranges] [--limit 60]
                                   blocks of a chemical system (exact component set unless --contains)
  coverage --comp C [--comp C ...] [--contains] [--prop S] [--ranges]
                                   papers / blocks / points per property for a system
  id ID                            GLOBlit_N[::PROPblock_M[::BLKpoint_K]], GLOBcomp_N, GLOBprop_N, GLOBmeas_N,
                                   GLOBphase_N, GLOBvar_N, GLOBconstr_N, GLOBsolvent_N
  sql "SELECT ..."                 read-only SQL over papers (doi, title, year, journal, first_author, n_*),
                                   compounds, blocks, block_properties, block_variables (200 rows max)
"""
import argparse
import csv
import hashlib
import io
import json
import re
import sqlite3
import sys
import time
from contextlib import redirect_stdout
from pathlib import Path

RAW = None
REG = None
LOGDIR = None

def configure(raw_db, registry_dir, run_root):
    global RAW, REG, LOGDIR, _db, _csv, _papers
    raw_db=Path(raw_db).absolute()
    registry_dir=Path(registry_dir).resolve(strict=True)
    run_root=Path(run_root).resolve(strict=True)
    if not raw_db.is_file() or not registry_dir.is_dir():
        raise ValueError("Expected an existing raw SQLite file and registry directory")
    if _db is not None:
        _db.close()
    RAW, REG, LOGDIR = raw_db, registry_dir, run_root/"public"/"tools"/"lookups"
    _db=None
    _csv={}
    _papers={}

INCHIKEY = re.compile(r"^[A-Z]{14}-[A-Z]{10}-[A-Z]$")

_db = None
_csv = {}
_papers = {}


def readonly_uri(path):
    """SQLite read-only URI for local/mapped paths and Windows UNC shares."""
    path=Path(path)
    return ("file:"+str(path)+"?mode=ro") if str(path).startswith("\\\\") else path.as_uri()+"?mode=ro"

def db():
    global _db
    if _db is None:
        _db = sqlite3.connect(readonly_uri(RAW), uri=True)
        _db.execute("PRAGMA query_only=ON")
    return _db


def arr(x):
    if x is None:
        return []
    return x if isinstance(x, list) else [x]


def reg(name):
    if name not in _csv:
        with open(REG / name, encoding="utf-8-sig", newline="") as f:
            _csv[name] = list(csv.DictReader(f))
    return _csv[name]


def lit_of(doi):
    d = doi.lower()
    for r in reg("reference_ids.csv"):
        if r["doi"].lower() == d:
            return r["lit_num_id"]
    return "-"


def resolve_ref(ref):
    ref = ref.strip()
    m = re.fullmatch(r"GLOBlit_(\d+)", ref)
    if m:
        for r in reg("reference_ids.csv"):
            if r["lit_num_id"] == ref:
                return r["doi"]
        raise SystemExit(f"unknown literature id {ref}")
    ref = re.sub(r"^(https?://(dx\.)?doi\.org/|doi:)", "", ref, flags=re.I)
    row = db().execute("SELECT doi FROM papers WHERE doi = ?", (ref,)).fetchone()
    if row:
        return row[0]
    for r in reg("reference_ids.csv"):
        if r["doi"].lower() == ref.lower():
            return r["doi"]
    raise SystemExit(f"DOI not in the archive: {ref}")


def paper_json(doi):
    if doi not in _papers:
        row = db().execute("SELECT json_data FROM papers WHERE doi = ?", (doi,)).fetchone()
        if not row:
            raise SystemExit(f"DOI not in the archive: {doi}")
        _papers[doi] = json.loads(row[0])
    return _papers[doi]


def one_key(d, prefix=""):
    """The single meaningful key/value of a ThermoML choice element (ignores tml_elements)."""
    if not isinstance(d, dict):
        return None, None
    for k, v in d.items():
        if k != "tml_elements" and k.startswith(prefix):
            return k, v
    return None, None


def compounds_of(j):
    out = {}
    for c in arr(j.get("Compound")):
        org = c.get("RegNum", {}).get("nOrgNum")
        names = arr(c.get("sCommonName"))
        out[org] = {
            "name": names[0] if names else (c.get("sIUPACName") or "?"),
            "names": names,
            "formula": c.get("sFormulaMolec", ""),
            "inchikey": c.get("sStandardInChIKey", ""),
            "samples": arr(c.get("Sample")),
        }
    return out


def glob_comp(inchikey):
    for r in reg("compound_ids.csv"):
        if r["inchi_key"] == inchikey:
            return r["comp_num_id"]
    return "-"


def purity_text(samples):
    parts = []
    for s in samples:
        bits = [f"sample {s.get('nSampleNm')}", s.get("eSource", "")]
        for p in arr(s.get("purity")):
            step = []
            for k in ("nPurityMass", "nPurityMol", "nPurityVol", "nUnknownPerCent", "nWaterMassPerCent", "nWaterMolPerCent", "nHalideMassPerCent"):
                if k in p:
                    step.append(f"{k[1:]}={p[k]}")
            for k in ("ePurifMethod", "sPurifMethod", "eAnalMeth", "sAnalMeth"):
                if k in p:
                    step.append(f"{k[1:]}={'/'.join(map(str, arr(p[k])))}")
            if step:
                bits.append(f"step {p.get('nStep', '?')}: " + ", ".join(step))
        parts.append("; ".join(b for b in bits if b))
    return " | ".join(parts) if parts else "no sample record"


def block_of(j, bn):
    for b in arr(j.get("PureOrMixtureData")):
        if int(b.get("nPureOrMixtureDataNumber", -1)) == int(bn):
            return b
    raise SystemExit(f"block {bn} not in this paper (blocks: {[x.get('nPureOrMixtureDataNumber') for x in arr(j.get('PureOrMixtureData'))]})")


SHORT = {
    "eTemperature": "T", "ePressure": "P", "eComponentComposition": "", "eSolventComposition": "solv:",
    "eMiscellaneous": "misc:", "eBioVariables": "bio:", "eParticipantAmount": "amount:",
}


def comp_label(kind_name, org, comps):
    nm = comps.get(org, {}).get("name", f"org{org}")
    n = (kind_name or "").lower()
    if n.startswith("mole fraction"):
        return f"x({nm})"
    if n.startswith("mass fraction"):
        return f"w({nm})"
    if n.startswith("volume fraction"):
        return f"phi({nm})"
    if n.startswith("molality"):
        return f"m({nm})/(mol/kg)"
    if "molarity" in n or "amount concentration" in n:
        return f"c({nm}):{kind_name}"
    return f"{kind_name}({nm})"


def describe_block(j, b):
    comps = compounds_of(j)
    out = {}
    out["components"] = [comps.get(c.get("RegNum", {}).get("nOrgNum"), {}).get("name", "?") + f" [org {c.get('RegNum', {}).get('nOrgNum')}]" for c in arr(b.get("Component"))]
    out["phases"] = [p.get("ePhase") for p in arr(b.get("PhaseID"))]
    props = {}
    for p in arr(b.get("Property")):
        k, grp = one_key(p.get("Property-MethodID", {}).get("PropertyGroup", {}))
        grp = grp or {}
        name = grp.get("ePropName") or grp.get("sPropName") or "?"
        meth = grp.get("eMethodName") or grp.get("sMethodName") or ""
        solv = [comps.get(r.get("nOrgNum"), {}).get("name", "?") for r in arr(p.get("Solvent", {}).get("RegNum"))] if p.get("Solvent") else []
        props[p.get("nPropNumber")] = {
            "name": name, "group": k, "method": meth, "presentation": p.get("ePresentation", ""),
            "phase": p.get("PropPhaseID", {}).get("ePropPhase", ""), "solvent": solv,
            "unc_note": (p.get("CombinedUncertainty") or {}).get("eCombUncertEvalMethod", ""),
            "conf": (p.get("CombinedUncertainty") or {}).get("nCombUncertLevOfConfid", ""),
        }
    vars_ = {}
    for v in arr(b.get("Variable")):
        vid = v.get("VariableID", {})
        k, nm = one_key(vid.get("VariableType", {}))
        org = (vid.get("RegNum") or {}).get("nOrgNum")
        if k == "eTemperature":
            lab = "T/K"
        elif k == "ePressure":
            lab = "P/kPa"
        elif org is not None:
            lab = comp_label(nm, org, comps)
        else:
            lab = f"{SHORT.get(k, k)}{nm}"
        vars_[v.get("nVarNumber")] = {"label": lab, "type": k, "name": nm, "org": org, "phase": (v.get("VarPhaseID") or {}).get("eVarPhase", "")}
    cons = []
    for c in arr(b.get("Constraint")):
        cid = c.get("ConstraintID", {})
        k, nm = one_key(cid.get("ConstraintType", {}))
        org = (cid.get("RegNum") or {}).get("nOrgNum")
        lab = "T/K" if k == "eTemperature" else "P/kPa" if k == "ePressure" else (comp_label(nm, org, comps) if org is not None else f"{SHORT.get(k, k)}{nm}")
        cons.append({"label": lab, "value": c.get("nConstraintValue"), "digits": c.get("nConstrDigits"), "phase": (c.get("ConstraintPhaseID") or {}).get("eConstraintPhase", "")})
    out["properties"], out["variables"], out["constraints"] = props, vars_, cons
    out["n_points"] = len(arr(b.get("NumValues")))
    return out


def unc_text(pv):
    bits = []
    cu = pv.get("CombinedUncertainty")
    for c in arr(cu):
        if isinstance(c, dict):
            for k in ("nCombExpandUncertValue", "nCombStdUncertValue", "nCombUncertValue"):
                if k in c:
                    bits.append(("U=" if "Expand" in k else "u=") + str(c[k]))
    for c in arr(pv.get("PropUncertainty")):
        if isinstance(c, dict):
            for k in ("nExpandUncertValue", "nStdUncertValue"):
                if k in c:
                    bits.append(("Uprop=" if "Expand" in k else "uprop=") + str(c[k]))
    for c in arr(pv.get("PropRepeatability")):
        if isinstance(c, dict) and "nPropRepeatValue" in c:
            bits.append(f"repeat={c['nPropRepeatValue']}")
    if "nPropDeviceSpecValue" in pv:
        bits.append(f"device={pv['nPropDeviceSpecValue']}")
    return ("(" + ", ".join(bits) + ")") if bits else ""


def point_rows(b, d):
    rows = []
    for i, nv in enumerate(arr(b.get("NumValues")), start=1):
        vv = {x.get("nVarNumber"): x.get("nVarValue") for x in arr(nv.get("VariableValue"))}
        pv = {x.get("nPropNumber"): x for x in arr(nv.get("PropertyValue"))}
        rows.append((i, vv, pv))
    return rows


def ranges_text(b, d):
    rows = point_rows(b, d)
    parts = []
    for vn, v in d["variables"].items():
        vals = [r[1][vn] for r in rows if r[1].get(vn) is not None]
        if vals:
            parts.append(f"{v['label']} {min(vals):g}..{max(vals):g}")
    for pn, p in d["properties"].items():
        vals = [r[2][pn].get("nPropValue") for r in rows if pn in r[2] and r[2][pn].get("nPropValue") is not None]
        if vals:
            parts.append(f"[{pn}] {min(vals):g}..{max(vals):g}")
    return "; ".join(parts)


def head_block(doi, j, bn, b, d, with_ranges=True):
    print(f"{doi} ({lit_of(doi)})  PROPblock_{bn}  points={d['n_points']}  components: {', '.join(d['components'])}  phase: {', '.join(p for p in d['phases'] if p)}")
    for pn, p in d["properties"].items():
        extra = f"; solvent {', '.join(p['solvent'])}" if p["solvent"] else ""
        unc = f"; uncertainty {p['unc_note']} {p['conf']}%".rstrip() if p["unc_note"] else ""
        print(f"  property [{pn}] {p['name']}  ({p['group']}; method: {p['method'] or '-'}; {p['presentation']}; phase {p['phase']}{extra}{unc})")
    print("  variables: " + "; ".join(f"[{vn}] {v['label']}" for vn, v in d["variables"].items()))
    if d["constraints"]:
        print("  constraints: " + "; ".join(f"{c['label']} = {c['value']}" for c in d["constraints"]))
    if with_ranges and d["n_points"]:
        print("  ranges: " + ranges_text(b, d))


def cmd_paper(a):
    doi = resolve_ref(a.ref)
    j = paper_json(doi)
    c = j.get("Citation", {})
    print(f"{doi}  ({lit_of(doi)})")
    print(f"  {'; '.join(arr(c.get('sAuthor')))} ({c.get('yrPubYr')}). {c.get('sTitle')}. {c.get('sPubName')} {c.get('sVol', '')}, {c.get('sPage', '')}.")
    if a.abstract and c.get("sAbstract"):
        print("  abstract: " + str(c.get("sAbstract")))
    comps = compounds_of(j)
    print("compounds:")
    for org, cc in comps.items():
        print(f"  org {org}: {cc['name']} | {cc['formula']} | {cc['inchikey']} | {glob_comp(cc['inchikey'])} | {purity_text(cc['samples'])}")
    blocks = arr(j.get("PureOrMixtureData"))
    print(f"blocks ({len(blocks)} PureOrMixtureData; reaction blocks: {len(arr(j.get('ReactionData')))}):")
    for b in blocks:
        d = describe_block(j, b)
        props = "; ".join(f"[{pn}] {p['name']} ({p['method'] or '-'})" for pn, p in d["properties"].items())
        cons = (" | constraints " + ", ".join(f"{x['label']}={x['value']}" for x in d["constraints"])) if d["constraints"] else ""
        print(f"  PROPblock_{b.get('nPureOrMixtureDataNumber')}: {' + '.join(x.split(' [')[0] for x in d['components'])} | {props} | vars {', '.join(v['label'] for v in d['variables'].values())}{cons} | {d['n_points']} pts | {ranges_text(b, d)}")


def cmd_block(a):
    doi = resolve_ref(a.ref)
    j = paper_json(doi)
    b = block_of(j, a.block)
    d = describe_block(j, b)
    head_block(doi, j, a.block, b, d)


def parse_points(spec):
    out = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            lo, hi = part.split("-")
            out.update(range(int(lo), int(hi) + 1))
        elif part:
            out.add(int(part))
    return out


def fmt_point(i, vv, pv, d):
    bits = [f"BLKpoint_{i}"]
    for vn, v in d["variables"].items():
        bits.append(f"{v['label']}={vv.get(vn, '-')}")
    for pn, p in d["properties"].items():
        x = pv.get(pn)
        if x is not None:
            bits.append(f"[{pn}]={x.get('nPropValue')} {unc_text(x)}".rstrip())
    return " | ".join(bits)


def cmd_points(a):
    doi = resolve_ref(a.ref)
    j = paper_json(doi)
    b = block_of(j, a.block)
    d = describe_block(j, b)
    head_block(doi, j, a.block, b, d)
    rows = point_rows(b, d)
    tv = next((vn for vn, v in d["variables"].items() if v["type"] == "eTemperature"), None)
    pv_ = next((vn for vn, v in d["variables"].items() if v["type"] == "ePressure"), None)
    xv = None
    for vn, v in d["variables"].items():
        if v["org"] is not None and (a.xorg is None or int(v["org"]) == a.xorg):
            xv = vn
            break
    sel = []
    want = parse_points(a.points) if a.points else None
    for i, vv, pv in rows:
        if want is not None and i not in want:
            continue
        if a.T is not None and (tv is None or vv.get(tv) is None or abs(vv[tv] - a.T) > a.Ttol):
            continue
        if a.P is not None and (pv_ is None or vv.get(pv_) is None or abs(vv[pv_] - a.P) > a.Ptol):
            continue
        if a.x is not None and (xv is None or vv.get(xv) is None or abs(vv[xv] - a.x) > a.xtol):
            continue
        sel.append((i, vv, pv))
    if a.nearest is not None:
        if xv is None:
            raise SystemExit("--nearest needs a composition variable in this block")
        sel = [r for r in sel if r[1].get(xv) is not None]
        sel.sort(key=lambda r: abs(r[1][xv] - a.nearest))
    note = []
    if a.T is not None and tv is None:
        note.append("T is not a variable of this block (see constraints)")
    if a.P is not None and pv_ is None:
        note.append("P is not a variable of this block (see constraints)")
    print(f"selected {len(sel)} of {len(rows)} points" + (f" ({'; '.join(note)})" if note else "") + (f"; showing {min(len(sel), a.limit)}" if len(sel) > a.limit else ""))
    for r in sel[: a.limit]:
        print("  " + fmt_point(r[0], r[1], r[2], d))


def tol_of(s):
    s = s.strip().lower()
    if "e" in s:
        mant, ex = s.split("e")
        dec = len(mant.split(".")[1]) if "." in mant else 0
        return 0.5 * 10 ** (int(ex) - dec)
    dec = len(s.split(".")[1]) if "." in s else 0
    return 0.5 * 10 ** (-dec)


def cmd_find(a):
    doi = resolve_ref(a.ref)
    j = paper_json(doi)
    target = float(a.value) * a.scale
    tol = a.tol if a.tol is not None else (abs(target) * a.rel if a.rel is not None else tol_of(a.value) * abs(a.scale))
    hits = 0
    print(f"searching {doi} for {target:g} +/- {tol:g}")
    for b in arr(j.get("PureOrMixtureData")):
        bn = b.get("nPureOrMixtureDataNumber")
        if a.block is not None and int(bn) != a.block:
            continue
        d = describe_block(j, b)
        for c in d["constraints"]:
            if c["value"] is not None and abs(float(c["value"]) - target) <= tol:
                hits += 1
                print(f"  PROPblock_{bn} constraint {c['label']} = {c['value']}")
        for i, vv, pv in point_rows(b, d):
            hit = [f"[{pn}]" for pn, x in pv.items() if x.get("nPropValue") is not None and abs(x["nPropValue"] - target) <= tol]
            hit += [d["variables"].get(vn, {}).get("label", f"var{vn}") for vn, x in vv.items() if x is not None and abs(x - target) <= tol]
            if hit:
                hits += 1
                if hits <= a.limit:
                    print(f"  PROPblock_{bn} matched {', '.join(hit)}: " + fmt_point(i, vv, pv, d))
    print(f"{hits} match(es)" + (f"; first {a.limit} shown" if hits > a.limit else ""))


def comp_keys(q):
    """Resolve a compound reference to InChIKeys, with the matched canonical rows."""
    q = q.strip()
    rows = reg("compound_ids.csv")
    if re.fullmatch(r"GLOBcomp_\d+", q):
        r = [x for x in rows if x["comp_num_id"] == q]
        if not r:
            raise SystemExit(f"unknown compound id {q}")
        return [r[0]["inchi_key"]], r
    if INCHIKEY.match(q):
        return [q], [x for x in rows if x["inchi_key"] == q]
    ql = q.lower()
    r = [x for x in rows if x["comp_id"].lower() == ql or x["common_name"].lower() == ql]
    if r:
        return [x["inchi_key"] for x in r], r
    keys = [k for (k,) in db().execute("SELECT DISTINCT standard_inchi_key FROM compounds WHERE lower(common_name) = ?", (ql,))]
    if keys:
        return keys, [x for x in rows if x["inchi_key"] in keys]
    raise SystemExit(f"no compound named exactly '{q}'; try: tml compound '{q}'")


def cmd_compound(a):
    q = a.query.strip()
    ql = q.lower()
    rows = reg("compound_ids.csv")
    hits = []
    if re.fullmatch(r"GLOBcomp_\d+", q) or INCHIKEY.match(q):
        _, hits = comp_keys(q)
    else:
        exact = [x for x in rows if ql in (x["comp_id"].lower(), x["common_name"].lower()) or x["formula"].lower() == ql]
        sub = [x for x in rows if x not in exact and (ql in x["comp_id"].lower() or ql in x["common_name"].lower())]
        hits = exact + sorted(sub, key=lambda x: -int(x["n_papers"] or 0))
        syn = db().execute("SELECT standard_inchi_key, common_name, count(DISTINCT doi) FROM compounds WHERE lower(common_name) LIKE ? GROUP BY standard_inchi_key, common_name ORDER BY 3 DESC LIMIT 25", (f"%{ql}%",)).fetchall()
        known = {x["inchi_key"] for x in hits}
        for k, nm, n in syn:
            if k not in known:
                known.add(k)
                hits += [x for x in rows if x["inchi_key"] == k] or [{"comp_num_id": "-", "comp_id": nm, "inchi_key": k, "common_name": nm, "formula": "?", "n_papers": str(n)}]
    print(f"{len(hits)} compound(s) for '{q}' (showing {min(len(hits), a.limit)}):")
    for x in hits[: a.limit]:
        names = [n for (n,) in db().execute("SELECT DISTINCT common_name FROM compounds WHERE standard_inchi_key = ? LIMIT 8", (x["inchi_key"],))]
        print(f"  {x['comp_num_id']} | {x['common_name']} | {x['formula']} | {x['inchi_key']} | papers {x['n_papers']} | names in papers: {', '.join(names)}")


def system_blocks(a):
    targets = []
    for c in a.comp:
        keys, _ = comp_keys(c)
        targets.append(set(keys))
    per = []
    for keys in targets:
        s = {}
        for k in keys:
            for doi, org in db().execute("SELECT doi, org_num FROM compounds WHERE standard_inchi_key = ?", (k,)):
                s.setdefault(doi, set()).add(org)
        per.append(s)
    dois = set(per[0])
    for s in per[1:]:
        dois &= set(s)
    out = []
    for doi in sorted(dois):
        orgsets = [s[doi] for s in per]
        for bn, bt, nc, orgs_json, npts in db().execute("SELECT block_number, block_type, n_components, component_org_nums, n_datapoints FROM blocks WHERE doi = ?", (doi,)):
            if bt != "PureOrMixtureData":
                continue
            orgs = set(json.loads(orgs_json or "[]"))
            hit = all(orgs & os_ for os_ in orgsets)
            if not hit:
                continue
            if not a.contains and len(orgs) != len(targets):
                continue
            props = db().execute("SELECT prop_number, prop_name, method_name, presentation FROM block_properties WHERE doi = ? AND block_number = ? AND block_type = ?", (doi, bn, bt)).fetchall()
            if a.prop:
                props = [p for p in props if a.prop.lower() in (p[1] or "").lower()]
                if not props:
                    continue
            if a.method:
                props = [p for p in props if a.method.lower() in (p[2] or "").lower()]
                if not props:
                    continue
            out.append((doi, bn, orgs, props, npts))
    return out


def cmd_blocks(a):
    out = system_blocks(a)
    papers = sorted({o[0] for o in out})
    print(f"{len(out)} block(s) in {len(papers)} paper(s) for {' + '.join(a.comp)} ({'contains' if a.contains else 'exact component set'}" + (f"; property ~ '{a.prop}'" if a.prop else "") + (f"; method ~ '{a.method}'" if a.method else "") + ")")
    for doi, bn, orgs, props, npts in out[: a.limit]:
        j = paper_json(doi) if a.ranges else None
        cite = db().execute("SELECT first_author, year FROM papers WHERE doi = ?", (doi,)).fetchone()
        line = f"  {doi} ({lit_of(doi)}; {cite[0] if cite else '?'} {cite[1] if cite else ''}) PROPblock_{bn} | " + "; ".join(f"[{p[0]}] {p[1]} ({p[2] or '-'})" for p in props) + f" | {npts} pts"
        if a.ranges:
            b = block_of(j, bn)
            d = describe_block(j, b)
            line += f" | {ranges_text(b, d)}" + ((" | constraints " + ", ".join(f"{c['label']}={c['value']}" for c in d["constraints"])) if d["constraints"] else "")
        print(line)
    if len(out) > a.limit:
        print(f"  ... {len(out) - a.limit} more (raise --limit)")


def cmd_coverage(a):
    out = system_blocks(a)
    agg = {}
    for doi, bn, orgs, props, npts in out:
        for p in props:
            g = agg.setdefault(p[1], {"papers": set(), "blocks": 0, "points": 0, "T": []})
            g["papers"].add(doi)
            g["blocks"] += 1
            g["points"] += npts or 0
            if a.ranges:
                j = paper_json(doi)
                b = block_of(j, bn)
                d = describe_block(j, b)
                tv = [vn for vn, v in d["variables"].items() if v["type"] == "eTemperature"]
                vals = [r[1][tv[0]] for r in point_rows(b, d) if tv and r[1].get(tv[0]) is not None]
                vals += [float(c["value"]) for c in d["constraints"] if c["label"] == "T/K" and c["value"] is not None]
                g["T"] += vals
    print(f"{' + '.join(a.comp)} ({'contains' if a.contains else 'exact component set'}): {len(out)} block(s) in {len({o[0] for o in out})} paper(s); block point counts are summed per property (a block with two properties counts for both)")
    for name, g in sorted(agg.items(), key=lambda kv: -kv[1]["points"]):
        t = f" | T {min(g['T']):g}..{max(g['T']):g} K" if g["T"] else ""
        print(f"  {name}: {len(g['papers'])} paper(s), {g['blocks']} block(s), {g['points']} point(s){t}")


CSV_FOR = {"GLOBcomp": "compound_ids.csv", "GLOBprop": "property_ids.csv", "GLOBmeas": "measurement_ids.csv", "GLOBphase": "phase_ids.csv",
           "GLOBvar": "variable_ids.csv", "GLOBconstr": "constraint_ids.csv", "GLOBsolvent": "solvent_components.csv",
           "GLOBblocktype": "block_types.csv", "GLOBrxntype": "reaction_type_ids.csv", "GLOBlit": "reference_ids.csv"}


def cmd_id(a):
    s = a.ident.strip()
    m = re.fullmatch(r"(GLOBlit_\d+)::PROPblock_(\d+)(?:::BLKpoint_(\d+))?(?:::.*)?", s)
    if m:
        doi = resolve_ref(m.group(1))
        j = paper_json(doi)
        b = block_of(j, m.group(2))
        d = describe_block(j, b)
        c = j.get("Citation", {})
        print(f"{m.group(1)} = {doi}: {'; '.join(arr(c.get('sAuthor')))} ({c.get('yrPubYr')}). {c.get('sTitle')}. {c.get('sPubName')} {c.get('sVol', '')}, {c.get('sPage', '')}.")
        head_block(doi, j, m.group(2), b, d)
        if m.group(3):
            rows = point_rows(b, d)
            k = int(m.group(3))
            if not 1 <= k <= len(rows):
                raise SystemExit(f"BLKpoint_{k} out of range 1..{len(rows)}")
            r = rows[k - 1]
            print("  " + fmt_point(r[0], r[1], r[2], d))
        return
    m = re.fullmatch(r"(GLOB[a-z]+)_(\d+)", s)
    if m and m.group(1) in CSV_FOR:
        rows = reg(CSV_FOR[m.group(1)])
        key = next(iter(rows[0].keys()))
        r = [x for x in rows if x[key] == s]
        if not r:
            raise SystemExit(f"unknown id {s}")
        print(json.dumps(r[0], ensure_ascii=False))
        if m.group(1) == "GLOBlit":
            cmd_paper(argparse.Namespace(ref=s, abstract=False))
        return
    raise SystemExit(f"cannot resolve '{s}' (INSP_* inspection ids are run-time ledger ids, not archive records)")


def cmd_sql(a):
    q = a.query.strip().rstrip(";")
    if not re.match(r"(?is)^(select|with)\b", q) or re.search(r"(?i)\b(insert|update|delete|drop|alter|attach|pragma|create|replace|vacuum)\b", q):
        raise SystemExit("only a single read-only SELECT / WITH statement is allowed")
    cur = db().execute(q)
    cols = [c[0] for c in cur.description]
    print(" | ".join(cols))
    n = 0
    for row in cur:
        n += 1
        if n > 200:
            print("  ... (200 rows max)")
            break
        print(" | ".join(str(v)[:300] for v in row))
    print(f"{min(n, 200)} row(s)")


def main():
    ap = argparse.ArgumentParser(prog="tml", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run-root", type=Path, required=True)
    ap.add_argument("--answer-id", required=True)
    ap.add_argument("--raw-db", type=Path, required=True)
    ap.add_argument("--registry-dir", type=Path, required=True)
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("paper"); p.add_argument("ref"); p.add_argument("--abstract", action="store_true"); p.set_defaults(fn=cmd_paper)
    p = sp.add_parser("block"); p.add_argument("ref"); p.add_argument("block", type=int); p.set_defaults(fn=cmd_block)
    p = sp.add_parser("points"); p.add_argument("ref"); p.add_argument("block", type=int)
    p.add_argument("--T", type=float); p.add_argument("--Ttol", type=float, default=0.051)
    p.add_argument("--P", type=float); p.add_argument("--Ptol", type=float, default=0.6)
    p.add_argument("--x", type=float); p.add_argument("--xtol", type=float, default=0.0011); p.add_argument("--xorg", type=int)
    p.add_argument("--nearest", type=float); p.add_argument("--points"); p.add_argument("--limit", type=int, default=80)
    p.set_defaults(fn=cmd_points)
    p = sp.add_parser("find"); p.add_argument("ref"); p.add_argument("value")
    p.add_argument("--tol", type=float); p.add_argument("--rel", type=float); p.add_argument("--scale", type=float, default=1.0)
    p.add_argument("--block", type=int); p.add_argument("--limit", type=int, default=40); p.set_defaults(fn=cmd_find)
    p = sp.add_parser("compound"); p.add_argument("query"); p.add_argument("--limit", type=int, default=15); p.set_defaults(fn=cmd_compound)
    for name, fn in (("blocks", cmd_blocks), ("coverage", cmd_coverage)):
        p = sp.add_parser(name); p.add_argument("--comp", action="append", required=True)
        p.add_argument("--contains", action="store_true"); p.add_argument("--prop"); p.add_argument("--method")
        p.add_argument("--ranges", action="store_true"); p.add_argument("--limit", type=int, default=60); p.set_defaults(fn=fn)
    p = sp.add_parser("id"); p.add_argument("ident"); p.set_defaults(fn=cmd_id)
    p = sp.add_parser("sql"); p.add_argument("query"); p.set_defaults(fn=cmd_sql)
    a = ap.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", a.answer_id):
        raise SystemExit("Invalid answer id")
    configure(a.raw_db, a.registry_dir, a.run_root)
    LOGDIR.mkdir(parents=True, exist_ok=True)
    tag = "tml_" + a.answer_id
    log = LOGDIR / f"{tag}.jsonl"
    n = sum(1 for _ in open(log, encoding="utf-8")) + 1 if log.exists() else 1
    lid = f"{tag}-L{n:03d}"
    argv = sys.argv[sys.argv.index(a.cmd):] if a.cmd in sys.argv else sys.argv[1:]
    buf = io.StringIO()
    t0 = time.time()
    status = "ok"
    try:
        with redirect_stdout(buf):
            a.fn(a)
    except SystemExit as e:
        status = f"refused: {e}"
        buf.write(f"ERROR: {e}\n")
    out = buf.getvalue()
    rec = {"id": lid, "ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "argv": argv, "status": status, "seconds": round(time.time() - t0, 2),
           "output_sha256": hashlib.sha256(out.encode("utf-8")).hexdigest(), "output": out}
    with open(log, "a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    sys.stdout.write(f"[lookup {lid}] tml {' '.join(argv)}\n{out}")


if __name__ == "__main__":
    main()
