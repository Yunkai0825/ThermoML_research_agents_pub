from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ENTRY = Path(__file__).resolve().parents[1] / 'prepare_artifacts.py'
spec = importlib.util.spec_from_file_location('prepare_artifacts_entry_test', ENTRY)
entry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(entry)


def fixture(session, value):
    session.mkdir(parents=True)
    arguments = json.dumps({'property': 'density', 'temperature': 298.15})
    result = 'R2=' + value + '\nAutomatic grounding diagnostic: retained in archival source.'
    history = ('# Saved run history\n\n### Step 1 [main]: `fit_block`\n\n'
               '<details><summary>Arguments</summary>\n\n```json\n' + arguments +
               '\n```\n</details>\n\n- **Result:** ' + str(len(result)) +
               ' chars\n\n<details><summary>Result</summary>\n\n```\n' + result +
               '\n```\n</details>\n')
    (session/'run_history.md').write_text(history, encoding='utf-8')
    (session/'final_full_context.md').write_text('# Full context\n', encoding='utf-8')
    (session/'data').mkdir()
    (session/'plots').mkdir()
    (session/'data'/'fit.csv').write_text('r2\n'+value+'\n', encoding='utf-8')
    (session/'plots'/'fit.png').write_bytes(b'fixed-plot-'+value.encode())
    return arguments, result


class PreparationEntryTest(unittest.TestCase):
    def test_batch_before_review_and_repeat_is_idempotent(self):
        with tempfile.TemporaryDirectory(prefix='thermoml-preparation-test-') as temp:
            temp = Path(temp).resolve()
            base, private = temp/'benchmark', temp/'private'
            analysis = base/'Analysis'/'test_run_full_capability'/'Q9.1_run_20000101'
            main = base/'Main'/'test_run_full_capability'/'Q9.2_run_20000101'
            a_args, a_result = fixture(analysis, '0.991')
            m_args, m_result = fixture(main/'analysis_runs'/'run_1', '0.883')
            destinations = [analysis/'eval'/'artifacts', main/'eval'/'artifacts'/'analysis_runs'/'run_1']
            destinations[0].mkdir(parents=True)
            (destinations[0]/'run_history.md').write_text('old preview', encoding='utf-8')
            # There are no result.md/evaluation.json files: evidence precedes evaluation.
            report = entry.ensure_prepared(base, private)
            self.assertEqual((report['stage'], report['status'], report['sessions']),
                             ('before_evaluation', 'COMPLETE', 2))
            self.assertTrue(Path(report['receipt']).parent.samefile(private))
            snapshots = []
            for dest, args, result, value in zip(destinations, (a_args,m_args), (a_result,m_result), ('0.991','0.883')):
                self.assertEqual({p.name for p in dest.iterdir()}, {'data','plots','run_history_verbatim.md','fitting_tool_calls_verbatim.md'})
                history = (dest/'run_history_verbatim.md').read_text(encoding='utf-8')
                self.assertIn(args, history)
                self.assertIn(result, history)
                fitting = (dest/'fitting_tool_calls_verbatim.md').read_text(encoding='utf-8')
                self.assertIn(args, fitting)
                self.assertIn(result, fitting)
                self.assertEqual((dest/'plots'/'fit.png').read_bytes(), b'fixed-plot-'+value.encode())
                snapshots.append((dest/'run_history_verbatim.md').read_bytes())
            rerun = entry.ensure_prepared(base, private)
            stable_keys = ('source', 'target', 'source_hashes', 'archive_sha256', 'fitting_archive_sha256', 'steps', 'gaps', 'files', 'status')
            self.assertEqual([{key: r[key] for key in stable_keys} for r in report['records']],
                             [{key: r[key] for key in stable_keys} for r in rerun['records']])
            for dest, before in zip(destinations, snapshots):
                self.assertEqual((dest/'run_history_verbatim.md').read_bytes(), before)

    def test_empty_benchmark_does_not_require_evaluation(self):
        with tempfile.TemporaryDirectory(prefix='thermoml-empty-preparation-') as temp:
            base = Path(temp).resolve()
            report = entry.ensure_prepared(base, base/'private')
            self.assertEqual((report['sessions'], report['gaps'], report['status']), (0,0,'COMPLETE'))

if __name__ == '__main__':
    unittest.main()
