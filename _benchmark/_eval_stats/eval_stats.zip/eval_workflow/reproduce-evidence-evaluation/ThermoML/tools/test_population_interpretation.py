"""Contextual population counts preserve native output and inspect real references."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from artifact_source import inspect_population_interpretation, inspect_generating_call, sha

class PopulationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.packet=Path(self.temp.name)
        (self.packet/'artifacts').mkdir();(self.packet/'answer.md').write_text('19 mixture points plus 2 pure references = 21 points.',encoding='utf-8')
        self.text='| ethanol | 1.2 |\n| water | 0.8 |\n'
        (self.packet/'artifacts/return.txt').write_text(self.text,encoding='utf-8')
        (self.packet/'artifacts/args.json').write_text('{"doi":"example"}',encoding='utf-8')
        self.files=[]
        for name in ['return.txt','args.json']:
            self.files.append({'path':name,'sha256':sha(self.packet/'artifacts'/name),'numeric_primary_eligible':name=='return.txt','eligibility':{'root':'own_answer/eval/artifacts','owner_answer_id':'fixture','source_path':'fitting_tool_calls_verbatim.md','source_sha256':'a'*64,'source_role':'deterministic_fitting_tool_calls','call_identity':{'tool':'fit_block','step':1,'occurrence':1}}})
        self.manifest={'answer_id':'fixture','artifact_files':self.files};self.save()
        reg=json.loads((Path(__file__).parent.parent/'user-interpretations.json').read_text(encoding='utf-8'))
        reply=next(x['user_reply_exact'] for x in reg['entries'] if x['id']=='H72')
        self.ref={'path':'return.txt','key':'n_points','stored_value':'19','stored_unit':'1','claimed_unit':'1','basis':'mixture rows','fit_session':'fit1','source_context':[{'path':'return.txt'}],'generating_call':{'path':'args.json','tool':'fit_block','fit_session':'fit1','arguments_excerpt':'{"doi":"example"}'}}
        self.spec={'decision_id':'H72','user_reply_exact':reply,'population':'mixtures_plus_pure_references','reason':'Explicit total includes two references','answer_context':['19 mixture points plus 2 pure references = 21 points.'],'pure_references':[]}
        for i,name in enumerate(['ethanol','water'],1):self.spec['pure_references'].append({'component':name,'path':'return.txt','format':'text','line':i,'excerpt':self.text.splitlines()[i-1],'pattern':r'\| '+name+r' \| (?P<value>[0-9.]+) \|'})
    def save(self):(self.packet/'BLIND_INPUT.json').write_text(json.dumps(self.manifest),encoding='utf-8')
    def tearDown(self):self.temp.cleanup()
    def test_explicit_total_preserves_native_count(self):
        result=inspect_population_interpretation(self.packet,self.ref,self.spec)
        self.assertEqual(result['native_mixture_count'],'19');self.assertEqual(result['interpreted_count'],'21');self.assertEqual(result['pure_reference_count'],2);self.assertEqual(self.ref['stored_value'],'19')
    def test_duplicate_and_unsupported_context_rejected(self):
        bad=copy.deepcopy(self.spec);bad['pure_references'].append(bad['pure_references'][0])
        with self.assertRaises(ValueError):inspect_population_interpretation(self.packet,self.ref,bad)
        bad=copy.deepcopy(self.spec);bad['answer_context']=['invented']
        with self.assertRaises(ValueError):inspect_population_interpretation(self.packet,self.ref,bad)
    def test_wrong_quantity_or_decision_rejected(self):
        bad=copy.deepcopy(self.ref);bad['key']='rmse'
        with self.assertRaises(ValueError):inspect_population_interpretation(self.packet,bad,self.spec)
        bad=copy.deepcopy(self.spec);bad['decision_id']='H999'
        with self.assertRaises(ValueError):inspect_population_interpretation(self.packet,self.ref,bad)
    def test_generating_call_identity_mismatch_rejected(self):
        self.assertTrue(inspect_generating_call(self.packet,self.ref)['inspected'])
        self.files[1]['eligibility']['call_identity']['occurrence']=2;self.save()
        with self.assertRaisesRegex(ValueError,'different original calls'):inspect_generating_call(self.packet,self.ref)
    def test_failed_multi_system_has_no_numeric_output(self):
        from native_tool_returns import has_numeric_result
        self.assertFalse(has_numeric_result('**Multi-system RK Fit** — 1 systems\n| bad | — | — | — | ERROR | | |'))
        self.assertTrue(has_numeric_result('**Multi-system RK Fit** — 2 systems\n| bad | — | — | — | ERROR | | |\n| good | DOI | block | a,b | 3 | .99 | .01 | 8 |'))
    def test_shared_range_multiplier_and_tolerance(self):
        from artifact_source import shared_range_scale
        from tokenize_numbers import tokenize
        token=tokenize('water: 1.807–1.841 × 10⁻⁵ m³/mol','fixture')[0]
        result=shared_range_scale(token)
        self.assertEqual(result['value'],'0.00001807');self.assertEqual(result['tolerance'],'5E-9');self.assertEqual(token['parsed_value'],'1.807')
        token=tokenize('difference: 1.807 - 1.841 × 10⁻⁵','fixture')[0]
        self.assertIsNone(shared_range_scale(token))
if __name__=='__main__':unittest.main()
