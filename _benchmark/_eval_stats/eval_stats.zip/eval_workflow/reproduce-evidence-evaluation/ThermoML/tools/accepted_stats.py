"""Independently recount accepted ThermoML canonical packages.

The caller supplies accepted package directories. This module never discovers or
publishes answers, and it does not turn provisional files into accepted results.
"""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path
from filesystem_paths import io_path
from canonical_export import boolean

NUMERIC_SCHEMA = "thermoml-benchmark-eval/3"
NUMERIC_SCHEMAS = {NUMERIC_SCHEMA, "thermoml-benchmark-eval/2"}
SCIENTIFIC_SCHEMA = "thermoml-benchmark-claim-review/1"
OUTCOMES = ("exact", "near_miss", "miss")
GROUPS = ("measurement_condition", "property_value", "stored_uncertainty", "pipeline_artifact")
CATEGORIES = ("database_verified", "domain_knowledge", "incorrect")


class StatsError(ValueError):
    """A package fails the canonical recount contract."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise StatsError(message)


def _json(path: Path) -> dict:
    try:
        value = json.loads(io_path(path).read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise StatsError(f"cannot read canonical JSON {path}: {exc}") from exc
    _require(isinstance(value, dict), f"{path}: expected JSON object")
    return value


def _bytes(path: Path) -> bytes:
    try:
        return io_path(path).read_bytes()
    except OSError as exc:
        raise StatsError(f"cannot read answer bytes {path}: {exc}") from exc


def _sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _lines(value: bytes, label: str) -> list[str]:
    try:
        return value.decode("utf-8-sig").splitlines()
    except UnicodeError as exc:
        raise StatsError(f"{label} is not UTF-8") from exc


def _span(lines: list[str], line: object, column: object, end: object, label: str) -> str:
    _require(all(type(x) is int for x in (line, column, end)), f"{label}: invalid span indices")
    _require(1 <= line <= len(lines) and 1 <= column < end <= len(lines[line - 1]) + 1,
             f"{label}: span outside answer")
    return lines[line - 1][column - 1:end - 1]


def _percentage(count: int, total: int) -> float | None:
    return 100 * count / total if total else None


def _numeric(rows: list[dict]) -> tuple[dict, dict]:
    by_group = {g: {**{o: 0 for o in OUTCOMES}, "total": 0, "misassigned": 0}
                for g in GROUPS}
    outside = Counter()
    dimensions = {k: Counter() for k in ("numeric_outcome", "condition_outcome", "source_outcome")}
    bands = set()
    band_rows = 0
    for row in rows:
        _require(isinstance(row, dict), "numeric value must be an object")
        group = row.get("group")
        outcome = row.get("outcome")
        _require(type(row.get("misassigned")) is bool, "numeric misassigned must be boolean")
        if row.get("band_id"):
            bands.add(row["band_id"])
            band_rows += 1
        if group == "outside":
            _require(outcome == "outside" and not row["misassigned"],
                     "outside numeric value has scored outcome or misassignment")
            outside[row.get("reference_role") or ""] += 1
            continue
        _require(group in by_group and outcome in OUTCOMES,
                 "unresolved or invalid scored numeric value")
        _require(row.get("source_kind") == "thermoml_archive" or
                 (row.get("source_kind") == "hardcoded_artifact" and
                  row.get("classification") == "pipeline_artifact" and group == "pipeline_artifact" and
                  row.get("artifact_inspected") is True),
                 "scored numeric value lacks archive or inspected pipeline artifact evidence")
        bucket = by_group[group]
        bucket[outcome] += 1
        bucket["total"] += 1
        bucket["misassigned"] += int(row["misassigned"])
        for key, counter in dimensions.items():
            counter[row.get(key) or ""] += 1
    totals = {key: sum(bucket[key] for bucket in by_group.values())
              for key in (*OUTCOMES, "total", "misassigned")}
    counts = {
        "lexical_tokens": len(rows), "outside": sum(outside.values()),
        "outside_by_role": dict(sorted(outside.items())), "scored": totals["total"],
        "by_group": by_group, "totals": totals,
        "property_rollup": {k: by_group["property_value"][k] + by_group["pipeline_artifact"][k] for k in by_group["property_value"]},
        "dimensions": {key: dict(sorted(counter.items()))
                       for key, counter in dimensions.items()},
        "peak_bands": {"bands": len(bands), "rows": band_rows},
    }
    percentages = {
        group: {outcome: _percentage(bucket[outcome], bucket["total"])
                for outcome in OUTCOMES}
        for group, bucket in {**by_group, "all_groups": totals}.items()
    }
    return counts, percentages


def _factual(rows: list[dict]) -> tuple[dict, dict]:
    verdicts = Counter()
    types = Counter()
    misassigned = 0
    for row in rows:
        _require(isinstance(row, dict), "factual claim must be an object")
        verdict = row.get("final_verdict")
        _require(verdict in (*OUTCOMES, "outside"), "unresolved factual claim verdict")
        _require(type(row.get("misassigned", False)) is bool,
                 "factual misassigned must be boolean")
        verdicts[verdict] += 1
        types[row.get("final_type") or row.get("type") or ""] += 1
        misassigned += int(row.get("misassigned", False))
    counts = {
        "total": len(rows), "scored": sum(verdicts[x] for x in OUTCOMES),
        "by_verdict": {x: verdicts[x] for x in (*OUTCOMES, "outside")},
        "by_type": dict(sorted(types.items())), "misassigned": misassigned,
    }
    percentages = {x: _percentage(verdicts[x], counts["scored"]) for x in OUTCOMES}
    return counts, percentages


def _coverage(coverage: dict) -> dict:
    _require(isinstance(coverage, dict), "coverage must be an object")
    keys = ("relevant_items", "present_items", "omitted_items", "diagnostic_alternative_sources")
    for key in keys[:3]:
        _require(isinstance(coverage.get(key), list), f"coverage {key} must be a list")
    diagnostics = coverage.get(keys[3], [])
    _require(isinstance(diagnostics, list), "coverage alternatives must be a list")
    return {"relevant": len(coverage[keys[0]]), "present": len(coverage[keys[1]]),
            "omitted": len(coverage[keys[2]]), "diagnostic_alternatives": len(diagnostics)}


def _original_path(package: Path, answer: dict, benchmark_root: Path | None) -> Path:
    _require(answer.get("result_file") == "../result.md", "canonical original result path invalid")
    if benchmark_root is None:
        _require(package.name == "eval", "benchmark_root required for staged packages")
        return package.parent / "result.md"
    root = io_path(benchmark_root).resolve(strict=True)
    folder = answer.get("folder")
    _require(isinstance(folder, str) and bool(folder), "answer folder missing")
    relative = Path(folder)
    _require(not relative.is_absolute() and ".." not in relative.parts and "." not in relative.parts,
             "answer folder must be relative to benchmark root")
    path = (root / relative / "result.md").resolve(strict=True)
    _require(path.is_relative_to(root), "original result escapes benchmark root")
    return path


def validate_package(package: Path, scientific_enabled: bool,
                     benchmark_root: Path | None = None) -> dict:
    """Validate and recount one accepted package; return per-answer statistics."""
    _require(type(scientific_enabled) is bool, "scientific_enabled must be boolean")
    package = io_path(package).resolve(strict=True)
    _require(package.is_dir(), "package must be a directory")
    _require(not (package / "draft_evaluation.json").exists()
             and not (package / "PROVISIONAL_MANIFEST.json").exists(),
             "provisional or draft package is not accepted")
    doc = _json(package / "evaluation.json")
    _require(doc.get("schema") in NUMERIC_SCHEMAS, "canonical numeric schema required")
    answer = doc.get("answer")
    _require(isinstance(answer, dict), "canonical answer identity missing")
    _require(answer.get("evaluated_answer_file") == "evaluated_answer.md",
             "canonical evaluated answer filename invalid")
    evaluated = _bytes(package / "evaluated_answer.md")
    original = _bytes(_original_path(package, answer, benchmark_root))
    _require(answer.get("evaluated_answer_sha256") == _sha(evaluated),
             "evaluated answer SHA mismatch")
    _require(answer.get("result_sha256") == _sha(original),
             "original result SHA mismatch")
    evaluated_lines = _lines(evaluated, "evaluated answer")
    original_lines = _lines(original, "original result")

    excerpts = doc.get("excerpts")
    _require(isinstance(excerpts, list), "canonical excerpts must be a list")
    rows = []
    ids = set()
    for excerpt in excerpts:
        _require(isinstance(excerpt, dict) and isinstance(excerpt.get("values"), list),
                 "invalid numeric excerpt")
        line = excerpt.get("line")
        context = excerpt.get("excerpt")
        _require(type(line) is int and 1 <= line <= len(evaluated_lines)
                 and context == evaluated_lines[line - 1], "evaluated excerpt line mismatch")
        for row in excerpt["values"]:
            _require(isinstance(row, dict), "numeric value must be an object")
            token_id = row.get("token_id")
            _require(isinstance(token_id, str) and token_id and token_id not in ids,
                     "duplicate or missing numeric token ID")
            ids.add(token_id)
            span = _span(evaluated_lines, line, row.get("column"), row.get("end_column"),
                         token_id)
            _require(span == row.get("text"), f"{token_id}: evaluated answer span mismatch")
            if row.get("group") != "outside":
                original_span = _span(original_lines, line, row.get("column"),
                                      row.get("end_column"), token_id)
                _require(original_span == row["text"], f"{token_id}: original result span mismatch")
            if row.get('group')=='pipeline_artifact':
                ref=row.get('artifact_reference')
                if row.get('reason_code')!='evidence_gap':
                    _require(isinstance(ref,dict), f'{token_id}: eligible artifact reference missing')
                    relative=Path(ref.get('path',''))
                    artifact_root=(package/'artifacts').resolve()
                    artifact=(artifact_root/relative).resolve()
                    _require(bool(ref.get('path')) and not relative.is_absolute() and '..' not in relative.parts and artifact.is_relative_to(artifact_root), f'{token_id}: artifact must belong to this eval/artifacts')
                    _require(artifact.is_file() and _sha(_bytes(artifact))==ref.get('sha256'), f'{token_id}: published artifact hash/bytes missing or changed')
                    _require(relative.suffix.lower()!='.md' or relative.name=='fitting_tool_calls_verbatim.md', f'{token_id}: general history cannot be a numerical source')
                    _require('completed_fits' not in relative.as_posix().lower(), f'{token_id}: Completed Fits is context only')
                    call=ref.get('generating_call',{})
                    call_relative=Path(call.get('path',''))
                    call_path=(artifact_root/call_relative).resolve()
                    _require(call_relative.name=='fitting_tool_calls_verbatim.md' and call_path.is_relative_to(artifact_root) and call_path.is_file(), f'{token_id}: generating call must resolve in own dedicated fitting-call artifact')
                    _require(_sha(_bytes(call_path))==call.get('sha256') and bool(call.get('arguments_excerpt')) and call['arguments_excerpt'].replace('\r\n','\n') in _bytes(call_path).decode('utf-8-sig').replace('\r\n','\n'), f'{token_id}: generating argument hash/excerpt mismatch')
            rows.append(row)
    _require(answer.get("token_count") == len(rows), "answer token count mismatch")
    if doc.get("schema") == "thermoml-benchmark-eval/2":
        rows = [{**row, "misassigned": boolean(row.get("misassigned", False))} for row in rows]
    counts, numeric_pct = _numeric(rows)
    factual_rows = doc.get("factual_claims")
    _require(isinstance(factual_rows, list), "factual claims must be a list")
    factual_counts, factual_pct = _factual(factual_rows)
    coverage = _coverage(doc.get("coverage"))
    recorded = doc.get("counts")
    if doc.get("schema") == "thermoml-benchmark-eval/2" and isinstance(recorded, dict):
        recorded = json.loads(json.dumps(recorded))
        legacy_numeric = recorded.get("numeric", {})
        legacy_numeric.setdefault("by_group", {}).setdefault("pipeline_artifact", {**{o: 0 for o in OUTCOMES}, "total": 0, "misassigned": 0})
        legacy_numeric.setdefault("property_rollup", dict(legacy_numeric["by_group"].get("property_value", {})))
    _require(isinstance(recorded, dict), "canonical count object missing")
    expected = {"numeric": counts, "factual_claims": factual_counts,
                "coverage": coverage, "excerpts": len(excerpts), "grouped_display_rows": 0}
    _require(recorded == expected, "canonical numeric, factual, or coverage count mismatch")
    identity = answer.get("answer_id")
    _require(isinstance(identity, str) and identity, "canonical answer ID missing")
    science = None
    if scientific_enabled:
        science_doc = _json(package / "claim_review.json")
        _require(science_doc.get("schema") == SCIENTIFIC_SCHEMA,
                 "canonical scientific schema required")
        science_answer = science_doc.get("answer")
        _require(isinstance(science_answer, dict)
                 and science_answer.get("answer_id") == identity
                 and science_answer.get("result_file") == "../result.md"
                 and science_answer.get("result_sha256") == _sha(original),
                 "scientific original result identity or SHA mismatch")
        claims = science_doc.get("claims")
        _require(isinstance(claims, list), "scientific claims must be a list")
        categories = Counter()
        resolved = unresolved = 0
        for claim in claims:
            _require(isinstance(claim, dict), "scientific claim must be an object")
            label = claim.get("claim_id", "scientific claim")
            span = _span(original_lines, claim.get("line"), claim.get("column"),
                         claim.get("end_column"), str(label))
            _require(span == claim.get("text"), f"{label}: scientific original span mismatch")
            if claim.get("status") == "resolved":
                _require(claim.get("category") in CATEGORIES, "invalid scientific category")
                categories[claim["category"]] += 1
                resolved += 1
            elif claim.get("status") == "unresolved":
                _require(claim.get("category") is None,
                         "unresolved scientific claim has a category")
                unresolved += 1
            else:
                raise StatsError("invalid scientific claim status")
        science_counts = {"resolved": resolved, "unresolved": unresolved,
                          "by_category": dict(categories)}
        _require(science_doc.get("counts") == science_counts,
                 "scientific category count mismatch")
        science = {
            "counts": science_counts,
            "percentages": {cat: _percentage(categories[cat], resolved)
                            for cat in CATEGORIES},
        }
    else:
        _require(not (package / "claim_review.json").exists(),
                 "scientific claim review present while layer is disabled")
    return {
        "answer_id": identity, "blind_id": answer.get("blind_id"),
        "level": answer.get("level"), "arm": answer.get("arm"),
        "question": answer.get("question"), "folder": answer.get("folder"),
        "numeric": {"counts": counts, "percentages": numeric_pct},
        "factual": {"counts": factual_counts, "percentages": factual_pct},
        "coverage": coverage,
        "scientific": science,
    }


def _source_counts(doc):
    sources = {}
    for excerpt in doc.get("excerpts", []):
        for row in excerpt.get("values", []):
            if row.get("group") == "outside":
                continue
            source=row.get("source_kind", "thermoml_archive")
            bucket=sources.setdefault(source, {g:{**{o:0 for o in OUTCOMES},"total":0,"misassigned":0} for g in GROUPS})[row["group"]]
            bucket[row["outcome"]]+=1;bucket["total"]+=1;bucket["misassigned"]+=int(boolean(row.get("misassigned",False)))
    return sources

def read_answer(root: Path, folder: Path) -> dict:
    """Compatibility entry point for one published answer folder."""
    root = io_path(root).resolve(strict=True)
    folder = io_path(folder).resolve(strict=True)
    _require(folder.is_relative_to(root), "answer folder outside benchmark root")
    result = validate_package(folder / "eval", (folder / "eval" / "claim_review.json").exists(),
                              benchmark_root=root)
    _require(result["folder"] == folder.relative_to(root).as_posix(),
             "canonical answer folder identity mismatch")
    return {
        "agent": result["level"], "arm": result["arm"],
        "question": result["question"], "answer_folder": result["folder"],
        "counts": result["numeric"]["counts"]["by_group"],
        "counts_by_source_kind": _source_counts(_json(folder / "eval" / "evaluation.json")),
        **result,
    }


def summarize(packages: list[Path], scientific_enabled: bool,
              benchmark_root: Path | None = None) -> dict:
    """Recount only explicitly supplied accepted packages; never scan a corpus."""
    _require(isinstance(packages, list), "accepted packages must be an explicit list")
    answers = [validate_package(path, scientific_enabled, benchmark_root) for path in packages]
    ids = [answer["answer_id"] for answer in answers]
    _require(len(ids) == len(set(ids)), "duplicate accepted answer ID")
    numeric_groups = {g: {**{o: 0 for o in OUTCOMES}, "total": 0, "misassigned": 0}
                      for g in GROUPS}
    factual_verdicts = {o: 0 for o in (*OUTCOMES, "outside")}
    factual_types = Counter()
    factual_total = factual_scored = factual_misassigned = 0
    coverage = {"relevant": 0, "present": 0, "omitted": 0, "diagnostic_alternatives": 0}
    science_categories = Counter()
    science_resolved = science_unresolved = 0
    for answer in answers:
        for group in GROUPS:
            for key in (*OUTCOMES, "total", "misassigned"):
                numeric_groups[group][key] += answer["numeric"]["counts"]["by_group"][group][key]
        factual = answer["factual"]["counts"]
        factual_total += factual["total"]
        factual_scored += factual["scored"]
        factual_misassigned += factual["misassigned"]
        for verdict in factual_verdicts:
            factual_verdicts[verdict] += factual["by_verdict"][verdict]
        factual_types.update(factual["by_type"])
        for key in coverage:
            coverage[key] += answer["coverage"][key]
        if scientific_enabled:
            scientific = answer["scientific"]["counts"]
            science_resolved += scientific["resolved"]
            science_unresolved += scientific["unresolved"]
            science_categories.update(scientific["by_category"])
    numeric_totals = {key: sum(group[key] for group in numeric_groups.values())
                      for key in (*OUTCOMES, "total", "misassigned")}
    numeric_pct = {group: {o: _percentage(counts[o], counts["total"]) for o in OUTCOMES}
                   for group, counts in {**numeric_groups, "all_groups": numeric_totals}.items()}
    factual_counts = {"total": factual_total, "scored": factual_scored,
                      "by_verdict": factual_verdicts,
                      "by_type": dict(sorted(factual_types.items())),
                      "misassigned": factual_misassigned}
    science = None
    if scientific_enabled:
        science = {
            "counts": {"resolved": science_resolved, "unresolved": science_unresolved,
                       "by_category": dict(science_categories)},
            "percentages": {cat: _percentage(science_categories[cat], science_resolved)
                            for cat in CATEGORIES},
        }
    return {
        "answers": answers,
        "aggregate": {
            "answer_count": len(answers),
            "numeric": {"counts": {"by_group": numeric_groups, "totals": numeric_totals, "property_rollup": {k: numeric_groups["property_value"][k] + numeric_groups["pipeline_artifact"][k] for k in numeric_totals}},
                        "percentages": numeric_pct},
            "factual": {"counts": factual_counts,
                        "percentages": {o: _percentage(factual_verdicts[o], factual_scored)
                                        for o in OUTCOMES}},
            "coverage": coverage, "scientific": science,
        },
    }
