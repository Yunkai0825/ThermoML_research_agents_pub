"""Decimal-only comparison rules. Input values must come from source-token/archive readers."""
from decimal import Decimal
D=Decimal
# Stored-unit -> answer-unit affine transformations are exact Decimal factors.
UNITS={
 'K':('temperature',D(1),D(0)), 'degC':('temperature',D(1),D('273.15')),
 'Pa':('pressure',D(1),D(0)), 'kPa':('pressure',D(1000),D(0)),
 'MPa':('pressure',D(1000000),D(0)), 'bar':('pressure',D(100000),D(0)),
 'atm':('pressure',D(101325),D(0)),
 'kg/m3':('density',D(1),D(0)), 'g/cm3':('density',D(1000),D(0)),
 'Pa*s':('viscosity',D(1),D(0)), 'mPa*s':('viscosity',D('.001'),D(0)),
 'cP':('viscosity',D('.001'),D(0)),
 'fraction':('fraction',D(1),D(0)), '%':('fraction',D('.01'),D(0)),
 'mol/kg':('molality',D(1),D(0)),
 'mol/m3':('molarity',D(1),D(0)), 'mol/dm3':('molarity',D(1000),D(0)),
 'mol/L':('molarity',D(1000),D(0)),
 'm3/mol':('molar_volume',D(1),D(0)), 'cm3/mol':('molar_volume',D('.000001'),D(0)),
 'J/mol':('molar_energy',D(1),D(0)), 'kJ/mol':('molar_energy',D(1000),D(0)),
 'J/(mol*K)':('molar_heat_capacity',D(1),D(0)),
 'm/s':('speed',D(1),D(0)), '1':('dimensionless',D(1),D(0)),
 'm2/s':('diffusivity',D(1),D(0)), 'cm2/s':('diffusivity',D('0.0001'),D(0)),
 'mm2/s':('diffusivity',D('0.000001'),D(0)),
 'N/m':('surface_tension',D(1),D(0)), 'mN/m':('surface_tension',D('0.001'),D(0)),
 'Hz':('frequency',D(1),D(0)), 'kHz':('frequency',D(1000),D(0)),
 'MHz':('frequency',D(1000000),D(0)),
}
def convert(value,stored_unit,answer_unit,uncertainty=False):
    value=D(str(value))
    if stored_unit==answer_unit:return value
    a=UNITS.get(stored_unit); b=UNITS.get(answer_unit)
    if a is None or b is None or a[0]!=b[0]:
        raise ValueError(f'No defined exact conversion: {stored_unit} -> {answer_unit}')
    # Offset temperatures do not offset uncertainty magnitudes.
    return (value*a[1]+(D(0) if uncertainty else a[2]-b[2]))/b[1]
def compare(answer,stored,tolerance):
    a,s,t=map(lambda x:D(str(x)),(answer,stored,tolerance))
    diff=abs(a-s)
    relative=None if not s else diff/abs(s)
    flags=['stored_zero'] if not s else []
    if diff<=t:category='exact'
    elif not s:
        category='miss'
    elif relative<D('.01'):category='near_miss'
    else:category='miss'
    return {'absolute_difference':str(diff),'relative_difference':None if relative is None else str(relative),'tolerance_used':str(t),'category':category,'flags':flags}
def self_check():
    assert compare('997.05','997.047','.005')['category']=='exact'
    assert compare('25',convert('298.15','K','degC'),'.5')['category']=='exact'
    assert compare('100.999','100','.0005')['category']=='near_miss'
    assert compare('101.000','100','.0005')['category']=='miss'
    assert compare('1.20e-3','1.205e-3','.000005')['category']=='exact'
    assert compare('0','0','.5')['category']=='exact'
    assert compare('.001','0','.0005')['category']=='miss'
    assert convert('1','atm','kPa')==D('101.325')
    assert convert('1','mPa*s','Pa*s')==D('.001')
    assert convert('.5','fraction','%')==D(50)
    assert convert('.1','K','degC',uncertainty=True)==D('.1')
    assert convert('1.25','mol/kg','mol/kg')==D('1.25')
    assert convert('1.25','mol/dm3','mol/L')==D('1.25')
    assert convert('1.25','mol/dm3','mol/m3')==D('1250')
    try: convert('1.25','mol/kg','fraction')
    except ValueError: pass
    else: raise AssertionError('Molality must not convert to mole fraction')
    print('15 comparison/conversion checks passed; no answer values have been classified.')
if __name__=='__main__':self_check()