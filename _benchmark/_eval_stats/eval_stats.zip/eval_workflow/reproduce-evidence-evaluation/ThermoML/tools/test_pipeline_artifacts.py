"""Behavioral regression tests for fixed pipeline evidence and property rollup."""
import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from artifact_source import resolve_artifact, inventory_errors, exclusion_errors, sha
from tokenize_numbers import tokenize
from canonical_export import _numeric_rows, _counts
from accepted_stats import _numeric
from review_contract import initial_check

HERE=Path(__file__).parent
FIXTURES=HERE/'examples/pipeline_artifacts'

def write(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

class PipelineArtifactTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.packet=Path(self.temp.name)/'fixture';self.packet.mkdir()
        (self.packet/'artifacts').mkdir()
        files=[]
        for path in FIXTURES.iterdir():
            if path.suffix in {'.csv','.txt','.json'}:
                dst=self.packet/'artifacts'/path.name;shutil.copyfile(path,dst)
                is_call=path.name.endswith(('_tool_return.txt','_arguments.json'))
                primary=path.suffix=='.csv' or path.name.endswith('_tool_return.txt')
                files.append({'path':path.name,'sha256':sha(dst),'numeric_primary_eligible':primary,
                    'use':'pipeline_artifact_and_source_evidence' if primary else 'context_only',
                    'eligibility':{'root':'own_answer/eval/artifacts','owner_answer_id':'fixture',
                    'source_path':'fitting_tool_calls_verbatim.md' if is_call else 'run_history_verbatim.md' if path.suffix=='.txt' else path.name,
                    'source_role':'deterministic_fitting_tool_calls' if is_call else 'context_only' if path.suffix=='.txt' else 'fixed_saved_data_or_plot',
                    'source_sha256':sha(dst),'transform':'fixture extraction of saved deterministic source; metadata is context only'}})
        write(self.packet/'BLIND_INPUT.json',{'answer_id':'fixture','artifact_files':files,'require_eval_artifact_origin':True})
        self.files=files
    def tearDown(self):
        from filesystem_paths import io_path
        temporary=io_path(self.temp.name).resolve()
        assert self.packet.resolve().is_relative_to(Path(self.temp.name).resolve())
        shutil.rmtree(temporary)
        self.temp.cleanup()
    def source(self,which,row,key,unit='1',claimed_unit=None,basis='excess ln viscosity',claimed_basis=None):
        metadata=(self.packet/'artifacts'/(which+'_fixed_metadata.txt')).read_text(encoding='utf-8')
        summary=(self.packet/'artifacts'/(which+'_fit_summ.csv')).read_text(encoding='utf-8-sig')
        return {'path':which+'_fit_summ.csv','format':'csv','row':row,'field':'value','key':key,
                'stored_unit':unit,'claimed_unit':claimed_unit or unit,'basis':basis,'claimed_basis':claimed_basis or basis,
                'fit_session':which+'_native_session','source_inputs':[summary.split('doi,')[1].splitlines()[0]],
                'state':'stored source state; see named fit artifact and native inputs',
                'generating_call':{'path':which+'_arguments.json','tool':'fit_block','fit_session':which+'_native_session','arguments_excerpt':(self.packet/'artifacts'/(which+'_arguments.json')).read_text(encoding='utf-8')},
                'source_context':[{'path':which+'_fixed_metadata.txt','excerpt':metadata,
                                   'supports':['stored_unit','basis','fit_session','source_inputs','state']}]}
    def check(self,token,reference=None,integer=False):
        d={'token_id':token['token_id'],'role':'value','quantity':{'kind':'property'},
           'classification':'pipeline_artifact','source_kind':'hardcoded_artifact',
           'property':'fixed '+(reference['key'] if reference else 'unreported optional diagnostic'),'unit':reference['claimed_unit'] if reference else '1'}
        if reference:d['artifact_reference']=reference
        else:d['artifact_search']={'complete':True,'reason':'Optional diagnostic is not stored in the fully inspected synthetic evidence pool; NA',
                                  'search_boundary':'all hashed native fixture files','inspected_files':[x['path'] for x in self.files]}
        if integer:d['integer_output']=True
        return d
    def prepare(self,text,checks):
        (self.packet/'answer.md').write_text(text,encoding='utf-8')
        tokens=tokenize(text,'fixture');write(self.packet/'tokens.json',tokens)
        ids={x['token_id'] for x in checks}
        mapping={'answer_id':'fixture','checks':checks,'exclusions':[{'tokens':[t['token_id']],'reason':'label','detail':'unit exponent or equation index'} for t in tokens if t['token_id'] not in ids],
                 'pipeline_inventory':{'complete':True,'answer_sha256':sha(self.packet/'answer.md'),
                                       'occurrences':[{'token_id':x['token_id'],'classification':'pipeline_artifact','reason':x['property']} for x in checks]}}
        write(self.packet/'mapping.json',mapping)
        resolved=[];checkmap={x['token_id']:x for x in checks}
        for token in tokens:
            resolved.append(resolve_artifact(self.packet,token,checkmap[token['token_id']]) if token['token_id'] in ids else {**token,'category':'excluded'})
        write(self.packet/'resolved.json',{'answer_id':'fixture','rows':resolved})
        return tokens,mapping,resolved
    def test_long_artifact_paths_keep_relative_eligibility(self):
        from filesystem_paths import io_path
        from artifact_source import artifact_bytes
        relative='/'.join(['long_session_'+('x'*45)]*4)+'/value.csv'
        destination=io_path(self.packet/'artifacts'/relative)
        destination.parent.mkdir(parents=True)
        destination.write_bytes(b'value\n0.982166\n')
        entry={'path':relative,'sha256':sha(destination),'eligibility':{
            'root':'own_answer/eval/artifacts','owner_answer_id':'fixture',
            'source_path':relative,'source_sha256':sha(destination)}}
        manifest=json.loads((self.packet/'BLIND_INPUT.json').read_text())
        manifest['artifact_files'].append(entry);write(self.packet/'BLIND_INPUT.json',manifest)
        actual=artifact_bytes(self.packet,relative)
        self.assertIn(b'0.982166',actual[0] if isinstance(actual,tuple) else actual)
        self.assertFalse(Path(entry['eligibility']['source_path']).is_absolute())

    def test_hyphenated_order_keeps_literal_span_and_true_negative_sign(self):
        for text,want in [('order-2 polynomial','exact'),('order -2 polynomial','miss'),('coefficient -2','miss')]:
            token=tokenize(text,'fixture')[0];ref=self.source('main',1,'rk_order')
            check=self.check(token,ref,integer=True)
            got=resolve_artifact(self.packet,token,check)
            self.assertEqual(got['category'],want)
            self.assertEqual(got['text'],'-2')
            self.assertEqual(got['parsed_value'],'-2')
            self.assertEqual(text[token['column']-1:token['end_column']-1],'-2')
            self.assertEqual(bool(got['lexical_sign_interpretation']),want=='exact')

    def test_equation_subtraction_coefficient_preserves_lexical_token(self):
        text='y = 1 - 0.0218724 x';token=tokenize(text,'fixture')[1]
        check=self.check(token,self.source('main',7,'A2'))
        check['property']='RK coefficient A2'
        check['equation_sign_interpretation']={'operation':'preceding_subtraction','reason':'Explicit negative polynomial term.'}
        got=resolve_artifact(self.packet,token,check)
        self.assertEqual(got['category'],'exact')
        self.assertEqual(got['parsed_value'],'0.0218724')
        self.assertEqual(got['comparison_value'],'-0.0218724')
        self.assertTrue(got['lexical_sign_interpretation'])
        for badtext in ['y = 1 + 0.0218724 x','value 1 - 0.0218724 x']:
            bad=tokenize(badtext,'fixture')[1]
            with self.assertRaises(ValueError):resolve_artifact(self.packet,bad,check)
        check['property']='RMSE'
        with self.assertRaises(ValueError):resolve_artifact(self.packet,token,check)

    def test_main_actual_summary_numbers_and_units(self):
        cases=[('0.982166',2,'r_squared','1','1','exact'),
               ('0.0396991',5,'A0','1','1','exact'),('0.0275633',6,'A1','1','1','exact'),
               ('−0.0218724',7,'A2','1','1','exact'),
               ('0.000473597',3,'rmse','1','1','exact'),
               ('0.000473597',3,'rmse','1','Pa*s','miss')]
        for display,row,key,unit,claim,want in cases:
            with self.subTest(key=key,claim=claim):
                t=tokenize(display,'fixture')[0];ref=self.source('main',row,key,unit,claim)
                got=resolve_artifact(self.packet,t,self.check(t,ref))
                self.assertEqual(got['category'],want)
                self.assertTrue(got['artifact_inspected'])
                self.assertEqual(got['classification'],'pipeline_artifact')
        # Completed Fits is context only, even when its number has greater precision.
        text=(self.packet/'artifacts/main_fixed_metadata.txt').read_text(encoding='utf-8')
        line=next((i,x) for i,x in enumerate(text.splitlines(),1) if 'RMSE=' in x)
        t=tokenize('0.000473597','fixture')[0];ref=self.source('main',3,'rmse')
        ref.update(path='main_fixed_metadata.txt',format='text',line=line[0],excerpt=line[1],pattern=r'RMSE=(?P<value>[0-9.eE+-]+)')
        with self.assertRaisesRegex(ValueError,'context/provenance only'):
            resolve_artifact(self.packet,t,self.check(t,ref))
    def test_real_fixed_tool_rmse_is_primary_but_not_invented_precision(self):
        source=(self.packet/'artifacts/main_tool_return.txt').read_text(encoding='utf-8')
        line=next((i,x) for i,x in enumerate(source.splitlines(),1) if 'RMSE' in x and 'BIC-selected' in x)
        for claimed_unit,want in [('1','exact'),('Pa*s','miss')]:
            t=tokenize('0.000473597','fixture')[0]
            ref=self.source('main',3,'rmse',claimed_unit=claimed_unit)
            ref.update(path='main_tool_return.txt',format='text',line=line[0],excerpt=line[1],pattern=r'RMSE = (?P<value>[+0-9.eE-]+)')
            got=resolve_artifact(self.packet,t,self.check(t,ref))
            self.assertEqual(got['category'],want)
            self.assertEqual(got['stored_value'],'0.000473597')
        t=tokenize('0.00047359700150033146','fixture')[0]
        ref['claimed_unit']='1'
        self.assertEqual(resolve_artifact(self.packet,t,self.check(t,ref))['category'],'exact')

    def test_history_cannot_be_promoted_and_generating_arguments_required(self):
        manifest=json.loads((self.packet/'BLIND_INPUT.json').read_text())
        entry=next(e for e in manifest['artifact_files'] if e['path']=='main_fixed_metadata.txt')
        entry['numeric_primary_eligible']=True
        write(self.packet/'BLIND_INPUT.json',manifest)
        from artifact_source import primary_source_entry
        with self.assertRaisesRegex(ValueError,'general history|Completed Fits'):
            primary_source_entry(self.packet,entry['path'])
        t=tokenize('0.982166','fixture')[0];ref=self.source('main',2,'r_squared')
        ref.pop('generating_call')
        with self.assertRaisesRegex(ValueError,'generating tool arguments'):
            resolve_artifact(self.packet,t,self.check(t,ref))
        ref=self.source('main',2,'r_squared');ref['generating_call']['arguments_excerpt']='invented arguments'
        with self.assertRaisesRegex(ValueError,'argument excerpt'):
            resolve_artifact(self.packet,t,self.check(t,ref))

    def test_density_real_metrics_and_bic_gap(self):
        for display,row,key in [('0.999796',2,'r_squared'),('0.0388524',3,'rmse')]:
            t=tokenize(display,'fixture')[0]
            unit='kg/m3' if key=='rmse' else '1'
            got=resolve_artifact(self.packet,t,self.check(t,self.source('density',row,key,unit,basis='excess density')))
            self.assertEqual(got['category'],'exact')
        for label,display in [('density','−57.07'),('main','−176.27')]:
            t=tokenize(display,'fixture')[0]
            text=(self.packet/'artifacts'/(label+'_tool_return.txt')).read_text(encoding='utf-8')
            line=next((i,x) for i,x in enumerate(text.splitlines(),1) if 'BIC-selected order:' in x)
            ref=self.source(label,2,'bic',basis='selected fit BIC')
            ref.update(path=label+'_tool_return.txt',format='text',line=line[0],excerpt=line[1],pattern=r'BIC = (?P<value>[+0-9.eE-]+)')
            got=resolve_artifact(self.packet,t,self.check(t,ref))
            self.assertEqual(got['category'],'exact')
            self.assertEqual(got['stored_value'],display.replace('−','-'))
        t=tokenize('123.456','fixture')[0];got=resolve_artifact(self.packet,t,self.check(t))
        self.assertEqual((got['category'],got['reason_code'],got['stored_value']),('miss','evidence_gap',None))
    def test_f020_old_exclusion_is_failure_but_exponents_not_values(self):
        text='R² = 0.999796; RMSE = 0.0388524 kg/m³; BIC = −57.07'
        tokens=tokenize(text,'fixture');write(self.packet/'tokens.json',tokens)
        actual=[t for t in tokens if t['lexical_kind']=='number']
        labels=[t for t in tokens if t['lexical_kind']!='number']
        self.assertEqual(len(actual),3);self.assertEqual(len(labels),2)
        bad={'checks':[],'exclusions':[{'tokens':[x['token_id'] for x in actual],'reason':'derived','detail':'fitted/model-selection outputs; not recomputed'}]}
        claim={'claim_id':'F020_regression','type':'derived','quote':text,'token_ids':[t['token_id'] for t in tokens],
               'verdict':'outside','reason':'R2, RMSE and BIC are fitted/model-selection outputs; not recomputed.'}
        self.assertTrue(exclusion_errors(self.packet,bad,[claim]))
        ordinary={'checks':[],'exclusions':[{'tokens':[x['token_id'] for x in actual],'reason':'derived','detail':'Agent-calculated illustrative coefficients; no assertion of a fixed saved output in eligible eval/artifacts.'}]}
        self.assertEqual(exclusion_errors(self.packet,ordinary,[]),[])
        good={'checks':[],'exclusions':[{'tokens':[t['token_id'] for t in labels],'reason':'label','detail':'R squared label and unit exponent'}]}
        self.assertEqual(exclusion_errors(self.packet,good,[]),[])
    def test_rollup_canonical_and_independent_recount_with_repeats(self):
        text='R² = 0.982166; repeat R² = 0.982166; unavailable optional diagnostic = 123.456'
        ts=tokenize(text,'fixture');numeric=[t for t in ts if t['lexical_kind']=='number']
        checks=[self.check(t,self.source('main',2,'r_squared')) for t in numeric[:2]]+[self.check(numeric[2])]
        tokens,mapping,rows=self.prepare(text,checks)
        self.assertEqual(inventory_errors(self.packet,mapping,rows),[])
        decisions=[]
        for row in rows:
            if row.get('classification')!='pipeline_artifact':continue
            decisions.append({'token_id':row['token_id'],'group':'pipeline_artifact','classification':'pipeline_artifact',
                              'source_kind':'hardcoded_artifact','artifact_inspected':True,'outcome':row['category'],
                              'numeric_outcome':row['numeric_outcome'],'source_outcome':'miss' if row.get('reason_code') else 'exact',
                              'condition_outcome':'not_applicable','misassigned':False,'reason':row['reason'],
                              'reason_code':row.get('reason_code'),'evidence':['inspected artifact']})
        self.assertEqual(inventory_errors(self.packet,mapping,decisions,final=True),[])
        canonical=_numeric_rows(self.packet,{'numeric_results':decisions})
        counted=_counts(canonical);independent,_=_numeric(canonical)
        self.assertEqual(counted,independent)
        self.assertEqual(counted['by_group']['pipeline_artifact']['total'],3)
        self.assertEqual(counted['by_group']['pipeline_artifact']['exact'],2)
        self.assertEqual(counted['by_group']['pipeline_artifact']['miss'],1)
        self.assertEqual(counted['outside'],2)
        self.assertEqual(counted['by_group']['property_value']['total'],0)
        self.assertEqual(counted['property_rollup']['total'],3)
        self.assertTrue(all(r['category']=='pipeline_artifact' for r in canonical if r['group']=='pipeline_artifact'))
        bad=copy.deepcopy(decisions);bad[0].update(group='outside',outcome='outside',classification='derived')
        self.assertTrue(inventory_errors(self.packet,mapping,bad,final=True))
        bad=copy.deepcopy(rows);next(r for r in bad if r.get('classification')=='pipeline_artifact')['stored_value']='999'
        self.assertTrue(inventory_errors(self.packet,mapping,bad))
        badmap=copy.deepcopy(mapping);badmap['pipeline_inventory']['occurrences'].pop()
        self.assertTrue(inventory_errors(self.packet,badmap,rows))
    def test_missing_inspection_hash_basis_and_integer_failures(self):
        t=tokenize('2','fixture')[0];ref=self.source('main',1,'rk_order')
        check=self.check(t,ref,integer=True)
        self.assertEqual(resolve_artifact(self.packet,t,check)['category'],'exact')
        t3=tokenize('3','fixture')[0]
        self.assertEqual(resolve_artifact(self.packet,t3,check)['category'],'miss')
        ref['claimed_basis']='raw viscosity'
        self.assertEqual(resolve_artifact(self.packet,t,self.check(t,ref))['category'],'miss')
        missing=self.check(t);missing['artifact_search']['inspected_files']=[]
        with self.assertRaises(ValueError):resolve_artifact(self.packet,t,missing)
        (self.packet/'artifacts/main_fit_summ.csv').write_text('changed',encoding='utf-8')
        with self.assertRaises(ValueError):resolve_artifact(self.packet,t,check)
    def test_no_inventory_rejected(self):
        (self.packet/'answer.md').write_text('0.982166',encoding='utf-8')
        self.assertTrue(inventory_errors(self.packet,{},[]))

    def test_correction_preserves_valid_existing_rows_and_rejects_relabel_only(self):
        from correct_artifacts import correct
        from canonical_export import _excerpts, _claim_counts
        text='Measured density 998.2; R² = 0.982166; repeat R² = 0.982166'
        tokens=tokenize(text,'fixture');outputs=[x for x in tokens if x['text']=='0.982166']
        checks=[self.check(x,self.source('main',2,'r_squared')) for x in outputs]
        _,mapping,resolved=self.prepare(text,checks)
        oldrows=[]
        for token in tokens:
            measured=token['text']=='998.2'
            oldrows.append({**token,'context_excerpt':token['line_text'],'group':'property_value' if measured else 'outside',
                            'outcome':'exact' if measured else 'outside','numeric_outcome':'exact' if measured else 'outside',
                            'source_outcome':'exact' if measured else 'outside','condition_outcome':'exact' if measured else 'outside',
                            'source_kind':'thermoml_archive' if measured else None,'misassigned':False,
                            'reason':'valid inspected archive input' if measured else 'old fit exclusion' if token in outputs else 'unit exponent',
                            'scope_exclusion':None if measured else {'reason':'derived' if token in outputs else 'label'}})
        claims=[{'claim_id':'fit','type':'derived','final_type':'derived','quote':text,'lines':[1,1],
                 'token_ids':[x['token_id'] for x in outputs],'final_verdict':'outside','final_reason':'fit not recomputed'}]
        old={'schema':'thermoml-benchmark-eval/2','answer':{'answer_id':'fixture'},'excerpts':_excerpts(oldrows),
             'factual_claims':claims,'columns':{'values':[]},'sources':{},'counts':{'numeric':_counts(oldrows),'factual_claims':_claim_counts(claims)}}
        write(self.packet/'existing_evaluation.json',old)
        for check in checks:check.update(numeric_outcome='exact',source_outcome='exact',condition_outcome='exact',outcome='exact',
                                        reason='native fitted R squared matches displayed value',evidence=['main_fit_summ.csv:row2:value'])
        report={'schema':'thermoml-artifact-correction/1','answer_id':'fixture','existing_evaluation_sha256':sha(self.packet/'existing_evaluation.json'),
                'answer_sha256':sha(self.packet/'answer.md'),'artifact_manifest_sha256':sha(self.packet/'BLIND_INPUT.json'),
                'complete':True,'entire_answer_read':True,'all_pipeline_outputs_inventoried':True,'all_artifacts_inspected':True,
                'unresolved_questions':[],'pipeline_inventory':mapping['pipeline_inventory'],'token_checks':checks,
                'claim_updates':[{'claim_id':'fit','final_type':'pipeline_artifact','final_verdict':'exact',
                                  'reason':'both occurrences compared to native output','evidence':['main_fit_summ.csv:row2:value']}]}
        doc,receipt=correct(self.packet,report)
        self.assertEqual(doc['schema'],'thermoml-benchmark-eval/3')
        self.assertEqual(doc['factual_claims'][0]['type'],'pipeline_artifact')
        self.assertEqual(doc['factual_claims'][0]['verdict'],'exact')
        self.assertNotIn('not recomputed',doc['factual_claims'][0]['reason'])
        self.assertTrue(all(r['claim_provenance'][0]['type']=='pipeline_artifact' for e in doc['excerpts'] for r in e['values'] if r['group']=='pipeline_artifact'))
        self.assertEqual(doc['counts']['numeric']['by_group']['pipeline_artifact']['exact'],2)
        self.assertEqual(doc['counts']['numeric']['by_group']['property_value']['exact'],1)
        self.assertEqual(doc['counts']['numeric']['property_rollup']['total'],3)
        self.assertEqual(doc['counts']['numeric']['totals']['total'],3)
        measured=next(r for r in old['excerpts'][0]['values'] if r['text']=='998.2')
        self.assertEqual(next(r for r in doc['excerpts'][0]['values'] if r['text']=='998.2'),measured)
        bad=copy.deepcopy(report);bad['token_checks'][0].pop('artifact_reference')
        with self.assertRaises(ValueError):correct(self.packet,bad)
        bad=copy.deepcopy(report);bad['token_checks'][0]['outcome']='outside'
        with self.assertRaises(ValueError):correct(self.packet,bad)
        bad=copy.deepcopy(report);bad['claim_updates']=[]
        with self.assertRaises(ValueError):correct(self.packet,bad)
        self.assertEqual(receipt['status'],'PASS')
        # Explicitly restore missing legacy owner links; keep legitimate labels outside.
        empty=copy.deepcopy(old);empty['factual_claims'][0]['token_ids']=[]
        write(self.packet/'existing_evaluation.json',empty)
        repaired=copy.deepcopy(report);repaired['existing_evaluation_sha256']=sha(self.packet/'existing_evaluation.json')
        repaired['claim_updates'][0]['token_ids']=[x['token_id'] for x in outputs]
        label=next(x for x in tokens if x['lexical_kind']=='superscript')
        repaired['exclusion_updates']=[{'token_id':label['token_id'],'kind':'label','reason':'R squared label exponent','evidence':['exact answer lexical context']}]
        fixed,_=correct(self.packet,repaired)
        self.assertEqual(fixed['factual_claims'][0]['initial_token_ids'],[])
        self.assertTrue(all(r['claim_provenance'][0]['type']=='pipeline_artifact' for e in fixed['excerpts'] for r in e['values'] if r['group']=='pipeline_artifact'))
        bad=copy.deepcopy(repaired);bad['exclusion_updates'][0]['token_id']=outputs[0]['token_id']
        with self.assertRaises(ValueError):correct(self.packet,bad)

    def test_sanitizer_preserves_unique_own_claim_ids_and_references(self):
        from prepare_correction import sanitized_existing
        old={'answer':{'answer_id':'A020','blind_id':'F020'},'factual_claims':[
            {'claim_id':'F020-C001','quote':'own F020-C001; foreign F070'},
            {'claim_id':'F020-C002','quote':'own F020-C002'}],
            'excerpts':[{'related_claim_ids':['F020-C001','F020-C002'],'claim_provenance':[{'claim_id':'F020-C001'}]}]}
        clean=sanitized_existing(old)
        self.assertEqual([c['claim_id'] for c in clean['factual_claims']],['F020-C001','F020-C002'])
        self.assertEqual(clean['excerpts'],old['excerpts'])
        self.assertNotIn('F070',clean['factual_claims'][0]['quote'])
        old['factual_claims'][1]['claim_id']='F020-C001'
        with self.assertRaises(ValueError):sanitized_existing(old)


    def test_no_prediction_claim_preserves_type_and_rejects_scalar_escape(self):
        from correct_artifacts import no_output_requested_condition
        text='**Question:** Viscosity at 25 °C?\nNo viscosity prediction can be made at 25 °C.\n'
        ts=tokenize(text,'fixture');by={t['token_id']:t for t in ts}
        c={'type':'prediction_feasibility','quote':text.splitlines()[1],'token_ids':[ts[-1]['token_id']]}
        self.assertTrue(no_output_requested_condition(c,by,text))
        self.assertFalse(no_output_requested_condition({**c,'type':'derived'},by,text))
        text2=text+'Saved R² = 0.9.\n';ts2=tokenize(text2,'fixture');by2={t['token_id']:t for t in ts2}
        self.assertFalse(no_output_requested_condition({**c,'token_ids':[ts2[-1]['token_id']]},by2,text2))
        self.assertFalse(no_output_requested_condition({**c,'quote':c['quote']+' Saved R² = 0.9.'},by,text2))
        self.assertFalse(no_output_requested_condition(c,by,text.replace('Question:** Viscosity at 25','Question:** Viscosity at 30')))

    def test_legacy_factual_flags_normalize_without_verdict_changes(self):
        from correct_artifacts import normalize_legacy_claim_flags
        from canonical_export import _claim_counts
        claims=[{'claim_id':'c1','verdict':'exact','final_verdict':'exact','misassigned':'False'},
                {'claim_id':'c2','verdict':'miss','final_verdict':'miss','misassigned':'True'},
                {'claim_id':'c3','verdict':'outside','final_verdict':'outside'}]
        records=normalize_legacy_claim_flags(claims)
        self.assertIs(claims[0]['misassigned'],False)
        self.assertIs(claims[1]['misassigned'],True)
        self.assertNotIn('misassigned',claims[2])
        self.assertEqual([c['verdict'] for c in claims],['exact','miss','outside'])
        self.assertEqual(_claim_counts(claims)['misassigned'],1)
        self.assertEqual([r['claim_id'] for r in records],['c1','c2'])
        with self.assertRaises(ValueError):normalize_legacy_claim_flags([{'claim_id':'bad','misassigned':'false'}])

    def test_legacy_boolean_strings_are_not_truthy_flags(self):
        from canonical_export import boolean
        self.assertIs(boolean("False"),False);self.assertIs(boolean("True"),True)
        with self.assertRaises(ValueError):boolean("false")
        rows=[{'group':'property_value','outcome':'exact','misassigned':'False'},
              {'group':'property_value','outcome':'miss','misassigned':'True'}]
        self.assertEqual(_counts(rows)['totals']['misassigned'],1)
        rows[1]['misassigned']='False'
        self.assertEqual(_counts(rows)['totals']['misassigned'],0)


    def test_embedded_run_verdict_tail_removed_without_authored_numbers(self):
        from prepare_correction import clean_existing_inputs
        from canonical_export import _excerpts, _claim_counts
        tail='Confidence reduced to medium because the first subagent run (run_5) failed to produce verified fit_block output per its verdict, and while the second subagent run (run_6) shows a successful fit_block call returning numerical coefficients, the identical numerical values across both runs warrant caution.'
        text='Measured 0.00132 Pa s. '+tail+' |\nFollowing 19 points.\n'
        tokens=tokenize(text,'fixture');rows=[{**x,'context_excerpt':x['line_text'],'group':'outside','outcome':'outside','misassigned':False} for x in tokens]
        claims=[{'claim_id':'partial-diagnostic','quote':'first subagent run (run_5) failed to produce verified fit_block output per its verdict, and while the second subagent run (run_6) shows a successful fit_block call returning numerical coefficients','token_ids':[],'final_verdict':'outside'}]
        old={'answer':{'answer_id':'fixture'},'excerpts':_excerpts(rows),'factual_claims':claims,'counts':{'numeric':_counts(rows),'factual_claims':_claim_counts(claims)}}
        clean,data,kept,receipt=clean_existing_inputs(old,text.encode())
        self.assertEqual(clean['factual_claims'],[])
        self.assertEqual(receipt['removed_diagnostic_claim_ids'],['partial-diagnostic'])
        self.assertNotIn('per its verdict',data.decode())
        self.assertEqual([x['text'] for x in kept],['0.00132','19'])
        self.assertEqual([(x['line'],x['column']) for x in kept],[(x['line'],x['column']) for x in tokens if x['text'] in ['0.00132','19']])
        self.assertEqual(len(receipt['removed_diagnostic_token_ids']),2)
        self.assertEqual(sum(len(e['values']) for e in clean['excerpts']),2)

    def test_legacy_diagnostic_removal_preserves_authored_spans_and_ids(self):
        from prepare_correction import clean_existing_inputs
        from sanitize_answer import FLAGS_HEADER
        from canonical_export import _excerpts, _claim_counts
        text='Measured 2.5\n---\n'+FLAGS_HEADER+'\n- **UNINSPECTED_VALUE** PROPblock_1: 2.5 exists in source\n  fix (required — this value IS in the cited block\'s database table): `inspect_block_table(block_number="PROPblock_1")`\n\n### Core claims\nMeasured 2.5\n'
        tokens=tokenize(text,'fixture')
        rows=[{**x,'context_excerpt':x['line_text'],'group':'outside','outcome':'outside','misassigned':False} for x in tokens]
        claims=[{'claim_id':'generated','lines':[4,4],'token_ids':[],'type':'derived','final_verdict':'outside','quote':'diagnostic'}]
        old={'answer':{'answer_id':'fixture'},'excerpts':_excerpts(rows),'factual_claims':claims,'counts':{'numeric':_counts(rows),'factual_claims':_claim_counts(claims)}}
        clean,data,kept,receipt=clean_existing_inputs(old,text.encode())
        expected=[x for x in tokens if x['line'] in [1,8]]
        self.assertEqual([(x['token_id'],x['line'],x['column']) for x in kept],[(x['token_id'],x['line'],x['column']) for x in expected])
        self.assertNotIn(FLAGS_HEADER,data.decode());self.assertEqual(clean['factual_claims'],[])
        self.assertTrue(receipt['retained_numeric_findings_unchanged'])
        self.assertEqual([x['line'] for x in clean['excerpts']],[1,8])


    def test_enriched_fixed_return_extraction_and_blocked_call_isolation(self):
        from native_tool_returns import extract
        text='### Step 4: `fit_block`\n\n<details><summary>Arguments</summary>\n\n```json\n{"doi":"example","purpose":"authored intention"}\n```\n</details>\n<details><summary>Result — full saved tool_result body</summary>\n\n~~~~text\nR² = 0.9; BIC = -12.3\n~~~~\n</details>\n'
        rows=extract(text);self.assertEqual(len(rows),1);self.assertEqual(rows[0]['text'],'R² = 0.9; BIC = -12.3\n')
        self.assertEqual(rows[0]['arguments'],{'doi':'example'})
        self.assertEqual(extract(text.replace('`fit_block`','`fit_block` VALIDATION BLOCKED')),[])


    def test_pipeline_evidence_requires_own_published_artifact_origin(self):
        token=tokenize('0.982166','fixture')[0];check=self.check(token,self.source('main',2,'r_squared'))
        manifest=json.loads((self.packet/'BLIND_INPUT.json').read_text());wanted=next(x for x in manifest['artifact_files'] if x['path']=='main_fit_summ.csv')
        original=copy.deepcopy(wanted['eligibility'])
        for field,value in [('root','original_session'),('owner_answer_id','other_answer'),('source_path','../outside.csv'),('source_sha256','')]:
            wanted['eligibility']=copy.deepcopy(original);wanted['eligibility'][field]=value;write(self.packet/'BLIND_INPUT.json',manifest)
            with self.assertRaises(ValueError):resolve_artifact(self.packet,token,check)
        wanted.pop('eligibility');write(self.packet/'BLIND_INPUT.json',manifest)
        with self.assertRaises(ValueError):resolve_artifact(self.packet,token,check)

if __name__=='__main__':unittest.main(verbosity=2)


class ChemicalLocantExclusionTests(unittest.TestCase):
    def test_mechanism_claim_not_retyped_as_label_but_metric_still_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)
            rows=[{'token_id':'n1','text':'1','line_text':'1-propanol mechanism','column':1,'end_column':2,'lexical_kind':'number'},
                  {'token_id':'n2','text':'0.99','line_text':'R2 = 0.99','column':6,'end_column':10,'lexical_kind':'number'}]
            write(p/'tokens.json',rows)
            claims=[{'claim_id':'mechanism','token_ids':['n1'],'quote':'1-propanol mechanism','type':'physical_interpretation','verdict':'outside','reason':'Fitting arithmetic not recomputed'},
                    {'claim_id':'metric','token_ids':['n2'],'quote':'R2 = 0.99','type':'derived','verdict':'outside','reason':'Fitting arithmetic not recomputed'}]
            errors=exclusion_errors(p,{'pipeline_inventory':{'occurrences':[]},'exclusions':[]},claims)
            self.assertEqual(len(errors),1)
            self.assertTrue(errors[0].startswith('metric:'))


class MagnitudeInterpretationTests(unittest.TestCase):
    def test_signed_max_excess_is_explicit_magnitude_only(self):
        from unittest.mock import patch
        from artifact_source import inspect_magnitude_interpretation
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder);(p/'answer.md').write_text('Maximum magnitude is 1.034e-6 m3/mol.')
            ref={'format':'text','path':'fixed.txt','line':1,'unit_error':None,'stored_value':'-1.03367e-6','converted_stored_value':'-1.03367e-6','basis':'signed extremum','claimed_basis':'absolute magnitude'}
            spec={'answer_context':'Maximum magnitude is 1.034e-6 m3/mol.','reason':'Absolute magnitude of native signed extremum'}
            with patch('artifact_source.artifact_bytes',return_value=(b'Max |excess| = -1.03367e-6','hash')):
                row=inspect_magnitude_interpretation(p,ref,spec)
                self.assertEqual(row['native_stored_value'],'-1.03367e-6')
                self.assertEqual(row['interpreted_value'],'0.00000103367')
                with self.assertRaises(ValueError):inspect_magnitude_interpretation(p,ref,{**spec,'answer_context':'Maximum'})
            with patch('artifact_source.artifact_bytes',return_value=(b'A0 = -1.03367e-6','hash')):
                with self.assertRaises(ValueError):inspect_magnitude_interpretation(p,ref,spec)


class ExistingOutsidePreservationTests(unittest.TestCase):
    def test_repair_preserves_method_but_cannot_exclude_corrected_or_changed_claim(self):
        from correct_artifacts import preserve_existing_outside
        claim={'type':'method','final_verdict':'outside','token_ids':['n1','n2']}
        update={'final_type':'method','final_verdict':'outside','preserve_existing_outside':True}
        self.assertTrue(preserve_existing_outside(claim,update,{'n1','n2'},set()))
        self.assertFalse(preserve_existing_outside(claim,update,{'n1','n2'},{'n2'}))
        self.assertFalse(preserve_existing_outside(claim,update,{'n1'},set()))
        self.assertFalse(preserve_existing_outside({**claim,'final_verdict':'miss'},update,{'n1','n2'},set()))
        self.assertFalse(preserve_existing_outside(claim,{**update,'final_type':'derived'}, {'n1','n2'},set()))
        self.assertFalse(preserve_existing_outside(claim,{**update,'token_ids':['n1']}, {'n1','n2'},set()))
        self.assertFalse(preserve_existing_outside(claim,{**update,'preserve_existing_outside':False}, {'n1','n2'},set()))

class NonnumericOwnershipRepairTests(unittest.TestCase):
    def test_only_verbatim_nonnumeric_outside_quote_can_clear_links(self):
        from correct_artifacts import clear_nonnumeric_quote_ownership
        answer='A0 = 2; strong molecular interactions.'
        tokens=tokenize(answer,'fixture');by={t['token_id']:t for t in tokens}
        claim={'quote':'strong molecular interactions','lines':[1,1],'type':'outside','verdict':'outside','token_ids':list(by)}
        update={'clear_spurious_numeric_ownership':True,'token_ids':[],'final_type':'outside','final_verdict':'outside','reason':'Broad line links are outside the actual quoted clause.'}
        self.assertTrue(clear_nonnumeric_quote_ownership(claim,update,by,answer))
        for change in [{'quote':'A0 = 2'},{'quote':'absent text'},{'verdict':'miss'},{'lines':[2,2]}]:
            self.assertFalse(clear_nonnumeric_quote_ownership({**claim,**change},update,by,answer))
        for change in [{'final_type':'label'},{'token_ids':list(by)},{'clear_spurious_numeric_ownership':False}]:
            self.assertFalse(clear_nonnumeric_quote_ownership(claim,{**update,**change},by,answer))
