# Shared worker dispatch

Initial numerical and enabled scientific workers receive one clean answer. Every reconciler receives a scoped group manifest; a singleton and a larger authorized group use the same render-group, check-group and run-group path. Scalar reconciliation dispatch is rejected.

Before rendering, prepare all clean packets, complete screens and actual orchestrator guidance. The group renderer composes templates/reconciler.system.md, a member-scoped supplement for each declared answer, and reconciler.task.md. --profile-template names the first member's Query/Analysis/Main supplement and locates the sibling templates; each member's validated packet level selects its own supplement. The record binds member_levels and every used template hash. It records one actual group context, its ordered member IDs, manifest/input hashes, explicit argv, model/settings and allowed reads. Do not compose the single-answer common.system.md into this group prompt. See [INTERFACE.md](INTERFACE.md) for exact binding names.

Create the group work directory and each member's reconciliation directory. The renderer settings must match dispatch.settings for writable roots in this order: RUN/groups/GROUP, each RUN/reconciliation/UNIT in manifest order, then optional RUN/public/tools/lookups. Group inputs remain read-only. Do not add the whole runtime, source databases or private identity directories as write roots.

Check without launching a reviewer:

    python -B tools/dispatch.py check-group --run-root RUN --group-manifest RUN/groups/GROUP/group.json --instruction-dir INSTRUCTION_DIR --codex-cli CODEX_EXE --model MODEL --reasoning-effort REASONING --max-workers MAX_WORKERS

MAX_WORKERS must equal the current user-bound run contract. The intent binds all member sanitization checks, initial/screen/guidance hashes, group manifest, instructions, model/settings, executable and worker limits. The check reads the installed CLI help and refuses unsupported runtime semantics. It does not dispatch an agent.

A per-invocation gate outside every worker-writable root (including the group directory, member decision directories and lookup directory) has schema_version thermoml-dispatch-gate/1; ready, evaluation_dispatch_allowed, workflow_ready and workflow_accepted are true; scope is reconciliation_group; group_scope contains group_id and the exact ordered member_ids; intent_sha256 matches the checked intent. Create it only after readiness and input/evidence checks. The same gate applies for group size one. Changed inputs or settings require a new check and matching gate.

Launch with the same arguments using run-group and required --gate GATE_JSON. Optional --allow-write-dir permits only RUN/public/tools/lookups; group and member output roots are derived. The launcher rechecks the gate, acquires a shared worker slot before process creation, records exact submitted prompt bytes and process status, and releases the slot after completion. All roles share max_workers and optional stage_limits. If no slot is available, no worker starts; the orchestrator queues work. Coordination and local checks are not worker agents.

Initial/scientific commands use check/run with one answer ID and their role, explicit packet/instruction paths and the same run contract. Bypass refuses scientific dispatch. Initial and reconciliation contexts start fresh. The runtime records instruction-only read isolation if no filesystem read sandbox is available; it must not claim stronger enforcement. The supplied CLI transport is combined prompt text, not a separate platform system-role message.

worker_slots.py uses an atomic lock directory and explicit leases under RUN/control/worker-slots. Interrupted process/lock records require inspection and verified termination before manual recovery; no stale record is automatically discarded. Failed dispatch outputs are preserved, and a failed process does not authorize an automatic retry. Recheck inputs and prepare a fresh invocation/gate after resolving the failure.
