# Rolling ThermoML answer-question interpretations

The [JSON register](user-interpretations.json) is authoritative. This file is its synchronized readable view. Record each relevant new user answer/comment in JSON first, then update this view and verify matching IDs and exact reply text.

Only answer meaning and claim applicability; excludes workflow, dispatch, model, publication, run-score comparison and continuation policy.

Orchestrator owns this multi-answer register. Give a one-answer worker only entries matched to its original question and actual answer excerpt. Preserve original H IDs.

Recovered original H01–H56 plus later H57–H67; preserve original stable H IDs. Earlier USER-prefixed subset is superseded as storage and is retained only in private history. This count is not a cap on future comments.

Historical provenance varies: H01–H06 and H67 include exact replies supplied from the current conversation; H07–H21 remain saved summaries; H22–H56 preserve recorded selections (possibly UI labels); H57–H66 preserve recorded replies. Do not invent unavailable dialogue.

Append each new user reply as exact text separately from the orchestrator interpretation. Include prompt, answer excerpt and source/property/state/population. Corrections link supersedes and superseded_by and retain old records.

Future records include unique next H ID, status, user_reply_exact when available, original question and exact answer/claim excerpt, answer identity and component/property/state/population applicability, separate scoped interpretation, source and attribution status, supersedes/superseded_by without deleting earlier text.

## H01

In a table headed P (kPa), cells "~92 (atm)" / "~101 (atm)" mean kPa; "(atm)" is an atmospheric-pressure note.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Main Q4.2; pressure table headed P (kPa)

Recorded user reply/selection: "Use kPa; treat “(atm)” as an atmospheric-pressure note (Recommended)"

Attribution: Exact user reply supplied from the current conversation by coordinating parent; interpreted in its original question context.

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H02

Density "as low as ~53 kg/m³" is a study-wide minimum. Preserve any conflicting later wording suggesting that this minimum occurred above 50 MPa as a separate wording/source-scope claim.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Main Q4.2; study-wide density minimum and >50 MPa wording

Recorded user reply/selection: "Check the study-wide minimum and retain the wording caveat (Recommended)"

Attribution: Exact user reply supplied from the current conversation by coordinating parent; interpreted in its original question context.

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H03

A joint statement that excess enthalpy and excess volume span x≈0.04–0.95 applies to each property separately, not the union of datasets.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q2.1; excess enthalpy and excess volume joint range

Recorded user reply/selection: "Apply to each property separately; retain the enthalpy lower-end discrepancy (Recommended)"

Attribution: Exact user reply supplied from the current conversation by coordinating parent; interpreted in its original question context.

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H04

The ethanol-viscosity statement "a few outliers reaching up to ~1.19 mPa·s" is a distribution summary to source-trace, not a new upper-bound assertion with invented pressure limits.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.5 B; ethanol-viscosity distribution

Recorded user reply/selection: "Source-trace the distribution summary (recommended)"

Attribution: Exact user reply supplied from the current conversation by coordinating parent; interpreted in its original question context.

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H05

A falling/rolling-sphere viscosity table headed η at 298.15 K and giving ~1.05–1.10 mPa·s (ambient P) is a reported-data claim, even where preceding prose says "expected".

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.5 B; falling/rolling-sphere viscosity table

Recorded user reply/selection: "Check as reported data; retain the missing-state result (Recommended)"

Attribution: Exact user reply supplied from the current conversation by coordinating parent; interpreted in its original question context.

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

The missing-state issue is the absence of a source observation at 298.15 K; do not replace it with a pressure-only objection.

Supersedes: []. Superseded by: null.

## H06

For a sentence calling 785.7 and 787.2 kg/m³ "Pure methanol densities", use the preceding table's ethanol/methanol assignments respectively and preserve the contradictory wording separately.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q2.3 B; ethanol/methanol pure densities

Recorded user reply/selection: "Use the table’s ethanol/methanol pair; retain the wording caveat (Recommended)"

Attribution: Exact user reply supplied from the current conversation by coordinating parent; interpreted in its original question context.

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H07

Generic pure-component baselines may be verified with independently located appropriate archive records. Retain unknown original attribution.

Status: active. Scope: general_claim_interpretation.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H08

Original derived/prescribed/external roles govern numerical scope when later diagnostics assert database verification. Evaluate the diagnostic source assertion separately from raw-measurement counts.

Status: active. Scope: general_claim_interpretation.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H09

Excess-volume intervals later described as estimates from chemical reasoning are estimates too, including earlier intervals called literature values. Preserve the source-description contradiction and check input provenance without recomputing outputs.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H10

Compare an explicitly stated fixed pressure directly against each block's fixed pressure. Dependent property values still have separate state checks.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H11

The approximate density plateau ρ≈997 kg/m³ for x(DMF)=0–0.10 is a collective regional summary. Trace supporting measurements rather than requiring every point to round to 997.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H12

Approximate viscosity-peak bands ~3–4 and ~5–7 mPa·s use the smallest/largest relevant dataset maxima at the stated temperatures. An unqualified repeated NMP narrative peak inherits the surrounding 293–298 K narrative scope; a table explicitly at 298 K retains its narrower scope.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H13

Repeated property summaries under shared numerical conditions ~293–298 K and ~101 kPa use those conditions directly, even when an earlier precise row has 100 kPa.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H14

A fit's claimed "actual measured temperatures" 298.145–298.146 K is checked against all observations in its stated 298.15±0.5 K input window. Retain that the original selected fit subset is unknown. Do not recompute the fit.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H15

The collective background dielectric range ε≈37–47 for DMF, DMSO and NMP is source-traced as a collective summary. Record missing original source/state; do not invent conditions.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H16

A repeated density range ~1002–1004 kg/m³ at 293 K described later as pure water inherits its earlier dilute-NaCl-solution assignment. Preserve the contradictory wording.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H17

Uncited thermophysical background claims remain in scope, including a ~72 °C miscibility statement, ~62 °C melting point, and a viscosity-maximum composition vicinity. Search absence and provenance gaps are retained.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H18

A temperature range described as "spanning 298.15 K" asserts coverage of the envelope, not a measured isotherm exactly at 298.15 K.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H19

Pressure and composition conditional matches strictly below 1% relative difference are permitted with separate coordinate and property outcomes, without interpolation or assumed physical equivalence. Nonexact comparisons against zero are Miss, with no new absolute tolerance.

Status: active. Scope: general_claim_interpretation.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H20

A DMF/water viscosity maximum x≈0.25, η≈1.28 mPa·s discussed as a fitted curve is model-derived. Check inputs and source provenance; do not recalculate its output.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H21

Calculations are not traced numerically by design: do not recompute means, fits, ratios or predictions. Factual property-category counts inside answer prose remain in scope.

Status: active. Scope: general_claim_interpretation.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Attribution: Saved historical summary of earlier user decision; literal reply unavailable

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H22

DMSO/water viscosity at 298 K described as "often exceeding 3–4 mPa·s" means above 3 within the 3–4 band; it does not require a value above 4. Preserve original source/state and composition checks separately.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Interpret as above 3 within the 3–4 band"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H23

In the benzene/toluene versus hexane/ethanol near-room-temperature comparison, the stated 288–308 K window is rounded and includes 308.15 K. Apply to that answer's data-block row and associated broader comparison; use the same interpretation for equivalent wording in either answer. Do not impose this window on claims that explicitly state a different range. Count only points actually satisfying the interpreted window when an assertion counts points in-window; do not conflate full-block totals with filtered point totals.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Treat 288–308 K as rounded; include 308.15 K"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H24

In the five-source pure-DMSO density summary, the unquantified qualitative phrase "near-atmospheric" includes the explicitly listed85.9kPa source alongside101–101.325kPa. This does not change checks of an explicitly numerical pressure such as~101kPa or1atm. Do not invent numerical pressure equality from this qualitative description.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Include85.9kPa in the qualitative description"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H25

The aqueous propan-2-ol statement "Common properties measured for this system in ThermoML typically include" is an availability list of the named categories, not an assertion that every category is frequently reported.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Check as available categories"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H26

For binary-viscosity claims that datasets typically contain full 0–1 composition sweeps with 11–21 or 10–20+ points, require a majority of all fixed-temperature/pressure binary measurement groups, not merely the already full-range subset.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Require a majority of all binary measurement groups"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H27

The source description ~14 points near 298.15 K for 10.1021/je700671t:3 describes one nearby isotherm of 14 points. It does not assert a measured 298.15 K isotherm or combine both neighboring isotherms. Fit execution remains outside.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "One nearby isotherm: 14 points"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H28

Where an answer explicitly says aqua is absent from stored aliases and recommends manual mapping to water, treat the normalization as external and verify the canonical water target. Do not require a stored aqua alias for the explicitly manual recommendation.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Treat manual normalization as external; verify the water target"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H29

The generic ternary liquid-viscosity pressure-range inventory includes reported experimental pressure coordinates, including CO2 gas-loading pressure 0 kPa associated with liquid-viscosity measurements. Retain the gas-loading label; do not equate it to liquid total pressure.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Include reported experimental pressure coordinates; retain the gas-loading label"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H30

The inference that ternary datasets map the Gibbs triangle well is an undefined qualitative adequacy judgment outside the score. Report measured composition coverage separately; numerical counts remain independently checked.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Qualitative adequacy judgment; report measured coverage separately"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H31

The approximate ethanol-viscosity cluster around 1.08–1.09 mPa·s at 298.15 K uses displayed-precision bounds 1.075–1.095 mPa·s. Preserve the source/state screening and observed majority counts.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Use displayed-precision bounds 1.075–1.095"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H32

For the ethanol/water source listing 288–323 K and 1.71–29.22 kPa, near-ambient conditions refers to both temperature and pressure. Flag the pressure description; check explicit numeric ranges separately.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Both temperature and pressure; flag the pressure description"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H33

When an answer explicitly identifies 1,2-dimethanol as nonstandard, proposes ethylene glycol conditionally and labels its data EG/water, validate the stated conditional EG/water data. The intended prompt chemical remains unresolved, not an established system-substitution error.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Validate the conditional EG/water data; leave prompt intent unresolved"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H34

Pure-component molar volumes 58.6, 40.7, 52.8 and 77.4 cm3/mol following an explicit density-to-volume method are calculated baselines. Check source provenance, retaining unknown original inputs; do not recompute or score outputs as raw measurements.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Treat as calculated baselines; check source provenance without recomputing"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H35

In the methanol-to-ethanol-to-1-propanol excess-enthalpy chain-length discussion, any longer-chain alcohol means the saturated straight-chain primary alcohol series. Do not use unsaturated alcohols or polyols as counterexamples to that selected scope.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Use the saturated straight-chain primary alcohol series"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H36

The only trioxide-like compound comparison is limited to the answer’s named candidate set: trioxane, the two trioxolanes, ethylene oxide and trimethyltrioxane. Do not introduce an undefined broader chemical class.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Use the named candidate set"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H37

For the trioxane/water partial-miscibility description, ambient temperatures includes the lowest stored LLE temperature 301.28 K. Retain the actual stored range; this is not a general numeric tolerance for temperature.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Include 301.28 K; retain the actual stored range"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H38

For the IPA/water claim that the viscosity maximum diminishes with temperature, require a demonstrated mixture peak. Monotonic measurements only at mass fractions 0.1, 0.2 and 0.3 show a decreasing largest sampled value but do not establish a peak.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Require a demonstrated mixture peak; retain insufficient coverage"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H39

For hexane/ethanol excess-enthalpy and excess-volume maxima described as near the equimolar region, the qualitative description includes ethanol mole fraction 0.3592. Preserve actual respective peak coordinates 0.3592 and 0.4524; no coordinate equality is implied.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Include 0.3592 in the qualitative description; retain the exact peak coordinates"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H40

Pure hexane approximately 650 and pure ethanol approximately 789 kg/m3 in the 298.15 K mixture comparison inherit 298.15 K. Compare with 654.9 and 785.1 in the same dataset, respectively: both Near. Matches at other temperatures remain diagnostic only.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Use 298.15 K for both baselines; classify both as Near"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H41

Negative excess enthalpy across the entire composition range summarizes the listed measured range, not every unmeasured interior composition. Apply equivalently to direct measured summaries; explicit fitted-curve signs remain Outside.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Summarize the listed measurements; retain the measured range"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H42

Most comprehensive without a ranking criterion is an undefined qualitative ranking outside the score. Report separately the cited 77-point wider-temperature dataset and the alternative 84-point narrower-temperature dataset.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Treat as an undefined qualitative ranking outside the score; report both facts"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H43

The ethanol/water source-table range 0.000759–0.002864 Pa·s following its 25-point 298.15 K description is checked at 298.15 K: 0.00089689–0.0024286 Pa·s. Both reported bounds are Miss; full-block matches remain diagnostic.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Use the preceding 298.15 K series; classify the range as Miss"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H44

Where measured binary excess molar volumes are explicitly explained as density-to-volume transformations, the explicit transformation governs. Retain the wording caveat rather than invent a separate assertion that measured excess volume is stored. Calculated outputs remain outside numerical scoring; source inputs and factual category counts under this interpretation remain checkable.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Use the explicit transformation; retain wording caveat"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H45

No ternary measurements exist in the stated ternary volume-estimation context means no volumetric measurements. Retain broad-wording caveat and the separately acknowledged enthalpy-of-solution record; do not count that record as a contradiction of volumetric absence.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Volumetric measurements; retain broad-wording caveat"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H46

The ACN/DMF source descriptions giving viscosity ranges 0.00028–0.00081 and 0.000293–0.000799 Pa·s describe full source blocks. Preserve the nearby 298.15 K wording as a temperature-scope caveat and keep explicit state claims separately checked.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Full blocks; retain temperature-scope caveat"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H47

For the viscosity fit targeting 303.15 K and 81.5 kPa, apply that target pressure to its separately cited pure methanol and ethanol input claims. Records at 101.325 kPa are state-assignment Miss; retain numeric comparisons and source metadata separately.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Apply the target pressure; count state-assignment Miss"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H48

The glycerol/water unqualified property list counts base properties across all presentations and groups refractive-index wavelengths. The applicable inventory is 14 property categories, 11 density blocks including one difference block, and 5 sound-speed blocks including one difference block. Other counts remain independently checked.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Count base properties across all presentations; group refractive-index wavelengths"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H49

Ethanol/water and methanol/water overview totals include all archived phases, including the explicitly described supercritical coverage. Check applicability of specific measurements to a liquid model separately; do not silently restrict overview totals to Liquid-labelled blocks.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Include all phases in the overview; check liquid applicability separately"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H50

qualitative peak width: Treat “broader in composition range” as a qualitative judgment outside scoring because no width criterion is specified. Retain measured curves and independently checked peak heights/coordinates.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Treat as qualitative and outside the score; retain the measured curves"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H51

approximate equimolar absence: The table's x approximately0.50 scope governs the later no-direct-measurement assertion. The cited methanol/water point x(methanol)=0.4997, eta=0.001309Pa*s makes the absence claim Miss. Interpolation arithmetic remains outside numerical scoring.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Use the approximate table scope; count the absence claim as Miss"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H52

unlabelled source-table coordinates: Use each cited block's water composition basis for x=0.0308–0.9798 and molality0.092mol/kg. Flag missing component labels. Explicit DMSO-labelled claims remain separately checked.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Use each cited block’s water basis; flag the missing component labels"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H53

undefined majority generalizations: Treat most-organic-mixture interior-maximum/low-composition enhancement generalizations as qualitative outside scoring. Report measured examples and exceptions; do not invent a population or threshold.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Treat as qualitative; report measured examples and exceptions"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H54

undefined viscosity class rankings: Treat the qualitative class ranking and repeated unquantified class comparisons as unscored. Retain evidence gaps and counterexamples. Individual quoted measurements remain scored.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Treat the class ranking as unscored; retain evidence gaps and counterexamples"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H55

sparse alcohol-rich density coverage: Treat sparse as an unscored adequacy judgment. Report the omitted13-point full composition scan, including five interior alcohol-rich observations at298.15K.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Unscored adequacy judgment; report the omitted scan"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H56

GLOBAL approximate peak-composition bands: Check peak containment using displayed-precision bounds and record actual measured coordinates. Do not require each composition-band endpoint to equal a measured peak coordinate. Keep the stated source, temperature, phase and component scope. This rule concerns composition-location bands, not the already-settled viscosity-magnitude endpoint rule. Originally derived composition conversions remain outside raw numerical scoring.

Status: active. Scope: general_claim_interpretation.

Known context: Match the exact claim context in the decision; no additional historical identity was recovered.

Recorded user reply/selection: "Check peak containment; record actual coordinates"

Attribution: Saved interpretation plus exact answer selection recorded in original decision-question log; selection may be a UI option label

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H57

The ethanol-viscosity summary "Range: 1.077–1.105 mPa·s" describes the five displayed examples.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.5; ethanol-viscosity five-example range

Recorded user reply/selection: "The five displayed examples"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H58

"Consensus value: ~1.08 mPa·s at 25 °C" is a derived consensus over a wider population.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.5; derived ethanol-viscosity consensus

Recorded user reply/selection: "A derived consensus over a wider population; trace its inputs and flag the unspecified method"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H59

Parenthetical data-point counts (including 39, 103 and 77) in the equimolar hexane/ethanol answer describe only measurements meeting the section's equimolar/298.15 K conditions and explicit row exceptions. These are factual counts, not measurement-score denominators.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.2; equimolar hexane/ethanol point counts

Recorded user reply/selection: "Only measurements meeting the section and row conditions"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H60

"Across 10 data blocks found in this temperature–pressure window" means actual measurements at the stated 298.15 K conditions.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.6; water heat-capacity block count

Recorded user reply/selection: "Actual measurements at the stated 298.15 K conditions"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H61

"Most precise single-point measurement" compares all individual measurements at 298.15 K, not only blocks with one total point.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.6; most precise water heat-capacity point

Recorded user reply/selection: "Compare all individual measurements at 298.15 K"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H62

The pure-propan-2-ol baseline in "Pure water at 25 °C has a density of ~997 kg/m³ and pure propan-2-ol ~786 kg/m³" inherits atmospheric pressure from the surrounding comparison.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.3; pure propan-2-ol density baseline

Recorded user reply/selection: "Inherit atmospheric pressure from the surrounding comparison"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H63

The repeated water heat-capacity cluster/spread band 75.1–75.5 J/(K·mol) is a qualitative central cluster, not an exhaustive range. Retain source populations and measurements outside the band; do not compare its bounds as stored extrema.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.6; water heat-capacity 75.1–75.5 cluster

Recorded user reply/selection: "Treat as a qualitative central cluster, not an exhaustive range (Recommended)"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H64

The two named labels, capillary tube and CAPTUB:UFactor:4, must be the two leading methods. Do not merge them into the broader capillary family to satisfy this claim.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.5; named capillary methods

Recorded user reply/selection: "Require the two named labels to be the two leading methods"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H65

For both surface-tension answers, include blocks whose nearest actual measurement is within 5 K of 298.15 K, inclusive. This does not turn interpolated target values into raw measurements.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.7; two surface-tension answers

Recorded user reply/selection: "Include blocks whose nearest measurement is within 5 K (Recommended)"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H66

The three unstarred uncertainties 0.00064, 0.001 and 0.0013 N/m beside interpolated surface tensions are copied input uncertainties. Check their bracketing source records and retain the provenance caveat; no source-reported uncertainty at 298.15 K is certified.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Query Q1.7; interpolated surface-tension uncertainty

Recorded user reply/selection: "Treat as copied input uncertainties; retain the provenance caveat (Recommended)"

Attribution: Saved interpretation plus literal user reply recorded in source

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Supersedes: []. Superseded by: null.

## H67

For the density-source agreement assertion comparing a displayed mean near 859.5 kg/m3 with the first source near 858.98 kg/m3, apply a strict 0.5 kg/m3 limit and annotate the failed bound as a near miss. This is a separate claim-layer interpretation; derived comparison output remains outside the frozen numerical score.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Density-source agreement claim: displayed mean near 859.5 versus first source 858.98 kg/m3, strict 0.5 bound

Recorded user reply/selection: "Option-1 but mark it as near miss"

Attribution: Exact user reply supplied from the current conversation by coordinating parent; interpreted in its original question context.

Use only for an original prompt and answer excerpt matching the specified claim, source, components, property, composition basis, temperature, pressure, phase, population and raw/derived role as applicable. Shared question numbering alone never establishes a match.

Option 1 is the displayed-mean comparison, not the closest individual measurement. This scoped claim-layer ruling cannot be transferred solely by question number or a base/rerun label.

Supersedes: []. Superseded by: null.

## H68

In the DMSO + water coverage answer, the statements about gaps above 318 K and no data above 308 K inherit the whole-kelvin rounding of the adjacent 298–318 K and 298–308 K windows. The stored maxima 318.15 K and 308.15 K belong to those rounded windows; do not interpret these excerpts as strict 318.000 K or 308.000 K upper thresholds.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Analysis Q4.2; no_ledger; F008-upper-temperature-bound

Original question: I am planning measurements on liquid DMSO + water near room temperature. Which thermophysical properties and composition–temperature regions are already well characterized, and where would new measurements add the most useful chemical information?

Recorded user reply/selection: "Use the rounded coverage windows (recommended)."

Attribution: Exact user reply in this conversation on 2026-10-28, supplied in response to the recorded answer-interpretation question.

DMSO + water, liquid viscosity and refractive-index temperature coverage in the quoted Analysis Q4.2 answer. Applies only to the adjacent rounded-window restatements; retain composition, pressure, source population and any separately explicit precision. Does not extend coverage beyond what the archive supports.

Answer excerpts:

- Line 43: - **Verdict: Well covered at 298–318 K. Gaps exist below 298 K and above 318 K.**
- Line 65: - DOI 10.1021/je7001013 (GLOBlit_10766, PROPblock_10): 298–308 K, x(DMSO) 0.01–0.77
- Line 67: - **⚠ Gap: Only one source; does not reach pure DMSO (n_D ≈ 1.479). No data above 308 K.**

Source context: [{"doi": "10.1016/j.jct.2006.12.012", "block": 3, "property": "viscosity", "maximum_temperature_k": "318.15"}, {"doi": "10.1021/je9001027", "block": 3, "property": "viscosity", "maximum_temperature_k": "318.15"}, {"doi": "10.1021/je7001013", "block": 10, "property": "refractive index", "maximum_temperature_k": "308.15"}]

This is an interpretation of display precision, not a preassigned numerical or factual verdict.

Supersedes: []. Superseded by: null.

## H69

For DMSO + water property-count and coverage statements qualified as near room temperature in the quoted answer, exclude liquid-property blocks whose measurements occur only at 275.15–283.15 K. Retain those records as colder adjacent evidence. Explicit claims of absence from the entire database remain archive-wide, and explicitly stated temperature intervals retain their own bounds.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Analysis Q4.2; full_capability; F027-near-room-scope

Original question: I am planning measurements on liquid DMSO + water near room temperature. Which thermophysical properties and composition–temperature regions are already well characterized, and where would new measurements add the most useful chemical information?

Recorded user reply/selection: "Exclude those cold-only blocks from near-room claims (recommended)."

Attribution: Exact user reply in this conversation on 2026-10-28, supplied in response to the recorded answer-interpretation question.

The near-room-temperature property inventory and composition–temperature coverage of the liquid DMSO + water system in Analysis Q4.2. The scope decision does not invent a universal numeric definition of room temperature and does not narrow categorical database-wide absence claims.

Answer excerpts:

- Line 15: The NIST ThermoML database contains data blocks for the dimethyl sulfoxide (DMSO) + water binary liquid system covering nine distinct thermophysical properties near room temperature, drawn from multiple publications. Coverage in composition–temperature space is highly uneven. Below is a property-by-property assessment.
- Line 22: - **Multiple blocks from independent research groups** (database query reports 8 blocks)
- Line 54: - **Gaps:** No data above the dilute DMSO region. The full composition range is entirely unmeasured.
- Line 144: - The NIST ThermoML database contains data for nine thermophysical properties of the DMSO + water binary liquid system near room temperature, but coverage in composition–temperature space is highly uneven across properties and sources.

Source context: [{"source": "ThermoML DMSO + water exact-system inventory", "population": "liquid-property blocks confined to 275.15–283.15 K", "properties": ["density", "heat capacity", "speed of sound"]}]

Re-enumerate actual property categories, eligible sources and phase relevance under this scope. The user did not approve the claimed number of properties, blocks, compositions or gaps.

Supersedes: []. Superseded by: null.

## H70

For the statement that no binary 1-propanol + water excess-enthalpy data exist at any temperature, binary data includes observations with exactly binary composition at a zero-third-component boundary of a ternary block. Retain the original ternary block provenance and the record state; do not restrict the inventory to blocks declared exactly binary.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Analysis Q5.1; no_ledger; F012-binary-boundary-scope

Original question: At 25 °C, does the nonideality of aqueous alcohol mixtures become stronger from methanol to ethanol to 1-propanol, by how much, and what molecular changes produce the trend?

Recorded user reply/selection: "Include binary-composition boundary records, retaining ternary provenance (recommended)."

Attribution: Exact user reply in this conversation on 2026-10-28, supplied in response to the recorded answer-interpretation question.

1-propanol + water excess molar enthalpy, specifically the archive-wide binary-data absence assertion in Analysis Q5.1. Acetic-acid mole fraction zero identifies the binary-composition boundary of the cited ternary source. Applicability to another excerpt requires matching its actual component/property/state/population wording, not merely its question number.

Answer excerpts:

- Line 51: **No binary 1-propanol + water Hᴱ data exists in the ThermoML database at any temperature.** However, the well-established literature consensus (not from ThermoML, so noted as context only) places the minimum Hᴱ for 1-propanol + water at approximately **+0.5 to +0.9 kJ/mol** (endothermic) near equimolar composition at 298.15 K — a dramatic sign reversal compared to the shorter-chain alcohols.
- Line 101: - No binary 1-propanol + water excess molar enthalpy data were found in the ThermoML database; the reported values for that system are from the broader literature and are explicitly flagged as non-database information.
- Line 112: | GLOBlit_1766 | 10.1016/j.fluid.2015.07.053 | PROPblock_1 |  | Ternary system excess molar enthalpy (GLOBprop_17) for 1-propanol (GLOBcomp_5) + acetic acid (GLOBcomp_35) + water (GLOBcomp_1) at 313.15 K and 101.0 kPa, measured by flow calorimetry. 59 data points. This is the only ThermoML block containing both 1-propanol and water with HE data; no binary 1-propanol + water HE data exists in the ThermoML database at any temperature. Not used for RK fitting. |

Source context: [{"doi": "10.1016/j.fluid.2015.07.053", "block": 1, "point_ids": [1, 22, 41], "declared_components": ["1-propanol", "acetic acid", "water"], "acetic_acid_mole_fraction": "0", "propanol_mole_fractions": ["0.5", "0.75", "0.25"], "excess_molar_enthalpy": "0", "temperature_k": "313.15", "pressure_kpa": "101"}]

The three boundary records do not establish a full binary calorimetric curve, a measurement at 298.15 K, or equivalence of reference states. Trace their original metadata and retain any reference-state uncertainty; no fitted values or arithmetic are newly authorized for raw measurement scoring.

Supersedes: []. Superseded by: null.

## H71

In the quoted DMSO + water viscosity sentence, the 22-point isotherm refers to the 22 observations selected as fit inputs, not to the total archived isotherm. Treat this count as fit-selection workflow provenance. Independently retain the complete raw isotherm of 24 observations, including 22 interior mixtures and two pure endpoints, and evaluate actual input coverage separately.

Status: active. Scope: specific_claim_or_claim_family.

Known context: Main Q3.6; no_ledger; F053-fit-subset-count

Original question: Water and dimethyl sulfoxide are known to interact strongly. Near 25 °C, at what DMSO composition is this interaction most evident in the measured thermodynamic or transport behavior, and what molecular picture explains it?

Recorded user reply/selection: "Selected 22 fit inputs (recommended)"

Attribution: Exact user reply supplied by parent /root on 2026-10-28 in response to F053-fit-subset-count / F053-Q1.

Only the quoted 22-point viscosity fit-input count in this DMSO + water answer. Other raw counts, composition-coverage assertions and source/state claims retain their own literal scope.

Answer excerpt, line 23:

The most striking evidence comes from viscosity measurements. Using the most comprehensive dataset in ThermoML — a 22-point isotherm at 298.15 K spanning the full composition range — a Redlich-Kister polynomial fit (order 5, R² = 0.9995) pinpoints the viscosity maximum:

Source context: [{"doi": "10.1016/j.jct.2006.12.012", "block": 3, "property": "viscosity", "temperature_k": "298.15", "pressure_kpa": "101", "raw_isotherm_points": 24, "interior_mixtures": 22, "pure_endpoints": 2, "fit_summary_n_points": 22}]

This resolves count interpretation only. It does not certify complete composition coverage by the selected interior inputs, endorse a fitted value, or preassign other outcomes. Fitted numerical outputs remain outside raw measurement scoring.

Supersedes: []. Superseded by: null.

## H72 — R-K fit population counts

For all Redlich–Kister fitting results, interpret point counts in context: total counts can include pure-component reference values, while mixture counts exclude them. Both populations can be correct or Near depending on wording and input provenance. The example 21=19+2 is not a universal count. Preserve the actual stored mixture n_points and show any explicit total-population derivation; do not automatically mark differing total/mixture counts Miss or unqualified mixture counts Near.

Exact clarification question: Main Q1.2.4 reports 21 points used in the fit; the saved artifacts contain 19 mixture points and 2 pure-component reference values. How should “21 points,” “19 mixture points,” and an unqualified “19 points” be scored?

Exact user reply: For all fitting results with R-K equation, 21 points include pure value, and 19 means excluding pure value (the data block), both can be correct or near miss depending on the context

Applicability: All R-K fitting results, using each answer actual wording, mixture subset and pure-reference inputs. Existing more-specific population interpretations such as H71 remain applicable.

Source context: [{"doi": "10.1016/j.jct.2018.02.022", "block": "PROPblock_24", "temperature_k": "298.15", "stored_mixture_n_points": 19, "pure_reference_values": 2, "total_population_derivation": "19 + 2 = 21", "numeric_source": "own answer eval/artifacts/analysis_runs/run_1/data/*fit_summ.csv and fitting_tool_calls_verbatim.md"}]

Interpretation of input population only, not a replacement for actual artifact inspection, source/state/unit/basis checks or numeric metric comparison.

H72 exact answer excerpts:

- Line22: `| **Data points** | 19 mixture compositions + 2 pure-component endpoints = 21 points |`
- Line100: `- The fit is based on 21 data points (19 mixture compositions plus 2 pure-component endpoints) from concentric cylinders viscometry measurements reported in DOI 10.1016/j.jct.2018.02.022.`

## H73 — Extrema represented by saved fitting curves

When a claimed extremum is represented by an eligible saved fitting plot but its position is absent from saved numerical tables and tool returns, the evaluator may calculate the position from the saved fit coefficients and score the claim using that saved curve as evidence. Explicit calculation provenance and checks that source precision supports the judgment are mandatory. Preserve the native artifact values separately; the calculated position is reviewer verification, not an original printed scalar.

Exact clarification question: Two reviews are held because an extremum is visible in a saved fitting plot but its position is not printed in the saved tables or tool outputs. May the evaluator calculate that position from the saved fit coefficients and score the claim using the saved curve as evidence, explicitly recording the calculation and checking whether the source precision supports the judgment?

Exact user reply: Yes—allow this with explicit provenance and precision checks

Applicability: Claims of extremum position represented by the answer own eligible saved fitting curve, with matching saved coefficients and original generating-call provenance; the coordinate is not printed as a native numerical output. Apply only after matching property, state, component axis, units, fitted basis and domain.

Required evidence:

- Eligible original saved plot and coefficient source, identified by file, hash and relevant field.
- Original generating tool arguments and fit/session identity, including source inputs, axis, state and fitted basis.
- Explicit reviewer calculation method, inputs, domain, axis transformation and resulting coordinate or interval, separate from native stored values.
- Source-precision assessment sufficient to support the reported comparison; no invented pixel or coefficient precision.

Answer contexts:

- Analysis Q5.3 (full_capability): What density should I expect for a liquid mixture containing one mole of ethanol per three moles of water at 310 K? Explain the measured evidence and correlation used for the prediction and give its applicable range.
  - Line 113: The large negative excess density (about −22 kg/m³ at this composition — computed from the RK formula — and up to −36.0 kg/m³ near x_ethanol ≈ 0.4–0.5 per the predict_from_rk output) reflects the well-known **volume contraction** in ethanol–water mixtures. Hydrogen-bonding reorganization between ethanol and water molecules allows more efficient molecular packing than in either pure liquid, producing a mixture denser than the mole-fraction-weighted average of the pure components.
  - Line 162: - The large negative excess density (approximately −22 kg/m³ at x(ethanol) = 0.25, and up to −36.0 kg/m³ near x(ethanol) ≈ 0.4–0.5) reflects volume contraction due to hydrogen-bonding reorganization in ethanol–water mixtures, making the mixture denser than the mole-fraction-weighted average of the pure components.
- Analysis Q5.4 (full_capability): Near 25 °C, at what composition does liquid DMSO + water depart most strongly from ideal mixing, and does the answer change when volume, enthalpy, viscosity, or another measured property is considered?
  - Line 24: | **Refractive index (excess)** | 10.1021/je7001013 / PROPblock_10 | 10 | 3 | 0.999858 | x(DMSO) ≈ 0.30–0.35 (from predict_from_rk) | +0.056 (from predict_from_rk) | ~4% of n_D (derived ratio) |
  - Line 37: - **Maximum |Vᴱ|:** −9.57 × 10⁻⁷ m³/mol near x(DMSO) ≈ 0.33 (from predict_from_rk output)
  - Line 59: - **Maximum |γᴱ|:** −0.0093 N/m near x(DMSO) ≈ 0.15–0.20 (from predict_from_rk output)
  - Line 70: - **Maximum |n_Dᴱ|:** +0.056 near x(DMSO) ≈ 0.30–0.35 (from predict_from_rk output)

Authorizes artifact-backed verification of represented extrema only. It does not authorize a new fit, replacement of missing curves with new computations, relabeling newly computed values as native saved outputs, automatic Exact outcomes, or disregard of incorrect source/state/unit/basis claims. Reported intervals and point claims retain their own meaning.

Supersedes: []. Superseded by: null.
