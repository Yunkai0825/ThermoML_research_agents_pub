# Scientific claim-verification method

This layer contains scientific claim judgments. It excludes whole-answer scores, workflow comparisons, timing, token use and cost. It is independent of numerical Exact/Near/Miss outcomes.

## Resolved categories

- **database_verified**: the claim matches original raw ThermoML records after checking the applicable system, property, phase, composition and basis, temperature, pressure, units, method and provenance.
- **domain_knowledge**: the claim is correct physical chemistry, a supported primary-literature fact, a valid conversion/calculation/interpolation, or an appropriately qualified physical interpretation. Derived values are not reclassified as original measurements.
- **incorrect**: the value, definition, scope, attribution, inference, or causal/proof claim is demonstrably wrong.

The categories are mutually exclusive. An absent citation alone is not an incorrect claim. A database match verifies faithful alignment with the stored record; it does not independently certify the experiment. Exclusion of calculation checking from the numerical layer does not establish that a scientific calculation claim is valid. Use actual supporting evidence or leave its consequential uncertainty unresolved.

## Claim units

A unit is a substantive scientific assertion or coupled experimental tuple, not each numeral. Repeated summaries, label-only headings, workflow text, confidence statements and deterministic ledger restatements are not counted again. Distinct numerical and interpretive assertions may be separated. Record the applied segmentation rule in the run contract and apply it consistently across all answers.

## Unresolved assertions and evidence

Assertions that cannot responsibly be assigned a resolved category remain under unresolved_claims, with exact excerpts, evidence and the open question. They are not a fourth category and are not part of the resolved-claim denominator. Do not force a category to complete a table.

Preserve exact source values and source locators. Record DOI:block:point where available; otherwise NA with its reason and the supporting literature or artifact reference. Record answer-byte identity and current evidence availability. A hash identifies bytes, not proof that a historical path remains accessible. Do not depend on another evaluation's decisions.

## Physical-chemistry safeguards

Distinguish mole fraction, mass fraction and molality; pure endpoints and mixture interiors; measured, derived and excess properties; mass-specific and molar heat capacities; mutual and tracer diffusion; measurement uncertainty and inter-paper scatter. Mechanistic plausibility does not establish a unique cause. An external database with different observables is not a substitute numerical alignment source. Inspect Analysis/Main solver artifacts only as linked supporting evidence, keeping derived outputs distinct from raw observations.
