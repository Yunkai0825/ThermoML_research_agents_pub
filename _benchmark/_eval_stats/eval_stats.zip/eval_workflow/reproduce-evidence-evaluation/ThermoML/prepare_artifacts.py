"""Prepare complete saved Analysis evidence before evaluation packet creation.

The archive contains original tool arguments/results and saved data/plots. Worker
packet builders separately apply blind-input rules; this file performs no scoring.
"""
from __future__ import annotations

import argparse
import importlib.util
import hashlib
import json
from pathlib import Path


def ensure_prepared(benchmark_root: Path, private_root: Path | None = None, *, apply: bool = True) -> dict:
    """Assemble every native session and return per-session provenance/gap records."""
    benchmark_root = Path(benchmark_root).resolve()
    private_root = Path(private_root).resolve() if private_root else (
        benchmark_root / "__obsolete__" / "eval_artifact_assembly")
    module_path = Path(__file__).resolve().parent / "tools" / "enrich_run_history.py"
    spec = importlib.util.spec_from_file_location("thermoml_run_history_archiver", module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    private_io = module.extended_path(private_root)
    prior_receipt = private_io / ("receipt_applied.json" if apply else "receipt_dry_run.json")
    if prior_receipt.is_file():
        prior = prior_receipt.read_bytes()
        saved = private_io / "receipts" / (hashlib.sha256(prior).hexdigest() + ".json")
        saved.parent.mkdir(parents=True, exist_ok=True)
        if saved.is_file() and saved.read_bytes() != prior:
            raise ValueError("Prior preparation receipt backup differs")
        if not saved.is_file():
            saved.write_bytes(prior)
    report = module.assemble_all(base=benchmark_root, private=private_root, apply=apply)
    report["stage"] = "before_evaluation"
    limitations = sum(len(record.get("visible_context_limitations", [])) for record in report.get("records", []))
    report["visible_context_limitations"] = limitations
    report["status"] = "SOURCE_GAPS" if report["gaps"] else (
        "COMPLETE_WITH_VISIBLE_LIMITS" if limitations else "COMPLETE")
    for record in report.get("records", []):
        record["status"] = "SOURCE_GAPS" if record.get("gaps") else (
            "COMPLETE_WITH_VISIBLE_LIMITS" if record.get("visible_context_limitations") else "COMPLETE")
    if report.get("receipt"):
        Path(report["receipt"]).write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--benchmark", type=Path, required=True,
                        help="benchmark root containing Analysis/ and Main/")
    parser.add_argument("--private", type=Path,
                        help="private backup/receipt directory; defaults to benchmark/__obsolete__/eval_artifact_assembly")
    parser.add_argument("--dry-run", action="store_true",
                        help="inspect recoverable sources and write only the private receipt")
    args = parser.parse_args(argv)
    report = ensure_prepared(args.benchmark, args.private, apply=not args.dry_run)
    print(json.dumps({key: report[key] for key in
                      ("status", "stage", "applied", "sessions", "steps", "gaps", "visible_context_limitations", "receipt")},
                     ensure_ascii=False, indent=2))
    for record in report.get("records", []):
        for gap in record.get("gaps", []):
            print(f"Source gap: {record['source']} | step {gap.get('step', 'NA')} | "
                  f"{gap['field']}: {gap['reason']}")
    return 0 if not report["gaps"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
