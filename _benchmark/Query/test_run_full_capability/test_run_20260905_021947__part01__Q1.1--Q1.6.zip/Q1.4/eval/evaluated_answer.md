# Q1.4 — Result

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

**[run statistics removed]**

---

## Answer

Yes — the ThermoML database contains **mean ionic activity coefficient (γ±)** measurements for the binary system **lithium chloride (LiCl) + water** at exactly **298.15 K (25 °C)** and **101.0 kPa**.

## Source

- **DOI:** 10.1016/j.fluid.2014.08.026
- **Method:** Calculated from EMF (electromotive force) cell potential measurements
- **Total data points:** 141

## Concentration Range

The dataset spans **LiCl molality from 0.0033 to 1.5555 mol/kg**, covering a wide range from very dilute to moderately concentrated solutions.

## Activity Coefficient Range

γ± values range from **0.7406 to 0.9425** across the 141 data points.

## Representative Data Points

**Dilute region:**

| Molality (mol/kg) | γ± |
|---|---|
| 0.0033 | 0.9425 |
| 0.0033 | 0.9398 |
| 0.0035 | 0.9388 |
| 0.004 | 0.935 |

**Concentrated region:**

| Molality (mol/kg) | γ± |
|---|---|
| 1.485 | 0.8424 |
| 1.5095 | 0.839 |
| 1.5483 | 0.845 |
| 1.5555 | 0.8461 |

## Chemistry Insight

The data exhibit the characteristic **non-monotonic (U-shaped) trend** expected for a strong 1:1 electrolyte like LiCl in water:

1. **Dilute limit:** γ± starts near unity (~0.94 at 0.003 mol/kg), consistent with Debye–Hückel theory predicting ideal behavior at infinite dilution.
2. **Intermediate molalities:** γ± decreases to a minimum of about **0.74**, driven by long-range electrostatic ion–ion interactions that lower the effective activity.
3. **Higher concentrations:** γ± rises again to ~0.85 near 1.5 mol/kg, reflecting the growing importance of short-range ion–solvent interactions (strong Li⁺ hydration) and ion-pairing effects that cause positive deviations from Debye–Hückel predictions.

This upturn at higher concentrations is especially pronounced for lithium salts because the small Li⁺ ion has a very high charge density and binds water molecules tightly, effectively reducing the amount of "free" solvent and increasing the effective salt concentration — and hence the activity coefficient. The EMF method used is a standard electrochemical technique well-suited for precise determination of mean ionic activity coefficients in electrolyte solutions.

### Core claims

- The ThermoML database contains mean ionic activity coefficient (γ±) measurements for the binary system LiCl + water at 298.15 K and 101.0 kPa, sourced from DOI 10.1016/j.fluid.2014.08.026, comprising 141 data points derived from EMF cell potential measurements.
- The dataset spans LiCl molality from 0.0033 to 1.5555 mol/kg, with γ± values ranging from 0.7406 to 0.9425.
- The data exhibit a non-monotonic (U-shaped) trend: γ± starts near unity in the dilute limit (~0.94 at 0.003 mol/kg), decreases to a minimum of about 0.74 at intermediate molalities due to long-range electrostatic ion–ion interactions, and rises again to ~0.85 near 1.5 mol/kg due to short-range ion–solvent interactions and strong Li⁺ hydration.

**Confidence:** medium

### Suggested follow-ups

- Compare LiCl activity coefficients with other alkali metal chlorides (NaCl, KCl) at 25 °C to examine the effect of cation size on the U-shaped γ± trend.
- Search for LiCl activity coefficient data at higher molalities (above 1.6 mol/kg) or at other temperatures to map the full concentration and temperature dependence.
- Look for osmotic coefficient data for aqueous LiCl near 25 °C to cross-validate the activity coefficient measurements via the Gibbs–Duhem relation.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
