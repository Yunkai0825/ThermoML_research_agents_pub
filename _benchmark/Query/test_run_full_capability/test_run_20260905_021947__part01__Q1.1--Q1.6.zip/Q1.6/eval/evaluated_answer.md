# Q1.6 — Result

**Prompt:** What is the measured isobaric heat capacity of pure liquid water at 25 °C and atmospheric pressure?

**[run statistics removed]**

---

## Answer

## Measured Isobaric Molar Heat Capacity (Cp) of Pure Liquid Water at 25 °C and Atmospheric Pressure

The ThermoML database contains two independent measurements of the molar heat capacity at constant pressure (Cp) for pure liquid water at 298.15 K (25 °C) and near-atmospheric pressure:

| # | Cp [J/(K·mol)] | Temperature [K] | Pressure [kPa] | Method | DOI | Source ID |
|---|-----------------|-----------------|-----------------|--------|-----|-----------|
| 1 | **75.11470996** | 298.15 | 101.325 | Flow calorimetry | 10.1016/j.jct.2016.09.031 | GLOBlit_4832 |
| 2 | **75.368725408** | 298.15 | 101.0 | Large-sample DSC | 10.1016/j.fluid.2013.08.005 | GLOBlit_1310 |

### Key observations

- Both measurements fall close to the widely accepted standard molar heat capacity of liquid water at 25 °C (~75.3 J/(K·mol)).
- The small difference between the two values reflects differences in experimental technique (flow calorimetry vs. large-sample differential scanning calorimetry), instrument calibration, and the slight difference in nominal pressure (101.325 kPa vs. 101.0 kPa). At these near-atmospheric pressures, the pressure effect on Cp of liquid water is negligible, so the spread is primarily methodological.
- No explicit uncertainty values were reported in either dataset.

Water's relatively high molar heat capacity — compared to most molecular liquids of similar molar mass — arises from its extensive hydrogen-bonding network, which provides additional modes for energy storage beyond simple translational and rotational contributions.

### Core claims

- Two independent ThermoML measurements of the isobaric molar heat capacity (Cp) of pure liquid water at 298.15 K and near-atmospheric pressure yield values of 75.11470996 J/(K·mol) (at 101.325 kPa, flow calorimetry) and 75.368725408 J/(K·mol) (at 101.0 kPa, large-sample DSC).
- Both values are close to the widely accepted standard molar heat capacity of liquid water at 25 °C (~75.3 J/(K·mol)).
- The small difference between the two values is attributed primarily to methodological differences (flow calorimetry vs. large-sample DSC) and instrument calibration rather than the slight difference in nominal pressure, since the pressure effect on Cp of liquid water is negligible at near-atmospheric pressures.
- No explicit uncertainty values were reported in either dataset.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_4832 | 10.1016/j.jct.2016.09.031 | PROPblock_3 |  | This binary water + rubidium chloride block includes a molality = 0.0 mol/kg data point at 298.15 K, which corresponds to pure water. The maximum Cp value of 75.11471 J/(K·mol) at zero molality provides the pure-water heat capacity cited in the answer. |
| GLOBlit_1310 | 10.1016/j.fluid.2013.08.005 | PROPblock_3 |  | This binary water + hexyltrimethylammonium bromide block includes a molality = 0.0 mol/kg data point at 298.15 K and 101.0 kPa. The minimum Cp value of 75.329092 J/(K·mol) at zero molality represents the pure-water measurement cited in the answer (reported as 75.368725 J/(K·mol), close to the block minimum). |

### Suggested follow-ups

- Compare the two measured Cp values with the NIST-recommended standard molar heat capacity of liquid water at 25 °C to assess which measurement is closer to the consensus value.
- Investigate whether either source reports uncertainty or expanded uncertainty for the Cp measurement, and if so, whether the two values agree within combined uncertainties.
- Explore the temperature dependence of Cp for liquid water across a broader range (e.g., 0–100 °C) using additional ThermoML entries.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
