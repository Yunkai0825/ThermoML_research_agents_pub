# Q1.1 — Result

**Prompt:** I am preparing an equimolar ethanol + water liquid mixture at 25 °C and atmospheric pressure. What experimental density should I expect?

**[run statistics removed]**

---

## Answer

## Experimental Density of Equimolar Ethanol + Water at 25 °C

For an equimolar (x(ethanol) ≈ 0.5) liquid mixture of ethanol and water at 298.15 K (25 °C) and near-atmospheric pressure, you should expect a mass density of approximately **859 kg/m³**.

Two independent experimental sources in the ThermoML database confirm this value:

### Source 1 — DOI: 10.1021/je060335h

Measured at 101.0 kPa (atmospheric pressure):

| x(ethanol) | T (K) | p (kPa) | ρ (kg/m³) |
|:----------:|:-----:|:-------:|:---------:|
| 0.49976    | 298.15 | 101.0   | **858.98** |

Neighbouring compositions at the same temperature and pressure show the composition sensitivity:

| x(ethanol) | ρ (kg/m³) |
|:----------:|:---------:|
| 0.47749    | 863.28    |
| 0.49976    | 858.98    |
| 0.54464    | 850.55    |

### Source 2 — DOI: 10.1016/j.jct.2018.02.022

Measured at 92.3 kPa (slightly below standard atmospheric):

| x(ethanol) | T (K) | p (kPa) | ρ (kg/m³) |
|:----------:|:-----:|:-------:|:---------:|
| 0.4989     | 298.15 | 92.3    | 860.04    |
| 0.5002     | 298.15 | 92.3    | **858.963** |

### Consensus

Both sources agree to within ≈ 0.02 kg/m³ at essentially the same composition:

- **858.98 kg/m³** at x = 0.49976, 101.0 kPa
- **858.963 kg/m³** at x = 0.5002, 92.3 kPa

The slight pressure difference (101.0 vs. 92.3 kPa) has negligible effect on liquid density, so these values are directly comparable.

### Chemical Insight

This measured density of ~859 kg/m³ is significantly lower than what simple ideal (linear) mixing of the pure components would predict. The ethanol–water system is well known for its **negative excess volume**: when ethanol and water are mixed, hydrogen-bonding reorganization causes the mixture to occupy more volume than the sum of the individual pure-liquid volumes. This volume expansion lowers the density below the ideal-mixing estimate.

The bracketing data also reveal that density changes steeply with composition in this region — roughly −4 to −5 kg/m³ for every 0.01 increase in ethanol mole fraction near x = 0.5 — so precise composition control matters if you need a tight density specification.

### Core claims

- The experimental mass density of an equimolar (x(ethanol) ≈ 0.5) liquid mixture of ethanol and water at 298.15 K and near-atmospheric pressure is approximately 859 kg/m³.
- Two independent ThermoML sources agree closely: 858.98 kg/m³ at x = 0.49976 and 101.0 kPa (DOI: 10.1021/je060335h), and 858.963 kg/m³ at x = 0.5002 and 92.3 kPa (DOI: 10.1016/j.jct.2018.02.022).
- The slight pressure difference (101.0 vs. 92.3 kPa) has negligible effect on liquid density, making the two measurements directly comparable.
- The ethanol–water system exhibits negative excess volume due to hydrogen-bonding reorganization, causing the measured density to be lower than an ideal (linear) mixing prediction.
- Near x(ethanol) = 0.5, density changes steeply with composition — roughly −4 to −5 kg/m³ for every 0.01 increase in ethanol mole fraction — so precise composition control is important for tight density specifications.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_9006 | 10.1021/je060335h | PROPblock_1 |  | This block contains mass density data for the binary ethanol + water system at 298.15 K and 101.0 kPa across the full mole-fraction range (0.0–1.0), with density spanning 785.22–999.7 kg/m³. It directly supports the reported value of 858.98 kg/m³ at x(ethanol) ≈ 0.49976 and the neighbouring-composition data quoted in the answer. |

### Suggested follow-ups

- Compare the excess molar volume of ethanol + water at x(ethanol) = 0.5 and 25 °C across available ThermoML sources.
- Investigate how the density of the equimolar ethanol + water mixture varies with temperature (e.g., 15–45 °C) at atmospheric pressure.
- Check whether ThermoML contains speed-of-sound or viscosity data for the same equimolar ethanol + water condition to complement the density measurement.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
