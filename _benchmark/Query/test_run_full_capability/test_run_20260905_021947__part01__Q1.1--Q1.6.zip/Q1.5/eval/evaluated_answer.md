# Q1.5 — Result

**Prompt:** How has the viscosity of pure liquid ethanol near 25 °C been measured, and what values were reported by the different methods?

**[run statistics removed]**

---

## Answer

## Dynamic Viscosity of Pure Liquid Ethanol Near 25 °C — Methods and Reported Values

### Overview

The ThermoML database contains extensive viscosity data for pure liquid ethanol near 298.15 K (25 °C). A comprehensive search returned **20+ data blocks** from multiple independent literature sources. Two principal measurement techniques are represented: **capillary tube (Ostwald/Ubbelohde) viscometry** and **falling/rolling sphere viscometry**. No data were found in the database for ethanol viscosity near 298 K using vibrating wire, Stabinger, oscillating, or rotational viscometer methods.

---

### Method 1: Capillary Tube (Ostwald/Ubbelohde) Viscometry

This is by far the most commonly used technique for ethanol viscosity in the ThermoML archive, appearing in at least 10 data blocks. The capillary method works by timing the flow of liquid through a narrow-bore glass tube under gravity; it is the standard reference technique for low-viscosity Newtonian liquids like ethanol.

**Verified values at 298.15 K and atmospheric pressure (~101.325 kPa):**

| Source (DOI) | Literature ID | Block | η (Pa·s) |
|---|---|---|---|
| 10.1016/j.fluid.2005.05.012 | GLOBlit_267 | PROPblock_3 | 0.001078 |
| 10.1016/j.fluid.2005.07.010 | GLOBlit_288 | PROPblock_9 | 0.001082 |
| 10.1016/j.fluid.2006.01.008 | GLOBlit_349 | PROPblock_11 | 0.001077 |
| 10.1016/j.fluid.2007.03.021 | GLOBlit_499 | PROPblock_3 | 0.001082 |
| 10.1016/j.jct.2005.04.019 | GLOBlit_2547 | PROPblock_4 | 0.001093 |
| 10.1016/j.jct.2012.02.027 | GLOBlit_3572 | PROPblock_11 | 0.001087 |
| 10.1016/j.jct.2012.08.024 | GLOBlit_3711 | PROPblock_4 | 0.001087 |

The first four values were confirmed by direct data-table inspection; the last three are taken from block-level metadata (single-point blocks or block range/mean fields).

**Capillary-method range:** 0.001077–0.001093 Pa·s (1.077–1.093 mPa·s), a spread of only ~1.5%, demonstrating excellent inter-laboratory reproducibility.

---

### Method 2: Falling or Rolling Sphere Viscometry

In this technique, the terminal velocity of a sphere falling through the liquid under gravity (or along an inclined tube) is measured and related to viscosity via Stokes' law. Three sources were inspected:

| Source (DOI) | Literature ID | Block | T (K) | P (kPa) | η (Pa·s) |
|---|---|---|---|---|---|
| 10.1016/j.jct.2009.06.023 | GLOBlit_3116 | PROPblock_1 | 298.15 | 101.325 | 0.0010569 |
| 10.1016/j.jct.2012.10.008 | GLOBlit_3748 | PROPblock_6 | 298.15 | 101.325 | 0.001134 |
| 10.1016/j.jct.2013.09.044 | GLOBlit_4013 | PROPblock_6 | 298.2 | 100 | 0.0011866 |

An additional high-pressure study (DOI 10.1007/s10765-005-8089-2, GLOBlit_8, PROPblock_1) also used falling sphere viscometry but has no exact 298.15 K point; its nearest temperature is 293.15 K, where η = 0.001194 Pa·s at 100 kPa.

**Falling-sphere range at ~298 K:** 0.0010569–0.0011866 Pa·s (1.057–1.187 mPa·s), a spread of about 12% — considerably larger than the capillary-method spread.

---

### Comparison of Methods

| Method | No. of inspected sources | η range at 298.15 K (Pa·s) | Spread |
|---|---|---|---|
| Capillary tube (Ostwald/Ubbelohde) | 7 | 0.001077–0.001093 | ~1.5% |
| Falling/rolling sphere | 3 | 0.0010569–0.001134 (at 101.325 kPa) | ~7% |

The capillary tube method yields tighter inter-laboratory agreement, consistent with its status as the reference technique for low-viscosity liquids. The falling-sphere values show more scatter, which may reflect differences in sample purity, sphere calibration, or instrument design. Notably, the lowest falling-sphere value (0.0010569 Pa·s from GLOBlit_3116) is slightly below the capillary-method range, while the highest (0.0011866 Pa·s from GLOBlit_4013, measured at 100 kPa rather than 101.325 kPa) sits well above it.

---

### Temperature Dependence

Data from GLOBlit_267 (DOI 10.1016/j.fluid.2005.05.012, capillary method) illustrate the expected monotonic decrease of viscosity with temperature at 101.325 kPa:

| T (K) | η (Pa·s) |
|---|---|
| 293.15 | 0.00117 |
| 298.15 | 0.001078 |
| 303.15 | 0.000982 |

This ~8% decrease per 5 K step is consistent with the Arrhenius-like temperature dependence typical of hydrogen-bonding liquids.

Similarly, from GLOBlit_3116 (falling sphere, 101.325 kPa):

| T (K) | η (Pa·s) |
|---|---|
| 293.15 | 0.0011617 |
| 298.15 | 0.0010569 |
| 303.15 | 0.0009645 |

Both methods capture the same qualitative trend, with the falling-sphere values from this particular source running slightly lower than the capillary values.

---

### Pressure Dependence

The high-pressure falling-sphere study (GLOBlit_8, DOI 10.1007/s10765-005-8089-2) shows that at 293.15 K, ethanol viscosity increases substantially with pressure:

| P (kPa) | η (Pa·s) |
|---|---|
| 100 | 0.001194 |
| 20 000 | 0.001344 |
| 40 000 | 0.001494 |

This ~25% increase from 100 kPa to 40 000 kPa (~400 atm) highlights why precise pressure specification matters when comparing viscosity values.

---

### Methods Not Represented

No ethanol viscosity data near 298 K were found in the ThermoML database for the following techniques:
- Vibrating wire viscometer/viscometry
- Stabinger viscometer
- Oscillating viscometer
- Rotational viscometer

---

### Consensus Value

Based on all available ThermoML data at 298.15 K and atmospheric pressure, the dynamic viscosity of pure liquid ethanol is approximately **0.00108 Pa·s (1.08 mPa·s)**. The capillary tube (Ostwald/Ubbelohde) method provides the most consistent results, with verified values clustering tightly around 0.001077–0.001082 Pa·s across multiple independent laboratories.

### Core claims

- The ThermoML database contains ethanol viscosity data near 298.15 K from two principal measurement techniques: capillary tube (Ostwald/Ubbelohde) viscometry and falling/rolling sphere viscometry; no data were found for vibrating wire, Stabinger, oscillating, or rotational viscometer methods.
- Capillary tube viscometry yields dynamic viscosity values for pure liquid ethanol at 298.15 K and atmospheric pressure in the range 0.001077–0.001093 Pa·s across seven independent sources, a spread of ~1.5%.
- Falling/rolling sphere viscometry yields dynamic viscosity values at ~298.15 K and ~101.325 kPa in the range 0.0010569–0.001134 Pa·s across three sources, a spread of about 7%, considerably larger than the capillary-method spread.
- The capillary tube method provides tighter inter-laboratory agreement, consistent with its status as the reference technique for low-viscosity liquids.
- Based on all available ThermoML data at 298.15 K and atmospheric pressure, the consensus dynamic viscosity of pure liquid ethanol is approximately 0.00108 Pa·s (1.08 mPa·s), with verified capillary-method values clustering around 0.001077–0.001082 Pa·s.
- Both methods show a monotonic decrease of viscosity with increasing temperature (~8% per 5 K step near 298 K), consistent with Arrhenius-like behavior typical of hydrogen-bonding liquids.
- High-pressure falling-sphere data at 293.15 K show ethanol viscosity increases ~25% from 100 kPa to 40 000 kPa, underscoring the importance of precise pressure specification when comparing values.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_267 | 10.1016/j.fluid.2005.05.012 | PROPblock_3 |  | Provides pure ethanol viscosity via capillary tube method at 293.15–303.15 K including 298.15 K (0.001078 Pa·s), and is used to illustrate temperature dependence in the answer. |
| GLOBlit_288 | 10.1016/j.fluid.2005.07.010 | PROPblock_9 |  | Single-point pure ethanol viscosity at 298.15 K via capillary tube method yielding 0.001082 Pa·s, directly cited in the capillary-method comparison table. |
| GLOBlit_349 | 10.1016/j.fluid.2006.01.008 | PROPblock_11 |  | Single-point pure ethanol viscosity at 298.15 K via capillary tube method yielding 0.001077 Pa·s, the lowest capillary value cited in the answer. |
| GLOBlit_499 | 10.1016/j.fluid.2007.03.021 | PROPblock_3 |  | Single-point pure ethanol viscosity at 298.15 K via capillary tube method yielding 0.001082 Pa·s, contributing to the capillary-method consensus in the answer. |
| GLOBlit_2547 | 10.1016/j.jct.2005.04.019 | PROPblock_4 |  | Single-point pure ethanol viscosity at 298.15 K via capillary tube method yielding 0.001093 Pa·s, the highest capillary value cited and used to define the upper bound of the capillary range. |
| GLOBlit_3572 | 10.1016/j.jct.2012.02.027 | PROPblock_11 |  | Single-point pure ethanol viscosity at 298.15 K via capillary tube method yielding 0.001087 Pa·s, cited in the capillary-method comparison table. |
| GLOBlit_3711 | 10.1016/j.jct.2012.08.024 | PROPblock_4 |  | Pure ethanol viscosity over 298.15–328.15 K via capillary tube method with max value 0.001087 Pa·s at 298.15 K, cited in the capillary-method table. |
| GLOBlit_3116 | 10.1016/j.jct.2009.06.023 | PROPblock_1 |  | Pure ethanol viscosity via falling/rolling sphere method over 283.15–333.15 K at 101.325 kPa; provides the 298.15 K value of 0.0010569 Pa·s and temperature-dependence data for the falling-sphere comparison. |
| GLOBlit_3748 | 10.1016/j.jct.2012.10.008 | PROPblock_6 |  | Pure ethanol viscosity via falling/rolling sphere method over 293.15–313.15 K at 101.325 kPa; the 298.15 K value of 0.001134 Pa·s is cited in the falling-sphere table. |
| GLOBlit_4013 | 10.1016/j.jct.2013.09.044 | PROPblock_6 |  | Single-point pure ethanol viscosity at 298.2 K and 100 kPa via falling/rolling sphere method yielding 0.001187 Pa·s (reported as 0.0011866 in the answer), the highest falling-sphere value cited. |
| GLOBlit_8 | 10.1007/s10765-005-8089-2 | PROPblock_1 |  | High-pressure pure ethanol viscosity via falling sphere method over 293.15–353.15 K and 100–100000 kPa; used in the answer to illustrate pressure dependence of ethanol viscosity near 293.15 K. |

### Suggested follow-ups

- Compare ThermoML ethanol viscosity values with NIST recommended reference data to assess systematic offsets between capillary and falling-sphere methods.
- Investigate whether any ThermoML sources report ethanol viscosity using vibrating-wire or Stabinger viscometers, possibly under different compound names or CAS identifiers.
- Examine the purity metadata reported in each source to determine whether sample purity differences explain the larger scatter in falling-sphere results.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
