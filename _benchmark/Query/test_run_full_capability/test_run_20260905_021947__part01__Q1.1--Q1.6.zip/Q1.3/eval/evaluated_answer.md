# Q1.3 — Result

**Prompt:** What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

**[run statistics removed]**

---

## Answer

## Mass Density of Equimolar Propan-2-ol + Water at 25 °C and Atmospheric Pressure

The mass density of a binary liquid mixture of propan-2-ol (isopropanol) and water has been measured at 298.15 K (25 °C) and 101.0 kPa (atmospheric pressure) across the full mole-fraction range by Soliman and Marschall (DOI: 10.1021/je700700f, GLOBlit_11042).

### Data Near the Equimolar Composition

There is no data point at exactly x(propan-2-ol) = 0.5000, but the nearest measured composition is very close. The three points bracketing the equimolar composition are:

| Mole fraction of propan-2-ol | Temperature (K) | Pressure (kPa) | Mass density (kg/m³) |
|:---:|:---:|:---:|:---:|
| 0.3992 | 298.15 | 101.0 | 857.7 |
| **0.4981** | **298.15** | **101.0** | **838.8** |
| 0.5979 | 298.15 | 101.0 | 823.5 |

**At the nearest-to-equimolar composition of x(propan-2-ol) = 0.4981, the mass density is 838.8 kg/m³** at 298.15 K and 101.0 kPa.

### Chemical Context

- The density decreases monotonically with increasing propan-2-ol mole fraction, from 997.2 kg/m³ for pure water down to 780.7 kg/m³ for pure propan-2-ol at 298.15 K.
- At the near-equimolar composition, the density (838.8 kg/m³) is notably closer to that of pure propan-2-ol (780.7 kg/m³) than to pure water (997.2 kg/m³). This reflects the significant contribution of the lighter, bulkier alcohol molecules to the mixture volume.
- The propan-2-ol + water system is well known for exhibiting **negative excess volumes** (volume contraction on mixing), particularly in the water-rich region, due to strong hydrogen-bonding interactions between propan-2-ol and water molecules.

**Source:** DOI 10.1021/je700700f (GLOBlit_11042, PROPblock_17) — 13 data points covering x(propan-2-ol) = 0 to 1 at 298.15 K and 101.0 kPa.

### Core claims

- At the nearest-to-equimolar composition of x(propan-2-ol) = 0.4981, the mass density of the propan-2-ol + water binary mixture is 838.8 kg/m³ at 298.15 K and 101.0 kPa, as reported by Soliman and Marschall (DOI: 10.1021/je700700f).
- The density of the propan-2-ol + water mixture decreases monotonically with increasing propan-2-ol mole fraction, from 997.2 kg/m³ for pure water to 780.7 kg/m³ for pure propan-2-ol at 298.15 K.
- No data point exists at exactly x(propan-2-ol) = 0.5000; the reported value is for the nearest measured composition of 0.4981.
- The propan-2-ol + water system is known to exhibit negative excess volumes (volume contraction on mixing), particularly in the water-rich region, due to hydrogen-bonding interactions.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11042 | 10.1021/je700700f | PROPblock_17 |  | This block provides mass density of the propan-2-ol + water binary system at 298.15 K and 101.0 kPa across 13 compositions (mole fraction 0–1), with density ranging from 780.7 to 997.2 kg/m³. The answer reports the near-equimolar point (x = 0.4981, ρ = 838.8 kg/m³) directly from this block. |

### Suggested follow-ups

- Compare with excess molar volume data for propan-2-ol + water at 25 °C to quantify the volume contraction on mixing.
- Examine temperature dependence of density for the equimolar propan-2-ol + water mixture using additional ThermoML sources.
- Look up density data from other literature sources for the same system to assess inter-laboratory agreement.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
