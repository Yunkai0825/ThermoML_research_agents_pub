1. Any longer-chain alcohol absence in primary alcohol chain discussion: saturated straight-chain series versus all larger alcohols.

   **Your reply:** Use the saturated straight-chain primary alcohol series
