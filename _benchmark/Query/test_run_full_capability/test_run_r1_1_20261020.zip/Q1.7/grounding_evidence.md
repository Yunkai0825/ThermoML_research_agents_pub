# Data grounding evidence

- generated: 2026-10-20T17:36:23
- gate verdict: 46 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | GLOBlit_3156 | yes | INSP_fac9735b726d, INSP_c13b558c06b1, INSP_bcddf7c7879f | 15 |
| PROPblock_2 | GLOBlit_3156 | yes | INSP_77112895df57, INSP_7d5a1a94edf0, INSP_f04912524dfd, INSP_595f738775d2 | 15 |
| PROPblock_22 | GLOBlit_9491 | yes | INSP_aaacf68bc4fe | 1 |
| PROPblock_4 | GLOBlit_572 | yes | INSP_0a71d523804a, INSP_0a4afe16876e | 20 |
| PROPblock_5 | GLOBlit_11673 | yes | INSP_725e2d6bb6bc | 1 |
| PROPblock_6 | GLOBlit_3600 | yes | INSP_119f4ecb69e0 | 6 |
| PROPblock_7 | GLOBlit_9790 | yes | INSP_8e064cd3160a | 9 |
| PROPblock_9 | GLOBlit_3588 | yes | INSP_89d8e4cf160c | 6 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 298 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0436 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0013 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 298.15 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04533 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0003 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 298.48 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04426 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0001 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 298.5 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04441 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00059 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 298 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04544 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00049 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 293.15 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04461 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00064 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 293.2 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0448 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.001 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 298.15 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04452 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00046 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 298.15 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0446 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00084 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 297 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0469 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0009 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 298.15 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04437 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00064 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 298.15 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0447 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0004 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 13 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | ungrounded | — |
| 293.65 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0446 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0013 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 14 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | ungrounded | — |
| 293.15 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04428 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00079 | PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5 | verified | — |
| 13 | PROPblock_5 | ungrounded | — |
| 14 | PROPblock_5 | ungrounded | — |
| 298.15 | PROPblock_5 | ambiguous | 4 sources |
| 293 | PROPblock_5 | verified | — |
| 294 | PROPblock_5 | misattributed | PROPblock_2 |
| 298.15 | PROPblock_5 | ambiguous | 4 sources |
| 0.0469 | PROPblock_5 | misattributed | PROPblock_22 |
| 0.0009 | PROPblock_5 | misattributed | PROPblock_22 |
| 0.0460 | PROPblock_5 | ungrounded | — |
| 0.0478 | PROPblock_5 | ungrounded | — |
| 297 | PROPblock_5 | misattributed | PROPblock_22 |
| 13 | PROPblock_5 | ungrounded | — |
| 0.04533 | PROPblock_5 | misattributed | PROPblock_4 |
| 0.0003 | PROPblock_5 | verified | — |
| 0.04503 | PROPblock_5 | ungrounded | — |
| 0.04563 | PROPblock_5 | ungrounded | — |
| 0.04544 | PROPblock_5 | ambiguous | 2 sources |
| 0.00049 | PROPblock_5 | misattributed | PROPblock_9 |
| 0.04495 | PROPblock_5 | ungrounded | — |
| 0.04593 | PROPblock_5 | ungrounded | — |
| 0.04426 | PROPblock_5 | verified | — |
| 0.0001 | PROPblock_5 | misattributed | PROPblock_1 |
| 0.04416 | PROPblock_5 | ungrounded | — |
| 0.04436 | PROPblock_5 | ungrounded | — |
| 0.7 | PROPblock_5 | misattributed | PROPblock_6 |
| 0.0436 | PROPblock_5 | ambiguous | 3 sources |
| 0.0013 | PROPblock_5 | ambiguous | 2 sources |
| 0.0423 | PROPblock_5 | misattributed | PROPblock_4 |
| 0.0449 | PROPblock_5 | ungrounded | — |
| 0.04495 | PROPblock_5 | ungrounded | — |
| 14 | PROPblock_5 | ungrounded | — |
| 0.04426 | PROPblock_5 | verified | — |
| 0.04480 | PROPblock_5 | misattributed | PROPblock_1 |
| 14 | PROPblock_5 | ungrounded | — |
| 0.04426 | PROPblock_5 | verified | — |
| 0.04480 | PROPblock_5 | misattributed | PROPblock_1 |
| 0.04533 | PROPblock_5 | misattributed | PROPblock_4 |
| 0.04544 | PROPblock_5 | ambiguous | 2 sources |
| 0.0469 | PROPblock_5 | misattributed | PROPblock_22 |
| 0.0436 | PROPblock_5 | ambiguous | 3 sources |
| 3.3 | PROPblock_5 | ungrounded | — |
| 0.0436 | PROPblock_5 | ambiguous | 3 sources |
| 0.0469 | PROPblock_5 | misattributed | PROPblock_22 |
| 14 | PROPblock_5 | ungrounded | — |
| 44.3 | PROPblock_5 | verified | — |
| 44.8 | PROPblock_5 | misattributed | PROPblock_1 |
| 298.15 | PROPblock_5 | ambiguous | 4 sources |
| 45.3 | PROPblock_5 | ambiguous | 2 sources |
| 45.4 | PROPblock_5 | ambiguous | 3 sources |
| 46.9 | PROPblock_5 | misattributed | PROPblock_22 |

## Violations

- **UNGROUNDED_LITERAL** PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5: 13 (near '…|   | 298.15 | 0.0447 | 0.0004 | Max. bubble pressure | | 13…') matches no inspected row/stat, database table, or other source of PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5: 14 (near '…|   |   | 293.65 | 0.0446 | 0.0013 | Ring tensiometer | | 14…') matches no inspected row/stat, database table, or other source of PROPblock_4 + PROPblock_1 + PROPblock_2 + PROPblock_9 + PROPblock_6 + PROPblock_22 + PROPblock_7 + PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 13 (near '…*Notes:* Entries 6, 7, 13, and 14 are the nearest available …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 14 (near '…*Notes:* Entries 6, 7, 13, and 14 are the nearest available …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **AMBIGUOUS_VALUE** PROPblock_5: 298.15 matches 4 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 294 does not belong to PROPblock_5; it matches only GLOBlit_3156::PROPblock_2 (inspected this run)
- **AMBIGUOUS_VALUE** PROPblock_5: 298.15 matches 4 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.0469 does not belong to PROPblock_5; it matches only GLOBlit_9491::PROPblock_22 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.0009 does not belong to PROPblock_5; it matches only GLOBlit_9491::PROPblock_22 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 0.0460 (near '…utlier —   (#10):** The value 0.0469 ± 0.0009 N/m (interval …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 0.0478 (near '…—   (#10):** The value 0.0469 ± 0.0009 N/m (interval 0.0460–…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 297 does not belong to PROPblock_5; it matches only GLOBlit_9491::PROPblock_22 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 13 (near '…uncertainty interval does not overlap with any of the other …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.04533 does not belong to PROPblock_5; it matches only GLOBlit_572::PROPblock_4 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 0.04503 (near '…) and   (#5):** These report 0.04533 ± 0.0003 N/m (interval …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 0.04563 (near '…(#5):** These report 0.04533 ± 0.0003 N/m (interval 0.04503–…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **AMBIGUOUS_VALUE** PROPblock_5: 0.04544 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.00049 does not belong to PROPblock_5; it matches only GLOBlit_3588::PROPblock_9 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 0.04495 (near '…terval 0.04503–0.04563) and 0.04544 ± 0.00049 N/m (interval …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 0.04593 (near '….04503–0.04563) and 0.04544 ± 0.00049 N/m (interval 0.04495–…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.0001 does not belong to PROPblock_5; it matches only GLOBlit_3156::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 0.04416 (near '…block 1 (#3), which gives 0.04426 ± 0.0001 N/m (interval 0.0…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 0.04436 (near '…1 (#3), which gives 0.04426 ± 0.0001 N/m (interval 0.04416–0…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.7 does not belong to PROPblock_5; it matches only GLOBlit_3600::PROPblock_6 (inspected this run)
- **AMBIGUOUS_VALUE** PROPblock_5: 0.0436 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** PROPblock_5: 0.0013 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.0423 does not belong to PROPblock_5; it matches only GLOBlit_572::PROPblock_4 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 0.0449 (near '…e value —   (#1):** At 0.0436 ± 0.0013 N/m (interval 0.0423–…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 0.04495 (near '…luster, but it does **not** overlap with #5 ( , lower bound …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 14 (near '…5) or #10 ( ).  4. **Central cluster (entries 3, 4, 6–9, 11–…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.04480 does not belong to PROPblock_5; it matches only GLOBlit_3156::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 14 (near '…nsistent? | |---|---|---| | Central cluster (#3, 4, 6–9, 11–…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.04480 does not belong to PROPblock_5; it matches only GLOBlit_3156::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.04533 does not belong to PROPblock_5; it matches only GLOBlit_572::PROPblock_4 (inspected this run)
- **AMBIGUOUS_VALUE** PROPblock_5: 0.04544 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.0469 does not belong to PROPblock_5; it matches only GLOBlit_9491::PROPblock_22 (inspected this run)
- **AMBIGUOUS_VALUE** PROPblock_5: 0.0436 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** PROPblock_5: 3.3 (near '…### Chemistry Insight  The ~3.3 mN/m total spread (from 0.04…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **AMBIGUOUS_VALUE** PROPblock_5: 0.0436 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.0469 does not belong to PROPblock_5; it matches only GLOBlit_9491::PROPblock_22 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 14 (near '…e ~3.3 mN/m total spread (from 0.0436 to 0.0469 N/m) across …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 44.8 does not belong to PROPblock_5; it matches only GLOBlit_3156::PROPblock_1 (inspected this run)
- **AMBIGUOUS_VALUE** PROPblock_5: 298.15 matches 4 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** PROPblock_5: 45.3 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** PROPblock_5: 45.4 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 46.9 does not belong to PROPblock_5; it matches only GLOBlit_9491::PROPblock_22 (inspected this run)

## Inspections (verbatim)

### INSP_0a71d523804a — GLOBlit_572::PROPblock_4 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_0a4afe16876e — GLOBlit_725::PROPblock_4 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_fac9735b726d — GLOBlit_3156::PROPblock_1 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_77112895df57 — GLOBlit_3156::PROPblock_2 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_89d8e4cf160c — GLOBlit_3588::PROPblock_9 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_119f4ecb69e0 — GLOBlit_3600::PROPblock_6 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_c13b558c06b1 — GLOBlit_4058::PROPblock_1 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_bcddf7c7879f — GLOBlit_5419::PROPblock_1 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_7d5a1a94edf0 — GLOBlit_6476::PROPblock_2 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_aaacf68bc4fe — GLOBlit_9491::PROPblock_22 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_f04912524dfd — GLOBlit_9568::PROPblock_2 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_8e064cd3160a — GLOBlit_9790::PROPblock_7 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_595f738775d2 — GLOBlit_11369::PROPblock_2 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_725e2d6bb6bc — GLOBlit_11673::PROPblock_5 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_
