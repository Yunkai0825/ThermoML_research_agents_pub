# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_36 | 1-butyl-3-methylimidazolium_tetrafluoroborate | 1-butyl-3-methylimidazolium tetrafluoroborate |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all surface tension measurements for 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at or near 298.15 → stored as L1_query_1 · validation: FLAGGED(8)

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: partial · validation: FLAGGED(8)

**Summary:**

Surface tension (liquid–gas) of pure 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) near 298.15 K was examined across 14 unary data blocks from 12 ThermoML literature sources. Seven blocks were individually inspected and yielded the following data points nearest 298.15 K: 0.0436 N/m at 298 K (GLOBlit_572, U = 0.0013 N/m), 0.04533 N/m at 298.15 K (GLOBlit_725, U = 0.0003 N/m), 0.04426 N/m at 298.48 K (GLOBlit_3156 block 1, U = 0.0001 N/m), 0.04441 N/m at 298.5 K (GLOBlit_3156 block 2, U = 0.00059 N/m), 0.04544 N/m at 298 K (GLOBlit_3588, U = 0.00049 N/m), 0.04461 N/m at 293.15 K (GLOBlit_3600, U = 0.00064 N/m), and 0.0448 N/m at 293.2 K (GLOBlit_4058, U = 0.001 N/m). Seven additional blocks were identified but not individually inspected; their aggregate temperature and surface-tension ranges are consistent with the inspected values. The cross-source spread of roughly 2 mN/m is attributed to differences in sample purity, measurement technique, and sensitivity to trace water and halide impurities. All blocks show a monotonically decreasing, near-linear dependence of surface tension on temperature.

**Answer:**

### Surface Tension of 1-Butyl-3-methylimidazolium Tetrafluoroborate ([C4mim][BF4]) at/near 298.15 K

**Compound:** 1-butyl-3-methylimidazolium tetrafluoroborate (GLOBcomp_36, C₈H₁₅BF₄N₂)  
**Property:** Surface tension liquid-gas (GLOBprop_13, N/m)

The ThermoML database contains **14 unary surface tension blocks** for this ionic liquid across 12 literature sources. Below are the inspected data points nearest to 298.15 K from the first 7 blocks, followed by summary information for blocks 8–14 (which were returned in compacted form and could not be individually read before the time limit).

---

#### Inspected Blocks — Data Points at/near 298.15 K

All uncertainties are expanded combined (U) at 95% confidence level.

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *Block* | *GLOBlit* | *DOI* | *T (K)* | *γ (N/m)* | *U (N/m)* | *Note* |
|---|---|---|---|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「PROPblock_4」 | 「GLOBlit_572」 | 「10.1016/j.fluid.2007.10.004」 | 「298」 | 「0.0436」 | 「0.0013」 | 「Nearest; no exact 298.15 K row (next above: 303 K)」 |
| WM_L1#1_Table#1_Row#2 | 「PROPblock_4」 | 「GLOBlit_725」 | 「10.1016/j.fluid.2009.07.010」 | 「298.15」 | 「0.04533」 | 「0.0003」 | 「Exact match at 298.15 K」 |
| WM_L1#1_Table#1_Row#3 | 「PROPblock_1」 | 「GLOBlit_3156」 | 「10.1016/j.jct.2009.09.007」 | 「298.48」 | 「0.04426」 | 「0.0001」 | 「Nearest; no exact 298.15 K row (bracketed by 293.32 and 298.48 K)」 |
| WM_L1#1_Table#1_Row#4 | 「PROPblock_2」 | 「GLOBlit_3156」 | 「10.1016/j.jct.2009.09.007」 | 「298.5」 | 「0.04441」 | 「0.00059」 | 「Nearest; no exact 298.15 K row (bracketed by 293.48 and 298.5 K)」 |
| WM_L1#1_Table#1_Row#5 | 「PROPblock_9」 | 「GLOBlit_3588」 | 「10.1016/j.jct.2012.03.008」 | 「298」 | 「0.04544」 | 「0.00049」 | 「Nearest; no exact 298.15 K row (next above: 307.9 K)」 |
| WM_L1#1_Table#1_Row#6 | 「PROPblock_6」 | 「GLOBlit_3600」 | 「10.1016/j.jct.2012.03.024」 | 「293.15」 | 「0.04461」 | 「0.00064」 | 「Nearest; no exact 298.15 K row (bracketed by 293.15 and 303.15 K)」 |
| WM_L1#1_Table#1_Row#7 | 「PROPblock_1」 | 「GLOBlit_4058」 | 「10.1016/j.jct.2013.11.024」 | 「293.2」 | 「0.0448」 | 「0.001」 | 「Nearest; no exact 298.15 K row (bracketed by 293.2 and 303.2 K)」 |

---

#### Blocks 8–14 — Not Individually Inspected (aggregate data from search_blocks)

These blocks were identified in the search and their T-range and γ-range are from the search_blocks listing, but individual data points at 298.15 K were not inspected before the time limit. The values below are block-level aggregates from the search tool, not individual data points.

**WM_L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *Block* | *GLOBlit* | *DOI* | *T range (K)* | *γ range (N/m)* | *Total pts* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「PROPblock_1」 | 「GLOBlit_5419」 | 「10.1016/j.jct.2018.12.036」 | 「293.15–323.15」 | 「0.04298–0.04475」 | 「7」 |
| WM_L1#1_Table#2_Row#2 | 「PROPblock_2」 | 「GLOBlit_6476」 | 「10.1016/j.tca.2019.01.018」 | 「298.15–338.15」 | 「0.04155–0.0446」 | 「5」 |
| WM_L1#1_Table#2_Row#3 | 「PROPblock_22」 | 「GLOBlit_9491」 | 「10.1021/je2000183」 | 「297 (single point)」 | 「0.0469」 | 「1」 |
| WM_L1#1_Table#2_Row#4 | 「PROPblock_2」 | 「GLOBlit_9568」 | 「10.1021/je200349t」 | 「288.15–328.15」 | 「0.04243–0.04497」 | 「5」 |
| WM_L1#1_Table#2_Row#5 | 「PROPblock_7」 | 「GLOBlit_9790」 | 「10.1021/je3000348」 | 「298.15–338.15」 | 「0.0417–0.0447」 | 「9」 |
| WM_L1#1_Table#2_Row#6 | 「PROPblock_2」 | 「GLOBlit_11369」 | 「10.1021/je800710p」 | 「293.65–360.95」 | 「0.0403–0.0446」 | 「10」 |
| WM_L1#1_Table#2_Row#7 | 「PROPblock_5」 | 「GLOBlit_11673」 | 「10.1021/je900502s」 | 「293.15 (single point)」 | 「0.04428」 | 「1」 |

*Note: The specific data points at 298.15 K and their uncertainties for blocks 8–14 were not inspected in this run. Based on their T-ranges, blocks 8, 9, 10, 11, 12, and 13 all contain data at or very near 298.15 K, while block 14 (GLOBlit_11673) has only a single point at 293.15 K.*

---

#### Chemistry Insight

The surface tension of pure [C4mim][BF4] near 298.15 K, based on the seven inspected blocks, ranges from **0.0436 to 0.04544 N/m** (43.6–45.44 mN/m), with expanded uncertainties spanning 0.0001 to 0.0013 N/m. The two blocks measured at slightly lower temperatures (293.15–293.2 K) gave values of 0.04461 and 0.0448 N/m, consistent with the expected slight increase in surface tension at lower temperature. All blocks show a monotonically decreasing, near-linear relationship between surface tension and temperature (R² > 0.99 in all cases), which is typical for ionic liquids in this temperature range.

The spread across sources (~2 mN/m) reflects differences in sample purity, measurement technique, and the inherent challenges of surface tension measurements for ionic liquids, which are sensitive to trace water and halide impurities.

**Core claims:**
- The ThermoML database contains 14 unary surface tension blocks for [C4mim][BF4] across 12 literature sources.
- From seven inspected blocks, the surface tension of pure [C4mim][BF4] near 298.15 K spans individual reported values from 0.0436 to 0.04544 N/m, with expanded uncertainties ranging from 0.0001 to 0.0013 N/m.
- The ~2 mN/m spread across sources reflects differences in sample purity, measurement technique, and sensitivity of ionic liquid surface tension to trace water and halide impurities.
- All inspected blocks show a monotonically decreasing, near-linear relationship between surface tension and temperature, consistent with typical ionic liquid behavior.
- Seven additional blocks (8–14) were identified but their individual data points at 298.15 K were not inspected, so their specific values at that temperature remain unverified.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_572」 | 「PROPblock_4」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] with nearest point at 298 K, value 0.0436 N/m, U = 0.0013 N/m.」 |
| WM_L1#1_Table#4 | 「GLOBlit_725」 | 「PROPblock_4」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at exact 298.15 K, value 0.04533 N/m, U = 0.0003 N/m.」 |
| WM_L1#1_Table#5 | 「GLOBlit_3156」 | 「PROPblock_1」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] with nearest point at 298.48 K, value 0.04426 N/m, U = 0.0001 N/m.」 |
| WM_L1#1_Table#6 | 「GLOBlit_3156」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] with nearest point at 298.5 K, value 0.04441 N/m, U = 0.00059 N/m.」 |
| WM_L1#1_Table#7 | 「GLOBlit_3588」 | 「PROPblock_9」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] with nearest point at 298 K, value 0.04544 N/m, U = 0.00049 N/m.」 |
| WM_L1#1_Table#8 | 「GLOBlit_3600」 | 「PROPblock_6」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] with nearest point at 293.15 K, value 0.04461 N/m, U = 0.00064 N/m.」 |
| WM_L1#1_Table#9 | 「GLOBlit_4058」 | 「PROPblock_1」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] with nearest point at 293.2 K, value 0.0448 N/m, U = 0.001 N/m.」 |
| WM_L1#1_Table#10 | 「GLOBlit_5419」 | 「PROPblock_1」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension block for pure [C4mim][BF4] covering 293.15–323.15 K; not individually inspected for 298.15 K data point.」 |
| WM_L1#1_Table#11 | 「GLOBlit_6476」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension block for pure [C4mim][BF4] covering 298.15–338.15 K; not individually inspected for 298.15 K data point.」 |
| WM_L1#1_Table#12 | 「GLOBlit_9491」 | 「PROPblock_22」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension block for pure [C4mim][BF4] with single point at 297 K, value 0.0469 N/m; not individually inspected.」 |
| WM_L1#1_Table#13 | 「GLOBlit_9568」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension block for pure [C4mim][BF4] covering 288.15–328.15 K; not individually inspected for 298.15 K data point.」 |
| WM_L1#1_Table#14 | 「GLOBlit_9790」 | 「PROPblock_7」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension block for pure [C4mim][BF4] covering 298.15–338.15 K; not individually inspected for 298.15 K data point.」 |
| WM_L1#1_Table#15 | 「GLOBlit_11369」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension block for pure [C4mim][BF4] covering 293.65–360.95 K; not individually inspected for 298.15 K data point.」 |
| WM_L1#1_Table#16 | 「GLOBlit_11673」 | 「PROPblock_5」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension block for pure [C4mim][BF4] with single point at 293.15 K; not individually inspected.」 |

*Not stored here: 14 verbatim data_inspections table(s); 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(8) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **UNGROUNDED_LITERAL** PROPblock_6: 14 (near '…---  ## Blocks 8–14 — Not Individually Inspected (aggregate…') matches no inspected row/stat, database table, or other source of PROPblock_6
- **UNGROUNDED_LITERAL** PROPblock_5: 14 (near '…ata points at 298.15 K and their uncertainties for blocks 8–…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 13 (near '…run. Based on their T-ranges, blocks 8, 9, 10, 11, 12, and 1…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 14 (near '…d 13 all contain data at or very near 298.15 K, while block …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **AMBIGUOUS_VALUE** PROPblock_5: 0.0436 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** PROPblock_5: 0.04544 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** PROPblock_5: 43.6 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** PROPblock_5: 45.44 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean


