# Reference Stats — query-agent

**Run started:** 2026-10-20 17:30:06
**Wall time (at last flush):** 414.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 29,181 | 70,700 | 18,170 | 99,881 | 19,976 | 109.3 | claudeopus46 |
| L1-worker | 25 | 370,540 | 359,520 | 43,244 | 730,060 | 29,202 | 290.3 | claudeopus46 |
| **TOTAL** | **30** | **399,721** | **430,220** | **61,414** | **829,941** | **27,664** | **399.6** | |

**Estimated tokens:** ~207,485 input + ~15,353 output = ~222,838 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **5** | **5** | **4** | **0** | **52** | **56** | **420** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_36 |  | resolve_compound_ids, search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_13 |  | resolve_property_ids, search_blocks |

#### References (13 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_572 |  | search_blocks |
| GLOBlit_725 |  | search_blocks |
| GLOBlit_3156 |  | search_blocks |
| GLOBlit_3588 |  | search_blocks |
| GLOBlit_3600 |  | search_blocks |
| GLOBlit_4058 |  | search_blocks |
| GLOBlit_5419 |  | search_blocks |
| GLOBlit_6476 |  | search_blocks |
| GLOBlit_9491 |  | search_blocks |
| GLOBlit_9568 |  | search_blocks |
| GLOBlit_9790 |  | search_blocks |
| GLOBlit_11369 |  | search_blocks |
| GLOBlit_11673 |  | search_blocks |

#### Measurements (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_58 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_32 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_192 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_19 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_22 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_1015 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_312 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_36 | Surface tension liquid-gas, N/m | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 1 |
| Unique References | 13 |
| Unique Measurements | 8 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Total DOIs | 13 |
| Unique parent blocks | 14 |
| Explicit block/subsystem targets | 14 |
| Subsystem targets | 0 |
| Target-matched data points | 420 |

---

## 3. DOI & Block References

**Unique DOIs:** 13  |  **Parent blocks:** 14  |  **Explicit targets:** 14  |  **Subsystems:** 0  |  **Target-matched datapoints:** 105

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2007.10.004 | 1 | 20 | unary | search_blocks |
| 10.1016/j.fluid.2009.07.010 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2009.09.007 | 2 | 30 | unary | search_blocks |
| 10.1016/j.jct.2012.03.008 | 1 | 6 | unary | search_blocks |
| 10.1016/j.jct.2012.03.024 | 1 | 6 | unary | search_blocks |
| 10.1016/j.jct.2013.11.024 | 1 | 4 | unary | search_blocks |
| 10.1016/j.jct.2018.12.036 | 1 | 7 | unary | search_blocks |
| 10.1016/j.tca.2019.01.018 | 1 | 5 | unary | search_blocks |
| 10.1021/je2000183 | 1 | 1 | unary | search_blocks |
| 10.1021/je200349t | 1 | 5 | unary | search_blocks |
| 10.1021/je3000348 | 1 | 9 | unary | search_blocks |
| 10.1021/je800710p | 1 | 10 | unary | search_blocks |
| 10.1021/je900502s | 1 | 1 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2007.10.004 | PROPblock_4 | declared | 20 | unary | — | search_blocks |
| 10.1016/j.fluid.2009.07.010 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2009.09.007 | PROPblock_1 | declared | 15 | unary | — | search_blocks |
| 10.1016/j.jct.2009.09.007 | PROPblock_2 | declared | 15 | unary | — | search_blocks |
| 10.1016/j.jct.2012.03.008 | PROPblock_9 | declared | 6 | unary | — | search_blocks |
| 10.1016/j.jct.2012.03.024 | PROPblock_6 | declared | 6 | unary | — | search_blocks |
| 10.1016/j.jct.2013.11.024 | PROPblock_1 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.jct.2018.12.036 | PROPblock_1 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.tca.2019.01.018 | PROPblock_2 | declared | 5 | unary | — | search_blocks |
| 10.1021/je2000183 | PROPblock_22 | declared | 1 | unary | — | search_blocks |
| 10.1021/je200349t | PROPblock_2 | declared | 5 | unary | — | search_blocks |
| 10.1021/je3000348 | PROPblock_7 | declared | 9 | unary | — | search_blocks |
| 10.1021/je800710p | PROPblock_2 | declared | 10 | unary | — | search_blocks |
| 10.1021/je900502s | PROPblock_5 | declared | 1 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve compound I… | 378 | KEEP ←in 293 | 378 | 5.3 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Confirm surface ten… | 217 | KEEP ←in 251 | 217 | 6.1 |
| 3 | 3 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,135 | KEEP ←in 7,536 | 1135 | 24.7 |
| 4 | 4 | `inspect_block_table` | block_number=GLOBlit_572::PROPblock_4, nearest={'c… | 353 | — | — | 0.2 |
| 5 | 4 | `inspect_block_table` | block_number=GLOBlit_725::PROPblock_4, nearest={'c… | 358 | — | — | 0.1 |
| 6 | 4 | `inspect_block_table` | block_number=GLOBlit_3156::PROPblock_1, nearest={'… | 361 | — | — | 0.2 |
| 7 | 4 | `inspect_block_table` | block_number=GLOBlit_3156::PROPblock_2, nearest={'… | 363 | — | — | 0.1 |
| 8 | 4 | `inspect_block_table` | block_number=GLOBlit_3588::PROPblock_9, nearest={'… | 356 | — | — | 0.1 |
| 9 | 4 | `inspect_block_table` | block_number=GLOBlit_3600::PROPblock_6, nearest={'… | 359 | — | — | 0.2 |
| 10 | 4 | `inspect_block_table` | block_number=GLOBlit_4058::PROPblock_1, nearest={'… | 352 | — | — | 0.1 |
| 11 | 5 | `inspect_block_table` | block_number=GLOBlit_572::PROPblock_4, nearest={'c… | 995 | — | — | 0.1 |
| 12 | 5 | `inspect_block_table` | block_number=GLOBlit_725::PROPblock_4, nearest={'c… | 820 | — | — | 0.1 |
| 13 | 5 | `inspect_block_table` | block_number=GLOBlit_3156::PROPblock_1, nearest={'… | 1,012 | — | — | 0.1 |
| 14 | 5 | `inspect_block_table` | block_number=GLOBlit_3156::PROPblock_2, nearest={'… | 1,013 | — | — | 0.1 |
| 15 | 5 | `inspect_block_table` | block_number=GLOBlit_3588::PROPblock_9, nearest={'… | 998 | — | — | 0.2 |
| 16 | 5 | `inspect_block_table` | block_number=GLOBlit_3600::PROPblock_6, nearest={'… | 1,008 | — | — | 0.2 |
| 17 | 5 | `inspect_block_table` | block_number=GLOBlit_4058::PROPblock_1, nearest={'… | 995 | — | — | 0.3 |
| 18 | 5 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,082 | KEEP ←in 7,536 | 1067 | 21.2 |
| 19 | 6 | `inspect_block_table` | block_number=GLOBlit_572::PROPblock_4, nearest={'c… | 995 | — | — | 0.1 |
| 20 | 7 | `inspect_block_table` | block_number=GLOBlit_725::PROPblock_4, nearest={'c… | 820 | — | — | 0.1 |
| 21 | 7 | `inspect_block_table` | block_number=GLOBlit_3156::PROPblock_1, nearest={'… | 1,012 | — | — | 0.1 |
| 22 | 7 | `inspect_block_table` | block_number=GLOBlit_3156::PROPblock_2, nearest={'… | 1,013 | — | — | 0.1 |
| 23 | 7 | `inspect_block_table` | block_number=GLOBlit_3588::PROPblock_9, nearest={'… | 998 | — | — | 0.1 |
| 24 | 7 | `inspect_block_table` | block_number=GLOBlit_3600::PROPblock_6, nearest={'… | 1,008 | — | — | 0.1 |
| 25 | 7 | `inspect_block_table` | block_number=GLOBlit_4058::PROPblock_1, nearest={'… | 995 | — | — | 0.1 |
| 26 | 8 | `inspect_block_table` | block_number=GLOBlit_725::PROPblock_4, nearest={'c… | 820 | — | — | 0.1 |
| 27 | 8 | `inspect_block_table` | block_number=GLOBlit_3156::PROPblock_1, nearest={'… | 1,012 | — | — | 0.1 |
| 28 | 8 | `inspect_block_table` | block_number=GLOBlit_3156::PROPblock_2, nearest={'… | 1,013 | — | — | 0.1 |
| 29 | 9 | `inspect_block_table` | block_number=GLOBlit_3588::PROPblock_9, nearest={'… | 998 | — | — | 0.1 |
| 30 | 9 | `inspect_block_table` | block_number=GLOBlit_3600::PROPblock_6, nearest={'… | 1,008 | — | — | 0.1 |
| 31 | 9 | `inspect_block_table` | block_number=GLOBlit_4058::PROPblock_1, nearest={'… | 995 | — | — | 0.1 |
| 32 | 9 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,096 | KEEP ←in 7,536 | 1096 | 18.4 |
| 33 | 10 | `inspect_block_table` | block_number=GLOBlit_3588::PROPblock_9, nearest={'… | 998 | — | — | 0.1 |
| 34 | 11 | `inspect_block_table` | block_number=GLOBlit_3600::PROPblock_6, nearest={'… | 1,008 | — | — | 0.1 |
| 35 | 11 | `inspect_block_table` | block_number=GLOBlit_4058::PROPblock_1, nearest={'… | 995 | — | — | 0.1 |
| 36 | 11 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,256 | KEEP ←in 7,536 | 1256 | 16.2 |
| 37 | 12 | `inspect_block_table` | block_number=GLOBlit_5419::PROPblock_1, nearest={'… | 916 | — | — | 0.1 |
| 38 | 12 | `inspect_block_table` | block_number=GLOBlit_6476::PROPblock_2, nearest={'… | 914 | — | — | 0.1 |
| 39 | 12 | `inspect_block_table` | block_number=GLOBlit_9491::PROPblock_22, nearest={… | 816 | — | — | 0.1 |
| 40 | 12 | `inspect_block_table` | block_number=GLOBlit_9568::PROPblock_2, nearest={'… | 883 | — | — | 0.1 |
| 41 | 12 | `inspect_block_table` | block_number=GLOBlit_9790::PROPblock_7, nearest={'… | 902 | — | — | 0.1 |
| 42 | 12 | `inspect_block_table` | block_number=GLOBlit_11369::PROPblock_2, nearest={… | 977 | — | — | 0.1 |
| 43 | 12 | `inspect_block_table` | block_number=GLOBlit_11673::PROPblock_5, nearest={… | 837 | — | — | 0.2 |
| 44 | 1 | `L1_query` | instruction=Search for the compound 1-but…, purpos… | 73,467 | — | — | 312.1 |
| | | **TOTAL (44 tools)** | | **109,907** | | **5,149** | **408.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 736 | 12,317 | 1,468 | 10.9 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,181 | 25,321 | 812 | 6.1 |
| 3 | L1-worker | claudeopus46 | 24,140 | 2,567 | 26,707 | 836 | 5.2 |
| 4 | L1-worker | claudeopus46 | 3,767 | 428 | 4,195 | 509 | 4.5 |
| 5 | L1-worker | claudeopus46 | 3,767 | 394 | 4,161 | 225 | 2.4 |
| 6 | L1-worker | claudeopus46 | 3,767 | 696 | 4,463 | 349 | 3.3 |
| 7 | L1-worker | claudeopus46 | 24,140 | 2,601 | 26,741 | 783 | 6.2 |
| 8 | L1-worker | claudeopus46 | 3,767 | 7,890 | 11,657 | 1,387 | 13.2 |
| 9 | L1-worker | claudeopus46 | 24,140 | 4,286 | 28,426 | 3,369 | 15.5 |
| 10 | L1-worker | claudeopus46 | 24,140 | 8,341 | 32,481 | 3,779 | 20.4 |
| 11 | L1-worker | claudeopus46 | 3,767 | 7,876 | 11,643 | 1,350 | 12.9 |
| 12 | L1-worker | claudeopus46 | 24,140 | 12,374 | 36,514 | 628 | 6.5 |
| 13 | L1-worker | claudeopus46 | 24,140 | 13,885 | 38,025 | 2,780 | 14.7 |
| 14 | L1-worker | claudeopus46 | 24,140 | 17,098 | 41,238 | 2,683 | 18.4 |
| 15 | L1-worker | claudeopus46 | 24,140 | 20,837 | 44,977 | 1,666 | 11.3 |
| 16 | L1-worker | claudeopus46 | 3,767 | 7,874 | 11,641 | 1,380 | 12.9 |
| 17 | L1-worker | claudeopus46 | 24,140 | 23,187 | 47,327 | 628 | 5.7 |
| 18 | L1-worker | claudeopus46 | 24,140 | 24,729 | 48,869 | 1,138 | 7.5 |
| 19 | L1-worker | claudeopus46 | 3,767 | 7,842 | 11,609 | 1,419 | 11.2 |
| 20 | L1-worker | claudeopus46 | 24,140 | 28,799 | 52,939 | 2,292 | 10.3 |
| 21 | L1-worker | claudeopus46 | 24,107 | 32,059 | 56,166 | 3,678 | 27.6 |
| 22 | L1-worker | claudeopus46 | 24,107 | 37,516 | 61,623 | 4,093 | 29.8 |
| 23 | L1-worker | claudeopus46 | 2,320 | 7,780 | 10,100 | 915 | 8.2 |
| 24 | L1-worker | claudeopus46 | 627 | 7,660 | 8,287 | 1,139 | 10.6 |
| 25 | L1-worker | claudeopus46 | 2,543 | 9,082 | 11,625 | 4,833 | 18.9 |
| 26 | L1-worker | claudeopus46 | 787 | 72,538 | 73,325 | 573 | 7.0 |
| 27 | L0-main | claudeopus46 | 11,581 | 42,923 | 54,504 | 8,130 | 54.2 |
| 28 | L0-main | claudeopus46 | 2,320 | 5,552 | 7,872 | 1,238 | 7.4 |
| 29 | L0-main | claudeopus46 | 2,543 | 6,120 | 8,663 | 2,259 | 13.5 |
| 30 | L0-main | claudeopus46 | 1,156 | 15,369 | 16,525 | 5,075 | 23.3 |

