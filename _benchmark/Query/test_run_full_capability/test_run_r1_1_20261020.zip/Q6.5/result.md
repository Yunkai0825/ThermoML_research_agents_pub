# Q6.5 — Result

**Prompt:** Does ThermoML contain Joule–Thomson coefficients for methane? If so, report them with their uncertainties and conditions; if not, say what Joule–Thomson data the archive does hold.

**Tool calls:** 1  |  **Time:** 182.6s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

## Joule–Thomson Coefficients in the ThermoML Database

### Methane
**No Joule–Thomson coefficient data exists for methane in the ThermoML database.**

### What Joule–Thomson Data the Archive Does Hold

The entire ThermoML archive contains Joule–Thomson coefficient data (units: K/kPa) from **a single publication**:

- **DOI:** 10.1016/j.fluid.2011.03.011
- **Compounds:** Triethylene glycol (TEG, C₆H₁₄O₄) and water (H₂O)
- **Measurement method:** Expansion technique
- **Phase:** Liquid
- **Conditions:** All measurements at **P = 7000 kPa**, **T ≈ 293–294 K**
- **Total data points:** 5, across three data blocks

#### Pure Triethylene Glycol (PROPblock_1)

| T (K) | P (kPa) | μ_JT (K/kPa) | U (k = 95%) |
|--------|---------|----------------|-------------|
| 293.1 | 7000 | −0.000366 | 5 × 10⁻⁶ |

#### Pure Water (PROPblock_2)

| T (K) | P (kPa) | μ_JT (K/kPa) | U (k = 95%) |
|--------|---------|----------------|-------------|
| 293.4 | 7000 | −0.000214 | 5 × 10⁻⁶ |

#### Binary Triethylene Glycol + Water Mixture (PROPblock_3)

| w(TEG) | T (K) | P (kPa) | μ_JT (K/kPa) | U (k = 95%) |
|--------|--------|---------|----------------|-------------|
| 0 | 293.4 | 7000.0 | −0.000214 | 5 × 10⁻⁶ |
| 0.99 | 293.8 | 7000.0 | −0.000321 | 5 × 10⁻⁶ |
| 1 | 293.1 | 7000.0 | −0.000366 | 5 × 10⁻⁶ |

### Chemistry Context

All measured Joule–Thomson coefficients are **negative**, which is physically consistent with liquid-phase behavior at high pressure (7 MPa ≈ 70 bar). Under these conditions the fluid is far from its inversion curve, so an isenthalpic expansion produces a temperature *increase* rather than the cooling familiar from gas-phase throttling.

Pure triethylene glycol exhibits a more negative JT coefficient (−0.000366 K/kPa) than pure water (−0.000214 K/kPa), reflecting TEG's larger molar volume and different intermolecular interaction landscape. The binary mixture at w(TEG) = 0.99 falls between the two pure-component values at −0.000321 K/kPa, consistent with composition-weighted mixing behavior.

In summary, while the Joule–Thomson coefficient is an important property for natural-gas processing (where methane is the dominant component), no experimental JT data for methane have been deposited in ThermoML. The only JT data available cover the triethylene glycol–water system from a single study.

### Core claims

- No Joule–Thomson coefficient data exists for methane in the ThermoML database.
- The entire ThermoML archive contains Joule–Thomson coefficient data from a single publication (DOI: 10.1016/j.fluid.2011.03.011), covering triethylene glycol (TEG) and water in the liquid phase at P = 7000 kPa and T ≈ 293–294 K, totaling 5 data points.
- Pure triethylene glycol has a Joule–Thomson coefficient of −0.000366 K/kPa at 293.1 K and 7000 kPa; pure water has −0.000214 K/kPa at 293.4 K and 7000 kPa; the binary mixture at w(TEG) = 0.99 has −0.000321 K/kPa at 293.8 K and 7000 kPa.
- All measured Joule–Thomson coefficients are negative, which is physically consistent with liquid-phase behavior at high pressure where isenthalpic expansion produces a temperature increase rather than cooling.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_950 | 10.1016/j.fluid.2011.03.011 | PROPblock_1 |  | Provides the pure triethylene glycol Joule–Thomson coefficient (−0.000366 K/kPa at 293.1 K, 7000 kPa), which is quoted directly in the answer's first pure-component table and used in the comparative discussion. |
| GLOBlit_950 | 10.1016/j.fluid.2011.03.011 | PROPblock_2 |  | Provides the pure water Joule–Thomson coefficient (−0.000214 K/kPa at 293.4 K, 7000 kPa), which is quoted in the answer's second pure-component table and compared with the TEG value. |
| GLOBlit_950 | 10.1016/j.fluid.2011.03.011 | PROPblock_3 |  | Provides the binary TEG + water mixture Joule–Thomson coefficient data (3 points, mass fraction 0–1, −0.000214 to −0.000366 K/kPa at 7000 kPa), directly reproduced in the answer's binary mixture table. |

### Suggested follow-ups

- Search for isenthalpic expansion or inversion-curve data for methane in complementary databases such as NIST TDE or DIPPR, which may hold Joule–Thomson coefficient measurements not deposited in ThermoML.
- Investigate whether ThermoML contains the constituent properties (isobaric heat capacity and isothermal throttling coefficient) from which the Joule–Thomson coefficient of methane could be derived indirectly.
- Examine the original study (10.1016/j.fluid.2011.03.011) for additional triethylene glycol–water mixture compositions that may not have been deposited in ThermoML.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_113",
    "registry_id": "triethylene_glycol",
    "name": "triethylene glycol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_100",
    "registry_id": "joulethomson_coefficient_k_kpa",
    "name": "Joule-Thomson coefficient, K/kPa"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_120",
    "registry_id": "expansion_technique",
    "name": "Expansion technique"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_51",
    "registry_id": "methane",
    "name": "methane"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_950",
    "registry_id": "2011-sat-sch-0",
    "name": "10.1016/j.fluid.2011.03.011"
  }
]
```

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1016/j.fluid.2011.03.011",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "pressure_kpa",
      "joulethomson_coefficient_k_kpa",
      "joulethomson_coefficient_k_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "293.1",
        "pressure_kpa": "7000",
        "joulethomson_coefficient_k_kpa": "-0.000366",
        "joulethomson_coefficient_k_kpa_U": "5e-06"
      }
    ],
    "inspection_id": "INSP_66a47c711965",
    "lit_num_id": "GLOBlit_950"
  },
  {
    "doi": "10.1016/j.fluid.2011.03.011",
    "block_number": "PROPblock_2",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "pressure_kpa",
      "joulethomson_coefficient_k_kpa",
      "joulethomson_coefficient_k_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "293.4",
        "pressure_kpa": "7000",
        "joulethomson_coefficient_k_kpa": "-0.000214",
        "joulethomson_coefficient_k_kpa_U": "5e-06"
      }
    ],
    "inspection_id": "INSP_e69fca6f26d9",
    "lit_num_id": "GLOBlit_950"
  },
  {
    "doi": "10.1016/j.fluid.2011.03.011",
    "block_number": "PROPblock_3",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "mass_fraction_<triethylene glycol>",
      "temperature_k",
      "pressure_kpa",
      "joulethomson_coefficient_k_kpa",
      "joulethomson_coefficient_k_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "mass_fraction_<triethylene glycol>": "0",
        "temperature_k": "293.4",
        "pressure_kpa": "7000.0",
        "joulethomson_coefficient_k_kpa": "-0.000214",
        "joulethomson_coefficient_k_kpa_U": "5e-06"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "mass_fraction_<triethylene glycol>": "0.99",
        "temperature_k": "293.8",
        "pressure_kpa": "7000.0",
        "joulethomson_coefficient_k_kpa": "-0.000321",
        "joulethomson_coefficient_k_kpa_U": "5e-06"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "mass_fraction_<triethylene glycol>": "1",
        "temperature_k": "293.1",
        "pressure_kpa": "7000.0",
        "joulethomson_coefficient_k_kpa": "-0.000366",
        "joulethomson_coefficient_k_kpa_U": "5e-06"
      }
    ],
    "inspection_id": "INSP_a6e34ffcf403",
    "lit_num_id": "GLOBlit_950"
  }
]
```
