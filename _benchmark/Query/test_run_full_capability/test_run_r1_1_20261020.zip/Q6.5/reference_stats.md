# Reference Stats — query-agent

**Run started:** 2026-10-20 17:52:52
**Wall time (at last flush):** 181.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 29,181 | 28,479 | 7,116 | 57,660 | 11,532 | 45.5 | claudeopus46 |
| L1-worker | 16 | 194,092 | 88,133 | 19,656 | 282,225 | 17,639 | 139.0 | claudeopus46 |
| **TOTAL** | **21** | **223,273** | **116,612** | **26,772** | **339,885** | **16,185** | **184.5** | |

**Estimated tokens:** ~84,971 input + ~6,693 output = ~91,664 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_property_ids` | 0 | 13 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 0 | 1 | 0 | 0 | 1 | 3 | 5 |
| `search_blocks` | 2 | 1 | 3 | 1 | 1 | 3 | 5 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **3** | **15** | **3** | **1** | **2** | **6** | **10** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Properties (13 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_100 |  | resolve_property_ids, search_blocks, search_system_summary |
| GLOBprop_38 |  | resolve_property_ids |
| GLOBprop_89 |  | resolve_property_ids |
| GLOBprop_73 |  | resolve_property_ids |
| GLOBprop_3 |  | resolve_property_ids |
| GLOBprop_56 |  | resolve_property_ids |
| GLOBprop_83 |  | resolve_property_ids |
| GLOBprop_29 |  | resolve_property_ids |
| GLOBprop_71 |  | resolve_property_ids |
| GLOBprop_101 |  | resolve_property_ids |
| GLOBprop_94 |  | resolve_property_ids |
| GLOBprop_95 |  | resolve_property_ids |
| GLOBprop_59 |  | resolve_property_ids |

#### Compounds (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_51 |  | resolve_compound_ids |
| GLOBcomp_113 | triethylene glycol | search_blocks |
| GLOBcomp_1 | water | search_blocks |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_950 |  | search_blocks, search_system_summary |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_120 | Joule-Thomson coefficient, K/kPa | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Properties | 13 |
| Unique Compounds | 3 |
| Unique References | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 3 |
| Explicit block/subsystem targets | 3 |
| Subsystem targets | 0 |
| Target-matched data points | 5 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 3  |  **Explicit targets:** 3  |  **Subsystems:** 0  |  **Target-matched datapoints:** 5

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2011.03.011 | 3 | 5 | binary, unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2011.03.011 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2011.03.011 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2011.03.011 | PROPblock_3 | declared | 3 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_property_ids` | limit=20, min_score=30, purpose=Find Joule-Thomson… | 246 | KEEP ←in 1,353 | 246 | 5.1 |
| 2 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Find methane compo… | 206 | KEEP ←in 219 | 206 | 4.2 |
| 3 | 3 | `search_blocks` | compound=GLOBcomp_51, limit=20, property=GLOBprop_… | 655 | DISCARD ←in 39 | 597 | 14.2 |
| 4 | 3 | `search_system_summary` | limit=20, property=GLOBprop_100, purpose=Find all … | 679 | KEEP ←in 550 | 665 | 8.0 |
| 5 | 4 | `search_blocks` | limit=20, literature=GLOBlit_950, property=GLOBpro… | 1,164 | KEEP ←in 4,293 | 1164 | 11.7 |
| 6 | 6 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_950, … | 766 | — | — | 0.1 |
| 7 | 6 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_950, … | 753 | — | — | 0.1 |
| 8 | 6 | `inspect_block_table` | block_number=PROPblock_3, literature=GLOBlit_950, … | 1,026 | — | — | 0.1 |
| 9 | 1 | `L1_query` | context=User wants Joule-Thomson coef…, id_catalog… | 22,690 | — | — | 140.0 |
| | | **TOTAL (9 tools)** | | **28,185** | | **2,878** | **183.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 643 | 12,224 | 1,597 | 10.6 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,371 | 25,511 | 861 | 6.4 |
| 3 | L1-worker | claudeopus46 | 24,140 | 2,827 | 26,967 | 907 | 5.7 |
| 4 | L1-worker | claudeopus46 | 3,767 | 1,537 | 5,304 | 469 | 4.8 |
| 5 | L1-worker | claudeopus46 | 3,767 | 356 | 4,123 | 360 | 3.6 |
| 6 | L1-worker | claudeopus46 | 24,140 | 2,649 | 26,789 | 1,035 | 7.5 |
| 7 | L1-worker | claudeopus46 | 3,767 | 403 | 4,170 | 840 | 6.1 |
| 8 | L1-worker | claudeopus46 | 3,767 | 993 | 4,760 | 1,055 | 7.3 |
| 9 | L1-worker | claudeopus46 | 24,140 | 4,675 | 28,815 | 861 | 6.8 |
| 10 | L1-worker | claudeopus46 | 3,767 | 4,664 | 8,431 | 1,399 | 11.4 |
| 11 | L1-worker | claudeopus46 | 24,140 | 6,329 | 30,469 | 4,739 | 31.9 |
| 12 | L1-worker | claudeopus46 | 24,140 | 14,128 | 38,268 | 1,095 | 6.6 |
| 13 | L1-worker | claudeopus46 | 24,140 | 17,478 | 41,618 | 2,246 | 17.1 |
| 14 | L1-worker | claudeopus46 | 627 | 2,257 | 2,884 | 775 | 5.2 |
| 15 | L1-worker | claudeopus46 | 2,320 | 2,377 | 4,697 | 960 | 6.0 |
| 16 | L1-worker | claudeopus46 | 2,543 | 3,869 | 6,412 | 1,455 | 6.7 |
| 17 | L1-worker | claudeopus46 | 787 | 22,220 | 23,007 | 599 | 5.9 |
| 18 | L0-main | claudeopus46 | 11,581 | 17,157 | 28,738 | 2,509 | 17.6 |
| 19 | L0-main | claudeopus46 | 2,320 | 2,514 | 4,834 | 868 | 4.3 |
| 20 | L0-main | claudeopus46 | 2,543 | 2,989 | 5,532 | 922 | 6.3 |
| 21 | L0-main | claudeopus46 | 1,156 | 5,176 | 6,332 | 1,220 | 6.7 |

