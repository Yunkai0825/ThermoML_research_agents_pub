# Answer

**Prompt:** Does ThermoML contain Joule–Thomson coefficients for methane? If so, report them with their uncertainties and conditions; if not, say what Joule–Thomson data the archive does hold.

**[run statistics removed]**

---

## Answer

## Joule–Thomson Coefficients in the ThermoML Database

### Methane
**No Joule–Thomson coefficient data exists for methane in the ThermoML database.**

### What Joule–Thomson Data the Archive Does Hold

The entire ThermoML archive contains Joule–Thomson coefficient data (units: K/kPa) from **a single publication**:

- **DOI:** 10.1016/j.fluid.2011.03.011
- **Compounds:** Triethylene glycol (TEG, C₆H₁₄O₄) and water (H₂O)
- **Measurement method:** Expansion technique
- **Phase:** Liquid
- **Conditions:** All measurements at **P = 7000 kPa**, **T ≈ 293–294 K**
- **Total data points:** 5, across three data blocks

#### Pure Triethylene Glycol (PROPblock_1)

| T (K) | P (kPa) | μ_JT (K/kPa) | U (k = 95%) |
|--------|---------|----------------|-------------|
| 293.1 | 7000 | −0.000366 | 5 × 10⁻⁶ |

#### Pure Water (PROPblock_2)

| T (K) | P (kPa) | μ_JT (K/kPa) | U (k = 95%) |
|--------|---------|----------------|-------------|
| 293.4 | 7000 | −0.000214 | 5 × 10⁻⁶ |

#### Binary Triethylene Glycol + Water Mixture (PROPblock_3)

| w(TEG) | T (K) | P (kPa) | μ_JT (K/kPa) | U (k = 95%) |
|--------|--------|---------|----------------|-------------|
| 0 | 293.4 | 7000.0 | −0.000214 | 5 × 10⁻⁶ |
| 0.99 | 293.8 | 7000.0 | −0.000321 | 5 × 10⁻⁶ |
| 1 | 293.1 | 7000.0 | −0.000366 | 5 × 10⁻⁶ |

### Chemistry Context

All measured Joule–Thomson coefficients are **negative**, which is physically consistent with liquid-phase behavior at high pressure (7 MPa ≈ 70 bar). Under these conditions the fluid is far from its inversion curve, so an isenthalpic expansion produces a temperature *increase* rather than the cooling familiar from gas-phase throttling.

Pure triethylene glycol exhibits a more negative JT coefficient (−0.000366 K/kPa) than pure water (−0.000214 K/kPa), reflecting TEG's larger molar volume and different intermolecular interaction landscape. The binary mixture at w(TEG) = 0.99 falls between the two pure-component values at −0.000321 K/kPa, consistent with composition-weighted mixing behavior.

In summary, while the Joule–Thomson coefficient is an important property for natural-gas processing (where methane is the dominant component), no experimental JT data for methane have been deposited in ThermoML. The only JT data available cover the triethylene glycol–water system from a single study.

### Core claims

- No Joule–Thomson coefficient data exists for methane in the ThermoML database.
- The entire ThermoML archive contains Joule–Thomson coefficient data from a single publication (DOI: 10.1016/j.fluid.2011.03.011), covering triethylene glycol (TEG) and water in the liquid phase at P = 7000 kPa and T ≈ 293–294 K, totaling 5 data points.
- Pure triethylene glycol has a Joule–Thomson coefficient of −0.000366 K/kPa at 293.1 K and 7000 kPa; pure water has −0.000214 K/kPa at 293.4 K and 7000 kPa; the binary mixture at w(TEG) = 0.99 has −0.000321 K/kPa at 293.8 K and 7000 kPa.
- All measured Joule–Thomson coefficients are negative, which is physically consistent with liquid-phase behavior at high pressure where isenthalpic expansion produces a temperature increase rather than cooling.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_950 | 10.1016/j.fluid.2011.03.011 | PROPblock_1 |  | Provides the pure triethylene glycol Joule–Thomson coefficient (−0.000366 K/kPa at 293.1 K, 7000 kPa), which is quoted directly in the answer's first pure-component table and used in the comparative discussion. |
| GLOBlit_950 | 10.1016/j.fluid.2011.03.011 | PROPblock_2 |  | Provides the pure water Joule–Thomson coefficient (−0.000214 K/kPa at 293.4 K, 7000 kPa), which is quoted in the answer's second pure-component table and compared with the TEG value. |
| GLOBlit_950 | 10.1016/j.fluid.2011.03.011 | PROPblock_3 |  | Provides the binary TEG + water mixture Joule–Thomson coefficient data (3 points, mass fraction 0–1, −0.000214 to −0.000366 K/kPa at 7000 kPa), directly reproduced in the answer's binary mixture table. |

### Suggested follow-ups

- Search for isenthalpic expansion or inversion-curve data for methane in complementary databases such as NIST TDE or DIPPR, which may hold Joule–Thomson coefficient measurements not deposited in ThermoML.
- Investigate whether ThermoML contains the constituent properties (isobaric heat capacity and isothermal throttling coefficient) from which the Joule–Thomson coefficient of methane could be derived indirectly.
- Examine the original study (10.1016/j.fluid.2011.03.011) for additional triethylene glycol–water mixture compositions that may not have been deposited in ThermoML.

---

<!-- END OF REVIEW COPY. Later generated run appendices are separate execution evidence. -->
