# Data grounding evidence

- generated: 2026-10-20T17:55:40
- gate verdict: OK

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | GLOBlit_950 | yes | INSP_66a47c711965 | 1 |
| PROPblock_2 | GLOBlit_950 | yes | INSP_e69fca6f26d9 | 1 |
| PROPblock_3 | GLOBlit_950 | yes | INSP_a6e34ffcf403 | 3 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 293.1 | PROPblock_1 | verified | — |
| 7000 | PROPblock_1 | verified | — |
| -0.000366 | PROPblock_1 | verified | — |
| 5e-6 | PROPblock_1 | verified | — |
| 293.4 | PROPblock_2 | verified | — |
| 7000 | PROPblock_2 | verified | — |
| -0.000214 | PROPblock_2 | verified | — |
| 5e-6 | PROPblock_2 | verified | — |
| 293.4 | PROPblock_3 | verified | — |
| 7000.0 | PROPblock_3 | verified | — |
| -0.000214 | PROPblock_3 | verified | — |
| 5e-6 | PROPblock_3 | verified | — |
| 0.99 | PROPblock_3 | verified | — |
| 293.8 | PROPblock_3 | verified | — |
| 7000.0 | PROPblock_3 | verified | — |
| -0.000321 | PROPblock_3 | verified | — |
| 5e-6 | PROPblock_3 | verified | — |
| 293.1 | PROPblock_3 | verified | — |
| 7000.0 | PROPblock_3 | verified | — |
| -0.000366 | PROPblock_3 | verified | — |
| 5e-6 | PROPblock_3 | verified | — |
| 70 | PROPblock_3 | verified | — |
| 0.99 | PROPblock_3 | verified | — |
| -0.000321 | PROPblock_3 | verified | — |

## Inspections (verbatim)

### INSP_66a47c711965 — GLOBlit_950::PROPblock_1 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_e69fca6f26d9 — GLOBlit_950::PROPblock_2 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_a6e34ffcf403 — GLOBlit_950::PROPblock_3 (complete, 3 rows shown)

_structured envelope entry (no markdown)_
