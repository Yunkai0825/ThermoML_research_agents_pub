# Data grounding evidence

- generated: 2026-10-20T17:46:02
- gate verdict: 5 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_23 | GLOBlit_8063 | yes | INSP_80faa7da7ddb | 1 |
| PROPblock_24 | GLOBlit_8063 | yes | INSP_584502286ced | 1 |
| PROPblock_25 | GLOBlit_8063 | yes | INSP_11e54d9b92fa | 1 |
| PROPblock_7 | GLOBlit_8544 | yes | INSP_4f046d8559d2, INSP_50a9f4c7288a | 1 |
| PROPblock_8 | GLOBlit_8544 | yes | INSP_3adb2faeb478, INSP_503f032355fb | 1 |
| PROPblock_9 | GLOBlit_8544 | yes | INSP_92360e5444e2, INSP_d33cb7fe1e1e | 1 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 374.13 | PROPblock_24 + PROPblock_23 + PROPblock_25 | verified | — |
| 0.07 | PROPblock_24 + PROPblock_23 + PROPblock_25 | verified | — |
| 4051 | PROPblock_24 + PROPblock_23 + PROPblock_25 | verified | — |
| 508 | PROPblock_24 + PROPblock_23 + PROPblock_25 | verified | — |
| 374.13 | PROPblock_8 + PROPblock_7 + PROPblock_9 | verified | — |
| 0.16 | PROPblock_8 + PROPblock_7 + PROPblock_9 | verified | — |
| 4053 | PROPblock_8 + PROPblock_7 + PROPblock_9 | verified | — |
| 508 | PROPblock_8 + PROPblock_7 + PROPblock_9 | verified | — |
| 374.13 | PROPblock_8 + PROPblock_7 + PROPblock_9 | verified | — |
| 0.16 | PROPblock_8 + PROPblock_7 + PROPblock_9 | verified | — |
| 4053 | PROPblock_8 + PROPblock_7 + PROPblock_9 | verified | — |
| 508 | PROPblock_8 + PROPblock_7 + PROPblock_9 | verified | — |
| 374.13 | PROPblock_9 | ambiguous | 2 sources |
| 0.07 | PROPblock_9 | misattributed | PROPblock_24 |
| 0.16 | PROPblock_9 | misattributed | PROPblock_8 |
| 4051 | PROPblock_9 | misattributed | PROPblock_23 |
| 4053 | PROPblock_9 | misattributed | PROPblock_7 |
| 508 | PROPblock_9 | verified | — |

## Violations

- **AMBIGUOUS_VALUE** PROPblock_9: 374.13 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_9: 0.07 does not belong to PROPblock_9; it matches only GLOBlit_8063::PROPblock_24 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_9: 0.16 does not belong to PROPblock_9; it matches only GLOBlit_8544::PROPblock_8 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_9: 4051 does not belong to PROPblock_9; it matches only GLOBlit_8063::PROPblock_23 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_9: 4053 does not belong to PROPblock_9; it matches only GLOBlit_8544::PROPblock_7 (inspected this run)

## Inspections (verbatim)

### INSP_80faa7da7ddb — GLOBlit_8063::PROPblock_23 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_584502286ced — GLOBlit_8063::PROPblock_24 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_11e54d9b92fa — GLOBlit_8063::PROPblock_25 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_4f046d8559d2 — GLOBlit_8544::PROPblock_7 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_3adb2faeb478 — GLOBlit_8544::PROPblock_8 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_92360e5444e2 — GLOBlit_8544::PROPblock_9 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_50a9f4c7288a — GLOBlit_8560::PROPblock_7 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_503f032355fb — GLOBlit_8560::PROPblock_8 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_d33cb7fe1e1e — GLOBlit_8560::PROPblock_9 (complete, 1 rows shown)

_structured envelope entry (no markdown)_
