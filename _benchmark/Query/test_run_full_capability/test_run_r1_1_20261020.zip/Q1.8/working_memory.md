# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_95 | 1,1,1,2-tetrafluoroethane | 1,1,1,2-tetrafluoroethane |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find critical temperature, critical pressure, and critical density of 1,1,1,2-tetrafluoroethane (R134a) with uncertainti → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

Three independent ThermoML sources report critical-point properties for 1,1,1,2-tetrafluoroethane (R134a, GLOBcomp_95). All three agree on a critical temperature of 374.13 K, a critical density of 508 kg/m³, and critical pressures of 4051 kPa (GLOBlit_8063) or 4053 kPa (GLOBlit_8544 and GLOBlit_8560), with the 2 kPa difference well within reported uncertainties. The most precise dataset is from DOI 10.1021/je0201976 (GLOBlit_8063), giving 374.13 ± 0.07 K (PROPblock_24), 4051 ± 5 kPa (PROPblock_23), and 508 ± 2 kg/m³ (PROPblock_25). The other two sources (GLOBlit_8544 from DOI 10.1021/je0499420 and GLOBlit_8560 from DOI 10.1021/je0499723) report identical values with wider expanded combined uncertainties (± 0.16 K, ± 12 kPa, ± 12 kg/m³) at the 95% confidence level.

**Answer:**

#### Critical Properties of 1,1,1,2-Tetrafluoroethane (R134a)

Three independent literature sources in the ThermoML database report critical-point data for R134a (GLOBcomp_95). The values are highly consistent across all sources.

##### Summary of Measured Values

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *Property* | *Value* | *Uncertainty (U, 95%)* | *Unit* | *Source DOI* | *Literature ID* | *Block* |
|---|---|---|---|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「**Critical Temperature**」 | 「374.13」 | 「± 0.07」 | 「K」 | 「10.1021/je0201976」 | 「GLOBlit_8063」 | 「PROPblock_24」 |
| WM_L1#1_Table#1_Row#2 | 「**Critical Pressure**」 | 「4051」 | 「± 5」 | 「kPa」 | 「10.1021/je0201976」 | 「GLOBlit_8063」 | 「PROPblock_23」 |
| WM_L1#1_Table#1_Row#3 | 「**Critical Density**」 | 「508」 | 「± 2」 | 「kg/m³」 | 「10.1021/je0201976」 | 「GLOBlit_8063」 | 「PROPblock_25」 |

##### Additional Corroborating Sources

**WM_L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *Property* | *Value* | *Uncertainty (U, 95%)* | *Unit* | *Source DOI* | *Literature ID* | *Block* |
|---|---|---|---|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「Critical Temperature」 | 「374.13」 | 「± 0.16」 | 「K」 | 「10.1021/je0499420」 | 「GLOBlit_8544」 | 「PROPblock_8」 |
| WM_L1#1_Table#2_Row#2 | 「Critical Pressure」 | 「4053」 | 「± 12」 | 「kPa」 | 「10.1021/je0499420」 | 「GLOBlit_8544」 | 「PROPblock_7」 |
| WM_L1#1_Table#2_Row#3 | 「Critical Density」 | 「508」 | 「± 12」 | 「kg/m³」 | 「10.1021/je0499420」 | 「GLOBlit_8544」 | 「PROPblock_9」 |
| WM_L1#1_Table#2_Row#4 | 「Critical Temperature」 | 「374.13」 | 「± 0.16」 | 「K」 | 「10.1021/je0499723」 | 「GLOBlit_8560」 | 「PROPblock_8」 |
| WM_L1#1_Table#2_Row#5 | 「Critical Pressure」 | 「4053」 | 「± 12」 | 「kPa」 | 「10.1021/je0499723」 | 「GLOBlit_8560」 | 「PROPblock_7」 |
| WM_L1#1_Table#2_Row#6 | 「Critical Density」 | 「508」 | 「± 12」 | 「kg/m³」 | 「10.1021/je0499723」 | 「GLOBlit_8560」 | 「PROPblock_9」 |

##### Key Observations

- **Critical temperature:** GLOBlit_8063 PROPblock_24 reports 374.13 K ± 0.07 K (visual observation in an unstirred cell). GLOBlit_8544 PROPblock_8 and GLOBlit_8560 PROPblock_8 each report 374.13 K ± 0.16 K. The tightest uncertainty is from GLOBlit_8063 PROPblock_24.
- **Critical pressure:** GLOBlit_8063 PROPblock_23 reports 4051 kPa ± 5 kPa. GLOBlit_8544 PROPblock_7 and GLOBlit_8560 PROPblock_7 each report 4053 kPa ± 12 kPa. The 2 kPa difference is well within the reported uncertainties. All measurements used direct measurement methods.
- **Critical density:** GLOBlit_8063 PROPblock_25 reports 508 kg/m³ ± 2 kg/m³. GLOBlit_8544 PROPblock_9 and GLOBlit_8560 PROPblock_9 each report 508 kg/m³ ± 12 kg/m³. The value is identical across all sources.

All uncertainties are expanded combined uncertainties (U) at the 95% confidence level, as evaluated by the data file compiler.

The most precise dataset is from DOI 10.1021/je0201976 (GLOBlit_8063), which reports the smallest uncertainties for all three critical properties.

**Core claims:**
- Three independent ThermoML sources report highly consistent critical-point data for 1,1,1,2-tetrafluoroethane (R134a): critical temperature of 374.13 K, critical pressure of 4051–4053 kPa, and critical density of 508 kg/m³.
- The most precise dataset (DOI 10.1021/je0201976, GLOBlit_8063) reports critical temperature 374.13 ± 0.07 K, critical pressure 4051 ± 5 kPa, and critical density 508 ± 2 kg/m³, all at the 95% confidence level.
- Two additional corroborating sources (DOIs 10.1021/je0499420 and 10.1021/je0499723) report the same critical temperature (374.13 ± 0.16 K), critical pressure (4053 ± 12 kPa), and critical density (508 ± 12 kg/m³), with differences well within reported uncertainties.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_8063」 | 「PROPblock_24」 | 「GLOBcomp_95」 | 「GLOBprop_23」 | 「Critical temperature of R134a reported as 374.13 K ± 0.07 K.」 |
| WM_L1#1_Table#4 | 「GLOBlit_8063」 | 「PROPblock_23」 | 「GLOBcomp_95」 | 「GLOBprop_25」 | 「Critical pressure of R134a reported as 4051 kPa ± 5 kPa.」 |
| WM_L1#1_Table#5 | 「GLOBlit_8063」 | 「PROPblock_25」 | 「GLOBcomp_95」 | 「GLOBprop_54」 | 「Critical density of R134a reported as 508 kg/m³ ± 2 kg/m³.」 |
| WM_L1#1_Table#6 | 「GLOBlit_8544」 | 「PROPblock_8」 | 「GLOBcomp_95」 | 「GLOBprop_23」 | 「Corroborating critical temperature of R134a reported as 374.13 K ± 0.16 K.」 |
| WM_L1#1_Table#7 | 「GLOBlit_8544」 | 「PROPblock_7」 | 「GLOBcomp_95」 | 「GLOBprop_25」 | 「Corroborating critical pressure of R134a reported as 4053 kPa ± 12 kPa.」 |
| WM_L1#1_Table#8 | 「GLOBlit_8544」 | 「PROPblock_9」 | 「GLOBcomp_95」 | 「GLOBprop_54」 | 「Corroborating critical density of R134a reported as 508 kg/m³ ± 12 kg/m³.」 |
| WM_L1#1_Table#9 | 「GLOBlit_8560」 | 「PROPblock_8」 | 「GLOBcomp_95」 | 「GLOBprop_23」 | 「Corroborating critical temperature of R134a reported as 374.13 K ± 0.16 K.」 |
| WM_L1#1_Table#10 | 「GLOBlit_8560」 | 「PROPblock_7」 | 「GLOBcomp_95」 | 「GLOBprop_25」 | 「Corroborating critical pressure of R134a reported as 4053 kPa ± 12 kPa.」 |
| WM_L1#1_Table#11 | 「GLOBlit_8560」 | 「PROPblock_9」 | 「GLOBcomp_95」 | 「GLOBprop_54」 | 「Corroborating critical density of R134a reported as 508 kg/m³ ± 12 kg/m³.」 |

*Not stored here: 9 verbatim data_inspections table(s); 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


