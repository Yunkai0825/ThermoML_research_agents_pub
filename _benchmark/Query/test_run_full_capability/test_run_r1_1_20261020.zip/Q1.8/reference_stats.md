# Reference Stats — query-agent

**Run started:** 2026-10-20 17:43:16
**Wall time (at last flush):** 187.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 29,181 | 37,549 | 10,101 | 66,730 | 13,346 | 55.9 | claudeopus46 |
| L1-worker | 16 | 234,838 | 137,386 | 21,504 | 372,224 | 23,264 | 133.1 | claudeopus46 |
| **TOTAL** | **21** | **264,019** | **174,935** | **31,605** | **438,954** | **20,902** | **189.0** | |

**Estimated tokens:** ~109,738 input + ~7,901 output = ~117,639 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 3 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 3 | 0 | 0 | 3 | 9 | 9 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **6** | **0** | **0** | **3** | **9** | **9** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_95 |  | resolve_compound_ids, search_blocks |

#### Properties (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_23 |  | resolve_property_ids, search_blocks |
| GLOBprop_25 |  | resolve_property_ids, search_blocks |
| GLOBprop_54 |  | resolve_property_ids, search_blocks |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8063 |  | search_blocks |
| GLOBlit_8544 |  | search_blocks |
| GLOBlit_8560 |  | search_blocks |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_43 | Critical pressure, kPa | search_blocks |
| GLOBmeas_37 | Critical temperature, K | search_blocks |
| GLOBmeas_137 | Critical density, kg/m3 | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 3 |
| Unique References | 3 |
| Unique Measurements | 3 |
| Unique Phases | 1 |
| Total DOIs | 3 |
| Unique parent blocks | 9 |
| Explicit block/subsystem targets | 9 |
| Subsystem targets | 0 |
| Target-matched data points | 9 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 9  |  **Explicit targets:** 9  |  **Subsystems:** 0  |  **Target-matched datapoints:** 9

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je0201976 | 3 | 3 | unary | search_blocks |
| 10.1021/je0499420 | 3 | 3 | unary | search_blocks |
| 10.1021/je0499723 | 3 | 3 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je0201976 | PROPblock_23 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0201976 | PROPblock_24 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0201976 | PROPblock_25 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499420 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499420 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499420 | PROPblock_9 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499723 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499723 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499723 | PROPblock_9 | declared | 1 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve R134a comp… | 243 | KEEP ←in 249 | 243 | 4.7 |
| 2 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Resolve critical p… | 233 | KEEP ←in 377 | 233 | 3.2 |
| 3 | 3 | `search_blocks` | compound=GLOBcomp_95, limit=50, property=['GLOBpro… | 1,353 | KEEP ←in 8,508 | 1353 | 17.7 |
| 4 | 4 | `inspect_block_table` | block_number=GLOBlit_8063::PROPblock_23, purpose=V… | 585 | — | — | 0.4 |
| 5 | 4 | `inspect_block_table` | block_number=GLOBlit_8063::PROPblock_24, purpose=V… | 604 | — | — | 0.2 |
| 6 | 4 | `inspect_block_table` | block_number=GLOBlit_8063::PROPblock_25, purpose=V… | 586 | — | — | 0.2 |
| 7 | 6 | `inspect_block_table` | block_number=GLOBlit_8544::PROPblock_7, purpose=Ve… | 587 | — | — | 0.2 |
| 8 | 6 | `inspect_block_table` | block_number=GLOBlit_8544::PROPblock_8, purpose=Ve… | 603 | — | — | 0.4 |
| 9 | 6 | `inspect_block_table` | block_number=GLOBlit_8544::PROPblock_9, purpose=Ve… | 588 | — | — | 0.1 |
| 10 | 7 | `inspect_block_table` | block_number=GLOBlit_8560::PROPblock_7, purpose=In… | 587 | — | — | 0.3 |
| 11 | 7 | `inspect_block_table` | block_number=GLOBlit_8560::PROPblock_8, purpose=In… | 603 | — | — | 0.3 |
| 12 | 7 | `inspect_block_table` | block_number=GLOBlit_8560::PROPblock_9, purpose=In… | 588 | — | — | 0.2 |
| 13 | 1 | `L1_query` | instruction=1. Resolve the compound 1,1,1…, purpos… | 35,132 | — | — | 135.9 |
| | | **TOTAL (13 tools)** | | **42,292** | | **1,829** | **163.8** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 703 | 12,284 | 1,597 | 10.3 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,247 | 25,387 | 914 | 5.7 |
| 3 | L1-worker | claudeopus46 | 24,140 | 2,710 | 26,850 | 913 | 4.9 |
| 4 | L1-worker | claudeopus46 | 3,767 | 401 | 4,168 | 388 | 4.1 |
| 5 | L1-worker | claudeopus46 | 3,767 | 571 | 4,338 | 358 | 3.1 |
| 6 | L1-worker | claudeopus46 | 24,140 | 2,548 | 26,688 | 926 | 6.1 |
| 7 | L1-worker | claudeopus46 | 3,767 | 8,985 | 12,752 | 1,632 | 10.8 |
| 8 | L1-worker | claudeopus46 | 24,140 | 4,459 | 28,599 | 1,439 | 8.6 |
| 9 | L1-worker | claudeopus46 | 24,140 | 7,050 | 31,190 | 2,229 | 13.7 |
| 10 | L1-worker | claudeopus46 | 24,140 | 12,254 | 36,394 | 1,078 | 6.8 |
| 11 | L1-worker | claudeopus46 | 24,140 | 14,792 | 38,932 | 1,061 | 6.2 |
| 12 | L1-worker | claudeopus46 | 24,140 | 17,314 | 41,454 | 2,229 | 13.8 |
| 13 | L1-worker | claudeopus46 | 24,140 | 23,172 | 47,312 | 3,563 | 22.5 |
| 14 | L1-worker | claudeopus46 | 627 | 2,465 | 3,092 | 788 | 5.4 |
| 15 | L1-worker | claudeopus46 | 2,320 | 2,585 | 4,905 | 759 | 5.7 |
| 16 | L1-worker | claudeopus46 | 2,543 | 3,953 | 6,496 | 2,623 | 9.7 |
| 17 | L1-worker | claudeopus46 | 787 | 32,880 | 33,667 | 604 | 6.0 |
| 18 | L0-main | claudeopus46 | 11,581 | 22,321 | 33,902 | 3,028 | 19.4 |
| 19 | L0-main | claudeopus46 | 2,320 | 2,958 | 5,278 | 1,006 | 5.4 |
| 20 | L0-main | claudeopus46 | 2,543 | 3,493 | 6,036 | 1,534 | 8.2 |
| 21 | L0-main | claudeopus46 | 1,156 | 8,074 | 9,230 | 2,936 | 12.6 |

