# Q6.3 — Result

**Prompt:** What is the viscosity of ethanol + water mixtures at 2000 K?

**[run statistics removed]**

---

## Answer

**No data found in the ThermoML database for viscosity of ethanol + water mixtures at 2000 K.**

At 2000 K, both ethanol and water would be far above their critical temperatures and normal boiling points, so a conventional liquid-phase viscosity measurement is not physically meaningful — both components would exist as supercritical fluids or thermal decomposition products. This explains why no such data exist in the archive.

### What viscosity data *are* available for ethanol + water

The ThermoML database contains dynamic viscosity (η, Pa·s) data for ethanol + water binary mixtures across **14 data blocks from 14 publications**, but all measurements are in the **liquid phase** and span only **268.1 K to 618.2 K**.

#### Highest-temperature data: up to 618.2 K

The closest data to your requested temperature come from two studies that used elevated pressures to keep the mixture in a dense/liquid state:

| DOI | Literature ID | Block | T range (K) | P range (kPa) | x(ethanol) | η range (Pa·s) | Points |
|-----|---------------|-------|-------------|---------------|------------|----------------|--------|
| 10.1016/j.fluid.2017.09.005 | GLOBlit_2092 | PROPblock_4 | 523.2–618.2 | 20 000–40 000 | 0–1 | 3.1×10⁻⁵ – 1.34×10⁻⁴ | 72 |
| 10.1016/j.fluid.2015.07.012 | GLOBlit_1742 | PROPblock_4 | 350.7–476.2 | 10 000–40 000 | 0.1–1 | 1.07×10⁻⁴ – 7.37×10⁻⁴ | 84 |

**Selected data points at the highest available temperature (618.2 K)** from GLOBlit_2092 · PROPblock_4:

| T (K) | P (kPa) | x(ethanol) | η (Pa·s) |
|-------|---------|------------|----------|
| 618.2 | 20 000 | 0 | 7.2×10⁻⁵ |
| 618.2 | 20 000 | 0.2 | 3.5×10⁻⁵ |
| 618.2 | 20 000 | 0.3 | 3.1×10⁻⁵ |
| 618.2 | 20 000 | 1 | 3.9×10⁻⁵ |
| 618.2 | 40 000 | 0 | 8.1×10⁻⁵ |
| 618.2 | 40 000 | 1 | 6.7×10⁻⁵ |

#### Near-ambient data: 293–303 K

At more conventional conditions (atmospheric pressure), data from GLOBlit_2825 · PROPblock_11 (DOI: 10.1016/j.jct.2007.05.004) cover 293.15–303.15 K at 101 kPa, with viscosities ranging from 7.97×10⁻⁴ to 2.705×10⁻³ Pa·s across the full water mole-fraction range.

### Summary

The maximum temperature with viscosity data for this system in ThermoML is **618.2 K** — still far below 2000 K. No extrapolation to 2000 K is possible from these liquid-phase measurements, and no gas-phase or supercritical viscosity data for this mixture are present in the database.

### Core claims

- No viscosity data for ethanol + water mixtures at 2000 K exist in the ThermoML database.
- At 2000 K, both ethanol and water would be far above their critical temperatures, so conventional liquid-phase viscosity measurement is not physically meaningful.
- The ThermoML database contains dynamic viscosity data for ethanol + water binary mixtures across 14 data blocks from 14 publications, all in the liquid phase, spanning only 268.1 K to 618.2 K.
- The highest-temperature viscosity data available are from DOI 10.1016/j.fluid.2017.09.005 (GLOBlit_2092, PROPblock_4), covering 523.2–618.2 K at 20 000–40 000 kPa, with viscosities of 3.1×10⁻⁵ – 1.34×10⁻⁴ Pa·s.
- No extrapolation from the available liquid-phase measurements to 2000 K is possible, and no gas-phase or supercritical viscosity data for this mixture are present in the database.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_4 |  | Provides the highest-temperature viscosity data for ethanol + water in ThermoML (523.2–618.2 K, 20 000–40 000 kPa, 72 points), demonstrating that even the closest available data fall far below the requested 2000 K. The answer quotes specific data points at 618.2 K from this block. |
| GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_4 |  | Supplies additional high-pressure viscosity data for ethanol + water at 350.7–476.2 K (84 points), reinforcing that available measurements span only up to ~618 K and no data exist near 2000 K. |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_11 |  | Provides near-ambient viscosity data for ethanol + water at 293.15–303.15 K and 101 kPa (37 points), cited in the answer to illustrate the range of conventional liquid-phase data available in ThermoML for this system. |

### Suggested follow-ups

- Would you like viscosity data for ethanol + water at the highest available temperature (up to 618.2 K) at elevated pressures?
- Would you like to see viscosity data for ethanol + water near ambient conditions (293–303 K)?
- Are you interested in other thermophysical properties of ethanol + water mixtures at high temperatures?

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
