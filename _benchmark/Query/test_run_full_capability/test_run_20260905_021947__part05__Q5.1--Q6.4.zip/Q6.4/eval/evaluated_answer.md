# Q6.4 — Result

**Prompt:** I need the density of pure liquid DMSO at 25 °C for a calculation. If ThermoML does not contain it, use an accepted value from another source.

**[run statistics removed]**

---

## Answer

## Density of Pure Liquid DMSO at 25 °C (298.15 K)

The ThermoML database contains this value from **five independent experimental sources**, all in excellent mutual agreement. Here are the reported values at 298.15 K and near-atmospheric pressure:

| Source (DOI) | Literature | Block | *T* (K) | *P* (kPa) | ρ (kg/m³) |
|---|---|---|---|---|---|
| 10.1007/s10765-008-0395-z | GLOBlit_57 | PROPblock_7 | 298.15 | 101.325 | **1095.271** |
| 10.1007/s10765-009-0648-5 | GLOBlit_86 | PROPblock_4 | 298.15 | 101.0 | **1095.278** |
| 10.1016/j.fluid.2010.01.002 | GLOBlit_779 | PROPblock_3 | 298.15 | 101.325 | **1095.27** |
| 10.1016/j.fluid.2011.02.010 | GLOBlit_938 | PROPblock_3 | 298.15 | 101.0 | **1095.37** |
| 10.1016/j.fluid.2013.05.001 | GLOBlit_1246 | PROPblock_1 | 298.15 | 85.9 | **1095.29** |

### Recommended value for your calculation

> **ρ(DMSO, 25 °C) ≈ 1095.3 kg/m³  (1.0953 g/cm³)**

All five sources fall in the narrow range **1095.27–1095.37 kg/m³**, so any value in that interval is well-supported. The spread of < 0.1 kg/m³ (among four of the five sources) reflects minor differences in sample purity and exact pressure conditions.

### Temperature dependence near 25 °C

From the GLOBlit_86 dataset (DOI 10.1007/s10765-009-0648-5), density decreases nearly linearly with temperature:

| *T* (K) | *P* (kPa) | ρ (kg/m³) |
|---|---|---|
| 293.15 | 101.0 | 1100.306 |
| 298.15 | 101.0 | 1095.278 |
| 303.15 | 101.0 | 1090.253 |

This gives a temperature coefficient of approximately **−1.0 kg·m⁻³·K⁻¹** near 25 °C, which is useful if your calculation involves a slightly different temperature.

### Chemistry note

DMSO (CH₃–SO–CH₃, M = 78.13 g/mol) is denser than water at 25 °C because of its relatively high molecular mass and strong dipole–dipole interactions (μ ≈ 3.96 D). The S=O bond creates a compact, highly polar structure that packs efficiently in the liquid phase.

### Core claims

- Five independent ThermoML sources report the density of pure liquid DMSO at 298.15 K and near-atmospheric pressure in the narrow range 1095.27–1095.37 kg/m³, yielding a recommended value of ρ(DMSO, 25 °C) ≈ 1095.3 kg/m³ (1.0953 g/cm³).
- The spread among four of the five sources is less than 0.1 kg/m³, reflecting minor differences in sample purity and exact pressure conditions.
- Near 25 °C, the density of liquid DMSO decreases approximately linearly with temperature, with a temperature coefficient of approximately −1.0 kg·m⁻³·K⁻¹.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_57 | 10.1007/s10765-008-0395-z | PROPblock_7 |  | Provides a single pure DMSO density measurement of 1095.271 kg/m³ at 298.15 K and 101.325 kPa, directly supporting the recommended value of ~1095.3 kg/m³. |
| GLOBlit_86 | 10.1007/s10765-009-0648-5 | PROPblock_4 |  | Contains 5 pure DMSO density datapoints spanning 288.15–308.15 K at 101.0 kPa, with the 298.15 K value of 1095.278 kg/m³ supporting the answer and the temperature series providing the cited temperature coefficient of approximately −1.0 kg·m⁻³·K⁻¹. |
| GLOBlit_779 | 10.1016/j.fluid.2010.01.002 | PROPblock_3 |  | Reports pure DMSO density with a maximum value of 1095.27 kg/m³ at 298.15 K and 101.325 kPa, corroborating the recommended density value. |
| GLOBlit_938 | 10.1016/j.fluid.2011.02.010 | PROPblock_3 |  | Reports pure DMSO density with a maximum value of 1095.37 kg/m³ at 298.15 K and 101.0 kPa, representing the upper bound of the cited 1095.27–1095.37 kg/m³ range. |
| GLOBlit_1246 | 10.1016/j.fluid.2013.05.001 | PROPblock_1 |  | Provides a single pure DMSO density measurement of 1095.29 kg/m³ at 298.15 K and 85.9 kPa, further supporting the recommended value of ~1095.3 kg/m³. |

### Suggested follow-ups

- Query ThermoML for DMSO density at other temperatures (e.g., 20 °C or 30 °C) to build a temperature-dependent correlation.
- Look up DMSO viscosity at 25 °C in ThermoML if your calculation also requires transport properties.
- Check for DMSO + water mixture density data in ThermoML if your system involves aqueous DMSO solutions.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
