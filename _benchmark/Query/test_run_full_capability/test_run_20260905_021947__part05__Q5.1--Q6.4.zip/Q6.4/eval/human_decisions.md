1. Five pure-DMSO density sources; four101–101.325kPa, fifth85.9kPa; qualitative near-atmospheric wording

   **Your reply:** Include85.9kPa in the qualitative description
