# Q5.1 — Result

**Prompt:** Do you have viscosity data for IPA + water?

**[run statistics removed]**

---

## Answer

Yes! The ThermoML database contains dynamic viscosity data for binary isopropanol (propan-2-ol) + water mixtures from **two literature sources**, totaling **25 data points**.

---

### Source 1 — DOI: 10.1016/j.jct.2019.105880

- **Measurement method:** Falling/rolling sphere viscometry
- **Temperature range:** 288.15–303.15 K
- **Pressure:** 100.0 kPa
- **Composition basis:** Mass fraction of IPA (w = 0.1, 0.2, 0.3)
- **12 data points**

| Temperature (K) | w(IPA) | Viscosity (Pa·s) |
|:---:|:---:|:---:|
| 288.15 | 0.1 | 0.001936 |
| 288.15 | 0.2 | 0.003087 |
| 288.15 | 0.3 | 0.004014 |
| 293.15 | 0.1 | 0.001633 |
| 293.15 | 0.2 | 0.002485 |
| 293.15 | 0.3 | 0.003172 |
| 298.15 | 0.1 | 0.001395 |
| 298.15 | 0.2 | 0.002045 |
| 298.15 | 0.3 | 0.002555 |
| 303.15 | 0.1 | 0.001208 |
| 303.15 | 0.2 | 0.00171 |
| 303.15 | 0.3 | 0.002105 |

---

### Source 2 — DOI: 10.1021/je700700f

- **Measurement method:** Capillary Ubbelohde viscometry
- **Temperature:** 298.15 K (isothermal)
- **Pressure:** 101.0 kPa
- **Composition basis:** Mole fraction of IPA (x = 0 to 1, full range)
- **13 data points** (10 shown below via shape-preserving subset)

| x(IPA) | Viscosity (Pa·s) |
|:---:|:---:|
| 0 | 0.00089 |
| 0.0491 | 0.001718 |
| 0.1008 | 0.002495 |
| 0.2011 | 0.003038 |
| 0.2994 | 0.003087 |
| 0.3992 | 0.002924 |
| 0.6987 | 0.002274 |
| 0.7993 | 0.002153 |
| 0.8998 | 0.002073 |
| 1 | 0.002082 |

---

### Key Chemistry Insights

1. **Non-monotonic viscosity maximum:** The full-composition data at 298.15 K (Source 2) beautifully illustrate the well-known anomalous viscosity behavior of the IPA–water system. The viscosity rises sharply from 0.00089 Pa·s for pure water to a maximum of 0.003087 Pa·s near x(IPA) ≈ 0.30, then gradually decreases to 0.002082 Pa·s for pure IPA. This maximum — roughly 3.5× the viscosity of pure water and 1.5× that of pure IPA — is attributed to enhanced hydrogen-bonding network restructuring and microheterogeneity in the alcohol–water mixture at intermediate compositions.

2. **Temperature dependence:** Source 1 shows that viscosity decreases with increasing temperature at all three mass fractions studied (w = 0.1–0.3), consistent with thermally activated flow. For example, at w = 0.3, viscosity drops from 0.004014 Pa·s at 288.15 K to 0.002105 Pa·s at 303.15 K — nearly halving over just 15 K.

3. **Complementary datasets:** The two sources use different composition bases (mass fraction vs. mole fraction) and different measurement techniques (falling sphere vs. capillary Ubbelohde), providing complementary coverage of the system.

### Core claims

- The ThermoML database contains dynamic viscosity data for binary isopropanol (propan-2-ol) + water mixtures from two literature sources (DOI: 10.1016/j.jct.2019.105880 and DOI: 10.1021/je700700f), totaling 25 data points.
- Source 1 provides 12 data points measured by falling/rolling sphere viscometry at 288.15–303.15 K, 100.0 kPa, at IPA mass fractions w = 0.1, 0.2, and 0.3.
- Source 2 provides 13 data points measured by capillary Ubbelohde viscometry at 298.15 K, 101.0 kPa, spanning the full IPA mole fraction range (x = 0 to 1).
- The full-composition data at 298.15 K show a non-monotonic viscosity maximum near x(IPA) ≈ 0.30, where viscosity reaches 0.003087 Pa·s compared to 0.00089 Pa·s for pure water and 0.002082 Pa·s for pure IPA, attributed to enhanced hydrogen-bonding network restructuring and microheterogeneity.
- Viscosity decreases with increasing temperature at all three mass fractions studied; at w = 0.3, viscosity drops from 0.004014 Pa·s at 288.15 K to 0.002105 Pa·s at 303.15 K.
- The two sources use different composition bases (mass fraction vs. mole fraction) and different measurement techniques, providing complementary coverage of the system.

**Confidence:** high

### Suggested follow-ups

- Would you like to compare these viscosity values with density data for the same IPA + water system?
- Should I look for viscosity data at higher temperatures or pressures for IPA + water?
- Would you like to see excess viscosity or viscosity deviation data for this system?
- Are you interested in viscosity data for other alcohol + water binary mixtures (e.g., methanol or ethanol + water) for comparison?

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
