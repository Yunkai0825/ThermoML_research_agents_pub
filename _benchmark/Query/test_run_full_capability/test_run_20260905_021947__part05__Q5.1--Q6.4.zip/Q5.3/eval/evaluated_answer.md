# Q5.3 — Result

**Prompt:** Find density data for salt water.

**[run statistics removed]**

---

## Answer

## Mass Density Data for Salt Water (NaCl + Water)

The ThermoML database contains **20 data blocks** reporting liquid-phase mass density for the sodium chloride + water binary system, covering multiple composition scales (mole fraction, mass fraction, molality, and molarity).

### Detailed Data — Inspected Block

The most detailed inspected source is from DOI **10.1016/j.fluid.2017.10.034** (PROPblock_3), containing **35 data points** measured via vibrating tube densimetry across five temperatures (288.15–318.15 K) and seven NaCl mole fractions (0.0099–0.0654). Densities range from **1012.1 to 1147.1 kg/m³**.

Representative data points:

| T (K) | x(NaCl) | Density (kg/m³) |
|--------|---------|-----------------|
| 288.15 | 0.0099 | 1022.2 |
| 288.15 | 0.0196 | 1044.7 |
| 288.15 | 0.0654 | 1147.1 |
| 293.15 | 0.0099 | 1021.0 |
| 293.15 | 0.0196 | 1043.2 |
| 293.15 | 0.0654 | 1144.8 |
| 298.15 | 0.0099 | 1019.6 |
| 298.15 | 0.0196 | 1041.6 |
| 298.15 | 0.0385 | 1082.8 |
| 298.15 | 0.0654 | 1142.4 |
| 308.15 | 0.0099 | 1016.2 |
| 308.15 | 0.0196 | 1037.8 |
| 308.15 | 0.0385 | 1078.5 |
| 308.15 | 0.0654 | 1137.4 |
| 318.15 | 0.0099 | 1012.1 |
| 318.15 | 0.0196 | 1033.5 |
| 318.15 | 0.0385 | 1073.7 |
| 318.15 | 0.0654 | 1132.2 |

### Additional Data Sources

Several other blocks are available but were not numerically inspected in detail:

| DOI | Block | Points | Composition Scale | T (K) Range | ρ (kg/m³) Range |
|-----|-------|--------|-------------------|-------------|-----------------|
| 10.1016/j.fluid.2012.04.003 | PROPblock_1 | 6 | Mass fraction (0.02–0.04) | 293.15–313.15 | 1006.1–1026.7 |
| 10.1016/j.jct.2005.03.008 | PROPblock_5 | 4 | Mass fraction (0.005–0.03) | 293.15 (fixed) | 1001.78–1019.58 |
| 10.1016/j.jct.2008.12.011 | PROPblock_6 | 39 | Molarity (1.0–4.0 mol/dm³) | 298.15–323.15 | 1023.15–1146.3 |

In total, 20 blocks span a wide range of conditions and composition representations.

### Chemical Insight

The data illustrate two classic trends for aqueous electrolyte solutions:

- **Concentration effect:** At 298.15 K, density increases from 1019.6 kg/m³ at x(NaCl) = 0.0099 to 1142.4 kg/m³ at x(NaCl) = 0.0654 — roughly a 12% increase. This reflects the higher molar mass of NaCl and the strong ion–dipole interactions between Na⁺/Cl⁻ ions and water molecules, which contract the solution volume relative to ideal mixing.

- **Temperature effect:** At a fixed mole fraction of 0.0654, density decreases from 1147.1 kg/m³ at 288.15 K to 1132.2 kg/m³ at 318.15 K (a drop of ~15 kg/m³ over 30 K), consistent with thermal expansion of the liquid. Even dilute NaCl solutions remain measurably denser than pure water across the entire temperature range studied.

### Core claims

- The ThermoML database contains 20 data blocks reporting liquid-phase mass density for the NaCl + water binary system, covering multiple composition scales (mole fraction, mass fraction, molality, and molarity).
- The most detailed inspected source (DOI 10.1016/j.fluid.2017.10.034, PROPblock_3) contains 35 data points measured via vibrating tube densimetry across five temperatures (288.15–318.15 K) and seven NaCl mole fractions (0.0099–0.0654), with densities ranging from 1012.1 to 1147.1 kg/m³.
- At fixed temperature (298.15 K), density increases with NaCl concentration, from 1019.6 kg/m³ at x(NaCl) = 0.0099 to 1142.4 kg/m³ at x(NaCl) = 0.0654, reflecting the higher molar mass of NaCl and ion–dipole interactions that contract solution volume relative to ideal mixing.
- At fixed mole fraction x(NaCl) = 0.0654, density decreases from 1147.1 kg/m³ at 288.15 K to 1132.2 kg/m³ at 318.15 K, consistent with thermal expansion of the liquid.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2114 | 10.1016/j.fluid.2017.10.034 | PROPblock_3 |  | Primary data source for the answer, providing 35 mass density data points for NaCl + water measured by vibrating tube densimetry across 288.15–318.15 K and mole fractions 0.0099–0.0654, with densities 1012.1–1147.1 kg/m³. Representative data points are quoted directly in the answer table. |
| GLOBlit_1096 | 10.1016/j.fluid.2012.04.003 | PROPblock_1 |  | Supporting source with 6 density data points for NaCl + water at mass fractions 0.02–0.04 and 293.15–313.15 K, with densities 1006.1–1026.7 kg/m³, cited in the additional data sources summary table. |
| GLOBlit_2516 | 10.1016/j.jct.2005.03.008 | PROPblock_5 |  | Supporting source with 4 density data points for NaCl + water at mass fractions 0.005–0.03 at fixed 293.15 K, with densities 1001.78–1019.58 kg/m³, cited in the additional data sources summary table. |
| GLOBlit_3044 | 10.1016/j.jct.2008.12.011 | PROPblock_6 |  | Supporting source with 39 density data points for NaCl + water at molarities 1.0–4.0 mol/dm³ and 298.15–323.15 K, with densities 1023.15–1146.3 kg/m³, cited in the additional data sources summary table. |

### Suggested follow-ups

- Search for density data at higher NaCl concentrations (e.g., near saturation) or at elevated pressures to explore compressibility effects.
- Compare NaCl + water density with other alkali halide aqueous solutions (e.g., KCl, LiCl) to examine ion-size effects on solution density.
- Look for apparent molar volume or excess molar volume data for the NaCl + water system to quantify non-ideal mixing behavior.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
