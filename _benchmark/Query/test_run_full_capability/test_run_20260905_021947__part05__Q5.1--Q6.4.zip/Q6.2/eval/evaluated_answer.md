# Q6.2 — Result

**Prompt:** What is the Gibbs free energy of formation for diamond at 1000 K?

**[run statistics removed]**

---

## Answer

No data found in the ThermoML database for the Gibbs free energy of formation of diamond at 1000 K.

The ThermoML database does not contain any entries for diamond or elemental carbon in any allotropic form. Multiple searches were conducted using the terms "diamond," "carbon," "graphite," the molecular formula "C," and related queries — none returned a match.

The ThermoML database primarily catalogues thermodynamic property measurements for molecular compounds and their mixtures (typically in liquid, gas, or solution phases). Solid elemental allotropes such as diamond fall outside its scope.

The Gibbs free energy of formation for diamond at 1000 K is a standard thermochemical quantity that would typically be found in specialized thermochemical references such as the NIST-JANAF Thermochemical Tables or the NIST Chemistry WebBook, but it is not available in the ThermoML archive.

### Core claims

- No data for the Gibbs free energy of formation of diamond at 1000 K were found in the ThermoML database.
- Multiple searches using terms including 'diamond,' 'carbon,' 'graphite,' and the molecular formula 'C' returned no matches in ThermoML.
- The ThermoML database primarily catalogues thermodynamic property measurements for molecular compounds and their mixtures, and solid elemental allotropes such as diamond fall outside its scope.

**Confidence:** high

### Suggested follow-ups

- Consult the NIST-JANAF Thermochemical Tables or the NIST Chemistry WebBook for the standard Gibbs free energy of formation of diamond at 1000 K.
- Search for solid-phase elemental carbon thermodynamic data in specialized thermochemical databases rather than ThermoML, which primarily covers molecular compounds and mixtures.
<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
