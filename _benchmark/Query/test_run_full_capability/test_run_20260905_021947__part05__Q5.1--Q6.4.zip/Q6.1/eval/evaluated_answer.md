# Q6.1 — Result

**Prompt:** Find data for the binary system propane-1,2,4-triol + water.

**[run statistics removed]**

---

## Answer

## Binary System: Propane-1,2,3-triol (Glycerol) + Water

### Important Note on Nomenclature

The compound **"propane-1,2,4-triol" cannot exist** because propane has only 3 carbon atoms (C₁, C₂, C₃), so position "4" is impossible. The intended compound is **glycerol (propane-1,2,3-triol, CAS 56-81-5)**.

---

### System Overview

The binary system **glycerol + water** is extensively represented in the ThermoML database with **36 property data blocks** across **20 literature sources**, covering **13 distinct thermophysical properties**. Sources span the period 2006–2018 and include journals such as *J. Chem. Thermodynamics*, *J. Chem. Eng. Data*, *Fluid Phase Equilibria*, and *Thermochimica Acta*.

---

### Available Properties

| Property | # Blocks |
|---|---|
| Mass density (kg/m³) | 10 |
| Speed of sound (m/s) | 5 |
| Boiling temperature (K) | 5 |
| Vapor pressure (kPa) | 2 |
| Binary diffusion coefficient (m²/s) | 2 |
| Additional (viscosity, refractive index, excess volumes, etc.) | remaining |

---

### Selected Literature Sources

| DOI | Source ID | Author | Year |
|---|---|---|---|
| 10.1016/j.jct.2017.01.011 | GLOBlit_4951 | Negadi, L. | 2017 |
| 10.1016/j.jct.2018.05.016 | GLOBlit_5254 | Kaur, K. | 2018 |

---

### Representative Data: Mass Density at 100 kPa

From **Negadi (2017)** (DOI: 10.1016/j.jct.2017.01.011, GLOBlit_4951), PROPblock_3 — 44 data points spanning 283.15–313.15 K across the full composition range:

| T (K) | x(water) | ρ (kg/m³) |
|---|---|---|
| 283.15 | 0 | 1267 |
| 283.15 | 0.4042 | 1236 |
| 283.15 | 0.7003 | 1183 |
| 283.15 | 0.7999 | 1148 |
| 283.15 | 0.9024 | 1091 |
| 283.15 | 1 | 1000 |
| 293.15 | 0 | 1261 |
| 293.15 | 0.4042 | 1230 |
| 293.15 | 0.6011 | 1201 |
| 293.15 | 0.7003 | 1177 |
| 293.15 | 0.7999 | 1143 |
| 293.15 | 0.9024 | 1087 |
| 293.15 | 1 | 998 |
| 303.15 | 0 | 1255 |
| 303.15 | 0.4042 | 1224 |
| 303.15 | 0.7003 | 1172 |
| 303.15 | 0.9024 | 1083 |
| 303.15 | 1 | 996 |
| 313.15 | 0 | 1248 |
| 313.15 | 0.4042 | 1218 |
| 313.15 | 0.7003 | 1166 |
| 313.15 | 0.9024 | 1078 |
| 313.15 | 1 | 992 |

---

### Chemical Insight

Glycerol (C₃H₈O₃) is a symmetric triol with hydroxyl groups on all three carbons, enabling extensive hydrogen bonding both with itself and with water. This explains several features of the data:

- **Density decreases monotonically** from pure glycerol (ρ ≈ 1267 kg/m³ at 283.15 K) to pure water (ρ ≈ 1000 kg/m³ at 283.15 K) as the water mole fraction increases, reflecting the replacement of the denser, more strongly self-associated glycerol network with lighter water molecules.

- **Temperature dependence** is consistent across all compositions: density decreases with increasing temperature due to thermal expansion. For pure glycerol, ρ drops from 1267 kg/m³ at 283.15 K to 1248 kg/m³ at 313.15 K (a decrease of ~19 kg/m³ over 30 K). Pure water shows a smaller absolute change, from 1000 to 992 kg/m³ over the same range.

- The glycerol–water system is widely studied because glycerol is a major bio-derived polyol used as a humectant, cryoprotectant, and green solvent. Its aqueous mixtures exhibit significant hydrogen-bonding interactions that strongly influence transport properties (viscosity, diffusion) and volumetric properties (density, excess volume).

### Core claims

- The compound 'propane-1,2,4-triol' cannot exist because propane has only 3 carbon atoms; the intended compound is glycerol (propane-1,2,3-triol, CAS 56-81-5).
- The binary system glycerol + water is represented in the ThermoML database by 36 property data blocks across 20 literature sources (2006–2018), covering 13 distinct thermophysical properties including mass density, speed of sound, boiling temperature, vapor pressure, and binary diffusion coefficient.
- Mass density at 100 kPa decreases monotonically from pure glycerol (ρ ≈ 1267 kg/m³ at 283.15 K) to pure water (ρ ≈ 1000 kg/m³ at 283.15 K) as water mole fraction increases, based on data from Negadi (2017) spanning 283.15–313.15 K across the full composition range.
- Density decreases with increasing temperature at all compositions: for pure glycerol, ρ drops from 1267 kg/m³ at 283.15 K to 1248 kg/m³ at 313.15 K (a decrease of ~19 kg/m³ over 30 K); for pure water, from 1000 to 992 kg/m³ over the same range.
- The extensive hydrogen-bonding capability of glycerol (hydroxyl groups on all three carbons) with itself and with water strongly influences the volumetric and transport properties of the aqueous mixtures.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_4951 | 10.1016/j.jct.2017.01.011 | PROPblock_3 |  | This block provides the 44-point mass density dataset for the glycerol + water binary system at 100 kPa, spanning 283.15–313.15 K and the full mole-fraction range (0–1), with density values from 992 to 1267 kg/m³. The answer's representative data table is drawn directly from this block. |

### Suggested follow-ups

- Retrieve speed-of-sound data for glycerol + water from the additional blocks identified across the 20 literature sources.
- Compare excess molar volume data across multiple sources to assess consistency of volumetric mixing behavior.
- Investigate transport properties (viscosity, binary diffusion coefficient) for glycerol + water as a function of temperature and composition.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
