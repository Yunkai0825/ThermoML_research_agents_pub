# Q5.4 — Result

**Prompt:** I'm looking for heat capacity data for butanol.

**[run statistics removed]**

---

## Answer

## Molar Heat Capacity (Cp) Data for Butanol Isomers

The ThermoML database contains molar heat capacity at constant pressure (Cp) data for **three of the four butanol isomers**. No Cp data were found for **tert-butanol** (2-methylpropan-2-ol).

---

### 1. 1-Butanol (butan-1-ol)

The most extensively covered isomer, with **16 data blocks** (7 pure-component, 9 binary mixtures), all in the liquid phase. Temperature coverage spans approximately 273–353 K, with pressures from atmospheric up to 25,000 kPa.

**Representative data** at atmospheric pressure (101.3 kPa), liquid phase, from DOI: 10.1016/j.jct.2004.09.007 (29 total data points):

| T (K) | Cp (J·K⁻¹·mol⁻¹) |
|------:|------------------:|
| 285.15 | 168.64 |
| 293.15 | 173.56 |
| 300.65 | 178.53 |
| 313.15 | 187.99 |
| 328.15 | 200.45 |
| 338.15 | 209.17 |
| 343.15 | 213.82 |
| 348.15 | 218.32 |
| 353.15 | 222.81 |

Cp increases monotonically from 168.64 to 222.81 J·K⁻¹·mol⁻¹ over this range, reflecting the growing contribution of intermolecular hydrogen-bonding disruption and increased molecular motion with temperature.

---

### 2. 2-Butanol (butan-2-ol)

**5 data blocks** found (3 pure-component, 2 binary mixtures), liquid phase.

**Data across a temperature × pressure grid** from DOI: 10.1016/j.jct.2017.03.006 (12 data points):

| T (K) | P (kPa) | Cp (J·K⁻¹·mol⁻¹) |
|------:|--------:|------------------:|
| 293.15 | 100 | 189.1 |
| 293.15 | 5000 | 187.1 |
| 293.15 | 10000 | 185.5 |
| 293.15 | 15000 | 185.2 |
| 293.15 | 20000 | 183.6 |
| 293.15 | 25000 | 182.7 |
| 313.15 | 100 | 214.9 |
| 313.15 | 5000 | 213.1 |
| 313.15 | 10000 | 211.1 |
| 313.15 | 15000 | 209.4 |
| 313.15 | 20000 | 207.2 |
| 313.15 | 25000 | 204.9 |

Cp decreases with increasing pressure (e.g., 189.1 → 182.7 J·K⁻¹·mol⁻¹ at 293.15 K from 100 to 25,000 kPa), consistent with compression reducing the configurational contribution to heat capacity. The overall range is 182.7–214.9 J·K⁻¹·mol⁻¹.

---

### 3. Isobutanol (2-methyl-1-propanol)

Only **1 data block** found (DOI: 10.1021/je049738c), containing a single liquid-phase data point measured by flow calorimetry at 298.15 K and 101.325 kPa. The block metadata reports a Cp value of **181.9 J·K⁻¹·mol⁻¹**.

---

### 4. tert-Butanol (2-methylpropan-2-ol)

**No molar heat capacity data found** in the ThermoML database for this isomer.

---

### Summary Comparison at Near-Ambient Conditions

| Isomer | T (K) | P (kPa) | Cp (J·K⁻¹·mol⁻¹) | Source DOI |
|--------|------:|--------:|------------------:|-----------|
| 1-Butanol | 293.15 | 101.3 | 173.56 | 10.1016/j.jct.2004.09.007 |
| 2-Butanol | 293.15 | 100 | 189.1 | 10.1016/j.jct.2017.03.006 |
| Isobutanol | 298.15 | 101.325 | 181.9 | 10.1021/je049738c |
| tert-Butanol | — | — | No data | — |

**Chemical insight:** At near-ambient conditions, 2-butanol (secondary alcohol) has the highest Cp (189.1 J·K⁻¹·mol⁻¹), followed by isobutanol (181.9 J·K⁻¹·mol⁻¹) and then 1-butanol (173.56 J·K⁻¹·mol⁻¹). The higher Cp of the branched isomers relative to the linear 1-butanol reflects differences in how the hydroxyl group position and carbon-chain branching affect hydrogen-bonding networks and rotational degrees of freedom. Branching tends to weaken cooperative hydrogen bonding, requiring more energy input per degree of temperature rise to disrupt the less-ordered liquid structure.

### Core claims

- The ThermoML database contains molar heat capacity at constant pressure (Cp) data for three of the four butanol isomers: 1-butanol, 2-butanol, and isobutanol; no Cp data were found for tert-butanol.
- For 1-butanol in the liquid phase at atmospheric pressure (~101.3 kPa), Cp increases monotonically from 168.64 J·K⁻¹·mol⁻¹ at 285.15 K to 222.81 J·K⁻¹·mol⁻¹ at 353.15 K.
- For 2-butanol in the liquid phase, Cp decreases with increasing pressure (e.g., 189.1 → 182.7 J·K⁻¹·mol⁻¹ at 293.15 K from 100 to 25,000 kPa) and increases with temperature, spanning an overall range of 182.7–214.9 J·K⁻¹·mol⁻¹.
- For isobutanol (2-methyl-1-propanol), only a single liquid-phase data point was found: Cp of 181.9 J·K⁻¹·mol⁻¹ at 298.15 K and 101.325 kPa.
- At near-ambient conditions (~293–298 K, ~101 kPa), 2-butanol has the highest reported Cp (189.1 J·K⁻¹·mol⁻¹), followed by isobutanol (181.9 J·K⁻¹·mol⁻¹) and 1-butanol (173.56 J·K⁻¹·mol⁻¹).

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2451 | 10.1016/j.jct.2004.09.007 | PROPblock_2 |  | This block contains molar heat capacity at constant pressure data for butan-1-ol (liquid phase) with 29 data points spanning 285.15–353.15 K at 101.3 kPa, with Cp ranging from 168.64 to 222.81 J/K/mol, directly matching the 1-butanol data presented in the answer. |

### Suggested follow-ups

- Search for tert-butanol (2-methylpropan-2-ol) heat capacity data in other databases such as NIST WebBook or DIPPR, as no Cp data were found in ThermoML for this isomer.
- Explore excess molar heat capacity data for butanol + solvent binary mixtures available in ThermoML to understand solvation effects.
- Compare heat capacity data for butanol isomers at higher pressures (up to 25 MPa) using the pressure-dependent datasets identified for 1-butanol and 2-butanol.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
