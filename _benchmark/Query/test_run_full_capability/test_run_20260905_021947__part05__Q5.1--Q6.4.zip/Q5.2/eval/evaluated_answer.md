# Q5.2 — Result

**Prompt:** What data is available for glycol + water mixtures?

**[run statistics removed]**

---

## Answer

## Glycol + Water Binary Mixture Data in the ThermoML Database

The ThermoML database contains extensive thermodynamic and transport property data for **four glycol + water binary systems**, totaling **161 property blocks** across **81 literature sources** (some shared across systems) with **10,081 data points**. These glycol–water mixtures are of major industrial importance as antifreeze formulations, heat-transfer fluids, and gas-dehydration agents.

---

### Cross-System Summary

| Glycol + Water System | Blocks | Papers | Data Points | T range (K) | P range (kPa) |
|---|---|---|---|---|---|
| Ethylene glycol (1,2-ethanediol) | 59 | 32 | 2,584 | 258.32 – 573.23 | 50.0 – 350,200.0 |
| Propylene glycol (1,2-propanediol) | 34 | 18 | 1,780 | 253.15 – 573.19 | 100.0 – 350,000.0 |
| Diethylene glycol | 28 | 15 | 2,079 | 278.15 – 573.184 | 50.0 – 30,500.0 |
| Triethylene glycol | 40 | 16 | 3,638 | 278.15 – 573.183 | 50.0 – 30,510.0 |
| **Total** | **161** | **81*** | **10,081** | — | — |

\*Some papers cover multiple glycol systems, so the unique paper count is lower.

---

### 1. Ethylene Glycol (1,2-Ethanediol) + Water

The most widely studied system, with **59 blocks from 32 papers** and **2,584 data points**, spanning 258.32–573.23 K and up to 350,200 kPa (~350 MPa).

**Properties measured (by number of blocks):**

| Property | Blocks |
|---|---|
| Mass density (kg/m³) | 16 |
| Speed of sound (m/s) | 8 |
| Viscosity (Pa·s) | 7 |
| Binary diffusion coefficient (m²/s) | 5 |
| Surface tension liquid–gas (N/m) | 4 |
| Vapor or sublimation pressure (kPa) | 3 |
| Boiling temperature at pressure P (K) | 3 |
| Mole fraction | 2 |
| Refractive index (Na D-line) | 2 |
| Specific volume (m³/kg) | 2 |

**Top literature sources:**

| DOI | Blocks | Points |
|---|---|---|
| 10.1016/j.jct.2018.02.022 | 3 | 456 |
| 10.1021/je4001203 | 2 | 276 |
| 10.1021/je020140j | 3 | 249 |
| 10.1021/acs.jced.6b00526 | 3 | 236 |
| 10.1016/j.fluid.2013.06.041 | 2 | 214 |

---

### 2. Propylene Glycol (1,2-Propanediol) + Water

**34 blocks from 18 papers**, **1,780 data points**, spanning 253.15–573.19 K and up to 350,000 kPa (~350 MPa).

**Properties measured (by number of blocks):**

| Property | Blocks |
|---|---|
| Mass density (kg/m³) | 10 |
| Speed of sound (m/s) | 4 |
| Viscosity (Pa·s) | 4 |
| Excess molar volume (m³/mol) | 2 |
| Molar heat capacity at constant pressure (J/K/mol) | 2 |
| Thermal conductivity (W/m/K) | 2 |
| Specific volume (m³/kg) | 2 |
| Excess molar heat capacity (J/K/mol) | 1 |
| Surface tension liquid–gas (N/m) | 1 |
| Excess molar enthalpy of mixing (kJ/mol) | 1 |

**Top literature sources:**

| DOI | Blocks | Points |
|---|---|---|
| 10.1021/je0340755 | 3 | 375 |
| 10.1021/acs.jced.8b00403 | 3 | 291 |
| 10.1021/je201184b | 2 | 212 |
| 10.1016/j.fluid.2013.06.041 | 2 | 185 |
| 10.1016/j.fluid.2014.12.040 | 2 | 168 |

---

### 3. Diethylene Glycol + Water

**28 blocks from 15 papers**, **2,079 data points**, spanning 278.15–573.184 K and up to 30,500 kPa.

**Properties measured (by number of blocks):**

| Property | Blocks |
|---|---|
| Mass density (kg/m³) | 10 |
| Speed of sound (m/s) | 6 |
| Viscosity (Pa·s) | 4 |
| Binary diffusion coefficient (m²/s) | 2 |
| Excess molar enthalpy of mixing (kJ/mol) | 2 |
| Molar heat capacity at constant pressure (J/K/mol) | 1 |
| Boiling temperature at pressure P (K) | 1 |
| Refractive index (Na D-line) | 1 |
| Thermal conductivity (W/m/K) | 1 |

**Top literature sources:**

| DOI | Blocks | Points |
|---|---|---|
| 10.1016/j.jct.2016.07.016 | 1 | 588 |
| 10.1016/j.jct.2018.02.022 | 3 | 456 |
| 10.1021/je700672f | 2 | 286 |
| 10.1021/je1009976 | 2 | 170 |
| 10.1021/acs.jced.5b00498 | 2 | 140 |

---

### 4. Triethylene Glycol + Water

The **largest dataset** with **40 blocks from 16 papers** and **3,638 data points**, spanning 278.15–573.183 K and up to 30,510 kPa.

**Properties measured (by number of blocks):**

| Property | Blocks |
|---|---|
| Mass density (kg/m³) | 10 |
| Refractive index (other wavelength) | 9 |
| Speed of sound (m/s) | 6 |
| Boiling temperature at pressure P (K) | 3 |
| Viscosity (Pa·s) | 3 |
| Binary diffusion coefficient (m²/s) | 2 |
| Mole fraction | 2 |
| Joule-Thomson coefficient (K/kPa) | 1 |
| Molar heat capacity at constant pressure (J/K/mol) | 1 |
| Excess molar enthalpy of mixing (kJ/mol) | 1 |

**Top literature sources:**

| DOI | Blocks | Points |
|---|---|---|
| 10.1016/j.fluid.2015.07.030 | 12 | 1,370 |
| 10.1016/j.jct.2015.05.024 | 2 | 667 |
| 10.1016/j.jct.2016.07.016 | 1 | 598 |
| 10.1016/j.jct.2018.02.022 | 3 | 432 |
| 10.1021/acs.jced.5b00498 | 2 | 140 |

---

### Key Observations & Chemical Context

- **Mass density** is the most commonly measured property across all four systems (46 blocks total), reflecting its central importance for engineering design of glycol–water heat-transfer fluids and antifreeze formulations.
- **Speed of sound** and **dynamic viscosity** are the next most common, each appearing in all four systems — critical for acoustic and flow characterization.
- **Ethylene glycol + water** has the broadest literature coverage (32 papers), consistent with its dominant industrial role as an automotive antifreeze and coolant.
- **Triethylene glycol + water** has the largest single dataset (3,638 points), driven largely by one comprehensive study (DOI: 10.1016/j.fluid.2015.07.030) contributing 1,370 points across 12 blocks — reflecting triethylene glycol's importance in natural gas dehydration.
- **Ethylene glycol** and **propylene glycol** systems extend to much higher pressures (up to ~350 MPa), likely from high-pressure density studies relevant to deep-well and high-pressure process conditions.
- All four systems reach similar upper temperatures (~573 K), covering conditions relevant to both ambient and elevated-temperature industrial processes.
- **Transport properties** (diffusion coefficients, thermal conductivity) and **excess thermodynamic properties** (excess molar enthalpy, excess molar volume) are available but less common than volumetric and acoustic properties.
- Several literature sources span multiple glycol systems (e.g., DOI: 10.1016/j.jct.2018.02.022 covers ethylene glycol, diethylene glycol, and triethylene glycol with water), enabling direct cross-system comparisons under identical experimental conditions.

### Core claims

- The ThermoML database contains thermodynamic and transport property data for four glycol + water binary systems (ethylene glycol, propylene glycol, diethylene glycol, and triethylene glycol), totaling 161 property blocks across 81 literature sources with 10,081 data points.
- Ethylene glycol + water is the most widely studied system by literature coverage (59 blocks from 32 papers, 2,584 data points), spanning 258.32–573.23 K and up to 350,200.0 kPa.
- Triethylene glycol + water has the largest single dataset (40 blocks from 16 papers, 3,638 data points), driven largely by one study (DOI: 10.1016/j.fluid.2015.07.030) contributing 1,370 points across 12 blocks.
- Mass density is the most commonly measured property across all four systems (46 blocks total), followed by speed of sound and dynamic viscosity, which appear in all four systems.
- Ethylene glycol and propylene glycol systems extend to much higher pressures (up to ~350 MPa) compared to diethylene glycol (up to 30,500.0 kPa) and triethylene glycol (up to 30,510.0 kPa).
- All four systems reach similar upper temperatures (~573 K), covering conditions relevant to both ambient and elevated-temperature industrial processes.
- Transport properties (diffusion coefficients, thermal conductivity) and excess thermodynamic properties (excess molar enthalpy, excess molar volume) are available but less common than volumetric and acoustic properties.

**Confidence:** medium

### Suggested follow-ups

- Retrieve detailed property data for a specific glycol + water system, e.g., 'Show all mass density data for ethylene glycol + water mixtures'
- Compare viscosity data across all four glycol + water systems at a specific temperature range
- Look up excess thermodynamic properties (excess molar enthalpy, excess molar volume) for propylene glycol + water
- Investigate high-pressure density data for ethylene glycol + water up to 350 MPa
- Search for glycol + water ternary systems (e.g., ethylene glycol + propylene glycol + water)
- Find vapor-liquid equilibrium data for triethylene glycol + water relevant to natural gas dehydration

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
