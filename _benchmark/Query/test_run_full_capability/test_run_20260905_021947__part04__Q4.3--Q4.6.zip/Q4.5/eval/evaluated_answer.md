# Q4.5 — Result

**Prompt:** How strongly does water + ethylene glycol deviate from ideal mixing in its transport properties, and what's the chemical reason behind?

**[run statistics removed]**

---

## Answer

## Non-Ideal Transport Properties of Water + Ethylene Glycol Mixtures

The water + ethylene glycol (1,2-ethanediol) binary system shows **strongly non-ideal mixing** in its transport properties, and the ThermoML database provides both viscosity and thermodynamic data that quantify and explain this behavior.

---

### 1. Dynamic Viscosity — Large Positive Deviations

From **GLOBlit_6951::PROPblock_18** (DOI: 10.1021/acs.jced.6b00526), 33 data points were measured by falling/rolling sphere viscometry at 100.0 kPa across the full composition range.

**Viscosity across composition at 293.15 K:**

| x(water) | Viscosity (Pa·s) |
|-----------|-----------------|
| 0 (pure EG) | 0.02113 |
| 0.2014 | 0.01495 |
| 0.4011 | 0.01005 |
| 0.6995 | 0.004584 |
| 1.0 (pure water) | 0.000949 |

**At 298.15 K:**

| x(water) | Viscosity (Pa·s) |
|-----------|-----------------|
| 0 (pure EG) | 0.01724 |
| 0.2014 | 0.01219 |
| 0.4011 | 0.00831 |
| 0.6995 | 0.003884 |
| 1.0 (pure water) | 0.000843 |

**At 303.15 K:**

| x(water) | Viscosity (Pa·s) |
|-----------|-----------------|
| 0 (pure EG) | 0.01423 |
| 0.2014 | 0.01014 |
| 0.4969 | 0.005653 |
| 1.0 (pure water) | 0.000755 |

#### How large is the deviation?

Pure ethylene glycol is roughly **22× more viscous** than pure water at 293.15 K (0.02113 vs. 0.000949 Pa·s; ratio derived from the two endpoint values). Under a log-linear (Arrhenius) ideal mixing rule, the viscosity at x(water) = 0.4011 would be approximately 0.006 Pa·s (derived: exp[0.5989 × ln(0.02113) + 0.4011 × ln(0.000949)]). The **measured value is 0.01005 Pa·s** — a substantial **positive deviation of roughly +65%** above the ideal estimate. This means the mixture is significantly more viscous than one would predict from a simple interpolation between the pure-component values.

Temperature strongly reduces viscosity at all compositions: pure EG drops from 0.02113 Pa·s at 293.15 K to 0.01423 Pa·s at 303.15 K — about a 33% decrease over just 10 K (derived from the inspected endpoint values).

---

### 2. Excess Molar Enthalpy — Thermodynamic Confirmation

From **GLOBlit_5843::PROPblock_1** (DOI: 10.1016/j.tca.2009.06.004), 13 Calvet calorimetry data points at 298.15 K and 101.0 kPa:

| x(water) | Hᴱ (kJ/mol) |
|-----------|-------------|
| 0.1014 | −0.174 |
| 0.1994 | −0.337 |
| 0.2091 | −0.347 |
| 0.3051 | −0.48 |
| 0.3674 | −0.559 |
| 0.3995 | −0.59 |
| 0.4807 | −0.64 |
| 0.5455 | −0.666 |
| 0.6144 | −0.698 |
| 0.669 | **−0.715** |
| 0.7949 | −0.681 |
| 0.8656 | −0.57 |
| 0.915 | −0.423 |

Hᴱ is **negative (exothermic) across the entire composition range**, confirming that mixing water and ethylene glycol is energetically favorable. The most exothermic point is **−0.715 kJ/mol at x(water) = 0.669**, corresponding to roughly a **2:1 water-to-EG molar ratio**.

---

### 3. The Chemical Explanation

The non-ideal transport behavior has a clear molecular origin: **extensive cross-species hydrogen bonding**.

- **Ethylene glycol has two hydroxyl (–OH) groups** on adjacent carbons, making it both a strong hydrogen-bond donor and acceptor. Each –OH group can form hydrogen bonds with water molecules.

- **The Hᴱ minimum at x(water) ≈ 0.67** (a 2:1 water:EG ratio) is chemically significant — it matches the stoichiometry where each of EG's two –OH groups is optimally solvated by one water molecule. This is the composition of maximum cross-interaction.

- **The asymmetry of the Hᴱ curve** (minimum shifted toward the water-rich side rather than at x = 0.5) directly reflects this 2:1 stoichiometry.

- **Why positive excess viscosity?** When water and EG mix, they form a more extensive and structured hydrogen-bond network than exists in either pure component alone. These cross-linked H-bond clusters resist flow more effectively than the individual pure-component networks, producing viscosities that exceed the ideal mixing prediction. The same favorable interactions that release enthalpy (negative Hᴱ) also create more rigid, cooperative molecular structures that increase viscous drag.

- **Why is the Hᴱ magnitude moderate** (|Hᴱ|_max = 0.715 kJ/mol)? Both pure water and pure ethylene glycol already possess extensive hydrogen-bond networks. Mixing requires **partial disruption** of these existing networks before new, favorable water–EG bonds can form. The observed Hᴱ is the net balance: the energy cost of breaking some water–water and EG–EG bonds is partially offset by the energy released from forming water–EG bonds. The net exotherm confirms that the cross-interactions are thermodynamically preferred, but the magnitude is tempered by the disruption cost.

### Summary

The water + ethylene glycol system deviates strongly from ideal mixing in its viscosity — measured values exceed log-linear ideal predictions by roughly 65% at intermediate compositions. This positive excess viscosity is driven by the formation of extensive cross-species hydrogen-bond networks, thermodynamically confirmed by uniformly negative excess molar enthalpies peaking at −0.715 kJ/mol near a 2:1 water:EG molar ratio that matches the stoichiometry of EG's two hydroxyl groups.

### Core claims

- The water + ethylene glycol binary system exhibits strongly non-ideal mixing in its transport properties, with measured dynamic viscosities showing large positive deviations above log-linear (Arrhenius) ideal mixing predictions — approximately +65% at intermediate compositions near x(water) ≈ 0.4 at 293.15 K.
- Pure ethylene glycol is roughly 22× more viscous than pure water at 293.15 K (0.02113 vs. 0.000949 Pa·s), and temperature strongly reduces viscosity at all compositions, with pure EG dropping from 0.02113 Pa·s at 293.15 K to 0.01423 Pa·s at 303.15 K.
- Excess molar enthalpy (Hᴱ) at 298.15 K is negative (exothermic) across the entire composition range, with a minimum of −0.715 kJ/mol at x(water) = 0.669, corresponding to a roughly 2:1 water-to-EG molar ratio consistent with the stoichiometry of EG's two hydroxyl groups.
- The asymmetry of the Hᴱ curve, with its minimum shifted toward the water-rich side rather than at x = 0.5, reflects the 2:1 stoichiometry where each of EG's two –OH groups is optimally solvated by one water molecule.
- The positive excess viscosity is attributed to extensive cross-species hydrogen bonding between water and ethylene glycol, forming a more structured hydrogen-bond network than in either pure component, which resists flow more effectively and is thermodynamically confirmed by the uniformly negative Hᴱ values.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18 |  | Provides 33 dynamic viscosity data points for the water + 1,2-ethanediol binary system across the full mole-fraction range (0–1) at 293.15–303.15 K and 100.0 kPa, which the answer uses to demonstrate large positive deviations from ideal mixing (~65% excess viscosity at intermediate compositions). |
| GLOBlit_5843 | 10.1016/j.tca.2009.06.004 | PROPblock_1 |  | Provides 13 excess molar enthalpy measurements for the water + 1,2-ethanediol binary at 298.15 K and 101.0 kPa, showing uniformly negative values with a minimum of −0.715 kJ/mol near x(water) = 0.669, which the answer uses to thermodynamically confirm the strong cross-species hydrogen bonding that drives the non-ideal viscosity behavior. |

### Suggested follow-ups

- How does the excess viscosity of water + ethylene glycol compare quantitatively to water + propylene glycol or water + glycerol systems?
- Is there ThermoML data on the diffusion coefficients of water + ethylene glycol mixtures to further characterize transport non-ideality?
- How does the excess molar volume of water + ethylene glycol correlate with the excess viscosity across composition?

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
