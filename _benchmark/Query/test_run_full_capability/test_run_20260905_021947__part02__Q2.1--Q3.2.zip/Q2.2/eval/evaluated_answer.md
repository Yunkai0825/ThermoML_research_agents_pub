# Q2.2 — Result

**Prompt:** I am deciding whether to validate a liquid-mixture viscosity model first on binary or ternary systems. Which class has enough experimental measurements across composition to provide the stronger test?

**[run statistics removed]**

---

## Answer

## Recommendation: Start with Binary Systems — They Offer the Stronger Initial Validation Test

Based on the dynamic viscosity (Viscosity, Pa·s) data holdings in ThermoML, **binary liquid mixtures** provide the stronger foundation for first-pass model validation, and here is why:

### Data Availability at a Glance

| Metric | Binary (2-component) | Ternary (3-component) |
|---|---|---|
| Distinct literature sources | 1176 | 429 |
| Property blocks | 3294 | 1081 |
| Total data points | 137,229 | 81,066 |
| Avg. data points per block | ~41.7 | ~75.0 |
| Temperature range (K) | 199.918 – 1173.0 | 20.0 – 1023.0 |
| Pressure range (kPa) | 0.0 – 387,800.0 | 0.0 – 196,130.0 |

### Why Binary Systems Win for Initial Validation

1. **Far greater diversity of chemical systems.** With 1176 independent literature sources and 3294 property blocks, binary data cover a much wider variety of solute–solvent pairs — polar + nonpolar, associating + inert, ionic liquids + molecular solvents, etc. This diversity is critical for stress-testing whether a model generalises across chemical families, not just across compositions within one mixture.

2. **Broader thermodynamic conditions.** Binary data span temperatures from ~200 K to 1173 K and pressures up to ~388 MPa, compared with ~20–1023 K and ~196 MPa for ternary data. A model validated over these wider windows is more credible.

3. **Simpler failure diagnosis.** In a binary system the composition variable is one-dimensional (mole fraction x₁), so any systematic deviation between model and experiment can be mapped directly against x₁. In a ternary system, deviations live on a two-dimensional Gibbs triangle, making it harder to isolate whether the error comes from a particular binary interaction parameter or from a higher-order cross term.

4. **Sufficient composition density per block.** Although ternary blocks are denser (~75 points/block vs. ~42), binary blocks still typically sweep 10–20+ mole-fraction values across the full 0 → 1 range at a given temperature — more than enough to reveal curvature, inflection points, or extrema in η(x) that challenge mixing rules.

### When to Move to Ternary Validation

Ternary data become essential in a **second validation stage**, once the model passes binary tests. Ternary viscosity is a much more demanding test of multi-body interaction terms (e.g., the Wohl or Cibulka ternary contribution in excess-property models). The 81,066 ternary data points across 429 sources and 1081 blocks are ample for this purpose, and the higher composition density per block (~75 points) means individual ternary datasets map the Gibbs triangle well.

Notable large datasets for each stage:

- **Binary:** DOI 10.1021/acs.jced.7b00221 (GLOBlit_7152) — 25 blocks, 1448 points; DOI 10.1016/j.jct.2011.02.018 (GLOBlit_3363) — 6 blocks, 848 points.
- **Ternary:** DOI 10.1021/acs.jced.5b00845 (GLOBlit_6743) — 48 blocks, 5168 points; DOI 10.1021/je5001523 (GLOBlit_10411) — 17 blocks, 1604 points.

### Bottom Line

**Binary systems first.** They give you 3× more independent sources, 3× more property blocks, 70% more total data points, wider T/P coverage, and — crucially — far greater chemical diversity, all while keeping failure diagnosis straightforward. Reserve the ternary corpus as the rigorous follow-up test that probes whether your model's multi-component mixing rules hold up in higher-dimensional composition space.

### Core claims

- For initial validation of dynamic viscosity models using ThermoML data, binary liquid mixtures are recommended over ternary mixtures because they offer greater diversity of chemical systems (1176 vs. 429 distinct literature sources; 3294 vs. 1081 property blocks), broader thermodynamic coverage (temperatures ~200–1173 K and pressures up to ~388 MPa for binary vs. ~20–1023 K and ~196 MPa for ternary), and simpler one-dimensional composition-based failure diagnosis.
- Binary systems provide 137,229 total viscosity data points across 1176 independent sources, while ternary systems provide 81,066 points across 429 sources, giving binary data roughly 3× more independent sources and property blocks.
- Ternary viscosity data should be used in a second validation stage to test multi-component mixing rules and higher-order interaction terms, leveraging the higher average composition density per block (~75 points/block for ternary vs. ~42 for binary) that maps the Gibbs triangle well.
- Although ternary blocks have higher average data density per block (~75 vs. ~42 points), binary blocks still typically contain sufficient mole-fraction sweeps to reveal curvature, inflection points, or extrema in viscosity as a function of composition.

**Confidence:** high

### Suggested follow-ups

- Drill into specific chemical families (e.g., alcohol+water, ionic-liquid+molecular-solvent) within the binary corpus to check whether composition coverage is uniform or clustered around equimolar.
- Compare the ternary datasets against their constituent binary sub-systems to verify internal consistency before using ternary data as a second-stage validation set.
- Examine pressure-dependent binary viscosity blocks separately, since high-pressure data (>100 MPa) may be sparse and could bias validation statistics if pooled with atmospheric-pressure measurements.
<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
