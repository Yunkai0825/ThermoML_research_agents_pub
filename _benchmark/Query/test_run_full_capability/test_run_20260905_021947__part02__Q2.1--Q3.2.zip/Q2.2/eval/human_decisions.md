1. Typical full binary0-1composition sweeps with11-21points or10-20+points:5555/12384 and5753/12384 across all fixedT/P groups;5555/6713 and5753/6713 among full-endpoint groups.

   **Your reply:** Require a majority of all binary measurement groups

2. | Pressure range (kPa) | 0.0 – 387,800.0 | 0.0 – 196,130.0 |

   **Your reply:** Include reported experimental pressure coordinates; retain the gas-loading label

3. the higher composition density per block (~75 points) means individual ternary datasets map the Gibbs triangle well higher average composition density per block (~75 points/block for ternary vs. ~42 for binary) that maps the Gibbs triangle well

   **Your reply:** Qualitative adequacy judgment; report measured coverage separately
