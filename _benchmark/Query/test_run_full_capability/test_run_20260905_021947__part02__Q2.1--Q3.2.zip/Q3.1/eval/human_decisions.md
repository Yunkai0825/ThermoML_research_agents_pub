1. Five occurrences state 101.0 kPa for paired density and viscosity blocks. The named density blocks have the unique fixed pressure 101.3 kPa; the paired viscosity blocks have 101 kPa. Should a directly asserted block constraint be compared with its unique stored constraint (density near miss), or should the current coordinate-matching rule require a point at 101.0 kPa first (density not found/miss)?

   **Your reply:** A — Compare the pressure assertion with each block’s fixed pressure; mark the density condition as a near miss (Recommended)
