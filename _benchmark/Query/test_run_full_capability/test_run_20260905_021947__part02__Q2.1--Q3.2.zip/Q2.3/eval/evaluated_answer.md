# Q2.3 — Result

**Prompt:** For validating a liquid-density model near room temperature, should I use ethanol + water or methanol + water? Which system has measurements over the broader composition and temperature ranges?

**[run statistics removed]**

---

## Answer

## Ethanol + Water vs. Methanol + Water: Mass Density Data Comparison

For validating a liquid-density model near room temperature, **ethanol + water is the stronger choice** based on the ThermoML database holdings. It offers substantially more data, broader coverage in temperature and pressure, and denser composition grids at near-ambient conditions. Here is a side-by-side comparison:

### Dataset Size and Coverage

| Feature | Ethanol + Water | Methanol + Water |
|---|---|---|
| Data blocks | 29 | ~18 (search-level estimate) |
| Distinct DOIs | 22 | ~15 (search-level estimate) |
| Total data points | ~2,920 | ~1,610 (search-level estimate) |
| Temperature range | 268.1–618.2 K | 287.15–417.15 K (block-verified) |
| Pressure range | 100–40,000 kPa | 101–29,927 kPa (block-verified) |
| Composition range | 0–1 (full) | 0–1 (full) |

### Near Room Temperature (298.15 K, atmospheric pressure)

**Ethanol + water** has **54 composition points** at 298.15 K and 100 kPa in a single block alone (GLOBlit_220, PROPblock_2; DOI 10.1016/j.fluid.2004.11.019), with density spanning from 995.3 kg/m³ at x(ethanol) = 0.003 to 785.7 kg/m³ at x(ethanol) = 1.0.

**Methanol + water** has **13 composition points** at 298.15 K and 101 kPa (GLOBlit_2825, PROPblock_10; DOI 10.1016/j.jct.2007.05.004), with density spanning from 787.2 kg/m³ (pure methanol) to 997.05 kg/m³ (pure water).

Representative density values at 298.15 K for both systems:

| x(alcohol) ≈ | Ethanol + Water ρ (kg/m³) | Methanol + Water ρ (kg/m³) |
|---|---|---|
| 0 (pure water) | 995.3 (at x = 0.003) | 997.05 |
| ~0.1 | 954.9 (x = 0.1296) | 804.11 (at x(water) = 0.0993, i.e. x(MeOH) ≈ 0.90) — *see note* |
| ~0.3 | 904.5 (x = 0.3009) | 840.79 (at x(water) = 0.2983, i.e. x(MeOH) ≈ 0.70) |
| ~0.5 | 859.3 (x = 0.498) | 881.69 (at x(water) = 0.5003, i.e. x(MeOH) ≈ 0.50) |
| 1.0 (pure alcohol) | 785.7 | 787.2 |

*Note: The methanol + water block reports composition as x(water), so x(methanol) = 1 − x(water). Pure methanol densities are very similar (785.7 vs. 787.2 kg/m³), as expected for these two small alcohols.*

### Why Ethanol + Water Is Preferred for Model Validation

1. **~1.8× more data points** (~2,920 vs. ~1,610), providing better statistical power for parameter fitting and residual analysis.

2. **Broader temperature range** (268.1–618.2 K vs. 287.15–417.15 K verified), spanning from sub-ambient to supercritical-like conditions — a 350 K window versus ~130 K.

3. **Broader pressure range** (100–40,000 kPa vs. 101–29,927 kPa verified), reaching 40 MPa.

4. **Much denser composition grid near room temperature**: 54 mole-fraction points at 298.15 K in a single ethanol + water block versus 13 for methanol + water. This dense grid is critical for capturing the non-linear excess volume behavior that challenges density models.

5. **More independent sources** (22 DOIs vs. ~15), allowing cross-validation between laboratories.

### Chemistry Insight

Both systems exhibit the classic alcohol–water density behavior: a monotonic decrease from the high density of pure water (~997 kg/m³) to the lower density of the pure alcohol (~786–787 kg/m³). The non-linearity is most pronounced in the water-rich region, where even small additions of alcohol strongly disrupt water's hydrogen-bonding network, producing significant excess volumes. Ethanol, being larger and more hydrophobic than methanol, tends to produce larger excess volume effects, making the ethanol + water system a more demanding (and therefore more informative) test case for liquid density models.

### Recommendation

Use **ethanol + water** as your primary validation system. Its larger dataset, broader state-space coverage, denser composition grids, and more numerous independent sources make it the superior benchmark. The methanol + water system can serve as a useful secondary validation set, particularly at atmospheric pressure and near-ambient temperatures.

### Core claims

- For validating a liquid-density model near room temperature, ethanol + water is the stronger choice over methanol + water based on ThermoML database holdings, offering substantially more data, broader coverage in temperature and pressure, and denser composition grids at near-ambient conditions.
- Ethanol + water has ~2,920 total data points across 29 data blocks and 22 DOIs, compared to ~1,610 data points, ~18 blocks, and ~15 DOIs for methanol + water (methanol estimates are search-level).
- Ethanol + water covers a temperature range of 268.1–618.2 K and a pressure range of 100–40,000 kPa, versus 287.15–417.15 K and 101–29,927 kPa (block-verified) for methanol + water.
- At 298.15 K and atmospheric pressure, ethanol + water provides 54 composition points in a single block (density spanning 995.3 kg/m³ at x(ethanol) = 0.003 to 785.7 kg/m³ at x(ethanol) = 1.0), whereas methanol + water provides 13 composition points (density spanning 787.2 kg/m³ to 997.05 kg/m³).
- Both systems exhibit monotonic density decrease from pure water (~997 kg/m³) to pure alcohol (~786–787 kg/m³), with non-linearity most pronounced in the water-rich region due to disruption of water's hydrogen-bonding network.
- Ethanol + water is a more demanding test case for density models because ethanol, being larger and more hydrophobic than methanol, tends to produce larger excess volume effects.
- Methanol + water can serve as a useful secondary validation set, particularly at atmospheric pressure and near-ambient temperatures.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 |  | This block provides 810 mass-density data points for ethanol + water covering 298.15–348.15 K, 100–40,000 kPa, and mole fractions 0.003–1.0. It is the primary evidence for the answer's claim that ethanol + water has a dense composition grid (54 points at 298.15 K / 100 kPa) and broad pressure coverage up to 40 MPa, and it supplies the representative density values quoted in the comparison table. |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 |  | This block provides 39 mass-density data points for methanol + water at 293.15–303.15 K, 101 kPa, and full mole-fraction range (0–1). It supplies the 13 composition points at 298.15 K cited in the answer and the representative methanol + water density values, serving as the direct comparison counterpart to the ethanol + water block. |

### Suggested follow-ups

- Compare excess molar volume (VE) data availability for ethanol + water vs. methanol + water to further assess non-ideal mixing behavior coverage.
- Check whether the ethanol + water blocks spanning 268–618 K include sub-ambient and high-temperature density data at multiple compositions, or only at limiting compositions.
- Investigate whether any ThermoML blocks report speed-of-sound or heat-capacity data for these same systems, enabling simultaneous multi-property model validation.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
