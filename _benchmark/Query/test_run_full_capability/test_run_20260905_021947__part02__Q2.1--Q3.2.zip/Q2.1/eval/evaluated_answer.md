# Q2.1 — Result

**Prompt:** I need a binary liquid for testing a mixture-property model near room temperature. Between benzene + toluene and hexane + ethanol, which would let me test the model over a wider composition range and against more types of measured properties?

**[run statistics removed]**

---

## Answer

## Recommendation: Hexane + Ethanol Is the Far Superior Choice

For testing a mixture-property model near room temperature, **hexane + ethanol** dominates benzene + toluene on every relevant criterion — composition coverage, property diversity, data volume, and the severity of non-ideal behavior that challenges a model.

---

### Head-to-Head Comparison

| Metric | Benzene + Toluene | Hexane + Ethanol |
|--------|-------------------|------------------|
| Distinct property types | 2 | **8** |
| Data blocks (288–308 K) | 2 | **9** |
| Literature sources | 2 | **5** |
| Composition range (mole fraction) | 0–0.7685 (only 3 points in 0.247–0.7685) | **0–1 for most properties** |
| Inspected data points (minimum) | 4 | **≥ 449** (49 inspected + 258 from block metadata for viscosity, density, surface tension, refractive index, speed of sound) |

---

### Property Types Available for Hexane + Ethanol

| # | Property | GLOBprop ID | Block(s) | Data points | x(ethanol) range |
|---|----------|-------------|----------|-------------|------------------|
| 1 | Excess molar enthalpy | GLOBprop_17 | GLOBlit_294 :: PROPblock_5 | 17 | 0.0544–0.9528 |
| 2 | Excess molar volume | GLOBprop_28 | GLOBlit_294 :: PROPblock_6 | 23 | 0.0417–0.9497 |
| 3 | Refractive index (Na D-line) | GLOBprop_7 | GLOBlit_2800 :: PROPblock_22 | 39 | 0.0–1.0 |
| 4 | Speed of sound | GLOBprop_8 | GLOBlit_2800 :: PROPblock_23 | 39 | 0.0–1.0 |
| 5 | Mass density | GLOBprop_1 | GLOBlit_2800 :: PROPblock_24 + GLOBlit_11449 :: PROPblock_10 | 39 + 103 | 0.0–1.0 |
| 6 | Binary diffusion coefficient | GLOBprop_29 | GLOBlit_8445 :: PROPblock_8 | 9 | 0.0–1.0 |
| 7 | Surface tension (liquid–gas) | GLOBprop_13 | GLOBlit_10821 :: PROPblock_5 | 77 | 0.0855–0.932 |
| 8 | Dynamic viscosity | GLOBprop_4 | GLOBlit_11449 :: PROPblock_9 | 103 | 0.0–1.0 |

By contrast, benzene + toluene offers only excess molar enthalpy (3 points, x(toluene) = 0.247–0.7685, from GLOBlit_6057, DOI 10.1016/j.tca.2013.01.028) and molar enthalpy of solution at infinite dilution (1 point, from GLOBlit_6268, DOI 10.1016/j.tca.2015.09.022).

---

### Why This Matters Chemically

**Hexane + ethanol** is a classic **polar/nonpolar** binary: ethanol's hydrogen-bonding network is disrupted by the inert alkane, producing large, positive excess enthalpies (peaking at 0.5795 kJ/mol near x(ethanol) ≈ 0.36 at 298.15 K) and positive excess volumes (maximum 4.12 × 10⁻⁷ m³/mol near x(ethanol) ≈ 0.45). The binary diffusion coefficient drops sharply from 5.74 × 10⁻⁹ m²/s in pure hexane to a minimum of 1.3 × 10⁻⁹ m²/s at x(ethanol) ≈ 0.5–0.7, reflecting the viscosity increase in the hydrogen-bonded regime. This strong non-ideality across thermodynamic, transport, acoustic, optical, volumetric, and interfacial properties provides a rigorous, multi-property stress test for any mixture model.

**Benzene + toluene**, by contrast, is a nearly ideal mixture of two structurally similar aromatics — excess enthalpies are only 0.0477–0.0713 kJ/mol. While useful as a sanity check, it cannot discriminate among competing models because deviations from ideality are tiny.

---

### Literature Sources for Hexane + Ethanol

| GLOBlit ID | DOI | Properties |
|------------|-----|------------|
| GLOBlit_294 | 10.1016/j.fluid.2005.08.001 | Excess molar enthalpy, excess molar volume |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | Refractive index, speed of sound, mass density |
| GLOBlit_8445 | 10.1021/je0497303 | Binary diffusion coefficient |
| GLOBlit_10821 | 10.1021/je700215z | Surface tension |
| GLOBlit_11449 | 10.1021/je800925v | Viscosity, mass density |

---

### Bottom Line

Choose **hexane + ethanol**. It gives you 8 property types over the full 0-to-1 mole-fraction range from 9 data blocks and 5 independent literature sources — versus just 2 property types, 4 data points, and a narrow composition window for benzene + toluene. The strong non-ideality of the hexane + ethanol system will provide a far more demanding and informative test of your mixture-property model.

### Core claims

- For testing a mixture-property model near room temperature, hexane + ethanol is far superior to benzene + toluene due to greater composition coverage, property diversity, data volume, and severity of non-ideal behavior.
- Hexane + ethanol provides 8 distinct property types (excess molar enthalpy, excess molar volume, refractive index, speed of sound, mass density, binary diffusion coefficient, surface tension, dynamic viscosity) across 9 data blocks from 5 independent literature sources, with most properties spanning the full 0–1 mole-fraction range.
- Benzene + toluene offers only 2 property types (excess molar enthalpy at 3 points over x(toluene) = 0.247–0.7685, and molar enthalpy of solution at infinite dilution at 1 point), totaling 4 data points from 2 sources.
- Hexane + ethanol exhibits strong non-ideality: positive excess enthalpies peaking at 0.5795 kJ/mol near x(ethanol) ≈ 0.36 at 298.15 K, positive excess volumes with a maximum of 4.12 × 10⁻⁷ m³/mol near x(ethanol) ≈ 0.45, and binary diffusion coefficients dropping from 5.74 × 10⁻⁹ m²/s in pure hexane to a minimum of 1.3 × 10⁻⁹ m²/s at x(ethanol) ≈ 0.5–0.7.
- Benzene + toluene is a nearly ideal mixture with excess enthalpies of only 0.0477–0.0713 kJ/mol, making it insufficient to discriminate among competing models.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_6057 | 10.1016/j.tca.2013.01.028 | PROPblock_1 |  | Provides excess molar enthalpy data for benzene + toluene (3 points, 0.0477–0.0713 kJ/mol, x = 0.247–0.7685 at 303.15 K), used in the answer to characterize the near-ideal benzene + toluene system for comparison. |
| GLOBlit_294 | 10.1016/j.fluid.2005.08.001 | PROPblock_5 |  | Provides 17 excess molar enthalpy data points for ethanol + hexane at 298.15 K (0.1216–0.5795 kJ/mol, x = 0.0544–0.9528), directly supporting the answer's recommendation and quoted peak value. |
| GLOBlit_294 | 10.1016/j.fluid.2005.08.001 | PROPblock_6 |  | Provides 23 excess molar volume data points for ethanol + hexane at 298.15 K (x = 0.0417–0.9497), supporting the answer's claim of positive excess volumes for this system. |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | PROPblock_22 |  | Provides 39 refractive index data points for ethanol + hexane over 293–303 K and x = 0–1, contributing one of the eight property types cited in the answer. |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | PROPblock_23 |  | Provides 39 speed of sound data points for ethanol + hexane over 293–303 K and x = 0–1, contributing one of the eight property types cited in the answer. |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | PROPblock_24 |  | Provides 39 mass density data points for ethanol + hexane over 293–303 K and x = 0–1, one of two density blocks cited in the answer. |
| GLOBlit_8445 | 10.1021/je0497303 | PROPblock_8 |  | Provides 9 binary diffusion coefficient data points for ethanol + hexane at 298.15 K over x = 0–1, supporting the answer's discussion of transport property behavior. |
| GLOBlit_10821 | 10.1021/je700215z | PROPblock_5 |  | Provides 77 surface tension data points for ethanol + hexane over 283–313 K and x = 0.0855–0.932, contributing the interfacial property type cited in the answer. |
| GLOBlit_11449 | 10.1021/je800925v | PROPblock_9 |  | Provides 103 dynamic viscosity data points for ethanol + hexane over 273–298 K and x = 0–1, contributing the transport viscosity property cited in the answer. |
| GLOBlit_11449 | 10.1021/je800925v | PROPblock_10 |  | Provides 103 mass density data points for ethanol + hexane over 273–298 K and x = 0–1, the second density block cited in the answer. |

### Suggested follow-ups

- Retrieve VLE (vapor-liquid equilibrium) data for hexane + ethanol to add phase-equilibrium testing to the model validation.
- Compare hexane + ethanol excess properties against UNIFAC or NRTL predictions to quantify model accuracy.
- Search for hexane + ethanol heat capacity data near 298 K to further expand the property diversity for model testing.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
