1. D005 near-room comparison; data-block row288–308K; additional viscosity/density at308.15K

   **Your reply:** Treat 288–308 K as rounded; include 308.15 K

2. Approximate peak composition bands: containment of measured coordinate under display bounds versus interval endpoints matching min/max measured peak coordinates. Reviewers used differing interpretations; H12 explicitly addressed property magnitudes.

   **Your reply:** Check peak containment; record actual coordinates
