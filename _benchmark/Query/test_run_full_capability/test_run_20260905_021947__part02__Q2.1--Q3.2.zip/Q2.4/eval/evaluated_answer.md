# Q2.4 — Result

**Prompt:** I want to validate an acoustic model for aqueous mixtures. Is the available speed-of-sound evidence broad enough for this purpose, or is it substantially more limited than the corresponding density evidence?

**[run statistics removed]**

---

## Answer

## Speed-of-Sound Evidence for Aqueous Mixtures: Breadth Assessment & Comparison with Density

### Short answer

The speed-of-sound dataset in the ThermoML database is **substantial and chemically diverse enough** to validate an acoustic model for aqueous mixtures — but it is **roughly 3–4 × smaller** than the corresponding mass-density dataset by every metric.

---

### Head-to-head comparison

| Metric | Speed of Sound | Mass Density | Ratio (ρ / u) |
|--------|---------------|-------------|----------------|
| Literature sources | 295 | 1,104 | ~3.7× |
| Data blocks | 753 | 2,558 | ~3.4× |
| Data points | 30,819 | 132,045 | ~4.3× |
| Temperature range | 273.15 – 596.3 K | 253.15 – 673.15 K | Density extends ~20 K lower, ~77 K higher |
| Pressure range | 100.0 – 120,000 kPa (≈1–1,200 atm) | 6.3 – 387,800 kPa (≈0.06–3,830 atm) | Density reaches ~3.2× higher pressure |
| Distinct co-solutes (lower bound from 100-block sample) | ~75–80 | ≥79 (likely several hundred total) | Density has substantially more |

---

### Chemical diversity of the speed-of-sound dataset

Even though it is smaller, the speed-of-sound dataset covers a remarkably broad chemical space of co-solutes dissolved in water:

| # | Co-solute | Class |
|---|-----------|-------|
| 1 | Glycine (2-aminoacetic acid) | Amino acid |
| 2 | L-Alanine | Amino acid |
| 3 | L-Valine | Amino acid |
| 4 | Sodium chloride | Inorganic salt |
| 5 | Potassium chloride | Inorganic salt |
| 6 | Potassium nitrate | Inorganic salt |
| 7 | D-Sucrose | Sugar |
| 8 | D-Glucose | Sugar |
| 9 | Dimethyl sulfoxide | Organic solvent |
| 10 | Acetonitrile | Organic solvent |
| 11 | Propan-1-ol | Alcohol |
| 12 | 1,2-Ethanediol | Glycol |
| 13 | Formamide | Amide |
| 14 | 1-Butyl-3-methylimidazolium bromide | Ionic liquid |
| 15 | N-Methyldiethanolamine | Alkanolamine |

This spans the key solute–water interaction regimes relevant to acoustic modelling: **electrostatic** (salts), **hydrogen-bonding** (sugars, amino acids, glycols, amides), and **hydrophobic** (organic solvents, ionic-liquid cations, alkanolamine alkyl chains).

---

### Largest speed-of-sound literature sources

| GLOBlit_N | DOI | Blocks | Points |
|-----------|-----|--------|--------|
| GLOBlit_5043 | 10.1016/j.jct.2017.06.001 | 1 | 961 |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | 5 | 712 |
| GLOBlit_8239 | 10.1021/je0340755 | 6 | 675 |
| GLOBlit_10102 | 10.1021/je4001203 | 5 | 657 |
| GLOBlit_9821 | 10.1021/je300175w | 7 | 598 |

---

### Interpretation

1. **The speed-of-sound evidence is broad enough for acoustic-model validation.** With ~31,000 data points across 295 independent literature sources, 753 data blocks, and at least 75–80 chemically distinct co-solutes, you have ample data to test predictions of sound velocity, derive isentropic compressibilities (κ_S = 1/(ρu²)), and benchmark equation-of-state performance across multiple solute classes.

2. **It is, however, substantially more limited than density evidence.** Density data is ~3.7× richer in sources, ~3.4× richer in blocks, and ~4.3× richer in data points. The thermodynamic window for density also extends to lower temperatures (253 K vs. 273 K), higher temperatures (673 K vs. 596 K), and much higher pressures (387,800 kPa vs. 120,000 kPa). The number of distinct co-solutes is also considerably larger for density.

3. **The gap is expected and well understood.** Mass density is the single most commonly measured thermophysical property — it is routinely co-reported with nearly every other measurement because it is needed for unit conversions (e.g., molarity ↔ molality). Speed-of-sound measurements, by contrast, require specialized acoustic instrumentation (ultrasonic pulse-echo, sing-around, or interferometric techniques), which limits the number of laboratories and publications reporting such data.

4. **Practical recommendation.** For model validation, the speed-of-sound dataset is sufficient to cover the major interaction regimes and a wide T–p window. Where you may find gaps is at extreme conditions (T > 596 K, p > 1,200 atm) and for more exotic co-solutes — in those regions, density data will be available but speed-of-sound data may not. You could use the density data as a complementary validation channel (e.g., checking that your model simultaneously reproduces both ρ and u) and reserve the speed-of-sound data for the acoustic-specific validation.

### Core claims

- The ThermoML speed-of-sound dataset for aqueous mixtures is substantial and chemically diverse enough to validate an acoustic model, comprising ~31,000 data points across 295 literature sources, 753 data blocks, and at least 75–80 chemically distinct co-solutes spanning electrostatic, hydrogen-bonding, and hydrophobic solute–water interaction regimes.
- The speed-of-sound dataset is roughly 3–4× smaller than the corresponding mass-density dataset: density has ~3.7× more literature sources (1,104 vs 295), ~3.4× more data blocks (2,558 vs 753), and ~4.3× more data points (132,045 vs 30,819).
- The thermodynamic window covered by density data extends further than that of speed-of-sound data: density spans 253.15–673.15 K and 6.3–387,800 kPa, whereas speed of sound spans 273.15–596.3 K and 100.0–120,000 kPa.
- The gap between density and speed-of-sound data availability is expected because mass density is routinely co-reported with other measurements, while speed-of-sound measurements require specialized acoustic instrumentation.
- Gaps in speed-of-sound coverage are most likely at extreme conditions (T > 596 K, p > 1,200 atm) and for more exotic co-solutes, where density data may still be available.

**Confidence:** medium

### Suggested follow-ups

- Drill into specific co-solute classes (e.g., electrolytes only, or organic solvents only) to assess whether the speed-of-sound coverage is adequate within each chemical family.
- Compare the temperature–pressure coverage of speed-of-sound vs. density data for a single representative system (e.g., NaCl + water) to quantify the thermodynamic-window gap for that system.
- Identify co-solutes that have density data but no speed-of-sound data, to map the blind spots for acoustic-model validation.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
