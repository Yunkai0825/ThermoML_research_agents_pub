# Q3.2 — Result

**Prompt:** I am building an activity-coefficient correlation for ethanol + water over the widest possible temperature range. What range can the experimental literature support, and which studies provide the coldest and hottest measurements?

**[run statistics removed]**

---

## Answer

## Activity Coefficient Data for Ethanol + Water: Temperature Range and Key Studies

### Verified Temperature Range

The ThermoML database contains **6 data blocks** of activity coefficient measurements for the ethanol + water binary system, spanning a verified temperature range of **273.35 K to 372.15 K** across **23 data points** from **4 publications**. All blocks report the **infinite-dilution activity coefficient of ethanol** (γ∞, with mole fraction of ethanol = 0.0).

---

### Coldest Measurement

**273.35 K** — from Vrba, Fenclová et al. (DOI: 10.1016/j.fluid.2005.08.018), PROPblock_4, measured by headspace analysis:

| Temperature (K) | x(ethanol) | γ∞(ethanol) |
|:---:|:---:|:---:|
| 273.35 | 0.0 | 2.54 |
| 283.15 | 0.0 | 3.13 |

### Hottest Measurement

**372.15 K** — from the same publication (DOI: 10.1016/j.fluid.2005.08.018), PROPblock_6, measured by a circulating still method:

| Temperature (K) | x(ethanol) | γ∞(ethanol) |
|:---:|:---:|:---:|
| 358.15 | 0.0 | 5.9 |
| 363.15 | 0.0 | 6.0 |
| 368.15 | 0.0 | 6.1 |
| 372.15 | 0.0 | 6.2 |

---

### Complete Block-by-Block Inventory

| Source | DOI | Block | Method | T range (K) | γ∞ range | Points | Trend |
|---|---|---|---|:---:|:---:|:---:|:---:|
| GLOBlit_299 | 10.1016/j.fluid.2005.08.018 | PROPblock_4 | Headspace analysis | 273.35–283.15 | 2.54–3.13 | 2 | ↑ |
| GLOBlit_299 | 10.1016/j.fluid.2005.08.018 | PROPblock_5 | Comparative tensimetry | 303.15–333.15 | 4.14–5.3 | 7 | ↑ |
| GLOBlit_299 | 10.1016/j.fluid.2005.08.018 | PROPblock_6 | Circulating still | 358.15–372.15 | 5.9–6.2 | 4 | ↑ |
| GLOBlit_8381 | 10.1021/je0495942 | PROPblock_1 | Chromatography | 298.15 | 3.77 | 1 | — |
| GLOBlit_8511 | 10.1021/je049875+ | PROPblock_1 | Dilutor chromatography | 303.25–343.25 | 5.03–5.96 | 5 | ↑ |
| GLOBlit_1971 | 10.1016/j.fluid.2016.08.030 | PROPblock_1 | Solid-phase micro-extraction | 323.15–353.15 | 4.11–5.17 | 4 | **↓ (anomalous)** |

---

### Chemistry Insight and Recommendations for Correlation Building

**Consistent data (5 of 6 blocks, 19 points):** In five blocks, γ∞ of ethanol increases monotonically with temperature — physically expected for a system where the hydrophobic interaction between ethanol and water weakens as thermal energy disrupts the hydrogen-bond network. The single most valuable publication is Vrba, Fenclová et al. (DOI: 10.1016/j.fluid.2005.08.018), which alone provides nearly continuous coverage from 273.35 K to 372.15 K using three complementary experimental techniques (headspace analysis, comparative tensimetry, circulating still), contributing 13 of the 19 consistent data points.

**Anomalous dataset — GLOBlit_1971 (DOI: 10.1016/j.fluid.2016.08.030):** This SPME-method dataset shows γ∞ *decreasing* from 5.17 at 323.15 K to 4.11 at 353.15 K, which contradicts every other source. For direct comparison at ~323 K: GLOBlit_1971 reports 5.17, GLOBlit_8511 reports 5.54 (at 323.25 K), and GLOBlit_299 PROPblock_5 reports 5.03 (at 323.15 K). While the absolute values at the lowest temperature are in the same ballpark, the reversed temperature trend is physically suspect and this dataset should be critically evaluated — or excluded — before inclusion in a correlation.

**Practical correlation range:** Your activity-coefficient correlation for ethanol + water can be reliably supported over **273.35 K to 372.15 K** using 19 data points from 3 independent publications with mutually consistent temperature trends.

### Core claims

- The ThermoML database contains 6 data blocks of infinite-dilution activity coefficient measurements for ethanol in water, spanning a verified temperature range of 273.35 K to 372.15 K across 23 data points from 4 publications.
- All blocks report the infinite-dilution activity coefficient of ethanol (γ∞ at ethanol mole fraction = 0.0).
- The coldest measurement is 273.35 K (γ∞ = 2.54) and the hottest is 372.15 K (γ∞ = 6.2), both from Vrba, Fenclová et al. (DOI: 10.1016/j.fluid.2005.08.018).
- In 5 of 6 blocks (19 data points), γ∞ of ethanol increases monotonically with temperature, consistent with weakening hydrophobic interactions as thermal energy disrupts the hydrogen-bond network.
- One dataset (GLOBlit_1971, DOI: 10.1016/j.fluid.2016.08.030, SPME method, 4 points from 323.15–353.15 K) shows γ∞ decreasing from 5.17 to 4.11 with increasing temperature, contradicting every other source and exhibiting a physically suspect reversed temperature trend.
- A reliable activity-coefficient correlation for ethanol + water can be supported over 273.35 K to 372.15 K using 19 mutually consistent data points from 3 independent publications.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_299 | 10.1016/j.fluid.2005.08.018 | PROPblock_4 |  | Provides the coldest activity coefficient measurements for ethanol+water at 273.35–283.15 K (γ∞ = 2.54–3.13) via headspace analysis, establishing the lower bound of the verified temperature range. |
| GLOBlit_299 | 10.1016/j.fluid.2005.08.018 | PROPblock_5 |  | Supplies 7 data points of infinite-dilution activity coefficients for ethanol in water over 303.15–333.15 K (γ∞ = 4.14–5.3) by comparative tensimetry, filling the mid-temperature range. |
| GLOBlit_299 | 10.1016/j.fluid.2005.08.018 | PROPblock_6 |  | Provides the hottest measurements at 358.15–372.15 K (γ∞ = 5.9–6.2) via circulating still method, establishing the upper bound of the verified temperature range at 372.15 K. |
| GLOBlit_8381 | 10.1021/je0495942 | PROPblock_1 |  | Contributes a single infinite-dilution activity coefficient data point for ethanol in water at 298.15 K (γ∞ = 3.77) by chromatography, providing an independent check in the near-ambient region. |
| GLOBlit_8511 | 10.1021/je049875+ | PROPblock_1 |  | Provides 5 data points of γ∞ for ethanol in water over 303.25–343.25 K (γ∞ = 5.03–5.96) by dilutor chromatography, offering independent corroboration of the monotonically increasing trend in the mid-temperature range. |
| GLOBlit_1971 | 10.1016/j.fluid.2016.08.030 | PROPblock_1 |  | Provides 4 data points of γ∞ for ethanol in water over 323.15–353.15 K (γ∞ = 4.11–5.17) by SPME; the answer correctly identifies this block's anomalous decreasing trend and recommends critical evaluation before use in correlations. |

### Suggested follow-ups

- Retrieve finite-concentration activity coefficient data for ethanol + water to complement the infinite-dilution values and improve mid-range correlation accuracy.
- Search for VLE (vapor-liquid equilibrium) datasets for ethanol + water above 372 K to extend the correlation toward the mixture critical region.
- Investigate the SPME methodology used in GLOBlit_1971 to determine whether the anomalous decreasing trend in γ∞ with temperature is a systematic artifact before deciding on exclusion.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
