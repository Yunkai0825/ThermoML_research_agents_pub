## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |
| GLOBprop_42 | Relative permittivity (various frequencies) | — |
| GLOBprop_44 | Relative permittivity (zero frequency / static dielectric constant) | — |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_12 | hexane | hexane |
| comp | GLOBcomp_2 | ethanol | ethanol |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all thermophysical properties measured for equimolar hexane + ethanol liquid mixture near 25 °C → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

The ThermoML database contains 7 distinct thermophysical properties measured for the binary hexane + ethanol liquid mixture near 298.15 K (25 °C), spanning 9 data blocks from 5 publications. The properties are: (1) mass density (650.4–789.3 kg/m³), (2) refractive index at the Na D-line (1.357–1.375), (3) speed of sound (1046–1160 m/s), (4) excess molar enthalpy (0.12–0.58 kJ/mol, positive across the full composition range), (5) excess molar volume (8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ m³/mol, positive), (6) liquid–gas surface tension, and (7) viscosity. A binary diffusion coefficient was also found but with only 2 data points in the temperature window. Representative data cover ethanol mole fractions from 0 to 1 and temperatures of 293.15–303.15 K. The positive excess enthalpy and excess molar volume near equimolar composition reflect endothermic mixing and volume expansion, consistent with strong positive deviations from ideality caused by the mismatch between nonpolar hexane and hydrogen-bonding ethanol. Approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Answer:**

#### Thermophysical Properties Measured for the Binary Hexane + Ethanol System Near 25 °C

The ThermoML database contains **7 distinct thermophysical properties** measured for the binary hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) liquid mixture in the temperature range near 298.15 K (25 °C), spread across **9 data blocks** from **5 publications**. Several blocks cover the full composition range (ethanol mole fraction 0–1), including equimolar (x ≈ 0.5).

##### Complete List of Measured Properties

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *#* | *Property* | *GLOBprop ID* | *Representative Block* | *Literature* | *DOI* |
|---|---|---|---|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「1」 | 「**Mass density** (kg/m³)」 | 「GLOBprop_1」 | 「PROPblock_24」 | 「GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| WM_L1_Q1_Table#1_Row#2 | 「2」 | 「**Refractive index (Na D-line)**」 | 「GLOBprop_7」 | 「PROPblock_22」 | 「GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| WM_L1_Q1_Table#1_Row#3 | 「3」 | 「**Speed of sound** (m/s)」 | 「GLOBprop_8」 | 「PROPblock_23」 | 「GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| WM_L1_Q1_Table#1_Row#4 | 「4」 | 「**Excess molar enthalpy** (kJ/mol)」 | 「GLOBprop_17」 | 「PROPblock_5」 | 「GLOBlit_294」 | 「10.1016/j.fluid.2005.08.001」 |
| WM_L1_Q1_Table#1_Row#5 | 「5」 | 「**Excess molar volume** (m³/mol)」 | 「GLOBprop_28」 | 「PROPblock_6」 | 「GLOBlit_294」 | 「10.1016/j.fluid.2005.08.001」 |
| WM_L1_Q1_Table#1_Row#6 | 「6」 | 「**Surface tension, liquid–gas** (N/m)」 | 「—」 | 「—」 | 「GLOBlit_10821」 | 「10.1021/je700215z」 |
| WM_L1_Q1_Table#1_Row#7 | 「7」 | 「**Viscosity** (Pa·s)」 | 「—」 | 「—」 | 「GLOBlit_11449」 | 「10.1021/je800925v」 |

An additional property, **binary diffusion coefficient** (GLOBprop_29), was found in GLOBlit_8445 (DOI: 10.1021/je0497303), though it had only 2 data points in the temperature window.

##### Representative Data Details

- **Mass density** (GLOBlit_2800, PROPblock_24): 15 points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 650.4–789.3 kg/m³. All liquid phase.
- **Speed of sound** (GLOBlit_2800, PROPblock_23): 24 points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1046–1160 m/s.
- **Refractive index** (GLOBlit_2800, PROPblock_22): 13 points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1.357–1.375.
- **Excess molar enthalpy** (GLOBlit_294, PROPblock_5): 9 points at constrained T (≈298.15 K), x(ethanol) = 0.054–0.953, values 0.12–0.58 kJ/mol. The positive H^E values across the full composition range reflect the endothermic mixing characteristic of the hexane + ethanol system, driven by disruption of ethanol hydrogen-bonding networks upon mixing with the nonpolar alkane.
- **Excess molar volume** (GLOBlit_294, PROPblock_6): 9 points at constrained T, x(ethanol) = 0.042–0.950, values 8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ m³/mol (positive V^E), consistent with volume expansion upon mixing.

##### Chemistry Insight

Hexane + ethanol is a classic partially miscible system at lower temperatures, exhibiting strong positive deviations from ideal mixing. The measured properties collectively characterize the volumetric (density, excess volume), acoustic (speed of sound), optical (refractive index), transport (viscosity, diffusion coefficient), energetic (excess enthalpy), and interfacial (surface tension) behavior. The positive excess enthalpy and excess volume near equimolar composition reflect the thermodynamic non-ideality arising from the mismatch between nonpolar hexane and hydrogen-bonding ethanol. In total, approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Core claims:**
- The ThermoML database contains 7 distinct thermophysical properties measured for the binary hexane + ethanol liquid mixture near 298.15 K: mass density, refractive index (Na D-line), speed of sound, excess molar enthalpy, excess molar volume, surface tension (liquid–gas), and viscosity, spread across 9 data blocks from 5 publications.
- An additional property, binary diffusion coefficient, was found but with only 2 data points in the temperature window.
- Excess molar enthalpy values are positive across the full composition range (0.12–0.58 kJ/mol for ethanol mole fractions 0.054–0.953), reflecting endothermic mixing driven by disruption of ethanol hydrogen-bonding networks upon mixing with nonpolar hexane.
- Excess molar volume values are positive (8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ m³/mol for ethanol mole fractions 0.042–0.950), consistent with volume expansion upon mixing.
- Mass density data span 650.4–789.3 kg/m³ over T = 293.15–303.15 K and ethanol mole fractions 0–1.
- Approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#2 | 「GLOBlit_2800」 | 「PROPblock_24」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_1」 | 「Mass density measurements for hexane + ethanol binary mixture at 293–303 K across full composition range.」 |
| WM_L1_Q1_Table#3 | 「GLOBlit_2800」 | 「PROPblock_22」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_7」 | 「Refractive index (Na D-line) measurements for hexane + ethanol binary mixture at 293–303 K across full composition range.」 |
| WM_L1_Q1_Table#4 | 「GLOBlit_2800」 | 「PROPblock_23」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_8」 | 「Speed of sound measurements for hexane + ethanol binary mixture at 293–303 K across full composition range.」 |
| WM_L1_Q1_Table#5 | 「GLOBlit_294」 | 「PROPblock_5」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_17」 | 「Excess molar enthalpy measurements for hexane + ethanol binary mixture at ~298.15 K across composition range.」 |
| WM_L1_Q1_Table#6 | 「GLOBlit_294」 | 「PROPblock_6」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_28」 | 「Excess molar volume measurements for hexane + ethanol binary mixture at ~298.15 K across composition range.」 |

*Not stored here: 2 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.



</memory>

## User
For an equimolar liquid mixture of hexane + ethanol near 25 °C, which thermophysical properties have been measured?

## Assistant
<summary>Dispatching L1 query to find all thermophysical properties measured for an equimolar hexane + ethanol liquid mixture near 25 °C in the ThermoML database.</summary>
<tool_call>L1_query(instruction=Search for the bi…, id_catalog=, context=User wants a comp…)</tool_call>
<wait/> (18 deferred)

## User
<tool_result>
<subagent_answer>
### L1#1 — L1_query return

**Status:** status=success

**Summary:**

The ThermoML database contains 7 distinct thermophysical properties measured for the binary hexane + ethanol liquid mixture near 298.15 K (25 °C), spanning 9 data blocks from 5 publications. The properties are: (1) mass density (650.4–789.3 kg/m³), (2) refractive index at the Na D-line (1.357–1.375), (3) speed of sound (1046–1160 m/s), (4) excess molar enthalpy (0.12–0.58 kJ/mol, positive across the full composition range), (5) excess molar volume (8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ m³/mol, positive), (6) liquid–gas surface tension, and (7) viscosity. A binary diffusion coefficient was also found but with only 2 data points in the temperature window. Representative data cover ethanol mole fractions from 0 to 1 and temperatures of 293.15–303.15 K. The positive excess enthalpy and excess molar volume near equimolar composition reflect endothermic mixing and volume expansion, consistent with strong positive deviations from ideality caused by the mismatch between nonpolar hexane and hydrogen-bonding ethanol. Approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Answer:**

#### Thermophysical Properties Measured for the Binary Hexane + Ethanol System Near 25 °C

The ThermoML database contains **7 distinct thermophysical properties** measured for the binary hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) liquid mixture in the temperature range near 298.15 K (25 °C), spread across **9 data blocks** from **5 publications**. Several blocks cover the full composition range (ethanol mole fraction 0–1), including equimolar (x ≈ 0.5).

##### Complete List of Measured Properties

**L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *#* | *Property* | *GLOBprop ID* | *Representative Block* | *Literature* | *DOI* |
|---|---|---|---|---|---|---|
| L1#1_Table#1_Row#1 | 「1」 | 「**Mass density** (kg/m³)」 | 「GLOBprop_1」 | 「PROPblock_24」 | 「GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| L1#1_Table#1_Row#2 | 「2」 | 「**Refractive index (Na D-line)**」 | 「GLOBprop_7」 | 「PROPblock_22」 | 「GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| L1#1_Table#1_Row#3 | 「3」 | 「**Speed of sound** (m/s)」 | 「GLOBprop_8」 | 「PROPblock_23」 | 「GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| L1#1_Table#1_Row#4 | 「4」 | 「**Excess molar enthalpy** (kJ/mol)」 | 「GLOBprop_17」 | 「PROPblock_5」 | 「GLOBlit_294」 | 「10.1016/j.fluid.2005.08.001」 |
| L1#1_Table#1_Row#5 | 「5」 | 「**Excess molar volume** (m³/mol)」 | 「GLOBprop_28」 | 「PROPblock_6」 | 「GLOBlit_294」 | 「10.1016/j.fluid.2005.08.001」 |
| L1#1_Table#1_Row#6 | 「6」 | 「**Surface tension, liquid–gas** (N/m)」 | 「—」 | 「—」 | 「GLOBlit_10821」 | 「10.1021/je700215z」 |
| L1#1_Table#1_Row#7 | 「7」 | 「**Viscosity** (Pa·s)」 | 「—」 | 「—」 | 「GLOBlit_11449」 | 「10.1021/je800925v」 |

An additional property, **binary diffusion coefficient** (GLOBprop_29), was found in GLOBlit_8445 (DOI: 10.1021/je0497303), though it had only 2 data points in the temperature window.

##### Representative Data Details

- **Mass density** (GLOBlit_2800, PROPblock_24): 15 points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 650.4–789.3 kg/m³. All liquid phase.
- **Speed of sound** (GLOBlit_2800, PROPblock_23): 24 points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1046–1160 m/s.
- **Refractive index** (GLOBlit_2800, PROPblock_22): 13 points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1.357–1.375.
- **Excess molar enthalpy** (GLOBlit_294, PROPblock_5): 9 points at constrained T (≈298.15 K), x(ethanol) = 0.054–0.953, values 0.12–0.58 kJ/mol. The positive H^E values across the full composition range reflect the endothermic mixing characteristic of the hexane + ethanol system, driven by disruption of ethanol hydrogen-bonding networks upon mixing with the nonpolar alkane.
- **Excess molar volume** (GLOBlit_294, PROPblock_6): 9 points at constrained T, x(ethanol) = 0.042–0.950, values 8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ m³/mol (positive V^E), consistent with volume expansion upon mixing.

##### Chemistry Insight

Hexane + ethanol is a classic partially miscible system at lower temperatures, exhibiting strong positive deviations from ideal mixing. The measured properties collectively characterize the volumetric (density, excess volume), acoustic (speed of sound), optical (refractive index), transport (viscosity, diffusion coefficient), energetic (excess enthalpy), and interfacial (surface tension) behavior. The positive excess enthalpy and excess volume near equimolar composition reflect the thermodynamic non-ideality arising from the mismatch between nonpolar hexane and hydrogen-bonding ethanol. In total, approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Core claims:**
- The ThermoML database contains 7 distinct thermophysical properties measured for the binary hexane + ethanol liquid mixture near 298.15 K: mass density, refractive index (Na D-line), speed of sound, excess molar enthalpy, excess molar volume, surface tension (liquid–gas), and viscosity, spread across 9 data blocks from 5 publications.
- An additional property, binary diffusion coefficient, was found but with only 2 data points in the temperature window.
- Excess molar enthalpy values are positive across the full composition range (0.12–0.58 kJ/mol for ethanol mole fractions 0.054–0.953), reflecting endothermic mixing driven by disruption of ethanol hydrogen-bonding networks upon mixing with nonpolar hexane.
- Excess molar volume values are positive (8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ m³/mol for ethanol mole fractions 0.042–0.950), consistent with volume expansion upon mixing.
- Mass density data span 650.4–789.3 kg/m³ over T = 293.15–303.15 K and ethanol mole fractions 0–1.
- Approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Core ID updates:**
- add GLOBcomp_12 — hexane (registry: hexane)
- add GLOBcomp_2 — ethanol (registry: ethanol)

#### Core blocks found — verbatim ledger

```ledger
**L1#1_Table#2_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_2800 | lit_id: 2007-per-rod-3 | doi: 10.1016/j.jct.2007.02.008
block: PROPblock_24 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_1) | system: binary | n_datapoints: 39
compounds: ethanol (C2H6O; GLOBcomp_2; DOIcomp_1; InChIKey LFQSCWFLJHTTHZ-UHFFFAOYSA-N); hexane (C6H14; GLOBcomp_12; DOIcomp_4; InChIKey VLKZOEOYAKHREP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_1
description: Mass density measurements for hexane + ethanol binary mixture at 293–303 K across full composition range.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#2_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=101.0 · phase=Liquid」 |
| L1#1_Table#2_Row#2 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=293.15–303.15 · n_unique=3 · phase=Liquid」 |
| L1#1_Table#2_Row#3 | 「variable」 | 「BLKvar_2/GLOBvar_2」 | 「Mole fraction of ethanol」 | 「range=0.0–1.0 · n_unique=13 · phase=Liquid」 |
| L1#1_Table#2_Row#4 | 「property」 | 「BLKprop_1/GLOBprop_1」 | 「Mass density, kg/m3」 | 「method=VIBTUB:UFactor:4 (GLOBmeas_134) · range=650.4–789.3 · mean=704.112821 · n=39 · phase=Liquid」 |
```

```ledger
**L1#1_Table#3_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_2800 | lit_id: 2007-per-rod-3 | doi: 10.1016/j.jct.2007.02.008
block: PROPblock_22 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_1) | system: binary | n_datapoints: 39
compounds: ethanol (C2H6O; GLOBcomp_2; DOIcomp_1; InChIKey LFQSCWFLJHTTHZ-UHFFFAOYSA-N); hexane (C6H14; GLOBcomp_12; DOIcomp_4; InChIKey VLKZOEOYAKHREP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_7
description: Refractive index (Na D-line) measurements for hexane + ethanol binary mixture at 293–303 K across full composition range.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#3_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=101.0 · phase=Liquid」 |
| L1#1_Table#3_Row#2 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=293.15–303.15 · n_unique=3 · phase=Liquid」 |
| L1#1_Table#3_Row#3 | 「variable」 | 「BLKvar_2/GLOBvar_2」 | 「Mole fraction of ethanol」 | 「range=0.0–1.0 · n_unique=13 · phase=Liquid」 |
| L1#1_Table#3_Row#4 | 「property」 | 「BLKprop_1/GLOBprop_7」 | 「Refractive index (Na D-line)」 | 「method=Standard Abbe refractometry (GLOBmeas_3) · range=1.35725–1.37495 · mean=1.366087 · n=39 · phase=Liquid」 |
```

```ledger
**L1#1_Table#4_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_2800 | lit_id: 2007-per-rod-3 | doi: 10.1016/j.jct.2007.02.008
block: PROPblock_23 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_1) | system: binary | n_datapoints: 39
compounds: ethanol (C2H6O; GLOBcomp_2; DOIcomp_1; InChIKey LFQSCWFLJHTTHZ-UHFFFAOYSA-N); hexane (C6H14; GLOBcomp_12; DOIcomp_4; InChIKey VLKZOEOYAKHREP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_8
description: Speed of sound measurements for hexane + ethanol binary mixture at 293–303 K across full composition range.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#4_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=101.0 · phase=Liquid」 |
| L1#1_Table#4_Row#2 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=293.15–303.15 · n_unique=3 · phase=Liquid」 |
| L1#1_Table#4_Row#3 | 「variable」 | 「BLKvar_2/GLOBvar_2」 | 「Mole fraction of ethanol」 | 「range=0.0–1.0 · n_unique=13 · phase=Liquid」 |
| L1#1_Table#4_Row#4 | 「property」 | 「BLKprop_1/GLOBprop_8」 | 「Speed of sound, m/s」 | 「method=Sing-around technique in a fixed-path interferometer (GLOBmeas_7) · range=1046.0–1160.0 · mean=1088.25641 · n=39 · phase=Liquid」 |
```

```ledger
**L1#1_Table#5_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_294 | lit_id: 2005-kwa-rez-0 | doi: 10.1016/j.fluid.2005.08.001
block: PROPblock_5 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_1) | system: binary | n_datapoints: 17
compounds: ethanol (C2H6O; GLOBcomp_2; DOIcomp_1; InChIKey LFQSCWFLJHTTHZ-UHFFFAOYSA-N); hexane (C6H14; GLOBcomp_12; DOIcomp_4; InChIKey VLKZOEOYAKHREP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_17
description: Excess molar enthalpy measurements for hexane + ethanol binary mixture at ~298.15 K across composition range.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#5_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_2」 | 「Temperature, K」 | 「value=298.15 · phase=Liquid」 |
| L1#1_Table#5_Row#2 | 「constraint」 | 「BLKconstr_2/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=101.325 · phase=Liquid」 |
| L1#1_Table#5_Row#3 | 「variable」 | 「BLKvar_1/GLOBvar_2」 | 「Mole fraction of ethanol」 | 「range=0.0544–0.9528 · n_unique=17 · phase=Liquid」 |
| L1#1_Table#5_Row#4 | 「property」 | 「BLKprop_1/GLOBprop_17」 | 「Excess molar enthalpy (molar enthalpy of mixing), kJ/mol」 | 「method=Flow calorimetry (GLOBmeas_12) · range=0.1216–0.5795 · mean=0.458288 · n=17 · phase=Liquid」 |
```

```ledger
**L1#1_Table#6_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_294 | lit_id: 2005-kwa-rez-0 | doi: 10.1016/j.fluid.2005.08.001
block: PROPblock_6 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_1) | system: binary | n_datapoints: 23
compounds: ethanol (C2H6O; GLOBcomp_2; DOIcomp_1; InChIKey LFQSCWFLJHTTHZ-UHFFFAOYSA-N); hexane (C6H14; GLOBcomp_12; DOIcomp_4; InChIKey VLKZOEOYAKHREP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_28
description: Excess molar volume measurements for hexane + ethanol binary mixture at ~298.15 K across composition range.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#6_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_2」 | 「Temperature, K」 | 「value=298.15 · phase=Liquid」 |
| L1#1_Table#6_Row#2 | 「constraint」 | 「BLKconstr_2/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=101.325 · phase=Liquid」 |
| L1#1_Table#6_Row#3 | 「variable」 | 「BLKvar_1/GLOBvar_2」 | 「Mole fraction of ethanol」 | 「range=0.0417–0.9497 · n_unique=23 · phase=Liquid」 |
| L1#1_Table#6_Row#4 | 「property」 | 「BLKprop_1/GLOBprop_28」 | 「Excess molar volume, m3/mol」 | 「method=Calculated with densities of this investigation (GLOBmeas_29) · range=0.0–0.0 · mean=0.0 · n=23 · phase=Liquid」 |
```
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 18 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<reasoning>
The L1 query has returned comprehensive results. I already have all the data I need from the previous query stored in working memory and confirmed by this fresh L1 return. I can now provide the final answer.
</reasoning>

<answer>

## Thermophysical Properties Measured for the Equimolar Hexane + Ethanol Liquid Mixture Near 25 °C

The ThermoML database contains **7 distinct thermophysical properties** measured for the binary hexane + ethanol liquid mixture near 298.15 K (25 °C), spread across **9 data blocks** from **5 publications**. Several blocks cover the full composition range (ethanol mole fraction 0–1), including equimolar (x ≈ 0.5).

### Complete List of Measured Properties

| # | Property | Unit | Representative Values | Source (DOI) |
|---|----------|------|-----------------------|--------------|
| 1 | **Mass density** | kg/m³ | 650.4–789.3 | 10.1016/j.jct.2007.02.008 |
| 2 | **Refractive index (Na D-line)** | — | 1.357–1.375 | 10.1016/j.jct.2007.02.008 |
| 3 | **Speed of sound** | m/s | 1046–1160 | 10.1016/j.jct.2007.02.008 |
| 4 | **Excess molar enthalpy (Hᴱ)** | kJ/mol | 0.12–0.58 | 10.1016/j.fluid.2005.08.001 |
| 5 | **Excess molar volume (Vᴱ)** | m³/mol | 8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ | 10.1016/j.fluid.2005.08.001 |
| 6 | **Surface tension (liquid–gas)** | N/m | — | 10.1021/je700215z |
| 7 | **Viscosity (dynamic)** | Pa·s | — | 10.1021/je800925v |

An additional property — **binary diffusion coefficient** — was found (DOI: 10.1021/je0497303), though with only 2 data points in the temperature window.

### Representative Data Details

- **Mass density** (PROPblock_24): 39 data points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 650.4–789.3 kg/m³ at 101 kPa. Measured by vibrating-tube densimetry.
- **Speed of sound** (PROPblock_23): 39 data points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1046–1160 m/s. Measured by sing-around technique.
- **Refractive index** (PROPblock_22): 39 data points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1.357–1.375. Measured by standard Abbe refractometry.
- **Excess molar enthalpy** (PROPblock_5): 17 data points at T = 298.15 K and 101.325 kPa, x(ethanol) = 0.054–0.953, values 0.12–0.58 kJ/mol. Measured by flow calorimetry. The positive Hᴱ values across the full composition range reflect endothermic mixing.
- **Excess molar volume** (PROPblock_6): 23 data points at T = 298.15 K and 101.325 kPa, x(ethanol) = 0.042–0.950. Positive Vᴱ values indicate volume expansion upon mixing.

### Chemistry Insight

Hexane + ethanol is a classic system exhibiting **strong positive deviations from ideal mixing**. The thermodynamic non-ideality arises from the fundamental mismatch between nonpolar hexane and hydrogen-bonding ethanol:

- **Positive excess enthalpy** (Hᴱ up to ~0.58 kJ/mol near equimolar composition) reflects the energy cost of disrupting ethanol's hydrogen-bonding network when mixed with the inert alkane.
- **Positive excess molar volume** indicates that the mixture occupies more space than the sum of the pure-component volumes — the molecules pack less efficiently together than in their pure liquids.
- The collection of volumetric (density, Vᴱ), acoustic (speed of sound), optical (refractive index), transport (viscosity, diffusion), energetic (Hᴱ), and interfacial (surface tension) measurements provides a comprehensive thermodynamic and transport characterization of this non-ideal binary system.

In total, approximately **400 data points** across these properties are available in the 290–310 K window from the five contributing publications.

</answer>