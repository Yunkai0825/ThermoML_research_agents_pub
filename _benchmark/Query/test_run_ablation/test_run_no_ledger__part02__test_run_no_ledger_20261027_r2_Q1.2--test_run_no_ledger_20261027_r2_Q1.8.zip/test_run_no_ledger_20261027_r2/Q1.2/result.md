# Q1.2 — Result

**Prompt:** For an equimolar liquid mixture of hexane + ethanol near 25 °C, which thermophysical properties have been measured?

**Tool calls:** 1  |  **Time:** 323.5s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

## Thermophysical Properties Measured for the Equimolar Hexane + Ethanol Liquid Mixture Near 25 °C

The ThermoML database contains **7 distinct thermophysical properties** measured for the binary hexane + ethanol liquid mixture near 298.15 K (25 °C), spread across **9 data blocks** from **5 publications**. Several blocks cover the full composition range (ethanol mole fraction 0–1), including equimolar (x ≈ 0.5).

### Complete List of Measured Properties

| # | Property | Unit | Representative Values | Source (DOI) |
|---|----------|------|-----------------------|--------------|
| 1 | **Mass density** | kg/m³ | 650.4–789.3 | 10.1016/j.jct.2007.02.008 |
| 2 | **Refractive index (Na D-line)** | — | 1.357–1.375 | 10.1016/j.jct.2007.02.008 |
| 3 | **Speed of sound** | m/s | 1046–1160 | 10.1016/j.jct.2007.02.008 |
| 4 | **Excess molar enthalpy (Hᴱ)** | kJ/mol | 0.12–0.58 | 10.1016/j.fluid.2005.08.001 |
| 5 | **Excess molar volume (Vᴱ)** | m³/mol | 8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ | 10.1016/j.fluid.2005.08.001 |
| 6 | **Surface tension (liquid–gas)** | N/m | — | 10.1021/je700215z |
| 7 | **Viscosity (dynamic)** | Pa·s | — | 10.1021/je800925v |

An additional property — **binary diffusion coefficient** — was found (DOI: 10.1021/je0497303), though with only 2 data points in the temperature window.

### Representative Data Details

- **Mass density** (PROPblock_24): 39 data points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 650.4–789.3 kg/m³ at 101 kPa. Measured by vibrating-tube densimetry.
- **Speed of sound** (PROPblock_23): 39 data points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1046–1160 m/s. Measured by sing-around technique.
- **Refractive index** (PROPblock_22): 39 data points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1.357–1.375. Measured by standard Abbe refractometry.
- **Excess molar enthalpy** (PROPblock_5): 17 data points at T = 298.15 K and 101.325 kPa, x(ethanol) = 0.054–0.953, values 0.12–0.58 kJ/mol. Measured by flow calorimetry. The positive Hᴱ values across the full composition range reflect endothermic mixing.
- **Excess molar volume** (PROPblock_6): 23 data points at T = 298.15 K and 101.325 kPa, x(ethanol) = 0.042–0.950. Positive Vᴱ values indicate volume expansion upon mixing.

### Chemistry Insight

Hexane + ethanol is a classic system exhibiting **strong positive deviations from ideal mixing**. The thermodynamic non-ideality arises from the fundamental mismatch between nonpolar hexane and hydrogen-bonding ethanol:

- **Positive excess enthalpy** (Hᴱ up to ~0.58 kJ/mol near equimolar composition) reflects the energy cost of disrupting ethanol's hydrogen-bonding network when mixed with the inert alkane.
- **Positive excess molar volume** indicates that the mixture occupies more space than the sum of the pure-component volumes — the molecules pack less efficiently together than in their pure liquids.
- The collection of volumetric (density, Vᴱ), acoustic (speed of sound), optical (refractive index), transport (viscosity, diffusion), energetic (Hᴱ), and interfacial (surface tension) measurements provides a comprehensive thermodynamic and transport characterization of this non-ideal binary system.

In total, approximately **400 data points** across these properties are available in the 290–310 K window from the five contributing publications.

### Core claims

- The ThermoML database contains 7 distinct thermophysical properties measured for the binary hexane + ethanol liquid mixture near 298.15 K: mass density, refractive index, speed of sound, excess molar enthalpy, excess molar volume, surface tension, and dynamic viscosity, spread across 9 data blocks from 5 publications.
- An additional property, binary diffusion coefficient, was found with only 2 data points in the temperature window.
- Positive excess molar enthalpy (Hᴱ up to ~0.58 kJ/mol near equimolar composition) across the full composition range reflects endothermic mixing due to disruption of ethanol's hydrogen-bonding network by nonpolar hexane.
- Positive excess molar volume indicates volume expansion upon mixing, consistent with less efficient molecular packing compared to the pure liquids.
- Approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | PROPblock_24 |  | Provides mass density data (650.4–789.3 kg/m³) for the binary ethanol + hexane system across 39 data points at 293.15–303.15 K and full composition range, directly supporting the answer's density entry. |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | PROPblock_23 |  | Provides speed of sound data (1046–1160 m/s) for the binary ethanol + hexane system across 39 data points at 293.15–303.15 K and full composition range, directly supporting the answer's speed of sound entry. |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | PROPblock_22 |  | Provides refractive index data (1.357–1.375) for the binary ethanol + hexane system across 39 data points at 293.15–303.15 K and full composition range, directly supporting the answer's refractive index entry. |
| GLOBlit_294 | 10.1016/j.fluid.2005.08.001 | PROPblock_5 |  | Provides excess molar enthalpy data (0.12–0.58 kJ/mol) for the binary ethanol + hexane system at 298.15 K across 17 data points covering x(ethanol) = 0.054–0.953, directly supporting the answer's Hᴱ entry. |
| GLOBlit_294 | 10.1016/j.fluid.2005.08.001 | PROPblock_6 |  | Provides excess molar volume data for the binary ethanol + hexane system at 298.15 K across 23 data points covering x(ethanol) = 0.042–0.950, directly supporting the answer's Vᴱ entry. |

### Suggested follow-ups

- Compare the excess molar enthalpy values at equimolar composition across different temperatures to assess the temperature dependence of mixing endothermicity.
- Retrieve activity coefficient or vapor-liquid equilibrium data for hexane + ethanol to complement the calorimetric and volumetric excess properties.
- Investigate whether the surface tension and viscosity data show extrema or monotonic behavior as a function of composition near x = 0.5.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_12",
    "registry_id": "hexane",
    "name": "hexane"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  }
]
```
