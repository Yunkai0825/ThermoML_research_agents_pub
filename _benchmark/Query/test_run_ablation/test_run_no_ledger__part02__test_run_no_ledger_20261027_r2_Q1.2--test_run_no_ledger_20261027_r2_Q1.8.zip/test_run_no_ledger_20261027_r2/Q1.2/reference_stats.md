# Reference Stats — query-agent

**Run started:** 2026-10-27 03:40:29
**Wall time (at last flush):** 239.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 26,101 | 41,849 | 25,461 | 67,950 | 11,325 | 132.5 | claudeopus46 |
| L1-worker | 14 | 147,314 | 82,974 | 19,365 | 230,288 | 16,449 | 117.7 | claudeopus46 |
| **TOTAL** | **20** | **173,415** | **124,823** | **44,826** | **298,238** | **14,911** | **250.2** | |

**Estimated tokens:** ~74,559 input + ~11,206 output = ~85,765 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 2 | 0 | 0 | 0 | 3 | 6 | 400 |
| `search_blocks` | 2 | 8 | 2 | 2 | 5 | 9 | 449 |
| **TOTAL** | **6** | **8** | **2** | **2** | **8** | **15** | **849** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_12 |  | resolve_compound_ids, search_blocks, search_system_summary |
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks, search_system_summary |

#### References (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_11449 |  | search_blocks, search_system_summary |
| GLOBlit_2800 |  | search_blocks, search_system_summary |
| GLOBlit_10821 |  | search_blocks, search_system_summary |
| GLOBlit_294 |  | search_blocks |
| GLOBlit_8445 |  | search_blocks |

#### Properties (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBprop_28 | Excess molar volume, m3/mol | search_blocks |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks |
| GLOBprop_8 | Speed of sound, m/s | search_blocks |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |
| GLOBprop_29 | Binary diffusion coefficient, m2/s | search_blocks |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_29 | Excess molar volume, m3/mol | search_blocks |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_38 | Binary diffusion coefficient, m2/s | search_blocks |
| GLOBmeas_342 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_284 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_147 | Mass density, kg/m3 | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 5 |
| Unique Properties | 8 |
| Unique Measurements | 9 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 2 |
| Total DOIs | 5 |
| Unique parent blocks | 9 |
| Explicit block/subsystem targets | 9 |
| Subsystem targets | 0 |
| Target-matched data points | 449 |

---

## 3. DOI & Block References

**Unique DOIs:** 5  |  **Parent blocks:** 9  |  **Explicit targets:** 9  |  **Subsystems:** 0  |  **Target-matched datapoints:** 449

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2005.08.001 | 2 | 40 | binary | search_blocks |
| 10.1016/j.jct.2007.02.008 | 3 | 117 | binary | search_blocks |
| 10.1021/je0497303 | 1 | 9 | binary | search_blocks |
| 10.1021/je700215z | 1 | 77 | binary | search_blocks |
| 10.1021/je800925v | 2 | 206 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2005.08.001 | PROPblock_5 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_6 | declared | 23 | binary | — | search_blocks |
| 10.1016/j.jct.2007.02.008 | PROPblock_22 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | declared | 39 | binary | — | search_blocks |
| 10.1021/je0497303 | PROPblock_8 | declared | 9 | binary | — | search_blocks |
| 10.1021/je700215z | PROPblock_5 | declared | 77 | binary | — | search_blocks |
| 10.1021/je800925v | PROPblock_10 | declared | 103 | binary | — | search_blocks |
| 10.1021/je800925v | PROPblock_9 | declared | 103 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | purpose=Resolve hexane and ethanol to…, queries=['… | 204 | KEEP ←in 287 | 204 | 3.6 |
| 2 | 4 | `search_system_summary` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=20, … | 723 | KEEP ←in 756 | 723 | 7.6 |
| 3 | 5 | `search_blocks` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=20, … | 1,293 | KEEP ←in 5,780 | 1293 | 13.8 |
| 4 | 1 | `L1_query` | context=User wants a comprehensive li…, id_catalog… | 35,100 | — | — | 110.5 |
| | | **TOTAL (4 tools)** | | **37,320** | | **2,220** | **135.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 578 | 10,339 | 17,396 | 85.0 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,212 | 22,630 | 536 | 4.5 |
| 3 | L1-worker | claudeopus46 | 21,418 | 1,907 | 23,325 | 521 | 4.3 |
| 4 | L1-worker | claudeopus46 | 3,767 | 467 | 4,234 | 367 | 3.5 |
| 5 | L1-worker | claudeopus46 | 21,418 | 2,165 | 23,583 | 902 | 6.1 |
| 6 | L1-worker | claudeopus46 | 21,418 | 2,919 | 24,337 | 674 | 4.9 |
| 7 | L1-worker | claudeopus46 | 3,767 | 1,305 | 5,072 | 1,027 | 6.7 |
| 8 | L1-worker | claudeopus46 | 21,418 | 3,817 | 25,235 | 964 | 6.9 |
| 9 | L1-worker | claudeopus46 | 3,767 | 6,298 | 10,065 | 1,548 | 13.1 |
| 10 | L1-worker | claudeopus46 | 21,418 | 5,649 | 27,067 | 5,783 | 32.7 |
| 11 | L1-worker | claudeopus46 | 2,320 | 3,460 | 5,780 | 1,183 | 6.0 |
| 12 | L1-worker | claudeopus46 | 627 | 3,340 | 3,967 | 1,156 | 6.2 |
| 13 | L1-worker | claudeopus46 | 2,543 | 4,793 | 7,336 | 2,261 | 8.5 |
| 14 | L1-worker | claudeopus46 | 1,228 | 7,491 | 8,719 | 1,570 | 6.0 |
| 15 | L1-worker | claudeopus46 | 787 | 38,151 | 38,938 | 873 | 8.3 |
| 16 | L0-main | claudeopus46 | 9,761 | 21,135 | 30,896 | 3,574 | 24.1 |
| 17 | L0-main | claudeopus46 | 2,320 | 3,508 | 5,828 | 1,034 | 5.3 |
| 18 | L0-main | claudeopus46 | 2,543 | 3,918 | 6,461 | 1,097 | 6.5 |
| 19 | L0-main | claudeopus46 | 560 | 4,433 | 4,993 | 330 | 2.7 |
| 20 | L0-main | claudeopus46 | 1,156 | 8,277 | 9,433 | 2,030 | 8.9 |

