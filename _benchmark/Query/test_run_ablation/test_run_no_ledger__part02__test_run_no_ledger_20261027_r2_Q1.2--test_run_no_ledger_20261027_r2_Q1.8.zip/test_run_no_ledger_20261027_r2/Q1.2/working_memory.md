# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_12 | hexane | hexane |
| comp | GLOBcomp_2 | ethanol | ethanol |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all thermophysical properties measured for equimolar hexane + ethanol liquid mixture near 25 °C → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

The ThermoML database contains 7 distinct thermophysical properties measured for the binary hexane + ethanol liquid mixture near 298.15 K (25 °C), spanning 9 data blocks from 5 publications. The properties are: (1) mass density (650.4–789.3 kg/m³), (2) refractive index at the Na D-line (1.357–1.375), (3) speed of sound (1046–1160 m/s), (4) excess molar enthalpy (0.12–0.58 kJ/mol, positive across the full composition range), (5) excess molar volume (8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ m³/mol, positive), (6) liquid–gas surface tension, and (7) viscosity. A binary diffusion coefficient was also found but with only 2 data points in the temperature window. Representative data cover ethanol mole fractions from 0 to 1 and temperatures of 293.15–303.15 K. The positive excess enthalpy and excess molar volume near equimolar composition reflect endothermic mixing and volume expansion, consistent with strong positive deviations from ideality caused by the mismatch between nonpolar hexane and hydrogen-bonding ethanol. Approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Answer:**

#### Thermophysical Properties Measured for the Binary Hexane + Ethanol System Near 25 °C

The ThermoML database contains **7 distinct thermophysical properties** measured for the binary hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) liquid mixture in the temperature range near 298.15 K (25 °C), spread across **9 data blocks** from **5 publications**. Several blocks cover the full composition range (ethanol mole fraction 0–1), including equimolar (x ≈ 0.5).

##### Complete List of Measured Properties

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *#* | *Property* | *GLOBprop ID* | *Representative Block* | *Literature* | *DOI* |
|---|---|---|---|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「1」 | 「**Mass density** (kg/m³)」 | 「GLOBprop_1」 | 「PROPblock_24」 | 「GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| WM_L1_Q1_Table#1_Row#2 | 「2」 | 「**Refractive index (Na D-line)**」 | 「GLOBprop_7」 | 「PROPblock_22」 | 「GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| WM_L1_Q1_Table#1_Row#3 | 「3」 | 「**Speed of sound** (m/s)」 | 「GLOBprop_8」 | 「PROPblock_23」 | 「GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| WM_L1_Q1_Table#1_Row#4 | 「4」 | 「**Excess molar enthalpy** (kJ/mol)」 | 「GLOBprop_17」 | 「PROPblock_5」 | 「GLOBlit_294」 | 「10.1016/j.fluid.2005.08.001」 |
| WM_L1_Q1_Table#1_Row#5 | 「5」 | 「**Excess molar volume** (m³/mol)」 | 「GLOBprop_28」 | 「PROPblock_6」 | 「GLOBlit_294」 | 「10.1016/j.fluid.2005.08.001」 |
| WM_L1_Q1_Table#1_Row#6 | 「6」 | 「**Surface tension, liquid–gas** (N/m)」 | 「—」 | 「—」 | 「GLOBlit_10821」 | 「10.1021/je700215z」 |
| WM_L1_Q1_Table#1_Row#7 | 「7」 | 「**Viscosity** (Pa·s)」 | 「—」 | 「—」 | 「GLOBlit_11449」 | 「10.1021/je800925v」 |

An additional property, **binary diffusion coefficient** (GLOBprop_29), was found in GLOBlit_8445 (DOI: 10.1021/je0497303), though it had only 2 data points in the temperature window.

##### Representative Data Details

- **Mass density** (GLOBlit_2800, PROPblock_24): 15 points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 650.4–789.3 kg/m³. All liquid phase.
- **Speed of sound** (GLOBlit_2800, PROPblock_23): 24 points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1046–1160 m/s.
- **Refractive index** (GLOBlit_2800, PROPblock_22): 13 points, T = 293.15–303.15 K, x(ethanol) = 0–1, values 1.357–1.375.
- **Excess molar enthalpy** (GLOBlit_294, PROPblock_5): 9 points at constrained T (≈298.15 K), x(ethanol) = 0.054–0.953, values 0.12–0.58 kJ/mol. The positive H^E values across the full composition range reflect the endothermic mixing characteristic of the hexane + ethanol system, driven by disruption of ethanol hydrogen-bonding networks upon mixing with the nonpolar alkane.
- **Excess molar volume** (GLOBlit_294, PROPblock_6): 9 points at constrained T, x(ethanol) = 0.042–0.950, values 8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ m³/mol (positive V^E), consistent with volume expansion upon mixing.

##### Chemistry Insight

Hexane + ethanol is a classic partially miscible system at lower temperatures, exhibiting strong positive deviations from ideal mixing. The measured properties collectively characterize the volumetric (density, excess volume), acoustic (speed of sound), optical (refractive index), transport (viscosity, diffusion coefficient), energetic (excess enthalpy), and interfacial (surface tension) behavior. The positive excess enthalpy and excess volume near equimolar composition reflect the thermodynamic non-ideality arising from the mismatch between nonpolar hexane and hydrogen-bonding ethanol. In total, approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Core claims:**
- The ThermoML database contains 7 distinct thermophysical properties measured for the binary hexane + ethanol liquid mixture near 298.15 K: mass density, refractive index (Na D-line), speed of sound, excess molar enthalpy, excess molar volume, surface tension (liquid–gas), and viscosity, spread across 9 data blocks from 5 publications.
- An additional property, binary diffusion coefficient, was found but with only 2 data points in the temperature window.
- Excess molar enthalpy values are positive across the full composition range (0.12–0.58 kJ/mol for ethanol mole fractions 0.054–0.953), reflecting endothermic mixing driven by disruption of ethanol hydrogen-bonding networks upon mixing with nonpolar hexane.
- Excess molar volume values are positive (8.8 × 10⁻⁸ – 4.12 × 10⁻⁷ m³/mol for ethanol mole fractions 0.042–0.950), consistent with volume expansion upon mixing.
- Mass density data span 650.4–789.3 kg/m³ over T = 293.15–303.15 K and ethanol mole fractions 0–1.
- Approximately 400 data points across these properties are available in the 290–310 K window from the five contributing publications.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#2 | 「GLOBlit_2800」 | 「PROPblock_24」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_1」 | 「Mass density measurements for hexane + ethanol binary mixture at 293–303 K across full composition range.」 |
| WM_L1_Q1_Table#3 | 「GLOBlit_2800」 | 「PROPblock_22」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_7」 | 「Refractive index (Na D-line) measurements for hexane + ethanol binary mixture at 293–303 K across full composition range.」 |
| WM_L1_Q1_Table#4 | 「GLOBlit_2800」 | 「PROPblock_23」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_8」 | 「Speed of sound measurements for hexane + ethanol binary mixture at 293–303 K across full composition range.」 |
| WM_L1_Q1_Table#5 | 「GLOBlit_294」 | 「PROPblock_5」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_17」 | 「Excess molar enthalpy measurements for hexane + ethanol binary mixture at ~298.15 K across composition range.」 |
| WM_L1_Q1_Table#6 | 「GLOBlit_294」 | 「PROPblock_6」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_28」 | 「Excess molar volume measurements for hexane + ethanol binary mixture at ~298.15 K across composition range.」 |

*Not stored here: 2 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


