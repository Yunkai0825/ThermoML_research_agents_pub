# Data grounding evidence

- generated: 2026-10-27T03:44:09
- grounding profile: current
- gate verdict: 5 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_22 | — | NO | — | — |
| PROPblock_23 | — | NO | — | — |
| PROPblock_24 | — | NO | — | — |
| PROPblock_5 | — | NO | — | — |
| PROPblock_6 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 39 | PROPblock_24 | uninspected_block | — |
| 293.15 | PROPblock_24 | uninspected_block | — |
| 303.15 | PROPblock_24 | uninspected_block | — |
| 650.4 | PROPblock_24 | uninspected_block | — |
| 789.3 | PROPblock_24 | uninspected_block | — |
| 101 | PROPblock_24 | uninspected_block | — |
| 39 | PROPblock_23 | uninspected_block | — |
| 293.15 | PROPblock_23 | uninspected_block | — |
| 303.15 | PROPblock_23 | uninspected_block | — |
| 1046 | PROPblock_23 | uninspected_block | — |
| 1160 | PROPblock_23 | uninspected_block | — |
| 39 | PROPblock_22 | uninspected_block | — |
| 293.15 | PROPblock_22 | uninspected_block | — |
| 303.15 | PROPblock_22 | uninspected_block | — |
| 1.357 | PROPblock_22 | uninspected_block | — |
| 1.375 | PROPblock_22 | uninspected_block | — |
| 17 | PROPblock_5 | uninspected_block | — |
| 298.15 | PROPblock_5 | uninspected_block | — |
| 101.325 | PROPblock_5 | uninspected_block | — |
| 0.054 | PROPblock_5 | uninspected_block | — |
| 0.953 | PROPblock_5 | uninspected_block | — |
| 0.12 | PROPblock_5 | uninspected_block | — |
| 0.58 | PROPblock_5 | uninspected_block | — |
| 23 | PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_6 | uninspected_block | — |
| 101.325 | PROPblock_6 | uninspected_block | — |
| 0.042 | PROPblock_6 | uninspected_block | — |
| 0.950 | PROPblock_6 | uninspected_block | — |
| 0.58 | PROPblock_6 | uninspected_block | — |
| 400 | PROPblock_6 | uninspected_block | — |
| 290 | PROPblock_6 | uninspected_block | — |
| 310 | PROPblock_6 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_24: PROPblock_24 is quoted with data values (39, 293.15, 303.15, 650.4, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_23: PROPblock_23 is quoted with data values (39, 293.15, 303.15, 1046, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_22: PROPblock_22 is quoted with data values (39, 293.15, 303.15, 1.357, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_5: PROPblock_5 is quoted with data values (17, 298.15, 101.325, 0.054, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_6: PROPblock_6 is quoted with data values (23, 298.15, 101.325, 0.042, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_