# Reference Stats — query-agent

**Run started:** 2026-10-27 03:40:47
**Wall time (at last flush):** 265.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 25,541 | 44,056 | 12,791 | 69,597 | 13,919 | 76.1 | claudeopus46 |
| L1-worker | 21 | 188,354 | 187,332 | 29,134 | 375,686 | 17,889 | 183.4 | claudeopus46 |
| **TOTAL** | **26** | **213,895** | **231,388** | **41,925** | **445,283** | **17,126** | **259.5** | |

**Estimated tokens:** ~111,320 input + ~10,481 output = ~121,801 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 49 | 50 | 249 |
| `resolve_measurement_ids` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 20 | 20 | 81 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **3** | **3** | **4** | **2** | **69** | **70** | **330** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 |  | resolve_property_ids, search_blocks |

#### References (52 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8 |  | search_blocks |
| GLOBlit_267 |  | search_blocks |
| GLOBlit_288 |  | search_blocks |
| GLOBlit_349 |  | search_blocks |
| GLOBlit_359 |  | search_blocks |
| GLOBlit_499 |  | search_blocks |
| GLOBlit_1969 |  | search_blocks |
| GLOBlit_2547 |  | search_blocks |
| GLOBlit_2568 |  | search_blocks |
| GLOBlit_2580 |  | search_blocks |
| GLOBlit_2632 |  | search_blocks |
| GLOBlit_2648 |  | search_blocks |
| GLOBlit_2674 |  | search_blocks |
| GLOBlit_2680 |  | search_blocks |
| GLOBlit_2707 |  | search_blocks |
| GLOBlit_2825 |  | search_blocks |
| GLOBlit_2934 |  | search_blocks |
| GLOBlit_2944 |  | search_blocks |
| GLOBlit_3116 |  | search_blocks |
| GLOBlit_3224 |  | search_blocks |
| GLOBlit_3572 |  | search_blocks |
| GLOBlit_3711 |  | search_blocks |
| GLOBlit_3748 |  | search_blocks |
| GLOBlit_3988 |  | search_blocks |
| GLOBlit_4013 |  | search_blocks |
| GLOBlit_4060 |  | search_blocks |
| GLOBlit_4369 |  | search_blocks |
| GLOBlit_4485 |  | search_blocks |
| GLOBlit_4940 |  | search_blocks |
| GLOBlit_5074 |  | search_blocks |
| GLOBlit_5201 |  | search_blocks |
| GLOBlit_5465 |  | search_blocks |
| GLOBlit_5522 |  | search_blocks |
| GLOBlit_6540 |  | search_blocks |
| GLOBlit_6543 |  | search_blocks |
| GLOBlit_6567 |  | search_blocks |
| GLOBlit_6598 |  | search_blocks |
| GLOBlit_6791 |  | search_blocks |
| GLOBlit_6838 |  | search_blocks |
| GLOBlit_6957 |  | search_blocks |
| GLOBlit_7168 |  | search_blocks |
| GLOBlit_7178 |  | search_blocks |
| GLOBlit_7184 |  | search_blocks |
| GLOBlit_7368 |  | search_blocks |
| GLOBlit_7448 |  | search_blocks |
| GLOBlit_7648 |  | search_blocks |
| GLOBlit_7676 |  | search_blocks |
| GLOBlit_7681 |  | search_blocks |
| GLOBlit_7699 |  | search_blocks |
| GLOBlit_8297 |  | search_blocks |
| GLOBlit_8570 |  | search_blocks |
| GLOBlit_8744 |  | search_blocks |

#### Measurements (28 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_497 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_234 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_1532 |  | resolve_measurement_ids |
| GLOBmeas_2055 |  | resolve_measurement_ids |
| GLOBmeas_2250 |  | resolve_measurement_ids |
| GLOBmeas_1930 |  | resolve_measurement_ids |
| GLOBmeas_1676 |  | resolve_measurement_ids |
| GLOBmeas_129 |  | resolve_measurement_ids |
| GLOBmeas_693 |  | resolve_measurement_ids |
| GLOBmeas_1673 |  | resolve_measurement_ids |
| GLOBmeas_1345 |  | resolve_measurement_ids |
| GLOBmeas_1620 |  | resolve_measurement_ids |
| GLOBmeas_75 |  | resolve_measurement_ids |
| GLOBmeas_1574 |  | resolve_measurement_ids |
| GLOBmeas_645 |  | resolve_measurement_ids |
| GLOBmeas_1008 |  | resolve_measurement_ids |
| GLOBmeas_499 |  | resolve_measurement_ids |
| GLOBmeas_1387 |  | resolve_measurement_ids |
| GLOBmeas_1082 |  | resolve_measurement_ids |
| GLOBmeas_51 |  | resolve_measurement_ids |
| GLOBmeas_1376 |  | resolve_measurement_ids |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 1 |
| Unique References | 52 |
| Unique Measurements | 28 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Total DOIs | 52 |
| Unique parent blocks | 53 |
| Explicit block/subsystem targets | 53 |
| Subsystem targets | 0 |
| Target-matched data points | 330 |

---

## 3. DOI & Block References

**Unique DOIs:** 52  |  **Parent blocks:** 53  |  **Explicit targets:** 53  |  **Subsystems:** 0  |  **Target-matched datapoints:** 259

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-005-8089-2 | 1 | 23 | unary | search_blocks |
| 10.1016/j.fluid.2005.05.012 | 1 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2005.07.010 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2006.01.008 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2006.01.030 | 2 | 23 | unary | search_blocks |
| 10.1016/j.fluid.2007.03.021 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2016.08.022 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2005.04.019 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2005.06.011 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2005.07.008 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2005.10.022 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2005.12.010 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2006.03.010 | 1 | 2 | unary | search_blocks |
| 10.1016/j.jct.2006.03.018 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2006.06.008 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2007.05.004 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2008.03.013 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2008.04.006 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2009.06.023 | 1 | 11 | unary | search_blocks |
| 10.1016/j.jct.2010.03.022 | 1 | 23 | unary | search_blocks |
| 10.1016/j.jct.2012.02.027 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2012.08.024 | 1 | 7 | unary | search_blocks |
| 10.1016/j.jct.2012.10.008 | 1 | 5 | unary | search_blocks |
| 10.1016/j.jct.2013.09.006 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2013.09.044 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2013.11.026 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2015.04.027 | 1 | 5 | unary | search_blocks |
| 10.1016/j.jct.2015.08.036 | 1 | 5 | unary | search_blocks |
| 10.1016/j.jct.2016.12.036 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2017.07.022 | 1 | 7 | unary | search_blocks |
| 10.1016/j.jct.2018.02.022 | 1 | 4 | unary | search_blocks |
| 10.1016/j.jct.2019.02.019 | 1 | 4 | unary | search_blocks |
| 10.1016/j.jct.2019.04.023 | 1 | 7 | unary | search_blocks |
| 10.1021/acs.jced.5b00152 | 1 | 27 | unary | search_blocks |
| 10.1021/acs.jced.5b00162 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.5b00259 | 1 | 7 | unary | search_blocks |
| 10.1021/acs.jced.5b00365 | 1 | 7 | unary | search_blocks |
| 10.1021/acs.jced.5b01000 | 1 | 3 | unary | search_blocks |
| 10.1021/acs.jced.6b00096 | 1 | 2 | unary | search_blocks |
| 10.1021/acs.jced.6b00563 | 1 | 3 | unary | search_blocks |
| 10.1021/acs.jced.7b00267 | 1 | 9 | unary | search_blocks |
| 10.1021/acs.jced.7b00299 | 1 | 2 | unary | search_blocks |
| 10.1021/acs.jced.7b00321 | 1 | 4 | unary | search_blocks |
| 10.1021/acs.jced.7b00944 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.8b00086 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.8b00793 | 1 | 4 | unary | search_blocks |
| 10.1021/acs.jced.8b00939 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.8b00965 | 1 | 5 | unary | search_blocks |
| 10.1021/acs.jced.8b01012 | 1 | 4 | unary | search_blocks |
| 10.1021/je034203p | 1 | 1 | unary | search_blocks |
| 10.1021/je050010l | 1 | 3 | unary | search_blocks |
| 10.1021/je050367p | 1 | 6 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-005-8089-2 | PROPblock_1 | declared | 23 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.05.012 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.07.010 | PROPblock_9 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.01.008 | PROPblock_11 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.01.030 | PROPblock_1 | declared | 20 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.01.030 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.03.021 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2016.08.022 | PROPblock_6 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2005.04.019 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2005.06.011 | PROPblock_26 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2005.07.008 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2005.10.022 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2005.12.010 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.03.010 | PROPblock_7 | declared | 2 | unary | — | search_blocks |
| 10.1016/j.jct.2006.03.018 | PROPblock_6 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.06.008 | PROPblock_13 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2007.05.004 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2008.03.013 | PROPblock_5 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2008.04.006 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2009.06.023 | PROPblock_1 | declared | 11 | unary | — | search_blocks |
| 10.1016/j.jct.2010.03.022 | PROPblock_2 | declared | 23 | unary | — | search_blocks |
| 10.1016/j.jct.2012.02.027 | PROPblock_11 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2012.08.024 | PROPblock_4 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.jct.2012.10.008 | PROPblock_6 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.jct.2013.09.006 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2013.09.044 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.11.026 | PROPblock_17 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2015.04.027 | PROPblock_4 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.jct.2015.08.036 | PROPblock_2 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.jct.2016.12.036 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2017.07.022 | PROPblock_2 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_3 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.jct.2019.02.019 | PROPblock_6 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.jct.2019.04.023 | PROPblock_5 | declared | 7 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00152 | PROPblock_10 | declared | 27 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00162 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00259 | PROPblock_6 | declared | 7 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00365 | PROPblock_4 | declared | 7 | unary | — | search_blocks |
| 10.1021/acs.jced.5b01000 | PROPblock_12 | declared | 3 | unary | — | search_blocks |
| 10.1021/acs.jced.6b00096 | PROPblock_2 | declared | 2 | unary | — | search_blocks |
| 10.1021/acs.jced.6b00563 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00267 | PROPblock_2 | declared | 9 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00299 | PROPblock_2 | declared | 2 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00321 | PROPblock_10 | declared | 4 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00944 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00086 | PROPblock_17 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00793 | PROPblock_2 | declared | 4 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00939 | PROPblock_12 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00965 | PROPblock_4 | declared | 5 | unary | — | search_blocks |
| 10.1021/acs.jced.8b01012 | PROPblock_6 | declared | 4 | unary | — | search_blocks |
| 10.1021/je034203p | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1021/je050010l | PROPblock_5 | declared | 3 | unary | — | search_blocks |
| 10.1021/je050367p | PROPblock_5 | declared | 6 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve ethanol to … | 238 | KEEP ←in 222 | 238 | 7.9 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=80, purpose=Confirm GLOBprop_4 … | 262 | KEEP ←in 213 | 262 | 4.2 |
| 3 | 4 | `search_blocks` | compound=GLOBcomp_2, limit=50, property=GLOBprop_4… | 1,121 | KEEP ←in 26,815 | 1106 | 21.6 |
| 4 | 5 | `resolve_measurement_ids` | limit=20, min_score=50, purpose=Find measurement m… | 1,678 | KEEP ←in 1,619 | 1678 | 10.3 |
| 5 | 5 | `search_blocks` | compound=GLOBcomp_2, limit=20, measurement=GLOBmea… | 783 | DISCARD ←in 39 | 725 | 9.1 |
| 6 | 6 | `search_blocks` | compound=GLOBcomp_2, limit=20, measurement=GLOBmea… | 1,086 | KEEP ←in 10,724 | 1071 | 13.1 |
| 7 | 6 | `search_blocks` | compound=GLOBcomp_2, limit=20, measurement=GLOBmea… | 748 | DISCARD ←in 39 | 690 | 10.0 |
| 8 | 1 | `L1_query` | context=User wants to know how viscos…, id_catalog… | 45,120 | — | — | 192.5 |
| | | **TOTAL (8 tools)** | | **51,036** | | **5,770** | **268.7** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 589 | 10,350 | 1,229 | 7.8 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,084 | 22,502 | 916 | 6.8 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,476 | 23,894 | 861 | 5.1 |
| 4 | L1-worker | claudeopus46 | 3,767 | 391 | 4,158 | 274 | 3.5 |
| 5 | L1-worker | claudeopus46 | 3,767 | 693 | 4,460 | 496 | 3.9 |
| 6 | L1-worker | claudeopus46 | 3,767 | 368 | 4,135 | 416 | 4.1 |
| 7 | L1-worker | claudeopus46 | 21,418 | 2,421 | 23,839 | 927 | 6.9 |
| 8 | L1-worker | claudeopus46 | 21,418 | 3,178 | 24,596 | 613 | 4.7 |
| 9 | L1-worker | claudeopus46 | 3,767 | 27,248 | 31,015 | 1,735 | 13.3 |
| 10 | L1-worker | claudeopus46 | 21,418 | 4,446 | 25,864 | 2,135 | 12.8 |
| 11 | L1-worker | claudeopus46 | 3,767 | 1,807 | 5,574 | 1,986 | 9.6 |
| 12 | L1-worker | claudeopus46 | 3,767 | 519 | 4,286 | 1,280 | 7.8 |
| 13 | L1-worker | claudeopus46 | 21,418 | 7,659 | 29,077 | 1,865 | 11.6 |
| 14 | L1-worker | claudeopus46 | 3,767 | 11,194 | 14,961 | 1,427 | 12.1 |
| 15 | L1-worker | claudeopus46 | 3,767 | 545 | 4,312 | 1,393 | 9.6 |
| 16 | L1-worker | claudeopus46 | 21,418 | 10,259 | 31,677 | 4,454 | 27.3 |
| 17 | L1-worker | claudeopus46 | 2,320 | 2,875 | 5,195 | 713 | 4.3 |
| 18 | L1-worker | claudeopus46 | 627 | 2,755 | 3,382 | 775 | 4.9 |
| 19 | L1-worker | claudeopus46 | 2,543 | 4,080 | 6,623 | 2,942 | 10.4 |
| 20 | L1-worker | claudeopus46 | 787 | 47,540 | 48,327 | 778 | 8.1 |
| 21 | L1-worker | claudeopus46 | 1,228 | 8,208 | 9,436 | 2,438 | 9.2 |
| 22 | L1-worker | claudeopus46 | 787 | 47,586 | 48,373 | 710 | 7.4 |
| 23 | L0-main | claudeopus46 | 9,761 | 21,672 | 31,433 | 5,303 | 35.9 |
| 24 | L0-main | claudeopus46 | 2,320 | 4,770 | 7,090 | 931 | 5.4 |
| 25 | L0-main | claudeopus46 | 2,543 | 5,191 | 7,734 | 1,683 | 9.0 |
| 26 | L0-main | claudeopus46 | 1,156 | 11,834 | 12,990 | 3,645 | 18.0 |

