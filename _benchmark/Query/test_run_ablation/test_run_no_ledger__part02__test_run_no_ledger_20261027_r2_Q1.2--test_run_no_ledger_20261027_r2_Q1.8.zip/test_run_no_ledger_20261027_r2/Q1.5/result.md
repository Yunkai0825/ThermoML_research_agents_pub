# Q1.5 — Result

**Prompt:** How has the viscosity of pure liquid ethanol near 25 °C been measured, and what values were reported by the different methods?

**Tool calls:** 1  |  **Time:** 358.9s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity of Pure Liquid Ethanol near 25 °C (298.15 K)

### Overview

The ThermoML database contains **50 data blocks** reporting the dynamic viscosity of pure liquid ethanol (CAS 64-17-5) in the temperature window 297–299 K, all at or near atmospheric pressure. The measurements span multiple independent laboratories and publications, providing an excellent picture of both the measurement landscape and the consensus value.

---

### Measurement Methods

**1. Capillary tube (Ostwald / Ubbelohde) viscometry** — the dominant technique, accounting for at least **20 of the 50 blocks**. This classical method measures the time for a fixed volume of liquid to flow through a narrow capillary under gravity. It is the gold-standard approach for low-viscosity Newtonian liquids like ethanol because of its high precision and straightforward calibration.

**2. Falling / rolling sphere viscometry** — also represented in the database. In this method a sphere descends through the liquid under gravity, and the terminal velocity is related to viscosity via Stokes' law (or its rolling-ball variant).

Other viscometry techniques catalogued in ThermoML (rotational, oscillating, vibrating wire, Stabinger) were not found for pure ethanol in this narrow temperature window.

---

### Reported Values by Method

#### Capillary viscometry results at 298.15 K

| η (Pa·s) | η (mPa·s) | DOI | Source |
|-----------|-----------|-----|--------|
| 0.001077 | 1.077 | 10.1016/j.fluid.2006.01.008 (GLOBlit_349, PROPblock_11) | Arce, Rodríguez et al. (2006) |
| 0.001082 | 1.082 | 10.1016/j.fluid.2007.03.021 (GLOBlit_499, PROPblock_3) | Calvar, González et al. (2007) |
| 0.001087 | 1.087 | 10.1016/j.jct.2012.02.027 (GLOBlit_3572, PROPblock_11) | Quijada-Maldonado, Boone et al. (2012) |
| 0.001093 | 1.093 | 10.1016/j.jct.2005.04.019 (GLOBlit_2547, PROPblock_4) | Iloukhani, Samiey et al. (2006) |

Two additional multi-temperature capillary studies bracket 298.15 K:

| T range (K) | η range (Pa·s) | DOI | Source |
|-------------|----------------|-----|--------|
| 293.15–333.15 | 0.00059–0.001194 | 10.1016/j.fluid.2006.01.030 (GLOBlit_359, PROPblock_2) | Zebarjad, Watson et al. (2006) |
| 293.15–333.15 | 0.0005849–0.0011608 | 10.1016/j.fluid.2016.08.022 (GLOBlit_1969, PROPblock_6) | Yang, González et al. (2016) |

#### Other / unspecified method results at 298.15 K

| η (Pa·s) | η (mPa·s) | DOI | Source | Method |
|-----------|-----------|-----|--------|--------|
| 0.001082 | 1.082 | 10.1016/j.fluid.2005.07.010 (GLOBlit_288, PROPblock_9) | Calvar, Domínguez et al. (2005) | Not specified |
| 0.001105 | 1.105 | 10.1016/j.jct.2005.07.008 (GLOBlit_2580, PROPblock_3) | Rodríguez, Pereiro et al. (2006) | Not specified |

#### Falling / rolling sphere viscometry at ~298.2 K

| η (Pa·s) | η (mPa·s) | DOI | Source |
|-----------|-----------|-----|--------|
| 0.001187 | 1.187 | 10.1016/j.jct.2013.09.044 (GLOBlit_4013, PROPblock_6) | González, Kosiński et al. (2014) |

This falling-sphere value (1.187 mPa·s) is notably higher than the capillary-based cluster, sitting about 9% above the capillary mean. Falling-body methods can be somewhat less precise for low-viscosity fluids and may be more sensitive to calibration and buoyancy corrections.

---

### Consensus and Chemistry Insight

All **capillary viscometry** measurements at exactly 298.15 K fall in the tight band **1.077–1.093 mPa·s**, with a mean of approximately **1.08–1.09 mPa·s** and a spread of only about ±1.5%. This remarkable consistency across independent laboratories and years of publication reflects ethanol's status as a well-characterized viscosity reference substance.

The viscosity of ethanol at 25 °C is governed by its extensive hydrogen-bonding network: each ethanol molecule can act as both a hydrogen-bond donor (O–H) and acceptor (lone pairs on oxygen), creating transient chain-like and cyclic aggregates in the liquid. These associations increase the effective hydrodynamic size of the flowing units and raise the viscosity above what would be expected for a simple polar molecule of similar molecular weight. Despite this, ethanol remains a low-viscosity liquid (≈1.1 mPa·s vs. water's ≈0.89 mPa·s at 25 °C) because its single hydroxyl group limits the degree of cross-linking compared to polyols.

**Bottom line:** The ThermoML-recommended consensus for the dynamic viscosity of pure liquid ethanol at 298.15 K and atmospheric pressure is **≈ 1.08–1.09 mPa·s (0.00108–0.00109 Pa·s)**, predominantly established by capillary tube viscometry across at least 20 independent measurements.

### Core claims

- The ThermoML database contains 50 data blocks reporting the dynamic viscosity of pure liquid ethanol (CAS 64-17-5) in the temperature window 297–299 K at or near atmospheric pressure.
- Capillary tube (Ostwald/Ubbelohde) viscometry is the dominant measurement technique, accounting for at least 20 of the 50 blocks.
- All capillary viscometry measurements at exactly 298.15 K fall in the tight band 1.077–1.093 mPa·s, with a spread of only about ±1.5%.
- A falling/rolling sphere viscometry value of 1.187 mPa·s at ~298.2 K is notably higher than the capillary-based cluster, sitting about 9% above the capillary mean.
- The ThermoML-recommended consensus for the dynamic viscosity of pure liquid ethanol at 298.15 K and atmospheric pressure is ≈ 1.08–1.09 mPa·s (0.00108–0.00109 Pa·s), predominantly established by capillary tube viscometry.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_349 | 10.1016/j.fluid.2006.01.008 | PROPblock_11 |  | Provides a capillary tube viscosity measurement of pure ethanol at 298.15 K and 101.325 kPa, reporting 0.001077 Pa·s (1.077 mPa·s), which anchors the low end of the consensus band cited in the answer. |
| GLOBlit_499 | 10.1016/j.fluid.2007.03.021 | PROPblock_3 |  | Capillary tube viscosity of pure ethanol at 298.15 K giving 0.001082 Pa·s (1.082 mPa·s), an independent confirmation of the ~1.08 mPa·s consensus value. |
| GLOBlit_3572 | 10.1016/j.jct.2012.02.027 | PROPblock_11 |  | Reports capillary viscosity of pure ethanol at 298.15 K as 0.001087 Pa·s (1.087 mPa·s), contributing to the mid-range of the capillary consensus cluster. |
| GLOBlit_2547 | 10.1016/j.jct.2005.04.019 | PROPblock_4 |  | Capillary tube measurement of pure ethanol viscosity at 298.15 K yielding 0.001093 Pa·s (1.093 mPa·s), the highest value in the capillary cluster and helping define the upper bound of the 1.077–1.093 mPa·s range. |
| GLOBlit_359 | 10.1016/j.fluid.2006.01.030 | PROPblock_2 |  | Multi-temperature capillary viscosity data for pure ethanol spanning 293.15–333.15 K (0.00059–0.001194 Pa·s), bracketing 298.15 K and supporting the temperature-dependent context discussed in the answer. |
| GLOBlit_1969 | 10.1016/j.fluid.2016.08.022 | PROPblock_6 |  | Another multi-temperature capillary dataset for pure ethanol over 293.15–333.15 K (0.000585–0.001161 Pa·s), providing an independent temperature-range bracket around 298.15 K consistent with the consensus. |
| GLOBlit_288 | 10.1016/j.fluid.2005.07.010 | PROPblock_9 |  | Pure ethanol viscosity at 298.15 K of 0.001082 Pa·s (1.082 mPa·s) via capillary tube method (CAPTUB), reinforcing the consensus value. The answer listed this as 'method not specified' but the card confirms capillary tube. |
| GLOBlit_2580 | 10.1016/j.jct.2005.07.008 | PROPblock_3 |  | Reports pure ethanol viscosity at 298.15 K as 0.001105 Pa·s (1.105 mPa·s) via capillary tube method. This slightly higher value provides useful contrast to the main cluster and is discussed in the answer. |
| GLOBlit_4013 | 10.1016/j.jct.2013.09.044 | PROPblock_6 |  | Falling/rolling sphere viscometry measurement of pure ethanol at 298.2 K giving 0.001187 Pa·s (1.187 mPa·s). This is the sole falling-sphere result and is explicitly discussed in the answer as an outlier ~9% above the capillary consensus, illustrating method-dependent differences. |

### Suggested follow-ups

- Compare the viscosity of ethanol with other short-chain alcohols (methanol, 1-propanol, 1-butanol) at 298.15 K to examine the effect of chain length on hydrogen-bonding and viscosity.
- Investigate how the viscosity of ethanol changes with temperature across a wider range (e.g., 278–348 K) to characterize its Arrhenius-type temperature dependence.
- Examine viscosity data for ethanol–water binary mixtures near 25 °C to explore the well-known viscosity maximum arising from enhanced hydrogen-bond networking.
