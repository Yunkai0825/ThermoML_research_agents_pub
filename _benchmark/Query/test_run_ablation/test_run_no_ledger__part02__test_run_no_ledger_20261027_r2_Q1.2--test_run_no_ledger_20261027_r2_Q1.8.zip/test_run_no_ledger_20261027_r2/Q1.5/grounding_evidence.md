# Data grounding evidence

- generated: 2026-10-27T03:44:44
- grounding profile: current
- gate verdict: 8 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_11 | — | NO | — | — |
| PROPblock_2 | — | NO | — | — |
| PROPblock_3 | — | NO | — | — |
| PROPblock_4 | — | NO | — | — |
| PROPblock_6 | — | NO | — | — |
| PROPblock_9 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 0.001077 | PROPblock_11 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 1.077 | PROPblock_11 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 0.001082 | PROPblock_11 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 1.082 | PROPblock_11 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 0.001087 | PROPblock_11 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 1.087 | PROPblock_11 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 0.001093 | PROPblock_11 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 1.093 | PROPblock_11 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 298.15 | PROPblock_4 | uninspected_block | — |
| 293.15 | PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 333.15 | PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.00059 | PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.001194 | PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 293.15 | PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 333.15 | PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0005849 | PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0011608 | PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_6 | uninspected_block | — |
| 0.001082 | PROPblock_9 + PROPblock_3 | uninspected_block | — |
| 1.082 | PROPblock_9 + PROPblock_3 | uninspected_block | — |
| 0.001105 | PROPblock_9 + PROPblock_3 | uninspected_block | — |
| 1.105 | PROPblock_9 + PROPblock_3 | uninspected_block | — |
| 298.2 | PROPblock_3 | uninspected_block | — |
| 0.001187 | PROPblock_6 | uninspected_block | — |
| 1.187 | PROPblock_6 | uninspected_block | — |
| 1.187 | PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_6 | uninspected_block | — |
| 1.077 | PROPblock_6 | uninspected_block | — |
| 1.093 | PROPblock_6 | uninspected_block | — |
| 1.08 | PROPblock_6 | uninspected_block | — |
| 1.09 | PROPblock_6 | uninspected_block | — |
| 25 | PROPblock_6 | uninspected_block | — |
| 1.1 | PROPblock_6 | uninspected_block | — |
| 0.89 | PROPblock_6 | uninspected_block | — |
| 25 | PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_6 | uninspected_block | — |
| 1.08 | PROPblock_6 | uninspected_block | — |
| 1.09 | PROPblock_6 | uninspected_block | — |
| 0.00108 | PROPblock_6 | uninspected_block | — |
| 0.00109 | PROPblock_6 | uninspected_block | — |
| 20 | PROPblock_6 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_11 + PROPblock_3 + PROPblock_4: PROPblock_11 + PROPblock_3 + PROPblock_4 is quoted with data values (0.001077, 1.077, 0.001082, 1.082, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_4: PROPblock_4 is quoted with data values (298.15, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_2 + PROPblock_6: PROPblock_2 + PROPblock_6 is quoted with data values (293.15, 333.15, 0.00059, 0.001194, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_6: PROPblock_6 is quoted with data values (298.15, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_9 + PROPblock_3: PROPblock_9 + PROPblock_3 is quoted with data values (0.001082, 1.082, 0.001105, 1.105, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_3: PROPblock_3 is quoted with data values (298.2, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_6: PROPblock_6 is quoted with data values (0.001187, 1.187, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_6: PROPblock_6 is quoted with data values (1.187, 298.15, 1.077, 1.093, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_