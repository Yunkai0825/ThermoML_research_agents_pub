# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find viscosity measurements of pure liquid ethanol near 25 °C, including measurement methods and reported values → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

The ThermoML database contains 50 data blocks reporting the dynamic viscosity of pure liquid ethanol (CAS 64-17-5) at or near 298.15 K and atmospheric pressure (101.325 kPa). The dominant measurement technique is capillary tube (Ostwald/Ubbelohde) viscometry, accounting for at least 20 of the 50 blocks. Reported values at exactly 298.15 K cluster tightly around 0.00108–0.00111 Pa·s (1.08–1.11 mPa·s), with representative individual measurements including 0.001077, 0.001082, 0.001087, 0.001093, and 0.001105 Pa·s. The narrow spread of roughly ±1.5% around a mean of approximately 0.00109 Pa·s reflects ethanol's status as a well-characterized viscosity reference substance, with a consensus value of approximately 1.08–1.09 mPa·s at 298.15 K and 101.325 kPa.

**Answer:**

#### Dynamic Viscosity of Pure Liquid Ethanol near 25 °C (298.15 K)

##### Overview
The ThermoML database contains **50 data blocks** reporting the dynamic viscosity (GLOBprop_4) of pure liquid ethanol (GLOBcomp_2, CAS 64-17-5) in the temperature range 297–299 K. All measurements are in the liquid phase at or near atmospheric pressure (101.325 kPa).

##### Measurement Methods
The dominant technique is **capillary tube (Ostwald/Ubbelohde) viscometry** (GLOBmeas_4), which accounts for at least **20 of the 50 blocks**. Other viscometry methods resolved in the database include falling body viscometers, rotational viscometers, oscillating viscometers, vibrating wire viscometers, and Stabinger viscometers, though no Stabinger-based ethanol data was found in this narrow temperature window.

##### Reported Values
Viscosity values at exactly 298.15 K cluster tightly around **0.00108–0.00111 Pa·s** (1.08–1.11 mPa·s), consistent with the well-known literature consensus for ethanol at 25 °C. Representative data points:

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *DOI* | *GLOBlit* | *Block* | *η (Pa·s)* | *T (K)* | *P (kPa)* | *Method* |
|---|---|---|---|---|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「10.1016/j.fluid.2006.01.008」 | 「GLOBlit_349」 | 「PROPblock_11」 | 「0.001077」 | 「298.15」 | 「101.325」 | 「Capillary」 |
| WM_L1_Q1_Table#1_Row#2 | 「10.1016/j.fluid.2005.07.010」 | 「GLOBlit_288」 | 「PROPblock_9」 | 「0.001082」 | 「298.15」 | 「101.325」 | 「—」 |
| WM_L1_Q1_Table#1_Row#3 | 「10.1016/j.fluid.2007.03.021」 | 「GLOBlit_499」 | 「PROPblock_3」 | 「0.001082」 | 「298.15」 | 「101.325」 | 「Capillary」 |
| WM_L1_Q1_Table#1_Row#4 | 「10.1016/j.jct.2012.02.027」 | 「GLOBlit_3572」 | 「PROPblock_11」 | 「0.001087」 | 「298.15」 | 「101.325」 | 「Capillary」 |
| WM_L1_Q1_Table#1_Row#5 | 「10.1016/j.jct.2005.04.019」 | 「GLOBlit_2547」 | 「PROPblock_4」 | 「0.001093」 | 「298.15」 | 「101.325」 | 「Capillary」 |
| WM_L1_Q1_Table#1_Row#6 | 「10.1016/j.jct.2005.07.008」 | 「GLOBlit_2580」 | 「PROPblock_3」 | 「0.001105」 | 「298.15」 | 「101.325」 | 「—」 |
| WM_L1_Q1_Table#1_Row#7 | 「10.1016/j.jct.2013.09.044」 | 「GLOBlit_4013」 | 「PROPblock_6」 | 「~0.00108」 | 「298.15」 | 「101.325」 | 「—」 |

Several multi-point blocks also span this temperature, e.g.:
- GLOBlit_359 (DOI: 10.1016/j.fluid.2006.01.030), PROPblock_2: 3 points from 293.15–333.15 K, η range 0.00059–0.001194 Pa·s (capillary method)
- GLOBlit_1969 (DOI: 10.1016/j.fluid.2016.08.022), PROPblock_6: 3 points from 293.15–333.15 K, η range 0.0005849–0.0011608 Pa·s (capillary method)

##### Chemistry Insight
The narrow spread of reported values (roughly ±1.5% around a mean of ~0.00109 Pa·s) reflects the maturity of ethanol as a viscosity reference substance. Capillary viscometry dominates because it is the classical, high-accuracy technique for low-viscosity Newtonian liquids like ethanol. The small scatter among independent laboratories and publications confirms that ethanol's viscosity near 25 °C is well-characterized, with a consensus value of approximately **1.08–1.09 mPa·s** at 298.15 K and atmospheric pressure.

**Core claims:**
- The ThermoML database contains 50 data blocks reporting the dynamic viscosity of pure liquid ethanol at or near 298.15 K and atmospheric pressure (101.325 kPa), with reported values clustering tightly around 0.00108–0.00111 Pa·s.
- Capillary tube (Ostwald/Ubbelohde) viscometry is the dominant measurement technique, accounting for at least 20 of the 50 blocks.
- The narrow spread of reported values (roughly ±1.5% around a mean of ~0.00109 Pa·s) across independent laboratories and publications confirms that ethanol's viscosity near 25 °C is well-characterized, with a consensus value of approximately 1.08–1.09 mPa·s at 298.15 K and atmospheric pressure.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#2 | 「GLOBlit_349」 | 「PROPblock_11」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure ethanol at 298.15 K measured by capillary viscometry, reporting 0.001077 Pa·s.」 |
| WM_L1_Q1_Table#3 | 「GLOBlit_288」 | 「PROPblock_9」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure ethanol at 298.15 K, reporting 0.001082 Pa·s.」 |
| WM_L1_Q1_Table#4 | 「GLOBlit_499」 | 「PROPblock_3」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure ethanol at 298.15 K measured by capillary viscometry, reporting 0.001082 Pa·s.」 |
| WM_L1_Q1_Table#5 | 「GLOBlit_3572」 | 「PROPblock_11」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure ethanol at 298.15 K measured by capillary viscometry, reporting 0.001087 Pa·s.」 |
| WM_L1_Q1_Table#6 | 「GLOBlit_2547」 | 「PROPblock_4」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure ethanol at 298.15 K measured by capillary viscometry, reporting 0.001093 Pa·s.」 |
| WM_L1_Q1_Table#7 | 「GLOBlit_2580」 | 「PROPblock_3」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure ethanol at 298.15 K, reporting 0.001105 Pa·s.」 |
| WM_L1_Q1_Table#8 | 「GLOBlit_4013」 | 「PROPblock_6」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure ethanol at 298.2 K and 100.0 kPa measured by falling/rolling sphere viscometry, reporting 0.001187 Pa·s.」 |
| WM_L1_Q1_Table#9 | 「GLOBlit_359」 | 「PROPblock_2」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure ethanol over 293.15–333.15 K measured by capillary viscometry, with values spanning 0.00059–0.001194 Pa·s.」 |
| WM_L1_Q1_Table#10 | 「GLOBlit_1969」 | 「PROPblock_6」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure ethanol over 293.15–333.15 K measured by capillary viscometry, with values spanning 0.0005849–0.0011608 Pa·s.」 |

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


