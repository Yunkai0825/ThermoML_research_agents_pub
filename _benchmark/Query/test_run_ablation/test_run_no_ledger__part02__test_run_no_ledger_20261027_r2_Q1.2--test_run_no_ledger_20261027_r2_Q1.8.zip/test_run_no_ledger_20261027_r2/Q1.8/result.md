# Q1.8 — Result

**Prompt:** What critical temperature, critical pressure and critical density of 1,1,1,2-tetrafluoroethane (R134a) does ThermoML hold? Give each value with its reported uncertainty and source, and say whether the sources are independent determinations.

**Tool calls:** 1  |  **Time:** 305.3s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

## Critical Properties of 1,1,1,2-Tetrafluoroethane (R-134a) in ThermoML

The ThermoML database contains critical temperature, critical pressure, and critical density data for pure 1,1,1,2-tetrafluoroethane (R-134a, C₂H₂F₄, CAS 811-97-2) from **three independent literature sources**. The values show remarkable mutual consistency.

---

### Critical Temperature (*T*c)

All three sources report **T_c = 374.13 K**, determined by visual observation in an unstirred cell:

| Source (DOI) | *T*c (K) | Expanded uncertainty (95 %) |
|---|---|---|
| 10.1021/je0201976 (GLOBlit_8063) | 374.13 | ± 0.07 K |
| 10.1021/je0499420 (GLOBlit_8544) | 374.13 | ± 0.16 K |
| 10.1021/je0499723 (GLOBlit_8560) | 374.13 | ± 0.16 K |

### Critical Pressure (*P*c)

Values cluster tightly at 4051–4053 kPa (~40.5 bar), measured by direct pressure measurement:

| Source (DOI) | *P*c (kPa) | Expanded uncertainty (95 %) |
|---|---|---|
| 10.1021/je0201976 (GLOBlit_8063) | 4051.0 | ± 5.0 kPa |
| 10.1021/je0499420 (GLOBlit_8544) | 4053.0 | ± 12.0 kPa |
| 10.1021/je0499723 (GLOBlit_8560) | 4053.0 | ± 12.0 kPa |

### Critical Density (*ρ*c)

All three sources report **ρ_c = 508.0 kg/m³**:

| Source (DOI) | *ρ*c (kg/m³) | Expanded uncertainty (95 %) |
|---|---|---|
| 10.1021/je0201976 (GLOBlit_8063) | 508.0 | ± 2.0 kg/m³ |
| 10.1021/je0499420 (GLOBlit_8544) | 508.0 | ± 12.0 kg/m³ |
| 10.1021/je0499723 (GLOBlit_8560) | 508.0 | ± 12.0 kg/m³ |

---

### Are the sources independent?

The three publications carry **different DOIs and different author lists** (Yasumoto & Yamamoto, 2003; Otake, Uchida et al., 2004; Uchida, Yasumoto et al., 2004), so they represent three separate published determinations. That said, two of the three (GLOBlit_8544 and GLOBlit_8560) share overlapping author groups and report identical central values with identical uncertainties for all three properties, suggesting they may originate from the same laboratory programme. The earliest paper (GLOBlit_8063, DOI 10.1021/je0201976) appears to be a genuinely independent determination and also provides the tightest uncertainties.

### Summary of consensus values

| Property | Consensus value | Best reported uncertainty |
|---|---|---|
| Critical temperature | **374.13 K** | ± 0.07 K |
| Critical pressure | **4051–4053 kPa** | ± 5.0 kPa |
| Critical density | **508.0 kg/m³** | ± 2.0 kg/m³ |

All measurements pertain to the pure compound at the liquid–gas critical point. The most precise set comes from DOI 10.1021/je0201976 (GLOBlit_8063). All uncertainties are expanded uncertainties at the 95 % confidence level. The perfect agreement in *T*c and *ρ*c across all three sources, and the mere 2 kPa spread in *P*c, lend high confidence to these critical constants for R-134a.

### Core claims

- The ThermoML database contains critical property data for pure 1,1,1,2-tetrafluoroethane (R-134a, CAS 811-97-2) from three independent literature sources (DOIs 10.1021/je0201976, 10.1021/je0499420, 10.1021/je0499723).
- All three sources report a critical temperature of 374.13 K, with expanded uncertainties (95 %) ranging from ± 0.07 K to ± 0.16 K.
- Critical pressure values cluster at 4051–4053 kPa across the three sources, with expanded uncertainties (95 %) of ± 5.0 kPa to ± 12.0 kPa.
- All three sources report a critical density of 508.0 kg/m³, with expanded uncertainties (95 %) of ± 2.0 kg/m³ to ± 12.0 kg/m³.
- Two of the three sources (GLOBlit_8544 and GLOBlit_8560) share overlapping author groups and report identical central values with identical uncertainties, suggesting they may originate from the same laboratory programme.
- The most precise determination comes from DOI 10.1021/je0201976 (GLOBlit_8063), which provides the tightest uncertainties for all three critical properties.

**Confidence:** high

### Suggested follow-ups

- Compare these ThermoML critical constants for R-134a with NIST/REFPROP recommended values to assess consistency.
- Investigate whether GLOBlit_8544 and GLOBlit_8560 share the same experimental apparatus by examining their full author lists and methodology sections.
- Search ThermoML for vapor-liquid equilibrium or saturation data for R-134a near the critical point to see if the critical properties are consistent with the phase envelope.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_95",
    "registry_id": "1,1,1,2-tetrafluoroethane",
    "name": "1,1,1,2-tetrafluoroethane"
  }
]
```
