# Reference Stats — query-agent

**Run started:** 2026-10-27 03:45:53
**Wall time (at last flush):** 245.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 26,467 | 38,870 | 28,844 | 65,337 | 9,333 | 146.9 | claudeopus46 |
| L1-worker | 15 | 118,318 | 65,195 | 15,538 | 183,513 | 12,234 | 98.9 | claudeopus46 |
| **TOTAL** | **22** | **144,785** | **104,065** | **44,382** | **248,850** | **11,311** | **245.8** | |

**Estimated tokens:** ~62,212 input + ~11,095 output = ~73,307 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 3 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 0 | 0 | 3 | 3 | 3 |
| `search_blocks` | 1 | 1 | 0 | 0 | 3 | 3 | 3 |
| `search_blocks` | 1 | 1 | 0 | 0 | 3 | 3 | 3 |
| **TOTAL** | **4** | **6** | **0** | **0** | **9** | **9** | **9** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_95 |  | resolve_compound_ids, search_blocks |

#### Properties (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_23 |  | resolve_property_ids, search_blocks |
| GLOBprop_25 |  | resolve_property_ids, search_blocks |
| GLOBprop_54 |  | resolve_property_ids, search_blocks |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8063 |  | search_blocks |
| GLOBlit_8544 |  | search_blocks |
| GLOBlit_8560 |  | search_blocks |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_37 | Critical temperature, K | search_blocks |
| GLOBmeas_43 | Critical pressure, kPa | search_blocks |
| GLOBmeas_137 | Critical density, kg/m3 | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 3 |
| Unique References | 3 |
| Unique Measurements | 3 |
| Unique Phases | 1 |
| Total DOIs | 3 |
| Unique parent blocks | 9 |
| Explicit block/subsystem targets | 9 |
| Subsystem targets | 0 |
| Target-matched data points | 9 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 9  |  **Explicit targets:** 9  |  **Subsystems:** 0  |  **Target-matched datapoints:** 9

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je0201976 | 3 | 3 | unary | search_blocks |
| 10.1021/je0499420 | 3 | 3 | unary | search_blocks |
| 10.1021/je0499723 | 3 | 3 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je0201976 | PROPblock_23 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0201976 | PROPblock_24 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0201976 | PROPblock_25 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499420 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499420 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499420 | PROPblock_9 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499723 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499723 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499723 | PROPblock_9 | declared | 1 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve compound I… | 125 | KEEP ←in 249 | 125 | 7.6 |
| 2 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Resolve property I… | 281 | KEEP ←in 377 | 281 | 6.7 |
| 3 | 3 | `search_blocks` | compound=GLOBcomp_95, limit=50, property=GLOBprop_… | 813 | KEEP ←in 3,005 | 813 | 16.4 |
| 4 | 3 | `search_blocks` | compound=GLOBcomp_95, limit=50, property=GLOBprop_… | 805 | KEEP ←in 2,941 | 805 | 9.9 |
| 5 | 3 | `search_blocks` | compound=GLOBcomp_95, limit=50, property=GLOBprop_… | 836 | KEEP ←in 2,914 | 836 | 10.6 |
| 6 | 1 | `L1_query` | instruction=Search for the compound 1,1,1…, purpos… | 30,538 | — | — | 102.7 |
| | | **TOTAL (6 tools)** | | **33,398** | | **2,860** | **153.9** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 703 | 10,464 | 20,392 | 94.0 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,047 | 22,465 | 1,023 | 5.8 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,510 | 23,928 | 913 | 4.8 |
| 4 | L1-worker | claudeopus46 | 3,767 | 396 | 4,163 | 259 | 3.0 |
| 5 | L1-worker | claudeopus46 | 3,767 | 698 | 4,465 | 294 | 3.6 |
| 6 | L1-worker | claudeopus46 | 3,767 | 576 | 4,343 | 231 | 2.7 |
| 7 | L1-worker | claudeopus46 | 3,767 | 878 | 4,645 | 536 | 3.9 |
| 8 | L1-worker | claudeopus46 | 21,418 | 2,278 | 23,696 | 1,575 | 8.2 |
| 9 | L1-worker | claudeopus46 | 3,767 | 3,375 | 7,142 | 1,110 | 8.5 |
| 10 | L1-worker | claudeopus46 | 3,767 | 3,305 | 7,072 | 1,067 | 9.5 |
| 11 | L1-worker | claudeopus46 | 3,767 | 3,276 | 7,043 | 1,128 | 9.9 |
| 12 | L1-worker | claudeopus46 | 21,418 | 5,611 | 27,029 | 2,769 | 15.1 |
| 13 | L1-worker | claudeopus46 | 627 | 2,397 | 3,024 | 540 | 3.5 |
| 14 | L1-worker | claudeopus46 | 2,320 | 2,517 | 4,837 | 752 | 4.7 |
| 15 | L1-worker | claudeopus46 | 2,543 | 3,685 | 6,228 | 2,878 | 10.8 |
| 16 | L1-worker | claudeopus46 | 787 | 32,646 | 33,433 | 463 | 4.9 |
| 17 | L0-main | claudeopus46 | 9,761 | 19,070 | 28,831 | 3,006 | 19.4 |
| 18 | L0-main | claudeopus46 | 2,543 | 3,466 | 6,009 | 860 | 5.1 |
| 19 | L0-main | claudeopus46 | 2,320 | 2,931 | 5,251 | 1,096 | 5.8 |
| 20 | L0-main | claudeopus46 | 1,156 | 4,797 | 5,953 | 1,457 | 7.5 |
| 21 | L0-main | claudeopus46 | 560 | 5,303 | 5,863 | 2,018 | 13.6 |
| 22 | L0-main | claudeopus46 | 366 | 2,600 | 2,966 | 15 | 1.5 |

