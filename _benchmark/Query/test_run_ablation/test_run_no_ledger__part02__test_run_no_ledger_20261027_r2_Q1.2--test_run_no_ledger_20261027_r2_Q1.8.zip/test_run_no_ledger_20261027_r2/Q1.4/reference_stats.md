# Reference Stats — query-agent

**Run started:** 2026-10-27 03:40:41
**Wall time (at last flush):** 157.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 25,541 | 19,598 | 13,207 | 45,139 | 9,027 | 75.6 | claudeopus46 |
| L1-worker | 14 | 149,853 | 45,776 | 12,833 | 195,629 | 13,973 | 91.1 | claudeopus46 |
| **TOTAL** | **19** | **175,394** | **65,374** | **26,040** | **240,768** | **12,672** | **166.7** | |

**Estimated tokens:** ~60,192 input + ~6,510 output = ~66,702 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 9 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 141 |
| **TOTAL** | **13** | **10** | **1** | **2** | **1** | **1** | **141** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (11 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_107 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_151 |  | resolve_compound_ids |
| GLOBcomp_416 |  | resolve_compound_ids |
| GLOBcomp_476 |  | resolve_compound_ids |
| GLOBcomp_256 |  | resolve_compound_ids |
| GLOBcomp_3148 |  | resolve_compound_ids |
| GLOBcomp_1581 |  | resolve_compound_ids |
| GLOBcomp_58 |  | resolve_compound_ids |
| GLOBcomp_338 |  | resolve_compound_ids |
| GLOBcomp_1104 |  | resolve_compound_ids |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### Properties (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_3 |  | resolve_property_ids |
| GLOBprop_56 |  | resolve_property_ids, search_blocks |
| GLOBprop_73 |  | resolve_property_ids |
| GLOBprop_38 |  | resolve_property_ids |
| GLOBprop_89 |  | resolve_property_ids |
| GLOBprop_94 |  | resolve_property_ids |
| GLOBprop_71 |  | resolve_property_ids |
| GLOBprop_95 |  | resolve_property_ids |
| GLOBprop_33 |  | resolve_property_ids |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_1540 |  | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_185 | Mean ionic activity coefficient | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Solvents (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_4 | Molality, mol/kg | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 11 |
| Unique Properties | 9 |
| Unique References | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Solvents | 1 |
| Unique Variables | 1 |
| Unique Constraints | 2 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 141 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 141

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2014.08.026 | 1 | 141 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2014.08.026 | PROPblock_13 | declared | 141 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve LiCl and w… | 586 | KEEP ←in 935 | 586 | 9.0 |
| 2 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Resolve activity c… | 586 | KEEP ←in 969 | 586 | 5.9 |
| 3 | 4 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve water compo… | 153 | KEEP ←in 216 | 153 | 3.4 |
| 4 | 5 | `search_blocks` | compound=['GLOBcomp_107', 'GLOBcomp_1'], limit=20,… | 1,258 | KEEP ←in 1,949 | 1228 | 13.5 |
| 5 | 1 | `L1_query` | instruction=Search for activity coefficie…, purpos… | 10,361 | — | — | 86.3 |
| | | **TOTAL (5 tools)** | | **12,944** | | **2,553** | **118.1** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 579 | 10,340 | 9,202 | 48.0 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,238 | 22,656 | 982 | 6.3 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,726 | 24,144 | 917 | 4.6 |
| 4 | L1-worker | claudeopus46 | 3,767 | 1,100 | 4,867 | 997 | 8.4 |
| 5 | L1-worker | claudeopus46 | 3,767 | 1,153 | 4,920 | 879 | 5.5 |
| 6 | L1-worker | claudeopus46 | 21,418 | 3,214 | 24,632 | 836 | 5.8 |
| 7 | L1-worker | claudeopus46 | 21,418 | 3,989 | 25,407 | 430 | 3.7 |
| 8 | L1-worker | claudeopus46 | 3,767 | 377 | 4,144 | 285 | 3.3 |
| 9 | L1-worker | claudeopus46 | 21,418 | 4,206 | 25,624 | 1,012 | 6.7 |
| 10 | L1-worker | claudeopus46 | 3,767 | 2,550 | 6,317 | 1,563 | 11.8 |
| 11 | L1-worker | claudeopus46 | 21,418 | 5,984 | 27,402 | 1,821 | 12.4 |
| 12 | L1-worker | claudeopus46 | 2,320 | 1,952 | 4,272 | 723 | 4.8 |
| 13 | L1-worker | claudeopus46 | 2,543 | 3,311 | 5,854 | 889 | 5.0 |
| 14 | L1-worker | claudeopus46 | 627 | 1,832 | 2,459 | 890 | 6.3 |
| 15 | L1-worker | claudeopus46 | 787 | 12,144 | 12,931 | 609 | 6.5 |
| 16 | L0-main | claudeopus46 | 9,761 | 11,779 | 21,540 | 2,003 | 14.0 |
| 17 | L0-main | claudeopus46 | 2,320 | 1,899 | 4,219 | 834 | 4.9 |
| 18 | L0-main | claudeopus46 | 2,543 | 2,310 | 4,853 | 713 | 5.0 |
| 19 | L0-main | claudeopus46 | 1,156 | 3,031 | 4,187 | 455 | 3.7 |

