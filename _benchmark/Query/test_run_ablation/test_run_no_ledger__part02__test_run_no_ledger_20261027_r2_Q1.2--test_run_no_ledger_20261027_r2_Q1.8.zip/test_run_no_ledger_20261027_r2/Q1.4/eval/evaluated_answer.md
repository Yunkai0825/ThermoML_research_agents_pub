# Q1.4 — Result

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

**[run statistics removed]**

---

## Answer

Yes, mean ionic activity coefficients (γ±) have been measured for aqueous lithium chloride (LiCl) at 25 °C (298.15 K). The ThermoML database contains a detailed dataset from the following source:

**Source:** DOI 10.1016/j.fluid.2014.08.026  
**Data block:** PROPblock_13  
**Measurement method:** Calculated from EMF (electromotive force) cell potential  
**Conditions:** T = 298.15 K, P = 101.0 kPa  
**Total data points:** 141  

**Concentration range:** The measurements span molalities from **0.0035 to 1.5095 mol/kg**, covering very dilute to moderately concentrated solutions.

Here are representative values across the concentration range:

| Molality (mol/kg) | γ± (mean ionic) | Expanded uncertainty (k = 95%) |
|---|---|---|
| 0.0035 | 0.9388 | ±0.0201 |
| 0.0313 | 0.8527 | ±0.0211 |
| 0.0847 | 0.8005 | ±0.0217 |
| 0.1658 | 0.7673 | ±0.0221 |
| 0.3285 | 0.7441 | ±0.0223 |
| 0.5696 | 0.7426 | ±0.0224 |
| 0.8769 | 0.7621 | ±0.0221 |
| 1.5095 | 0.8390 | ±0.0212 |

**Chemistry insight:** The data display the classic non-monotonic behavior expected for a strong 1-1 electrolyte. At very low concentrations, γ± is close to unity and decreases as predicted by Debye–Hückel theory (long-range electrostatic screening). A minimum of approximately **γ± ≈ 0.74** is reached around 0.3–0.6 mol/kg. Beyond that, γ± rises again — reaching about 0.84 at 1.5 mol/kg. This upturn is characteristic of LiCl and is driven by the exceptionally strong hydration of the small, highly charge-dense Li⁺ cation: at moderate-to-high concentrations, ion–solvent interactions and the reduction of free water activity increasingly dominate over simple electrostatic screening, pushing the activity coefficient back upward.

### Core claims

- Mean ionic activity coefficients (γ±) for aqueous LiCl at 298.15 K and 101.0 kPa have been measured (calculated from EMF cell potential) across molalities from 0.0035 to 1.5095 mol/kg, comprising 141 data points (DOI 10.1016/j.fluid.2014.08.026, PROPblock_13).
- The data exhibit classic non-monotonic behavior: γ± starts near unity at low concentration, decreases consistent with Debye–Hückel theory, reaches a minimum of approximately γ± ≈ 0.74 around 0.3–0.6 mol/kg, and then rises to about 0.84 at 1.5 mol/kg.
- The upturn in γ± at higher concentrations is attributed to the exceptionally strong hydration of the small, charge-dense Li⁺ cation, where ion–solvent interactions and reduction of free water activity dominate over electrostatic screening.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_1540 | 10.1016/j.fluid.2014.08.026 | PROPblock_13 |  | This block provides 141 data points of mean ionic activity coefficients for aqueous LiCl at 298.15 K and 101.0 kPa over a molality range of 0.0033–1.5555 mol/kg with γ± spanning 0.7406–0.9425, directly backing the answer's reported values, concentration range, and non-monotonic behavior. |

### Suggested follow-ups

- Compare the LiCl activity coefficient data with other alkali metal chlorides (NaCl, KCl) at 25 °C to highlight the effect of cation size on hydration and activity coefficient behavior.
- Search for LiCl activity coefficient measurements at higher molalities (above 1.5 mol/kg) or at different temperatures to map out the full concentration and temperature dependence.
- Look for osmotic coefficient data for aqueous LiCl near 25 °C, which provides complementary thermodynamic information and can be cross-checked via the Gibbs–Duhem relation.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
