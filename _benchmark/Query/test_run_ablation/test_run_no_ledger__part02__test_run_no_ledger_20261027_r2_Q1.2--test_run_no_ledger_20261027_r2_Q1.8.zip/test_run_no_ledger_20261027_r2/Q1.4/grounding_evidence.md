# Data grounding evidence

- generated: 2026-10-27T03:43:10
- grounding profile: current
- gate verdict: 3 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_13 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 298.15 | PROPblock_13 | uninspected_block | — |
| 101.0 | PROPblock_13 | uninspected_block | — |
| 141 | PROPblock_13 | uninspected_block | — |
| 0.0035 | PROPblock_13 | uninspected_block | — |
| 1.5095 | PROPblock_13 | uninspected_block | — |
| 0.0035 | PROPblock_13 | uninspected_block | — |
| 0.9388 | PROPblock_13 | uninspected_block | — |
| 0.0201 | PROPblock_13 | uninspected_block | — |
| 0.0313 | PROPblock_13 | uninspected_block | — |
| 0.8527 | PROPblock_13 | uninspected_block | — |
| 0.0211 | PROPblock_13 | uninspected_block | — |
| 0.0847 | PROPblock_13 | uninspected_block | — |
| 0.8005 | PROPblock_13 | uninspected_block | — |
| 0.0217 | PROPblock_13 | uninspected_block | — |
| 0.1658 | PROPblock_13 | uninspected_block | — |
| 0.7673 | PROPblock_13 | uninspected_block | — |
| 0.0221 | PROPblock_13 | uninspected_block | — |
| 0.3285 | PROPblock_13 | uninspected_block | — |
| 0.7441 | PROPblock_13 | uninspected_block | — |
| 0.0223 | PROPblock_13 | uninspected_block | — |
| 0.5696 | PROPblock_13 | uninspected_block | — |
| 0.7426 | PROPblock_13 | uninspected_block | — |
| 0.0224 | PROPblock_13 | uninspected_block | — |
| 0.8769 | PROPblock_13 | uninspected_block | — |
| 0.7621 | PROPblock_13 | uninspected_block | — |
| 0.0221 | PROPblock_13 | uninspected_block | — |
| 1.5095 | PROPblock_13 | uninspected_block | — |
| 0.8390 | PROPblock_13 | uninspected_block | — |
| 0.0212 | PROPblock_13 | uninspected_block | — |
| 0.74 | PROPblock_13 | uninspected_block | — |
| 0.3 | PROPblock_13 | uninspected_block | — |
| 0.6 | PROPblock_13 | uninspected_block | — |
| 0.84 | PROPblock_13 | uninspected_block | — |
| 1.5 | PROPblock_13 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_13: PROPblock_13 is quoted with data values (298.15, 101.0, 141, 0.0035, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_13: PROPblock_13 is quoted with data values (0.0035, 0.9388, 0.0201, 0.0313, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_13: PROPblock_13 is quoted with data values (0.74, 0.3, 0.6, 0.84, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_