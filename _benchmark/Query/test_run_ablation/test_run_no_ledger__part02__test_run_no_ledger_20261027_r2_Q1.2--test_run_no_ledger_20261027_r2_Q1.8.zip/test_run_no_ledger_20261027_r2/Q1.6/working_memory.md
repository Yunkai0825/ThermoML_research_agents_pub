# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find measured molar isobaric heat capacity (Cp) of pure liquid water at 298.15 K and atmospheric pressure → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

The ThermoML database contains multiple measurements of the molar isobaric heat capacity (Cp) of pure liquid water (H₂O, GLOBcomp_1) at 298.15 K and atmospheric pressure (GLOBprop_9). The most precise single-point measurement at exactly 298.15 K and 101.325 kPa gives Cp = 75.1147 J/(K·mol) (DOI 10.1016/j.jct.2016.09.031, GLOBlit_4832, PROPblock_1). Additional measurements at 298.15 K include ~75.317 J/(K·mol) (DOI 10.1016/j.fluid.2013.08.005, GLOBlit_1310, PROPblock_1), ~75.268 J/(K·mol) (DOI 10.1016/j.jct.2009.01.011, GLOBlit_3054, PROPblock_8), and ~75.448 J/(K·mol) (DOI 10.1021/acs.jced.7b00483, GLOBlit_7221, PROPblock_1). All measurements are for unary pure water in the liquid phase, with values clustering around 75.1–75.5 J/(K·mol) and a spread of ~0.4 J/(K·mol) reflecting typical experimental uncertainties.

**Answer:**

The ThermoML database contains multiple measurements of the molar isobaric heat capacity (Cp) of pure liquid water at 298.15 K and atmospheric pressure. Here are the key findings:

**Most precise single-point measurement at exactly 298.15 K and 101.325 kPa:**
- **Cp = 75.1147 J/(K·mol)**
- DOI: 10.1016/j.jct.2016.09.031 (GLOBlit_4832), PROPblock_1
- Single data point at the exact requested conditions

**Additional measurements with data at 298.15 K:**

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *DOI* | *GLOBlit* | *Block* | *Cp at 298.15 K (J/K/mol)* | *Notes* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「10.1016/j.fluid.2013.08.005」 | 「GLOBlit_1310」 | 「PROPblock_1」 | 「~75.317」 | 「8-point series starting at 298.15 K」 |
| WM_L1_Q1_Table#1_Row#2 | 「10.1016/j.jct.2009.01.011」 | 「GLOBlit_3054」 | 「PROPblock_8」 | 「~75.268」 | 「16-point series starting at 298.15 K」 |
| WM_L1_Q1_Table#1_Row#3 | 「10.1021/acs.jced.7b00483」 | 「GLOBlit_7221」 | 「PROPblock_1」 | 「~75.448」 | 「14-point series starting at 298.15 K」 |

All measurements are for unary (pure) water systems in the liquid phase. The measured values cluster around **75.1–75.5 J/(K·mol)**, which is consistent with the well-known heat capacity of liquid water at standard conditions. The small spread across studies (~0.4 J/(K·mol)) reflects typical experimental uncertainties in calorimetric measurements of this quantity.

**Compound:** water (H₂O), GLOBcomp_1  
**Property:** Molar heat capacity at constant pressure, GLOBprop_9, in J/(K·mol)  
**Conditions:** T = 298.15 K, P ≈ 101.325 kPa, liquid phase

**Core claims:**
- The ThermoML database contains multiple measurements of the molar isobaric heat capacity (Cp) of pure liquid water at 298.15 K and atmospheric pressure, with values clustering around 75.1–75.5 J/(K·mol).
- The most precise single-point measurement at exactly 298.15 K and 101.325 kPa reports Cp = 75.1147 J/(K·mol) (DOI: 10.1016/j.jct.2016.09.031).
- Additional measurements at 298.15 K from three other studies report approximate values of ~75.317, ~75.268, and ~75.448 J/(K·mol), with the spread of ~0.4 J/(K·mol) across studies attributed to typical experimental uncertainties in calorimetric measurements.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#2 | 「GLOBlit_4832」 | 「PROPblock_1」 | 「GLOBcomp_1」 | 「GLOBprop_9」 | 「Most precise single-point molar Cp measurement of pure liquid water at exactly 298.15 K and 101.325 kPa, reporting 75.1147 J/(K·mol).」 |
| WM_L1_Q1_Table#3 | 「GLOBlit_1310」 | 「PROPblock_1」 | 「GLOBcomp_1」 | 「GLOBprop_9」 | 「Molar Cp measurement series for pure liquid water starting at 298.15 K, reporting approximately 75.317 J/(K·mol) at that temperature.」 |
| WM_L1_Q1_Table#4 | 「GLOBlit_3054」 | 「PROPblock_8」 | 「GLOBcomp_1」 | 「GLOBprop_9」 | 「Molar Cp measurement series for pure liquid water starting at 298.15 K, reporting approximately 75.268 J/(K·mol) at that temperature.」 |
| WM_L1_Q1_Table#5 | 「GLOBlit_7221」 | 「PROPblock_1」 | 「GLOBcomp_1」 | 「GLOBprop_9」 | 「Molar Cp measurement series for pure liquid water starting at 298.15 K, reporting approximately 75.448 J/(K·mol) at that temperature.」 |

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


