# Data grounding evidence

- generated: 2026-10-27T03:45:21
- grounding profile: current
- gate verdict: 3 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 298.15 | PROPblock_1 | uninspected_block | — |
| 298.15 | PROPblock_1 | uninspected_block | — |
| 75.317 | PROPblock_1 | uninspected_block | — |
| 101.0 | PROPblock_1 | uninspected_block | — |
| 298 | PROPblock_1 | uninspected_block | — |
| 313 | PROPblock_1 | uninspected_block | — |
| 75.268 | PROPblock_1 | uninspected_block | — |
| 101.325 | PROPblock_1 | uninspected_block | — |
| 16 | PROPblock_1 | uninspected_block | — |
| 298 | PROPblock_1 | uninspected_block | — |
| 373 | PROPblock_1 | uninspected_block | — |
| 75.448 | PROPblock_1 | uninspected_block | — |
| 100.0 | PROPblock_1 | uninspected_block | — |
| 14 | PROPblock_1 | uninspected_block | — |
| 298 | PROPblock_1 | uninspected_block | — |
| 363 | PROPblock_1 | uninspected_block | — |
| 75.1 | PROPblock_1 | uninspected_block | — |
| 75.5 | PROPblock_1 | uninspected_block | — |
| 0.4 | PROPblock_1 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_1: PROPblock_1 is quoted with data values (298.15, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_1: PROPblock_1 is quoted with data values (298.15, 75.317, 101.0, 298, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_1: PROPblock_1 is quoted with data values (75.1, 75.5, 0.4, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_