# Q1.6 — Result

**Prompt:** What is the measured isobaric heat capacity of pure liquid water at 25 °C and atmospheric pressure?

**[run statistics removed]**

---

## Answer

The ThermoML database contains multiple experimental measurements of the molar isobaric heat capacity (Cp) of pure liquid water at 25 °C (298.15 K) and atmospheric pressure. Here are the results:

## Most Precise Single-Point Measurement

- **Cp = 75.1147 J/(K·mol)**
- Conditions: exactly 298.15 K and 101.325 kPa, liquid phase
- Method: Flow calorimetry
- Source: DOI 10.1016/j.jct.2016.09.031 (Gao & Li, 2017), PROPblock_1

## Additional Measurements at 298.15 K

| Source (DOI) | Cp at 298.15 K (J/(K·mol)) | Pressure (kPa) | Method | Notes |
|---|---|---|---|---|
| 10.1016/j.fluid.2013.08.005 | ~75.317 | 101.0 | Large-sample DSC | 8-point series, 298–313 K |
| 10.1016/j.jct.2009.01.011 | ~75.268 | 101.325 | Small-sample DSC | 16-point series, 298–373 K |
| 10.1021/acs.jced.7b00483 | ~75.448 | 100.0 | Flow calorimetry | 14-point series, 298–363 K |

## Summary

All four independent studies report values clustering in the range **75.1–75.5 J/(K·mol)**, which is fully consistent with the well-known heat capacity of liquid water near standard conditions. The spread of ~0.4 J/(K·mol) across studies reflects typical experimental uncertainties inherent in calorimetric measurements. Water's relatively high molar heat capacity — compared with most organic liquids of similar molar mass — arises from its extensive three-dimensional hydrogen-bonding network, which provides additional modes for energy storage beyond simple molecular translations and rotations.

### Core claims

- Multiple independent ThermoML studies report the molar isobaric heat capacity (Cp) of pure liquid water at 298.15 K and atmospheric pressure in the range 75.1–75.5 J/(K·mol), consistent with the well-known value.
- The most precise single-point measurement is Cp = 75.1147 J/(K·mol) at exactly 298.15 K and 101.325 kPa, obtained by flow calorimetry (DOI 10.1016/j.jct.2016.09.031).
- The spread of ~0.4 J/(K·mol) across four independent studies reflects typical experimental uncertainties in calorimetric measurements.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_4832 | 10.1016/j.jct.2016.09.031 | PROPblock_1 |  | Provides the most precise single-point measurement of Cp for pure liquid water at 298.15 K and 101.325 kPa: 75.11471 J/(K·mol) by flow calorimetry, which is the headline value in the answer. |
| GLOBlit_1310 | 10.1016/j.fluid.2013.08.005 | PROPblock_1 |  | Provides an 8-point series of Cp for pure water starting at 298.15 K (min 75.316 J/(K·mol)) at 101.0 kPa by large-sample DSC, supporting the answer's ~75.317 value and cross-study comparison. |
| GLOBlit_7221 | 10.1021/acs.jced.7b00483 | PROPblock_1 |  | Provides a 14-point Cp series for pure water starting at 298.15 K (min 75.448 J/(K·mol)) at 100.0 kPa by flow calorimetry, contributing the ~75.448 value cited in the answer's comparison table. |

### Suggested follow-ups

- Compare the ThermoML experimental values with the IAPWS-95 recommended value for the isobaric heat capacity of water at 298.15 K and 101.325 kPa.
- Investigate how the isobaric heat capacity of water varies with temperature across the liquid range (273–373 K) using the available multi-point datasets.
- Examine the pressure dependence of water's heat capacity by searching for measurements at elevated pressures in ThermoML.
<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
