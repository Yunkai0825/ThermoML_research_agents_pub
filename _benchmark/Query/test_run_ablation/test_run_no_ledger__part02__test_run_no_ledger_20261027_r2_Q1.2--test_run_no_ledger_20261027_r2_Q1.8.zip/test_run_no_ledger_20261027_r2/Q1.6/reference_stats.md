# Reference Stats — query-agent

**Run started:** 2026-10-27 03:43:52
**Wall time (at last flush):** 107.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 26,101 | 24,698 | 6,097 | 50,799 | 8,466 | 40.9 | claudeopus46 |
| L1-worker | 11 | 120,901 | 47,097 | 10,493 | 167,998 | 15,272 | 72.5 | claudeopus46 |
| **TOTAL** | **17** | **147,002** | **71,795** | **16,590** | **218,797** | **12,870** | **113.4** | |

**Estimated tokens:** ~54,699 input + ~4,147 output = ~58,846 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 10 | 10 | 110 |
| **TOTAL** | **2** | **1** | **2** | **1** | **10** | **10** | **110** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### References (10 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_1310 |  | search_blocks |
| GLOBlit_1445 |  | search_blocks |
| GLOBlit_1986 |  | search_blocks |
| GLOBlit_2622 |  | search_blocks |
| GLOBlit_3019 |  | search_blocks |
| GLOBlit_3054 |  | search_blocks |
| GLOBlit_4832 |  | search_blocks |
| GLOBlit_7221 |  | search_blocks |
| GLOBlit_7754 |  | search_blocks |
| GLOBlit_11179 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |

#### Measurements (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_31 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_12 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_132 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique References | 10 |
| Unique Properties | 1 |
| Unique Measurements | 4 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Total DOIs | 10 |
| Unique parent blocks | 10 |
| Explicit block/subsystem targets | 10 |
| Subsystem targets | 0 |
| Target-matched data points | 110 |

---

## 3. DOI & Block References

**Unique DOIs:** 10  |  **Parent blocks:** 10  |  **Explicit targets:** 10  |  **Subsystems:** 0  |  **Target-matched datapoints:** 110

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2013.08.005 | 1 | 8 | unary | search_blocks |
| 10.1016/j.fluid.2014.03.017 | 1 | 28 | unary | search_blocks |
| 10.1016/j.fluid.2016.10.005 | 1 | 9 | unary | search_blocks |
| 10.1016/j.jct.2005.10.010 | 1 | 15 | unary | search_blocks |
| 10.1016/j.jct.2008.10.002 | 1 | 6 | unary | search_blocks |
| 10.1016/j.jct.2009.01.011 | 1 | 16 | unary | search_blocks |
| 10.1016/j.jct.2016.09.031 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.7b00483 | 1 | 14 | unary | search_blocks |
| 10.1021/acs.jced.8b01174 | 1 | 6 | unary | search_blocks |
| 10.1021/je800248w | 1 | 7 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2013.08.005 | PROPblock_1 | declared | 8 | unary | — | search_blocks |
| 10.1016/j.fluid.2014.03.017 | PROPblock_3 | declared | 28 | unary | — | search_blocks |
| 10.1016/j.fluid.2016.10.005 | PROPblock_2 | declared | 9 | unary | — | search_blocks |
| 10.1016/j.jct.2005.10.010 | PROPblock_1 | declared | 15 | unary | — | search_blocks |
| 10.1016/j.jct.2008.10.002 | PROPblock_1 | declared | 6 | unary | — | search_blocks |
| 10.1016/j.jct.2009.01.011 | PROPblock_8 | declared | 16 | unary | — | search_blocks |
| 10.1016/j.jct.2016.09.031 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00483 | PROPblock_1 | declared | 14 | unary | — | search_blocks |
| 10.1021/acs.jced.8b01174 | PROPblock_5 | declared | 6 | unary | — | search_blocks |
| 10.1021/je800248w | PROPblock_1 | declared | 7 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Find water compound… | 194 | KEEP ←in 216 | 194 | 4.2 |
| 2 | 4 | `search_blocks` | compound=GLOBcomp_1, limit=20, property=GLOBprop_9… | 1,136 | KEEP ←in 5,937 | 1106 | 14.5 |
| 3 | 1 | `L1_query` | context=User wants the isobaric heat …, id_catalog… | 21,169 | — | — | 68.2 |
| | | **TOTAL (3 tools)** | | **22,499** | | **1,300** | **86.9** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 562 | 10,323 | 1,181 | 7.9 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,128 | 22,546 | 649 | 5.7 |
| 3 | L1-worker | claudeopus46 | 21,418 | 1,802 | 23,220 | 502 | 4.2 |
| 4 | L1-worker | claudeopus46 | 3,767 | 360 | 4,127 | 334 | 3.4 |
| 5 | L1-worker | claudeopus46 | 21,418 | 2,065 | 23,483 | 1,125 | 8.1 |
| 6 | L1-worker | claudeopus46 | 21,418 | 2,775 | 24,193 | 661 | 5.0 |
| 7 | L1-worker | claudeopus46 | 3,767 | 6,372 | 10,139 | 1,620 | 12.6 |
| 8 | L1-worker | claudeopus46 | 21,418 | 4,050 | 25,468 | 1,961 | 12.1 |
| 9 | L1-worker | claudeopus46 | 2,320 | 1,604 | 3,924 | 664 | 4.0 |
| 10 | L1-worker | claudeopus46 | 627 | 1,484 | 2,111 | 851 | 5.0 |
| 11 | L1-worker | claudeopus46 | 2,543 | 2,853 | 5,396 | 1,615 | 6.6 |
| 12 | L1-worker | claudeopus46 | 787 | 22,604 | 23,391 | 511 | 5.8 |
| 13 | L0-main | claudeopus46 | 9,761 | 12,957 | 22,718 | 1,756 | 12.4 |
| 14 | L0-main | claudeopus46 | 2,320 | 1,659 | 3,979 | 597 | 3.8 |
| 15 | L0-main | claudeopus46 | 2,543 | 2,053 | 4,596 | 756 | 5.1 |
| 16 | L0-main | claudeopus46 | 560 | 2,266 | 2,826 | 262 | 2.3 |
| 17 | L0-main | claudeopus46 | 1,156 | 5,201 | 6,357 | 1,545 | 9.4 |

