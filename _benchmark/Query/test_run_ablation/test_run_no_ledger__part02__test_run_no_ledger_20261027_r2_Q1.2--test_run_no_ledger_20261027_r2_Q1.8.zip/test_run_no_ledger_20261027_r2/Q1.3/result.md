# Q1.3 — Result

**Prompt:** What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

**Tool calls:** 2  |  **Time:** 505.3s  |  **Iterations:** 3  |  **Timed out:** False

---

## Answer

The ThermoML database records a measured liquid density of **838.8 ± 0.4 kg/m³** for a nearly equimolar propan-2-ol (isopropanol) + water binary mixture under the following conditions:

| Parameter | Value |
|-----------|-------|
| **Density** | 838.8 kg/m³ |
| **Mole fraction of propan-2-ol** | 0.4981 (essentially equimolar) |
| **Temperature** | 298.15 K (25.00 °C) |
| **Pressure** | 101.0 kPa (~1 atm) |
| **Phase** | Liquid |
| **Source** | DOI 10.1021/je700700f (GLOBlit_11042, PROPblock_17) |
| **Measurement method** | Vibrating-tube densimetry |

**Chemical context:** Pure water at 25 °C has a density of ~997 kg/m³ and pure propan-2-ol ~786 kg/m³. A simple mole-fraction-weighted (ideal) estimate would give roughly 892 kg/m³ for the equimolar mixture. The measured value of 838.8 kg/m³ is notably lower, reflecting the well-known **negative excess volume** (volume contraction) characteristic of short-chain alcohol + water systems. This contraction arises from hydrogen-bonding reorganization: when propan-2-ol and water mix, the restructuring of the hydrogen-bond network allows molecules to pack more efficiently than in the pure liquids, producing a mixture that is denser than ideal mixing would predict.

**Corroborating data:** A second ThermoML dataset (DOI 10.1021/je800158z, GLOBlit_11142, PROPblock_4) reports ρ = 839.36 kg/m³ at x(propan-2-ol) = 0.5204 and 293.15 K (P = 81.5 kPa). This value is consistent with the primary measurement when accounting for the slightly different temperature and composition.

### Core claims

- The ThermoML database records a measured liquid density of 838.8 ± 0.4 kg/m³ for a propan-2-ol + water binary mixture at a propan-2-ol mole fraction of 0.4981, temperature of 298.15 K, and pressure of 101.0 kPa, sourced from DOI 10.1021/je700700f.
- The measured equimolar mixture density of 838.8 kg/m³ is lower than a simple mole-fraction-weighted ideal estimate, reflecting negative excess volume (volume contraction) characteristic of short-chain alcohol + water systems due to hydrogen-bonding reorganization.
- A corroborating ThermoML dataset (DOI 10.1021/je800158z) reports a density of 839.36 kg/m³ at x(propan-2-ol) = 0.5204 and 293.15 K (P = 81.5 kPa), consistent with the primary measurement when accounting for slightly different temperature and composition.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11042 | 10.1021/je700700f | PROPblock_17 |  | This block provides the primary density measurement for the propan-2-ol + water binary system at 298.15 K and 101.0 kPa across the full mole-fraction range (0–1), with density spanning 780.7–997.2 kg/m³ via vibrating-tube densimetry. The answer's reported value of 838.8 kg/m³ at x = 0.4981 falls within these ranges and conditions. |
| GLOBlit_11142 | 10.1021/je800158z | PROPblock_4 |  | This block serves as corroborating data for the same binary system (propan-2-ol + water), covering densities from 758.68–998.2 kg/m³ over temperatures 293.15–323.15 K and the full composition range. The answer cites ρ = 839.36 kg/m³ at x = 0.5204 and 293.15 K from this source as a consistency check. |

### Suggested follow-ups

- Investigate how the density of the propan-2-ol + water equimolar mixture varies with temperature (e.g., 15–45 °C) using available ThermoML data.
- Compare excess molar volumes for propan-2-ol + water with those of other short-chain alcohol + water systems (methanol, ethanol, propan-1-ol) at 25 °C.
- Check whether ThermoML contains viscosity or speed-of-sound data for the same equimolar propan-2-ol + water mixture at 25 °C to complement the density measurement.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_6",
    "registry_id": "propan-2-ol",
    "name": "propan-2-ol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  }
]
```
