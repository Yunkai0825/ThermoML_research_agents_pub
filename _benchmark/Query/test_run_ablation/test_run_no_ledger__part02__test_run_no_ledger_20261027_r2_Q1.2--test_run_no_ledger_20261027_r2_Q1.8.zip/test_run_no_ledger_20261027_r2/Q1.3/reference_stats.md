# Reference Stats — query-agent

**Run started:** 2026-10-27 03:40:35
**Wall time (at last flush):** 448.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 35,302 | 40,046 | 7,513 | 75,348 | 12,558 | 51.9 | claudeopus46 |
| L1-worker | 45 | 557,873 | 250,994 | 53,491 | 808,867 | 17,974 | 390.9 | claudeopus46 |
| **TOTAL** | **51** | **593,175** | **291,040** | **61,004** | **884,215** | **17,337** | **442.8** | |

**Estimated tokens:** ~221,053 input + ~15,251 output = ~236,304 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 0 | 3 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 5 | 2 | 10 | 10 | 898 |
| `search_blocks` | 2 | 1 | 3 | 0 | 1 | 1 | 529 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 0 | 2 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 5 | 2 | 10 | 10 | 898 |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 13 |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 56 |
| **TOTAL** | **12** | **6** | **20** | **12** | **23** | **23** | **2,394** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_6 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 |  | resolve_property_ids, search_blocks |

#### Variables (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids, search_blocks |
| GLOBvar_3 |  | resolve_ids, search_blocks |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### Constraints (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 |  | resolve_ids, search_blocks |
| GLOBconstr_1 |  | resolve_ids, search_blocks |
| GLOBconstr_3 |  | resolve_ids |

#### References (10 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2432 |  | search_blocks |
| GLOBlit_5585 |  | search_blocks |
| GLOBlit_6822 |  | search_blocks |
| GLOBlit_7474 |  | search_blocks |
| GLOBlit_8447 |  | search_blocks |
| GLOBlit_9722 |  | search_blocks |
| GLOBlit_11042 |  | search_blocks |
| GLOBlit_11130 |  | search_blocks |
| GLOBlit_11142 |  | search_blocks |
| GLOBlit_11872 |  | search_blocks |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Solvents (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique Variables | 5 |
| Unique Constraints | 3 |
| Unique References | 10 |
| Unique Measurements | 2 |
| Unique Phases | 1 |
| Unique Solvents | 1 |
| Total DOIs | 10 |
| Unique parent blocks | 10 |
| Explicit block/subsystem targets | 10 |
| Subsystem targets | 0 |
| Target-matched data points | 2,394 |

---

## 3. DOI & Block References

**Unique DOIs:** 10  |  **Parent blocks:** 10  |  **Explicit targets:** 10  |  **Subsystems:** 0  |  **Target-matched datapoints:** 898

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2004.07.019 | 1 | 529 | binary | search_blocks |
| 10.1016/j.jct.2019.105880 | 1 | 12 | binary | search_blocks |
| 10.1021/acs.jced.6b00019 | 1 | 6 | binary | search_blocks |
| 10.1021/acs.jced.8b00160 | 1 | 18 | binary | search_blocks |
| 10.1021/je049738c | 1 | 8 | binary | search_blocks |
| 10.1021/je201010s | 1 | 17 | binary | search_blocks |
| 10.1021/je700700f | 1 | 13 | binary | search_blocks |
| 10.1021/je8001305 | 1 | 209 | binary | search_blocks |
| 10.1021/je800158z | 1 | 56 | binary | search_blocks |
| 10.1021/je900966r | 1 | 30 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2004.07.019 | PROPblock_4 | declared | 529 | binary | — | search_blocks |
| 10.1016/j.jct.2019.105880 | PROPblock_10 | declared | 12 | binary | — | search_blocks |
| 10.1021/acs.jced.6b00019 | PROPblock_13 | declared | 6 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00160 | PROPblock_15 | declared | 18 | binary | — | search_blocks |
| 10.1021/je049738c | PROPblock_28 | declared | 8 | binary | — | search_blocks |
| 10.1021/je201010s | PROPblock_8 | declared | 17 | binary | — | search_blocks |
| 10.1021/je700700f | PROPblock_17 | declared | 13 | binary | — | search_blocks |
| 10.1021/je8001305 | PROPblock_1 | declared | 209 | binary | — | search_blocks |
| 10.1021/je800158z | PROPblock_4 | declared | 56 | binary | — | search_blocks |
| 10.1021/je900966r | PROPblock_6 | declared | 30 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 183 | KEEP ←in 285 | 183 | 3.9 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=70, purpose=Confirm property ID… | 289 | KEEP ←in 218 | 289 | 7.7 |
| 3 | 4 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 280 | KEEP ←in 395 | 280 | 4.1 |
| 4 | 4 | `resolve_ids` | entity_type=constraint, limit=5, min_score=70, pur… | 298 | KEEP ←in 421 | 298 | 4.0 |
| 5 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_6… | 977 | DISCARD ←in 1,000 | 916 | 17.9 |
| 6 | 9 | `search_blocks` | compound=['GLOBcomp_6', 'GLOBcomp_1'], limit=10, p… | 603 | KEEP ←in 6,532 | 603 | 15.4 |
| 7 | 11 | `search_blocks` | block_number=GLOBlit_2432::PROPblock_4, purpose=Re… | 744 | KEEP ←in 2,444 | 729 | 17.0 |
| 8 | 1 | `L1_query` | context=User wants density of equimol…, id_catalog… | 10,066 | — | — | 216.9 |
| 9 | 3 | `resolve_ids` | entity_type=variable, limit=10, min_score=50, purp… | 298 | KEEP ←in 241 | 298 | 4.7 |
| 10 | 3 | `resolve_ids` | entity_type=constraint, limit=10, min_score=50, pu… | 231 | KEEP ←in 328 | 231 | 4.3 |
| 11 | 8 | `search_blocks` | compound=['GLOBcomp_6', 'GLOBcomp_1'], limit=15, p… | 1,888 | KEEP ←in 6,532 | 1888 | 37.6 |
| 12 | 9 | `search_blocks` | block_number=GLOBlit_11042::PROPblock_17, purpose=… | 640 | KEEP ←in 1,906 | 608 | 7.5 |
| 13 | 9 | `search_blocks` | block_number=GLOBlit_11142::PROPblock_4, purpose=I… | 1,012 | KEEP ←in 2,627 | 996 | 14.1 |
| 14 | 2 | `L1_query` | context=Previous search found 10 bloc…, id_catalog… | 14,596 | — | — | 182.7 |
| | | **TOTAL (14 tools)** | | **32,105** | | **7,319** | **537.8** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 580 | 10,341 | 1,378 | 9.7 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,255 | 22,673 | 891 | 6.3 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,612 | 24,030 | 775 | 4.6 |
| 4 | L1-worker | claudeopus46 | 3,767 | 446 | 4,213 | 363 | 3.8 |
| 5 | L1-worker | claudeopus46 | 3,767 | 362 | 4,129 | 239 | 3.2 |
| 6 | L1-worker | claudeopus46 | 3,767 | 664 | 4,431 | 437 | 4.1 |
| 7 | L1-worker | claudeopus46 | 21,418 | 2,516 | 23,934 | 1,776 | 10.1 |
| 8 | L1-worker | claudeopus46 | 21,418 | 3,744 | 25,162 | 1,022 | 5.0 |
| 9 | L1-worker | claudeopus46 | 3,767 | 611 | 4,378 | 411 | 4.0 |
| 10 | L1-worker | claudeopus46 | 3,767 | 642 | 4,409 | 456 | 3.8 |
| 11 | L1-worker | claudeopus46 | 21,418 | 4,249 | 25,667 | 1,973 | 14.2 |
| 12 | L1-worker | claudeopus46 | 21,418 | 5,143 | 26,561 | 1,511 | 12.3 |
| 13 | L1-worker | claudeopus46 | 21,418 | 5,983 | 27,401 | 1,735 | 12.2 |
| 14 | L1-worker | claudeopus46 | 3,767 | 1,267 | 5,034 | 1,533 | 9.4 |
| 15 | L1-worker | claudeopus46 | 21,418 | 6,509 | 27,927 | 1,177 | 8.5 |
| 16 | L1-worker | claudeopus46 | 21,418 | 7,280 | 28,698 | 693 | 5.0 |
| 17 | L1-worker | claudeopus46 | 3,767 | 7,091 | 10,858 | 1,654 | 14.2 |
| 18 | L1-worker | claudeopus46 | 21,418 | 8,000 | 29,418 | 2,159 | 16.0 |
| 19 | L1-worker | claudeopus46 | 21,418 | 8,911 | 30,329 | 1,310 | 9.2 |
| 20 | L1-worker | claudeopus46 | 3,767 | 2,859 | 6,626 | 2,119 | 16.4 |
| 21 | L1-worker | claudeopus46 | 21,418 | 9,699 | 31,117 | 1,904 | 13.7 |
| 22 | L1-worker | claudeopus46 | 21,385 | 10,310 | 31,695 | 2,107 | 15.1 |
| 23 | L1-worker | claudeopus46 | 2,320 | 2,238 | 4,558 | 734 | 3.9 |
| 24 | L1-worker | claudeopus46 | 2,543 | 3,614 | 6,157 | 650 | 4.0 |
| 25 | L1-worker | claudeopus46 | 627 | 2,118 | 2,745 | 607 | 4.1 |
| 26 | L1-worker | claudeopus46 | 787 | 12,135 | 12,922 | 661 | 6.4 |
| 27 | L0-main | claudeopus46 | 9,761 | 10,841 | 20,602 | 1,912 | 14.5 |
| 28 | L1-worker | claudeopus46 | 21,418 | 6,123 | 27,541 | 1,475 | 10.3 |
| 29 | L1-worker | claudeopus46 | 21,418 | 7,556 | 28,974 | 888 | 5.0 |
| 30 | L1-worker | claudeopus46 | 21,418 | 8,639 | 30,057 | 837 | 4.6 |
| 31 | L1-worker | claudeopus46 | 3,767 | 370 | 4,137 | 418 | 3.8 |
| 32 | L1-worker | claudeopus46 | 3,767 | 486 | 4,253 | 386 | 3.7 |
| 33 | L1-worker | claudeopus46 | 21,418 | 7,980 | 29,398 | 1,879 | 12.7 |
| 34 | L1-worker | claudeopus46 | 21,418 | 8,954 | 30,372 | 1,965 | 13.3 |
| 35 | L1-worker | claudeopus46 | 21,418 | 9,788 | 31,206 | 2,087 | 12.8 |
| 36 | L1-worker | claudeopus46 | 21,418 | 10,614 | 32,032 | 1,122 | 9.1 |
| 37 | L1-worker | claudeopus46 | 21,418 | 11,378 | 32,796 | 640 | 5.2 |
| 38 | L1-worker | claudeopus46 | 3,767 | 6,997 | 10,764 | 1,617 | 15.7 |
| 39 | L1-worker | claudeopus46 | 3,767 | 7,299 | 11,066 | 2,385 | 19.0 |
| 40 | L1-worker | claudeopus46 | 21,418 | 12,023 | 33,441 | 1,351 | 10.0 |
| 41 | L1-worker | claudeopus46 | 3,767 | 2,272 | 6,039 | 777 | 7.0 |
| 42 | L1-worker | claudeopus46 | 3,767 | 2,992 | 6,759 | 1,692 | 13.7 |
| 43 | L1-worker | claudeopus46 | 21,418 | 14,380 | 35,798 | 2,187 | 16.5 |
| 44 | L1-worker | claudeopus46 | 2,320 | 1,717 | 4,037 | 736 | 4.0 |
| 45 | L1-worker | claudeopus46 | 627 | 1,597 | 2,224 | 755 | 4.5 |
| 46 | L1-worker | claudeopus46 | 2,543 | 3,427 | 5,970 | 939 | 5.5 |
| 47 | L1-worker | claudeopus46 | 787 | 16,144 | 16,931 | 458 | 5.0 |
| 48 | L0-main | claudeopus46 | 9,761 | 21,138 | 30,899 | 1,552 | 11.5 |
| 49 | L0-main | claudeopus46 | 2,320 | 1,722 | 4,042 | 850 | 4.4 |
| 50 | L0-main | claudeopus46 | 2,543 | 2,134 | 4,677 | 775 | 5.3 |
| 51 | L0-main | claudeopus46 | 1,156 | 3,631 | 4,787 | 1,046 | 6.5 |

