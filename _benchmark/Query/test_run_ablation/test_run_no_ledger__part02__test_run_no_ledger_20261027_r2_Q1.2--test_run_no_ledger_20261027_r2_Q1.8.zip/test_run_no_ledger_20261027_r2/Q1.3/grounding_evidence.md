# Data grounding evidence

- generated: 2026-10-27T03:47:51
- grounding profile: current
- gate verdict: 3 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_17 | — | NO | — | — |
| PROPblock_4 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 838.8 | PROPblock_17 | uninspected_block | — |
| 0.4981 | PROPblock_17 | uninspected_block | — |
| 298.15 | PROPblock_17 | uninspected_block | — |
| 25.00 | PROPblock_17 | uninspected_block | — |
| 101.0 | PROPblock_17 | uninspected_block | — |
| 25 | PROPblock_17 | uninspected_block | — |
| 997 | PROPblock_17 | uninspected_block | — |
| 786 | PROPblock_17 | uninspected_block | — |
| 892 | PROPblock_17 | uninspected_block | — |
| 838.8 | PROPblock_17 | uninspected_block | — |
| 839.36 | PROPblock_4 | uninspected_block | — |
| 0.5204 | PROPblock_4 | uninspected_block | — |
| 293.15 | PROPblock_4 | uninspected_block | — |
| 81.5 | PROPblock_4 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_17: PROPblock_17 is quoted with data values (838.8, 0.4981, 298.15, 25.00, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_17: PROPblock_17 is quoted with data values (25, 997, 786, 892, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_4: PROPblock_4 is quoted with data values (839.36, 0.5204, 293.15, 81.5, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_