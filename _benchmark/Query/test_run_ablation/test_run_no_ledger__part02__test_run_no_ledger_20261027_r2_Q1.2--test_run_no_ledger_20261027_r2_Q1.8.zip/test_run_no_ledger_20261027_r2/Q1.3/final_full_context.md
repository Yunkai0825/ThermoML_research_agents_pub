## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |
| GLOBprop_42 | Relative permittivity (various frequencies) | — |
| GLOBprop_44 | Relative permittivity (zero frequency / static dielectric constant) | — |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_6 | propan-2-ol | propan-2-ol |
| comp | GLOBcomp_1 | water | water |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find measured density of equimolar propan-2-ol + water mixture at 25 °C and atmospheric pressure → stored as L1_query_1 · validation: PASS
- [L1] Extract the actual measured density value for equimolar propan-2-ol + water at 298.15 K from ThermoML blocks NOT yet ins → stored as L1_query_2 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: partial · validation: PASS

**Summary:**

The search identified 10 binary mass density data blocks for propan-2-ol (CAS 67-63-0) + water (CAS 7732-18-5) in ThermoML near 298.15 K. One block inspected in detail (GLOBlit_2432, PROPblock_4, DOI 10.1016/j.jct.2004.07.019) reported density differences at very dilute molalities (x ≈ 0.002–0.014) and was not suitable for equimolar composition. The remaining blocks are expected to cover the full mole-fraction range including x ≈ 0.5 but their exact numerical values could not be extracted in this session. No precise ThermoML-recorded density value at equimolar composition was confirmed.

**Answer:**

Based on my search of the ThermoML database, I found 10 binary mass density (GLOBprop_1) data blocks for the propan-2-ol (GLOBcomp_6) + water (GLOBcomp_1) system near 298.15 K. However, I was unable to drill down to extract the exact numerical density value at the equimolar (x ≈ 0.5) composition due to tool-call limitations encountered during this session.

Here is what was established:

- **System:** Binary mixture of propan-2-ol (isopropanol, CAS 67-63-0) and water (CAS 7732-18-5)
- **Property:** Mass density (GLOBprop_1, kg/m³)
- **Conditions sought:** T ≈ 298.15 K, P ≈ 101.325 kPa, x(propan-2-ol) ≈ 0.5

**Available data blocks identified (all binary, T range includes ~298 K):**

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *DOI* | *GLOBlit* | *Block* | *Notes* |
|---|---|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「10.1016/j.jct.2004.07.019」 | 「GLOBlit_2432」 | 「PROPblock_4」 | 「Density differences (Δρ) at dilute molalities — not suitable for equimolar data」 |
| WM_L1_Q1_Table#1_Row#2 | 「(9 additional blocks found)」 | 「Various GLOBlit IDs」 | 「Various PROPblock IDs」 | 「Several span the full mole/mass fraction range and likely contain data near x = 0.5」 |

The search confirmed that multiple ThermoML literature sources report density data for propan-2-ol + water binaries at 298.15 K across broad composition ranges. The one block inspected in detail (GLOBlit_2432, PROPblock_4) turned out to report density differences at very dilute concentrations (molality-based, x ≈ 0.002–0.014), so it was not suitable for the equimolar query.

The remaining blocks from the initial search are expected to contain absolute mass density values at mole fractions spanning up to and including x ≈ 0.5. For reference, the density of an equimolar propan-2-ol + water mixture at 25 °C and atmospheric pressure is typically around **840–860 kg/m³** based on the general trend of this well-studied system, but I was unable to confirm the exact ThermoML-recorded value in this session. A follow-up targeted inspection of the other identified blocks (e.g., those reporting mole-fraction-based composition variables over the full range) would yield the precise measured value with its DOI provenance.

**Core claims:**
- Ten binary mass density data blocks for the propan-2-ol + water system near 298.15 K were identified in the ThermoML database, but the exact numerical density value at the equimolar composition (x ≈ 0.5) could not be extracted due to tool-call limitations.
- The one block inspected in detail (GLOBlit_2432, PROPblock_4) reported density differences at very dilute concentrations (molality-based, x ≈ 0.002–0.014) and was not suitable for the equimolar query.
- A typical literature value for the density of an equimolar propan-2-ol + water mixture at 25 °C and atmospheric pressure is around 840–860 kg/m³, but this was not confirmed from ThermoML-recorded data in this session.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#2 | 「GLOBlit_2432」 | 「PROPblock_4」 | 「GLOBcomp_6, GLOBcomp_1」 | 「GLOBprop_1」 | 「Density difference data for propan-2-ol + water at dilute molalities near 298 K; inspected but found unsuitable for equimolar composition query.」 |

*Not stored here: 2 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.
### L1_query_2
**L1_query_2** — status: success · validation: PASS

**Summary:**

The ThermoML database contains a measured mass density for a nearly equimolar propan-2-ol + water binary mixture at 25 °C and atmospheric pressure. The density is 838.8 ± 0.4 kg/m³ at x(propan-2-ol) = 0.4981, 298.15 K, and 101.0 kPa in the liquid phase, sourced from DOI 10.1021/je700700f. This value reflects the well-known negative excess volume of alcohol–water mixtures; an ideal mole-fraction-weighted estimate would give roughly 892 kg/m³, so the measured value being ~53 kg/m³ lower indicates significant non-ideal mixing due to hydrogen-bonding reorganization. A second dataset (DOI 10.1021/je800158z) at x = 0.5204 and 293.15 K reports ρ = 839.36 kg/m³, consistent when accounting for slight temperature and composition differences.

**Answer:**

The ThermoML database contains a measured mass density for a nearly equimolar propan-2-ol + water binary mixture at 25 °C and atmospheric pressure:

- **Density: 838.8 ± 0.4 kg/m³**
- **Composition:** x(propan-2-ol) = 0.4981 (essentially equimolar)
- **Temperature:** 298.15 K (25.00 °C)
- **Pressure:** 101.0 kPa (~1 atm)
- **Phase:** Liquid
- **Source:** DOI 10.1021/je700700f (GLOBlit_11042, PROPblock_17)
- **Compounds:** propan-2-ol (GLOBcomp_6, CAS 67-63-0) + water (GLOBcomp_1, CAS 7732-18-5)

This value is physically reasonable: pure water at 25 °C has a density of ~997 kg/m³ and pure propan-2-ol ~786 kg/m³. The equimolar mixture density of 838.8 kg/m³ reflects the well-known negative excess volume (volume contraction) of alcohol–water mixtures, where hydrogen-bonding reorganization causes the mixture to be denser than a simple linear (ideal) interpolation by mole fraction would predict. An ideal mole-fraction-weighted estimate would give roughly 892 kg/m³, so the measured value being ~53 kg/m³ lower indicates significant non-ideal mixing — consistent with the strong negative excess volumes observed near x ≈ 0.3–0.5 for short-chain alcohol + water systems.

A second block (GLOBlit_11142, PROPblock_4, DOI 10.1021/je800158z) also covers this composition range but at a lower fixed pressure of 81.5 kPa and did not include 298.15 K data at x ≈ 0.5 in the available subset. At x = 0.5204 and 293.15 K in that dataset, ρ = 839.36 kg/m³, which is consistent with the value above when accounting for the slight temperature and composition differences.

**Core claims:**
- The ThermoML database reports a measured liquid density of 838.8 ± 0.4 kg/m³ for a propan-2-ol + water binary mixture at x(propan-2-ol) = 0.4981, 298.15 K, and 101.0 kPa (DOI 10.1021/je700700f).
- The measured equimolar mixture density of 838.8 kg/m³ reflects the well-known negative excess volume (volume contraction) of alcohol–water mixtures due to hydrogen-bonding reorganization, making the mixture denser than a simple linear mole-fraction interpolation would predict.
- A second dataset (DOI 10.1021/je800158z) at x = 0.5204 and 293.15 K reports ρ = 839.36 kg/m³, which is consistent with the primary value when accounting for slight temperature and composition differences.

**Core blocks found:**

**WM_L1_Q2_Blocks_(Query_L1_Q2_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q2_Table#1 | 「GLOBlit_11042」 | 「PROPblock_17」 | 「GLOBcomp_6, GLOBcomp_1」 | 「GLOBprop_1」 | 「Mass density of propan-2-ol + water at x(propan-2-ol) = 0.4981, T = 298.15 K, P = 101.0 kPa; measured value 838.8 kg/m³ used as the primary answer.」 |
| WM_L1_Q2_Table#2 | 「GLOBlit_11142」 | 「PROPblock_4」 | 「GLOBcomp_6, GLOBcomp_1」 | 「GLOBprop_1」 | 「Mass density of propan-2-ol + water at x = 0.5204, T = 293.15 K, P = 81.5 kPa; cited as corroborating data (839.36 kg/m³) consistent with the primary value.」 |

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.



</memory>

## User
What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

## Assistant
<summary>Dispatching L1 query to find density (GLOBprop_1) data for propan-2-ol + water binary mixture at 298.15 K, equimolar composition (x = 0.5), atmospheric pressure.</summary>
<tool_call>L1_query(instruction=Search for densit…, id_catalog=, context=User wants densit…)</tool_call>

## User
<tool_result>
<subagent_answer>
### L1#1 — L1_query return

**Status:** status=partial

**Summary:**

The search identified 10 binary mass density data blocks for propan-2-ol (CAS 67-63-0) + water (CAS 7732-18-5) in ThermoML near 298.15 K. One block inspected in detail (GLOBlit_2432, PROPblock_4, DOI 10.1016/j.jct.2004.07.019) reported density differences at very dilute molalities (x ≈ 0.002–0.014) and was not suitable for equimolar composition. The remaining blocks are expected to cover the full mole-fraction range including x ≈ 0.5 but their exact numerical values could not be extracted in this session. No precise ThermoML-recorded density value at equimolar composition was confirmed.

**Answer:**

Based on my search of the ThermoML database, I found 10 binary mass density (GLOBprop_1) data blocks for the propan-2-ol (GLOBcomp_6) + water (GLOBcomp_1) system near 298.15 K. However, I was unable to drill down to extract the exact numerical density value at the equimolar (x ≈ 0.5) composition due to tool-call limitations encountered during this session.

Here is what was established:

- **System:** Binary mixture of propan-2-ol (isopropanol, CAS 67-63-0) and water (CAS 7732-18-5)
- **Property:** Mass density (GLOBprop_1, kg/m³)
- **Conditions sought:** T ≈ 298.15 K, P ≈ 101.325 kPa, x(propan-2-ol) ≈ 0.5

**Available data blocks identified (all binary, T range includes ~298 K):**

**L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *DOI* | *GLOBlit* | *Block* | *Notes* |
|---|---|---|---|---|
| L1#1_Table#1_Row#1 | 「10.1016/j.jct.2004.07.019」 | 「GLOBlit_2432」 | 「PROPblock_4」 | 「Density differences (Δρ) at dilute molalities — not suitable for equimolar data」 |
| L1#1_Table#1_Row#2 | 「(9 additional blocks found)」 | 「Various GLOBlit IDs」 | 「Various PROPblock IDs」 | 「Several span the full mole/mass fraction range and likely contain data near x = 0.5」 |

The search confirmed that multiple ThermoML literature sources report density data for propan-2-ol + water binaries at 298.15 K across broad composition ranges. The one block inspected in detail (GLOBlit_2432, PROPblock_4) turned out to report density differences at very dilute concentrations (molality-based, x ≈ 0.002–0.014), so it was not suitable for the equimolar query.

The remaining blocks from the initial search are expected to contain absolute mass density values at mole fractions spanning up to and including x ≈ 0.5. For reference, the density of an equimolar propan-2-ol + water mixture at 25 °C and atmospheric pressure is typically around **840–860 kg/m³** based on the general trend of this well-studied system, but I was unable to confirm the exact ThermoML-recorded value in this session. A follow-up targeted inspection of the other identified blocks (e.g., those reporting mole-fraction-based composition variables over the full range) would yield the precise measured value with its DOI provenance.

**Core claims:**
- Ten binary mass density data blocks for the propan-2-ol + water system near 298.15 K were identified in the ThermoML database, but the exact numerical density value at the equimolar composition (x ≈ 0.5) could not be extracted due to tool-call limitations.
- The one block inspected in detail (GLOBlit_2432, PROPblock_4) reported density differences at very dilute concentrations (molality-based, x ≈ 0.002–0.014) and was not suitable for the equimolar query.
- A typical literature value for the density of an equimolar propan-2-ol + water mixture at 25 °C and atmospheric pressure is around 840–860 kg/m³, but this was not confirmed from ThermoML-recorded data in this session.

**Core ID updates:**
- add GLOBcomp_6 — propan-2-ol (registry: propan-2-ol)
- add GLOBcomp_1 — water (registry: water)

#### Core blocks found — verbatim ledger

```ledger
**L1#1_Table#2_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_2432 | lit_id: 2004-hyn-hne-0 | doi: 10.1016/j.jct.2004.07.019
block: PROPblock_4 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_1) | system: binary | n_datapoints: 529
compounds: propan-2-ol (C3H8O; GLOBcomp_6; DOIcomp_3; InChIKey KFZMGEQAYNKOFK-UHFFFAOYSA-N); water (H2O; GLOBcomp_1; DOIcomp_4; InChIKey XLYOFNOQVPJJNP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_1
description: Density difference data for propan-2-ol + water at dilute molalities near 298 K; inspected but found unsuitable for equimolar composition query.
solvents: [{'component_org_num': 'DOIcomp_4', 'comp_num_id': 'GLOBcomp_1', 'solvent_num_id': 'GLOBsolvent_1', 'inchi_key': 'XLYOFNOQVPJJNP-UHFFFAOYSA-N'}]

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#2_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.16–573.15 · n_unique=18 · phase=Liquid」 |
| L1#1_Table#2_Row#2 | 「variable」 | 「BLKvar_2/GLOBvar_3」 | 「Pressure, kPa」 | 「range=390.0–30330.0 · n_unique=33 · phase=Liquid」 |
| L1#1_Table#2_Row#3 | 「variable」 | 「BLKvar_3/GLOBvar_4」 | 「Molality, mol/kg of propan-2-ol」 | 「range=0.08624–0.82102 · n_unique=159 · phase=Liquid」 |
| L1#1_Table#2_Row#4 | 「property」 | 「BLKprop_1/GLOBprop_1」 | 「Mass density, kg/m3」 | 「method=Vibrating tube method (GLOBmeas_2) · range=-19.9725–-1.1132 · mean=-5.916491 · n=529 · phase=Liquid」 |
```
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>First L1 query found 10 blocks but only inspected one unsuitable block. Dispatching a follow-up L1 query to inspect the remaining 9 blocks and extract actual density values at x(propan-2-ol) ≈ 0.5, T = 298.15 K.</summary>
<tool_call>L1_query(instruction=We already know t…, id_catalog=comp: GLOBcomp_6 …, context=Previous…)</tool_call>

## User
<tool_result>
<subagent_answer>
### L1#2 — L1_query return

**Status:** status=success

**Summary:**

The ThermoML database contains a measured mass density for a nearly equimolar propan-2-ol + water binary mixture at 25 °C and atmospheric pressure. The density is 838.8 ± 0.4 kg/m³ at x(propan-2-ol) = 0.4981, 298.15 K, and 101.0 kPa in the liquid phase, sourced from DOI 10.1021/je700700f. This value reflects the well-known negative excess volume of alcohol–water mixtures; an ideal mole-fraction-weighted estimate would give roughly 892 kg/m³, so the measured value being ~53 kg/m³ lower indicates significant non-ideal mixing due to hydrogen-bonding reorganization. A second dataset (DOI 10.1021/je800158z) at x = 0.5204 and 293.15 K reports ρ = 839.36 kg/m³, consistent when accounting for slight temperature and composition differences.

**Answer:**

The ThermoML database contains a measured mass density for a nearly equimolar propan-2-ol + water binary mixture at 25 °C and atmospheric pressure:

- **Density: 838.8 ± 0.4 kg/m³**
- **Composition:** x(propan-2-ol) = 0.4981 (essentially equimolar)
- **Temperature:** 298.15 K (25.00 °C)
- **Pressure:** 101.0 kPa (~1 atm)
- **Phase:** Liquid
- **Source:** DOI 10.1021/je700700f (GLOBlit_11042, PROPblock_17)
- **Compounds:** propan-2-ol (GLOBcomp_6, CAS 67-63-0) + water (GLOBcomp_1, CAS 7732-18-5)

This value is physically reasonable: pure water at 25 °C has a density of ~997 kg/m³ and pure propan-2-ol ~786 kg/m³. The equimolar mixture density of 838.8 kg/m³ reflects the well-known negative excess volume (volume contraction) of alcohol–water mixtures, where hydrogen-bonding reorganization causes the mixture to be denser than a simple linear (ideal) interpolation by mole fraction would predict. An ideal mole-fraction-weighted estimate would give roughly 892 kg/m³, so the measured value being ~53 kg/m³ lower indicates significant non-ideal mixing — consistent with the strong negative excess volumes observed near x ≈ 0.3–0.5 for short-chain alcohol + water systems.

A second block (GLOBlit_11142, PROPblock_4, DOI 10.1021/je800158z) also covers this composition range but at a lower fixed pressure of 81.5 kPa and did not include 298.15 K data at x ≈ 0.5 in the available subset. At x = 0.5204 and 293.15 K in that dataset, ρ = 839.36 kg/m³, which is consistent with the value above when accounting for the slight temperature and composition differences.

**Core claims:**
- The ThermoML database reports a measured liquid density of 838.8 ± 0.4 kg/m³ for a propan-2-ol + water binary mixture at x(propan-2-ol) = 0.4981, 298.15 K, and 101.0 kPa (DOI 10.1021/je700700f).
- The measured equimolar mixture density of 838.8 kg/m³ reflects the well-known negative excess volume (volume contraction) of alcohol–water mixtures due to hydrogen-bonding reorganization, making the mixture denser than a simple linear mole-fraction interpolation would predict.
- A second dataset (DOI 10.1021/je800158z) at x = 0.5204 and 293.15 K reports ρ = 839.36 kg/m³, which is consistent with the primary value when accounting for slight temperature and composition differences.

#### Core blocks found — verbatim ledger

```ledger
**L1#2_Table#1_(Query_L1#2_CoreBLK):**
lit_num_id: GLOBlit_11042 | lit_id: 2008-gon-cal-0 | doi: 10.1021/je700700f
block: PROPblock_17 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_1) | system: binary | n_datapoints: 13
compounds: propan-2-ol (C3H8O; GLOBcomp_6; DOIcomp_2; InChIKey KFZMGEQAYNKOFK-UHFFFAOYSA-N); water (H2O; GLOBcomp_1; DOIcomp_3; InChIKey XLYOFNOQVPJJNP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_1
description: Mass density of propan-2-ol + water at x(propan-2-ol) = 0.4981, T = 298.15 K, P = 101.0 kPa; measured value 838.8 kg/m³ used as the primary answer.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#2_Table#1_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=101.0 · phase=Liquid」 |
| L1#2_Table#1_Row#2 | 「constraint」 | 「BLKconstr_2/GLOBconstr_2」 | 「Temperature, K」 | 「value=298.15 · phase=Liquid」 |
| L1#2_Table#1_Row#3 | 「variable」 | 「BLKvar_1/GLOBvar_2」 | 「Mole fraction of propan-2-ol」 | 「range=0.0–1.0 · n_unique=13 · phase=Liquid」 |
| L1#2_Table#1_Row#4 | 「property」 | 「BLKprop_1/GLOBprop_1」 | 「Mass density, kg/m3」 | 「method=VIBTUB:UFactor:4 (GLOBmeas_134) · range=780.7–997.2 · mean=861.961538 · n=13 · phase=Liquid」 |
```

```ledger
**L1#2_Table#2_(Query_L1#2_CoreBLK):**
lit_num_id: GLOBlit_11142 | lit_id: 2008-zar-sha-0 | doi: 10.1021/je800158z
block: PROPblock_4 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_1) | system: binary | n_datapoints: 56
compounds: propan-2-ol (C3H8O; GLOBcomp_6; DOIcomp_2; InChIKey KFZMGEQAYNKOFK-UHFFFAOYSA-N); water (H2O; GLOBcomp_1; DOIcomp_3; InChIKey XLYOFNOQVPJJNP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_1
description: Mass density of propan-2-ol + water at x = 0.5204, T = 293.15 K, P = 81.5 kPa; cited as corroborating data (839.36 kg/m³) consistent with the primary value.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#2_Table#2_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=81.5 · phase=Liquid」 |
| L1#2_Table#2_Row#2 | 「variable」 | 「BLKvar_1/GLOBvar_2」 | 「Mole fraction of propan-2-ol」 | 「range=0.0–1.0 · n_unique=14 · phase=Liquid」 |
| L1#2_Table#2_Row#3 | 「variable」 | 「BLKvar_2/GLOBvar_1」 | 「Temperature, K」 | 「range=293.15–323.15 · n_unique=4 · phase=Liquid」 |
| L1#2_Table#2_Row#4 | 「property」 | 「BLKprop_1/GLOBprop_1」 | 「Mass density, kg/m3」 | 「method=VIBTUB:UFactor:4 (GLOBmeas_134) · range=758.68–998.2 · mean=854.478036 · n=56 · phase=Liquid」 |
```
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
The ThermoML database records a measured liquid density of **838.8 ± 0.4 kg/m³** for a nearly equimolar propan-2-ol (isopropanol) + water binary mixture under the following conditions:

| Parameter | Value |
|-----------|-------|
| **Density** | 838.8 kg/m³ |
| **Mole fraction of propan-2-ol** | 0.4981 (essentially equimolar) |
| **Temperature** | 298.15 K (25.00 °C) |
| **Pressure** | 101.0 kPa (~1 atm) |
| **Phase** | Liquid |
| **Source** | DOI 10.1021/je700700f (GLOBlit_11042, PROPblock_17) |
| **Measurement method** | Vibrating-tube densimetry |

**Chemical context:** Pure water at 25 °C has a density of ~997 kg/m³ and pure propan-2-ol ~786 kg/m³. A simple mole-fraction-weighted (ideal) estimate would give roughly 892 kg/m³ for the equimolar mixture. The measured value of 838.8 kg/m³ is notably lower, reflecting the well-known **negative excess volume** (volume contraction) characteristic of short-chain alcohol + water systems. This contraction arises from hydrogen-bonding reorganization: when propan-2-ol and water mix, the restructuring of the hydrogen-bond network allows molecules to pack more efficiently than in the pure liquids, producing a mixture that is denser than ideal mixing would predict.

**Corroborating data:** A second ThermoML dataset (DOI 10.1021/je800158z, GLOBlit_11142, PROPblock_4) reports ρ = 839.36 kg/m³ at x(propan-2-ol) = 0.5204 and 293.15 K (P = 81.5 kPa). This value is consistent with the primary measurement when accounting for the slightly different temperature and composition.
</answer>