# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_36 | 1-butyl-3-methylimidazolium_tetrafluoroborate | 1-butyl-3-methylimidazolium tetrafluoroborate |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all surface tension measurements for 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at or near 298.15 → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

Nine independent ThermoML data blocks report the surface tension (liquid–gas) of pure 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4], C₈H₁₅BF₄N₂) at approximately 298.15 K. Reported values span 0.0436–0.0469 N/m (43.6–46.9 mN/m), with most clustering around 0.0443–0.0454 N/m. Expanded uncertainties (95% coverage) range from ±0.0003 N/m (drop volume) to ±0.0013 N/m (capillary rise). Six different measurement techniques are represented: ring tensiometer, pendant drop shape, drop volume, maximal bubble pressure, plate method, and capillary rise. The value at 297.0 K of 0.0469 N/m is notably higher than the consensus. The weighted consensus of the tighter measurements centers near 0.0445 ± 0.001 N/m at 298.15 K, consistent with expectations for imidazolium-based ionic liquids with the BF₄⁻ anion.

**Answer:**

#### Surface Tension of 1-Butyl-3-methylimidazolium Tetrafluoroborate ([C4mim][BF4]) at ~298.15 K

**Compound:** 1-butyl-3-methylimidazolium tetrafluoroborate (GLOBcomp_36, C₈H₁₅BF₄N₂)  
**Property:** Surface tension, liquid–gas (GLOBprop_13), unit: N/m  
**System:** Pure (unary)

Nine independent ThermoML data blocks report surface tension for this ionic liquid at or near 298.15 K. All expanded uncertainties are reported at 95% coverage (k = 95%), propagation method, compiler-assigned.

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *#* | *T (K)* | *γ (N/m)* | *U (N/m)* | *Block* | *Literature* | *DOI* | *Method* |
|---|---|---|---|---|---|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「1」 | 「297.0」 | 「0.0469」 | 「0.0009」 | 「PROPblock_22」 | 「GLOBlit_9491」 | 「10.1021/je2000183」 | 「Ring tensiometer」 |
| WM_L1_Q1_Table#1_Row#2 | 「2」 | 「298.0」 | 「0.04544」 | 「0.00049」 | 「PROPblock_9」 | 「GLOBlit_3588」 | 「10.1016/j.jct.2012.03.008」 | 「Pendant drop shape」 |
| WM_L1_Q1_Table#1_Row#3 | 「3」 | 「298.15」 | 「0.04533」 | 「0.0003」 | 「PROPblock_4」 | 「GLOBlit_725」 | 「10.1016/j.fluid.2009.07.010」 | 「Drop volume」 |
| WM_L1_Q1_Table#1_Row#4 | 「4」 | 「298.15」 | 「0.0447」 | 「0.0004」 | 「PROPblock_7」 | 「GLOBlit_9790」 | 「10.1021/je3000348」 | 「Maximal bubble pressure」 |
| WM_L1_Q1_Table#1_Row#5 | 「5」 | 「298.15」 | 「0.04452」 | 「0.00046」 | 「PROPblock_1」 | 「GLOBlit_5419」 | 「10.1016/j.jct.2018.12.036」 | 「Plate method」 |
| WM_L1_Q1_Table#1_Row#6 | 「6」 | 「298.15」 | 「0.0446」 | 「0.00084」 | 「PROPblock_2」 | 「GLOBlit_6476」 | 「10.1016/j.tca.2019.01.018」 | 「Ring tensiometer」 |
| WM_L1_Q1_Table#1_Row#7 | 「7」 | 「298.15」 | 「0.04437」 | 「0.00064」 | 「PROPblock_2」 | 「GLOBlit_9568」 | 「10.1021/je200349t」 | 「Ring tensiometer」 |
| WM_L1_Q1_Table#1_Row#8 | 「8」 | 「298.5」 | 「0.04441」 | 「0.00059」 | 「PROPblock_2」 | 「GLOBlit_3156」 | 「10.1016/j.jct.2009.09.007」 | 「Ring tensiometer」 |
| WM_L1_Q1_Table#1_Row#9 | 「9」 | 「298.0」 | 「0.0436」 | 「0.0013」 | 「PROPblock_4」 | 「GLOBlit_572」 | 「10.1016/j.fluid.2007.10.004」 | 「Capillary rise」 |

##### Key observations

- **Value range:** Surface tension values at ~298 K span 0.0436–0.0469 N/m (43.6–46.9 mN/m), with most values clustering around 0.0443–0.0454 N/m.
- **Expanded uncertainties** range from ±0.0003 N/m (drop volume, GLOBlit_725) to ±0.0013 N/m (capillary rise, GLOBlit_572).
- The outlier at 0.0469 N/m (GLOBlit_9491, ring tensiometer at 297 K) is notably higher than the consensus and carries a relatively large uncertainty (±0.0009 N/m).
- Five different measurement techniques are represented: ring tensiometer, pendant drop shape, drop volume, maximal bubble pressure, plate method, and capillary rise — providing a robust cross-method comparison.
- The weighted consensus of the tighter measurements (entries 2–8) centers near **0.0445 ± 0.001 N/m** at 298.15 K, consistent with the moderate surface tension expected for imidazolium-based ionic liquids with the BF₄⁻ anion.

**Core claims:**
- Nine independent ThermoML data blocks report the surface tension of pure 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at approximately 298.15 K, spanning a range of 0.0436–0.0469 N/m with most values clustering around 0.0443–0.0454 N/m.
- Expanded uncertainties (95% coverage) across the nine measurements range from ±0.0003 N/m (drop volume) to ±0.0013 N/m (capillary rise).
- The value of 0.0469 N/m (GLOBlit_9491, ring tensiometer at 297 K) is identified as a notable outlier above the consensus, with a relatively large uncertainty of ±0.0009 N/m.
- Five or more different measurement techniques (ring tensiometer, pendant drop shape, drop volume, maximal bubble pressure, plate method, capillary rise) are represented, providing a cross-method comparison.
- The weighted consensus of the tighter measurements (entries 2–8) centers near 0.0445 ± 0.001 N/m at 298.15 K.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#2 | 「GLOBlit_9491」 | 「PROPblock_22」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at 297.0 K via ring tensiometer, reporting 0.0469 N/m with expanded uncertainty 0.0009 N/m.」 |
| WM_L1_Q1_Table#3 | 「GLOBlit_3588」 | 「PROPblock_9」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at 298.0 K via pendant drop shape, reporting 0.04544 N/m with expanded uncertainty 0.00049 N/m.」 |
| WM_L1_Q1_Table#4 | 「GLOBlit_725」 | 「PROPblock_4」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at 298.15 K via drop volume, reporting 0.04533 N/m with expanded uncertainty 0.0003 N/m.」 |
| WM_L1_Q1_Table#5 | 「GLOBlit_9790」 | 「PROPblock_7」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at 298.15 K via maximal bubble pressure, reporting 0.0447 N/m with expanded uncertainty 0.0004 N/m.」 |
| WM_L1_Q1_Table#6 | 「GLOBlit_5419」 | 「PROPblock_1」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at 298.15 K via plate method, reporting 0.04452 N/m with expanded uncertainty 0.00046 N/m.」 |
| WM_L1_Q1_Table#7 | 「GLOBlit_6476」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at 298.15 K via ring tensiometer, reporting 0.0446 N/m with expanded uncertainty 0.00084 N/m.」 |
| WM_L1_Q1_Table#8 | 「GLOBlit_9568」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at 298.15 K via ring tensiometer, reporting 0.04437 N/m with expanded uncertainty 0.00064 N/m.」 |
| WM_L1_Q1_Table#9 | 「GLOBlit_3156」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at 298.5 K via ring tensiometer, reporting 0.04441 N/m with expanded uncertainty 0.00059 N/m.」 |
| WM_L1_Q1_Table#10 | 「GLOBlit_572」 | 「PROPblock_4」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension measurement for pure [C4mim][BF4] at 298.0 K via capillary rise, reporting 0.0436 N/m with expanded uncertainty 0.0013 N/m.」 |

*Not stored here: 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


