# Q1.7 — Result

**Prompt:** Using ThermoML, report the surface tension of 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at or near 298.15 K from every source, each with its reported expanded uncertainty and block identifier, and say whether the sources agree within those uncertainties.

**Tool calls:** 1  |  **Time:** 447.6s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

## Surface Tension of 1-Butyl-3-methylimidazolium Tetrafluoroborate ([C4mim][BF4]) at ~298.15 K

**Compound:** 1-butyl-3-methylimidazolium tetrafluoroborate (C₈H₁₅BF₄N₂)  
**Property:** Surface tension, liquid–gas (N/m)  
**System:** Pure compound

Nine independent ThermoML data blocks report the surface tension of this ionic liquid at or near 298.15 K. All expanded uncertainties are at 95% coverage.

| # | T (K) | γ (N/m) | U₉₅ (N/m) | Block | Literature | DOI | Method |
|---|-------|---------|-----------|-------|------------|-----|--------|
| 1 | 297.0 | 0.0469 | ±0.0009 | PROPblock_22 | GLOBlit_9491 | 10.1021/je2000183 | Ring tensiometer |
| 2 | 298.0 | 0.04544 | ±0.00049 | PROPblock_9 | GLOBlit_3588 | 10.1016/j.jct.2012.03.008 | Pendant drop shape |
| 3 | 298.15 | 0.04533 | ±0.0003 | PROPblock_4 | GLOBlit_725 | 10.1016/j.fluid.2009.07.010 | Drop volume |
| 4 | 298.15 | 0.0447 | ±0.0004 | PROPblock_7 | GLOBlit_9790 | 10.1021/je3000348 | Maximal bubble pressure |
| 5 | 298.15 | 0.04452 | ±0.00046 | PROPblock_1 | GLOBlit_5419 | 10.1016/j.jct.2018.12.036 | Plate method |
| 6 | 298.15 | 0.0446 | ±0.00084 | PROPblock_2 | GLOBlit_6476 | 10.1016/j.tca.2019.01.018 | Ring tensiometer |
| 7 | 298.15 | 0.04437 | ±0.00064 | PROPblock_2 | GLOBlit_9568 | 10.1021/je200349t | Ring tensiometer |
| 8 | 298.5 | 0.04441 | ±0.00059 | PROPblock_2 | GLOBlit_3156 | 10.1016/j.jct.2009.09.007 | Ring tensiometer |
| 9 | 298.0 | 0.0436 | ±0.0013 | PROPblock_4 | GLOBlit_572 | 10.1016/j.fluid.2007.10.004 | Capillary rise |

---

### Do the sources agree within their reported expanded uncertainties?

**No — not all sources agree.** A pairwise overlap analysis (two values agree if |γ₁ − γ₂| ≤ U₁ + U₂) reveals three tiers of consistency:

1. **Clear outlier — Entry 1 (0.0469 N/m, GLOBlit_9491):**  
   This ring-tensiometer value at 297.0 K is 1.6–3.3 mN/m above all other entries. It fails the overlap test with every other source. For example, vs. Entry 3: |0.0469 − 0.04533| = 0.00157 N/m, which exceeds U₁ + U₃ = 0.0012 N/m. This value likely reflects a systematic bias (sample purity, wetting issues, or calibration).

2. **Core cluster — Entries 4–8 (0.0444–0.0447 N/m):**  
   These five measurements from four independent laboratories using three different techniques (maximal bubble pressure, plate method, ring tensiometer) agree mutually within their expanded uncertainties. They define a tight consensus of **γ ≈ 0.0445 ± 0.0002 N/m** at 298.15 K.

3. **Marginally higher sub-group — Entries 2 & 3 (0.0453–0.0454 N/m):**  
   The pendant-drop and drop-volume values agree with each other (|diff| = 0.00011 < 0.00079) and with Entry 4 (maximal bubble pressure), but they *barely fail* the overlap criterion against Entries 5, 7, and 8. For instance, Entry 3 vs. Entry 7: |0.04533 − 0.04437| = 0.00096 N/m, just exceeding U₃ + U₇ = 0.00094 N/m. This ~1 mN/m offset may reflect a real method-dependent systematic effect.

4. **Entry 9 (0.0436 N/m, capillary rise, GLOBlit_572):**  
   The lowest value, but it carries the largest uncertainty (±0.0013 N/m). It agrees with the core cluster (Entries 4–8) within uncertainties, but barely fails against the higher Entries 2 and 3.

### Summary assessment

Six of the nine sources (Entries 4–9) are mutually consistent within their stated expanded uncertainties, centering on **γ ≈ 0.0445 N/m**. The pendant-drop and drop-volume values (Entries 2–3) sit about 1 mN/m higher and show only marginal overlap with the core group. Entry 1 (0.0469 N/m) is a clear outlier that disagrees with all other sources. Overall, the inter-laboratory spread of ~3.3 mN/m (0.0436–0.0469 N/m) exceeds the individual expanded uncertainties, indicating that systematic effects — likely related to sample purity, measurement technique, and surface equilibration — are the dominant source of disagreement, as is commonly observed for ionic liquid surface tension measurements.

### Core claims

- Nine independent ThermoML sources report the surface tension of pure [C4mim][BF4] at or near 298.15 K, spanning a range of ~3.3 mN/m (0.0436–0.0469 N/m), which exceeds the individual expanded uncertainties and indicates that not all sources agree within their reported uncertainties.
- Five measurements (Entries 4–8, γ = 0.0444–0.0447 N/m) from four independent laboratories using three different techniques form a mutually consistent core cluster centering on γ ≈ 0.0445 ± 0.0002 N/m at 298.15 K.
- The pendant-drop and drop-volume values (Entries 2–3, γ = 0.0453–0.0454 N/m) sit about 1 mN/m above the core cluster and show only marginal overlap with it, barely failing the pairwise uncertainty overlap criterion against several core-cluster entries.
- Entry 1 (0.0469 N/m at 297.0 K, GLOBlit_9491) is a clear outlier that fails the overlap test with every other source and likely reflects a systematic bias.
- Entry 9 (0.0436 N/m, capillary rise, GLOBlit_572) is the lowest value but carries the largest uncertainty (±0.0013 N/m) and agrees with the core cluster within uncertainties.
- Systematic effects — likely related to sample purity, measurement technique, and surface equilibration — are identified as the dominant source of inter-laboratory disagreement, consistent with common observations for ionic liquid surface tension measurements.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_9491 | 10.1021/je2000183 | PROPblock_22 |  | Provides the surface tension of [C4mim][BF4] at 297.0 K (0.0469 N/m) via ring tensiometer. Identified in the answer as a clear outlier that disagrees with all other sources, contributing to the inter-laboratory spread analysis. |
| GLOBlit_3588 | 10.1016/j.jct.2012.03.008 | PROPblock_9 |  | Provides pendant drop shape surface tension data for [C4mim][BF4] with the 298.0 K value of 0.04544 N/m used in the answer. Contributes to the marginally higher sub-group (Entries 2–3) in the consistency analysis. |
| GLOBlit_725 | 10.1016/j.fluid.2009.07.010 | PROPblock_4 |  | Provides a single drop-volume surface tension measurement of 0.04533 N/m at 298.15 K for [C4mim][BF4]. Part of the marginally higher sub-group used in the pairwise overlap analysis. |
| GLOBlit_9790 | 10.1021/je3000348 | PROPblock_7 |  | Provides maximal bubble pressure surface tension data for [C4mim][BF4] with the 298.15 K value of 0.0447 N/m. Part of the core cluster (Entries 4–8) centering on γ ≈ 0.0445 N/m. |
| GLOBlit_5419 | 10.1016/j.jct.2018.12.036 | PROPblock_1 |  | Provides plate method surface tension data for [C4mim][BF4] with the 298.15 K value of 0.04452 N/m. Part of the core cluster contributing to the consensus value of γ ≈ 0.0445 N/m. |
| GLOBlit_6476 | 10.1016/j.tca.2019.01.018 | PROPblock_2 |  | Provides ring tensiometer surface tension data for [C4mim][BF4] with the 298.15 K value of 0.0446 N/m. Part of the core cluster (Entries 4–8) in the agreement analysis. |
| GLOBlit_9568 | 10.1021/je200349t | PROPblock_2 |  | Provides ring tensiometer surface tension data for [C4mim][BF4] with the 298.15 K value of 0.04437 N/m. Part of the core cluster and used in the pairwise overlap test (e.g., vs. Entry 3). |
| GLOBlit_3156 | 10.1016/j.jct.2009.09.007 | PROPblock_2 |  | Provides ring tensiometer surface tension data for [C4mim][BF4] over a wide temperature range; the ~298.5 K value of 0.04441 N/m is used in the answer as part of the core cluster. |
| GLOBlit_572 | 10.1016/j.fluid.2007.10.004 | PROPblock_4 |  | Provides capillary rise surface tension data for [C4mim][BF4] with the 298.0 K value of 0.0436 N/m. Identified as the lowest value with the largest uncertainty, agreeing with the core cluster but defining the lower bound of the inter-laboratory spread. |

### Suggested follow-ups

- Investigate the effect of sample purity (water content, halide impurities) on the reported surface tension values, particularly for the outlier GLOBlit_9491.
- Compare surface tension values obtained by different measurement techniques (ring, pendant drop, bubble pressure, capillary rise) across a wider temperature range to quantify method-dependent systematic offsets for [C4mim][BF4].
- Search for additional ThermoML entries reporting surface tension of [C4mim][BF4] at other temperatures to construct a complete γ(T) curve and assess consistency of temperature coefficients across sources.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_36",
    "registry_id": "1-butyl-3-methylimidazolium_tetrafluoroborate",
    "name": "1-butyl-3-methylimidazolium tetrafluoroborate"
  }
]
```
