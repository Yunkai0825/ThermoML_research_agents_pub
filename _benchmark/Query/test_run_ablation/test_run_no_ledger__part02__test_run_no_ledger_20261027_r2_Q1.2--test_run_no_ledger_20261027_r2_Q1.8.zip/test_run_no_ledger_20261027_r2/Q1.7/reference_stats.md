# Reference Stats — query-agent

**Run started:** 2026-10-27 03:44:52
**Wall time (at last flush):** 390.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 25,541 | 42,453 | 16,362 | 67,994 | 13,598 | 100.5 | claudeopus46 |
| L1-worker | 29 | 312,264 | 166,791 | 40,272 | 479,055 | 16,519 | 273.9 | claudeopus46 |
| **TOTAL** | **34** | **337,805** | **209,244** | **56,634** | **547,049** | **16,089** | **374.4** | |

**Estimated tokens:** ~136,762 input + ~14,158 output = ~150,920 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 1 | 0 | 0 | 0 | 9 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 1 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 9 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 6 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 1 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 5 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 7 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 15 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 5 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 20 |
| **TOTAL** | **12** | **10** | **11** | **0** | **31** | **23** | **174** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_36 |  | block_search_adv, resolve_compound_ids, search_blocks |

#### References (13 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_572 |  | block_search_adv, search_blocks |
| GLOBlit_725 |  | block_search_adv, search_blocks |
| GLOBlit_3156 |  | block_search_adv, search_blocks |
| GLOBlit_3588 |  | block_search_adv, search_blocks |
| GLOBlit_3600 |  | search_blocks |
| GLOBlit_4058 |  | search_blocks |
| GLOBlit_5419 |  | block_search_adv, search_blocks |
| GLOBlit_6476 |  | block_search_adv, search_blocks |
| GLOBlit_9491 |  | block_search_adv, search_blocks |
| GLOBlit_9568 |  | block_search_adv, search_blocks |
| GLOBlit_9790 |  | block_search_adv, search_blocks |
| GLOBlit_11369 |  | search_blocks |
| GLOBlit_11673 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks |

#### Measurements (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_58 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_32 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_192 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_19 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_22 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_1015 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_312 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_36 | Surface tension liquid-gas, N/m | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | resolve_ids, search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_2 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique References | 13 |
| Unique Properties | 1 |
| Unique Measurements | 8 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 13 |
| Unique parent blocks | 14 |
| Explicit block/subsystem targets | 14 |
| Subsystem targets | 0 |
| Target-matched data points | 174 |

---

## 3. DOI & Block References

**Unique DOIs:** 13  |  **Parent blocks:** 14  |  **Explicit targets:** 14  |  **Subsystems:** 0  |  **Target-matched datapoints:** 105

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2007.10.004 | 1 | 20 | unary | search_blocks |
| 10.1016/j.fluid.2009.07.010 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2009.09.007 | 2 | 30 | unary | search_blocks |
| 10.1016/j.jct.2012.03.008 | 1 | 6 | unary | search_blocks |
| 10.1016/j.jct.2012.03.024 | 1 | 6 | unary | search_blocks |
| 10.1016/j.jct.2013.11.024 | 1 | 4 | unary | search_blocks |
| 10.1016/j.jct.2018.12.036 | 1 | 7 | unary | search_blocks |
| 10.1016/j.tca.2019.01.018 | 1 | 5 | unary | search_blocks |
| 10.1021/je2000183 | 1 | 1 | unary | search_blocks |
| 10.1021/je200349t | 1 | 5 | unary | search_blocks |
| 10.1021/je3000348 | 1 | 9 | unary | search_blocks |
| 10.1021/je800710p | 1 | 10 | unary | search_blocks |
| 10.1021/je900502s | 1 | 1 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2007.10.004 | PROPblock_4 | declared | 20 | unary | — | search_blocks |
| 10.1016/j.fluid.2009.07.010 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2009.09.007 | PROPblock_1 | declared | 15 | unary | — | search_blocks |
| 10.1016/j.jct.2009.09.007 | PROPblock_2 | declared | 15 | unary | — | search_blocks |
| 10.1016/j.jct.2012.03.008 | PROPblock_9 | declared | 6 | unary | — | search_blocks |
| 10.1016/j.jct.2012.03.024 | PROPblock_6 | declared | 6 | unary | — | search_blocks |
| 10.1016/j.jct.2013.11.024 | PROPblock_1 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.jct.2018.12.036 | PROPblock_1 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.tca.2019.01.018 | PROPblock_2 | declared | 5 | unary | — | search_blocks |
| 10.1021/je2000183 | PROPblock_22 | declared | 1 | unary | — | search_blocks |
| 10.1021/je200349t | PROPblock_2 | declared | 5 | unary | — | search_blocks |
| 10.1021/je3000348 | PROPblock_7 | declared | 9 | unary | — | search_blocks |
| 10.1021/je800710p | PROPblock_2 | declared | 10 | unary | — | search_blocks |
| 10.1021/je900502s | PROPblock_5 | declared | 1 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve [C4mim][BF… | 296 | KEEP ←in 293 | 296 | 5.6 |
| 2 | 4 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,129 | KEEP ←in 7,536 | 1114 | 25.9 |
| 3 | 6 | `resolve_ids` | entity_type=variable, limit=5, min_score=50, purpo… | 297 | KEEP ←in 231 | 297 | 5.5 |
| 4 | 7 | `block_search_adv` | compound_match=all, compounds=REQUIRE GLOBcomp_36 … | 1,130 | KEEP ←in 7,730 | 1115 | 21.4 |
| 5 | 9 | `search_blocks` | block_number=GLOBlit_725::PROPblock_4, purpose=Ret… | 627 | KEEP ←in 1,292 | 613 | 7.9 |
| 6 | 9 | `search_blocks` | block_number=GLOBlit_9790::PROPblock_7, purpose=Re… | 583 | KEEP ←in 1,514 | 568 | 6.8 |
| 7 | 9 | `search_blocks` | block_number=GLOBlit_3588::PROPblock_9, purpose=Re… | 762 | KEEP ←in 1,471 | 762 | 8.8 |
| 8 | 10 | `search_blocks` | block_number=GLOBlit_9491::PROPblock_22, purpose=G… | 757 | KEEP ←in 1,310 | 727 | 8.6 |
| 9 | 10 | `search_blocks` | block_number=GLOBlit_6476::PROPblock_2, purpose=Ge… | 686 | KEEP ←in 1,493 | 671 | 7.3 |
| 10 | 10 | `search_blocks` | block_number=GLOBlit_5419::PROPblock_1, purpose=Ge… | 721 | KEEP ←in 1,479 | 706 | 7.2 |
| 11 | 11 | `search_blocks` | block_number=GLOBlit_3156::PROPblock_2, purpose=Ge… | 1,029 | KEEP ←in 1,581 | 1029 | 9.9 |
| 12 | 11 | `search_blocks` | block_number=GLOBlit_9568::PROPblock_2, purpose=Ge… | 833 | KEEP ←in 1,401 | 833 | 8.9 |
| 13 | 11 | `search_blocks` | block_number=GLOBlit_572::PROPblock_4, purpose=Get… | 972 | KEEP ←in 1,550 | 958 | 9.3 |
| 14 | 1 | `L1_query` | context=Surface tension is GLOBprop_1…, id_catalog… | 40,336 | — | — | 295.5 |
| | | **TOTAL (14 tools)** | | **50,158** | | **9,689** | **428.6** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 736 | 10,497 | 1,626 | 11.3 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,338 | 22,756 | 681 | 5.4 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,465 | 23,883 | 697 | 4.4 |
| 4 | L1-worker | claudeopus46 | 3,767 | 504 | 4,271 | 480 | 4.5 |
| 5 | L1-worker | claudeopus46 | 21,418 | 2,302 | 23,720 | 2,022 | 14.5 |
| 6 | L1-worker | claudeopus46 | 21,418 | 3,081 | 24,499 | 688 | 5.0 |
| 7 | L1-worker | claudeopus46 | 3,767 | 8,038 | 11,805 | 1,453 | 13.1 |
| 8 | L1-worker | claudeopus46 | 21,418 | 4,367 | 25,785 | 2,083 | 15.2 |
| 9 | L1-worker | claudeopus46 | 21,418 | 5,168 | 26,586 | 582 | 4.4 |
| 10 | L1-worker | claudeopus46 | 3,767 | 398 | 4,165 | 513 | 4.9 |
| 11 | L1-worker | claudeopus46 | 21,418 | 5,621 | 27,039 | 2,541 | 17.6 |
| 12 | L1-worker | claudeopus46 | 3,767 | 8,024 | 11,791 | 1,682 | 13.8 |
| 13 | L1-worker | claudeopus46 | 21,418 | 7,354 | 28,772 | 2,346 | 14.1 |
| 14 | L1-worker | claudeopus46 | 21,418 | 8,799 | 30,217 | 1,086 | 5.7 |
| 15 | L1-worker | claudeopus46 | 3,767 | 1,655 | 5,422 | 998 | 7.2 |
| 16 | L1-worker | claudeopus46 | 3,767 | 1,878 | 5,645 | 768 | 6.1 |
| 17 | L1-worker | claudeopus46 | 3,767 | 1,835 | 5,602 | 1,073 | 8.6 |
| 18 | L1-worker | claudeopus46 | 21,418 | 10,586 | 32,004 | 1,520 | 9.7 |
| 19 | L1-worker | claudeopus46 | 3,767 | 1,655 | 5,422 | 1,036 | 8.1 |
| 20 | L1-worker | claudeopus46 | 3,767 | 1,840 | 5,607 | 950 | 6.9 |
| 21 | L1-worker | claudeopus46 | 3,767 | 1,826 | 5,593 | 900 | 6.8 |
| 22 | L1-worker | claudeopus46 | 21,418 | 13,473 | 34,891 | 2,033 | 13.3 |
| 23 | L1-worker | claudeopus46 | 3,767 | 1,916 | 5,683 | 1,370 | 9.3 |
| 24 | L1-worker | claudeopus46 | 3,767 | 1,736 | 5,503 | 1,190 | 8.6 |
| 25 | L1-worker | claudeopus46 | 3,767 | 1,884 | 5,651 | 1,322 | 9.1 |
| 26 | L1-worker | claudeopus46 | 21,418 | 17,206 | 38,624 | 4,521 | 30.1 |
| 27 | L1-worker | claudeopus46 | 2,320 | 2,644 | 4,964 | 953 | 4.8 |
| 28 | L1-worker | claudeopus46 | 627 | 2,524 | 3,151 | 843 | 4.8 |
| 29 | L1-worker | claudeopus46 | 2,543 | 4,103 | 6,646 | 3,408 | 12.3 |
| 30 | L1-worker | claudeopus46 | 787 | 42,571 | 43,358 | 533 | 5.6 |
| 31 | L0-main | claudeopus46 | 9,761 | 22,456 | 32,217 | 8,006 | 53.7 |
| 32 | L0-main | claudeopus46 | 2,320 | 4,099 | 6,419 | 1,444 | 7.2 |
| 33 | L0-main | claudeopus46 | 2,543 | 4,667 | 7,210 | 1,738 | 10.6 |
| 34 | L0-main | claudeopus46 | 1,156 | 10,495 | 11,651 | 3,548 | 17.7 |

