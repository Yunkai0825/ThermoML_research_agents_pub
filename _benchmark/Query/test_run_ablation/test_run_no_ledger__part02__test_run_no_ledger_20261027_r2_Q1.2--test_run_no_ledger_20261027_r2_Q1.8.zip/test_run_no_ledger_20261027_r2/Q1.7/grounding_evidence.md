# Data grounding evidence

- generated: 2026-10-27T03:50:53
- grounding profile: current
- gate verdict: 2 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | — | NO | — | — |
| PROPblock_2 | — | NO | — | — |
| PROPblock_22 | — | NO | — | — |
| PROPblock_4 | — | NO | — | — |
| PROPblock_7 | — | NO | — | — |
| PROPblock_9 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 297.0 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.0469 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.0009 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 298.0 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.04544 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.00049 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.04533 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.0003 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.0447 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.0004 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.04452 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.00046 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.0446 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.00084 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.04437 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.00064 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 298.5 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.04441 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.00059 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 298.0 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.0436 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.0013 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 | uninspected_block | — |
| 0.0469 | PROPblock_2 | uninspected_block | — |
| 297.0 | PROPblock_2 | uninspected_block | — |
| 1.6 | PROPblock_2 | uninspected_block | — |
| 3.3 | PROPblock_2 | uninspected_block | — |
| 0.0469 | PROPblock_2 | uninspected_block | — |
| 0.04533 | PROPblock_2 | uninspected_block | — |
| 0.00157 | PROPblock_2 | uninspected_block | — |
| 0.0012 | PROPblock_2 | uninspected_block | — |
| 0.0444 | PROPblock_2 | uninspected_block | — |
| 0.0447 | PROPblock_2 | uninspected_block | — |
| 0.0445 | PROPblock_2 | uninspected_block | — |
| 0.0002 | PROPblock_2 | uninspected_block | — |
| 298.15 | PROPblock_2 | uninspected_block | — |
| 0.0453 | PROPblock_2 | uninspected_block | — |
| 0.0454 | PROPblock_2 | uninspected_block | — |
| 0.00011 | PROPblock_2 | uninspected_block | — |
| 0.00079 | PROPblock_2 | uninspected_block | — |
| 0.04533 | PROPblock_2 | uninspected_block | — |
| 0.04437 | PROPblock_2 | uninspected_block | — |
| 0.00096 | PROPblock_2 | uninspected_block | — |
| 0.00094 | PROPblock_2 | uninspected_block | — |
| 0.0436 | PROPblock_2 | uninspected_block | — |
| 0.0013 | PROPblock_2 | uninspected_block | — |
| 0.0445 | PROPblock_2 | uninspected_block | — |
| 0.0469 | PROPblock_2 | uninspected_block | — |
| 3.3 | PROPblock_2 | uninspected_block | — |
| 0.0436 | PROPblock_2 | uninspected_block | — |
| 0.0469 | PROPblock_2 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2: PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_7 + PROPblock_1 + PROPblock_2 is quoted with data values (297.0, 0.0469, 0.0009, 298.0, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_2: PROPblock_2 is quoted with data values (0.0469, 297.0, 1.6, 3.3, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_