1. Most comprehensive viscositydataset77pts wide293.15-353.15 vs84pts293.15-308.15; metricundefined.

   **Your reply:** Treat as an undefined qualitative ranking outside the score; report both facts
