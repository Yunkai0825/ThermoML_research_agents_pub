1. Approximate peak composition bands: containment of measured coordinate under display bounds versus interval endpoints matching min/max measured peak coordinates. Reviewers used differing interpretations; H12 explicitly addressed property magnitudes.

   **Your reply:** Check peak containment; record actual coordinates

2. How should this unreferenced collective range be treated when the answer specifies neither temperature/frequency nor which solvent supplies each bound?

   **Your reply:** A — Source-trace the collective property summary; record missing original source and state (Recommended)

3. Do these approximate peak intervals assert the lower and upper values of the source datasets' maxima, or a descriptive band around the peaks?

   **Your reply:** A — Compare endpoints with the smallest/largest dataset maxima at the stated temperature(s) (Recommended for the data table)

4. Should generic pure-solvent baselines inherit the preceding mixture-source citations, or be checked as uncited pure-system data?

   **Your reply:** A — Use independent pure-component archive records; retain unknown original attribution (Recommended)
