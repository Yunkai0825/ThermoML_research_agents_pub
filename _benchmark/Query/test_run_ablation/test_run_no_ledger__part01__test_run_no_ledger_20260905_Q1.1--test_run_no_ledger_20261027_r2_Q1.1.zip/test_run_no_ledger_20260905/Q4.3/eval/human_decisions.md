1. Does the final estimate qualification apply to the earlier binary-volume intervals, or only to the later chosen scalar inputs (−0.8,−0.7,−0.2 cm³/mol)?

   **Your reply:** B — Treat the earlier intervals as estimates too; record conflicting wording and missing quantitative provenance (Recommended)
