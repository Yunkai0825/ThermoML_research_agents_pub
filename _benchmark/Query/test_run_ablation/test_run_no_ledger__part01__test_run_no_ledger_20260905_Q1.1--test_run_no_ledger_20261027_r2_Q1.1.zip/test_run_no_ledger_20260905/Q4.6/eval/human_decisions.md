1. D023 line26: often exceeding3–4mPa*s at298K; inspected max3.7353

   **Your reply:** Interpret as above 3 within the 3–4 band

2. Most organic mixtures viscosity enhancement/interior maximum: undefined population, state and low-x interval; counterexamples do not establish majority false.

   **Your reply:** Treat as qualitative; report measured examples and exceptions

3. Class viscosity ranking near 298 K has no fixed composition/comparator; chemical families overlap. The repeated line54 claim also says ACN barely perturbs water viscosity without defining composition or effect-size threshold.

   **Your reply:** Treat the class ranking as unscored; retain evidence gaps and counterexamples

4. Approximate peak composition bands: containment of measured coordinate under display bounds versus interval endpoints matching min/max measured peak coordinates. Reviewers used differing interpretations; H12 explicitly addressed property magnitudes.

   **Your reply:** Check peak containment; record actual coordinates
