1. Ethanol/water source lists288-323K and1.71-29.22kPa, then says near-ambient conditions. Does phrase refer only to temperature or also pressure?

   **Your reply:** Both temperature and pressure; flag the pressure description
