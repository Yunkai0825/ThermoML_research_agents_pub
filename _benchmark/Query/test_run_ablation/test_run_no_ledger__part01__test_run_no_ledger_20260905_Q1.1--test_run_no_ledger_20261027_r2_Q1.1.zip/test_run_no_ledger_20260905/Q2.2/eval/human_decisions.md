1. Typical full binary0-1composition sweeps with11-21points or10-20+points:5555/12384 and5753/12384 across all fixedT/P groups;5555/6713 and5753/6713 among full-endpoint groups.

   **Your reply:** Require a majority of all binary measurement groups
