1. Common properties measured...typically include eight existing water/propan-2-ol categories

   **Your reply:** Check as available categories
