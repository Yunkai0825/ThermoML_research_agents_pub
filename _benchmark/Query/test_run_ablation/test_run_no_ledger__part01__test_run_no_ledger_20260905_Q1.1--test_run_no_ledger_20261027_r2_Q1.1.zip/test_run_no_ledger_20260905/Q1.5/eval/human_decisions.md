1. Majority cluster around1.08-1.09mPa*s at298.15K: literal38/84 vsdisplayprecision52/84 ondiagnostic80-105kPascreen; narrowerpressure screens preserveflip.

   **Your reply:** Use displayed-precision bounds 1.075–1.095

2. Most values cluster near1.08–1.09mPa*s, with a few outliers reaching up to~1.19mPa*s; near-atmospheric pressure but no numeric pressure scope or complete input list.

   **Your reply:** Source-trace the distribution summary

3. Table headed eta at 298.15 K lists falling/rolling sphere ~1.05-1.10 mPa*s at ambient P; preceding prose says expected agreement. Cited block has no 298.15 K point.

   **Your reply:** Check as reported data; retain the missing-state result
