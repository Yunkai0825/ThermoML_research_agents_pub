1. D005 near-room comparison; data-block row288–308K; additional viscosity/density at308.15K

   **Your reply:** Treat 288–308 K as rounded; include 308.15 K

2. Query Q2.1 twice says excess enthalpy and excess volume span x ≈ 0.04–0.95. The cited blocks start at 0.0544 for enthalpy and 0.0417 for volume; the separate property rows correctly distinguish them. Should the joint interval apply to each property separately, or describe the combined range of both datasets?

   **Your reply:** Apply to each property separately; retain the enthalpy lower-end discrepancy
