# Data grounding evidence

- generated: 2026-10-27T03:21:26
- grounding profile: current
- gate verdict: 5 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_13 | — | NO | — | — |
| PROPblock_4 | — | NO | — | — |
| PROPblock_74 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 298.15 | PROPblock_13 | uninspected_block | — |
| 101.0 | PROPblock_13 | uninspected_block | — |
| 0.0035 | PROPblock_13 | uninspected_block | — |
| 1.5095 | PROPblock_13 | uninspected_block | — |
| 0.0035 | PROPblock_13 | uninspected_block | — |
| 0.939 | PROPblock_13 | uninspected_block | — |
| 0.33 | PROPblock_13 | uninspected_block | — |
| 0.742 | PROPblock_13 | uninspected_block | — |
| 1.51 | PROPblock_13 | uninspected_block | — |
| 0.839 | PROPblock_13 | uninspected_block | — |
| 0.33 | PROPblock_13 | uninspected_block | — |
| 0.5 | PROPblock_74 + PROPblock_4 | uninspected_block | — |
| 1.0 | PROPblock_74 + PROPblock_4 | uninspected_block | — |
| 070 | PROPblock_74 + PROPblock_4 | uninspected_block | — |
| 15 | PROPblock_74 + PROPblock_4 | uninspected_block | — |
| 0.9064 | PROPblock_74 + PROPblock_4 | uninspected_block | — |
| 4.6684 | PROPblock_74 + PROPblock_4 | uninspected_block | — |
| 1.55 | PROPblock_4 | uninspected_block | — |
| 4.67 | PROPblock_4 | uninspected_block | — |
| 298.15 | PROPblock_4 | uninspected_block | — |
| 0.0035 | PROPblock_4 | uninspected_block | — |
| 4.67 | PROPblock_4 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_13: PROPblock_13 is quoted with data values (298.15, 101.0, 0.0035, 1.5095, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_13: PROPblock_13 is quoted with data values (0.0035, 0.939, 0.33, 0.742, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_13: PROPblock_13 is quoted with data values (0.33, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_74 + PROPblock_4: PROPblock_74 + PROPblock_4 is quoted with data values (0.5, 1.0, 070, 15, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_4: PROPblock_4 is quoted with data values (1.55, 4.67, 298.15, 0.0035, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_