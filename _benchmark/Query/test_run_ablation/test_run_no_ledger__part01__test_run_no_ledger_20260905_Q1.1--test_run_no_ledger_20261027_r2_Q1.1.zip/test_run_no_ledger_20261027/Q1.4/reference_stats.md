# Reference Stats — query-agent

**Run started:** 2026-10-27 03:18:13
**Wall time (at last flush):** 207.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 25,541 | 28,078 | 20,435 | 53,619 | 10,723 | 106.9 | claudeopus46 |
| L1-worker | 16 | 175,038 | 71,319 | 16,996 | 246,357 | 15,397 | 112.3 | claudeopus46 |
| **TOTAL** | **21** | **200,579** | **99,397** | **37,431** | **299,976** | **14,284** | **219.2** | |

**Estimated tokens:** ~74,994 input + ~9,357 output = ~84,351 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 9 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 2 | 1 | 2 | 3 | 3 | 160 |
| **TOTAL** | **13** | **12** | **1** | **2** | **3** | **3** | **160** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (11 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_107 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_151 |  | resolve_compound_ids |
| GLOBcomp_416 |  | resolve_compound_ids |
| GLOBcomp_476 |  | resolve_compound_ids |
| GLOBcomp_256 |  | resolve_compound_ids |
| GLOBcomp_3148 |  | resolve_compound_ids |
| GLOBcomp_1581 |  | resolve_compound_ids |
| GLOBcomp_58 |  | resolve_compound_ids |
| GLOBcomp_338 |  | resolve_compound_ids |
| GLOBcomp_1104 |  | resolve_compound_ids |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### Properties (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_3 |  | resolve_property_ids |
| GLOBprop_56 |  | resolve_property_ids, search_blocks |
| GLOBprop_73 |  | resolve_property_ids |
| GLOBprop_38 |  | resolve_property_ids, search_blocks |
| GLOBprop_89 |  | resolve_property_ids |
| GLOBprop_94 |  | resolve_property_ids |
| GLOBprop_71 |  | resolve_property_ids |
| GLOBprop_95 |  | resolve_property_ids |
| GLOBprop_33 |  | resolve_property_ids |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_1540 |  | search_blocks |
| GLOBlit_3969 |  | search_blocks |
| GLOBlit_4743 |  | search_blocks |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_185 | Mean ionic activity coefficient | search_blocks |
| GLOBmeas_305 | Osmotic coefficient | search_blocks |
| GLOBmeas_166 | Osmotic coefficient | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Solvents (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_4 | Molality, mol/kg | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 11 |
| Unique Properties | 9 |
| Unique References | 3 |
| Unique Measurements | 3 |
| Unique Phases | 1 |
| Unique Solvents | 1 |
| Unique Variables | 1 |
| Unique Constraints | 2 |
| Total DOIs | 3 |
| Unique parent blocks | 3 |
| Explicit block/subsystem targets | 3 |
| Subsystem targets | 0 |
| Target-matched data points | 160 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 3  |  **Explicit targets:** 3  |  **Subsystems:** 0  |  **Target-matched datapoints:** 160

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2014.08.026 | 1 | 141 | binary | search_blocks |
| 10.1016/j.jct.2013.08.018 | 1 | 4 | binary | search_blocks |
| 10.1016/j.jct.2016.07.003 | 1 | 15 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2014.08.026 | PROPblock_13 | declared | 141 | binary | — | search_blocks |
| 10.1016/j.jct.2013.08.018 | PROPblock_74 | declared | 4 | binary | — | search_blocks |
| 10.1016/j.jct.2016.07.003 | PROPblock_4 | declared | 15 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve global IDs… | 581 | KEEP ←in 935 | 581 | 8.0 |
| 2 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Resolve property I… | 597 | KEEP ←in 965 | 597 | 6.1 |
| 3 | 4 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve water comp… | 132 | KEEP ←in 216 | 132 | 3.4 |
| 4 | 4 | `resolve_property_ids` | limit=10, min_score=50, purpose=Resolve osmotic co… | 222 | KEEP ←in 232 | 222 | 3.5 |
| 5 | 6 | `search_blocks` | compound=['GLOBcomp_107', 'GLOBcomp_1'], limit=50,… | 1,213 | KEEP ←in 5,201 | 1213 | 14.7 |
| 6 | 1 | `L1_query` | instruction=Search for activity coefficie…, purpos… | 22,998 | — | — | 103.7 |
| | | **TOTAL (6 tools)** | | **25,743** | | **2,745** | **139.4** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 579 | 10,340 | 14,674 | 71.1 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,141 | 22,559 | 980 | 5.9 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,681 | 24,099 | 1,034 | 5.8 |
| 4 | L1-worker | claudeopus46 | 3,767 | 1,092 | 4,859 | 919 | 7.5 |
| 5 | L1-worker | claudeopus46 | 3,767 | 1,160 | 4,927 | 913 | 5.9 |
| 6 | L1-worker | claudeopus46 | 21,418 | 3,188 | 24,606 | 832 | 5.3 |
| 7 | L1-worker | claudeopus46 | 21,418 | 4,282 | 25,700 | 746 | 4.7 |
| 8 | L1-worker | claudeopus46 | 3,767 | 345 | 4,112 | 264 | 3.3 |
| 9 | L1-worker | claudeopus46 | 3,767 | 383 | 4,150 | 350 | 3.4 |
| 10 | L1-worker | claudeopus46 | 21,418 | 4,683 | 26,101 | 1,293 | 8.4 |
| 11 | L1-worker | claudeopus46 | 21,418 | 5,513 | 26,931 | 755 | 5.0 |
| 12 | L1-worker | claudeopus46 | 3,767 | 5,802 | 9,569 | 1,484 | 14.0 |
| 13 | L1-worker | claudeopus46 | 21,418 | 6,878 | 28,296 | 3,139 | 17.6 |
| 14 | L1-worker | claudeopus46 | 2,320 | 2,550 | 4,870 | 895 | 5.6 |
| 15 | L1-worker | claudeopus46 | 2,543 | 3,812 | 6,355 | 1,668 | 6.8 |
| 16 | L1-worker | claudeopus46 | 627 | 2,430 | 3,057 | 1,115 | 6.9 |
| 17 | L1-worker | claudeopus46 | 787 | 25,379 | 26,166 | 609 | 6.2 |
| 18 | L0-main | claudeopus46 | 9,761 | 16,713 | 26,474 | 2,628 | 18.4 |
| 19 | L0-main | claudeopus46 | 2,320 | 2,528 | 4,848 | 1,004 | 5.2 |
| 20 | L0-main | claudeopus46 | 2,543 | 2,939 | 5,482 | 949 | 5.6 |
| 21 | L0-main | claudeopus46 | 1,156 | 5,319 | 6,475 | 1,180 | 6.6 |

