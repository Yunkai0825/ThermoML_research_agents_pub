# Q1.4 — Result

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

**[run statistics removed]**

---

## Answer

Yes, activity coefficients have been measured for aqueous lithium chloride (LiCl) near 25 °C (298.15 K), and the ThermoML database contains three relevant data blocks spanning a wide concentration range.

## Mean Ionic Activity Coefficient (γ±)

The most extensive dataset comes from **PROPblock_13** (GLOBlit_1540; DOI 10.1016/j.fluid.2014.08.026), which reports **141 mean ionic activity coefficient values** derived from EMF (electromotive force) cell-potential measurements at 298.15 K and 101.0 kPa. The molality range covered is **0.0035 – 1.5095 mol/kg**.

Representative values illustrate the characteristic behavior of this strongly hydrated electrolyte:

| Molality (mol/kg) | γ± (approx.) |
|---|---|
| 0.0035 | 0.939 |
| 0.33 | 0.742 (minimum) |
| 1.51 | 0.839 |

The activity coefficient first **decreases** from near-unity at infinite dilution to a minimum around 0.33 mol/kg, then **increases** at higher concentrations. This upturn is a hallmark of LiCl: the small, highly charge-dense Li⁺ ion interacts very strongly with water, and at moderate-to-high concentrations ion–ion correlations and hydration effects cause γ± to rise well above the Debye–Hückel limiting-law prediction. Reported uncertainties are approximately ±0.02.

## Osmotic Coefficient (φ) — Complementary Data

Two additional blocks report the closely related **osmotic coefficient**, extending the concentration coverage:

| Block | Literature / DOI | Data Points | Molality Range (mol/kg) | Method |
|---|---|---|---|---|
| PROPblock_74 | GLOBlit_3969 / 10.1016/j.jct.2013.08.018 | 4 | 0.5 – 1.0 | Vapor-pressure osmometry (Gonotec 070) |
| PROPblock_4 | GLOBlit_4743 / 10.1016/j.jct.2016.07.003 | 15 | 0.9064 – 4.6684 | Isopiestic method |

The osmotic coefficient ranges from about 0.93 at 0.5 mol/kg up to roughly 1.55 at 4.67 mol/kg, again reflecting the strong ion–solvent interactions in concentrated LiCl solutions.

## Overall Concentration Coverage

Combining all three datasets, the ThermoML database covers aqueous LiCl at 298.15 K from **0.0035 mol/kg (very dilute) to 4.67 mol/kg (fairly concentrated)**—a span of more than three orders of magnitude in concentration. All activity-coefficient data are reported under the "mean ionic activity coefficient" designation, which is the standard thermodynamic quantity for electrolyte solutions.

### Core claims

- The ThermoML database contains mean ionic activity coefficient (γ±) data for aqueous LiCl at 298.15 K and 101.0 kPa, comprising 141 values from EMF measurements covering a molality range of 0.0035 – 1.5095 mol/kg, with reported uncertainties of approximately ±0.02.
- The mean ionic activity coefficient of aqueous LiCl at 298.15 K first decreases from near-unity at infinite dilution to a minimum around 0.33 mol/kg, then increases at higher concentrations, reflecting the strong hydration of the small, charge-dense Li⁺ ion.
- Two additional ThermoML data blocks report osmotic coefficients for aqueous LiCl at 298.15 K, extending concentration coverage from 0.5 to 4.6684 mol/kg via vapor-pressure osmometry and isopiestic methods.
- Combining all three datasets, the ThermoML database covers aqueous LiCl at 298.15 K from 0.0035 mol/kg to 4.67 mol/kg, spanning more than three orders of magnitude in concentration.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_1540 | 10.1016/j.fluid.2014.08.026 | PROPblock_13 |  | Primary source for the answer: provides 141 mean ionic activity coefficient values for aqueous LiCl at 298.15 K over the molality range 0.0033–1.5555 mol/kg, with γ± spanning 0.7406–0.9425, directly answering the question about activity coefficients. |
| GLOBlit_3969 | 10.1016/j.jct.2013.08.018 | PROPblock_74 |  | Complementary osmotic coefficient data (4 points, 0.5–1.0 mol/kg) for aqueous LiCl at 298.15 K. The osmotic coefficient is thermodynamically related to the activity coefficient and extends the characterization of the system. |
| GLOBlit_4743 | 10.1016/j.jct.2016.07.003 | PROPblock_4 |  | Provides 15 osmotic coefficient values for aqueous LiCl at 298.15 K over 0.9064–4.6684 mol/kg, extending the concentration coverage to higher molalities and complementing the activity coefficient data from the primary block. |

### Suggested follow-ups

- Compare ThermoML activity coefficient data for LiCl with Debye–Hückel or Pitzer model predictions to assess model accuracy across the full concentration range.
- Investigate whether ThermoML contains activity coefficient data for other alkali-metal chlorides (NaCl, KCl, CsCl) at 298.15 K to compare hydration effects across the series.
- Check whether temperature-dependent activity coefficient data exist for aqueous LiCl beyond 298.15 K to study the thermal sensitivity of ion–solvent interactions.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
