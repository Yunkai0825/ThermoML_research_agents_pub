## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |
| GLOBprop_42 | Relative permittivity (various frequencies) | — |
| GLOBprop_44 | Relative permittivity (zero frequency / static dielectric constant) | — |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_36 | 1-butyl-3-methylimidazolium_tetrafluoroborate | 1-butyl-3-methylimidazolium tetrafluoroborate |
| prop | GLOBprop_13 | surface_tension_liquidgas_n_m | Surface tension liquid-gas, N/m |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all surface tension measurements for 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at or near 298.15 → stored as L1_query_1 · validation: PASS
- [L1] Find the remaining 3 surface tension data blocks for [C4mim][BF4] (GLOBcomp_36, GLOBprop_13) not yet recovered. Already  → stored as L1_query_2 · validation: PASS
- [L1] Get the exact surface tension value at or near 298.15 K from GLOBlit_3600/PROPblock_6 for [C4mim][BF4], and attempt to f → stored as L1_query_3 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

Surface tension (liquid–gas, GLOBprop_13) of pure 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4], GLOBcomp_36, CAS 174501-65-6) at ~298.15 K is reported across 14 data blocks from 12 literature sources in ThermoML. All uncertainties are expanded uncertainties at 95% coverage (k = 95%, propagation, compiler-assigned). Reported values at or near 298.15 K span 0.0436–0.0469 N/m, with the majority clustering in 0.0443–0.0453 N/m. Specific values include: 0.0469 ± 0.0009 N/m at 297.0 K (GLOBlit_9491, ring tensiometer), 0.04544 N/m at 298.0 K (GLOBlit_3588), 0.04533 ± 0.0003 N/m at 298.15 K (GLOBlit_725, drop volume), 0.04452 ± 0.00046 N/m at 298.15 K (GLOBlit_5419, plate method), 0.0447 ± 0.0004 N/m at 298.15 K (GLOBlit_9790, maximal bubble pressure), 0.0446 N/m at 298.15 K (GLOBlit_6476), 0.04437 ± 0.00064 N/m at 298.15 K (GLOBlit_9568, ring tensiometer), 0.04441 N/m at 298.5 K (GLOBlit_3156), ~0.0453 N/m at ~298 K (GLOBlit_3156, second block), and 0.0436 ± 0.0013 N/m at 298.0 K (GLOBlit_572, capillary rise). The ~3 mN/m spread across sources reflects differences in measurement technique and ionic liquid purity (water and halide content). Expanded uncertainties range from ±0.0003 to ±0.0013 N/m. Surface tension decreases approximately linearly with temperature across all blocks.

**Answer:**

### Surface Tension of 1-Butyl-3-methylimidazolium Tetrafluoroborate ([C4mim][BF4]) at ~298.15 K

**Compound:** 1-butyl-3-methylimidazolium tetrafluoroborate (GLOBcomp_36, C₈H₁₅BF₄N₂, CAS 174501-65-6)

**Property:** Surface tension, liquid–gas (GLOBprop_13), units: N/m

The ThermoML database contains **14 data blocks across 12 literature sources** reporting surface tension for pure [C4mim][BF4] with temperature ranges overlapping 293–303 K. All uncertainties are expanded uncertainties at 95% coverage (k = 95%, propagation, compiler-assigned). Below are all sources for which detailed block-level data at or near 298.15 K were recovered:

#### Detailed Results (inspected blocks with uncertainties)

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *T (K)* | *γ (N/m)* | *±U (N/m)* | *Method* |
|---|---|---|---|---|---|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「1」 | 「10.1021/je2000183」 | 「GLOBlit_9491」 | 「PROPblock_22」 | 「297.0」 | 「0.0469」 | 「0.0009」 | 「Ring tensiometer (GLOBmeas_19)」 |
| WM_L1_Q1_Table#1_Row#2 | 「2」 | 「10.1016/j.jct.2012.03.008」 | 「GLOBlit_3588」 | 「PROPblock_9」 | 「298.0」 | 「0.04544」 | 「—」 | 「(GLOBmeas_22)」 |
| WM_L1_Q1_Table#1_Row#3 | 「3」 | 「10.1016/j.fluid.2009.07.010」 | 「GLOBlit_725」 | 「PROPblock_4」 | 「298.15」 | 「0.04533」 | 「0.0003」 | 「Drop volume (GLOBmeas_32)」 |
| WM_L1_Q1_Table#1_Row#4 | 「4」 | 「10.1016/j.jct.2018.12.036」 | 「GLOBlit_5419」 | 「PROPblock_1」 | 「298.15」 | 「0.04452」 | 「0.00046」 | 「Plate method (GLOBmeas_312)」 |
| WM_L1_Q1_Table#1_Row#5 | 「5」 | 「10.1021/je3000348」 | 「GLOBlit_9790」 | 「PROPblock_7」 | 「298.15」 | 「0.0447」 | 「0.0004」 | 「Maximal bubble pressure (GLOBmeas_36)」 |
| WM_L1_Q1_Table#1_Row#6 | 「6」 | 「10.1016/j.tca.2019.01.018」 | 「GLOBlit_6476」 | 「PROPblock_2」 | 「298.15」 | 「0.0446」 | 「—」 | 「—」 |
| WM_L1_Q1_Table#1_Row#7 | 「7」 | 「10.1021/je200349t」 | 「GLOBlit_9568」 | 「PROPblock_2」 | 「298.15」 | 「0.04437」 | 「0.00064」 | 「Ring tensiometer (GLOBmeas_19)」 |
| WM_L1_Q1_Table#1_Row#8 | 「8」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_2」 | 「298.5」 | 「0.04441」 | 「—」 | 「(GLOBmeas_19)」 |
| WM_L1_Q1_Table#1_Row#9 | 「9」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_1」 | 「~298」 | 「~0.0453」 | 「—」 | 「(GLOBmeas_192)」 |
| WM_L1_Q1_Table#1_Row#10 | 「10」 | 「10.1016/j.fluid.2007.10.004」 | 「GLOBlit_572」 | 「PROPblock_4」 | 「298.0」 | 「0.0436」 | 「0.0013」 | 「Capillary rise (GLOBmeas_58)」 |

#### Additional blocks identified but not individually inspected

The initial search returned 14 blocks total. The remaining 4 blocks (from the truncated portion of the initial listing) belong to these additional literature sources:

**WM_L1_Q1_Table#2_(Query_L1_Q1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* |
|---|---|---|---|---|
| WM_L1_Q1_Table#2_Row#1 | 「11」 | 「10.1016/j.jct.2012.03.024」 | 「GLOBlit_3600」 | 「PROPblock_6」 |
| WM_L1_Q1_Table#2_Row#2 | 「12–14」 | 「(truncated in search output — 3 additional blocks from distinct DOIs)」 | 「—」 | 「—」 |

All 14 blocks report k = 95% expanded uncertainties (propagation, compiler-assigned).

#### Chemistry Insight

The measured surface tension values for pure [C4mim][BF4] at 298.15 K cluster in the range **0.0436–0.0469 N/m** (43.6–46.9 mN/m). The spread of ~3 mN/m across sources reflects differences in measurement technique (ring tensiometer, drop volume, capillary rise, maximal bubble pressure, plate method) and likely variations in ionic liquid purity (water content, halide impurities). The majority of values fall in the narrower range of 0.0443–0.0453 N/m. Expanded uncertainties (k = 95%) range from ±0.0003 to ±0.0013 N/m, with the capillary rise measurement (GLOBlit_572) showing the largest uncertainty and the drop volume method (GLOBlit_725) the smallest.

Surface tension decreases approximately linearly with temperature across all blocks (typical R² > 0.99), consistent with the expected behavior for ionic liquids where thermal expansion weakens cohesive interactions at the liquid–gas interface.

**Core claims:**
- The ThermoML database contains 14 data blocks across 12 literature sources reporting surface tension for pure 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at or near 298.15 K.
- Measured surface tension values at 298.15 K cluster in the range 0.0436–0.0469 N/m (43.6–46.9 mN/m), with the majority falling in the narrower range of 0.0443–0.0453 N/m.
- The spread of ~3 mN/m across sources reflects differences in measurement technique (ring tensiometer, drop volume, capillary rise, maximal bubble pressure, plate method) and likely variations in ionic liquid purity (water content, halide impurities).
- Expanded uncertainties (k = 95%, propagation, compiler-assigned) range from ±0.0003 to ±0.0013 N/m, with the capillary rise measurement showing the largest uncertainty and the drop volume method the smallest.
- Surface tension decreases approximately linearly with temperature across all blocks, consistent with expected behavior for ionic liquids where thermal expansion weakens cohesive interactions at the liquid–gas interface.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#3 | 「GLOBlit_9491」 | 「PROPblock_22」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at 297.0 K measured by ring tensiometer (GLOBmeas_19), value 0.0469 N/m with expanded uncertainty ±0.0009 N/m.」 |
| WM_L1_Q1_Table#4 | 「GLOBlit_3588」 | 「PROPblock_9」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at 298.0 K, value 0.04544 N/m, measurement method GLOBmeas_22.」 |
| WM_L1_Q1_Table#5 | 「GLOBlit_725」 | 「PROPblock_4」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at 298.15 K measured by drop volume method (GLOBmeas_32), value 0.04533 N/m with expanded uncertainty ±0.0003 N/m.」 |
| WM_L1_Q1_Table#6 | 「GLOBlit_5419」 | 「PROPblock_1」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at 298.15 K measured by plate method (GLOBmeas_312), value 0.04452 N/m with expanded uncertainty ±0.00046 N/m.」 |
| WM_L1_Q1_Table#7 | 「GLOBlit_9790」 | 「PROPblock_7」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at 298.15 K measured by maximal bubble pressure (GLOBmeas_36), value 0.0447 N/m with expanded uncertainty ±0.0004 N/m.」 |
| WM_L1_Q1_Table#8 | 「GLOBlit_6476」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at 298.15 K, value 0.0446 N/m.」 |
| WM_L1_Q1_Table#9 | 「GLOBlit_9568」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at 298.15 K measured by ring tensiometer (GLOBmeas_19), value 0.04437 N/m with expanded uncertainty ±0.00064 N/m.」 |
| WM_L1_Q1_Table#10 | 「GLOBlit_3156」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at 298.5 K measured by ring tensiometer (GLOBmeas_19), value 0.04441 N/m.」 |
| WM_L1_Q1_Table#11 | 「GLOBlit_3156」 | 「PROPblock_1」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at ~298 K, value ~0.0453 N/m, measurement method GLOBmeas_192.」 |
| WM_L1_Q1_Table#12 | 「GLOBlit_572」 | 「PROPblock_4」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] at 298.0 K measured by capillary rise (GLOBmeas_58), value 0.0436 N/m with expanded uncertainty ±0.0013 N/m.」 |
| WM_L1_Q1_Table#13 | 「GLOBlit_3600」 | 「PROPblock_6」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] identified in search results but not individually inspected for detailed values.」 |

*Not stored here: 2 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.
### L1_query_2
**L1_query_2** — status: partial · validation: PASS

**Summary:**

From 14 total surface tension data blocks for pure 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) in ThermoML, 12 were identified. The newly found block (GLOBlit_4058, DOI 10.1016/j.jct.2013.11.024, Wilhelmy plate method) reports 4 data points from 293.2–323.2 K with ±0.001 N/m uncertainty: 0.0448 N/m at 293.2 K, 0.0441 at 303.2 K, 0.0435 at 313.2 K, and 0.0426 at 323.2 K. Surface tension decreases near-linearly with temperature (slope approximately −7.3 × 10⁻⁵ N/(m·K)). The interpolated value at 298.15 K is ~0.0445 N/m, consistent with the cluster of values (0.0443–0.0453 N/m) from other sources. Across the 12 recovered blocks, values near 298.15 K range from 0.0436 to 0.0469 N/m, measured by capillary rise, drop volume, ring tensiometer, plate method, and maximal bubble pressure techniques. Two blocks remain unidentified due to search result truncation.

**Answer:**

##### Remaining Surface Tension Data Blocks for [C4mim][BF4]

From the 14 total surface tension (GLOBprop_13) blocks for pure 1-butyl-3-methylimidazolium tetrafluoroborate (GLOBcomp_36), one additional block was successfully identified and inspected beyond the 11 previously recovered:

###### Newly Found Block

**GLOBlit_4058 :: PROPblock_1**
- **DOI:** 10.1016/j.jct.2013.11.024
- **Method:** Wilhelmy plate (GLOBmeas_1015)
- **Data points:** 4 (293.2–323.2 K)
- **Uncertainty:** ±0.001 N/m (k = 95%, propagation, compiler-assigned)
- **Phases:** Liquid; Air at 1 atmosphere

**WM_L1_Q2_Table#1_(Query_L1_Q2_Answer):**

| *row_id* | *T (K)* | *γ (N/m)* | *±U (N/m)* |
|---|---|---|---|
| WM_L1_Q2_Table#1_Row#1 | 「293.2」 | 「0.0448」 | 「0.001」 |
| WM_L1_Q2_Table#1_Row#2 | 「303.2」 | 「0.0441」 | 「0.001」 |
| WM_L1_Q2_Table#1_Row#3 | 「313.2」 | 「0.0435」 | 「0.001」 |
| WM_L1_Q2_Table#1_Row#4 | 「323.2」 | 「0.0426」 | 「0.001」 |

The value nearest 298.15 K is **0.0448 N/m at 293.2 K** (or interpolated ~0.0445 N/m at 298.15 K), consistent with the cluster of values (0.0443–0.0453 N/m) from other sources. Surface tension decreases near-linearly with temperature (R² = 0.9931), with a slope of approximately −7.3 × 10⁻⁵ N/(m·K).

###### Remaining 2 Blocks

The search results consistently truncated at 8 entries (sorted by GLOBlit number ascending), preventing retrieval of the last 2 blocks from the 14-block total. The first 8 entries always covered GLOBlit_572 through GLOBlit_5419. The previously known blocks GLOBlit_6476, GLOBlit_9491, GLOBlit_9568, and GLOBlit_9790 (4 blocks) were recovered in earlier work, meaning 2 blocks remain unidentified from the truncated tail of the search results. These could not be individually inspected within the available search budget.

###### Updated Complete Inventory (12 of 14 blocks)

**WM_L1_Q2_Table#2_(Query_L1_Q2_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *T nearest 298.15 K* | *γ (N/m)* | *±U (N/m)* | *Method* |
|---|---|---|---|---|---|---|---|---|
| WM_L1_Q2_Table#2_Row#1 | 「1」 | 「10.1021/je2000183」 | 「GLOBlit_9491」 | 「PROPblock_22」 | 「297.0」 | 「0.0469」 | 「0.0009」 | 「Ring tensiometer」 |
| WM_L1_Q2_Table#2_Row#2 | 「2」 | 「10.1016/j.jct.2012.03.008」 | 「GLOBlit_3588」 | 「PROPblock_9」 | 「298.0」 | 「0.04544」 | 「—」 | 「—」 |
| WM_L1_Q2_Table#2_Row#3 | 「3」 | 「10.1016/j.fluid.2009.07.010」 | 「GLOBlit_725」 | 「PROPblock_4」 | 「298.15」 | 「0.04533」 | 「0.0003」 | 「Drop volume」 |
| WM_L1_Q2_Table#2_Row#4 | 「4」 | 「10.1016/j.jct.2018.12.036」 | 「GLOBlit_5419」 | 「PROPblock_1」 | 「298.15」 | 「0.04452」 | 「0.00046」 | 「Plate method」 |
| WM_L1_Q2_Table#2_Row#5 | 「5」 | 「10.1021/je3000348」 | 「GLOBlit_9790」 | 「PROPblock_7」 | 「298.15」 | 「0.0447」 | 「0.0004」 | 「Maximal bubble pressure」 |
| WM_L1_Q2_Table#2_Row#6 | 「6」 | 「10.1016/j.tca.2019.01.018」 | 「GLOBlit_6476」 | 「PROPblock_2」 | 「298.15」 | 「0.0446」 | 「—」 | 「—」 |
| WM_L1_Q2_Table#2_Row#7 | 「7」 | 「10.1021/je200349t」 | 「GLOBlit_9568」 | 「PROPblock_2」 | 「298.15」 | 「0.04437」 | 「0.00064」 | 「Ring tensiometer」 |
| WM_L1_Q2_Table#2_Row#8 | 「8」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_2」 | 「298.5」 | 「0.04441」 | 「—」 | 「Ring tensiometer」 |
| WM_L1_Q2_Table#2_Row#9 | 「9」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_1」 | 「~298」 | 「~0.0453」 | 「—」 | 「—」 |
| WM_L1_Q2_Table#2_Row#10 | 「10」 | 「10.1016/j.fluid.2007.10.004」 | 「GLOBlit_572」 | 「PROPblock_4」 | 「298.0」 | 「0.0436」 | 「0.0013」 | 「Capillary rise」 |
| WM_L1_Q2_Table#2_Row#11 | 「11」 | 「10.1016/j.jct.2012.03.024」 | 「GLOBlit_3600」 | 「PROPblock_6」 | 「~298」 | 「(not inspected)」 | 「—」 | 「—」 |
| WM_L1_Q2_Table#2_Row#12 | 「12」 | 「10.1016/j.jct.2013.11.024」 | 「GLOBlit_4058」 | 「PROPblock_1」 | 「293.2」 | 「0.0448」 | 「0.001」 | 「Wilhelmy plate」 |

Two additional blocks (entries 13–14 of 14) could not be retrieved due to search result truncation.

**Core claims:**
- 12 of 14 ThermoML surface tension data blocks for pure [C4mim][BF4] have been identified and inventoried; the remaining 2 blocks could not be retrieved due to search result truncation.
- The newly found block (GLOBlit_4058, DOI 10.1016/j.jct.2013.11.024) reports surface tension via Wilhelmy plate at 293.2–323.2 K with ±0.001 N/m uncertainty, giving 0.0448 N/m at 293.2 K and an interpolated value of ~0.0445 N/m at 298.15 K.
- Across the 12 recovered blocks, surface tension values near 298.15 K cluster in the range 0.0436–0.0469 N/m, with most values falling between 0.0443 and 0.0453 N/m.
- In the GLOBlit_4058 block, surface tension decreases near-linearly with temperature (R² = 0.9931) with a slope of approximately −7.3 × 10⁻⁵ N/(m·K).

**Core blocks found:**

**WM_L1_Q2_Blocks_(Query_L1_Q2_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q2_Table#3 | 「GLOBlit_4058」 | 「PROPblock_1」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension data for pure [C4mim][BF4] measured by Wilhelmy plate method at 293.2–323.2 K with expanded uncertainty ±0.001 N/m; nearest value to 298.15 K is 0.0448 N/m at 293.2 K.」 |

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.
### L1_query_3
**L1_query_3** — status: partial · validation: PASS

**Summary:**

Surface tension data for pure [C4mim][BF4] from GLOBlit_3600/PROPblock_6 (DOI 10.1016/j.jct.2012.03.024) contains 6 data points measured by ring tensiometer over 283.15–333.15 K with no exact 298.15 K point; linear interpolation of the bracketing values at 293.15 K (0.04461 N/m, ±0.00064 N/m) and 303.15 K (0.04379 N/m, ±0.00063 N/m) gives an estimated surface tension at 298.15 K of ~0.04420 N/m. A newly identified block, GLOBlit_11369/PROPblock_2 (DOI 10.1021/je800710p), contains 10 data points by ring tensiometer over 293.65–360.95 K; interpolation of bracketing values at 293.65 K (0.0446 N/m, ±0.0013 N/m) and 303.35 K (0.0438 N/m, ±0.0013 N/m) yields ~0.04423 N/m at 298.15 K. Both interpolated values are consistent, falling at the lower end of the 0.0443–0.0453 N/m cluster from other sources. In total, 13 of 14 surface tension blocks for pure [C4mim][BF4] were identified across 12 distinct literature sources; the 14th block could not be retrieved. The 13 recovered values near 298.15 K span 0.0436–0.0469 N/m, with the majority clustering in 0.0442–0.0453 N/m.

**Answer:**

##### Surface Tension Data for GLOBlit_3600/PROPblock_6 and Newly Identified Blocks

###### GLOBlit_3600 / PROPblock_6 (DOI: 10.1016/j.jct.2012.03.024)

This block contains 6 surface tension data points for pure [C4mim][BF4] (GLOBcomp_36) measured by ring tensiometer (GLOBmeas_19) over 283.15–333.15 K. There is **no exact data point at 298.15 K**; the two nearest bracketing values are:

**WM_L1_Q3_Table#1_(Query_L1_Q3_Answer):**

| *row_id* | *T (K)* | *γ (N/m)* | *±U (N/m)* |
|---|---|---|---|
| WM_L1_Q3_Table#1_Row#1 | 「293.15」 | 「0.04461」 | 「0.00064」 |
| WM_L1_Q3_Table#1_Row#2 | 「303.15」 | 「0.04379」 | 「0.00063」 |

Uncertainties are expanded (k = 95%, propagation, compiler-assigned). By linear interpolation, the estimated surface tension at 298.15 K is **~0.04420 N/m**.

###### Newly Found Block: GLOBlit_11369 / PROPblock_2 (DOI: 10.1021/je800710p)

This previously unidentified block contains 10 surface tension data points for pure [C4mim][BF4] measured by ring tensiometer (GLOBmeas_19) over 293.65–360.95 K. Again, no exact 298.15 K point exists; the nearest bracketing values are:

**WM_L1_Q3_Table#2_(Query_L1_Q3_Answer):**

| *row_id* | *T (K)* | *γ (N/m)* | *±U (N/m)* |
|---|---|---|---|
| WM_L1_Q3_Table#2_Row#1 | 「293.65」 | 「0.0446」 | 「0.0013」 |
| WM_L1_Q3_Table#2_Row#2 | 「303.35」 | 「0.0438」 | 「0.0013」 |

Uncertainties are expanded (k = 95%, propagation, compiler-assigned). By linear interpolation, the estimated surface tension at 298.15 K is **~0.04423 N/m**.

Both interpolated values (~0.04420 and ~0.04423 N/m) are consistent with the cluster of values (0.0443–0.0453 N/m) from other sources, falling at the lower end of that range.

###### Status of the 14th Block

13 of 14 total surface tension blocks for pure [C4mim][BF4] have now been identified. The 14th block could not be retrieved due to persistent truncation in search results. The 13 identified blocks span 12 distinct literature sources (GLOBlit_3156 contributes two blocks).

###### Complete Updated Inventory (13 of 14 blocks)

**WM_L1_Q3_Table#3_(Query_L1_Q3_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *T nearest 298.15 K* | *γ (N/m)* | *±U (N/m)* | *Method* |
|---|---|---|---|---|---|---|---|---|
| WM_L1_Q3_Table#3_Row#1 | 「1」 | 「10.1021/je2000183」 | 「GLOBlit_9491」 | 「PROPblock_22」 | 「297.0」 | 「0.0469」 | 「0.0009」 | 「Ring tensiometer」 |
| WM_L1_Q3_Table#3_Row#2 | 「2」 | 「10.1016/j.jct.2012.03.008」 | 「GLOBlit_3588」 | 「PROPblock_9」 | 「298.0」 | 「0.04544」 | 「—」 | 「—」 |
| WM_L1_Q3_Table#3_Row#3 | 「3」 | 「10.1016/j.fluid.2009.07.010」 | 「GLOBlit_725」 | 「PROPblock_4」 | 「298.15」 | 「0.04533」 | 「0.0003」 | 「Drop volume」 |
| WM_L1_Q3_Table#3_Row#4 | 「4」 | 「10.1016/j.jct.2018.12.036」 | 「GLOBlit_5419」 | 「PROPblock_1」 | 「298.15」 | 「0.04452」 | 「0.00046」 | 「Plate method」 |
| WM_L1_Q3_Table#3_Row#5 | 「5」 | 「10.1021/je3000348」 | 「GLOBlit_9790」 | 「PROPblock_7」 | 「298.15」 | 「0.0447」 | 「0.0004」 | 「Maximal bubble pressure」 |
| WM_L1_Q3_Table#3_Row#6 | 「6」 | 「10.1016/j.tca.2019.01.018」 | 「GLOBlit_6476」 | 「PROPblock_2」 | 「298.15」 | 「0.0446」 | 「—」 | 「—」 |
| WM_L1_Q3_Table#3_Row#7 | 「7」 | 「10.1021/je200349t」 | 「GLOBlit_9568」 | 「PROPblock_2」 | 「298.15」 | 「0.04437」 | 「0.00064」 | 「Ring tensiometer」 |
| WM_L1_Q3_Table#3_Row#8 | 「8」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_2」 | 「298.5」 | 「0.04441」 | 「—」 | 「Ring tensiometer」 |
| WM_L1_Q3_Table#3_Row#9 | 「9」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_1」 | 「~298」 | 「~0.0453」 | 「—」 | 「—」 |
| WM_L1_Q3_Table#3_Row#10 | 「10」 | 「10.1016/j.fluid.2007.10.004」 | 「GLOBlit_572」 | 「PROPblock_4」 | 「298.0」 | 「0.0436」 | 「0.0013」 | 「Capillary rise」 |
| WM_L1_Q3_Table#3_Row#11 | 「11」 | 「10.1016/j.jct.2012.03.024」 | 「GLOBlit_3600」 | 「PROPblock_6」 | 「~298.15 (interp.)」 | 「~0.04420」 | 「0.00064」 | 「Ring tensiometer」 |
| WM_L1_Q3_Table#3_Row#12 | 「12」 | 「10.1016/j.jct.2013.11.024」 | 「GLOBlit_4058」 | 「PROPblock_1」 | 「293.2」 | 「0.0448」 | 「0.001」 | 「Wilhelmy plate」 |
| WM_L1_Q3_Table#3_Row#13 | 「13」 | 「10.1021/je800710p」 | 「GLOBlit_11369」 | 「PROPblock_2」 | 「~298.15 (interp.)」 | 「~0.04423」 | 「0.0013」 | 「Ring tensiometer」 |
| WM_L1_Q3_Table#3_Row#14 | 「14」 | 「(not retrieved)」 | 「—」 | 「—」 | 「—」 | 「—」 | 「—」 | 「—」 |

The 13 recovered values near 298.15 K span **0.0436–0.0469 N/m** (43.6–46.9 mN/m), with the majority clustering in the narrower range of 0.0442–0.0453 N/m.

**Core claims:**
- GLOBlit_3600/PROPblock_6 contains 6 surface tension data points for pure [C4mim][BF4] over 283.15–333.15 K with no exact 298.15 K point; the two nearest bracketing values are 0.04461 N/m at 293.15 K and 0.04379 N/m at 303.15 K, yielding an interpolated estimate of ~0.04420 N/m at 298.15 K.
- A newly identified block GLOBlit_11369/PROPblock_2 (DOI: 10.1021/je800710p) contains 10 surface tension data points for pure [C4mim][BF4] over 293.65–360.95 K; bracketing values of 0.0446 N/m at 293.65 K and 0.0438 N/m at 303.35 K yield an interpolated estimate of ~0.04423 N/m at 298.15 K.
- 13 of 14 total surface tension blocks for pure [C4mim][BF4] have been identified across 12 distinct literature sources; the 14th block could not be retrieved.
- The 13 recovered surface tension values near 298.15 K span 0.0436–0.0469 N/m, with the majority clustering in the narrower range of 0.0442–0.0453 N/m.

**Core blocks found:**

**WM_L1_Q3_Blocks_(Query_L1_Q3_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q3_Table#4 | 「GLOBlit_3600」 | 「PROPblock_6」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Surface tension of pure [C4mim][BF4] measured by ring tensiometer over 283.15–333.15 K; bracketing values at 293.15 K (0.04461 N/m) and 303.15 K (0.04379 N/m) used to interpolate ~0.04420 N/m at 298.15 K.」 |
| WM_L1_Q3_Table#5 | 「GLOBlit_11369」 | 「PROPblock_2」 | 「GLOBcomp_36」 | 「GLOBprop_13」 | 「Newly identified surface tension block for pure [C4mim][BF4] measured by ring tensiometer over 293.65–360.95 K with 10 data points; interpolated value ~0.04423 N/m at 298.15 K.」 |

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.



</memory>

## User
Using ThermoML, report the surface tension of 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at or near 298.15 K from every source, each with its reported expanded uncertainty and block identifier, and say whether the sources agree within those uncertainties.

## Assistant
<summary>Dispatching L1 query to find surface tension (GLOBprop_13) data for 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at ~298.15 K from all available sources, including uncertainties and block IDs.</summary>
<tool_call>L1_query(instruction=First, resolve th…)</tool_call>

## User
<tool_result>
<subagent_answer>
### L1#1 — L1_query return

**Status:** status=success

**Summary:**

Surface tension (liquid–gas, GLOBprop_13) of pure 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4], GLOBcomp_36, CAS 174501-65-6) at ~298.15 K is reported across 14 data blocks from 12 literature sources in ThermoML. All uncertainties are expanded uncertainties at 95% coverage (k = 95%, propagation, compiler-assigned). Reported values at or near 298.15 K span 0.0436–0.0469 N/m, with the majority clustering in 0.0443–0.0453 N/m. Specific values include: 0.0469 ± 0.0009 N/m at 297.0 K (GLOBlit_9491, ring tensiometer), 0.04544 N/m at 298.0 K (GLOBlit_3588), 0.04533 ± 0.0003 N/m at 298.15 K (GLOBlit_725, drop volume), 0.04452 ± 0.00046 N/m at 298.15 K (GLOBlit_5419, plate method), 0.0447 ± 0.0004 N/m at 298.15 K (GLOBlit_9790, maximal bubble pressure), 0.0446 N/m at 298.15 K (GLOBlit_6476), 0.04437 ± 0.00064 N/m at 298.15 K (GLOBlit_9568, ring tensiometer), 0.04441 N/m at 298.5 K (GLOBlit_3156), ~0.0453 N/m at ~298 K (GLOBlit_3156, second block), and 0.0436 ± 0.0013 N/m at 298.0 K (GLOBlit_572, capillary rise). The ~3 mN/m spread across sources reflects differences in measurement technique and ionic liquid purity (water and halide content). Expanded uncertainties range from ±0.0003 to ±0.0013 N/m. Surface tension decreases approximately linearly with temperature across all blocks.

**Answer:**

### Surface Tension of 1-Butyl-3-methylimidazolium Tetrafluoroborate ([C4mim][BF4]) at ~298.15 K

**Compound:** 1-butyl-3-methylimidazolium tetrafluoroborate (GLOBcomp_36, C₈H₁₅BF₄N₂, CAS 174501-65-6)

**Property:** Surface tension, liquid–gas (GLOBprop_13), units: N/m

The ThermoML database contains **14 data blocks across 12 literature sources** reporting surface tension for pure [C4mim][BF4] with temperature ranges overlapping 293–303 K. All uncertainties are expanded uncertainties at 95% coverage (k = 95%, propagation, compiler-assigned). Below are all sources for which detailed block-level data at or near 298.15 K were recovered:

#### Detailed Results (inspected blocks with uncertainties)

**L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *T (K)* | *γ (N/m)* | *±U (N/m)* | *Method* |
|---|---|---|---|---|---|---|---|---|
| L1#1_Table#1_Row#1 | 「1」 | 「10.1021/je2000183」 | 「GLOBlit_9491」 | 「PROPblock_22」 | 「297.0」 | 「0.0469」 | 「0.0009」 | 「Ring tensiometer (GLOBmeas_19)」 |
| L1#1_Table#1_Row#2 | 「2」 | 「10.1016/j.jct.2012.03.008」 | 「GLOBlit_3588」 | 「PROPblock_9」 | 「298.0」 | 「0.04544」 | 「—」 | 「(GLOBmeas_22)」 |
| L1#1_Table#1_Row#3 | 「3」 | 「10.1016/j.fluid.2009.07.010」 | 「GLOBlit_725」 | 「PROPblock_4」 | 「298.15」 | 「0.04533」 | 「0.0003」 | 「Drop volume (GLOBmeas_32)」 |
| L1#1_Table#1_Row#4 | 「4」 | 「10.1016/j.jct.2018.12.036」 | 「GLOBlit_5419」 | 「PROPblock_1」 | 「298.15」 | 「0.04452」 | 「0.00046」 | 「Plate method (GLOBmeas_312)」 |
| L1#1_Table#1_Row#5 | 「5」 | 「10.1021/je3000348」 | 「GLOBlit_9790」 | 「PROPblock_7」 | 「298.15」 | 「0.0447」 | 「0.0004」 | 「Maximal bubble pressure (GLOBmeas_36)」 |
| L1#1_Table#1_Row#6 | 「6」 | 「10.1016/j.tca.2019.01.018」 | 「GLOBlit_6476」 | 「PROPblock_2」 | 「298.15」 | 「0.0446」 | 「—」 | 「—」 |
| L1#1_Table#1_Row#7 | 「7」 | 「10.1021/je200349t」 | 「GLOBlit_9568」 | 「PROPblock_2」 | 「298.15」 | 「0.04437」 | 「0.00064」 | 「Ring tensiometer (GLOBmeas_19)」 |
| L1#1_Table#1_Row#8 | 「8」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_2」 | 「298.5」 | 「0.04441」 | 「—」 | 「(GLOBmeas_19)」 |
| L1#1_Table#1_Row#9 | 「9」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_1」 | 「~298」 | 「~0.0453」 | 「—」 | 「(GLOBmeas_192)」 |
| L1#1_Table#1_Row#10 | 「10」 | 「10.1016/j.fluid.2007.10.004」 | 「GLOBlit_572」 | 「PROPblock_4」 | 「298.0」 | 「0.0436」 | 「0.0013」 | 「Capillary rise (GLOBmeas_58)」 |

#### Additional blocks identified but not individually inspected

The initial search returned 14 blocks total. The remaining 4 blocks (from the truncated portion of the initial listing) belong to these additional literature sources:

**L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* |
|---|---|---|---|---|
| L1#1_Table#2_Row#1 | 「11」 | 「10.1016/j.jct.2012.03.024」 | 「GLOBlit_3600」 | 「PROPblock_6」 |
| L1#1_Table#2_Row#2 | 「12–14」 | 「(truncated in search output — 3 additional blocks from distinct DOIs)」 | 「—」 | 「—」 |

All 14 blocks report k = 95% expanded uncertainties (propagation, compiler-assigned).

#### Chemistry Insight

The measured surface tension values for pure [C4mim][BF4] at 298.15 K cluster in the range **0.0436–0.0469 N/m** (43.6–46.9 mN/m). The spread of ~3 mN/m across sources reflects differences in measurement technique (ring tensiometer, drop volume, capillary rise, maximal bubble pressure, plate method) and likely variations in ionic liquid purity (water content, halide impurities). The majority of values fall in the narrower range of 0.0443–0.0453 N/m. Expanded uncertainties (k = 95%) range from ±0.0003 to ±0.0013 N/m, with the capillary rise measurement (GLOBlit_572) showing the largest uncertainty and the drop volume method (GLOBlit_725) the smallest.

Surface tension decreases approximately linearly with temperature across all blocks (typical R² > 0.99), consistent with the expected behavior for ionic liquids where thermal expansion weakens cohesive interactions at the liquid–gas interface.

**Core claims:**
- The ThermoML database contains 14 data blocks across 12 literature sources reporting surface tension for pure 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at or near 298.15 K.
- Measured surface tension values at 298.15 K cluster in the range 0.0436–0.0469 N/m (43.6–46.9 mN/m), with the majority falling in the narrower range of 0.0443–0.0453 N/m.
- The spread of ~3 mN/m across sources reflects differences in measurement technique (ring tensiometer, drop volume, capillary rise, maximal bubble pressure, plate method) and likely variations in ionic liquid purity (water content, halide impurities).
- Expanded uncertainties (k = 95%, propagation, compiler-assigned) range from ±0.0003 to ±0.0013 N/m, with the capillary rise measurement showing the largest uncertainty and the drop volume method the smallest.
- Surface tension decreases approximately linearly with temperature across all blocks, consistent with expected behavior for ionic liquids where thermal expansion weakens cohesive interactions at the liquid–gas interface.

**Core ID updates:**
- add GLOBcomp_36 — 1-butyl-3-methylimidazolium tetrafluoroborate (registry: 1-butyl-3-methylimidazolium_tetrafluoroborate)
- add GLOBprop_13 — Surface tension liquid-gas, N/m (registry: surface_tension_liquidgas_n_m)

#### Core blocks found — verbatim ledger

```ledger
**L1#1_Table#3_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_9491 | lit_id: 2011-shi-man-0 | doi: 10.1021/je2000183
block: PROPblock_22 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_7; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at 297.0 K measured by ring tensiometer (GLOBmeas_19), value 0.0469 N/m with expanded uncertainty ±0.0009 N/m.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#3_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=297.0–297.0 · n_unique=1 · phase=Liquid」 |
| L1#1_Table#3_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Ring tensiometer (GLOBmeas_19) · range=0.0469–0.0469 · mean=0.0469 · n=1 · phase=Liquid」 |
```

```ledger
**L1#1_Table#4_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_3588 | lit_id: 2012-alm-tel-0 | doi: 10.1016/j.jct.2012.03.008
block: PROPblock_9 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 6
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_9; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at 298.0 K, value 0.04544 N/m, measurement method GLOBmeas_22.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#4_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.0–343.1 · n_unique=6 · phase=Liquid」 |
| L1#1_Table#4_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Pendant drop shape (GLOBmeas_22) · range=0.04217–0.04544 · mean=0.043622 · n=6 · phase=Liquid」 |
```

```ledger
**L1#1_Table#5_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_725 | lit_id: 2009-ril-pic-0 | doi: 10.1016/j.fluid.2009.07.010
block: PROPblock_4 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_2; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at 298.15 K measured by drop volume method (GLOBmeas_32), value 0.04533 N/m with expanded uncertainty ±0.0003 N/m.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#5_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.15–298.15 · n_unique=1 · phase=Liquid」 |
| L1#1_Table#5_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Drop volume (GLOBmeas_32) · range=0.04533–0.04533 · mean=0.04533 · n=1 · phase=Liquid」 |
```

```ledger
**L1#1_Table#6_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_5419 | lit_id: 2019-li-sun-0 | doi: 10.1016/j.jct.2018.12.036
block: PROPblock_1 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 7
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_1; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at 298.15 K measured by plate method (GLOBmeas_312), value 0.04452 N/m with expanded uncertainty ±0.00046 N/m.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#6_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=293.15–323.15 · n_unique=7 · phase=Liquid」 |
| L1#1_Table#6_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Plate method (GLOBmeas_312) · range=0.04298–0.04475 · mean=0.043904 · n=7 · phase=Liquid」 |
```

```ledger
**L1#1_Table#7_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_9790 | lit_id: 2012-xu-li-0 | doi: 10.1021/je3000348
block: PROPblock_7 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 9
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_3; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at 298.15 K measured by maximal bubble pressure (GLOBmeas_36), value 0.0447 N/m with expanded uncertainty ±0.0004 N/m.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#7_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.15–338.15 · n_unique=9 · phase=Liquid」 |
| L1#1_Table#7_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Maximal bubble pressure (GLOBmeas_36) · range=0.0417–0.0447 · mean=0.043233 · n=9 · phase=Liquid」 |
```

```ledger
**L1#1_Table#8_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_6476 | lit_id: 2019-sho--0 | doi: 10.1016/j.tca.2019.01.018
block: PROPblock_2 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 5
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_2; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at 298.15 K, value 0.0446 N/m.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#8_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.15–338.15 · n_unique=5 · phase=Liquid」 |
| L1#1_Table#8_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Ring tensiometer (GLOBmeas_19) · range=0.04155–0.0446 · mean=0.043 · n=5 · phase=Liquid」 |
```

```ledger
**L1#1_Table#9_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_9568 | lit_id: 2011-wan-zha-2 | doi: 10.1021/je200349t
block: PROPblock_2 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 5
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_2; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at 298.15 K measured by ring tensiometer (GLOBmeas_19), value 0.04437 N/m with expanded uncertainty ±0.00064 N/m.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#9_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=288.15–328.15 · n_unique=5 · phase=Liquid」 |
| L1#1_Table#9_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Ring tensiometer (GLOBmeas_19) · range=0.04243–0.04497 · mean=0.043824 · n=5 · phase=Liquid」 |
```

```ledger
**L1#1_Table#10_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_3156 | lit_id: 2010-klo-sou-0 | doi: 10.1016/j.jct.2009.09.007
block: PROPblock_2 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 15
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_1; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at 298.5 K measured by ring tensiometer (GLOBmeas_19), value 0.04441 N/m.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#10_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=284.25–351.44 · n_unique=15 · phase=Liquid」 |
| L1#1_Table#10_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Ring tensiometer (GLOBmeas_19) · range=0.04085–0.04544 · mean=0.043112 · n=15 · phase=Liquid」 |
```

```ledger
**L1#1_Table#11_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_3156 | lit_id: 2010-klo-sou-0 | doi: 10.1016/j.jct.2009.09.007
block: PROPblock_1 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 15
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_1; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at ~298 K, value ~0.0453 N/m, measurement method GLOBmeas_192.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#11_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=284.17–351.23 · n_unique=15 · phase=Liquid」 |
| L1#1_Table#11_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Wilhelmy plate method (GLOBmeas_192) · range=0.04089–0.04529 · mean=0.043048 · n=15 · phase=Liquid」 |
```

```ledger
**L1#1_Table#12_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_572 | lit_id: 2008-gha-zol-0 | doi: 10.1016/j.fluid.2007.10.004
block: PROPblock_4 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 20
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_4; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] at 298.0 K measured by capillary rise (GLOBmeas_58), value 0.0436 N/m with expanded uncertainty ±0.0013 N/m.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#12_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.0–393.0 · n_unique=20 · phase=Liquid」 |
| L1#1_Table#12_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Capillary rise (GLOBmeas_58) · range=0.0382–0.0436 · mean=0.04083 · n=20 · phase=Liquid」 |
```

```ledger
**L1#1_Table#13_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_3600 | lit_id: 2012-vak-vat-0 | doi: 10.1016/j.jct.2012.03.024
block: PROPblock_6 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 6
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_2; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] identified in search results but not individually inspected for detailed values.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#13_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=283.15–333.15 · n_unique=6 · phase=Liquid」 |
| L1#1_Table#13_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Ring tensiometer (GLOBmeas_19) · range=0.04196–0.04542 · mean=0.043573 · n=6 · phase=Liquid」 |
```
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>L1 returned 11 of 14 blocks with detailed values. Querying for the remaining 3 blocks that were truncated in the initial search to provide a complete answer.</summary>
<tool_call>L1_query(instruction=Search for all su…, id_catalog=GLOBcomp_36: 1-bu…, context=14 total…)</tool_call>

## User
<tool_result>
<subagent_answer>
### L1#2 — L1_query return

**Status:** status=partial

**Summary:**

From 14 total surface tension data blocks for pure 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) in ThermoML, 12 were identified. The newly found block (GLOBlit_4058, DOI 10.1016/j.jct.2013.11.024, Wilhelmy plate method) reports 4 data points from 293.2–323.2 K with ±0.001 N/m uncertainty: 0.0448 N/m at 293.2 K, 0.0441 at 303.2 K, 0.0435 at 313.2 K, and 0.0426 at 323.2 K. Surface tension decreases near-linearly with temperature (slope approximately −7.3 × 10⁻⁵ N/(m·K)). The interpolated value at 298.15 K is ~0.0445 N/m, consistent with the cluster of values (0.0443–0.0453 N/m) from other sources. Across the 12 recovered blocks, values near 298.15 K range from 0.0436 to 0.0469 N/m, measured by capillary rise, drop volume, ring tensiometer, plate method, and maximal bubble pressure techniques. Two blocks remain unidentified due to search result truncation.

**Answer:**

##### Remaining Surface Tension Data Blocks for [C4mim][BF4]

From the 14 total surface tension (GLOBprop_13) blocks for pure 1-butyl-3-methylimidazolium tetrafluoroborate (GLOBcomp_36), one additional block was successfully identified and inspected beyond the 11 previously recovered:

###### Newly Found Block

**GLOBlit_4058 :: PROPblock_1**
- **DOI:** 10.1016/j.jct.2013.11.024
- **Method:** Wilhelmy plate (GLOBmeas_1015)
- **Data points:** 4 (293.2–323.2 K)
- **Uncertainty:** ±0.001 N/m (k = 95%, propagation, compiler-assigned)
- **Phases:** Liquid; Air at 1 atmosphere

**L1#2_Table#1_(Query_L1#2_Answer):**

| *row_id* | *T (K)* | *γ (N/m)* | *±U (N/m)* |
|---|---|---|---|
| L1#2_Table#1_Row#1 | 「293.2」 | 「0.0448」 | 「0.001」 |
| L1#2_Table#1_Row#2 | 「303.2」 | 「0.0441」 | 「0.001」 |
| L1#2_Table#1_Row#3 | 「313.2」 | 「0.0435」 | 「0.001」 |
| L1#2_Table#1_Row#4 | 「323.2」 | 「0.0426」 | 「0.001」 |

The value nearest 298.15 K is **0.0448 N/m at 293.2 K** (or interpolated ~0.0445 N/m at 298.15 K), consistent with the cluster of values (0.0443–0.0453 N/m) from other sources. Surface tension decreases near-linearly with temperature (R² = 0.9931), with a slope of approximately −7.3 × 10⁻⁵ N/(m·K).

###### Remaining 2 Blocks

The search results consistently truncated at 8 entries (sorted by GLOBlit number ascending), preventing retrieval of the last 2 blocks from the 14-block total. The first 8 entries always covered GLOBlit_572 through GLOBlit_5419. The previously known blocks GLOBlit_6476, GLOBlit_9491, GLOBlit_9568, and GLOBlit_9790 (4 blocks) were recovered in earlier work, meaning 2 blocks remain unidentified from the truncated tail of the search results. These could not be individually inspected within the available search budget.

###### Updated Complete Inventory (12 of 14 blocks)

**L1#2_Table#2_(Query_L1#2_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *T nearest 298.15 K* | *γ (N/m)* | *±U (N/m)* | *Method* |
|---|---|---|---|---|---|---|---|---|
| L1#2_Table#2_Row#1 | 「1」 | 「10.1021/je2000183」 | 「GLOBlit_9491」 | 「PROPblock_22」 | 「297.0」 | 「0.0469」 | 「0.0009」 | 「Ring tensiometer」 |
| L1#2_Table#2_Row#2 | 「2」 | 「10.1016/j.jct.2012.03.008」 | 「GLOBlit_3588」 | 「PROPblock_9」 | 「298.0」 | 「0.04544」 | 「—」 | 「—」 |
| L1#2_Table#2_Row#3 | 「3」 | 「10.1016/j.fluid.2009.07.010」 | 「GLOBlit_725」 | 「PROPblock_4」 | 「298.15」 | 「0.04533」 | 「0.0003」 | 「Drop volume」 |
| L1#2_Table#2_Row#4 | 「4」 | 「10.1016/j.jct.2018.12.036」 | 「GLOBlit_5419」 | 「PROPblock_1」 | 「298.15」 | 「0.04452」 | 「0.00046」 | 「Plate method」 |
| L1#2_Table#2_Row#5 | 「5」 | 「10.1021/je3000348」 | 「GLOBlit_9790」 | 「PROPblock_7」 | 「298.15」 | 「0.0447」 | 「0.0004」 | 「Maximal bubble pressure」 |
| L1#2_Table#2_Row#6 | 「6」 | 「10.1016/j.tca.2019.01.018」 | 「GLOBlit_6476」 | 「PROPblock_2」 | 「298.15」 | 「0.0446」 | 「—」 | 「—」 |
| L1#2_Table#2_Row#7 | 「7」 | 「10.1021/je200349t」 | 「GLOBlit_9568」 | 「PROPblock_2」 | 「298.15」 | 「0.04437」 | 「0.00064」 | 「Ring tensiometer」 |
| L1#2_Table#2_Row#8 | 「8」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_2」 | 「298.5」 | 「0.04441」 | 「—」 | 「Ring tensiometer」 |
| L1#2_Table#2_Row#9 | 「9」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_1」 | 「~298」 | 「~0.0453」 | 「—」 | 「—」 |
| L1#2_Table#2_Row#10 | 「10」 | 「10.1016/j.fluid.2007.10.004」 | 「GLOBlit_572」 | 「PROPblock_4」 | 「298.0」 | 「0.0436」 | 「0.0013」 | 「Capillary rise」 |
| L1#2_Table#2_Row#11 | 「11」 | 「10.1016/j.jct.2012.03.024」 | 「GLOBlit_3600」 | 「PROPblock_6」 | 「~298」 | 「(not inspected)」 | 「—」 | 「—」 |
| L1#2_Table#2_Row#12 | 「12」 | 「10.1016/j.jct.2013.11.024」 | 「GLOBlit_4058」 | 「PROPblock_1」 | 「293.2」 | 「0.0448」 | 「0.001」 | 「Wilhelmy plate」 |

Two additional blocks (entries 13–14 of 14) could not be retrieved due to search result truncation.

**Core claims:**
- 12 of 14 ThermoML surface tension data blocks for pure [C4mim][BF4] have been identified and inventoried; the remaining 2 blocks could not be retrieved due to search result truncation.
- The newly found block (GLOBlit_4058, DOI 10.1016/j.jct.2013.11.024) reports surface tension via Wilhelmy plate at 293.2–323.2 K with ±0.001 N/m uncertainty, giving 0.0448 N/m at 293.2 K and an interpolated value of ~0.0445 N/m at 298.15 K.
- Across the 12 recovered blocks, surface tension values near 298.15 K cluster in the range 0.0436–0.0469 N/m, with most values falling between 0.0443 and 0.0453 N/m.
- In the GLOBlit_4058 block, surface tension decreases near-linearly with temperature (R² = 0.9931) with a slope of approximately −7.3 × 10⁻⁵ N/(m·K).

#### Core blocks found — verbatim ledger

```ledger
**L1#2_Table#3_(Query_L1#2_CoreBLK):**
lit_num_id: GLOBlit_4058 | lit_id: 2014-fu-wan-0 | doi: 10.1016/j.jct.2013.11.024
block: PROPblock_1 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 4
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_1; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension data for pure [C4mim][BF4] measured by Wilhelmy plate method at 293.2–323.2 K with expanded uncertainty ±0.001 N/m; nearest value to 298.15 K is 0.0448 N/m at 293.2 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#2_Table#3_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=293.2–323.2 · n_unique=4 · phase=Liquid」 |
| L1#2_Table#3_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Wilhemy plate principle (GLOBmeas_1015) · range=0.0426–0.0448 · mean=0.04375 · n=4 · phase=Liquid」 |
```
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Need to get the specific 298.15 K value from GLOBlit_3600/PROPblock_6 and attempt to find the remaining 2 unidentified blocks. Dispatching targeted query.</summary>
<tool_call>L1_query(instruction=1) Inspect block …, id_catalog=GLOBcomp_36: 1-bu…, context=12 of 14…)</tool_call>

## User
<tool_result>
<subagent_answer>
### L1#3 — L1_query return

**Status:** status=partial

**Summary:**

Surface tension data for pure [C4mim][BF4] from GLOBlit_3600/PROPblock_6 (DOI 10.1016/j.jct.2012.03.024) contains 6 data points measured by ring tensiometer over 283.15–333.15 K with no exact 298.15 K point; linear interpolation of the bracketing values at 293.15 K (0.04461 N/m, ±0.00064 N/m) and 303.15 K (0.04379 N/m, ±0.00063 N/m) gives an estimated surface tension at 298.15 K of ~0.04420 N/m. A newly identified block, GLOBlit_11369/PROPblock_2 (DOI 10.1021/je800710p), contains 10 data points by ring tensiometer over 293.65–360.95 K; interpolation of bracketing values at 293.65 K (0.0446 N/m, ±0.0013 N/m) and 303.35 K (0.0438 N/m, ±0.0013 N/m) yields ~0.04423 N/m at 298.15 K. Both interpolated values are consistent, falling at the lower end of the 0.0443–0.0453 N/m cluster from other sources. In total, 13 of 14 surface tension blocks for pure [C4mim][BF4] were identified across 12 distinct literature sources; the 14th block could not be retrieved. The 13 recovered values near 298.15 K span 0.0436–0.0469 N/m, with the majority clustering in 0.0442–0.0453 N/m.

**Answer:**

##### Surface Tension Data for GLOBlit_3600/PROPblock_6 and Newly Identified Blocks

###### GLOBlit_3600 / PROPblock_6 (DOI: 10.1016/j.jct.2012.03.024)

This block contains 6 surface tension data points for pure [C4mim][BF4] (GLOBcomp_36) measured by ring tensiometer (GLOBmeas_19) over 283.15–333.15 K. There is **no exact data point at 298.15 K**; the two nearest bracketing values are:

**L1#3_Table#1_(Query_L1#3_Answer):**

| *row_id* | *T (K)* | *γ (N/m)* | *±U (N/m)* |
|---|---|---|---|
| L1#3_Table#1_Row#1 | 「293.15」 | 「0.04461」 | 「0.00064」 |
| L1#3_Table#1_Row#2 | 「303.15」 | 「0.04379」 | 「0.00063」 |

Uncertainties are expanded (k = 95%, propagation, compiler-assigned). By linear interpolation, the estimated surface tension at 298.15 K is **~0.04420 N/m**.

###### Newly Found Block: GLOBlit_11369 / PROPblock_2 (DOI: 10.1021/je800710p)

This previously unidentified block contains 10 surface tension data points for pure [C4mim][BF4] measured by ring tensiometer (GLOBmeas_19) over 293.65–360.95 K. Again, no exact 298.15 K point exists; the nearest bracketing values are:

**L1#3_Table#2_(Query_L1#3_Answer):**

| *row_id* | *T (K)* | *γ (N/m)* | *±U (N/m)* |
|---|---|---|---|
| L1#3_Table#2_Row#1 | 「293.65」 | 「0.0446」 | 「0.0013」 |
| L1#3_Table#2_Row#2 | 「303.35」 | 「0.0438」 | 「0.0013」 |

Uncertainties are expanded (k = 95%, propagation, compiler-assigned). By linear interpolation, the estimated surface tension at 298.15 K is **~0.04423 N/m**.

Both interpolated values (~0.04420 and ~0.04423 N/m) are consistent with the cluster of values (0.0443–0.0453 N/m) from other sources, falling at the lower end of that range.

###### Status of the 14th Block

13 of 14 total surface tension blocks for pure [C4mim][BF4] have now been identified. The 14th block could not be retrieved due to persistent truncation in search results. The 13 identified blocks span 12 distinct literature sources (GLOBlit_3156 contributes two blocks).

###### Complete Updated Inventory (13 of 14 blocks)

**L1#3_Table#3_(Query_L1#3_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *T nearest 298.15 K* | *γ (N/m)* | *±U (N/m)* | *Method* |
|---|---|---|---|---|---|---|---|---|
| L1#3_Table#3_Row#1 | 「1」 | 「10.1021/je2000183」 | 「GLOBlit_9491」 | 「PROPblock_22」 | 「297.0」 | 「0.0469」 | 「0.0009」 | 「Ring tensiometer」 |
| L1#3_Table#3_Row#2 | 「2」 | 「10.1016/j.jct.2012.03.008」 | 「GLOBlit_3588」 | 「PROPblock_9」 | 「298.0」 | 「0.04544」 | 「—」 | 「—」 |
| L1#3_Table#3_Row#3 | 「3」 | 「10.1016/j.fluid.2009.07.010」 | 「GLOBlit_725」 | 「PROPblock_4」 | 「298.15」 | 「0.04533」 | 「0.0003」 | 「Drop volume」 |
| L1#3_Table#3_Row#4 | 「4」 | 「10.1016/j.jct.2018.12.036」 | 「GLOBlit_5419」 | 「PROPblock_1」 | 「298.15」 | 「0.04452」 | 「0.00046」 | 「Plate method」 |
| L1#3_Table#3_Row#5 | 「5」 | 「10.1021/je3000348」 | 「GLOBlit_9790」 | 「PROPblock_7」 | 「298.15」 | 「0.0447」 | 「0.0004」 | 「Maximal bubble pressure」 |
| L1#3_Table#3_Row#6 | 「6」 | 「10.1016/j.tca.2019.01.018」 | 「GLOBlit_6476」 | 「PROPblock_2」 | 「298.15」 | 「0.0446」 | 「—」 | 「—」 |
| L1#3_Table#3_Row#7 | 「7」 | 「10.1021/je200349t」 | 「GLOBlit_9568」 | 「PROPblock_2」 | 「298.15」 | 「0.04437」 | 「0.00064」 | 「Ring tensiometer」 |
| L1#3_Table#3_Row#8 | 「8」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_2」 | 「298.5」 | 「0.04441」 | 「—」 | 「Ring tensiometer」 |
| L1#3_Table#3_Row#9 | 「9」 | 「10.1016/j.jct.2009.09.007」 | 「GLOBlit_3156」 | 「PROPblock_1」 | 「~298」 | 「~0.0453」 | 「—」 | 「—」 |
| L1#3_Table#3_Row#10 | 「10」 | 「10.1016/j.fluid.2007.10.004」 | 「GLOBlit_572」 | 「PROPblock_4」 | 「298.0」 | 「0.0436」 | 「0.0013」 | 「Capillary rise」 |
| L1#3_Table#3_Row#11 | 「11」 | 「10.1016/j.jct.2012.03.024」 | 「GLOBlit_3600」 | 「PROPblock_6」 | 「~298.15 (interp.)」 | 「~0.04420」 | 「0.00064」 | 「Ring tensiometer」 |
| L1#3_Table#3_Row#12 | 「12」 | 「10.1016/j.jct.2013.11.024」 | 「GLOBlit_4058」 | 「PROPblock_1」 | 「293.2」 | 「0.0448」 | 「0.001」 | 「Wilhelmy plate」 |
| L1#3_Table#3_Row#13 | 「13」 | 「10.1021/je800710p」 | 「GLOBlit_11369」 | 「PROPblock_2」 | 「~298.15 (interp.)」 | 「~0.04423」 | 「0.0013」 | 「Ring tensiometer」 |
| L1#3_Table#3_Row#14 | 「14」 | 「(not retrieved)」 | 「—」 | 「—」 | 「—」 | 「—」 | 「—」 | 「—」 |

The 13 recovered values near 298.15 K span **0.0436–0.0469 N/m** (43.6–46.9 mN/m), with the majority clustering in the narrower range of 0.0442–0.0453 N/m.

**Core claims:**
- GLOBlit_3600/PROPblock_6 contains 6 surface tension data points for pure [C4mim][BF4] over 283.15–333.15 K with no exact 298.15 K point; the two nearest bracketing values are 0.04461 N/m at 293.15 K and 0.04379 N/m at 303.15 K, yielding an interpolated estimate of ~0.04420 N/m at 298.15 K.
- A newly identified block GLOBlit_11369/PROPblock_2 (DOI: 10.1021/je800710p) contains 10 surface tension data points for pure [C4mim][BF4] over 293.65–360.95 K; bracketing values of 0.0446 N/m at 293.65 K and 0.0438 N/m at 303.35 K yield an interpolated estimate of ~0.04423 N/m at 298.15 K.
- 13 of 14 total surface tension blocks for pure [C4mim][BF4] have been identified across 12 distinct literature sources; the 14th block could not be retrieved.
- The 13 recovered surface tension values near 298.15 K span 0.0436–0.0469 N/m, with the majority clustering in the narrower range of 0.0442–0.0453 N/m.

#### Core blocks found — verbatim ledger

```ledger
**L1#3_Table#4_(Query_L1#3_CoreBLK):**
lit_num_id: GLOBlit_3600 | lit_id: 2012-vak-vat-0 | doi: 10.1016/j.jct.2012.03.024
block: PROPblock_6 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 6
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_2; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Surface tension of pure [C4mim][BF4] measured by ring tensiometer over 283.15–333.15 K; bracketing values at 293.15 K (0.04461 N/m) and 303.15 K (0.04379 N/m) used to interpolate ~0.04420 N/m at 298.15 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#3_Table#4_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=283.15–333.15 · n_unique=6 · phase=Liquid」 |
| L1#3_Table#4_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Ring tensiometer (GLOBmeas_19) · range=0.04196–0.04542 · mean=0.043573 · n=6 · phase=Liquid」 |
```

```ledger
**L1#3_Table#5_(Query_L1#3_CoreBLK):**
lit_num_id: GLOBlit_11369 | lit_id: 2009-san-esp-1 | doi: 10.1021/je800710p
block: PROPblock_2 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 10
compounds: 1-butyl-3-methylimidazolium tetrafluoroborate (C8H15BF4N2; GLOBcomp_36; DOIcomp_2; InChIKey LSBXQLQATZTAPE-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_13
description: Newly identified surface tension block for pure [C4mim][BF4] measured by ring tensiometer over 293.65–360.95 K with 10 data points; interpolated value ~0.04423 N/m at 298.15 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#3_Table#5_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=293.65–360.95 · n_unique=10 · phase=Liquid」 |
| L1#3_Table#5_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_13」 | 「Surface tension liquid-gas, N/m」 | 「method=Ring tensiometer (GLOBmeas_19) · range=0.0403–0.0446 · mean=0.04253 · n=10 · phase=Liquid」 |
```
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## User
[TIME WARNING 1/3] 65% of time budget used (846s / 1000s). Wrap up soon — provide your best answer with available data.

## LLM Response
<reasoning>
I now have comprehensive data from 13 of 14 blocks across 12 literature sources. Let me compile the final answer with all values, uncertainties, and an assessment of whether the sources agree within their reported uncertainties.

Key data points at or near 298.15 K:
1. GLOBlit_9491/PROPblock_22: 0.0469 ± 0.0009 N/m at 297.0 K (ring tensiometer)
2. GLOBlit_3588/PROPblock_9: 0.04544 N/m at 298.0 K (pendant drop) - no uncertainty
3. GLOBlit_725/PROPblock_4: 0.04533 ± 0.0003 N/m at 298.15 K (drop volume)
4. GLOBlit_5419/PROPblock_1: 0.04452 ± 0.00046 N/m at 298.15 K (plate method)
5. GLOBlit_9790/PROPblock_7: 0.0447 ± 0.0004 N/m at 298.15 K (maximal bubble pressure)
6. GLOBlit_6476/PROPblock_2: 0.0446 N/m at 298.15 K - no uncertainty
7. GLOBlit_9568/PROPblock_2: 0.04437 ± 0.00064 N/m at 298.15 K (ring tensiometer)
8. GLOBlit_3156/PROPblock_2: 0.04441 N/m at 298.5 K (ring tensiometer) - no uncertainty
9. GLOBlit_3156/PROPblock_1: ~0.0453 N/m at ~298 K (Wilhelmy plate) - no uncertainty
10. GLOBlit_572/PROPblock_4: 0.0436 ± 0.0013 N/m at 298.0 K (capillary rise)
11. GLOBlit_3600/PROPblock_6: ~0.04420 N/m interpolated at 298.15 K (ring tensiometer), ±0.00064 N/m
12. GLOBlit_4058/PROPblock_1: 0.0448 N/m at 293.2 K, interpolated ~0.0445 at 298.15 K (Wilhelmy plate), ±0.001 N/m
13. GLOBlit_11369/PROPblock_2: ~0.04423 N/m interpolated at 298.15 K (ring tensiometer), ±0.0013 N/m

Agreement analysis:
- The majority cluster: 0.0442–0.0453 N/m (entries 4-13 above)
- Outlier high: 0.0469 N/m (GLOBlit_9491) - this is ~2 mN/m above the cluster
- Outlier low: 0.0436 N/m (GLOBlit_572) - but with large uncertainty ±0.0013

Do they agree within uncertainties? Let me check pairwise:
- GLOBlit_725 (0.04533 ± 0.0003) vs GLOBlit_9568 (0.04437 ± 0.00064): difference = 0.00096 N/m, combined U = sqrt(0.0003² + 0.00064²) ≈ 0.00071. The difference exceeds the combined uncertainty → they do NOT agree.
- GLOBlit_9491 (0.0469 ± 0.0009) vs GLOBlit_725 (0.04533 ± 0.0003): difference = 0.00157, combined U ≈ 0.00095. Difference exceeds combined U → do NOT agree.
- GLOBlit_572 (0.0436 ± 0.0013) vs GLOBlit_725 (0.04533 ± 0.0003): difference = 0.00173, combined U ≈ 0.00134. Difference exceeds combined U → do NOT agree.

So the sources do NOT all agree within their reported expanded uncertainties. The spread of ~3.3 mN/m (0.0436–0.0469) far exceeds even the largest individual uncertainty (±0.0013 N/m). Even within the tighter cluster (0.0442–0.0453), the ~1 mN/m spread exceeds typical reported uncertainties of ±0.0003–0.0006 N/m.
</reasoning>

<answer>
## Surface Tension of 1-Butyl-3-methylimidazolium Tetrafluoroborate ([C4mim][BF4]) at ~298.15 K — Complete Multi-Source Report

**Compound:** 1-butyl-3-methylimidazolium tetrafluoroborate, C₈H₁₅BF₄N₂, CAS 174501-65-6  
**Property:** Surface tension (liquid–gas), N/m  
**Target temperature:** 298.15 K

The ThermoML database contains **14 data blocks from 12 literature sources** reporting this property. Values from 13 of those blocks were recovered (the 14th could not be retrieved due to search-result truncation). All stated uncertainties are expanded uncertainties at 95 % confidence (k = 2, propagation/compiler-assigned).

### Source-by-Source Data

| # | DOI | Literature ID | Block | T (K) | γ (N/m) | ±U (N/m) | Method |
|---|-----|---------------|-------|--------|---------|----------|--------|
| 1 | 10.1021/je2000183 | GLOBlit_9491 | PROPblock_22 | 297.0 | 0.0469 | 0.0009 | Ring tensiometer |
| 2 | 10.1016/j.jct.2012.03.008 | GLOBlit_3588 | PROPblock_9 | 298.0 | 0.04544 | — | Pendant drop |
| 3 | 10.1016/j.fluid.2009.07.010 | GLOBlit_725 | PROPblock_4 | 298.15 | 0.04533 | 0.0003 | Drop volume |
| 4 | 10.1016/j.jct.2018.12.036 | GLOBlit_5419 | PROPblock_1 | 298.15 | 0.04452 | 0.00046 | Plate method |
| 5 | 10.1021/je3000348 | GLOBlit_9790 | PROPblock_7 | 298.15 | 0.0447 | 0.0004 | Maximal bubble pressure |
| 6 | 10.1016/j.tca.2019.01.018 | GLOBlit_6476 | PROPblock_2 | 298.15 | 0.0446 | — | Ring tensiometer |
| 7 | 10.1021/je200349t | GLOBlit_9568 | PROPblock_2 | 298.15 | 0.04437 | 0.00064 | Ring tensiometer |
| 8 | 10.1016/j.jct.2009.09.007 | GLOBlit_3156 | PROPblock_2 | 298.5 | 0.04441 | — | Ring tensiometer |
| 9 | 10.1016/j.jct.2009.09.007 | GLOBlit_3156 | PROPblock_1 | ~298 | ~0.0453 | — | Wilhelmy plate |
| 10 | 10.1016/j.fluid.2007.10.004 | GLOBlit_572 | PROPblock_4 | 298.0 | 0.0436 | 0.0013 | Capillary rise |
| 11 | 10.1016/j.jct.2012.03.024 | GLOBlit_3600 | PROPblock_6 | ~298.15* | ~0.04420* | 0.00064 | Ring tensiometer |
| 12 | 10.1016/j.jct.2013.11.024 | GLOBlit_4058 | PROPblock_1 | ~298.15* | ~0.0445* | 0.001 | Wilhelmy plate |
| 13 | 10.1021/je800710p | GLOBlit_11369 | PROPblock_2 | ~298.15* | ~0.04423* | 0.0013 | Ring tensiometer |

\* Interpolated from bracketing temperatures (no exact 298.15 K data point in the block).

### Do the Sources Agree Within Their Reported Uncertainties?

**No — the sources do not all agree within their reported expanded uncertainties.**

The full spread across the 13 recovered values is **0.0436–0.0469 N/m (43.6–46.9 mN/m)**, a range of ~3.3 mN/m. This far exceeds even the largest individual expanded uncertainty (±1.3 mN/m for the capillary-rise measurement). Several specific pairwise comparisons illustrate the disagreement:

- **GLOBlit_725 (drop volume, 0.04533 ± 0.0003) vs. GLOBlit_9568 (ring tensiometer, 0.04437 ± 0.00064):** The difference is 0.00096 N/m, but the combined expanded uncertainty is only ~0.00071 N/m — the values are statistically inconsistent.
- **GLOBlit_9491 (ring tensiometer, 0.0469 ± 0.0009) vs. GLOBlit_725 (drop volume, 0.04533 ± 0.0003):** The difference is 0.00157 N/m against a combined uncertainty of ~0.00095 N/m — again inconsistent.
- **GLOBlit_572 (capillary rise, 0.0436 ± 0.0013) vs. GLOBlit_725 (drop volume, 0.04533 ± 0.0003):** The difference is 0.00173 N/m against a combined uncertainty of ~0.00134 N/m — marginally inconsistent.

Even within the tighter cluster of 11 sources (entries 3–13, spanning 0.0436–0.0453 N/m), the ~1.7 mN/m spread exceeds the typical reported uncertainties of ±0.3–0.6 mN/m.

### Chemistry Insight

The inter-source scatter is a well-known issue for ionic liquid surface tension measurements. The dominant causes are:

1. **Sample purity:** [C4mim][BF4] is hygroscopic, and even trace water (a few hundred ppm) lowers the surface tension measurably. Halide impurities from synthesis can also shift values.
2. **Measurement technique:** Different methods (ring tensiometer, drop volume, capillary rise, maximal bubble pressure, pendant drop, Wilhelmy plate) have different sensitivities to surface-active contaminants and equilibration time.
3. **The highest outlier** (GLOBlit_9491, 0.0469 N/m at 297.0 K) is ~2 mN/m above the main cluster and may reflect a particularly dry or pure sample, or a systematic offset in that ring tensiometer measurement.

A reasonable consensus value from the majority of sources is approximately **0.0443–0.0453 N/m (44.3–45.3 mN/m)** at 298.15 K, but the reported expanded uncertainties are too small to encompass the full inter-laboratory spread, indicating that systematic errors (primarily purity-related) dominate over the stated random uncertainties.
</answer>