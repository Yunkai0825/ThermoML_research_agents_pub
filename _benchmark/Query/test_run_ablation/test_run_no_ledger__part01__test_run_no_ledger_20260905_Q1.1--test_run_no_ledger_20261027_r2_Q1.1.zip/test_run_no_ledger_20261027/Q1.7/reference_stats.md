# Reference Stats — query-agent

**Run started:** 2026-10-27 03:23:24
**Wall time (at last flush):** 931.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 45,063 | 152,630 | 21,254 | 197,693 | 28,241 | 133.7 | claudeopus46 |
| L1-worker | 59 | 672,424 | 557,222 | 111,313 | 1,229,646 | 20,841 | 764.0 | claudeopus46 |
| **TOTAL** | **66** | **717,487** | **709,852** | **132,567** | **1,427,339** | **21,626** | **897.7** | |

**Estimated tokens:** ~356,834 input + ~33,141 output = ~389,975 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 1 | 0 | 0 | 0 | 9 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 1 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 9 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 7 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 20 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 1 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 5 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 4 |
| `search_system_registry` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 6 |
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 14 | 105 |
| `block_search_adv` | 1 | 0 | 0 | 0 | 13 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 10 |
| **TOTAL** | **18** | **16** | **16** | **0** | **109** | **93** | **693** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_36 |  | block_search_adv, resolve_compound_ids, search_blocks, search_system_registry |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_13 |  | resolve_property_ids, search_blocks, search_system_registry |

#### References (13 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_572 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_725 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_3156 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_3588 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_3600 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_4058 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_5419 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_6476 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_9491 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_9568 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_9790 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_11369 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_11673 |  | block_search_adv, search_blocks, search_system_registry |

#### Measurements (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_58 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_32 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_192 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_19 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_22 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_1015 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_312 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_36 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks, search_system_registry |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | resolve_ids, search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_2 |  | block_search_adv, search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 1 |
| Unique References | 13 |
| Unique Measurements | 8 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 13 |
| Unique parent blocks | 14 |
| Explicit block/subsystem targets | 14 |
| Subsystem targets | 0 |
| Target-matched data points | 693 |

---

## 3. DOI & Block References

**Unique DOIs:** 13  |  **Parent blocks:** 14  |  **Explicit targets:** 14  |  **Subsystems:** 0  |  **Target-matched datapoints:** 105

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2007.10.004 | 1 | 20 | unary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.07.010 | 1 | 1 | unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2009.09.007 | 2 | 30 | unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.03.008 | 1 | 6 | unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.03.024 | 1 | 6 | unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.11.024 | 1 | 4 | unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.12.036 | 1 | 7 | unary | search_blocks, search_system_registry |
| 10.1016/j.tca.2019.01.018 | 1 | 5 | unary | search_blocks, search_system_registry |
| 10.1021/je2000183 | 1 | 1 | unary | search_blocks, search_system_registry |
| 10.1021/je200349t | 1 | 5 | unary | search_blocks, search_system_registry |
| 10.1021/je3000348 | 1 | 9 | unary | search_blocks, search_system_registry |
| 10.1021/je800710p | 1 | 10 | unary | search_blocks, search_system_registry |
| 10.1021/je900502s | 1 | 1 | unary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2007.10.004 | PROPblock_4 | declared | 20 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.07.010 | PROPblock_4 | declared | 1 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2009.09.007 | PROPblock_1 | declared | 15 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2009.09.007 | PROPblock_2 | declared | 15 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.03.008 | PROPblock_9 | declared | 6 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.03.024 | PROPblock_6 | declared | 6 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.11.024 | PROPblock_1 | declared | 4 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.12.036 | PROPblock_1 | declared | 7 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.tca.2019.01.018 | PROPblock_2 | declared | 5 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/je2000183 | PROPblock_22 | declared | 1 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/je200349t | PROPblock_2 | declared | 5 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/je3000348 | PROPblock_7 | declared | 9 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/je800710p | PROPblock_2 | declared | 10 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/je900502s | PROPblock_5 | declared | 1 | unary | 1 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve [C4mim][BF… | 360 | KEEP ←in 293 | 360 | 4.8 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Confirm surface ten… | 181 | KEEP ←in 251 | 181 | 3.2 |
| 3 | 4 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,132 | KEEP ←in 7,536 | 1132 | 26.1 |
| 4 | 6 | `resolve_ids` | entity_type=variable, limit=5, min_score=50, purpo… | 303 | KEEP ←in 233 | 303 | 4.9 |
| 5 | 8 | `block_search_adv` | compounds=REQUIRE GLOBcomp_36 AS bmimbf4, explanat… | 1,109 | KEEP ←in 7,733 | 1109 | 17.3 |
| 6 | 9 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,031 | KEEP ←in 7,536 | 1031 | 23.1 |
| 7 | 11 | `search_blocks` | block_number=GLOBlit_725::PROPblock_4, purpose=Ins… | 614 | KEEP ←in 1,292 | 600 | 7.7 |
| 8 | 11 | `search_blocks` | block_number=GLOBlit_9790::PROPblock_7, purpose=In… | 1,192 | KEEP ←in 1,514 | 1192 | 11.1 |
| 9 | 11 | `search_blocks` | block_number=GLOBlit_5419::PROPblock_1, purpose=In… | 900 | KEEP ←in 1,479 | 885 | 9.6 |
| 10 | 12 | `search_blocks` | block_number=GLOBlit_572::PROPblock_4, purpose=Get… | 896 | KEEP ←in 1,550 | 882 | 8.7 |
| 11 | 12 | `search_blocks` | block_number=GLOBlit_9491::PROPblock_22, purpose=G… | 490 | KEEP ←in 1,310 | 490 | 6.9 |
| 12 | 12 | `search_blocks` | block_number=GLOBlit_9568::PROPblock_2, purpose=Ge… | 796 | KEEP ←in 1,401 | 766 | 7.9 |
| 13 | 1 | `L1_query` | instruction=First, resolve the compound 1…, purpos… | 49,817 | — | — | 308.4 |
| 14 | 1 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,070 | KEEP ←in 7,536 | 1070 | 17.4 |
| 15 | 2 | `search_blocks` | block_number=GLOBlit_4058::PROPblock_1, purpose=In… | 919 | KEEP ←in 1,420 | 904 | 8.5 |
| 16 | 2 | `search_system_registry` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 596 | KEEP ←in 9,423 | 596 | 19.6 |
| 17 | 4 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,093 | KEEP ←in 7,536 | 1093 | 20.2 |
| 18 | 2 | `L1_query` | context=14 total blocks were identifi…, id_catalog… | 8,996 | — | — | 280.0 |
| 19 | 3 | `search_blocks` | block_number=GLOBlit_3600::PROPblock_6, purpose=In… | 945 | KEEP ←in 1,610 | 945 | 9.5 |
| 20 | 5 | `search_blocks` | compound=GLOBcomp_36, limit=50, property=GLOBprop_… | 1,015 | KEEP ←in 7,536 | 1015 | 21.5 |
| 21 | 7 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_36 AS bmim…, explanat… | 1,051 | KEEP ←in 8,330 | 1033 | 20.1 |
| 22 | 8 | `search_blocks` | block_number=GLOBlit_11369::PROPblock_2, purpose=I… | 834 | KEEP ←in 1,561 | 834 | 9.4 |
| 23 | 3 | `L1_query` | context=12 of 14 blocks already found…, id_catalog… | 13,740 | — | — | 212.6 |
| | | **TOTAL (23 tools)** | | **89,080** | | **16,421** | **1058.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 736 | 10,497 | 1,493 | 10.1 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,207 | 22,625 | 876 | 6.4 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,627 | 24,045 | 892 | 5.0 |
| 4 | L1-worker | claudeopus46 | 3,767 | 458 | 4,225 | 492 | 4.1 |
| 5 | L1-worker | claudeopus46 | 3,767 | 395 | 4,162 | 304 | 3.1 |
| 6 | L1-worker | claudeopus46 | 21,418 | 2,595 | 24,013 | 858 | 6.8 |
| 7 | L1-worker | claudeopus46 | 21,418 | 3,328 | 24,746 | 639 | 5.3 |
| 8 | L1-worker | claudeopus46 | 3,767 | 7,977 | 11,744 | 1,489 | 13.3 |
| 9 | L1-worker | claudeopus46 | 21,418 | 4,634 | 26,052 | 1,787 | 11.5 |
| 10 | L1-worker | claudeopus46 | 21,418 | 5,434 | 26,852 | 624 | 4.3 |
| 11 | L1-worker | claudeopus46 | 3,767 | 358 | 4,125 | 421 | 3.7 |
| 12 | L1-worker | claudeopus46 | 21,418 | 5,906 | 27,324 | 1,602 | 11.8 |
| 13 | L1-worker | claudeopus46 | 21,418 | 6,761 | 28,179 | 2,060 | 13.8 |
| 14 | L1-worker | claudeopus46 | 3,767 | 8,004 | 11,771 | 1,640 | 13.2 |
| 15 | L1-worker | claudeopus46 | 21,418 | 7,965 | 29,383 | 2,534 | 18.2 |
| 16 | L1-worker | claudeopus46 | 3,767 | 7,992 | 11,759 | 1,395 | 13.1 |
| 17 | L1-worker | claudeopus46 | 21,418 | 9,610 | 31,028 | 3,367 | 19.4 |
| 18 | L1-worker | claudeopus46 | 21,418 | 11,028 | 32,446 | 1,075 | 6.1 |
| 19 | L1-worker | claudeopus46 | 3,767 | 1,633 | 5,400 | 842 | 6.8 |
| 20 | L1-worker | claudeopus46 | 3,767 | 1,856 | 5,623 | 1,439 | 10.5 |
| 21 | L1-worker | claudeopus46 | 3,767 | 1,821 | 5,588 | 1,231 | 8.8 |
| 22 | L1-worker | claudeopus46 | 21,418 | 13,630 | 35,048 | 2,214 | 15.1 |
| 23 | L1-worker | claudeopus46 | 3,767 | 1,907 | 5,674 | 1,135 | 8.1 |
| 24 | L1-worker | claudeopus46 | 3,767 | 1,670 | 5,437 | 672 | 6.1 |
| 25 | L1-worker | claudeopus46 | 3,767 | 1,762 | 5,529 | 1,007 | 7.5 |
| 26 | L1-worker | claudeopus46 | 21,385 | 16,292 | 37,677 | 3,429 | 24.0 |
| 27 | L1-worker | claudeopus46 | 2,320 | 3,558 | 5,878 | 1,115 | 5.0 |
| 28 | L1-worker | claudeopus46 | 627 | 3,438 | 4,065 | 1,334 | 9.4 |
| 29 | L1-worker | claudeopus46 | 2,543 | 4,886 | 7,429 | 4,021 | 15.8 |
| 30 | L1-worker | claudeopus46 | 787 | 52,966 | 53,753 | 811 | 8.2 |
| 31 | L0-main | claudeopus46 | 9,761 | 28,130 | 37,891 | 2,112 | 16.6 |
| 32 | L1-worker | claudeopus46 | 21,418 | 11,312 | 32,730 | 687 | 6.1 |
| 33 | L1-worker | claudeopus46 | 3,767 | 7,915 | 11,682 | 1,264 | 11.9 |
| 34 | L1-worker | claudeopus46 | 21,418 | 12,887 | 34,305 | 10,466 | 59.0 |
| 35 | L1-worker | claudeopus46 | 3,767 | 1,809 | 5,576 | 1,232 | 8.3 |
| 36 | L1-worker | claudeopus46 | 3,767 | 9,827 | 13,594 | 1,705 | 14.2 |
| 37 | L1-worker | claudeopus46 | 21,418 | 15,229 | 36,647 | 9,681 | 53.8 |
| 38 | L1-worker | claudeopus46 | 21,418 | 16,103 | 37,521 | 8,908 | 49.0 |
| 39 | L1-worker | claudeopus46 | 3,767 | 7,961 | 11,728 | 1,364 | 12.6 |
| 40 | L1-worker | claudeopus46 | 21,418 | 17,571 | 38,989 | 4,190 | 30.3 |
| 41 | L1-worker | claudeopus46 | 2,543 | 5,005 | 7,548 | 524 | 4.6 |
| 42 | L1-worker | claudeopus46 | 2,320 | 3,265 | 5,585 | 804 | 7.3 |
| 43 | L1-worker | claudeopus46 | 627 | 3,145 | 3,772 | 895 | 8.2 |
| 44 | L1-worker | claudeopus46 | 787 | 12,092 | 12,879 | 655 | 7.1 |
| 45 | L0-main | claudeopus46 | 9,761 | 41,496 | 51,257 | 2,202 | 17.3 |
| 46 | L1-worker | claudeopus46 | 21,418 | 17,529 | 38,947 | 1,354 | 10.1 |
| 47 | L1-worker | claudeopus46 | 21,418 | 18,705 | 40,123 | 1,367 | 8.6 |
| 48 | L1-worker | claudeopus46 | 21,418 | 19,432 | 40,850 | 756 | 5.1 |
| 49 | L1-worker | claudeopus46 | 3,767 | 1,980 | 5,747 | 1,251 | 9.2 |
| 50 | L1-worker | claudeopus46 | 21,418 | 19,896 | 41,314 | 1,330 | 10.3 |
| 51 | L1-worker | claudeopus46 | 21,418 | 20,840 | 42,258 | 1,103 | 8.4 |
| 52 | L1-worker | claudeopus46 | 3,767 | 7,986 | 11,753 | 1,377 | 12.8 |
| 53 | L1-worker | claudeopus46 | 21,418 | 22,001 | 43,419 | 2,990 | 21.5 |
| 54 | L1-worker | claudeopus46 | 21,418 | 22,985 | 44,403 | 1,607 | 12.1 |
| 55 | L1-worker | claudeopus46 | 3,767 | 8,506 | 12,273 | 1,247 | 11.8 |
| 56 | L1-worker | claudeopus46 | 21,418 | 24,188 | 45,606 | 3,232 | 24.4 |
| 57 | L1-worker | claudeopus46 | 3,767 | 2,005 | 5,772 | 1,164 | 9.2 |
| 58 | L1-worker | claudeopus46 | 21,418 | 25,543 | 46,961 | 5,344 | 34.9 |
| 59 | L1-worker | claudeopus46 | 2,543 | 5,349 | 7,892 | 908 | 6.2 |
| 60 | L1-worker | claudeopus46 | 2,320 | 3,669 | 5,989 | 957 | 7.7 |
| 61 | L1-worker | claudeopus46 | 627 | 3,549 | 4,176 | 1,090 | 8.9 |
| 62 | L1-worker | claudeopus46 | 787 | 17,240 | 18,027 | 556 | 6.0 |
| 63 | L0-main | claudeopus46 | 9,761 | 58,040 | 67,801 | 7,230 | 46.6 |
| 64 | L0-main | claudeopus46 | 2,320 | 4,841 | 7,161 | 1,164 | 6.3 |
| 65 | L0-main | claudeopus46 | 2,543 | 5,409 | 7,952 | 2,139 | 13.7 |
| 66 | L0-main | claudeopus46 | 1,156 | 13,978 | 15,134 | 4,914 | 23.1 |

