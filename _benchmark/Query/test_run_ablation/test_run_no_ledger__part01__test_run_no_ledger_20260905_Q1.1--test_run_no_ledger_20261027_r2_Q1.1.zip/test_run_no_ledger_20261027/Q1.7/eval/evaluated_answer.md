# Q1.7 — Result

**Prompt:** Using ThermoML, report the surface tension of 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4]) at or near 298.15 K from every source, each with its reported expanded uncertainty and block identifier, and say whether the sources agree within those uncertainties.

**[run statistics removed]**

---

## Answer

## Surface Tension of 1-Butyl-3-methylimidazolium Tetrafluoroborate ([C4mim][BF4]) at ~298.15 K — Complete Multi-Source Report

**Compound:** 1-butyl-3-methylimidazolium tetrafluoroborate, C₈H₁₅BF₄N₂, CAS 174501-65-6  
**Property:** Surface tension (liquid–gas), N/m  
**Target temperature:** 298.15 K

The ThermoML database contains **14 data blocks from 12 literature sources** reporting this property. Values from 13 of those blocks were recovered (the 14th could not be retrieved due to search-result truncation). All stated uncertainties are expanded uncertainties at 95 % confidence (k = 2, propagation/compiler-assigned).

### Source-by-Source Data

| # | DOI | Literature ID | Block | T (K) | γ (N/m) | ±U (N/m) | Method |
|---|-----|---------------|-------|--------|---------|----------|--------|
| 1 | 10.1021/je2000183 | GLOBlit_9491 | PROPblock_22 | 297.0 | 0.0469 | 0.0009 | Ring tensiometer |
| 2 | 10.1016/j.jct.2012.03.008 | GLOBlit_3588 | PROPblock_9 | 298.0 | 0.04544 | — | Pendant drop |
| 3 | 10.1016/j.fluid.2009.07.010 | GLOBlit_725 | PROPblock_4 | 298.15 | 0.04533 | 0.0003 | Drop volume |
| 4 | 10.1016/j.jct.2018.12.036 | GLOBlit_5419 | PROPblock_1 | 298.15 | 0.04452 | 0.00046 | Plate method |
| 5 | 10.1021/je3000348 | GLOBlit_9790 | PROPblock_7 | 298.15 | 0.0447 | 0.0004 | Maximal bubble pressure |
| 6 | 10.1016/j.tca.2019.01.018 | GLOBlit_6476 | PROPblock_2 | 298.15 | 0.0446 | — | Ring tensiometer |
| 7 | 10.1021/je200349t | GLOBlit_9568 | PROPblock_2 | 298.15 | 0.04437 | 0.00064 | Ring tensiometer |
| 8 | 10.1016/j.jct.2009.09.007 | GLOBlit_3156 | PROPblock_2 | 298.5 | 0.04441 | — | Ring tensiometer |
| 9 | 10.1016/j.jct.2009.09.007 | GLOBlit_3156 | PROPblock_1 | ~298 | ~0.0453 | — | Wilhelmy plate |
| 10 | 10.1016/j.fluid.2007.10.004 | GLOBlit_572 | PROPblock_4 | 298.0 | 0.0436 | 0.0013 | Capillary rise |
| 11 | 10.1016/j.jct.2012.03.024 | GLOBlit_3600 | PROPblock_6 | ~298.15* | ~0.04420* | 0.00064 | Ring tensiometer |
| 12 | 10.1016/j.jct.2013.11.024 | GLOBlit_4058 | PROPblock_1 | ~298.15* | ~0.0445* | 0.001 | Wilhelmy plate |
| 13 | 10.1021/je800710p | GLOBlit_11369 | PROPblock_2 | ~298.15* | ~0.04423* | 0.0013 | Ring tensiometer |

\* Interpolated from bracketing temperatures (no exact 298.15 K data point in the block).

### Do the Sources Agree Within Their Reported Uncertainties?

**No — the sources do not all agree within their reported expanded uncertainties.**

The full spread across the 13 recovered values is **0.0436–0.0469 N/m (43.6–46.9 mN/m)**, a range of ~3.3 mN/m. This far exceeds even the largest individual expanded uncertainty (±1.3 mN/m for the capillary-rise measurement). Several specific pairwise comparisons illustrate the disagreement:

- **GLOBlit_725 (drop volume, 0.04533 ± 0.0003) vs. GLOBlit_9568 (ring tensiometer, 0.04437 ± 0.00064):** The difference is 0.00096 N/m, but the combined expanded uncertainty is only ~0.00071 N/m — the values are statistically inconsistent.
- **GLOBlit_9491 (ring tensiometer, 0.0469 ± 0.0009) vs. GLOBlit_725 (drop volume, 0.04533 ± 0.0003):** The difference is 0.00157 N/m against a combined uncertainty of ~0.00095 N/m — again inconsistent.
- **GLOBlit_572 (capillary rise, 0.0436 ± 0.0013) vs. GLOBlit_725 (drop volume, 0.04533 ± 0.0003):** The difference is 0.00173 N/m against a combined uncertainty of ~0.00134 N/m — marginally inconsistent.

Even within the tighter cluster of 11 sources (entries 3–13, spanning 0.0436–0.0453 N/m), the ~1.7 mN/m spread exceeds the typical reported uncertainties of ±0.3–0.6 mN/m.

### Chemistry Insight

The inter-source scatter is a well-known issue for ionic liquid surface tension measurements. The dominant causes are:

1. **Sample purity:** [C4mim][BF4] is hygroscopic, and even trace water (a few hundred ppm) lowers the surface tension measurably. Halide impurities from synthesis can also shift values.
2. **Measurement technique:** Different methods (ring tensiometer, drop volume, capillary rise, maximal bubble pressure, pendant drop, Wilhelmy plate) have different sensitivities to surface-active contaminants and equilibration time.
3. **The highest outlier** (GLOBlit_9491, 0.0469 N/m at 297.0 K) is ~2 mN/m above the main cluster and may reflect a particularly dry or pure sample, or a systematic offset in that ring tensiometer measurement.

A reasonable consensus value from the majority of sources is approximately **0.0443–0.0453 N/m (44.3–45.3 mN/m)** at 298.15 K, but the reported expanded uncertainties are too small to encompass the full inter-laboratory spread, indicating that systematic errors (primarily purity-related) dominate over the stated random uncertainties.

### Core claims

- The ThermoML database contains 14 data blocks from 12 literature sources reporting the surface tension of 1-butyl-3-methylimidazolium tetrafluoroborate ([C4mim][BF4], CAS 174501-65-6) near 298.15 K; values from 13 blocks were recovered.
- The 13 recovered surface tension values span 0.0436–0.0469 N/m (43.6–46.9 mN/m), a range of ~3.3 mN/m that far exceeds even the largest individual reported expanded uncertainty (±1.3 mN/m).
- The sources do not all agree within their reported expanded uncertainties; specific pairwise comparisons show statistically inconsistent values, indicating that systematic errors dominate over stated random uncertainties.
- The dominant causes of inter-source scatter are attributed to sample purity (especially trace water and halide impurities in the hygroscopic ionic liquid) and differences in measurement technique.
- A reasonable consensus value from the majority of sources is approximately 0.0443–0.0453 N/m (44.3–45.3 mN/m) at 298.15 K, but reported expanded uncertainties are too small to encompass the full inter-laboratory spread.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_9491 | 10.1021/je2000183 | PROPblock_22 |  | Provides a single surface tension data point (0.0469 N/m at 297.0 K) for pure [C4mim][BF4] via ring tensiometer, contributing the highest value in the comparison and illustrating inter-source scatter. |
| GLOBlit_3588 | 10.1016/j.jct.2012.03.008 | PROPblock_9 |  | Contains pendant drop surface tension data for pure [C4mim][BF4] with a maximum of 0.04544 N/m at 298.0 K, directly supporting the answer's reported value for this source. |
| GLOBlit_725 | 10.1016/j.fluid.2009.07.010 | PROPblock_4 |  | Provides a single drop-volume surface tension measurement of 0.04533 N/m at exactly 298.15 K for pure [C4mim][BF4], used as a key reference point in the pairwise disagreement analysis. |
| GLOBlit_5419 | 10.1016/j.jct.2018.12.036 | PROPblock_1 |  | Contains plate-method surface tension data for pure [C4mim][BF4] spanning 293.15–323.15 K; the 298.15 K value of 0.04452 N/m falls within the block's range and contributes to the consensus cluster. |
| GLOBlit_9790 | 10.1021/je3000348 | PROPblock_7 |  | Provides maximal bubble pressure surface tension data for pure [C4mim][BF4] with a maximum of 0.0447 N/m at 298.15 K, directly matching the answer's reported value. |
| GLOBlit_6476 | 10.1016/j.tca.2019.01.018 | PROPblock_2 |  | Contains ring tensiometer surface tension data for pure [C4mim][BF4] with a maximum of 0.0446 N/m at 298.15 K, consistent with the answer's reported value for this source. |
| GLOBlit_9568 | 10.1021/je200349t | PROPblock_2 |  | Provides ring tensiometer surface tension data for pure [C4mim][BF4] over 288.15–328.15 K; the 298.15 K value of 0.04437 N/m is used in the pairwise disagreement analysis in the answer. |
| GLOBlit_3156 | 10.1016/j.jct.2009.09.007 | PROPblock_2 |  | Contains ring tensiometer surface tension data for pure [C4mim][BF4] over 284.25–351.44 K; the ~298.5 K value of 0.04441 N/m is reported in the answer. |
| GLOBlit_3156 | 10.1016/j.jct.2009.09.007 | PROPblock_1 |  | Contains Wilhelmy plate surface tension data for pure [C4mim][BF4] over 284.17–351.23 K; the ~298 K value of ~0.0453 N/m provides a second independent measurement from the same reference. |
| GLOBlit_572 | 10.1016/j.fluid.2007.10.004 | PROPblock_4 |  | Provides capillary rise surface tension data for pure [C4mim][BF4] with a maximum of 0.0436 N/m at 298.0 K, contributing the lowest value in the comparison and used in pairwise disagreement analysis. |
| GLOBlit_3600 | 10.1016/j.jct.2012.03.024 | PROPblock_6 |  | Contains ring tensiometer surface tension data for pure [C4mim][BF4] over 283.15–333.15 K; the interpolated ~298.15 K value of ~0.04420 N/m contributes to the consensus analysis. |
| GLOBlit_4058 | 10.1016/j.jct.2013.11.024 | PROPblock_1 |  | Contains Wilhelmy plate surface tension data for pure [C4mim][BF4] over 293.2–323.2 K; the interpolated ~298.15 K value of ~0.0445 N/m contributes to the multi-source comparison. |
| GLOBlit_11369 | 10.1021/je800710p | PROPblock_2 |  | Contains ring tensiometer surface tension data for pure [C4mim][BF4] over 293.65–360.95 K; the interpolated ~298.15 K value of ~0.04423 N/m contributes to the multi-source comparison. |

### Suggested follow-ups

- Retrieve the 14th block that was truncated from the search results to complete the dataset.
- Compare these surface tension values with NIST recommended or critically evaluated reference data for [C4mim][BF4].
- Investigate the water content reported in each source to assess whether purity differences explain the inter-laboratory scatter.
- Examine temperature-dependent surface tension data from these sources to check whether the discrepancies persist across the full temperature range or are specific to 298.15 K.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
