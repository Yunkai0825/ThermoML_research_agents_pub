# Data grounding evidence

- generated: 2026-10-27T03:38:17
- grounding profile: current
- gate verdict: 2 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | — | NO | — | — |
| PROPblock_2 | — | NO | — | — |
| PROPblock_22 | — | NO | — | — |
| PROPblock_4 | — | NO | — | — |
| PROPblock_6 | — | NO | — | — |
| PROPblock_7 | — | NO | — | — |
| PROPblock_9 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 297.0 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0469 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0009 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.0 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.04544 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.04533 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0003 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.04452 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.00046 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0447 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0004 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0446 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.04437 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.00064 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.5 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.04441 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0453 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.0 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0436 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0013 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.04420 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.00064 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0445 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.001 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 13 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.04423 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 0.0013 | PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_6 | uninspected_block | — |
| 13 | PROPblock_6 | uninspected_block | — |
| 0.0436 | PROPblock_6 | uninspected_block | — |
| 0.0469 | PROPblock_6 | uninspected_block | — |
| 43.6 | PROPblock_6 | uninspected_block | — |
| 46.9 | PROPblock_6 | uninspected_block | — |
| 3.3 | PROPblock_6 | uninspected_block | — |
| 1.3 | PROPblock_6 | uninspected_block | — |
| 0.04533 | PROPblock_6 | uninspected_block | — |
| 0.0003 | PROPblock_6 | uninspected_block | — |
| 0.04437 | PROPblock_6 | uninspected_block | — |
| 0.00064 | PROPblock_6 | uninspected_block | — |
| 0.00096 | PROPblock_6 | uninspected_block | — |
| 0.00071 | PROPblock_6 | uninspected_block | — |
| 0.0469 | PROPblock_6 | uninspected_block | — |
| 0.0009 | PROPblock_6 | uninspected_block | — |
| 0.04533 | PROPblock_6 | uninspected_block | — |
| 0.0003 | PROPblock_6 | uninspected_block | — |
| 0.00157 | PROPblock_6 | uninspected_block | — |
| 0.00095 | PROPblock_6 | uninspected_block | — |
| 0.0436 | PROPblock_6 | uninspected_block | — |
| 0.0013 | PROPblock_6 | uninspected_block | — |
| 0.04533 | PROPblock_6 | uninspected_block | — |
| 0.0003 | PROPblock_6 | uninspected_block | — |
| 0.00173 | PROPblock_6 | uninspected_block | — |
| 0.00134 | PROPblock_6 | uninspected_block | — |
| 13 | PROPblock_6 | uninspected_block | — |
| 0.0436 | PROPblock_6 | uninspected_block | — |
| 0.0453 | PROPblock_6 | uninspected_block | — |
| 1.7 | PROPblock_6 | uninspected_block | — |
| 0.3 | PROPblock_6 | uninspected_block | — |
| 0.6 | PROPblock_6 | uninspected_block | — |
| 0.0469 | PROPblock_6 | uninspected_block | — |
| 297.0 | PROPblock_6 | uninspected_block | — |
| 0.0443 | PROPblock_6 | uninspected_block | — |
| 0.0453 | PROPblock_6 | uninspected_block | — |
| 44.3 | PROPblock_6 | uninspected_block | — |
| 45.3 | PROPblock_6 | uninspected_block | — |
| 298.15 | PROPblock_6 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6: PROPblock_22 + PROPblock_9 + PROPblock_4 + PROPblock_1 + PROPblock_7 + PROPblock_2 + PROPblock_6 is quoted with data values (297.0, 0.0469, 0.0009, 298.0, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_6: PROPblock_6 is quoted with data values (298.15, 13, 0.0436, 0.0469, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_