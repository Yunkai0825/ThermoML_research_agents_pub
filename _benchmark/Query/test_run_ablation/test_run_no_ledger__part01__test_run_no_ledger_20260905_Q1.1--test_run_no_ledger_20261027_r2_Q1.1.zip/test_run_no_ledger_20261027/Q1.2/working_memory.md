# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_12 | hexane | hexane |
| comp | GLOBcomp_2 | ethanol | ethanol |
| prop | GLOBprop_29 | binary_diffusion_coefficient_m2_s | Binary diffusion coefficient, m2/s |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all thermophysical properties measured for an equimolar liquid mixture of hexane + ethanol near 25 °C → stored as L1_query_1 · validation: PASS
- [L1] Identify the 8th property measured for hexane + ethanol near 25 °C from GLOBlit_8445 (DOI: 10.1021/je0497303) → stored as L1_query_2 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

The ThermoML database contains measurements for the binary liquid mixture of hexane + ethanol near 25 °C (290–310 K range) covering at least 8 distinct thermophysical properties across 5 literature sources. The identified properties are: mass density, viscosity, refractive index (Na D-line), speed of sound, surface tension (liquid–gas), excess molar enthalpy, and excess molar volume, with an 8th property from an additional source (DOI: 10.1021/je0497303) indicated but truncated. Composition spans mole fraction of ethanol from 0 to 1; temperature is typically 293–303 K with many points at exactly 298.15 K; pressure is ~101 kPa. Representative data near x ≈ 0.5 and T = 298.15 K include: mass density ~650–789 kg/m³ across the full composition range, excess molar enthalpy up to ~0.58 kJ/mol, excess molar volume up to ~4.1 × 10⁻⁷ m³/mol, surface tension 0.016–0.022 N/m, and viscosity 0.000287–0.001377 Pa·s. The system exhibits significant positive excess enthalpy and positive excess volume, consistent with the disruption of ethanol's hydrogen-bond network upon mixing with nonpolar hexane.

**Answer:**

The ThermoML database contains measurements for the binary liquid mixture of **hexane** (GLOBcomp_12) + **ethanol** (GLOBcomp_2) near 25 °C (290–310 K range) covering at least **8 distinct thermophysical properties** across 5 literature sources. Here is the complete list of identified properties:

##### Distinct Properties Measured

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *#* | *Property* | *GLOBprop ID* | *Representative Block* | *Literature (DOI)* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「1」 | 「**Mass density**」 | 「GLOBprop_1」 | 「PROPblock_24 @ GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| WM_L1_Q1_Table#1_Row#2 | 「2」 | 「**Viscosity**」 | 「GLOBprop_4」 | 「PROPblock_9 @ GLOBlit_11449」 | 「10.1021/je800925v」 |
| WM_L1_Q1_Table#1_Row#3 | 「3」 | 「**Refractive index** (Na D-line)」 | 「GLOBprop_7」 | 「PROPblock_22 @ GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| WM_L1_Q1_Table#1_Row#4 | 「4」 | 「**Speed of sound**」 | 「GLOBprop_8」 | 「PROPblock_23 @ GLOBlit_2800」 | 「10.1016/j.jct.2007.02.008」 |
| WM_L1_Q1_Table#1_Row#5 | 「5」 | 「**Surface tension** (liquid–gas)」 | 「GLOBprop_13」 | 「PROPblock_5 @ GLOBlit_10821」 | 「10.1021/je700215z」 |
| WM_L1_Q1_Table#1_Row#6 | 「6」 | 「**Excess molar enthalpy** (HᴱE)」 | 「GLOBprop_17」 | 「PROPblock_5 @ GLOBlit_294」 | 「10.1016/j.fluid.2005.08.001」 |
| WM_L1_Q1_Table#1_Row#7 | 「7」 | 「**Excess molar volume** (VᴱE)」 | 「GLOBprop_28」 | 「PROPblock_6 @ GLOBlit_294」 | 「10.1016/j.fluid.2005.08.001」 |

An 8th property was indicated in the initial search results from additional blocks at GLOBlit_8445 (DOI: 10.1021/je0497303) but the result was truncated.

##### Key Conditions
- **System type:** Binary liquid mixture
- **Composition variable:** Mole fraction of ethanol (GLOBvar_2), spanning 0–1 (including equimolar x ≈ 0.5)
- **Temperature:** Typically 293–303 K, with many points at exactly 298.15 K
- **Pressure:** ~101 kPa (atmospheric) where constrained

##### Representative Data Points Near x = 0.5, T = 298.15 K
- **Mass density:** ~650–789 kg/m³ across the full composition range (GLOBlit_2800)
- **Excess molar enthalpy:** up to ~0.58 kJ/mol at intermediate compositions (GLOBlit_294), reflecting the strongly non-ideal nature of the hexane–ethanol system
- **Excess molar volume:** up to ~4.1 × 10⁻⁷ m³/mol (GLOBlit_294), indicating positive volume of mixing
- **Surface tension:** 0.016–0.022 N/m across compositions (GLOBlit_10821)
- **Viscosity:** 0.000287–0.001377 Pa·s (GLOBlit_11449)

##### Chemistry Insight
Hexane + ethanol is a classic non-ideal binary system: hexane is a nonpolar alkane while ethanol is a hydrogen-bonding polar molecule. This leads to significant positive excess enthalpy (endothermic mixing) and positive excess volume, consistent with the disruption of ethanol's hydrogen-bond network upon mixing. The wide range of measured properties reflects the system's importance as a benchmark for testing thermodynamic models of polar–nonpolar mixtures.

**Core claims:**
- The ThermoML database contains measurements for the binary liquid mixture of hexane + ethanol near 25 °C (290–310 K range) covering at least 8 distinct thermophysical properties across 5 literature sources.
- The identified properties include mass density, viscosity, refractive index (Na D-line), speed of sound, surface tension (liquid–gas), excess molar enthalpy, and excess molar volume, with an 8th property from an additional source truncated in the results.
- Measurements span the full ethanol mole fraction range (0–1) at temperatures typically 293–303 K and atmospheric pressure (~101 kPa), with many points at exactly 298.15 K.
- Representative values near 298.15 K include: mass density ~650–789 kg/m³ across the full composition range; excess molar enthalpy up to ~0.58 kJ/mol at intermediate compositions; excess molar volume up to ~4.1 × 10⁻⁷ m³/mol; surface tension 0.016–0.022 N/m; viscosity 0.000287–0.001377 Pa·s.
- The hexane + ethanol system exhibits significant positive excess enthalpy (endothermic mixing) and positive excess volume, consistent with the disruption of ethanol's hydrogen-bond network upon mixing with the nonpolar alkane.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#2 | 「GLOBlit_2800」 | 「PROPblock_24」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_1」 | 「Mass density measurements for hexane + ethanol binary mixture near 298.15 K across the full composition range.」 |
| WM_L1_Q1_Table#3 | 「GLOBlit_11449」 | 「PROPblock_9」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_4」 | 「Viscosity measurements for hexane + ethanol binary mixture near 298.15 K.」 |
| WM_L1_Q1_Table#4 | 「GLOBlit_2800」 | 「PROPblock_22」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_7」 | 「Refractive index (Na D-line) measurements for hexane + ethanol binary mixture near 298.15 K.」 |
| WM_L1_Q1_Table#5 | 「GLOBlit_2800」 | 「PROPblock_23」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_8」 | 「Speed of sound measurements for hexane + ethanol binary mixture near 298.15 K.」 |
| WM_L1_Q1_Table#6 | 「GLOBlit_10821」 | 「PROPblock_5」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_13」 | 「Surface tension (liquid–gas) measurements for hexane + ethanol binary mixture near 298.15 K.」 |
| WM_L1_Q1_Table#7 | 「GLOBlit_294」 | 「PROPblock_5」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_17」 | 「Excess molar enthalpy measurements for hexane + ethanol binary mixture near 298.15 K, showing endothermic mixing.」 |
| WM_L1_Q1_Table#8 | 「GLOBlit_294」 | 「PROPblock_6」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_28」 | 「Excess molar volume measurements for hexane + ethanol binary mixture near 298.15 K, showing positive volume of mixing.」 |

*Not stored here: 2 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.
### L1_query_2
**L1_query_2** — status: success · validation: PASS

**Summary:**

The 8th property measured for the hexane + ethanol binary system near 25 °C in the ThermoML database is the binary diffusion coefficient (GLOBprop_29), found in PROPblock_8 of GLOBlit_8445 (DOI: 10.1021/je0497303). The measurement method is Taylor dispersion (GLOBmeas_38) in the liquid phase at T = 298.15 K and P = 101.3 kPa, with 9 data points spanning mole fraction of ethanol from 0 to 1. Representative values at 298.15 K: at x(ethanol) = 0.0, D = 5.74 × 10⁻⁹ m²/s (±0.11 × 10⁻⁹); at x(ethanol) = 1.0, D = 1.60 × 10⁻⁹ m²/s (±0.07 × 10⁻⁹). The diffusion coefficient decreases roughly 3.6-fold from the hexane-rich to the ethanol-rich end, consistent with higher viscosity and stronger hydrogen bonding in ethanol-rich solutions.

**Answer:**

The 8th property measured for the hexane + ethanol binary system near 25 °C in the ThermoML database is the **binary diffusion coefficient** (GLOBprop_29), found in **PROPblock_8** of **GLOBlit_8445** (DOI: 10.1021/je0497303).

**Details:**
- **Property:** Binary diffusion coefficient (units: m²/s)
- **GLOBprop ID:** GLOBprop_29
- **Block:** PROPblock_8 @ GLOBlit_8445
- **Method:** Taylor dispersion (GLOBmeas_38)
- **Phase:** Liquid
- **Conditions:** T = 298.15 K, P = 101.3 kPa
- **Composition variable:** Mole fraction of ethanol (GLOBvar_2), 9 data points spanning x = 0 to 1
- **Representative data at 298.15 K:**
  - At x(ethanol) = 0.0 (pure hexane limit): D = 5.74 × 10⁻⁹ m²/s (±0.11 × 10⁻⁹)
  - At x(ethanol) = 1.0 (pure ethanol limit): D = 1.60 × 10⁻⁹ m²/s (±0.07 × 10⁻⁹)

The diffusion coefficient decreases roughly 3.6-fold from the hexane-rich to the ethanol-rich end, consistent with the higher viscosity of ethanol compared to hexane and the stronger intermolecular interactions (hydrogen bonding) in ethanol-rich solutions that impede molecular transport.

**Core claims:**
- The 8th property measured for the hexane + ethanol binary system near 25 °C in the ThermoML database is the binary diffusion coefficient (GLOBprop_29), found in PROPblock_8 of GLOBlit_8445 (DOI: 10.1021/je0497303).
- The binary diffusion coefficient was measured by Taylor dispersion in the liquid phase at T = 298.15 K and P = 101.3 kPa, with 9 data points spanning ethanol mole fraction x = 0 to 1.
- At x(ethanol) = 0.0 (pure hexane limit), D = 5.74 × 10⁻⁹ m²/s (±0.11 × 10⁻⁹); at x(ethanol) = 1.0 (pure ethanol limit), D = 1.60 × 10⁻⁹ m²/s (±0.07 × 10⁻⁹).
- The diffusion coefficient decreases from the hexane-rich to the ethanol-rich end, consistent with the higher viscosity of ethanol and stronger hydrogen-bonding interactions in ethanol-rich solutions.

**Core blocks found:**

**WM_L1_Q2_Blocks_(Query_L1_Q2_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q2_Table#1 | 「GLOBlit_8445」 | 「PROPblock_8」 | 「GLOBcomp_2, GLOBcomp_12」 | 「GLOBprop_29」 | 「Binary diffusion coefficient measurements for hexane + ethanol at 298.15 K via Taylor dispersion, spanning mole fraction of ethanol from 0 to 1.」 |

*Not stored here: 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


