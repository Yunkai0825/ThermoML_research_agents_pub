# Q1.2 — Result

**Prompt:** For an equimolar liquid mixture of hexane + ethanol near 25 °C, which thermophysical properties have been measured?

**Tool calls:** 3  |  **Time:** 481.2s  |  **Iterations:** 4  |  **Timed out:** False

---

## Answer

For an equimolar liquid mixture of **hexane + ethanol** near 25 °C (typically 293–303 K, with many measurements at exactly 298.15 K), the ThermoML database contains measurements of **8 distinct thermophysical properties** reported across 5 literature sources:

| # | Property | Units | Representative Source (DOI) |
|---|----------|-------|-----------------------------|
| 1 | **Mass density** | kg/m³ | 10.1016/j.jct.2007.02.008 |
| 2 | **Dynamic viscosity** | Pa·s | 10.1021/je800925v |
| 3 | **Refractive index** (Na D-line) | — | 10.1016/j.jct.2007.02.008 |
| 4 | **Speed of sound** | m/s | 10.1016/j.jct.2007.02.008 |
| 5 | **Surface tension** (liquid–gas) | N/m | 10.1021/je700215z |
| 6 | **Excess molar enthalpy** (H^E) | kJ/mol | 10.1016/j.fluid.2005.08.001 |
| 7 | **Excess molar volume** (V^E) | m³/mol | 10.1016/j.fluid.2005.08.001 |
| 8 | **Binary diffusion coefficient** | m²/s | 10.1021/je0497303 |

### Representative values near equimolar composition (x ≈ 0.5) at 298.15 K and ~101 kPa

- **Mass density:** ~650–789 kg/m³ across the full composition range (39 data points)
- **Dynamic viscosity:** 0.000287–0.001377 Pa·s (103 data points, 273–298 K)
- **Refractive index:** 1.357–1.375 (39 data points)
- **Speed of sound:** 1046–1160 m/s (39 data points)
- **Surface tension:** 0.016–0.022 N/m (77 data points, 283–313 K)
- **Excess molar enthalpy:** up to ~0.58 kJ/mol at intermediate compositions (17 data points at 298.15 K), indicating strongly endothermic mixing
- **Excess molar volume:** positive values across the composition range (23 data points at 298.15 K)
- **Binary diffusion coefficient:** 5.74 × 10⁻⁹ m²/s at x(ethanol) = 0 down to 1.60 × 10⁻⁹ m²/s at x(ethanol) = 1 (9 data points at 298.15 K, measured by Taylor dispersion)

### Chemistry insight

Hexane + ethanol is a classic non-ideal binary system: hexane is a nonpolar alkane, while ethanol is a strongly hydrogen-bonding polar molecule. Mixing disrupts ethanol's hydrogen-bond network without compensating attractive interactions, leading to significant **positive excess enthalpy** (endothermic mixing) and **positive excess volume** (expansion on mixing). The ~3.6-fold decrease in the binary diffusion coefficient from the hexane-rich to the ethanol-rich limit reflects the higher viscosity and stronger intermolecular cohesion in ethanol-rich solutions. This system is widely used as a benchmark for testing thermodynamic models of polar–nonpolar liquid mixtures.

### Core claims

- For an equimolar liquid mixture of hexane + ethanol near 25 °C (293–303 K), the ThermoML database contains measurements of 8 distinct thermophysical properties across 5 literature sources: mass density, dynamic viscosity, refractive index, speed of sound, surface tension, excess molar enthalpy, excess molar volume, and binary diffusion coefficient.
- Excess molar enthalpy values are positive (up to ~0.58 kJ/mol at intermediate compositions, 17 data points at 298.15 K), indicating strongly endothermic mixing due to disruption of ethanol's hydrogen-bond network without compensating attractive interactions.
- Excess molar volume is positive across the composition range (23 data points at 298.15 K), indicating expansion on mixing.
- The binary diffusion coefficient ranges from 5.74 × 10⁻⁹ m²/s at x(ethanol) = 0 to 1.60 × 10⁻⁹ m²/s at x(ethanol) = 1 (9 data points at 298.15 K, measured by Taylor dispersion), reflecting higher viscosity and stronger intermolecular cohesion in ethanol-rich solutions.
- Dynamic viscosity spans 0.000287–0.001377 Pa·s across 103 data points covering 273–298 K.
- Hexane + ethanol is a classic non-ideal polar–nonpolar binary system widely used as a benchmark for testing thermodynamic models of polar–nonpolar liquid mixtures.

**Confidence:** medium

### Suggested follow-ups

- Compare the excess molar enthalpy of hexane + ethanol with hexane + methanol or hexane + 1-propanol to see how alcohol chain length affects non-ideal mixing behavior.
- Investigate whether vapor–liquid equilibrium (VLE) data for hexane + ethanol near 25 °C are available in ThermoML, since this system exhibits an azeotrope.
- Examine how the binary diffusion coefficient varies with temperature by querying additional temperature ranges beyond 298.15 K.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_12",
    "registry_id": "hexane",
    "name": "hexane"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_29",
    "registry_id": "binary_diffusion_coefficient_m2_s",
    "name": "Binary diffusion coefficient, m2/s"
  }
]
```
