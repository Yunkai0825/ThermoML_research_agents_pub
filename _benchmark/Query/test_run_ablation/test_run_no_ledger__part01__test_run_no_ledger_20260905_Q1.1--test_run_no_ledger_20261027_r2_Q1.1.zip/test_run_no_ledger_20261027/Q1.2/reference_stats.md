# Reference Stats — query-agent

**Run started:** 2026-10-27 03:18:00
**Wall time (at last flush):** 386.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 45,989 | 75,785 | 12,472 | 121,774 | 13,530 | 76.4 | claudeopus46 |
| L1-worker | 33 | 345,493 | 174,961 | 50,856 | 520,454 | 15,771 | 313.0 | claudeopus46 |
| **TOTAL** | **42** | **391,482** | **250,746** | **63,328** | **642,228** | **15,291** | **389.4** | |

**Estimated tokens:** ~160,557 input + ~15,832 output = ~176,389 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 8 | 2 | 2 | 5 | 9 | 449 |
| `search_system_registry` | 2 | 5 | 2 | 1 | 3 | 6 | 400 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 8 | 2 | 2 | 5 | 9 | 449 |
| `search_system_registry` | 2 | 5 | 2 | 1 | 3 | 6 | 400 |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 9 |
| **TOTAL** | **14** | **27** | **9** | **8** | **17** | **31** | **1,707** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_12 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks, search_system_registry |

#### References (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_294 |  | search_blocks |
| GLOBlit_2800 |  | search_blocks, search_system_registry |
| GLOBlit_8445 |  | search_blocks |
| GLOBlit_10821 |  | search_blocks, search_system_registry |
| GLOBlit_11449 |  | search_blocks, search_system_registry |

#### Properties (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBprop_28 | Excess molar volume, m3/mol | search_blocks |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBprop_29 | Binary diffusion coefficient, m2/s | search_blocks |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry |

#### Measurements (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_29 | Excess molar volume, m3/mol | search_blocks |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_38 | Binary diffusion coefficient, m2/s | search_blocks |
| GLOBmeas_342 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_284 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_147 | Mass density, kg/m3 | search_blocks, search_system_registry |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 5 |
| Unique Properties | 8 |
| Unique Measurements | 9 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 2 |
| Unique Block_Types | 1 |
| Total DOIs | 5 |
| Unique parent blocks | 9 |
| Explicit block/subsystem targets | 9 |
| Subsystem targets | 0 |
| Target-matched data points | 1,707 |

---

## 3. DOI & Block References

**Unique DOIs:** 5  |  **Parent blocks:** 9  |  **Explicit targets:** 9  |  **Subsystems:** 0  |  **Target-matched datapoints:** 449

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2005.08.001 | 2 | 40 | binary | search_blocks |
| 10.1016/j.jct.2007.02.008 | 3 | 117 | binary | search_blocks, search_system_registry |
| 10.1021/je0497303 | 1 | 9 | binary | search_blocks |
| 10.1021/je700215z | 1 | 77 | binary | search_blocks, search_system_registry |
| 10.1021/je800925v | 2 | 206 | binary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2005.08.001 | PROPblock_5 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_6 | declared | 23 | binary | — | search_blocks |
| 10.1016/j.jct.2007.02.008 | PROPblock_22 | declared | 39 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | declared | 39 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | declared | 39 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0497303 | PROPblock_8 | declared | 9 | binary | — | search_blocks |
| 10.1021/je700215z | PROPblock_5 | declared | 77 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je800925v | PROPblock_10 | declared | 103 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je800925v | PROPblock_9 | declared | 103 | binary | 2 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | purpose=Resolve compound IDs for hexa…, queries=['… | 216 | KEEP ←in 287 | 216 | 4.1 |
| 2 | 4 | `search_blocks` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=50, … | 1,333 | KEEP ←in 5,780 | 1317 | 21.5 |
| 3 | 5 | `search_system_registry` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=50, … | 1,172 | KEEP ←in 4,751 | 1172 | 12.3 |
| 4 | 1 | `L1_query` | context=User wants a comprehensive li…, id_catalog… | 512 | — | — | 143.6 |
| 5 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve hexane and … | 216 | KEEP ←in 287 | 216 | 4.0 |
| 6 | 4 | `search_blocks` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=50, … | 1,234 | KEEP ←in 5,780 | 1219 | 24.5 |
| 7 | 5 | `search_system_registry` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=50, … | 1,376 | KEEP ←in 4,751 | 1283 | 13.8 |
| 8 | 2 | `L1_query` | context=User wants to know which ther…, id_catalog… | 44,678 | — | — | 130.9 |
| 9 | 1 | `search_blocks` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=50, … | 1,198 | KEEP ←in 1,681 | 1183 | 10.5 |
| 10 | 3 | `L1_query` | context=We already identified 7 prope…, id_catalog… | 8,617 | — | — | 38.1 |
| | | **TOTAL (10 tools)** | | **60,552** | | **6,606** | **403.3** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 578 | 10,339 | 1,447 | 9.7 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,268 | 22,686 | 532 | 4.7 |
| 3 | L1-worker | claudeopus46 | 21,418 | 1,953 | 23,371 | 517 | 4.6 |
| 4 | L1-worker | claudeopus46 | 3,767 | 489 | 4,256 | 379 | 3.9 |
| 5 | L1-worker | claudeopus46 | 21,418 | 2,217 | 23,635 | 944 | 6.9 |
| 6 | L1-worker | claudeopus46 | 21,418 | 2,965 | 24,383 | 624 | 4.5 |
| 7 | L1-worker | claudeopus46 | 3,767 | 6,241 | 10,008 | 1,568 | 11.5 |
| 8 | L1-worker | claudeopus46 | 21,418 | 4,442 | 25,860 | 3,543 | 22.3 |
| 9 | L1-worker | claudeopus46 | 3,767 | 5,288 | 9,055 | 1,491 | 11.8 |
| 10 | L1-worker | claudeopus46 | 21,418 | 6,227 | 27,645 | 5,181 | 31.4 |
| 11 | L1-worker | claudeopus46 | 2,320 | 3,165 | 5,485 | 989 | 5.6 |
| 12 | L1-worker | claudeopus46 | 627 | 3,045 | 3,672 | 1,178 | 7.1 |
| 13 | L1-worker | claudeopus46 | 2,543 | 4,554 | 7,097 | 4,047 | 14.7 |
| 14 | L1-worker | claudeopus46 | 1,228 | 9,357 | 10,585 | 4,360 | 15.0 |
| 15 | L0-main | claudeopus46 | 9,761 | 1,335 | 11,096 | 1,137 | 7.2 |
| 16 | L1-worker | claudeopus46 | 21,418 | 1,237 | 22,655 | 545 | 4.6 |
| 17 | L1-worker | claudeopus46 | 21,418 | 2,266 | 23,684 | 610 | 4.8 |
| 18 | L1-worker | claudeopus46 | 3,767 | 459 | 4,226 | 389 | 3.8 |
| 19 | L1-worker | claudeopus46 | 21,418 | 2,131 | 23,549 | 2,220 | 13.9 |
| 20 | L1-worker | claudeopus46 | 21,418 | 2,886 | 24,304 | 694 | 5.6 |
| 21 | L1-worker | claudeopus46 | 3,767 | 6,294 | 10,061 | 1,557 | 12.7 |
| 22 | L1-worker | claudeopus46 | 21,418 | 4,281 | 25,699 | 1,624 | 11.3 |
| 23 | L1-worker | claudeopus46 | 3,767 | 5,261 | 9,028 | 1,615 | 13.2 |
| 24 | L1-worker | claudeopus46 | 21,418 | 6,239 | 27,657 | 4,833 | 28.8 |
| 25 | L1-worker | claudeopus46 | 2,320 | 2,828 | 5,148 | 1,226 | 5.4 |
| 26 | L1-worker | claudeopus46 | 627 | 2,708 | 3,335 | 1,127 | 5.5 |
| 27 | L1-worker | claudeopus46 | 2,543 | 4,186 | 6,729 | 2,542 | 10.0 |
| 28 | L1-worker | claudeopus46 | 787 | 47,097 | 47,884 | 581 | 6.6 |
| 29 | L0-main | claudeopus46 | 9,761 | 23,014 | 32,775 | 1,341 | 10.5 |
| 30 | L1-worker | claudeopus46 | 21,418 | 8,729 | 30,147 | 626 | 6.0 |
| 31 | L1-worker | claudeopus46 | 3,767 | 2,090 | 5,857 | 1,471 | 9.7 |
| 32 | L1-worker | claudeopus46 | 21,418 | 10,408 | 31,826 | 1,093 | 7.9 |
| 33 | L1-worker | claudeopus46 | 2,543 | 2,650 | 5,193 | 582 | 3.3 |
| 34 | L1-worker | claudeopus46 | 627 | 1,104 | 1,731 | 747 | 4.4 |
| 35 | L1-worker | claudeopus46 | 2,320 | 1,224 | 3,544 | 821 | 4.8 |
| 36 | L1-worker | claudeopus46 | 787 | 9,672 | 10,459 | 600 | 6.7 |
| 37 | L0-main | claudeopus46 | 9,761 | 31,290 | 41,051 | 2,664 | 17.5 |
| 38 | L0-main | claudeopus46 | 2,543 | 3,058 | 5,601 | 936 | 5.6 |
| 39 | L0-main | claudeopus46 | 2,320 | 2,648 | 4,968 | 1,362 | 5.7 |
| 40 | L0-main | claudeopus46 | 1,156 | 6,506 | 7,662 | 2,361 | 10.4 |
| 41 | L0-main | claudeopus46 | 560 | 5,564 | 6,124 | 1,210 | 8.2 |
| 42 | L0-main | claudeopus46 | 366 | 1,792 | 2,158 | 14 | 1.6 |

