# Reference Stats — query-agent

**Run started:** 2026-10-27 03:24:15
**Wall time (at last flush):** 152.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 4 | 24,385 | 28,856 | 6,950 | 53,241 | 13,310 | 42.2 | claudeopus46 |
| L1-worker | 13 | 110,784 | 66,587 | 16,826 | 177,371 | 13,643 | 105.8 | claudeopus46 |
| **TOTAL** | **17** | **135,169** | **95,443** | **23,776** | **230,612** | **13,565** | **148.0** | |

**Estimated tokens:** ~57,653 input + ~5,944 output = ~63,597 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 3 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 0 | 0 | 3 | 3 | 3 |
| `search_blocks` | 1 | 1 | 0 | 0 | 3 | 3 | 3 |
| `search_blocks` | 1 | 1 | 0 | 0 | 3 | 3 | 3 |
| **TOTAL** | **4** | **6** | **0** | **0** | **9** | **9** | **9** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_95 |  | resolve_compound_ids, search_blocks |

#### Properties (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_23 |  | resolve_property_ids, search_blocks |
| GLOBprop_25 |  | resolve_property_ids, search_blocks |
| GLOBprop_54 |  | resolve_property_ids, search_blocks |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8063 |  | search_blocks |
| GLOBlit_8544 |  | search_blocks |
| GLOBlit_8560 |  | search_blocks |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_37 | Critical temperature, K | search_blocks |
| GLOBmeas_43 | Critical pressure, kPa | search_blocks |
| GLOBmeas_137 | Critical density, kg/m3 | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 3 |
| Unique References | 3 |
| Unique Measurements | 3 |
| Unique Phases | 1 |
| Total DOIs | 3 |
| Unique parent blocks | 9 |
| Explicit block/subsystem targets | 9 |
| Subsystem targets | 0 |
| Target-matched data points | 9 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 9  |  **Explicit targets:** 9  |  **Subsystems:** 0  |  **Target-matched datapoints:** 9

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je0201976 | 3 | 3 | unary | search_blocks |
| 10.1021/je0499420 | 3 | 3 | unary | search_blocks |
| 10.1021/je0499723 | 3 | 3 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je0201976 | PROPblock_23 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0201976 | PROPblock_24 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0201976 | PROPblock_25 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499420 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499420 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499420 | PROPblock_9 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499723 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499723 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0499723 | PROPblock_9 | declared | 1 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve compound I… | 307 | KEEP ←in 249 | 307 | 5.0 |
| 2 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Resolve property I… | 281 | KEEP ←in 377 | 281 | 4.4 |
| 3 | 3 | `search_blocks` | compound=GLOBcomp_95, limit=50, property=GLOBprop_… | 744 | KEEP ←in 3,005 | 744 | 22.7 |
| 4 | 3 | `search_blocks` | compound=GLOBcomp_95, limit=50, property=GLOBprop_… | 915 | KEEP ←in 2,941 | 915 | 10.4 |
| 5 | 3 | `search_blocks` | compound=GLOBcomp_95, limit=50, property=GLOBprop_… | 758 | KEEP ←in 2,914 | 758 | 10.2 |
| 6 | 1 | `L1_query` | instruction=Search for the compound 1,1,1…, purpos… | 31,304 | — | — | 114.8 |
| | | **TOTAL (6 tools)** | | **34,309** | | **3,005** | **167.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 703 | 10,464 | 1,237 | 7.0 |
| 2 | L1-worker | claudeopus46 | 21,418 | 998 | 22,416 | 1,026 | 5.6 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,479 | 23,897 | 931 | 4.6 |
| 4 | L1-worker | claudeopus46 | 3,767 | 407 | 4,174 | 505 | 4.2 |
| 5 | L1-worker | claudeopus46 | 3,767 | 583 | 4,350 | 492 | 4.0 |
| 6 | L1-worker | claudeopus46 | 21,418 | 2,411 | 23,829 | 1,644 | 8.8 |
| 7 | L1-worker | claudeopus46 | 3,767 | 3,401 | 7,168 | 1,075 | 10.0 |
| 8 | L1-worker | claudeopus46 | 3,767 | 3,331 | 7,098 | 1,181 | 9.6 |
| 9 | L1-worker | claudeopus46 | 3,767 | 3,302 | 7,069 | 1,048 | 9.8 |
| 10 | L1-worker | claudeopus46 | 21,418 | 5,713 | 27,131 | 3,976 | 22.3 |
| 11 | L1-worker | claudeopus46 | 2,320 | 3,017 | 5,337 | 787 | 5.0 |
| 12 | L1-worker | claudeopus46 | 627 | 2,897 | 3,524 | 788 | 5.5 |
| 13 | L1-worker | claudeopus46 | 2,543 | 4,136 | 6,679 | 2,872 | 10.4 |
| 14 | L1-worker | claudeopus46 | 787 | 33,912 | 34,699 | 501 | 6.0 |
| 15 | L0-main | claudeopus46 | 9,761 | 20,558 | 30,319 | 3,805 | 22.9 |
| 16 | L0-main | claudeopus46 | 2,543 | 4,065 | 6,608 | 650 | 5.3 |
| 17 | L0-main | claudeopus46 | 2,320 | 3,530 | 5,850 | 1,258 | 7.0 |

