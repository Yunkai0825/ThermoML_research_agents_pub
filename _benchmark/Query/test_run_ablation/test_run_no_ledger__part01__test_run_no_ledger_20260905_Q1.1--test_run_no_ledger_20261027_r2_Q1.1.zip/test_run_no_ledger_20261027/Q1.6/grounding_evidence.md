# Data grounding evidence

- generated: 2026-10-27T03:24:33
- grounding profile: current
- gate verdict: 2 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | — | NO | — | — |
| PROPblock_8 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 298.15 | PROPblock_1 + PROPblock_8 | uninspected_block | — |
| 75.1147 | PROPblock_1 + PROPblock_8 | uninspected_block | — |
| 101.325 | PROPblock_1 + PROPblock_8 | uninspected_block | — |
| 75.3165 | PROPblock_1 + PROPblock_8 | uninspected_block | — |
| 101.0 | PROPblock_1 + PROPblock_8 | uninspected_block | — |
| 75.2678 | PROPblock_1 + PROPblock_8 | uninspected_block | — |
| 101.325 | PROPblock_1 + PROPblock_8 | uninspected_block | — |
| 75.4 | PROPblock_1 + PROPblock_8 | uninspected_block | — |
| 100.0 | PROPblock_1 + PROPblock_8 | uninspected_block | — |
| 75.1 | PROPblock_8 | uninspected_block | — |
| 75.5 | PROPblock_8 | uninspected_block | — |
| 298.15 | PROPblock_8 | uninspected_block | — |
| 101.325 | PROPblock_8 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_1 + PROPblock_8: PROPblock_1 + PROPblock_8 is quoted with data values (298.15, 75.1147, 101.325, 75.3165, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_8: PROPblock_8 is quoted with data values (75.1, 75.5, 298.15, 101.325, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_