## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |
| GLOBprop_42 | Relative permittivity (various frequencies) | — |
| GLOBprop_44 | Relative permittivity (zero frequency / static dielectric constant) | — |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_1 | water | water |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find measured molar isobaric heat capacity (Cp) of pure liquid water at 25 °C (298.15 K) and atmospheric pressure (~101. → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

Multiple ThermoML data blocks report the molar isobaric heat capacity (Cp, GLOBprop_9) of pure liquid water (H₂O, GLOBcomp_1) at 298.15 K and ~101.325 kPa. Representative values include 75.1147 J/(K·mol) (GLOBlit_4832, DOI 10.1016/j.jct.2016.09.031), 75.3165 J/(K·mol) (GLOBlit_1310, DOI 10.1016/j.fluid.2013.08.005), and 75.2678 J/(K·mol) (GLOBlit_3054, DOI 10.1016/j.jct.2009.01.011). Across 10 data blocks in the 295–302 K window, reported values cluster around 75.1–75.5 J/(K·mol), with ~75.3 J/(K·mol) being the most commonly reported figure. The spread reflects differences in experimental technique, sample purity, and exact pressure conditions across laboratories.

**Answer:**

**Molar Isobaric Heat Capacity (Cp) of Pure Liquid Water at 25 °C and Atmospheric Pressure**

The ThermoML database contains multiple measured data blocks for the molar heat capacity at constant pressure (Cp, GLOBprop_9) of pure liquid water (H₂O, GLOBcomp_1) at or near 298.15 K and ~101.325 kPa. The reported values cluster around **75.1–75.5 J/(K·mol)**, consistent with the well-known accepted value for liquid water.

**Key representative data points:**

1. **GLOBlit_4832** — DOI: 10.1016/j.jct.2016.09.031, PROPblock_1  
   - Cp = **75.1147 J/(K·mol)** at exactly T = 298.15 K, P = 101.325 kPa  
   - Phase: Liquid; single data point; unary system

2. **GLOBlit_1310** — DOI: 10.1016/j.fluid.2013.08.005, PROPblock_1  
   - Cp = **75.3165 J/(K·mol)** at T = 298.15 K (lowest T in the block's 298.15–313.15 K range)  
   - Phase: Liquid; 8 data points; unary system

3. **GLOBlit_3054** — DOI: 10.1016/j.jct.2009.01.011, PROPblock_8  
   - Cp = **75.2678 J/(K·mol)** at T = 298.15 K (lowest T in the block's 298.15–373.15 K range)  
   - Phase: Liquid; 11 data points; unary system

4. **GLOBlit_7221** — DOI: 10.1021/acs.jced.7b00483, PROPblock_1  
   - Cp values starting at T = 298.15 K in the range 298.15–363.15 K  
   - Phase: Liquid; unary system

In total, 10 data blocks were found in the 295–302 K temperature window. The slight spread in reported Cp values (75.1–75.5 J/(K·mol)) reflects differences in experimental technique, sample purity, and exact pressure conditions across different laboratories and publications. The value of ~75.3 J/(K·mol) is the most commonly reported figure at 298.15 K and 0.1 MPa for liquid water.

**Conditions:** T = 298.15 K, P ≈ 101.325 kPa (1 atm), liquid phase, unary (pure) system.  
**Units:** J/(K·mol)  
**Compound:** water (H₂O), GLOBcomp_1  
**Property:** Molar heat capacity at constant pressure, GLOBprop_9

**Core claims:**
- Multiple ThermoML data blocks report the molar isobaric heat capacity (Cp) of pure liquid water at 298.15 K and ~101.325 kPa, with values clustering around 75.1–75.5 J/(K·mol).
- Representative reported values include 75.1147 J/(K·mol) (GLOBlit_4832), 75.3165 J/(K·mol) (GLOBlit_1310), and 75.2678 J/(K·mol) (GLOBlit_3054), all at T = 298.15 K and P = 101.325 kPa for the liquid phase.
- The slight spread in reported Cp values (75.1–75.5 J/(K·mol)) reflects differences in experimental technique, sample purity, and exact pressure conditions across different laboratories and publications.
- Ten data blocks were found in the 295–302 K temperature window, with ~75.3 J/(K·mol) being the most commonly reported figure at 298.15 K and 0.1 MPa for liquid water.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#1 | 「GLOBlit_4832」 | 「PROPblock_1」 | 「GLOBcomp_1」 | 「GLOBprop_9」 | 「Molar heat capacity at constant pressure of pure liquid water measured at 298.15 K and 101.325 kPa, reporting Cp = 75.1147 J/(K·mol).」 |
| WM_L1_Q1_Table#2 | 「GLOBlit_1310」 | 「PROPblock_1」 | 「GLOBcomp_1」 | 「GLOBprop_9」 | 「Molar heat capacity at constant pressure of pure liquid water over 298.15–313.15 K, with Cp = 75.3165 J/(K·mol) at 298.15 K.」 |
| WM_L1_Q1_Table#3 | 「GLOBlit_3054」 | 「PROPblock_8」 | 「GLOBcomp_1」 | 「GLOBprop_9」 | 「Molar heat capacity at constant pressure of pure liquid water over 298.15–373.15 K, with Cp = 75.2678 J/(K·mol) at 298.15 K.」 |
| WM_L1_Q1_Table#4 | 「GLOBlit_7221」 | 「PROPblock_1」 | 「GLOBcomp_1」 | 「GLOBprop_9」 | 「Molar heat capacity at constant pressure of pure liquid water starting at 298.15 K in the range 298.15–363.15 K.」 |

*Not stored here: 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.



</memory>

## User
What is the measured isobaric heat capacity of pure liquid water at 25 °C and atmospheric pressure?

## Assistant
<summary>Searching ThermoML database for molar isobaric heat capacity (GLOBprop_9) of pure liquid water at 298.15 K and atmospheric pressure.</summary>
<tool_call>L1_query(instruction=Search for proper…, id_catalog=, context=)</tool_call>

## User
<tool_result>
<subagent_answer>
### L1#1 — L1_query return

**Status:** status=success

**Summary:**

Multiple ThermoML data blocks report the molar isobaric heat capacity (Cp, GLOBprop_9) of pure liquid water (H₂O, GLOBcomp_1) at 298.15 K and ~101.325 kPa. Representative values include 75.1147 J/(K·mol) (GLOBlit_4832, DOI 10.1016/j.jct.2016.09.031), 75.3165 J/(K·mol) (GLOBlit_1310, DOI 10.1016/j.fluid.2013.08.005), and 75.2678 J/(K·mol) (GLOBlit_3054, DOI 10.1016/j.jct.2009.01.011). Across 10 data blocks in the 295–302 K window, reported values cluster around 75.1–75.5 J/(K·mol), with ~75.3 J/(K·mol) being the most commonly reported figure. The spread reflects differences in experimental technique, sample purity, and exact pressure conditions across laboratories.

**Answer:**

**Molar Isobaric Heat Capacity (Cp) of Pure Liquid Water at 25 °C and Atmospheric Pressure**

The ThermoML database contains multiple measured data blocks for the molar heat capacity at constant pressure (Cp, GLOBprop_9) of pure liquid water (H₂O, GLOBcomp_1) at or near 298.15 K and ~101.325 kPa. The reported values cluster around **75.1–75.5 J/(K·mol)**, consistent with the well-known accepted value for liquid water.

**Key representative data points:**

1. **GLOBlit_4832** — DOI: 10.1016/j.jct.2016.09.031, PROPblock_1  
   - Cp = **75.1147 J/(K·mol)** at exactly T = 298.15 K, P = 101.325 kPa  
   - Phase: Liquid; single data point; unary system

2. **GLOBlit_1310** — DOI: 10.1016/j.fluid.2013.08.005, PROPblock_1  
   - Cp = **75.3165 J/(K·mol)** at T = 298.15 K (lowest T in the block's 298.15–313.15 K range)  
   - Phase: Liquid; 8 data points; unary system

3. **GLOBlit_3054** — DOI: 10.1016/j.jct.2009.01.011, PROPblock_8  
   - Cp = **75.2678 J/(K·mol)** at T = 298.15 K (lowest T in the block's 298.15–373.15 K range)  
   - Phase: Liquid; 11 data points; unary system

4. **GLOBlit_7221** — DOI: 10.1021/acs.jced.7b00483, PROPblock_1  
   - Cp values starting at T = 298.15 K in the range 298.15–363.15 K  
   - Phase: Liquid; unary system

In total, 10 data blocks were found in the 295–302 K temperature window. The slight spread in reported Cp values (75.1–75.5 J/(K·mol)) reflects differences in experimental technique, sample purity, and exact pressure conditions across different laboratories and publications. The value of ~75.3 J/(K·mol) is the most commonly reported figure at 298.15 K and 0.1 MPa for liquid water.

**Conditions:** T = 298.15 K, P ≈ 101.325 kPa (1 atm), liquid phase, unary (pure) system.  
**Units:** J/(K·mol)  
**Compound:** water (H₂O), GLOBcomp_1  
**Property:** Molar heat capacity at constant pressure, GLOBprop_9

**Core claims:**
- Multiple ThermoML data blocks report the molar isobaric heat capacity (Cp) of pure liquid water at 298.15 K and ~101.325 kPa, with values clustering around 75.1–75.5 J/(K·mol).
- Representative reported values include 75.1147 J/(K·mol) (GLOBlit_4832), 75.3165 J/(K·mol) (GLOBlit_1310), and 75.2678 J/(K·mol) (GLOBlit_3054), all at T = 298.15 K and P = 101.325 kPa for the liquid phase.
- The slight spread in reported Cp values (75.1–75.5 J/(K·mol)) reflects differences in experimental technique, sample purity, and exact pressure conditions across different laboratories and publications.
- Ten data blocks were found in the 295–302 K temperature window, with ~75.3 J/(K·mol) being the most commonly reported figure at 298.15 K and 0.1 MPa for liquid water.

**Core ID updates:**
- add GLOBcomp_1 — water (registry: water)

#### Core blocks found — verbatim ledger

```ledger
**L1#1_Table#1_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_4832 | lit_id: 2017-gao-li-1 | doi: 10.1016/j.jct.2016.09.031
block: PROPblock_1 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: water (H2O; GLOBcomp_1; DOIcomp_4; InChIKey XLYOFNOQVPJJNP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_9
description: Molar heat capacity at constant pressure of pure liquid water measured at 298.15 K and 101.325 kPa, reporting Cp = 75.1147 J/(K·mol).

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#1_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.15–298.15 · n_unique=1 · phase=Liquid」 |
| L1#1_Table#1_Row#2 | 「variable」 | 「BLKvar_2/GLOBvar_3」 | 「Pressure, kPa」 | 「range=101.325–101.325 · n_unique=1 · phase=Liquid」 |
| L1#1_Table#1_Row#3 | 「property」 | 「BLKprop_1/GLOBprop_9」 | 「Molar heat capacity at constant pressure, J/K/mol」 | 「method=Flow calorimetry (GLOBmeas_12) · range=75.11471–75.11471 · mean=75.11471 · n=1 · phase=Liquid」 |
```

```ledger
**L1#1_Table#2_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_1310 | lit_id: 2013-was-kun-0 | doi: 10.1016/j.fluid.2013.08.005
block: PROPblock_1 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 8
compounds: water (H2O; GLOBcomp_1; DOIcomp_3; InChIKey XLYOFNOQVPJJNP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_9
description: Molar heat capacity at constant pressure of pure liquid water over 298.15–313.15 K, with Cp = 75.3165 J/(K·mol) at 298.15 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#2_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=101.0 · phase=Liquid」 |
| L1#1_Table#2_Row#2 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.15–313.15 · n_unique=4 · phase=Liquid」 |
| L1#1_Table#2_Row#3 | 「property」 | 「BLKprop_1/GLOBprop_9」 | 「Molar heat capacity at constant pressure, J/K/mol」 | 「method=Large sample (1 g) DSC (GLOBmeas_31) · range=75.316481–75.368725 · mean=75.337199 · n=8 · phase=Liquid」 |
```

```ledger
**L1#1_Table#3_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_3054 | lit_id: 2009-ano-cai-1 | doi: 10.1016/j.jct.2009.01.011
block: PROPblock_8 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 16
compounds: water (H2O; GLOBcomp_1; DOIcomp_6; InChIKey XLYOFNOQVPJJNP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_9
description: Molar heat capacity at constant pressure of pure liquid water over 298.15–373.15 K, with Cp = 75.2678 J/(K·mol) at 298.15 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#3_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=101.325 · phase=Liquid」 |
| L1#1_Table#3_Row#2 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.15–373.15 · n_unique=16 · phase=Liquid」 |
| L1#1_Table#3_Row#3 | 「property」 | 「BLKprop_1/GLOBprop_9」 | 「Molar heat capacity at constant pressure, J/K/mol」 | 「method=Small sample (50 mg) DSC (GLOBmeas_9) · range=75.26784–76.006466 · mean=75.508794 · n=16 · phase=Liquid」 |
```

```ledger
**L1#1_Table#4_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_7221 | lit_id: 2017-yi-hu-0 | doi: 10.1021/acs.jced.7b00483
block: PROPblock_1 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 14
compounds: water (H2O; GLOBcomp_1; DOIcomp_3; InChIKey XLYOFNOQVPJJNP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_9
description: Molar heat capacity at constant pressure of pure liquid water starting at 298.15 K in the range 298.15–363.15 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#4_Row#1 | 「constraint」 | 「BLKconstr_1/GLOBconstr_1」 | 「Pressure, kPa」 | 「value=100.0 · phase=Liquid」 |
| L1#1_Table#4_Row#2 | 「variable」 | 「BLKvar_1/GLOBvar_1」 | 「Temperature, K」 | 「range=298.15–363.15 · n_unique=14 · phase=Liquid」 |
| L1#1_Table#4_Row#3 | 「property」 | 「BLKprop_1/GLOBprop_9」 | 「Molar heat capacity at constant pressure, J/K/mol」 | 「method=Flow calorimetry (GLOBmeas_12) · range=75.447993–76.024482 · mean=75.61013 · n=14 · phase=Liquid」 |
```
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<reasoning>
The L1 query has returned comprehensive data on the molar isobaric heat capacity of pure liquid water at 298.15 K and atmospheric pressure. I have all the information needed to provide a complete answer. The data is already in working memory from the previous query as well. Let me compile the final answer.
</reasoning>

<answer>
## Measured Molar Isobaric Heat Capacity (Cp) of Pure Liquid Water at 25 °C and Atmospheric Pressure

The ThermoML database contains multiple independent experimental measurements of the molar heat capacity at constant pressure (Cp) of pure liquid water (H₂O) at 298.15 K (25 °C) and approximately 101.325 kPa (1 atm). Across 10 data blocks found in this temperature–pressure window, reported values cluster around **75.1–75.5 J/(K·mol)**, with **~75.3 J/(K·mol)** being the most commonly reported figure — fully consistent with the well-known accepted value for liquid water.

### Representative Data Points

| Source (DOI) | Block | Cp at 298.15 K | Pressure | Method |
|---|---|---|---|---|
| 10.1016/j.jct.2016.09.031 (GLOBlit_4832) | PROPblock_1 | **75.1147 J/(K·mol)** | 101.325 kPa | Flow calorimetry |
| 10.1016/j.fluid.2013.08.005 (GLOBlit_1310) | PROPblock_1 | **75.3165 J/(K·mol)** | 101.0 kPa | Large-sample DSC |
| 10.1016/j.jct.2009.01.011 (GLOBlit_3054) | PROPblock_8 | **75.2678 J/(K·mol)** | 101.325 kPa | Small-sample DSC |
| 10.1021/acs.jced.7b00483 (GLOBlit_7221) | PROPblock_1 | **~75.4 J/(K·mol)** (lowest T in range) | 100.0 kPa | Flow calorimetry |

### Chemistry Context

Water's unusually high molar heat capacity — roughly twice that of most small organic liquids — arises from its extensive three-dimensional hydrogen-bonding network. Absorbing heat at constant pressure must partially disrupt these cooperative O–H···O interactions, which requires significant energy beyond simple translational and rotational excitation. This makes water an exceptionally effective thermal buffer, underpinning its roles in climate regulation, biological thermoregulation, and industrial heat-transfer applications.

The slight spread in reported values (75.1–75.5 J/(K·mol)) across different laboratories reflects differences in calorimetric technique (flow calorimetry vs. DSC), sample purity, and exact pressure conditions, but all measurements are mutually consistent within typical experimental uncertainty for this property.

**Conditions:** T = 298.15 K, P ≈ 101.325 kPa, liquid phase, pure (unary) system.  
**Units:** J/(K·mol)
</answer>