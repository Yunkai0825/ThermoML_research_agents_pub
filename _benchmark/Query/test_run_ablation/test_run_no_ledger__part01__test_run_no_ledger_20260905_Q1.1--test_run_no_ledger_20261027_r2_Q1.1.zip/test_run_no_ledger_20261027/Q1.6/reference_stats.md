# Reference Stats — query-agent

**Run started:** 2026-10-27 03:22:23
**Wall time (at last flush):** 144.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 25,541 | 24,988 | 6,924 | 50,529 | 10,105 | 41.9 | claudeopus46 |
| L1-worker | 14 | 149,853 | 57,744 | 13,427 | 207,597 | 14,828 | 94.5 | claudeopus46 |
| **TOTAL** | **19** | **175,394** | **82,732** | **20,351** | **258,126** | **13,585** | **136.4** | |

**Estimated tokens:** ~64,531 input + ~5,087 output = ~69,618 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 7 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 10 | 10 | 110 |
| **TOTAL** | **2** | **8** | **2** | **1** | **10** | **10** | **110** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### Properties (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_9 |  | resolve_property_ids, search_blocks |
| GLOBprop_81 |  | resolve_property_ids |
| GLOBprop_72 |  | resolve_property_ids |
| GLOBprop_43 |  | resolve_property_ids |
| GLOBprop_63 |  | resolve_property_ids |
| GLOBprop_85 |  | resolve_property_ids |
| GLOBprop_64 |  | resolve_property_ids |

#### References (10 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_1310 |  | search_blocks |
| GLOBlit_1445 |  | search_blocks |
| GLOBlit_1986 |  | search_blocks |
| GLOBlit_2622 |  | search_blocks |
| GLOBlit_3019 |  | search_blocks |
| GLOBlit_3054 |  | search_blocks |
| GLOBlit_4832 |  | search_blocks |
| GLOBlit_7221 |  | search_blocks |
| GLOBlit_7754 |  | search_blocks |
| GLOBlit_11179 |  | search_blocks |

#### Measurements (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_31 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_12 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_132 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 7 |
| Unique References | 10 |
| Unique Measurements | 4 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Total DOIs | 10 |
| Unique parent blocks | 10 |
| Explicit block/subsystem targets | 10 |
| Subsystem targets | 0 |
| Target-matched data points | 110 |

---

## 3. DOI & Block References

**Unique DOIs:** 10  |  **Parent blocks:** 10  |  **Explicit targets:** 10  |  **Subsystems:** 0  |  **Target-matched datapoints:** 110

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2013.08.005 | 1 | 8 | unary | search_blocks |
| 10.1016/j.fluid.2014.03.017 | 1 | 28 | unary | search_blocks |
| 10.1016/j.fluid.2016.10.005 | 1 | 9 | unary | search_blocks |
| 10.1016/j.jct.2005.10.010 | 1 | 15 | unary | search_blocks |
| 10.1016/j.jct.2008.10.002 | 1 | 6 | unary | search_blocks |
| 10.1016/j.jct.2009.01.011 | 1 | 16 | unary | search_blocks |
| 10.1016/j.jct.2016.09.031 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.7b00483 | 1 | 14 | unary | search_blocks |
| 10.1021/acs.jced.8b01174 | 1 | 6 | unary | search_blocks |
| 10.1021/je800248w | 1 | 7 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2013.08.005 | PROPblock_1 | declared | 8 | unary | — | search_blocks |
| 10.1016/j.fluid.2014.03.017 | PROPblock_3 | declared | 28 | unary | — | search_blocks |
| 10.1016/j.fluid.2016.10.005 | PROPblock_2 | declared | 9 | unary | — | search_blocks |
| 10.1016/j.jct.2005.10.010 | PROPblock_1 | declared | 15 | unary | — | search_blocks |
| 10.1016/j.jct.2008.10.002 | PROPblock_1 | declared | 6 | unary | — | search_blocks |
| 10.1016/j.jct.2009.01.011 | PROPblock_8 | declared | 16 | unary | — | search_blocks |
| 10.1016/j.jct.2016.09.031 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00483 | PROPblock_1 | declared | 14 | unary | — | search_blocks |
| 10.1021/acs.jced.8b01174 | PROPblock_5 | declared | 6 | unary | — | search_blocks |
| 10.1021/je800248w | PROPblock_1 | declared | 7 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | purpose=Resolve global compound ID fo…, queries=['… | 218 | KEEP ←in 216 | 218 | 6.9 |
| 2 | 1 | `resolve_property_ids` | purpose=Confirm property ID for molar…, queries=['… | 262 | KEEP ←in 960 | 262 | 4.3 |
| 3 | 5 | `search_blocks` | compound=GLOBcomp_1, limit=20, property=GLOBprop_9… | 1,069 | KEEP ←in 5,937 | 1054 | 25.9 |
| 4 | 1 | `L1_query` | context=, id_catalog=, instruction=Search for prop… | 21,680 | — | — | 104.6 |
| | | **TOTAL (4 tools)** | | **23,229** | | **1,534** | **141.7** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 562 | 10,323 | 1,083 | 7.7 |
| 2 | L1-worker | claudeopus46 | 21,418 | 933 | 22,351 | 843 | 5.2 |
| 3 | L1-worker | claudeopus46 | 3,767 | 353 | 4,120 | 201 | 2.9 |
| 4 | L1-worker | claudeopus46 | 3,767 | 655 | 4,422 | 366 | 3.3 |
| 5 | L1-worker | claudeopus46 | 3,767 | 1,106 | 4,873 | 407 | 3.9 |
| 6 | L1-worker | claudeopus46 | 21,418 | 2,010 | 23,428 | 1,287 | 9.7 |
| 7 | L1-worker | claudeopus46 | 21,418 | 2,878 | 24,296 | 847 | 6.7 |
| 8 | L1-worker | claudeopus46 | 21,418 | 3,755 | 25,173 | 990 | 7.6 |
| 9 | L1-worker | claudeopus46 | 21,418 | 4,428 | 25,846 | 674 | 4.5 |
| 10 | L1-worker | claudeopus46 | 3,767 | 6,428 | 10,195 | 1,666 | 12.9 |
| 11 | L1-worker | claudeopus46 | 21,418 | 4,685 | 26,103 | 2,385 | 14.8 |
| 12 | L1-worker | claudeopus46 | 2,320 | 2,017 | 4,337 | 779 | 4.1 |
| 13 | L1-worker | claudeopus46 | 627 | 1,897 | 2,524 | 686 | 4.5 |
| 14 | L1-worker | claudeopus46 | 2,543 | 3,071 | 5,614 | 1,521 | 6.4 |
| 15 | L1-worker | claudeopus46 | 787 | 23,528 | 24,315 | 775 | 8.0 |
| 16 | L0-main | claudeopus46 | 9,761 | 13,701 | 23,462 | 2,502 | 16.4 |
| 17 | L0-main | claudeopus46 | 2,320 | 2,338 | 4,658 | 752 | 3.8 |
| 18 | L0-main | claudeopus46 | 2,543 | 2,732 | 5,275 | 920 | 5.1 |
| 19 | L0-main | claudeopus46 | 1,156 | 5,655 | 6,811 | 1,667 | 8.9 |

