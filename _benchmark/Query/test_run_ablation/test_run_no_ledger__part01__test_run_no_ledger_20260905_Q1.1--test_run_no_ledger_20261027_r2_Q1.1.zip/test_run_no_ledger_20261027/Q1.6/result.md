# Q1.6 — Result

**Prompt:** What is the measured isobaric heat capacity of pure liquid water at 25 °C and atmospheric pressure?

**Tool calls:** 1  |  **Time:** 274.8s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

## Measured Molar Isobaric Heat Capacity (Cp) of Pure Liquid Water at 25 °C and Atmospheric Pressure

The ThermoML database contains multiple independent experimental measurements of the molar heat capacity at constant pressure (Cp) of pure liquid water (H₂O) at 298.15 K (25 °C) and approximately 101.325 kPa (1 atm). Across 10 data blocks found in this temperature–pressure window, reported values cluster around **75.1–75.5 J/(K·mol)**, with **~75.3 J/(K·mol)** being the most commonly reported figure — fully consistent with the well-known accepted value for liquid water.

### Representative Data Points

| Source (DOI) | Block | Cp at 298.15 K | Pressure | Method |
|---|---|---|---|---|
| 10.1016/j.jct.2016.09.031 (GLOBlit_4832) | PROPblock_1 | **75.1147 J/(K·mol)** | 101.325 kPa | Flow calorimetry |
| 10.1016/j.fluid.2013.08.005 (GLOBlit_1310) | PROPblock_1 | **75.3165 J/(K·mol)** | 101.0 kPa | Large-sample DSC |
| 10.1016/j.jct.2009.01.011 (GLOBlit_3054) | PROPblock_8 | **75.2678 J/(K·mol)** | 101.325 kPa | Small-sample DSC |
| 10.1021/acs.jced.7b00483 (GLOBlit_7221) | PROPblock_1 | **~75.4 J/(K·mol)** (lowest T in range) | 100.0 kPa | Flow calorimetry |

### Chemistry Context

Water's unusually high molar heat capacity — roughly twice that of most small organic liquids — arises from its extensive three-dimensional hydrogen-bonding network. Absorbing heat at constant pressure must partially disrupt these cooperative O–H···O interactions, which requires significant energy beyond simple translational and rotational excitation. This makes water an exceptionally effective thermal buffer, underpinning its roles in climate regulation, biological thermoregulation, and industrial heat-transfer applications.

The slight spread in reported values (75.1–75.5 J/(K·mol)) across different laboratories reflects differences in calorimetric technique (flow calorimetry vs. DSC), sample purity, and exact pressure conditions, but all measurements are mutually consistent within typical experimental uncertainty for this property.

**Conditions:** T = 298.15 K, P ≈ 101.325 kPa, liquid phase, pure (unary) system.  
**Units:** J/(K·mol)

### Core claims

- Multiple independent ThermoML measurements of the molar isobaric heat capacity (Cp) of pure liquid water at 298.15 K and approximately 101.325 kPa report values clustering around 75.1–75.5 J/(K·mol), with ~75.3 J/(K·mol) being the most commonly reported figure.
- Representative reported values include 75.1147 J/(K·mol), 75.3165 J/(K·mol), 75.2678 J/(K·mol), and ~75.4 J/(K·mol) from different laboratories using flow calorimetry and DSC techniques.
- The slight spread across reported values reflects differences in calorimetric technique, sample purity, and exact pressure conditions, but all measurements are mutually consistent within typical experimental uncertainty.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_4832 | 10.1016/j.jct.2016.09.031 | PROPblock_1 |  | Provides a single-point measurement of Cp for pure liquid water at exactly 298.15 K and 101.325 kPa, reporting 75.11471 J/(K·mol) via flow calorimetry, directly cited in the answer table. |
| GLOBlit_1310 | 10.1016/j.fluid.2013.08.005 | PROPblock_1 |  | Contains 8 datapoints for Cp of pure water starting at 298.15 K and 101.0 kPa with a minimum value of 75.316481 J/(K·mol) measured by large-sample DSC, directly supporting the answer's reported value of 75.3165 J/(K·mol). |
| GLOBlit_3054 | 10.1016/j.jct.2009.01.011 | PROPblock_8 |  | Contains 16 datapoints for Cp of pure water starting at 298.15 K and 101.325 kPa with a minimum value of 75.26784 J/(K·mol) measured by small-sample DSC, directly cited in the answer as 75.2678 J/(K·mol). |
| GLOBlit_7221 | 10.1021/acs.jced.7b00483 | PROPblock_1 |  | Contains 14 datapoints for Cp of pure water starting at 298.15 K and 100.0 kPa with a minimum of 75.447993 J/(K·mol) via flow calorimetry, supporting the answer's cited value of ~75.4 J/(K·mol) at the lowest temperature in the range. |

### Suggested follow-ups

- Compare the isobaric heat capacity of liquid water at 25 °C with that of heavy water (D₂O) under the same conditions.
- Examine how the isobaric heat capacity of liquid water varies with temperature from 0 °C to 100 °C at atmospheric pressure.
- Investigate the pressure dependence of the molar heat capacity of water up to high pressures (e.g., 100 MPa).

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  }
]
```
