# Q1.3 — Result

**Prompt:** What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

**Tool calls:** 1  |  **Time:** 256.5s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

**Density of an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure**

The ThermoML database contains a measurement of the mass density of the binary liquid mixture of propan-2-ol (isopropanol) and water at near-equimolar composition:

| Quantity | Value |
|---|---|
| **Density (ρ)** | **838.8 ± 0.4 kg/m³** |
| Mole fraction x(propan-2-ol) | 0.4981 |
| Temperature | 298.15 K (25 °C) |
| Pressure | 101.0 kPa |
| Phase | Liquid |
| Measurement method | Vibrating-tube densimeter |

**Source:** DOI 10.1021/je700700f, data block PROPblock_17.

This data point comes from a set of 13 measurements spanning the full composition range. For context, here are neighboring compositions:

| x(propan-2-ol) | ρ (kg/m³) | ±U (kg/m³) |
|---|---|---|
| 0.3992 | 857.7 | 0.4 |
| **0.4981** | **838.8** | **0.4** |
| 0.5979 | 823.5 | 0.4 |

**Chemistry insight:** The density of 838.8 kg/m³ at the near-equimolar composition falls between the pure-component values — approximately 997 kg/m³ for water and approximately 781 kg/m³ for pure propan-2-ol — and decreases monotonically with increasing alcohol content across the full composition range. This system is a classic example of non-ideal mixing: propan-2-ol and water form strong hydrogen bonds, and the mixing process leads to volume contraction (negative excess volume), meaning the actual density is slightly higher than what a simple linear interpolation of the pure-component densities would predict. The expanded uncertainty of ±0.4 kg/m³ reflects the high precision achievable with modern vibrating-tube densimetry.

### Core claims

- The mass density of a near-equimolar liquid mixture of propan-2-ol and water (x(propan-2-ol) = 0.4981) at 298.15 K and 101.0 kPa is 838.8 ± 0.4 kg/m³, as measured by vibrating-tube densimetry (DOI 10.1021/je700700f).
- The density decreases monotonically with increasing propan-2-ol mole fraction across the full composition range, with neighboring values of 857.7 kg/m³ at x = 0.3992 and 823.5 kg/m³ at x = 0.5979.
- The propan-2-ol + water system exhibits non-ideal mixing with negative excess volume, meaning the measured density is slightly higher than a simple linear interpolation of the pure-component densities would predict.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11042 | 10.1021/je700700f | PROPblock_17 |  | This block provides mass density measurements for the binary propan-2-ol + water system at 298.15 K and 101.0 kPa across 13 compositions (mole fraction 0–1), with density range 780.7–997.2 kg/m³. The answer correctly reports the near-equimolar (x = 0.4981) density of 838.8 ± 0.4 kg/m³ from this block, which directly answers the question. |

### Suggested follow-ups

- Compare the measured density with ideal mixing predictions to quantify the excess molar volume at equimolar composition.
- Examine how the density of this propan-2-ol + water mixture varies with temperature at the same equimolar composition.
- Look for viscosity or refractive index data for the same system and composition to build a more complete thermophysical profile.
