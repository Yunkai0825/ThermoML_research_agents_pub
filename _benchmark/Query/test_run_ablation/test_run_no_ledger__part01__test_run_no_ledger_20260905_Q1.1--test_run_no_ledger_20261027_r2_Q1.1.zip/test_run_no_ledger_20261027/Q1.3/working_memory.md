# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find density measurements for equimolar propan-2-ol + water mixture at 25°C and atmospheric pressure → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

A ThermoML data block (DOI 10.1021/je700700f, GLOBlit_11042, PROPblock_17) reports the mass density of the binary liquid mixture propan-2-ol (GLOBcomp_6) + water (GLOBcomp_1) at near-equimolar composition. At x(propan-2-ol) = 0.4981, T = 298.15 K, and P = 101.0 kPa, the density is 838.8 ± 0.4 kg/m³, measured by vibrating-tube densimetry. The block contains 13 data points spanning the full composition range from pure water (x = 0, ρ = 997.2 kg/m³) to pure propan-2-ol (x = 1.0), with density decreasing monotonically with increasing propan-2-ol content. Neighboring points include x = 0.3992 (ρ = 857.7 ± 0.4 kg/m³) and x = 0.5979 (ρ = 823.5 ± 0.4 kg/m³). Property identifier: GLOBprop_1 (mass density).

**Answer:**

**Density of equimolar propan-2-ol + water at 25 °C and atmospheric pressure**

A ThermoML data block reports the mass density of the binary liquid mixture propan-2-ol (isopropanol) + water at the near-equimolar composition:

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *Quantity* | *Value* |
|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「**Density (ρ)**」 | 「**838.8 ± 0.4 kg/m³**」 |
| WM_L1_Q1_Table#1_Row#2 | 「Mole fraction x(propan-2-ol)」 | 「0.4981」 |
| WM_L1_Q1_Table#1_Row#3 | 「Temperature」 | 「298.15 K (fixed constraint)」 |
| WM_L1_Q1_Table#1_Row#4 | 「Pressure」 | 「101.0 kPa (fixed constraint)」 |
| WM_L1_Q1_Table#1_Row#5 | 「Phase」 | 「Liquid」 |
| WM_L1_Q1_Table#1_Row#6 | 「Measurement method」 | 「Vibrating-tube densimeter」 |

**Source:** DOI 10.1021/je700700f (GLOBlit_11042), block PROPblock_17.

The block contains 13 data points spanning the full composition range from pure water (x = 0, ρ = 997.2 kg/m³) to pure propan-2-ol (x = 1.0). Selected neighboring points for context:

**WM_L1_Q1_Table#2_(Query_L1_Q1_Answer):**

| *row_id* | *x(propan-2-ol)* | *ρ (kg/m³)* | *±U (kg/m³)* |
|---|---|---|---|
| WM_L1_Q1_Table#2_Row#1 | 「0.3992」 | 「857.7」 | 「0.4」 |
| WM_L1_Q1_Table#2_Row#2 | 「**0.4981**」 | 「**838.8**」 | 「**0.4**」 |
| WM_L1_Q1_Table#2_Row#3 | 「0.5979」 | 「823.5」 | 「0.4」 |

**Chemistry note:** The density decreases monotonically with increasing propan-2-ol content. At the near-equimolar composition (x ≈ 0.5), the density of 838.8 kg/m³ lies between the pure-component values (water ≈ 997 kg/m³, propan-2-ol ≈ 781 kg/m³), reflecting the strong hydrogen-bonding interactions and non-ideal mixing behavior characteristic of alcohol–water systems. The expanded uncertainty of ±0.4 kg/m³ indicates high-precision vibrating-tube measurements.

**Identifiers:**
- Propan-2-ol: GLOBcomp_6; Water: GLOBcomp_1
- Property: mass density, GLOBprop_1
- Literature: GLOBlit_11042, PROPblock_17

**Core claims:**
- The mass density of the equimolar liquid mixture of propan-2-ol and water (x(propan-2-ol) = 0.4981) at 298.15 K and 101.0 kPa is 838.8 ± 0.4 kg/m³, as measured by vibrating-tube densimetry and reported in DOI 10.1021/je700700f.
- Across the full composition range at 298.15 K and 101.0 kPa, the density of the propan-2-ol + water mixture decreases monotonically with increasing propan-2-ol mole fraction, from approximately 997 kg/m³ for pure water to approximately 781 kg/m³ for pure propan-2-ol.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#3 | 「GLOBlit_11042」 | 「PROPblock_17」 | 「GLOBcomp_6, GLOBcomp_1」 | 「GLOBprop_1」 | 「Mass density measurements for the binary liquid mixture propan-2-ol + water across the full composition range at 298.15 K and 101.0 kPa, providing the equimolar density of 838.8 kg/m³ at x(propan-2-ol) = 0.4981.」 |

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


