# Data grounding evidence

- generated: 2026-10-27T03:21:09
- grounding profile: current
- gate verdict: 3 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_17 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 13 | PROPblock_17 | uninspected_block | — |
| 0.3992 | PROPblock_17 | uninspected_block | — |
| 857.7 | PROPblock_17 | uninspected_block | — |
| 0.4 | PROPblock_17 | uninspected_block | — |
| 0.4981 | PROPblock_17 | uninspected_block | — |
| 838.8 | PROPblock_17 | uninspected_block | — |
| 0.4 | PROPblock_17 | uninspected_block | — |
| 0.5979 | PROPblock_17 | uninspected_block | — |
| 823.5 | PROPblock_17 | uninspected_block | — |
| 0.4 | PROPblock_17 | uninspected_block | — |
| 838.8 | PROPblock_17 | uninspected_block | — |
| 997 | PROPblock_17 | uninspected_block | — |
| 781 | PROPblock_17 | uninspected_block | — |
| 0.4 | PROPblock_17 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_17: PROPblock_17 is quoted with data values (13, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_17: PROPblock_17 is quoted with data values (0.3992, 857.7, 0.4, 0.4981, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_17: PROPblock_17 is quoted with data values (838.8, 997, 781, 0.4, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_