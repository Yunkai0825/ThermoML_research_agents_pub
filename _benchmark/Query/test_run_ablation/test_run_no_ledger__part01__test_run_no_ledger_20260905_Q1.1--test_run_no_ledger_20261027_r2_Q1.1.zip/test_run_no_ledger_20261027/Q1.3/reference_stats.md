# Reference Stats — query-agent

**Run started:** 2026-10-27 03:18:06
**Wall time (at last flush):** 192.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 25,541 | 17,003 | 4,957 | 42,544 | 8,508 | 33.3 | claudeopus46 |
| L1-worker | 19 | 239,292 | 66,708 | 22,015 | 306,000 | 16,105 | 154.4 | claudeopus46 |
| **TOTAL** | **24** | **264,833** | **83,711** | **26,972** | **348,544** | **14,522** | **187.7** | |

**Estimated tokens:** ~87,136 input + ~6,743 output = ~93,879 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 0 | 2 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 13 |
| **TOTAL** | **6** | **1** | **4** | **4** | **2** | **1** | **13** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_6 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_3 |  | resolve_ids |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 |  | resolve_ids, search_blocks |
| GLOBconstr_1 |  | resolve_ids, search_blocks |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_11042 |  | block_search_adv, search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Unique References | 1 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 13 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 13

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je700700f | 1 | 13 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je700700f | PROPblock_17 | declared | 13 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 183 | KEEP ←in 285 | 183 | 4.2 |
| 2 | 4 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 272 | KEEP ←in 395 | 272 | 4.3 |
| 3 | 4 | `resolve_ids` | entity_type=constraint, limit=5, min_score=70, pur… | 277 | KEEP ←in 328 | 277 | 4.2 |
| 4 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_6… | 1,077 | KEEP ←in 1,707 | 1061 | 22.5 |
| 5 | 9 | `search_blocks` | block_number=GLOBlit_11042::PROPblock_17, purpose=… | 1,049 | KEEP ←in 1,906 | 1049 | 10.8 |
| 6 | 1 | `L1_query` | context=Property of interest: mass de…, id_catalog… | 8,612 | — | — | 161.8 |
| | | **TOTAL (6 tools)** | | **11,470** | | **2,842** | **207.8** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 580 | 10,341 | 1,342 | 8.9 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,213 | 22,631 | 709 | 5.8 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,226 | 23,644 | 535 | 3.9 |
| 4 | L1-worker | claudeopus46 | 3,767 | 438 | 4,205 | 344 | 3.7 |
| 5 | L1-worker | claudeopus46 | 21,418 | 2,018 | 23,436 | 2,068 | 12.0 |
| 6 | L1-worker | claudeopus46 | 21,418 | 3,274 | 24,692 | 1,063 | 5.3 |
| 7 | L1-worker | claudeopus46 | 3,767 | 611 | 4,378 | 421 | 4.0 |
| 8 | L1-worker | claudeopus46 | 3,767 | 538 | 4,305 | 415 | 3.6 |
| 9 | L1-worker | claudeopus46 | 21,418 | 3,808 | 25,226 | 3,107 | 18.8 |
| 10 | L1-worker | claudeopus46 | 21,418 | 4,792 | 26,210 | 1,917 | 12.4 |
| 11 | L1-worker | claudeopus46 | 21,418 | 5,690 | 27,108 | 1,902 | 13.2 |
| 12 | L1-worker | claudeopus46 | 21,418 | 6,515 | 27,933 | 1,337 | 10.3 |
| 13 | L1-worker | claudeopus46 | 3,767 | 1,918 | 5,685 | 1,521 | 12.0 |
| 14 | L1-worker | claudeopus46 | 21,418 | 6,721 | 28,139 | 850 | 6.9 |
| 15 | L1-worker | claudeopus46 | 3,767 | 2,358 | 6,125 | 1,490 | 10.5 |
| 16 | L1-worker | claudeopus46 | 21,418 | 8,279 | 29,697 | 2,004 | 13.5 |
| 17 | L1-worker | claudeopus46 | 2,543 | 2,997 | 5,540 | 575 | 3.9 |
| 18 | L1-worker | claudeopus46 | 2,320 | 1,663 | 3,983 | 547 | 4.1 |
| 19 | L1-worker | claudeopus46 | 627 | 1,543 | 2,170 | 733 | 4.9 |
| 20 | L1-worker | claudeopus46 | 787 | 10,106 | 10,893 | 477 | 5.6 |
| 21 | L0-main | claudeopus46 | 9,761 | 9,592 | 19,353 | 1,873 | 11.7 |
| 22 | L0-main | claudeopus46 | 2,543 | 2,193 | 4,736 | 533 | 4.2 |
| 23 | L0-main | claudeopus46 | 2,320 | 1,781 | 4,101 | 712 | 4.3 |
| 24 | L0-main | claudeopus46 | 1,156 | 2,857 | 4,013 | 497 | 4.2 |

