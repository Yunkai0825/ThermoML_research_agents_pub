# Reference Stats — query-agent

**Run started:** 2026-10-27 03:17:54
**Wall time (at last flush):** 211.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 27,257 | 28,424 | 5,886 | 55,681 | 7,954 | 41.1 | claudeopus46 |
| L1-worker | 19 | 221,641 | 81,400 | 23,729 | 303,041 | 15,949 | 162.2 | claudeopus46 |
| **TOTAL** | **26** | **248,898** | **109,824** | **29,615** | **358,722** | **13,797** | **203.3** | |

**Estimated tokens:** ~89,680 input + ~7,403 output = ~97,083 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 2 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 0 | 3 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 3 | 0 | 0 |
| **TOTAL** | **4** | **2** | **2** | **3** | **3** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids |

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 |  | resolve_property_ids |
| GLOBprop_2 |  | resolve_property_ids |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |
| GLOBvar_2 |  | resolve_ids |

#### Constraints (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 |  | resolve_ids |
| GLOBconstr_1 |  | resolve_ids |
| GLOBconstr_3 |  | resolve_ids |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_9006 |  | block_search_adv |
| GLOBlit_5201 |  | block_search_adv |
| GLOBlit_220 |  | block_search_adv |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Properties | 2 |
| Unique Variables | 2 |
| Unique Constraints | 3 |
| Unique References | 3 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | purpose=Resolve compound IDs for etha…, queries=['… | 195 | KEEP ←in 278 | 195 | 4.4 |
| 2 | 2 | `resolve_property_ids` | purpose=Resolve property and variable…, queries=['… | 226 | KEEP ←in 307 | 226 | 3.8 |
| 3 | 3 | `resolve_ids` | entity_type=variable, purpose=Resolve variable IDs… | 227 | KEEP ←in 320 | 227 | 4.1 |
| 4 | 3 | `resolve_ids` | entity_type=constraint, purpose=Resolve constraint… | 322 | KEEP ←in 421 | 322 | 5.1 |
| 5 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 1,206 | DISCARD ←in 918 | 1145 | 24.8 |
| 6 | 8 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_2 AS eth',…, explanat… | 1,147 | KEEP ←in 3,285 | 1117 | 15.6 |
| 7 | 1 | `L1_query` | context=User wants the experimental d…, id_catalog… | 21,995 | — | — | 171.9 |
| | | **TOTAL (7 tools)** | | **25,318** | | **3,232** | **229.7** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 599 | 10,360 | 1,180 | 8.9 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,090 | 22,508 | 1,286 | 8.7 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,216 | 23,634 | 791 | 5.3 |
| 4 | L1-worker | claudeopus46 | 3,767 | 431 | 4,198 | 368 | 4.0 |
| 5 | L1-worker | claudeopus46 | 3,767 | 475 | 4,242 | 374 | 3.6 |
| 6 | L1-worker | claudeopus46 | 21,418 | 2,647 | 24,065 | 1,275 | 7.4 |
| 7 | L1-worker | claudeopus46 | 3,767 | 514 | 4,281 | 367 | 3.6 |
| 8 | L1-worker | claudeopus46 | 3,767 | 586 | 4,353 | 474 | 3.6 |
| 9 | L1-worker | claudeopus46 | 21,418 | 3,894 | 25,312 | 1,974 | 12.1 |
| 10 | L1-worker | claudeopus46 | 21,418 | 4,751 | 26,169 | 1,534 | 11.1 |
| 11 | L1-worker | claudeopus46 | 3,767 | 1,185 | 4,952 | 1,932 | 13.8 |
| 12 | L1-worker | claudeopus46 | 21,418 | 6,051 | 27,469 | 1,649 | 12.7 |
| 13 | L1-worker | claudeopus46 | 21,418 | 6,966 | 28,384 | 1,816 | 12.6 |
| 14 | L1-worker | claudeopus46 | 21,418 | 7,830 | 29,248 | 2,021 | 12.8 |
| 15 | L1-worker | claudeopus46 | 3,767 | 3,510 | 7,277 | 1,634 | 13.0 |
| 16 | L1-worker | claudeopus46 | 21,418 | 8,577 | 29,995 | 2,096 | 13.2 |
| 17 | L1-worker | claudeopus46 | 2,320 | 1,940 | 4,260 | 825 | 4.6 |
| 18 | L1-worker | claudeopus46 | 627 | 1,820 | 2,447 | 963 | 5.1 |
| 19 | L1-worker | claudeopus46 | 2,543 | 3,151 | 5,694 | 1,670 | 7.6 |
| 20 | L1-worker | claudeopus46 | 787 | 23,766 | 24,553 | 680 | 7.4 |
| 21 | L0-main | claudeopus46 | 9,761 | 14,023 | 23,784 | 1,361 | 10.5 |
| 22 | L0-main | claudeopus46 | 2,320 | 1,531 | 3,851 | 621 | 3.6 |
| 23 | L0-main | claudeopus46 | 2,543 | 1,962 | 4,505 | 695 | 4.8 |
| 24 | L0-main | claudeopus46 | 1,156 | 3,379 | 4,535 | 937 | 5.3 |
| 25 | L0-main | claudeopus46 | 560 | 2,937 | 3,497 | 189 | 2.4 |
| 26 | L0-main | claudeopus46 | 1,156 | 3,993 | 5,149 | 903 | 5.6 |

