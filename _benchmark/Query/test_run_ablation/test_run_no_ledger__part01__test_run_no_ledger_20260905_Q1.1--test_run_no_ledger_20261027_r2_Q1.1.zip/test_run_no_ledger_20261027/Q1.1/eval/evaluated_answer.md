# Q1.1 — Result

**Prompt:** I am preparing an equimolar ethanol + water liquid mixture at 25 °C and atmospheric pressure. What experimental density should I expect?

**[run statistics removed]**

---

## Answer

For an equimolar ethanol + water liquid mixture at 25 °C (298.15 K) and atmospheric pressure, you should expect an experimental mass density of approximately **857.6–857.7 kg/m³** (about **0.858 g/cm³**).

This value is well-supported by two independent experimental studies in the ThermoML database that agree to within ~0.1 kg/m³:

1. **Hernández et al.** (DOI: 10.1021/je060335h)  
   - Ethanol mole fraction: ~0.507  
   - Density: **~857.6 kg/m³**  

2. **Hogarth et al.** (DOI: 10.1016/j.jct.2018.02.022)  
   - Ethanol mole fraction: ~0.510  
   - Density: **~857.7 kg/m³**  

### Chemical context

This density sits between the values for the two pure components at 25 °C — pure water (~997 kg/m³) and pure ethanol (~785 kg/m³) — but it is noticeably **lower** than the simple mole-fraction-weighted average (~891 kg/m³). The difference reflects the well-known **negative excess volume** (i.e., a positive volume expansion on mixing) in the ethanol–water system. When ethanol molecules are introduced into water, they partially disrupt water's extensive three-dimensional hydrogen-bonding network. The resulting rearrangement of molecular packing leads to a net volume increase relative to ideal mixing, and hence a lower-than-expected density.

So when you prepare your 1 : 1 molar mixture, expect a density of about **0.858 g/cm³**.

### Core claims

- An equimolar ethanol + water liquid mixture at 25 °C (298.15 K) and atmospheric pressure has an experimental mass density of approximately 857.6–857.7 kg/m³ (about 0.858 g/cm³), supported by two independent ThermoML studies that agree to within ~0.1 kg/m³.
- This density is lower than the simple mole-fraction-weighted average (~891 kg/m³) of pure water (~997 kg/m³) and pure ethanol (~785 kg/m³) at 25 °C, reflecting a negative excess volume (positive volume expansion on mixing) due to disruption of water's hydrogen-bonding network by ethanol.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_9006 | 10.1021/je060335h | PROPblock_1 |  | This block contains mass density data for the binary ethanol + water system at 298.15 K and 101 kPa, covering the full mole fraction range (0.0–1.0). It directly supports the answer's reported density of ~857.6 kg/m³ at an ethanol mole fraction near 0.5. |

### Suggested follow-ups

- Compare the excess molar volume of ethanol + water at 25 °C across multiple mole fractions to map the full VE curve.
- Investigate how the density of the equimolar ethanol–water mixture changes with temperature (e.g., 15–45 °C) at atmospheric pressure.
- Look up the speed of sound or refractive index for the same equimolar mixture to cross-check structural interpretations of non-ideal mixing.

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
