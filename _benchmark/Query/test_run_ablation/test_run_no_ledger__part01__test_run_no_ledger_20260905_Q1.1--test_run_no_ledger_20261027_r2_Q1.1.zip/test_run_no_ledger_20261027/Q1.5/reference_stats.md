# Reference Stats — query-agent

**Run started:** 2026-10-27 03:18:18
**Wall time (at last flush):** 210.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 25,541 | 34,460 | 9,984 | 60,001 | 12,000 | 57.6 | claudeopus46 |
| L1-worker | 15 | 153,620 | 95,586 | 24,751 | 249,206 | 16,613 | 153.0 | claudeopus46 |
| **TOTAL** | **20** | **179,161** | **130,046** | **34,735** | **309,207** | **15,460** | **210.6** | |

**Estimated tokens:** ~77,301 input + ~8,683 output = ~85,984 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `resolve_measurement_ids` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 49 | 50 | 249 |
| `resolve_measurement_ids` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **2** | **2** | **1** | **49** | **50** | **249** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 |  | resolve_property_ids, search_blocks |

#### Measurements (28 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_2250 |  | resolve_measurement_ids |
| GLOBmeas_135 |  | resolve_measurement_ids |
| GLOBmeas_1197 |  | resolve_measurement_ids |
| GLOBmeas_704 |  | resolve_measurement_ids |
| GLOBmeas_2002 |  | resolve_measurement_ids |
| GLOBmeas_166 |  | resolve_measurement_ids |
| GLOBmeas_276 |  | resolve_measurement_ids |
| GLOBmeas_229 |  | resolve_measurement_ids |
| GLOBmeas_1194 |  | resolve_measurement_ids |
| GLOBmeas_170 |  | resolve_measurement_ids |
| GLOBmeas_340 |  | resolve_measurement_ids |
| GLOBmeas_595 |  | resolve_measurement_ids |
| GLOBmeas_604 |  | resolve_measurement_ids |
| GLOBmeas_1082 |  | resolve_measurement_ids |
| GLOBmeas_1192 |  | resolve_measurement_ids |
| GLOBmeas_1526 |  | resolve_measurement_ids |
| GLOBmeas_2001 |  | resolve_measurement_ids |
| GLOBmeas_2244 |  | resolve_measurement_ids |
| GLOBmeas_4 |  | resolve_measurement_ids, search_blocks |
| GLOBmeas_58 |  | resolve_measurement_ids |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_497 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_234 | Viscosity, Pa*s | search_blocks |

#### References (49 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8 |  | search_blocks |
| GLOBlit_267 |  | search_blocks |
| GLOBlit_288 |  | search_blocks |
| GLOBlit_349 |  | search_blocks |
| GLOBlit_359 |  | search_blocks |
| GLOBlit_499 |  | search_blocks |
| GLOBlit_1969 |  | search_blocks |
| GLOBlit_2547 |  | search_blocks |
| GLOBlit_2568 |  | search_blocks |
| GLOBlit_2580 |  | search_blocks |
| GLOBlit_2632 |  | search_blocks |
| GLOBlit_2648 |  | search_blocks |
| GLOBlit_2674 |  | search_blocks |
| GLOBlit_2680 |  | search_blocks |
| GLOBlit_2707 |  | search_blocks |
| GLOBlit_2825 |  | search_blocks |
| GLOBlit_2934 |  | search_blocks |
| GLOBlit_2944 |  | search_blocks |
| GLOBlit_3116 |  | search_blocks |
| GLOBlit_3224 |  | search_blocks |
| GLOBlit_3572 |  | search_blocks |
| GLOBlit_3711 |  | search_blocks |
| GLOBlit_3748 |  | search_blocks |
| GLOBlit_3988 |  | search_blocks |
| GLOBlit_4013 |  | search_blocks |
| GLOBlit_4060 |  | search_blocks |
| GLOBlit_4369 |  | search_blocks |
| GLOBlit_4485 |  | search_blocks |
| GLOBlit_4940 |  | search_blocks |
| GLOBlit_5074 |  | search_blocks |
| GLOBlit_5201 |  | search_blocks |
| GLOBlit_5465 |  | search_blocks |
| GLOBlit_5522 |  | search_blocks |
| GLOBlit_6540 |  | search_blocks |
| GLOBlit_6543 |  | search_blocks |
| GLOBlit_6567 |  | search_blocks |
| GLOBlit_6598 |  | search_blocks |
| GLOBlit_6791 |  | search_blocks |
| GLOBlit_6838 |  | search_blocks |
| GLOBlit_6957 |  | search_blocks |
| GLOBlit_7168 |  | search_blocks |
| GLOBlit_7178 |  | search_blocks |
| GLOBlit_7184 |  | search_blocks |
| GLOBlit_7368 |  | search_blocks |
| GLOBlit_7448 |  | search_blocks |
| GLOBlit_7648 |  | search_blocks |
| GLOBlit_7676 |  | search_blocks |
| GLOBlit_7681 |  | search_blocks |
| GLOBlit_7699 |  | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 1 |
| Unique Measurements | 28 |
| Unique References | 49 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Total DOIs | 49 |
| Unique parent blocks | 50 |
| Explicit block/subsystem targets | 50 |
| Subsystem targets | 0 |
| Target-matched data points | 249 |

---

## 3. DOI & Block References

**Unique DOIs:** 49  |  **Parent blocks:** 50  |  **Explicit targets:** 50  |  **Subsystems:** 0  |  **Target-matched datapoints:** 249

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-005-8089-2 | 1 | 23 | unary | search_blocks |
| 10.1016/j.fluid.2005.05.012 | 1 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2005.07.010 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2006.01.008 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2006.01.030 | 2 | 23 | unary | search_blocks |
| 10.1016/j.fluid.2007.03.021 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2016.08.022 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2005.04.019 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2005.06.011 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2005.07.008 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2005.10.022 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2005.12.010 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2006.03.010 | 1 | 2 | unary | search_blocks |
| 10.1016/j.jct.2006.03.018 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2006.06.008 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2007.05.004 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2008.03.013 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2008.04.006 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2009.06.023 | 1 | 11 | unary | search_blocks |
| 10.1016/j.jct.2010.03.022 | 1 | 23 | unary | search_blocks |
| 10.1016/j.jct.2012.02.027 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2012.08.024 | 1 | 7 | unary | search_blocks |
| 10.1016/j.jct.2012.10.008 | 1 | 5 | unary | search_blocks |
| 10.1016/j.jct.2013.09.006 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2013.09.044 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2013.11.026 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2015.04.027 | 1 | 5 | unary | search_blocks |
| 10.1016/j.jct.2015.08.036 | 1 | 5 | unary | search_blocks |
| 10.1016/j.jct.2016.12.036 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2017.07.022 | 1 | 7 | unary | search_blocks |
| 10.1016/j.jct.2018.02.022 | 1 | 4 | unary | search_blocks |
| 10.1016/j.jct.2019.02.019 | 1 | 4 | unary | search_blocks |
| 10.1016/j.jct.2019.04.023 | 1 | 7 | unary | search_blocks |
| 10.1021/acs.jced.5b00152 | 1 | 27 | unary | search_blocks |
| 10.1021/acs.jced.5b00162 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.5b00259 | 1 | 7 | unary | search_blocks |
| 10.1021/acs.jced.5b00365 | 1 | 7 | unary | search_blocks |
| 10.1021/acs.jced.5b01000 | 1 | 3 | unary | search_blocks |
| 10.1021/acs.jced.6b00096 | 1 | 2 | unary | search_blocks |
| 10.1021/acs.jced.6b00563 | 1 | 3 | unary | search_blocks |
| 10.1021/acs.jced.7b00267 | 1 | 9 | unary | search_blocks |
| 10.1021/acs.jced.7b00299 | 1 | 2 | unary | search_blocks |
| 10.1021/acs.jced.7b00321 | 1 | 4 | unary | search_blocks |
| 10.1021/acs.jced.7b00944 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.8b00086 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.8b00793 | 1 | 4 | unary | search_blocks |
| 10.1021/acs.jced.8b00939 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.8b00965 | 1 | 5 | unary | search_blocks |
| 10.1021/acs.jced.8b01012 | 1 | 4 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-005-8089-2 | PROPblock_1 | declared | 23 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.05.012 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.07.010 | PROPblock_9 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.01.008 | PROPblock_11 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.01.030 | PROPblock_1 | declared | 20 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.01.030 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.03.021 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2016.08.022 | PROPblock_6 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2005.04.019 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2005.06.011 | PROPblock_26 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2005.07.008 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2005.10.022 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2005.12.010 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.03.010 | PROPblock_7 | declared | 2 | unary | — | search_blocks |
| 10.1016/j.jct.2006.03.018 | PROPblock_6 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.06.008 | PROPblock_13 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2007.05.004 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2008.03.013 | PROPblock_5 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2008.04.006 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2009.06.023 | PROPblock_1 | declared | 11 | unary | — | search_blocks |
| 10.1016/j.jct.2010.03.022 | PROPblock_2 | declared | 23 | unary | — | search_blocks |
| 10.1016/j.jct.2012.02.027 | PROPblock_11 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2012.08.024 | PROPblock_4 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.jct.2012.10.008 | PROPblock_6 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.jct.2013.09.006 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2013.09.044 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.11.026 | PROPblock_17 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2015.04.027 | PROPblock_4 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.jct.2015.08.036 | PROPblock_2 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.jct.2016.12.036 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2017.07.022 | PROPblock_2 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_3 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.jct.2019.02.019 | PROPblock_6 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.jct.2019.04.023 | PROPblock_5 | declared | 7 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00152 | PROPblock_10 | declared | 27 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00162 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00259 | PROPblock_6 | declared | 7 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00365 | PROPblock_4 | declared | 7 | unary | — | search_blocks |
| 10.1021/acs.jced.5b01000 | PROPblock_12 | declared | 3 | unary | — | search_blocks |
| 10.1021/acs.jced.6b00096 | PROPblock_2 | declared | 2 | unary | — | search_blocks |
| 10.1021/acs.jced.6b00563 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00267 | PROPblock_2 | declared | 9 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00299 | PROPblock_2 | declared | 2 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00321 | PROPblock_10 | declared | 4 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00944 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00086 | PROPblock_17 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00793 | PROPblock_2 | declared | 4 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00939 | PROPblock_12 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00965 | PROPblock_4 | declared | 5 | unary | — | search_blocks |
| 10.1021/acs.jced.8b01012 | PROPblock_6 | declared | 4 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | purpose=Resolve ethanol to GLOBcomp_N, queries=['e… | 204 | KEEP ←in 222 | 204 | 4.0 |
| 2 | 2 | `resolve_property_ids` | purpose=Verify dynamic viscosity prop…, queries=['… | 235 | KEEP ←in 213 | 235 | 4.1 |
| 3 | 2 | `resolve_measurement_ids` | purpose=Resolve viscosity measurement…, queries=['… | 972 | KEEP ←in 1,417 | 972 | 12.2 |
| 4 | 4 | `search_blocks` | compound=GLOBcomp_2, limit=50, property=GLOBprop_4… | 1,153 | KEEP ←in 26,815 | 1153 | 23.0 |
| 5 | 5 | `resolve_measurement_ids` | purpose=Identify measurement method n…, queries=['… | 390 | KEEP ←in 303 | 390 | 5.3 |
| 6 | 1 | `L1_query` | context=User wants to know how viscos…, id_catalog… | 27,951 | — | — | 157.1 |
| | | **TOTAL (6 tools)** | | **30,905** | | **2,954** | **205.7** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 589 | 10,350 | 1,418 | 9.1 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,226 | 22,644 | 8,790 | 47.4 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,642 | 24,060 | 946 | 5.7 |
| 4 | L1-worker | claudeopus46 | 3,767 | 367 | 4,134 | 361 | 3.6 |
| 5 | L1-worker | claudeopus46 | 3,767 | 360 | 4,127 | 360 | 3.8 |
| 6 | L1-worker | claudeopus46 | 3,767 | 1,589 | 5,356 | 1,866 | 11.5 |
| 7 | L1-worker | claudeopus46 | 21,418 | 3,924 | 25,342 | 1,046 | 7.3 |
| 8 | L1-worker | claudeopus46 | 21,418 | 4,718 | 26,136 | 648 | 5.2 |
| 9 | L1-worker | claudeopus46 | 3,767 | 27,282 | 31,049 | 1,623 | 14.4 |
| 10 | L1-worker | claudeopus46 | 21,418 | 6,021 | 27,439 | 1,059 | 7.7 |
| 11 | L1-worker | claudeopus46 | 3,767 | 511 | 4,278 | 561 | 5.0 |
| 12 | L1-worker | claudeopus46 | 21,418 | 7,009 | 28,427 | 3,265 | 18.8 |
| 13 | L1-worker | claudeopus46 | 627 | 2,672 | 3,299 | 652 | 3.9 |
| 14 | L1-worker | claudeopus46 | 2,320 | 2,792 | 5,112 | 848 | 4.4 |
| 15 | L1-worker | claudeopus46 | 2,543 | 4,139 | 6,682 | 2,102 | 8.1 |
| 16 | L1-worker | claudeopus46 | 787 | 30,334 | 31,121 | 624 | 6.2 |
| 17 | L0-main | claudeopus46 | 9,761 | 17,724 | 27,485 | 4,328 | 25.9 |
| 18 | L0-main | claudeopus46 | 2,320 | 3,893 | 6,213 | 962 | 5.6 |
| 19 | L0-main | claudeopus46 | 2,543 | 4,314 | 6,857 | 1,131 | 6.3 |
| 20 | L0-main | claudeopus46 | 1,156 | 7,940 | 9,096 | 2,145 | 10.7 |

