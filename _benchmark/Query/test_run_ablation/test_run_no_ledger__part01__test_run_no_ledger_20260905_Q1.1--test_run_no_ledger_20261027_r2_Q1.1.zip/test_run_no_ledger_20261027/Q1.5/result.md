# Q1.5 — Result

**Prompt:** How has the viscosity of pure liquid ethanol near 25 °C been measured, and what values were reported by the different methods?

**Tool calls:** 1  |  **Time:** 411.3s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity of Pure Liquid Ethanol near 25 °C (298.15 K)

### Overview

The ThermoML database contains **50 data blocks** drawn from **47 distinct publications** that report the dynamic viscosity of pure liquid ethanol (C₂H₆O) in the liquid phase at or near 298.15 K (25 °C). This makes ethanol one of the most extensively characterized liquids for viscosity in the archive.

---

### Measurement Methods

Across these 50 blocks, two capillary-viscometry methods dominate:

| Method ID | Name | Description |
|-----------|------|-------------|
| GLOBmeas_4 | Capillary tube (Ostwald / Ubbelohde) method | The classical standard technique: a known volume of liquid flows under gravity through a precision-bore capillary, and the efflux time is converted to viscosity via calibration constants. |
| GLOBmeas_142 | CAPTUB:UFactor:4 (capillary tube variant) | A variant of the capillary tube method that applies a specific correction factor (U-factor) to the raw efflux data. |

Both are forms of **capillary viscometry**, which is the gold-standard technique for Newtonian liquids of moderate viscosity such as ethanol. The Ubbelohde design, in particular, is favored because the efflux time is independent of the sample volume, improving reproducibility.

No other measurement techniques (e.g., rotational viscometry, falling-ball, or vibrating-wire methods) appear in the database for this specific system and temperature, underscoring the dominance of capillary methods for this well-characterized reference liquid.

---

### Reported Values at 298.15 K

Representative data points at 298.15 K and 101.325 kPa from five independent studies:

| DOI | Block | Method | η (Pa·s) | η (mPa·s) |
|-----|-------|--------|----------|------------|
| 10.1016/j.fluid.2006.01.008 (GLOBlit_349) | PROPblock_11 | Capillary tube (GLOBmeas_4) | 0.001077 | 1.077 |
| 10.1016/j.fluid.2005.07.010 (GLOBlit_288) | PROPblock_9 | Capillary variant (GLOBmeas_142) | 0.001082 | 1.082 |
| 10.1016/j.fluid.2007.03.021 (GLOBlit_499) | PROPblock_3 | Capillary tube (GLOBmeas_4) | 0.001082 | 1.082 |
| 10.1016/j.jct.2005.04.019 (GLOBlit_2547) | PROPblock_4 | Capillary tube (GLOBmeas_4) | 0.001093 | 1.093 |
| 10.1016/j.jct.2005.07.008 (GLOBlit_2580) | PROPblock_3 | Capillary variant (GLOBmeas_142) | 0.001105 | 1.105 |

All measurements were performed at **T = 298.15 K** and **P = 101.325 kPa** (atmospheric pressure) in the **liquid phase**.

---

### Statistical Summary and Chemistry Insight

- **Range:** 0.001077–0.001105 Pa·s (1.077–1.105 mPa·s)
- **Spread:** ~2.5% across 47 independent laboratories
- **Consensus value:** ~1.08 mPa·s at 25 °C

The remarkably tight clustering of values reflects both the high reproducibility of capillary viscometry and the fact that ethanol is a well-defined, high-purity reference liquid. The small residual scatter arises from differences in sample purity, calibration standards, and minor instrumental variations between laboratories.

**Why is ethanol's viscosity what it is?** Ethanol's dynamic viscosity at 25 °C (~1.08 mPa·s) is notably higher than that of water (~0.89 mPa·s), despite ethanol's lower density. This is because ethanol molecules form extensive hydrogen-bonding networks through their hydroxyl (–OH) groups, while the ethyl chain contributes additional van der Waals interactions. These intermolecular forces create internal friction that resists flow. The balance between hydrogen bonding and the relatively small hydrophobic tail places ethanol's viscosity in a moderate range — higher than small non-polar solvents like acetone (~0.3 mPa·s) but much lower than polyols like glycerol (~950 mPa·s), which have multiple hydrogen-bonding sites per molecule.

### Core claims

- The ThermoML database contains 50 data blocks from 47 distinct publications reporting the dynamic viscosity of pure liquid ethanol at or near 298.15 K.
- All reported measurements used capillary viscometry methods (Ostwald/Ubbelohde or a capillary tube variant with U-factor correction); no other measurement techniques appear in the database for this system and temperature.
- At 298.15 K and 101.325 kPa, reported dynamic viscosity values range from 0.001077 to 0.001105 Pa·s (1.077–1.105 mPa·s), with a spread of ~2.5% across 47 independent laboratories and a consensus value of ~1.08 mPa·s.
- The tight clustering of values reflects the high reproducibility of capillary viscometry and the use of high-purity ethanol as a well-defined reference liquid; residual scatter is attributed to differences in sample purity, calibration standards, and minor instrumental variations.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_349 | 10.1016/j.fluid.2006.01.008 | PROPblock_11 |  | Provides dynamic viscosity of pure ethanol at 298.15 K and 101.325 kPa measured by capillary tube (Ostwald/Ubbelohde) method, reporting 0.001077 Pa·s (1.077 mPa·s), which anchors the low end of the reported range in the answer. |
| GLOBlit_288 | 10.1016/j.fluid.2005.07.010 | PROPblock_9 |  | Reports dynamic viscosity of pure ethanol at 298.15 K and 101.325 kPa as 0.001082 Pa·s using the CAPTUB:UFactor:4 capillary variant method, contributing an independent measurement to the consensus value of ~1.08 mPa·s cited in the answer. |
| GLOBlit_499 | 10.1016/j.fluid.2007.03.021 | PROPblock_3 |  | Provides dynamic viscosity of pure ethanol at 298.15 K and 101.325 kPa as 0.001082 Pa·s via capillary tube (Ostwald/Ubbelohde) method, corroborating the value from GLOBlit_288 and supporting the consensus ~1.08 mPa·s. |
| GLOBlit_2547 | 10.1016/j.jct.2005.04.019 | PROPblock_4 |  | Reports dynamic viscosity of pure ethanol at 298.15 K and 101.325 kPa as 0.001093 Pa·s (1.093 mPa·s) using capillary tube method, providing a slightly higher independent measurement that helps define the spread across laboratories. |
| GLOBlit_2580 | 10.1016/j.jct.2005.07.008 | PROPblock_3 |  | Reports dynamic viscosity of pure ethanol at 298.15 K and 101.325 kPa as 0.001105 Pa·s (1.105 mPa·s) using the CAPTUB:UFactor:4 method, anchoring the high end of the 1.077–1.105 mPa·s range cited in the answer. |

### Suggested follow-ups

- Compare the viscosity of ethanol with other short-chain alcohols (methanol, 1-propanol, 1-butanol) at 298.15 K to examine the effect of chain length on viscosity.
- Investigate how the viscosity of pure ethanol changes with temperature across the full liquid range (e.g., 278–348 K) using the available ThermoML data.
- Examine viscosity data for ethanol–water binary mixtures near 25 °C to explore the well-known viscosity maximum phenomenon.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_4",
    "registry_id": "capillary_tube_ostwald_ubbelohde_method",
    "name": "Capillary tube (Ostwald; Ubbelohde) method"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_142",
    "registry_id": "captub_ufactor_4",
    "name": "CAPTUB:UFactor:4"
  }
]
```
