# Q1.5 — Tool Trace

**Prompt:** How has the viscosity of pure liquid ethanol near 25 °C been measured, and what values were reported by the different methods?

**Summary:** 411.3s  |  2 iterations  |  1 tools

---

### Step 1: `L1_query`
- **Args:** `{"context": "...", "id_catalog": "...", "instruction": "...", "purpose": "..."}`
- **Result size:** 27,951 chars
- **Elapsed:** 157.1s

---

## Working Memory (final snapshot)

# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_2 | ethanol | ethanol |
| prop | GLOBprop_4 | viscosity_pa_s | Viscosity, Pa*s |
| meas | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method |
| meas | GLOBmeas_142 | captub_ufactor_4 | CAPTUB:UFactor:4 |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all viscosity (dynamic) measurements of pure liquid ethanol near 25 °C (298.15 K), including measurement methods an → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

The ThermoML database contains 50 data blocks from 47 distinct DOIs reporting dynamic viscosity of pure liquid ethanol (C₂H₆O; CCO) at or near 298.15 K in the liquid phase. The dominant measurement technique is capillary viscometry (Ostwald/Ubbelohde type), identified as GLOBmeas_4 and GLOBmeas_142. Representative values at 298.15 K and 101.325 kPa cluster in the range 0.001077–0.001105 Pa·s (approximately 1.08–1.11 mPa·s), consistent with the literature consensus of ~1.08 mPa·s at 25 °C. The ~2.5% spread among independent laboratories reflects high reproducibility of capillary methods for this well-characterized reference liquid.

**Answer:**

#### Dynamic Viscosity of Pure Liquid Ethanol near 25 °C (298.15 K)

##### Compound and Property
- **Compound:** Ethanol (GLOBcomp_2; C₂H₆O; SMILES: CCO)
- **Property:** Dynamic viscosity (GLOBprop_4; unit: Pa·s)
- **System type:** Unary (pure component), liquid phase

##### Data Availability
The ThermoML database contains **50 data blocks** from **47 distinct DOIs** reporting dynamic viscosity of pure liquid ethanol in the 295–301 K temperature range. All are liquid-phase measurements.

##### Measurement Methods Identified
Two primary measurement method identifiers appear across these blocks:

**WM_L1_Q1_Table#1_(Query_L1_Q1_Answer):**

| *row_id* | *Method ID* | *Name* | *Type* |
|---|---|---|---|
| WM_L1_Q1_Table#1_Row#1 | 「GLOBmeas_4」 | 「Capillary tube (Ostwald/Ubbelohde) method」 | 「Standard」 |
| WM_L1_Q1_Table#1_Row#2 | 「GLOBmeas_142」 | 「CAPTUB:UFactor:4 (capillary tube variant)」 | 「Custom」 |

Both methods are based on capillary viscometry — the Ostwald and Ubbelohde capillary tube technique is the most widely used standard method for measuring liquid viscosity in this range.

##### Representative Data Points at 298.15 K

**WM_L1_Q1_Table#2_(Query_L1_Q1_Answer):**

| *row_id* | *DOI* | *GLOBlit* | *Block* | *Method* | *η (Pa·s)* | *Conditions* |
|---|---|---|---|---|---|---|
| WM_L1_Q1_Table#2_Row#1 | 「10.1016/j.fluid.2006.01.008」 | 「GLOBlit_349」 | 「PROPblock_11」 | 「GLOBmeas_4 (Capillary tube)」 | 「0.001077」 | 「T = 298.15 K, P = 101.325 kPa」 |
| WM_L1_Q1_Table#2_Row#2 | 「10.1016/j.fluid.2005.07.010」 | 「GLOBlit_288」 | 「PROPblock_9」 | 「GLOBmeas_142 (Capillary variant)」 | 「0.001082」 | 「T = 298.15 K, P = 101.325 kPa」 |
| WM_L1_Q1_Table#2_Row#3 | 「10.1016/j.fluid.2007.03.021」 | 「GLOBlit_499」 | 「PROPblock_3」 | 「GLOBmeas_4 (Capillary tube)」 | 「0.001082」 | 「T = 298.15 K, P = 101.325 kPa」 |
| WM_L1_Q1_Table#2_Row#4 | 「10.1016/j.jct.2005.04.019」 | 「GLOBlit_2547」 | 「PROPblock_4」 | 「GLOBmeas_4 (Capillary tube)」 | 「0.001093」 | 「T = 298.15 K, P = 101.325 kPa」 |
| WM_L1_Q1_Table#2_Row#5 | 「10.1016/j.jct.2005.07.008」 | 「GLOBlit_2580」 | 「PROPblock_3」 | 「GLOBmeas_142 (Capillary variant)」 | 「0.001105」 | 「T = 298.15 K, P = 101.325 kPa」 |

##### Chemistry Insight
The reported dynamic viscosity values for pure liquid ethanol at 298.15 K cluster tightly in the range **0.001077–0.001105 Pa·s** (approximately **1.08–1.11 mPa·s**), which is consistent with the well-established literature consensus of ~1.08 mPa·s at 25 °C. The dominant measurement technique across these studies is capillary viscometry (Ostwald/Ubbelohde type), which is the classical standard method for Newtonian liquids of moderate viscosity. The small spread (~2.5%) among independent laboratories reflects the high reproducibility of capillary methods for this well-characterized reference liquid. Ethanol's viscosity at 25 °C is notably higher than that of water (~0.89 mPa·s) due to extensive hydrogen bonding in the alcohol, despite its lower molecular weight compared to many organic solvents.

**Core claims:**
- The ThermoML database contains 50 data blocks from 47 distinct DOIs reporting dynamic viscosity of pure liquid ethanol in the 295–301 K temperature range, all for the liquid phase.
- The dominant measurement technique across these studies is capillary viscometry (Ostwald/Ubbelohde type), identified by method IDs GLOBmeas_4 and GLOBmeas_142.
- At 298.15 K and 101.325 kPa, reported dynamic viscosity values for pure liquid ethanol cluster tightly in the range 0.001077–0.001105 Pa·s, with a spread of approximately 2.5% among independent laboratories.
- The tight clustering of values is consistent with the well-established literature consensus of approximately 1.08 mPa·s at 25 °C and reflects the high reproducibility of capillary methods for this well-characterized reference liquid.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#3 | 「GLOBlit_349」 | 「PROPblock_11」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure liquid ethanol at 298.15 K measured by capillary tube method (GLOBmeas_4), reporting 0.001077 Pa·s.」 |
| WM_L1_Q1_Table#4 | 「GLOBlit_288」 | 「PROPblock_9」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure liquid ethanol at 298.15 K measured by capillary tube variant method (GLOBmeas_142), reporting 0.001082 Pa·s.」 |
| WM_L1_Q1_Table#5 | 「GLOBlit_499」 | 「PROPblock_3」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure liquid ethanol at 298.15 K measured by capillary tube method (GLOBmeas_4), reporting 0.001082 Pa·s.」 |
| WM_L1_Q1_Table#6 | 「GLOBlit_2547」 | 「PROPblock_4」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure liquid ethanol at 298.15 K measured by capillary tube method (GLOBmeas_4), reporting 0.001093 Pa·s.」 |
| WM_L1_Q1_Table#7 | 「GLOBlit_2580」 | 「PROPblock_3」 | 「GLOBcomp_2」 | 「GLOBprop_4」 | 「Dynamic viscosity of pure liquid ethanol at 298.15 K measured by capillary tube variant method (GLOBmeas_142), reporting 0.001105 Pa·s.」 |

*Not stored here: 4 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.

---

**Total:** 1 tool calls  |  411.3s  |  OK
