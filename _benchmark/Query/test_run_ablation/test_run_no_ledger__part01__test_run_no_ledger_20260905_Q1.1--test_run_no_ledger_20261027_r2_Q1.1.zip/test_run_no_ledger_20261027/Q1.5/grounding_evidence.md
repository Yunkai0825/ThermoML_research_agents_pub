# Data grounding evidence

- generated: 2026-10-27T03:21:31
- grounding profile: current
- gate verdict: 2 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_11 | — | NO | — | — |
| PROPblock_3 | — | NO | — | — |
| PROPblock_4 | — | NO | — | — |
| PROPblock_9 | — | NO | — | — |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 0.001077 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 1.077 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 0.001082 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 1.082 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 0.001082 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 1.082 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 0.001093 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 1.093 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 0.001105 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 1.105 | PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 | uninspected_block | — |
| 298.15 | PROPblock_4 | uninspected_block | — |
| 101.325 | PROPblock_4 | uninspected_block | — |
| 0.001077 | PROPblock_4 | uninspected_block | — |
| 0.001105 | PROPblock_4 | uninspected_block | — |
| 1.077 | PROPblock_4 | uninspected_block | — |
| 1.105 | PROPblock_4 | uninspected_block | — |
| 47 | PROPblock_4 | uninspected_block | — |
| 1.08 | PROPblock_4 | uninspected_block | — |
| 25 | PROPblock_4 | uninspected_block | — |
| 25 | PROPblock_4 | uninspected_block | — |
| 1.08 | PROPblock_4 | uninspected_block | — |
| 0.89 | PROPblock_4 | uninspected_block | — |
| 0.3 | PROPblock_4 | uninspected_block | — |
| 950 | PROPblock_4 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4: PROPblock_11 + PROPblock_9 + PROPblock_3 + PROPblock_4 is quoted with data values (0.001077, 1.077, 0.001082, 1.082, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_4: PROPblock_4 is quoted with data values (298.15, 101.325, 0.001077, 0.001105, …) but was never inspected in this run

## Inspections (verbatim)

_none in this run_