# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find experimental mass density of ethanol + water mixture at equimolar composition (x_ethanol = 0.5) and T = 298.15 K, a → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

Experimental mass density of the ethanol + water binary mixture at equimolar composition (x_ethanol = 0.5) and T = 298.15 K at atmospheric pressure is approximately 859 kg/m³ based on ThermoML data from multiple independent sources. Key values: 858.98 kg/m³ (DOI 10.1021/je060335h), 858.96–860.04 kg/m³ with mean ≈ 859.5 kg/m³ (DOI 10.1016/j.jct.2018.02.022), and 859.3–882.0 kg/m³ with mean ≈ 871 kg/m³ (DOI 10.1016/j.fluid.2004.11.019, wider range likely reflecting additional composition or pressure variation). The two tightest-constrained sources agree at ≈859 kg/m³. This value is consistent with non-ideal mixing behavior: the equimolar mixture is denser than ideal mole-fraction-weighted mixing of pure ethanol (ρ ≈ 785 kg/m³) and pure water (ρ ≈ 997 kg/m³) would predict, reflecting strong hydrogen-bonding interactions and volume contraction. Best estimate: ρ ≈ 859.0 kg/m³ at x_ethanol = 0.5, T = 298.15 K, ~1 atm.

**Answer:**

Experimental mass density of the ethanol + water binary mixture at equimolar composition (x_ethanol = 0.5) and T = 298.15 K (25 °C) at atmospheric pressure is approximately **859 kg/m³**, based on ThermoML data from multiple independent sources:

1. **ρ = 858.98 kg/m³** — DOI: 10.1021/je060335h (GLOBlit_9006, PROPblock_1). Single data point at exactly x_ethanol = 0.5, T = 298.15 K.

2. **ρ = 858.96–860.04 kg/m³ (mean ≈ 859.5 kg/m³)** — DOI: 10.1016/j.jct.2018.02.022 (GLOBlit_5201, PROPblock_19). Two data points near x_ethanol = 0.5.

3. **ρ = 859.3–882.0 kg/m³ (mean ≈ 871 kg/m³)** — DOI: 10.1016/j.fluid.2004.11.019 (GLOBlit_220, PROPblock_2). Five matched points; the wider range likely reflects additional composition or pressure variation within the block.

The two tightest-constrained sources are in excellent agreement at **≈859 kg/m³**. This value is consistent with the well-known non-ideal mixing behavior of ethanol and water: the equimolar mixture is denser than what ideal mixing of pure ethanol (ρ ≈ 785 kg/m³) and pure water (ρ ≈ 997 kg/m³) would predict on a mole-fraction-weighted basis, reflecting the strong hydrogen-bonding interactions and volume contraction characteristic of this system.

**Best estimate from ThermoML data: ρ ≈ 859.0 kg/m³** at x_ethanol = 0.5, T = 298.15 K, ~1 atm.

**Core claims:**
- The experimental mass density of the ethanol + water binary mixture at equimolar composition (x_ethanol = 0.5), T = 298.15 K, and atmospheric pressure is approximately 859 kg/m³, based on ThermoML data from multiple independent sources.
- The two tightest-constrained sources report ρ = 858.98 kg/m³ (DOI: 10.1021/je060335h) and ρ = 858.96–860.04 kg/m³ with mean ≈ 859.5 kg/m³ (DOI: 10.1016/j.jct.2018.02.022), which are in excellent mutual agreement.
- A third source (DOI: 10.1016/j.fluid.2004.11.019) reports a wider range of ρ = 859.3–882.0 kg/m³ (mean ≈ 871 kg/m³), likely reflecting additional composition or pressure variation within the data block.
- The equimolar mixture density reflects the well-known non-ideal mixing behavior of ethanol and water, involving strong hydrogen-bonding interactions and volume contraction.

**Core blocks found:**

**WM_L1_Q1_Blocks_(Query_L1_Q1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1_Q1_Table#1 | 「GLOBlit_9006」 | 「PROPblock_1」 | 「GLOBcomp_2, GLOBcomp_1」 | 「GLOBprop_1」 | 「Mass density of ethanol + water at x_ethanol = 0.5 and T = 298.15 K, yielding ρ = 858.98 kg/m³.」 |
| WM_L1_Q1_Table#2 | 「GLOBlit_5201」 | 「PROPblock_19」 | 「GLOBcomp_2, GLOBcomp_1」 | 「GLOBprop_1」 | 「Mass density of ethanol + water near x_ethanol = 0.5 and T = 298.15 K, yielding ρ ≈ 858.96–860.04 kg/m³.」 |
| WM_L1_Q1_Table#3 | 「GLOBlit_220」 | 「PROPblock_2」 | 「GLOBcomp_2, GLOBcomp_1」 | 「GLOBprop_1」 | 「Mass density of ethanol + water at compositions near x_ethanol = 0.5 and T = 298.15 K, yielding ρ ≈ 859.3–882.0 kg/m³.」 |

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


