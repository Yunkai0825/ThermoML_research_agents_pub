# Q1.1 — Result

**Prompt:** I am preparing an equimolar ethanol + water liquid mixture at 25 °C and atmospheric pressure. What experimental density should I expect?

**Tool calls:** 1  |  **Time:** 209.5s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

For an equimolar ethanol + water liquid mixture (x_ethanol = 0.5) at 25 °C (298.15 K) and atmospheric pressure, you should expect an experimental mass density of approximately **859 kg/m³**.

This value is supported by multiple independent experimental sources in the ThermoML database:

1. **ρ = 858.98 kg/m³** — from Hernández & Santiago (DOI: 10.1021/je060335h), measured by vibrating-tube densimetry at exactly x_ethanol = 0.5 and T = 298.15 K, P = 101.0 kPa.

2. **ρ ≈ 859.0–860.0 kg/m³ (mean ≈ 859.5 kg/m³)** — from Hogarth et al. (DOI: 10.1016/j.jct.2018.02.022), also by vibrating-tube densimetry, with two data points near x_ethanol = 0.5 at T = 298.15 K.

3. **ρ ≈ 859–882 kg/m³** — from Pecar & Doleček (DOI: 10.1016/j.fluid.2004.11.019). This source covers a wide pressure range (0.1–400 MPa), so the broader spread reflects high-pressure measurements; the atmospheric-pressure value is consistent with the other two sources at ~859 kg/m³.

The two best-constrained sources agree to within 0.5 kg/m³, giving high confidence in the value.

### Why is the density what it is?

This result reflects the well-known **non-ideal mixing** of ethanol and water. If the two pure liquids mixed ideally (simple mole-fraction-weighted average), you would predict a density around 880–890 kg/m³ based on pure ethanol (ρ ≈ 785 kg/m³) and pure water (ρ ≈ 997 kg/m³). The actual density of ~859 kg/m³ is somewhat lower than a simple mass-weighted average but notably reflects significant **volume contraction** upon mixing — the mixture volume is smaller than the sum of the pure-component volumes. This contraction arises from strong **hydrogen-bonding interactions** between ethanol and water molecules, which pack more efficiently together than in the pure liquids. The ethanol–water system is one of the classic examples of negative excess volume (Vᴱ < 0) in physical chemistry.

**Bottom line: expect ρ ≈ 859 kg/m³ (0.859 g/cm³).**

### Core claims

- For an equimolar ethanol + water liquid mixture (x_ethanol = 0.5) at 298.15 K and atmospheric pressure, the expected experimental mass density is approximately 859 kg/m³.
- This value is supported by multiple independent ThermoML sources: 858.98 kg/m³ from Hernández & Santiago and a mean of approximately 859.5 kg/m³ from Hogarth et al., agreeing to within 0.5 kg/m³.
- The density reflects non-ideal mixing of ethanol and water, with negative excess volume (Vᴱ < 0) arising from strong hydrogen-bonding interactions that cause volume contraction upon mixing.

**Confidence:** high

### Suggested follow-ups

- Investigate the excess molar volume (Vᴱ) of ethanol + water at x_ethanol = 0.5 and 298.15 K to quantify the non-ideal mixing behavior.
- Compare the density at other mole fractions (e.g., x_ethanol = 0.1, 0.3, 0.7, 0.9) to map the full composition dependence at 25 °C.
- Examine how the density of this equimolar mixture changes with temperature (e.g., 15–50 °C) at atmospheric pressure.
