# Reference Stats — query-agent

**Run started:** 2026-10-27 03:40:23
**Wall time (at last flush):** 149.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 26,101 | 25,148 | 6,293 | 51,249 | 8,541 | 43.5 | claudeopus46 |
| L1-worker | 17 | 196,456 | 61,497 | 15,711 | 257,953 | 15,173 | 111.8 | claudeopus46 |
| **TOTAL** | **23** | **222,557** | **86,645** | **22,004** | **309,202** | **13,443** | **155.3** | |

**Estimated tokens:** ~77,300 input + ~5,501 output = ~82,801 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 3 | 0 | 0 |
| **TOTAL** | **4** | **1** | **2** | **0** | **3** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 |  | resolve_property_ids |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |
| GLOBvar_2 |  | resolve_ids |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_9006 |  | block_search_adv |
| GLOBlit_5201 |  | block_search_adv |
| GLOBlit_220 |  | block_search_adv |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique Variables | 2 |
| Unique References | 3 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | purpose=Find GLOBcomp IDs for ethanol…, queries=['… | 209 | KEEP ←in 278 | 209 | 4.4 |
| 2 | 2 | `resolve_property_ids` | purpose=Confirm GLOBprop ID for mass …, queries=['… | 270 | KEEP ←in 218 | 270 | 7.1 |
| 3 | 4 | `resolve_ids` | entity_type=variable, purpose=Find GLOBvar IDs for… | 220 | KEEP ←in 320 | 220 | 3.9 |
| 4 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 882 | KEEP ←in 3,354 | 882 | 15.2 |
| 5 | 1 | `L1_query` | context=User wants the expected exper…, id_catalog… | 20,684 | — | — | 109.1 |
| | | **TOTAL (5 tools)** | | **22,265** | | **1,581** | **139.7** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,761 | 599 | 10,360 | 1,186 | 8.5 |
| 2 | L1-worker | claudeopus46 | 21,418 | 1,096 | 22,514 | 898 | 6.2 |
| 3 | L1-worker | claudeopus46 | 21,418 | 2,080 | 23,498 | 757 | 4.9 |
| 4 | L1-worker | claudeopus46 | 3,767 | 466 | 4,233 | 381 | 3.7 |
| 5 | L1-worker | claudeopus46 | 3,767 | 383 | 4,150 | 262 | 3.0 |
| 6 | L1-worker | claudeopus46 | 3,767 | 685 | 4,452 | 426 | 3.8 |
| 7 | L1-worker | claudeopus46 | 21,418 | 2,561 | 23,979 | 1,299 | 9.1 |
| 8 | L1-worker | claudeopus46 | 21,418 | 3,352 | 24,770 | 577 | 4.1 |
| 9 | L1-worker | claudeopus46 | 3,767 | 517 | 4,284 | 393 | 3.8 |
| 10 | L1-worker | claudeopus46 | 21,418 | 3,647 | 25,065 | 1,362 | 9.2 |
| 11 | L1-worker | claudeopus46 | 21,418 | 4,493 | 25,911 | 1,362 | 9.7 |
| 12 | L1-worker | claudeopus46 | 21,418 | 5,336 | 26,754 | 1,575 | 10.3 |
| 13 | L1-worker | claudeopus46 | 3,767 | 3,554 | 7,321 | 1,408 | 11.7 |
| 14 | L1-worker | claudeopus46 | 21,418 | 5,863 | 27,281 | 1,609 | 11.1 |
| 15 | L1-worker | claudeopus46 | 2,320 | 1,463 | 3,783 | 891 | 4.8 |
| 16 | L1-worker | claudeopus46 | 627 | 1,343 | 1,970 | 939 | 4.9 |
| 17 | L1-worker | claudeopus46 | 2,543 | 2,680 | 5,223 | 1,071 | 5.4 |
| 18 | L1-worker | claudeopus46 | 787 | 21,978 | 22,765 | 501 | 6.1 |
| 19 | L0-main | claudeopus46 | 9,761 | 12,230 | 21,991 | 2,295 | 16.9 |
| 20 | L0-main | claudeopus46 | 2,320 | 2,121 | 4,441 | 639 | 3.6 |
| 21 | L0-main | claudeopus46 | 2,543 | 2,552 | 5,095 | 801 | 5.5 |
| 22 | L0-main | claudeopus46 | 560 | 2,771 | 3,331 | 181 | 2.3 |
| 23 | L0-main | claudeopus46 | 1,156 | 4,875 | 6,031 | 1,191 | 6.7 |

