# Main Agent Run — [run id removed] (Round 1)

**Question:** I am combining aqueous-alcohol measurements reported under the names “ethanol,” “ethyl alcohol,” “water,” and “aqua.” Before I compare the measurements, which canonical ThermoML compounds do these names refer to?

**[run statistics removed]**

---

## Answer

## Canonical ThermoML Compound Resolution

All four names you are using map to just **two** canonical ThermoML compounds:

| Name you used | Canonical ID | Canonical name | Molecular formula | SMILES | InChI Key |
|---|---|---|---|---|---|
| ethanol | **GLOBcomp_2** | ethanol | C₂H₆O | CCO | LFQSCWFLJHTTHZ-UHFFFAOYSA-N |
| ethyl alcohol | **GLOBcomp_2** | ethanol | C₂H₆O | CCO | LFQSCWFLJHTTHZ-UHFFFAOYSA-N |
| water | **GLOBcomp_1** | water | H₂O | O | XLYOFNOQVPJJNP-UHFFFAOYSA-N |
| aqua | **GLOBcomp_1** | water | H₂O | O | XLYOFNOQVPJJNP-UHFFFAOYSA-N |

### Key details

1. **"Ethanol" and "ethyl alcohol"** are exact synonyms that both resolve to the same canonical entry **GLOBcomp_2** (ethanol, C₂H₆O).

2. **"Water" and "aqua"** both refer to **GLOBcomp_1** (water, H₂O). The name "water" matches exactly in the ThermoML registry, while "aqua" does not have its own registered entry — fuzzy matching on "aqua" returns only complex coordination compounds that contain "aqua" as a substring (e.g., "diaquabis…"). Nonetheless, both names denote the same substance H₂O and should be mapped to GLOBcomp_1.

3. **CAS registry numbers are not stored** as an explicit field in ThermoML compound records. The primary unique chemical identifiers used by ThermoML are **InChI Keys** (listed in the table above). If you need CAS numbers, you can cross-reference these InChI Keys against an external registry such as PubChem or the CAS Common Chemistry API.

### Practical advice for merging your datasets

Since both synonym pairs collapse to single canonical compounds, you can safely merge all your aqueous-ethanol datasets by joining on **GLOBcomp_1** (water) and **GLOBcomp_2** (ethanol) — regardless of which name variant was used in the original source. Just be aware that "aqua" must be mapped to GLOBcomp_1 manually, as it has no direct registered entry in ThermoML.

### Core claims

- In the ThermoML registry, 'ethanol' and 'ethyl alcohol' both resolve to the same canonical compound (GLOBcomp_2, ethanol, C₂H₆O, InChI Key LFQSCWFLJHTTHZ-UHFFFAOYSA-N), and 'water' and 'aqua' both denote the same canonical compound (GLOBcomp_1, water, H₂O, InChI Key XLYOFNOQVPJJNP-UHFFFAOYSA-N), meaning all four names map to only two distinct canonical ThermoML compounds.
- 'Aqua' does not have a direct registered entry in ThermoML and must be mapped manually to GLOBcomp_1, as fuzzy matching on 'aqua' returns only complex coordination compounds containing 'aqua' as a substring.
- CAS registry numbers are not stored as an explicit field in ThermoML compound records; the primary unique chemical identifiers used are InChI Keys.
- Datasets using any of these synonym variants can be safely merged by joining on GLOBcomp_1 (water) and GLOBcomp_2 (ethanol).

**Confidence:** high

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
