1. Answers explicitly distinguish absence of aqua from stored aliases and recommended manual water mapping. Water canonical target metadata correct.

   **Your reply:** Treat manual normalization as external; verify the water target
