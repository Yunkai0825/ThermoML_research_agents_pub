1. Sparse alcohol-rich density coverage versus a full13-point298.15K scan including5interior alcohol-rich compositions. No threshold for sparse.

   **Your reply:** Unscored adequacy judgment; report the omitted scan

2. Should generic pure-solvent baselines inherit the preceding mixture-source citations, or be checked as uncited pure-system data?

   **Your reply:** A — Use independent pure-component archive records; retain unknown original attribution (Recommended)
