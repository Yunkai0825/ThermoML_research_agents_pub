1. In Main Q4.2, the table header says “P (kPa)”, but three cells say “~92 (atm)”, “~101 (atm)”, and “~101 (atm)”. The cited blocks store 92.3, 101, and 101 kPa, respectively, and the prose says “near atmospheric pressure”. Which interpretation should govern the comparisons?

   **Your reply:** Use kPa; treat (atm) as an atmospheric-pressure note

2. Main Q4.2 says pressures exceeded 50 MPa “and even then” density fell to ~53 kg/m³. The cited block does store 52.89 kg/m³, but at 6.99 MPa. Should ~53 be checked as the study-wide minimum, consistent with the earlier “as low as” wording, or as a value specifically above 50 MPa?

   **Your reply:** Check the study-wide minimum and retain the wording caveat
