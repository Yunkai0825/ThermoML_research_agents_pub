1. Approximate peak composition bands: containment of measured coordinate under display bounds versus interval endpoints matching min/max measured peak coordinates. Reviewers used differing interpretations; H12 explicitly addressed property magnitudes.

   **Your reply:** Check peak containment; record actual coordinates

2. Should generic pure-solvent baselines inherit the preceding mixture-source citations, or be checked as uncited pure-system data?

   **Your reply:** A — Use independent pure-component archive records; retain unknown original attribution (Recommended)
