1. Should the external-literature qualification extend to this threshold, or should it be audited as uncited empirical phase-boundary data?

   **Your reply:** A — Keep them in scope; retain archive not-found results and source-lineage gaps as appropriate (Recommended)
