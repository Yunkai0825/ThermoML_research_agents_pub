# Main Agent Run — [run id removed] (Round 1)

**Question:** What viscosity data are available for rubbing alcohol mixed with water at room temperature?

**[run statistics removed]**

---

## Answer

## Viscosity Data for Rubbing Alcohol (Isopropanol) + Water at Room Temperature

"Rubbing alcohol" is isopropanol (propan-2-ol, 2-propanol). The ThermoML database contains **dynamic viscosity** measurements for the binary mixture of isopropanol + water near room temperature.

### Source

- **Literature ID:** GLOBlit_5585
- **DOI:** 10.1016/j.jct.2019.105880
- **Data block:** PROPblock_12
- **Method:** Falling/rolling sphere viscometry
- **Phase:** Liquid
- **Pressure:** 100 kPa
- **Full temperature range in block:** 288.15–303.15 K (12 data points total)
- **Composition range:** Mass fraction of isopropanol from 0.1 to 0.3

### Data at Room Temperature (293–298 K)

Six data points fall within the standard "room temperature" window:

| Temperature (K) | Mass fraction of isopropanol | Dynamic Viscosity (Pa·s) |
|:---:|:---:|:---:|
| 293.15 | 0.1 | 0.001633 |
| 293.15 | 0.2 | 0.002485 |
| 293.15 | 0.3 | 0.003172 |
| 298.15 | 0.1 | 0.001395 |
| 298.15 | 0.2 | 0.002045 |
| 298.15 | 0.3 | 0.002555 |

All measurements at 100.0 kPa in the liquid phase.

### Additional Inspected Data Points

The full block also includes data at the boundary temperatures:

| Temperature (K) | Mass fraction of isopropanol | Dynamic Viscosity (Pa·s) |
|:---:|:---:|:---:|
| 288.15 | 0.1 | 0.001936 |
| 288.15 | 0.3 | 0.004014 |
| 303.15 | 0.1 | 0.001208 |

### Key Observations

1. **Viscosity increases with isopropanol content** across the 0.1–0.3 mass-fraction range. At 293.15 K, the viscosity nearly doubles from 0.001633 Pa·s (w = 0.1) to 0.003172 Pa·s (w = 0.3). This reflects the strong hydrogen-bonding interactions between isopropanol and water molecules, which progressively increase internal friction as more alcohol is added. It is well known from the general physical chemistry literature (not from this database) that the viscosity maximum for this system occurs at higher alcohol concentrations, around w ≈ 0.6–0.7; the data here capture the rising portion of that curve.

2. **Viscosity decreases with increasing temperature**, consistent with the typical Arrhenius-type behavior of liquid viscosity. For example, at w = 0.3, the viscosity drops from 0.003172 Pa·s at 293.15 K to 0.002555 Pa·s at 298.15 K — a reduction of roughly 19% for just a 5 K increase.

3. **Only dynamic viscosity** (not kinematic viscosity) was found in ThermoML for this system in this temperature range.

4. **Across the full block** (288.15–303.15 K, w = 0.1–0.3), viscosities range from 0.001208 Pa·s (at 303.15 K, w = 0.1) to 0.004014 Pa·s (at 288.15 K, w = 0.3).

### Sources
- Literature ID: GLOBlit_5585 | DOI: 10.1016/j.jct.2019.105880 | Block: PROPblock_12 | System: propan-2-ol (isopropanol) + water

---
[UNGROUNDED DATA FLAGS] The following quoted values could not be verified against any verbatim data inspection in this run and must be treated as UNVERIFIED:
- **UNINSPECTED_VALUE** PROPblock_12: 288.15 exists in PROPblock_12's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_5585::PROPblock_12", nearest={"column": "temperature_k", "value": 288.15})`
- **UNINSPECTED_VALUE** PROPblock_12: 303.15 exists in PROPblock_12's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_5585::PROPblock_12", nearest={"column": "temperature_k", "value": 303.15})`
- **UNINSPECTED_VALUE** PROPblock_12: 288.15 exists in PROPblock_12's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_5585::PROPblock_12", nearest={"column": "temperature_k", "value": 288.15})`
- **UNINSPECTED_VALUE** PROPblock_12: 0.001936 exists in PROPblock_12's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_5585::PROPblock_12", nearest={"column": "viscosity_pa_s", "value": 0.001936})`
- **UNINSPECTED_VALUE** PROPblock_12: 288.15 exists in PROPblock_12's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_5585::PROPblock_12", nearest={"column": "temperature_k", "value": 288.15})`
- **UNINSPECTED_VALUE** PROPblock_12: 0.004014 exists in PROPblock_12's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_5585::PROPblock_12", nearest={"column": "viscosity_pa_s", "value": 0.004014})`
- **UNINSPECTED_VALUE** PROPblock_12: 303.15 exists in PROPblock_12's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_5585::PROPblock_12", nearest={"column": "temperature_k", "value": 303.15})`
- **UNINSPECTED_VALUE** PROPblock_12: 0.001208 exists in PROPblock_12's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_5585::PROPblock_12", nearest={"column": "viscosity_pa_s", "value": 0.001208})`
- … and 8 more of the same kinds — PROPblock_12: 0.6, 0.7, 288.15, 303.15, 0.001208, 0.004014
Inspected so far: PROPblock_12

### Core claims

- ThermoML contains dynamic viscosity data for the isopropanol + water binary mixture from DOI 10.1016/j.jct.2019.105880 (GLOBlit_5585, PROPblock_12), measured by falling/rolling sphere viscometry in the liquid phase at 100 kPa.
- At room temperature (293.15–298.15 K) and mass fractions of isopropanol from 0.1 to 0.3, the reported dynamic viscosity ranges from 0.001395 Pa·s (298.15 K, w = 0.1) to 0.003172 Pa·s (293.15 K, w = 0.3).
- Within the 0.1–0.3 mass-fraction range, viscosity increases with increasing isopropanol content at a given temperature; at 293.15 K it rises from 0.001633 Pa·s (w = 0.1) to 0.003172 Pa·s (w = 0.3).
- Viscosity decreases with increasing temperature; at w = 0.3, it drops from 0.003172 Pa·s at 293.15 K to 0.002555 Pa·s at 298.15 K.
- Only dynamic viscosity (not kinematic viscosity) was found in ThermoML for this system in this temperature range.
- Data at 288.15 K and 303.15 K were reported but are flagged as UNVERIFIED because they were not directly inspected during the analysis run.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5585 | 10.1016/j.jct.2019.105880 | PROPblock_12 |  | This block provides dynamic viscosity (Pa·s) for the binary system propan-2-ol + water measured by falling/rolling sphere viscometry at 100 kPa, covering 288.15–303.15 K and mass fractions 0.1–0.3 (12 data points). It directly backs the answer's room-temperature viscosity data for isopropanol + water, with viscosities ranging from 0.001208 to 0.004014 Pa·s. |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
