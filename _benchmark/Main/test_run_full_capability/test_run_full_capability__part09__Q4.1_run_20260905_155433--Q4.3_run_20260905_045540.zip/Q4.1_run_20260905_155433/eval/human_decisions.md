1. Only trioxide-like compound: named candidates versus undefined broader chemical class.

   **Your reply:** Use the named candidate set

2. Ambient partial miscibility: include loweststoredLLE301.28K or293-298K.

   **Your reply:** Include 301.28 K; retain the actual stored range

3. Should the external-literature qualification extend to this threshold, or should it be audited as uncited empirical phase-boundary data?

   **Your reply:** A — Keep them in scope; retain archive not-found results and source-lineage gaps as appropriate (Recommended)
