# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.1_run_20260905_050055`

### History
- [menu:browse] {'text': 'I need to explore the `query/id_resolution` submen
- [menu:run] search_id_alignment → OK
- [menu:run] search_id_alignment → OK
- [menu:run] search_id_alignment → OK
- [menu:run] search_id_alignment → OK
