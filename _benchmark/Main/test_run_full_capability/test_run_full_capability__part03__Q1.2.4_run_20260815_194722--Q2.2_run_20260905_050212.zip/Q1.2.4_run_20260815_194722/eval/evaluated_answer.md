# Main Agent Run — [run id removed] (Round 1)

**Question:** Near 25 °C, give me a Redlich–Kister correlation for the viscosity of liquid water + ethylene glycol using a single state-aligned composition series. State the selected temperature, pressure, composition basis, and viscosity basis, then report the equation, polynomial order, coefficients with units, R², RMSE, and composition range.

**[run statistics removed]**

---

## Answer

## Redlich–Kister Correlation for the Dynamic Viscosity of Water + Ethylene Glycol at 298.15 K

### System & Conditions

| Parameter | Value |
|---|---|
| **System** | Water + 1,2-ethanediol (ethylene glycol), binary liquid |
| **Temperature** | 298.15 K (25.00 °C) |
| **Pressure** | 92.3 kPa |
| **Composition basis** | Mole fraction of 1,2-ethanediol, *x*₁ (single state-aligned series, 21 unique compositions from *x*₁ = 0 to 1) |
| **Viscosity basis** | Dynamic viscosity, η (Pa·s) |
| **Data points** | 19 mixture compositions + 2 pure-component endpoints = 21 points |
| **Measurement method** | Concentric cylinders viscometry |

### Pure-Component Endpoint Viscosities

| Component | η\* (Pa·s) |
|---|---|
| 1,2-Ethanediol (*x*₁ = 1) | 0.016223 |
| Water (*x*₁ = 0) | 0.00089689 |

### Mixing Rule & Redlich–Kister Equation

Because the dynamic viscosity spans nearly two orders of magnitude across the composition range (from ~0.9 × 10⁻³ to ~16 × 10⁻³ Pa·s), the **Arrhenius (logarithmic) mixing rule** is employed. The Redlich–Kister excess term is applied in ln η space:

$$\ln\eta = x_1 \ln\eta_1^{*} + (1 - x_1)\ln\eta_2^{*} \;+\; x_1(1 - x_1)\sum_{k=0}^{n} A_k\,(2x_1 - 1)^k$$

where *x*₁ is the mole fraction of 1,2-ethanediol, η₁\* = 0.016223 Pa·s (pure ethylene glycol), and η₂\* = 0.00089689 Pa·s (pure water).

### BIC-Selected Polynomial Order: 3

The Bayesian Information Criterion (BIC) selects **order 3** as optimal. Orders 4 and 5 offer negligible improvement in R² and RMSE while incurring a parameter-count penalty.

### Fitted Coefficients

| Coefficient | Value (dimensionless) |
|---|---|
| A₀ | +2.39674 |
| A₁ | −1.04444 |
| A₂ | +0.668173 |
| A₃ | −0.3209 |

The coefficients are dimensionless because the Redlich–Kister polynomial acts on ln η (also dimensionless).

### Fit Quality

| Metric | Value |
|---|---|
| R² | 0.999940 |
| RMSE | 0.001320 (in ln η space) |
| BIC | −240.17 |

### Model Selection Summary

| Order | BIC | R² | RMSE |
|---|---|---|---|
| 0 | −90.89 | 0.7516 | 0.08465 |
| 1 | −141.05 | 0.9848 | 0.02092 |
| 2 | −194.71 | 0.9992 | 0.00472 |
| **3** | **−240.17** | **0.9999** | **0.00132** |
| 4 | −237.59 | 0.9999 | 0.00131 |
| 5 | −234.83 | 0.9999 | 0.00130 |

### Composition Range

The correlation covers the **full mole-fraction range** of 1,2-ethanediol: *x*₁ = 0 (pure water) to *x*₁ = 1 (pure ethylene glycol), with 19 intermediate mixture compositions.

### Representative Data Points (298.15 K, from inspected block)

| *x*₁ (1,2-ethanediol) | η (Pa·s) |
|---|---|
| 0 (pure water) | 0.00089689 |
| 0.2072 | 0.0028109 |
| 0.4446 | 0.0060624 |
| 1.0 (pure EG) | 0.016223 |

### Chemistry Insight

The large, positive A₀ coefficient (+2.40) confirms a strong **positive deviation** of viscosity from the Arrhenius ideal-mixing baseline. This is characteristic of the water–ethylene glycol system: the two hydroxyl groups of ethylene glycol form an extensive hydrogen-bonding network with water, creating transient supramolecular structures that resist flow more than either pure component would predict. The asymmetry captured by A₁ (−1.04) and higher-order terms reflects the fact that the viscosity enhancement peaks on the ethylene-glycol-rich side, consistent with the stoichiometry of the dominant hydrogen-bonding complexes.

### Sources

- **Literature ID:** GLOBlit_5201 | **DOI:** 10.1016/j.jct.2018.02.022 | **Block:** PROPblock_24 — Binary viscosity data for water + 1,2-ethanediol across the full mole-fraction range at multiple temperatures including 298.15 K, measured by concentric cylinders viscometry at 92.3 kPa. The 21 data points at 298.15 K were used for the Redlich–Kister fit.

### Core claims

- A Redlich–Kister correlation of order 3 (selected by BIC) in ln η space accurately describes the dynamic viscosity of the water + 1,2-ethanediol binary system at 298.15 K and 92.3 kPa over the full mole-fraction range (x₁ = 0 to 1), with fitted coefficients A₀ = +2.39674, A₁ = −1.04444, A₂ = +0.668173, A₃ = −0.3209 (dimensionless), yielding R² = 0.999940 and RMSE = 0.001320 in ln η space.
- Pure-component endpoint viscosities used are η* = 0.00089689 Pa·s for water and η* = 0.016223 Pa·s for 1,2-ethanediol, spanning nearly two orders of magnitude, motivating the use of an Arrhenius (logarithmic) mixing rule.
- The large positive A₀ coefficient (+2.39674) indicates a strong positive deviation of viscosity from the Arrhenius ideal-mixing baseline, attributed to extensive hydrogen-bonding interactions between water and ethylene glycol.
- The fit is based on 21 data points (19 mixture compositions plus 2 pure-component endpoints) from concentric cylinders viscometry measurements reported in DOI 10.1016/j.jct.2018.02.022.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | This block provides 84 binary viscosity data points for water + 1,2-ethanediol measured by concentric cylinders viscometry at 92.3 kPa, covering temperatures 293.15–308.15 K and the full mole-fraction range 0–1. The 21 data points at 298.15 K (viscosity range ~0.00076–0.0206 Pa·s) were extracted and used to fit the order-3 Redlich–Kister correlation reported in the answer. |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
