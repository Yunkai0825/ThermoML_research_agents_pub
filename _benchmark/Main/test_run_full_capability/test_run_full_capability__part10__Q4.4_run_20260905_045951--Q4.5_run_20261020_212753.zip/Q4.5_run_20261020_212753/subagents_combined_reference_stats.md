# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 4 | 28,025 | 11,725 | 4,986 | 39,750 | 9,937 | 25.2 | claudeopus46 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| L1-worker | 18 | 181,253 | 91,986 | 23,066 | 273,239 | 15,179 | 143.6 | claudeopus46 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| verdict | 1 | 972 | 3,362 | 1,093 | 4,334 | 4,334 | 8.2 | claudeopus46 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| **TOTAL** | **23** | **210,250** | **107,073** | **29,145** | **317,323** | **29,450** | **177.0** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_property_ids` | 0 | 10 | 0 | 0 | 0 | 0 | 0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| `resolve_property_ids` | 0 | 20 | 0 | 0 | 0 | 0 | 0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| `search_blocks` | 27 | 13 | 9 | 7 | 18 | 50 | 2,527 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| `search_system_summary` | 11 | 0 | 0 | 0 | 94 | 319 | 16,246 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| `search_system_registry` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| **TOTAL** | **38** | **43** | **9** | **7** | **112** | **369** | **18,773** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_65 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_15 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_110 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_8 |  | resolve_property_ids, search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_36 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_46 |  | resolve_property_ids, search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_10 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_6 |  | resolve_property_ids, search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_19 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_22 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_24 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_81 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_30 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_68 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_97 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_2 |  | resolve_property_ids, search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_86 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_90 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_75 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_17 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_50 |  | resolve_property_ids | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_38 | Osmotic coefficient | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_37 | Molar conductivity, S*m2/mol | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_14 | Boiling temperature at pressure P, K | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_18 | Electrical conductivity, S/m | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_33 | (Relative) activity | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBprop_21 | Molality, mol/kg | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_679 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_716 |  | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_873 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_983 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1024 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1049 |  | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1055 |  | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1147 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1249 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1478 |  | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1535 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1659 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1712 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1888 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1904 |  | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_1996 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_2065 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_2127 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_3319 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_5444 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_4780 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_8044 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_3808 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_6743 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_5314 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_4056 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_7617 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_5887 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_9580 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_4893 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_6765 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_4176 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBlit_2540 |  | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_90 | D-glucose | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_58 | glycerol | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_1 | water | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_24 | 1,2-ethanediol | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_263 | 2,3-butanediol | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_788 | nickel monosulfate | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_517 | 1-methyl-3-octylimidazolium bromide | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_68 | 1-ethyl-3-methylimidazolium ethyl sulfate | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_1250 | N-methyl-N,N-dioctyl-1-octanaminium chloride | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_99 | 1-butyl-3-methylimidazolium chloride | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_185 | 1-hexyl-3-methylimidazolium chloride | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_273 | 1-methyl-3-octylimidazolium chloride | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_776 | 1-decyl-3-methylimidazolium chloride | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_573 | 1-pentyl-3-methylimidazolium bromide | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_261 | 3-hexyl-1-methyl-1H-imidazolium bromide | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_741 | manganese(II) sulfate | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_232 | sodium dodecyl sulfate | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_100 | choline chloride | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_252 | 1-ethyl-3-methylimidazolium thiocyanate | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_1242 | tris(2-hydroxyethyl) methylammonium methylsulfate | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_53 | 2-aminoacetic acid | search_blocks, search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_3186 | N-methyl-2-oxopyrrolidinium formate | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_2526 | N-methyl-2-oxopyrrolidinium propionate | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_23 | tetrahydrofuran | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_622 | 1H-imidazole | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_160 | tetrabutylammonium bromide | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_158 | 1-butyl-3-methylimidazolium bromide | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_94 | urea | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_873 | (S)-2-hydroxypropanoic acid | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_36 | 1-butyl-3-methylimidazolium tetrafluoroborate | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_221 | L-threonine | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBcomp_74 | (S)-2-aminopropanoic acid | search_system_summary | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_166 | Osmotic coefficient | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_49 | Molar conductivity, S*m2/mol | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_1734 | Boiling temperature at pressure P, K | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_14 | Molar conductivity, S*m2/mol | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_1 | Mass fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_684 | Mass fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_476 | Osmotic coefficient | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_279 | Molar enthalpy of dilution, kJ/mol | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_131 | Mass fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_10 | Mass fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_199 | Mole fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBmeas_395 | Molality, mol/kg | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBphase_4 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBphase_5 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBsolvent_1 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBsolvent_34 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBsolvent_184 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBsolvent_194 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBsolvent_88 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBsolvent_43 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBsolvent_386 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBsolvent_382 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBsolvent_244 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBsolvent_78 |  | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_4 | Molality, mol/kg | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBvar_1 | Temperature, K | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBvar_6 | Solvent: Molality, mol/kg | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBvar_3 | Pressure, kPa | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBvar_5 | Mass fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBvar_11 | Solvent: Amount concentration (molarity), mol/dm3 | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBvar_9 | Amount concentration (molarity), mol/dm3 | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBvar_8 | Solvent: Mole fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBvar_2 | Mole fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_2 | Temperature, K | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBconstr_1 | Pressure, kPa | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBconstr_3 | Mole fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBconstr_14 | Initial molality of solute, mol/kg | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBconstr_16 | Final molality of solute, mol/kg | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBconstr_6 | Solvent: Molality, mol/kg | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| GLOBconstr_7 | Solvent: Mole fraction | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Properties | 30 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Unique References | 33 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Unique Compounds | 32 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Unique Measurements | 16 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Unique Phases | 3 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Unique Solvents | 10 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Unique Variables | 9 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Unique Constraints | 7 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Unique parent blocks | 50 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Explicit block/subsystem targets | 50 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Subsystem targets | 0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| Target-matched data points | 2,527 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| **TOTAL** | **2,767** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.fluid.2008.11.016 | 3 | 144 | ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2009.06.008 | 3 | 378 | binary, ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2010.08.018 | 1 | 72 | binary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.06.021 | 4 | 173 | ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.10.011 | 2 | 9 | binary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.11.028 | 6 | 295 | binary, ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.12.012 | 2 | 288 | ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2012.08.024 | 5 | 153 | binary, ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2013.05.006 | 3 | 54 | binary, ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2014.05.020 | 1 | 342 | ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2014.08.017 | 1 | 7 | binary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2015.03.020 | 2 | 12 | binary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2015.05.043 | 1 | 176 | ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.02.030 | 1 | 25 | binary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.03.016 | 6 | 300 | binary, ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.11.001 | 3 | 35 | ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2017.05.024 | 4 | 19 | ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2017.12.006 | 2 | 45 | ternary | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1016/j.fluid.2008.11.016 | PROPblock_1 | declared | 48 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2008.11.016 | PROPblock_2 | declared | 48 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2008.11.016 | PROPblock_3 | declared | 48 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2009.06.008 | PROPblock_1 | declared | 42 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2009.06.008 | PROPblock_2 | declared | 42 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2009.06.008 | PROPblock_3 | declared | 294 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2010.08.018 | PROPblock_1 | declared | 72 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.06.021 | PROPblock_1 | declared | 40 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.06.021 | PROPblock_2 | declared | 45 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.06.021 | PROPblock_3 | declared | 45 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.06.021 | PROPblock_4 | declared | 43 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.10.011 | PROPblock_1 | declared | 5 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.10.011 | PROPblock_5 | declared | 4 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.11.028 | PROPblock_1 | declared | 6 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.11.028 | PROPblock_13 | declared | 62 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.11.028 | PROPblock_17 | declared | 69 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.11.028 | PROPblock_18 | declared | 78 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.11.028 | PROPblock_19 | declared | 74 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.11.028 | PROPblock_2 | declared | 6 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.12.012 | PROPblock_1 | declared | 144 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2011.12.012 | PROPblock_2 | declared | 144 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2012.08.024 | PROPblock_2 | declared | 50 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2012.08.024 | PROPblock_3 | declared | 45 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2012.08.024 | PROPblock_4 | declared | 43 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2012.08.024 | PROPblock_7 | declared | 9 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2012.08.024 | PROPblock_8 | declared | 6 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2013.05.006 | PROPblock_1 | declared | 6 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2013.05.006 | PROPblock_2 | declared | 6 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2013.05.006 | PROPblock_7 | declared | 42 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2014.05.020 | PROPblock_2 | declared | 342 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2014.08.017 | PROPblock_16 | declared | 7 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2015.03.020 | PROPblock_1 | declared | 6 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2015.03.020 | PROPblock_5 | declared | 6 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2015.05.043 | PROPblock_6 | declared | 176 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.02.030 | PROPblock_7 | declared | 25 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.03.016 | PROPblock_2 | declared | 32 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.03.016 | PROPblock_3 | declared | 4 | binary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.03.016 | PROPblock_4 | declared | 128 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.03.016 | PROPblock_5 | declared | 4 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.03.016 | PROPblock_6 | declared | 128 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.03.016 | PROPblock_7 | declared | 4 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.11.001 | PROPblock_12 | declared | 31 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.11.001 | PROPblock_13 | declared | 2 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2016.11.001 | PROPblock_14 | declared | 2 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2017.05.024 | PROPblock_6 | declared | 1 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2017.05.024 | PROPblock_7 | declared | 6 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2017.05.024 | PROPblock_8 | declared | 6 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2017.05.024 | PROPblock_9 | declared | 6 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2017.12.006 | PROPblock_8 | declared | 42 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10.1016/j.fluid.2017.12.006 | PROPblock_9 | declared | 3 | ternary | — | search_blocks | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |


## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 2 | `resolve_property_ids` | limit=10, min_score=40, purpose=Find property IDs … | 997 | KEEP ←in 1,156 | 997 | 11.6 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 2 | 3 | `search_blocks` | compound=GLOBcomp_90, limit=50, property=GLOBprop_… | 1,028 | DISCARD ←in 39 | 970 | 31.3 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 3 | 3 | `resolve_property_ids` | limit=20, min_score=30, purpose=Find combustion en… | 1,185 | KEEP ←in 2,321 | 1185 | 14.0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 4 | 4 | `search_blocks` | compound=GLOBcomp_90, limit=50, property=GLOBprop_… | 1,165 | DISCARD ←in 39 | 1107 | 16.8 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 5 | 4 | `search_blocks` | compound=GLOBcomp_90, limit=50, property=GLOBprop_… | 1,087 | DISCARD ←in 39 | 1029 | 9.5 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 6 | 4 | `search_blocks` | compound=GLOBcomp_90, limit=50, purpose=Find all a… | 872 | KEEP ←in 38,658 | 816 | 16.4 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 7 | 5 | `search_system_summary` | compound=GLOBcomp_90, include_reactions=True, limi… | 699 | KEEP ←in 1,640 | 699 | 16.5 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 8 | 5 | `search_system_registry` | block_type=reaction, compound=GLOBcomp_90, include… | 668 | DISCARD ←in 39 | 601 | 6.5 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 9 | 1 | `L1_query` | context=D-glucose is GLOBcomp_90 with…, id_catalog… | 2,715 | — | — | 183.8 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| **TOTAL** | **31** |  |  | **10,416** |  | **7,404** | **306.4** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 11,581 | 909 | 12,490 | 1,729 | 8.9 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,473 | 25,613 | 806 | 5.2 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 3 | L1-worker | claudeopus46 | 24,140 | 2,637 | 26,777 | 687 | 4.0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 4 | L1-worker | claudeopus46 | 3,767 | 1,338 | 5,105 | 1,637 | 11.4 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 5 | L1-worker | claudeopus46 | 24,140 | 3,089 | 27,229 | 1,680 | 10.1 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 6 | L1-worker | claudeopus46 | 3,767 | 461 | 4,228 | 1,397 | 9.1 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 7 | L1-worker | claudeopus46 | 3,767 | 2,538 | 6,305 | 2,353 | 12.6 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 8 | L1-worker | claudeopus46 | 24,140 | 6,033 | 30,173 | 1,534 | 7.6 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 9 | L1-worker | claudeopus46 | 3,767 | 418 | 4,185 | 1,595 | 9.3 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 10 | L1-worker | claudeopus46 | 3,767 | 415 | 4,182 | 1,531 | 8.7 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 11 | L1-worker | claudeopus46 | 3,767 | 38,964 | 42,731 | 1,845 | 14.1 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 12 | L1-worker | claudeopus46 | 24,140 | 9,974 | 34,114 | 1,672 | 10.5 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 13 | L1-worker | claudeopus46 | 3,767 | 2,090 | 5,857 | 1,339 | 8.4 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 14 | L1-worker | claudeopus46 | 3,767 | 456 | 4,223 | 764 | 5.9 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 15 | L1-worker | claudeopus46 | 24,140 | 12,140 | 36,280 | 2,504 | 13.6 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 16 | L1-worker | claudeopus46 | 2,543 | 3,079 | 5,622 | 92 | 2.0 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 17 | L1-worker | claudeopus46 | 2,320 | 1,485 | 3,805 | 528 | 3.1 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 18 | L1-worker | claudeopus46 | 627 | 1,365 | 1,992 | 661 | 3.6 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 19 | L1-worker | claudeopus46 | 787 | 4,031 | 4,818 | 441 | 4.4 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 20 | L0-main | claudeopus46 | 11,581 | 6,949 | 18,530 | 1,936 | 7.4 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 21 | L0-main | claudeopus46 | 2,320 | 1,563 | 3,883 | 577 | 3.1 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 22 | L0-main | claudeopus46 | 2,543 | 2,304 | 4,847 | 744 | 5.8 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
| 23 | verdict | claudeopus46 | 972 | 3,362 | 4,334 | 1,093 | 8.2 | Find all blocks containing energy of combustion or enthalpy  (query_runs/run_1) |
