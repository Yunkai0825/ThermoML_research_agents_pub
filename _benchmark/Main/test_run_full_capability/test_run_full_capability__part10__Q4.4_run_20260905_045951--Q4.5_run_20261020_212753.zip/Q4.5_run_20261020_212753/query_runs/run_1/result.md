# Delegated query run — result

**Question:** Find all blocks containing energy of combustion or enthalpy of combustion data for D-glucose (GLOBcomp_90, compound ID 90). Search for properties related to combustion energy.

**Iterations:** 2  |  **Elapsed:** 200.6s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

No energy of combustion or enthalpy of combustion data for D-glucose (GLOBcomp_90, C₆H₁₂O₆) was found in the ThermoML database.

A comprehensive search was conducted using multiple approaches:

1. **Property-specific searches** — D-glucose was searched against all combustion-relevant properties:
   - GLOBprop_36 (Molar enthalpy of reaction, kJ/mol) → 0 results
   - GLOBprop_24 (Specific internal energy of reaction at constant volume, J/g) → 0 results
   - GLOBprop_68 (Molar internal energy of reaction at constant volume, kJ/mol) → 0 results

2. **Broad compound search** — A search for all D-glucose data blocks returned 50 blocks from 16 DOIs, but every block contains solution/mixture properties only (mass density, viscosity, molar conductivity, osmotic coefficient, speed of sound, refractive index, etc.).

3. **Reaction block search** — A search across the system summary (319 blocks across 94 papers) and system registry with reaction block filters returned zero reaction blocks of any kind for D-glucose.

**Conclusion:** The ThermoML database contains extensive solution thermodynamic data for D-glucose — primarily in aqueous and ternary systems — but no combustion calorimetry or reaction enthalpy data is present. Combustion energy/enthalpy values for D-glucose needed to derive the standard enthalpy of formation (ΔfH°) are not available in this database.

### Core claims

- No energy of combustion or enthalpy of combustion data for D-glucose was found in the ThermoML database.
- The ThermoML database contains extensive solution thermodynamic data for D-glucose (e.g., mass density, viscosity, molar conductivity, osmotic coefficient, speed of sound, refractive index) but no combustion calorimetry or reaction enthalpy data.
- Combustion energy/enthalpy values for D-glucose needed to derive the standard enthalpy of formation (ΔfH°) are not available in this database.

**Confidence:** high

### Suggested follow-ups

- Search for combustion calorimetry data for D-glucose in dedicated thermochemical databases such as the NIST WebBook or the ATcT (Active Thermochemical Tables), as ThermoML does not contain combustion energy or enthalpy data for this compound.
- Consider searching ThermoML for the standard enthalpy of formation directly using GLOBprop_36 (Molar enthalpy of reaction) with broader reaction type filters, in case formation reaction data exists under a different classification.
- Look for combustion data for closely related sugars (e.g., fructose, sucrose) in ThermoML to assess whether any carbohydrate combustion calorimetry data exists in the database at all.
