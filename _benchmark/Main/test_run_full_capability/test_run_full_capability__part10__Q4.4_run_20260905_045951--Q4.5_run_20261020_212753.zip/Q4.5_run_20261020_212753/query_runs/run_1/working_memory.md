# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all data blocks containing energy of combustion or enthalpy of combustion data for D-glucose (GLOBcomp_90) → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: no_results · validation: PASS

**Summary:**

No energy of combustion or enthalpy of combustion data was found for D-glucose (GLOBcomp_90) in the ThermoML database. Searches covered all combustion-relevant properties (GLOBprop_36, GLOBprop_24, GLOBprop_68) and returned zero results. A broad compound search returned 50 data blocks from 16 DOIs, but all contain solution/mixture properties only (mass density, viscosity, molar conductivity, osmotic coefficient, speed of sound, refractive index, etc.). A reaction-block search also returned zero reaction blocks. The database contains extensive solution thermodynamic data for D-glucose but no combustion calorimetry or reaction enthalpy data.

**Answer:**

No energy of combustion or enthalpy of combustion data was found for D-glucose (GLOBcomp_90) in the ThermoML database.

A comprehensive search was conducted using multiple approaches:

1. **Property-specific searches** — Searched for D-glucose combined with all combustion-relevant properties:
   - GLOBprop_36 (Molar enthalpy of reaction, kJ/mol) → 0 results
   - GLOBprop_24 (Specific internal energy of reaction at constant volume, J/g) → 0 results
   - GLOBprop_68 (Molar internal energy of reaction at constant volume, kJ/mol) → 0 results

2. **Broad compound search** — A search for all D-glucose data blocks returned 50 blocks (from 16 DOIs), but every block contains solution/mixture properties only: mass density, viscosity, molar conductivity, osmotic coefficient, speed of sound, refractive index, etc.

3. **Reaction block search** — Searched the system summary (319 blocks across 94 papers) and system registry with `include_reactions=True` and `block_type=reaction`. Zero reaction blocks of any kind were found for D-glucose.

**Conclusion:** The ThermoML database contains extensive solution thermodynamic data for D-glucose (primarily in aqueous and ternary systems), but no combustion calorimetry or reaction enthalpy data is present. Combustion energy/enthalpy values for D-glucose are not available in this database.

**Core claims:**
- No energy of combustion or enthalpy of combustion data for D-glucose was found in the ThermoML database, despite comprehensive searches across combustion-relevant properties, broad compound queries, and reaction block searches.
- The ThermoML database contains extensive solution thermodynamic data for D-glucose (e.g., mass density, viscosity, molar conductivity, osmotic coefficient, speed of sound, refractive index in aqueous and ternary systems), but no combustion calorimetry or reaction enthalpy data.

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


