# Answer

**Question:** What does ThermoML report for the energy of combustion of D-glucose? Derive the standard enthalpy of formation of crystalline glucose at 298.15 K and propagate the uncertainties, using ΔfH°(CO2, g) = −393.51 ± 0.13 kJ/mol and ΔfH°(H2O, l) = −285.830 ± 0.040 kJ/mol (CODATA key values; treat these uncertainties as expanded, k = 2, like the ThermoML values).

**[run statistics removed]**

---

## Answer

## ThermoML Results for the Energy of Combustion of D-Glucose

### Database Search Outcome

A comprehensive search of the ThermoML database for energy of combustion or enthalpy of combustion data for D-glucose (GLOBcomp_90, C₆H₁₂O₆) returned **no results**.

The search covered all combustion-relevant properties in ThermoML:

- **GLOBprop_36** (Molar enthalpy of reaction, kJ/mol) — 0 results for D-glucose
- **GLOBprop_24** (Specific internal energy of reaction at constant volume, J/g) — 0 results for D-glucose
- **GLOBprop_68** (Molar internal energy of reaction at constant volume, kJ/mol) — 0 results for D-glucose

While ThermoML contains approximately 50 data blocks for D-glucose across 16 DOIs, all of these contain solution/mixture thermodynamic properties (mass density, viscosity, molar conductivity, osmotic coefficient, speed of sound, refractive index, etc.). No reaction blocks of any kind — combustion or otherwise — were found for D-glucose.

This is not surprising: classical combustion calorimetry for well-established compounds like D-glucose largely predates ThermoML's coverage period, and ThermoML primarily archives VLE, solution, and transport property data.

---

### Derivation of ΔfH°(C₆H₁₂O₆, cr) at 298.15 K — Why It Cannot Be Completed from ThermoML Alone

Because ThermoML contains no combustion energy or enthalpy data for D-glucose, the requested derivation cannot be carried out using ThermoML data. However, for completeness, the thermochemical framework is outlined below.

#### The Combustion Reaction

C₆H₁₂O₆(cr) + 6 O₂(g) → 6 CO₂(g) + 6 H₂O(l)

#### Hess's Law Relationship

ΔfH°(C₆H₁₂O₆, cr) = 6 ΔfH°(CO₂, g) + 6 ΔfH°(H₂O, l) − ΔcH°(C₆H₁₂O₆, cr)

Using the CODATA key values provided:
- ΔfH°(CO₂, g) = −393.51 ± 0.13 kJ/mol (expanded, k = 2)
- ΔfH°(H₂O, l) = −285.830 ± 0.040 kJ/mol (expanded, k = 2)

The sum of formation enthalpies of products:

6 × (−393.51) + 6 × (−285.830) = −2361.06 + (−1714.98) = −4076.04 kJ/mol

#### Uncertainty Propagation (if combustion data were available)

Converting expanded uncertainties (k = 2) to standard uncertainties:
- u(ΔfH°(CO₂)) = 0.13/2 = 0.065 kJ/mol
- u(ΔfH°(H₂O)) = 0.040/2 = 0.020 kJ/mol

For the product-side sum (6 CO₂ + 6 H₂O):

u(products) = √[(6 × 0.065)² + (6 × 0.020)²] = √[(0.390)² + (0.120)²] = √[0.15210 + 0.01440] = √0.16650 ≈ 0.408 kJ/mol

If a ThermoML combustion value ΔcH° with standard uncertainty u(ΔcH°) were available, the combined standard uncertainty would be:

u(ΔfH°) = √[u(products)² + u(ΔcH°)²] = √[(0.408)² + u(ΔcH°)²]

And the expanded uncertainty (k = 2): U(ΔfH°) = 2 × u(ΔfH°)

#### For Reference (not from ThermoML)

The well-known literature value for the standard enthalpy of combustion of α-D-glucose is approximately −2803 kJ/mol, which yields ΔfH°(C₆H₁₂O₆, cr) ≈ −1274 kJ/mol. However, **this value was not found in ThermoML and cannot be reported as a ThermoML result.**

---

### Conclusion

**ThermoML does not contain combustion calorimetry data for D-glucose.** The derivation of ΔfH°(C₆H₁₂O₆, cr) from ThermoML combustion data is therefore not possible. For combustion energy/enthalpy values for D-glucose, dedicated thermochemical databases such as the NIST Chemistry WebBook or the Active Thermochemical Tables (ATcT) should be consulted.

### Core claims

- A comprehensive search of the ThermoML database found no combustion energy or enthalpy of combustion data for D-glucose (C₆H₁₂O₆), despite the database containing approximately 50 data blocks for D-glucose across 16 DOIs covering solution/mixture thermodynamic properties.
- The derivation of ΔfH°(C₆H₁₂O₆, cr) at 298.15 K cannot be completed from ThermoML data alone because no combustion calorimetry data for D-glucose exist in the database.
- The thermochemical framework for the derivation is outlined: ΔfH°(C₆H₁₂O₆, cr) = 6 ΔfH°(CO₂, g) + 6 ΔfH°(H₂O, l) − ΔcH°(C₆H₁₂O₆, cr), with the product-side sum equal to −4076.04 kJ/mol using the provided CODATA values.
- The propagated standard uncertainty for the product-side sum (6 CO₂ + 6 H₂O) is approximately 0.408 kJ/mol, derived from standard uncertainties u(ΔfH°(CO₂)) = 0.065 kJ/mol and u(ΔfH°(H₂O)) = 0.020 kJ/mol.
- Classical combustion calorimetry data for well-established compounds like D-glucose largely predate ThermoML's coverage period, which primarily archives VLE, solution, and transport property data.

**Confidence:** high

---

<!-- END OF REVIEW COPY. Later generated run appendices are separate execution evidence. -->
