# Reference Stats — main-agent

**Run started:** 2026-10-20 21:27:53
**Wall time (at last flush):** 417.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 11 | 114,939 | 50,623 | 32,817 | 165,562 | 15,051 | 164.0 | claudeopus46 |
| L0-menu-planner | 1 | 1,013 | 1,321 | 2,139 | 2,334 | 2,334 | 11.5 | claudesonnet46 |
| L1-worker | 1 | 3,767 | 2,567 | 820 | 6,334 | 6,334 | 7.4 | claudeopus46 |
| **TOTAL** | **13** | **119,719** | **54,511** | **35,776** | **174,230** | **13,402** | **182.9** | |

**Estimated tokens:** ~43,557 input + ~8,944 output = ~52,501 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 3 | `browse_subagent_tools` | purpose=Find energy of combustion dat…, tasks=Sear… | 2,139 | — | — | 28.2 |
| 2 | 6 | `run_subagent_tool` | kwargs={'queries': ['D-glucose', 'gl…, purpose=Fin… | 389 | — | — | 8.3 |
| 3 | 7 | `run_query_agent` | context=D-glucose is GLOBcomp_90 with…, purpose=Lo… | 4,484 | — | — | 216.1 |
| | | **TOTAL (3 tools)** | | **7,012** | | **0** | **252.6** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 13,598 | 523 | 14,121 | 22,570 | 94.7 |
| 2 | L0-main | claudeopus46 | 13,598 | 1,140 | 14,738 | 670 | 4.5 |
| 3 | L0-main | claudeopus46 | 13,598 | 1,893 | 15,491 | 556 | 3.8 |
| 4 | L0-menu-planner | claudesonnet46 | 1,013 | 1,321 | 2,334 | 2,139 | 11.5 |
| 5 | L0-main | claudeopus46 | 13,598 | 3,767 | 17,365 | 957 | 5.6 |
| 6 | L0-main | claudeopus46 | 13,598 | 5,406 | 19,004 | 590 | 4.6 |
| 7 | L0-main | claudeopus46 | 13,598 | 6,116 | 19,714 | 500 | 4.2 |
| 8 | L1-worker | claudeopus46 | 3,767 | 2,567 | 6,334 | 820 | 7.4 |
| 9 | L0-main | claudeopus46 | 13,598 | 5,518 | 19,116 | 1,155 | 7.7 |
| 10 | L0-main | claudeopus46 | 13,598 | 13,117 | 26,715 | 3,293 | 19.5 |
| 11 | L0-main | claudeopus46 | 2,543 | 4,102 | 6,645 | 31 | 1.9 |
| 12 | L0-main | claudeopus46 | 2,320 | 3,463 | 5,783 | 1,159 | 7.0 |
| 13 | L0-main | claudeopus46 | 1,292 | 5,578 | 6,870 | 1,336 | 10.5 |

