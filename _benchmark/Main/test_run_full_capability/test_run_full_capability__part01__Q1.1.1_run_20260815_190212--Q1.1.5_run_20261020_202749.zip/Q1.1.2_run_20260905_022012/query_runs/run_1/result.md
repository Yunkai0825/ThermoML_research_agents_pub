# Delegated query run — result

**Question:** Find measured viscosity data for a binary mixture of methanol and water at equimolar composition (mole fraction 0.5), temperature 25 degrees Celsius (298.15 K), and atmospheric pressure (101.325 kPa). Report the viscosity value with units, the DOI, block number, and compound details.

**Iterations:** 2  |  **Elapsed:** 169.5s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity of Methanol + Water at Equimolar Composition, 298.15 K

### Result

The measured dynamic viscosity of the **methanol + water** binary mixture at near-equimolar composition is:

| Temperature (K) | x(water) | Pressure (kPa) | Dynamic Viscosity (Pa·s) |
|---|---|---|---|
| 298.15 | 0.5003 | 101.0 | 0.001309 |

**η = 0.001309 Pa·s (≈ 1.309 mPa·s or 1.309 cP)**

### Source Details

- **DOI:** 10.1016/j.jct.2007.05.004
- **Block:** PROPblock_9
- **Measurement method:** Capillary tube viscometry (CAPTUB)

### Compound Details

| Compound | Formula | InChIKey |
|---|---|---|
| Methanol | CH₄O | OKKJLVBELUTLKV-UHFFFAOYSA-N |
| Water | H₂O | XLYOFNOQVPJJNP-UHFFFAOYSA-N |

### Notes

- **Composition:** No data point exists at exactly x(methanol) = 0.5000 in this dataset. The nearest available composition is **x(water) = 0.5003**, corresponding to x(methanol) ≈ 0.4997.
- **Pressure:** The reported pressure in the dataset is **101.0 kPa**, slightly below the requested 101.325 kPa. At liquid-phase conditions this small difference has negligible effect on viscosity.
- **Uncertainty:** No explicit uncertainty is reported for this data point.

### Chemistry Context

The viscosity of the equimolar methanol–water mixture (0.001309 Pa·s) is significantly higher than that of pure methanol at the same temperature (0.000545 Pa·s at x(water) = 0). This well-known viscosity enhancement arises from extensive hydrogen-bonding network restructuring when water and methanol molecules interact. The data from this source show that viscosity continues to increase beyond equimolar composition, reaching a maximum near x(water) ≈ 0.7:

| Temperature (K) | x(water) | Pressure (kPa) | Dynamic Viscosity (Pa·s) |
|---|---|---|---|
| 298.15 | 0.3985 | 101.0 | 0.00115 |
| 298.15 | 0.5003 | 101.0 | 0.001309 |
| 298.15 | 0.5994 | 101.0 | 0.001463 |
| 298.15 | 0.6997 | 101.0 | 0.001554 |
| 298.15 | 0.7986 | 101.0 | 0.001542 |
| 298.15 | 0.8999 | 101.0 | 0.001317 |

The viscosity maximum at x(water) ≈ 0.7 (η = 0.001554 Pa·s) reflects the composition where the mixed hydrogen-bonding network is most structured, creating the greatest resistance to flow. Beyond this point, the system transitions toward the pure-water hydrogen-bonding structure and viscosity decreases.

### Core claims

- The dynamic viscosity of the methanol + water binary mixture at x(water) = 0.5003, 298.15 K, and 101.0 kPa is 0.001309 Pa·s, as measured by capillary tube viscometry (DOI: 10.1016/j.jct.2007.05.004).
- No data point exists at exactly equimolar composition; the nearest available is x(water) = 0.5003 (x(methanol) ≈ 0.4997), and the reported pressure of 101.0 kPa is slightly below the standard 101.325 kPa, with negligible effect on liquid-phase viscosity.
- The equimolar mixture viscosity (0.001309 Pa·s) is significantly higher than that of pure methanol at the same temperature (0.000545 Pa·s), consistent with hydrogen-bonding network restructuring in methanol–water mixtures.
- The data show a viscosity maximum near x(water) ≈ 0.7 (η = 0.001554 Pa·s at 298.15 K), beyond which viscosity decreases toward pure-water values.
- No explicit uncertainty is reported for the viscosity measurement.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9 |  | This block provides dynamic viscosity (Pa·s) of the methanol + water binary mixture measured by capillary tube viscometry at 101.0 kPa, covering temperatures 293.15–303.15 K and mole fractions 0.0–1.0. It directly supplies the reported value of 0.001309 Pa·s at 298.15 K and x(water) = 0.5003. |

### Suggested follow-ups

- Compare viscosity values for methanol + water at x=0.5 across multiple ThermoML sources to assess inter-laboratory consistency.
- Retrieve viscosity data at additional temperatures (e.g., 288.15 K, 308.15 K) from the same source to examine the temperature dependence at equimolar composition.
- Look up the viscosity maximum composition more precisely by querying finer composition grids near x(water) ≈ 0.7 from this or other datasets.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "methanol",
    "name": "methanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_2825",
    "registry_id": "2007-gon-cal-1",
    "name": "10.1016/j.jct.2007.05.004"
  }
]
```

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored. 2 entr(ies); verbatim rows below.

- INSP_2852b20db799 — GLOBlit_2825::PROPblock_9 · nearest · 4 rows
- INSP_87b7eb06bdc8 — GLOBlit_2825::PROPblock_9 · nearest · 2 rows

```json
[
  {
    "doi": "10.1016/j.jct.2007.05.004",
    "block_number": "PROPblock_9",
    "table_mode": "nearest",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "mole_fraction_<water>",
      "pressure_kpa",
      "viscosity_pa_s"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_19",
        "temperature_k": "298.15",
        "mole_fraction_<water>": "0.3985",
        "pressure_kpa": "101.0",
        "viscosity_pa_s": "0.00115"
      },
      {
        "BLKpoint_id": "BLKpoint_20",
        "temperature_k": "298.15",
        "mole_fraction_<water>": "0.5003",
        "pressure_kpa": "101.0",
        "viscosity_pa_s": "0.001309"
      },
      {
        "BLKpoint_id": "BLKpoint_21",
        "temperature_k": "298.15",
        "mole_fraction_<water>": "0.5994",
        "pressure_kpa": "101.0",
        "viscosity_pa_s": "0.001463"
      },
      {
        "BLKpoint_id": "BLKpoint_22",
        "temperature_k": "298.15",
        "mole_fraction_<water>": "0.6997",
        "pressure_kpa": "101.0",
        "viscosity_pa_s": "0.001554"
      }
    ],
    "inspection_id": "INSP_2852b20db799",
    "lit_num_id": "GLOBlit_2825"
  },
  {
    "doi": "10.1016/j.jct.2007.05.004",
    "block_number": "PROPblock_9",
    "table_mode": "nearest",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "mole_fraction_<water>",
      "pressure_kpa",
      "viscosity_pa_s"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_23",
        "temperature_k": "298.15",
        "mole_fraction_<water>": "0.7986",
        "pressure_kpa": "101.0",
        "viscosity_pa_s": "0.001542"
      },
      {
        "BLKpoint_id": "BLKpoint_24",
        "temperature_k": "298.15",
        "mole_fraction_<water>": "0.8999",
        "pressure_kpa": "101.0",
        "viscosity_pa_s": "0.001317"
      }
    ],
    "inspection_id": "INSP_87b7eb06bdc8",
    "lit_num_id": "GLOBlit_2825"
  }
]
```
