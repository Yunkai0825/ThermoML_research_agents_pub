# Main Agent Run — [run id removed] (Round 1)

**Question:** What surface tensions have been reported for liquid methanol + acetonitrile mixtures near room temperature, and how do they vary with composition?

**[run statistics removed]**

---

## Answer

## Surface Tension of Liquid Methanol + Acetonitrile Mixtures near Room Temperature

### Data Source

One dataset was found in the ThermoML database for the binary system **methanol (CH₄O) + acetonitrile (C₂H₃N)**:

- **Literature ID:** GLOBlit_8821
- **DOI:** 10.1021/je050519g
- **Reference:** Tahery, Modarress, et al. (2006), *"Density and Surface Tension of Binary Mixtures of Acetonitrile + 1-Alkanol at 293.15 K"*
- **Block:** PROPblock_13
- **Method:** Pendant drop shape

### Measured Surface Tension Values (T = 293.15 K)

All measurements were performed at a fixed temperature of **293.15 K**, with composition expressed as the mole fraction of acetonitrile in the liquid phase:

| x(acetonitrile) | Surface tension γ (N/m) |
|:---:|:---:|
| 0.1001 | 0.0238 |
| 0.2011 | 0.02473 |
| 0.2996 | 0.02553 |
| 0.4997 | 0.02685 |
| 0.7012 | 0.02794 |
| 0.8009 | 0.02842 |
| 0.8956 | 0.02885 |

### Composition Dependence

The surface tension increases **monotonically** with increasing acetonitrile mole fraction across the entire measured range. At the methanol-rich end (x = 0.1001), γ = 0.0238 N/m (23.8 mN/m), while at the acetonitrile-rich end (x = 0.8956), γ = 0.02885 N/m (28.85 mN/m) — a total span of approximately 5 mN/m. No extrema (minima or maxima) are observed.

This monotonic behavior is consistent with methanol having a lower pure-component surface tension than acetonitrile (~29 mN/m at 293 K), so progressively replacing methanol with acetonitrile steadily raises the mixture surface tension. The smooth, monotonic trend without any extrema suggests relatively ideal mixing behavior at the liquid–gas interface. Both components are small, polar molecules — methanol acts as both a hydrogen-bond donor and acceptor, while acetonitrile is primarily an acceptor — and their similar molecular sizes and polarities contribute to this near-ideal surface behavior.

### Data Availability

Only this single dataset was found in the ThermoML database for the methanol + acetonitrile system. The measurements cover seven compositions at a single temperature of 293.15 K. No additional surface tension data at other near-room-temperature conditions were available in the database.

### Sources
- **Literature ID:** GLOBlit_8821 | **DOI:** 10.1021/je050519g | **Block:** PROPblock_13 | **System:** Acetonitrile + Methanol

### Core claims

- At 293.15 K, the surface tension of liquid methanol + acetonitrile mixtures increases monotonically with increasing acetonitrile mole fraction, from 0.0238 N/m at x(acetonitrile) = 0.1001 to 0.02885 N/m at x(acetonitrile) = 0.8956, with no extrema observed.
- The data comprise seven compositions at a single temperature of 293.15 K, measured by the pendant drop shape method, from a single ThermoML dataset (DOI: 10.1021/je050519g).
- No additional surface tension data for the methanol + acetonitrile system at other near-room-temperature conditions were available in the ThermoML database.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8821 | 10.1021/je050519g | PROPblock_13 |  | This block provides all 7 surface tension data points for the methanol + acetonitrile binary system at 293.15 K, covering mole fractions 0.1001–0.8956 and surface tensions 0.0238–0.02885 N/m, which are directly quoted and discussed in the answer. |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
