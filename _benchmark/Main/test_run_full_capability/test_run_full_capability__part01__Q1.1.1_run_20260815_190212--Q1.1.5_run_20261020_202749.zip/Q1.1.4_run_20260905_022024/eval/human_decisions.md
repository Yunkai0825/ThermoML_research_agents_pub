1. D086 source descriptions identify data at298.15K, then give ranges .00028-.00081 and .000293-.000799 Pa*s. Full-block extrema support both ranges, but the298.15K lower values are .00034 and .000342. The text does not explicitly say these ranges include other temperatures.

   **Your reply:** Full blocks; retain temperature-scope caveat
