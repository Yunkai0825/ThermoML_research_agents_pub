# Main Agent Run — [run id removed] (Round 1)

**Question:** For an equimolar acetonitrile + N,N-dimethylformamide liquid mixture at 25 °C, what experimental viscosity values have been reported?

**[run statistics removed]**

---

## Answer

## Experimental Viscosity of an Equimolar Acetonitrile + N,N-Dimethylformamide Mixture at 25 °C

Two independent experimental studies in the ThermoML database report dynamic viscosity for the binary system **acetonitrile (ACN) + N,N-dimethylformamide (DMF)** near equimolar composition at 298.15 K (25 °C):

---

### Source 1 — Mole-fraction basis (best direct match)

**Literature:** GLOBlit_7481 | DOI: 10.1021/acs.jced.8b00176  
**Block:** PROPblock_18  
**Method:** Falling/rolling sphere viscometer  
**Pressure:** 100.0 kPa

This dataset reports composition on a mole-fraction basis. The closest composition to equimolar is **x(DMF) = 0.5029**. Data at 298.15 K in the equimolar region:

| T (K) | x(DMF) | p (kPa) | η (Pa·s) | η (mPa·s) |
|--------|---------|----------|-----------|------------|
| 298.15 | 0.3932 | 100.0 | 0.00054 | 0.54 |
| **298.15** | **0.5029** | **100.0** | **0.00061** | **0.61** |
| 298.15 | 0.6002 | 100.0 | 0.00065 | 0.65 |
| 298.15 | 0.6931 | 100.0 | 0.00069 | 0.69 |

**Best near-equimolar value: η = 0.00061 Pa·s (0.61 mPa·s) at x(DMF) = 0.5029, 298.15 K, 100.0 kPa.**

---

### Source 2 — Mass-fraction basis (independent corroboration)

**Literature:** GLOBlit_4124 | DOI: 10.1016/j.jct.2014.02.019  
**Block:** PROPblock_6  
**Method:** Capillary tube (Ostwald–Ubbelohde)  
**Pressure:** 101.0 kPa

This dataset reports composition as mass fraction of DMF. The data at 298.15 K bracketing the equimolar region are:

| T (K) | w(DMF) | p (kPa) | η (Pa·s) | η (mPa·s) |
|--------|--------|----------|-----------|------------|
| 298.15 | 0.50 | 101.0 | 0.0005214 | 0.521 |
| 298.15 | 0.75 | 101.0 | 0.0006465 | 0.647 |

The equimolar composition on a mass-fraction basis falls between these two rows, so the equimolar viscosity from this source is bracketed between 0.0005214 and 0.0006465 Pa·s (0.521–0.647 mPa·s).

---

### Summary

| Source | Composition basis | Nearest equimolar point | η (Pa·s) | η (mPa·s) |
|--------|-------------------|------------------------|-----------|------------|
| GLOBlit_7481 / PROPblock_18 | Mole fraction | x(DMF) = 0.5029 | 0.00061 | 0.61 |
| GLOBlit_4124 / PROPblock_6 | Mass fraction | Bracketed (w = 0.50–0.75) | 0.0005214–0.0006465 | 0.521–0.647 |

### Chemistry Insight

The viscosity of this mixture increases monotonically with DMF content at 298.15 K. Pure-component viscosities from PROPblock_18 are η(ACN) = 0.00034 Pa·s at x(DMF) = 0 (BLKpoint_1) and η(DMF) = 0.00081 Pa·s at x(DMF) = 1 (BLKpoint_11). The near-equimolar value of 0.00061 Pa·s (from PROPblock_18, BLKpoint_6) falls between these pure-component values without exhibiting a pronounced maximum or minimum, indicating relatively ideal mixing behavior. This is consistent with the fact that both ACN and DMF are polar aprotic solvents with similar dipole–dipole interactions but no strong specific associations (e.g., hydrogen bonding) that would produce large viscosity deviations from ideality.

### Sources
- Literature ID: GLOBlit_7481 | DOI: 10.1021/acs.jced.8b00176 | Block: PROPblock_18 | System: acetonitrile + N,N-dimethylformamide
- Literature ID: GLOBlit_4124 | DOI: 10.1016/j.jct.2014.02.019 | Block: PROPblock_6 | System: acetonitrile + N,N-dimethylformamide

---
[UNGROUNDED DATA FLAGS] The following quoted values could not be verified against any verbatim data inspection in this run and must be treated as UNVERIFIED:
- **UNINSPECTED_VALUE** PROPblock_18: 0.00034 exists in PROPblock_18's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_7481::PROPblock_18", nearest={"column": "mole_fraction_<dimethylformamide>", "value": 0.00034})`
- **UNINSPECTED_VALUE** PROPblock_18: 0.00081 exists in PROPblock_18's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_7481::PROPblock_18", nearest={"column": "mole_fraction_<dimethylformamide>", "value": 0.00081})`
Inspected so far: PROPblock_18, PROPblock_6

### Core claims

- At 298.15 K and 100.0 kPa, the dynamic viscosity of an approximately equimolar acetonitrile + N,N-dimethylformamide mixture (x(DMF) = 0.5029) is 0.00061 Pa·s (0.61 mPa·s), as reported in GLOBlit_7481 / PROPblock_18 using a falling/rolling sphere viscometer.
- An independent source (GLOBlit_4124 / PROPblock_6, capillary tube method, 101.0 kPa, 298.15 K) brackets the equimolar viscosity between 0.0005214 and 0.0006465 Pa·s (0.521–0.647 mPa·s), corroborating the first source.
- The viscosity of the mixture increases monotonically with DMF content at 298.15 K, and the near-equimolar value falls between the pure-component values without a pronounced maximum or minimum, indicating relatively ideal mixing behavior consistent with both components being polar aprotic solvents.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_7481 | 10.1021/acs.jced.8b00176 | PROPblock_18 |  | This block provides mole-fraction-based viscosity data for the acetonitrile + DMF binary system at 298.15 K and 100.0 kPa, with the nearest equimolar point at x(DMF) = 0.5029 giving η = 0.00061 Pa·s. The viscosity range 0.00028–0.00081 Pa·s and mole fraction range 0.0–1.0 are consistent with the answer's quoted values. |
| GLOBlit_4124 | 10.1016/j.jct.2014.02.019 | PROPblock_6 |  | This block provides independent corroboration via mass-fraction-based viscosity data for the same binary system at 298.15 K and 101.0 kPa. The answer brackets the equimolar viscosity between the w = 0.50 and w = 0.75 data points, consistent with the block's viscosity range of 0.000293–0.000799 Pa·s and mass fraction range 0.0–1.0. |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
