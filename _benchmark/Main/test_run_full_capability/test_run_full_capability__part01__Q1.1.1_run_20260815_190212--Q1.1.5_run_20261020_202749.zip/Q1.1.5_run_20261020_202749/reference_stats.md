# Reference Stats — main-agent

**Run started:** 2026-10-20 20:27:49
**Wall time (at last flush):** 1,833.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 36 | 301,194 | 1,025,829 | 152,788 | 1,327,023 | 36,861 | 963.5 | claudeopus46 |
| L0-menu-planner | 1 | 1,013 | 1,467 | 3,008 | 2,480 | 2,480 | 17.2 | claudesonnet46 |
| L1-worker | 39 | 146,913 | 39,242 | 44,465 | 186,155 | 4,773 | 341.6 | claudeopus46 |
| **TOTAL** | **76** | **449,120** | **1,066,538** | **200,261** | **1,515,658** | **19,942** | **1322.3** | |

**Estimated tokens:** ~378,914 input + ~50,065 output = ~428,979 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `browse_subagent_tools` | purpose=Find pure-component melting t…, tasks=Sear… | 3,008 | — | — | 32.7 |
| 2 | 6 | `run_subagent_tool` | kwargs={'queries': ['ethylene carbon…, purpose=Res… | 647 | — | — | 9.2 |
| 3 | 7 | `run_subagent_tool` | kwargs={'queries': ['4-methyl-1,3-di…, purpose=Res… | 396 | — | — | 7.3 |
| 4 | 8 | `run_parallel_subagents` | tasks=[{'agent': 'query', 'label': … | 1,378 | — | — | 554.5 |
| 5 | 10 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_6…, purpose=Ins… | 327 | — | — | 5.1 |
| 6 | 10 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ins… | 291 | — | — | 4.8 |
| 7 | 10 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_1…, purpose=Ins… | 447 | — | — | 5.1 |
| 8 | 10 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Ins… | 977 | — | — | 10.7 |
| 9 | 10 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Ins… | 934 | — | — | 10.5 |
| 10 | 10 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ins… | 886 | — | — | 11.0 |
| 11 | 10 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ins… | 628 | — | — | 9.5 |
| 12 | 10 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ins… | 882 | — | — | 11.1 |
| 13 | 11 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ver… | 355 | — | — | 5.0 |
| 14 | 11 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Ver… | 814 | — | — | 9.3 |
| 15 | 11 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Ver… | 828 | — | — | 10.2 |
| 16 | 11 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ver… | 758 | — | — | 9.7 |
| 17 | 11 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ver… | 963 | — | — | 11.2 |
| 18 | 11 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ver… | 820 | — | — | 9.4 |
| 19 | 12 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ver… | 693 | — | — | 9.1 |
| 20 | 12 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ver… | 810 | — | — | 9.4 |
| 21 | 12 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Ver… | 684 | — | — | 9.5 |
| 22 | 12 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Ver… | 726 | — | — | 9.1 |
| 23 | 12 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Ver… | 553 | — | — | 7.2 |
| 24 | 13 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Get… | 683 | — | — | 7.7 |
| 25 | 13 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Get… | 740 | — | — | 8.0 |
| 26 | 13 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Get… | 772 | — | — | 9.4 |
| 27 | 13 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Get… | 802 | — | — | 9.2 |
| 28 | 13 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Get… | 571 | — | — | 8.6 |
| 29 | 14 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Get… | 818 | — | — | 9.7 |
| 30 | 14 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Get… | 1,006 | — | — | 11.4 |
| 31 | 14 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Get… | 960 | — | — | 11.7 |
| 32 | 14 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_3…, purpose=Get… | 911 | — | — | 12.4 |
| 33 | 14 | `run_subagent_tool` | kwargs={'block_number': 'PROPblock_4…, purpose=Get… | 604 | — | — | 7.7 |
| 34 | 17 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_2959'…, purpose=Ver… | 302 | — | — | 5.1 |
| 35 | 17 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_1484'…, purpose=Ver… | 500 | — | — | 6.4 |
| 36 | 17 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_8264'…, purpose=Ver… | 383 | — | — | 6.0 |
| 37 | 17 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_8264'…, purpose=Ver… | 940 | — | — | 12.9 |
| 38 | 17 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_8264'…, purpose=Ver… | 1,015 | — | — | 14.6 |
| 39 | 17 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_8264'…, purpose=Ver… | 718 | — | — | 9.6 |
| 40 | 17 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_8264'…, purpose=Ver… | 731 | — | — | 9.2 |
| 41 | 17 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_8264'…, purpose=Ver… | 812 | — | — | 11.3 |
| | | **TOTAL (41 tools)** | | **32,073** | | **0** | **941.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 13,598 | 484 | 14,082 | 1,596 | 9.3 |
| 2 | L0-main | claudeopus46 | 13,598 | 1,563 | 15,161 | 760 | 6.0 |
| 3 | L0-menu-planner | claudesonnet46 | 1,013 | 1,467 | 2,480 | 3,008 | 17.2 |
| 4 | L0-main | claudeopus46 | 13,598 | 4,486 | 18,084 | 15,793 | 70.4 |
| 5 | L0-main | claudeopus46 | 13,598 | 5,894 | 19,492 | 1,131 | 6.5 |
| 6 | L0-main | claudeopus46 | 13,598 | 7,390 | 20,988 | 1,192 | 6.9 |
| 7 | L0-main | claudeopus46 | 13,598 | 8,771 | 22,369 | 751 | 5.0 |
| 8 | L1-worker | claudeopus46 | 3,767 | 828 | 4,595 | 1,174 | 8.5 |
| 9 | L0-main | claudeopus46 | 13,598 | 7,455 | 21,053 | 762 | 6.8 |
| 10 | L1-worker | claudeopus46 | 3,767 | 2,408 | 6,175 | 652 | 6.5 |
| 11 | L0-main | claudeopus46 | 13,598 | 8,427 | 22,025 | 3,643 | 15.6 |
| 12 | L0-main | claudeopus46 | 161 | 3,959 | 4,120 | 504 | 4.5 |
| 13 | L0-main | claudeopus46 | 3,766 | 19,425 | 23,191 | 1,116 | 9.3 |
| 14 | L0-main | claudeopus46 | 3,766 | 18,937 | 22,703 | 1,119 | 9.6 |
| 15 | L0-main | claudeopus46 | 3,766 | 7,053 | 10,819 | 845 | 7.0 |
| 16 | L0-main | claudeopus46 | 3,766 | 21,377 | 25,143 | 1,122 | 11.1 |
| 17 | L0-main | claudeopus46 | 3,766 | 20,870 | 24,636 | 1,068 | 10.2 |
| 18 | L0-main | claudeopus46 | 3,766 | 25,358 | 29,124 | 1,092 | 11.1 |
| 19 | L0-main | claudeopus46 | 3,766 | 7,566 | 11,332 | 1,190 | 12.3 |
| 20 | L0-main | claudeopus46 | 13,598 | 52,318 | 65,916 | 11,224 | 74.6 |
| 21 | L0-main | claudeopus46 | 13,598 | 68,171 | 81,769 | 12,903 | 79.1 |
| 22 | L1-worker | claudeopus46 | 3,767 | 783 | 4,550 | 505 | 4.8 |
| 23 | L1-worker | claudeopus46 | 3,767 | 786 | 4,553 | 475 | 4.6 |
| 24 | L1-worker | claudeopus46 | 3,767 | 773 | 4,540 | 684 | 5.0 |
| 25 | L1-worker | claudeopus46 | 3,767 | 1,531 | 5,298 | 1,327 | 10.6 |
| 26 | L1-worker | claudeopus46 | 3,767 | 1,577 | 5,344 | 1,380 | 10.4 |
| 27 | L1-worker | claudeopus46 | 3,767 | 1,515 | 5,282 | 1,394 | 10.6 |
| 28 | L1-worker | claudeopus46 | 3,767 | 1,069 | 4,836 | 1,072 | 8.6 |
| 29 | L1-worker | claudeopus46 | 3,767 | 1,613 | 5,380 | 1,302 | 10.6 |
| 30 | L0-main | claudeopus46 | 3,766 | 5,992 | 9,758 | 1,268 | 10.5 |
| 31 | L0-main | claudeopus46 | 13,598 | 70,838 | 84,436 | 15,746 | 92.3 |
| 32 | L1-worker | claudeopus46 | 3,767 | 796 | 4,563 | 463 | 4.8 |
| 33 | L1-worker | claudeopus46 | 3,767 | 605 | 4,372 | 1,353 | 9.1 |
| 34 | L1-worker | claudeopus46 | 3,767 | 604 | 4,371 | 1,334 | 9.4 |
| 35 | L1-worker | claudeopus46 | 3,767 | 592 | 4,359 | 1,301 | 9.4 |
| 36 | L1-worker | claudeopus46 | 3,767 | 1,064 | 4,831 | 1,467 | 11.0 |
| 37 | L1-worker | claudeopus46 | 3,767 | 590 | 4,357 | 1,317 | 9.2 |
| 38 | L0-main | claudeopus46 | 3,766 | 5,057 | 8,823 | 1,010 | 10.1 |
| 39 | L0-main | claudeopus46 | 13,598 | 73,260 | 86,858 | 12,719 | 75.7 |
| 40 | L1-worker | claudeopus46 | 3,767 | 596 | 4,363 | 1,283 | 8.9 |
| 41 | L1-worker | claudeopus46 | 3,767 | 595 | 4,362 | 1,408 | 9.3 |
| 42 | L1-worker | claudeopus46 | 3,767 | 591 | 4,358 | 1,405 | 9.4 |
| 43 | L1-worker | claudeopus46 | 3,767 | 590 | 4,357 | 1,359 | 8.9 |
| 44 | L1-worker | claudeopus46 | 3,767 | 1,069 | 4,836 | 892 | 7.1 |
| 45 | L0-main | claudeopus46 | 3,766 | 3,929 | 7,695 | 1,435 | 11.6 |
| 46 | L0-main | claudeopus46 | 13,598 | 75,173 | 88,771 | 12,107 | 74.0 |
| 47 | L1-worker | claudeopus46 | 3,767 | 557 | 4,324 | 1,069 | 7.4 |
| 48 | L1-worker | claudeopus46 | 3,767 | 556 | 4,323 | 1,168 | 7.8 |
| 49 | L1-worker | claudeopus46 | 3,767 | 561 | 4,328 | 1,363 | 9.2 |
| 50 | L1-worker | claudeopus46 | 3,767 | 560 | 4,327 | 1,326 | 9.0 |
| 51 | L1-worker | claudeopus46 | 3,767 | 551 | 4,318 | 1,151 | 8.4 |
| 52 | L0-main | claudeopus46 | 3,766 | 3,999 | 7,765 | 1,362 | 9.9 |
| 53 | L0-main | claudeopus46 | 13,598 | 77,358 | 90,956 | 10,639 | 66.2 |
| 54 | L1-worker | claudeopus46 | 3,767 | 1,466 | 5,233 | 1,198 | 9.5 |
| 55 | L1-worker | claudeopus46 | 3,767 | 1,419 | 5,186 | 1,371 | 11.3 |
| 56 | L1-worker | claudeopus46 | 3,767 | 1,411 | 5,178 | 1,448 | 11.5 |
| 57 | L1-worker | claudeopus46 | 3,767 | 1,406 | 5,173 | 1,344 | 11.9 |
| 58 | L1-worker | claudeopus46 | 3,767 | 1,258 | 5,025 | 821 | 7.4 |
| 59 | L0-main | claudeopus46 | 3,766 | 4,727 | 8,493 | 1,070 | 10.0 |
| 60 | L0-main | claudeopus46 | 13,598 | 79,303 | 92,901 | 7,770 | 53.5 |
| 61 | L0-main | claudeopus46 | 13,598 | 92,326 | 105,924 | 2,291 | 11.1 |
| 62 | L0-main | claudeopus46 | 13,598 | 95,931 | 109,529 | 11,734 | 72.6 |
| 63 | L1-worker | claudeopus46 | 3,767 | 749 | 4,516 | 551 | 4.8 |
| 64 | L1-worker | claudeopus46 | 3,767 | 752 | 4,519 | 818 | 6.2 |
| 65 | L1-worker | claudeopus46 | 3,767 | 740 | 4,507 | 655 | 5.5 |
| 66 | L1-worker | claudeopus46 | 3,767 | 1,404 | 5,171 | 1,538 | 12.1 |
| 67 | L1-worker | claudeopus46 | 3,767 | 1,399 | 5,166 | 1,584 | 13.6 |
| 68 | L1-worker | claudeopus46 | 3,767 | 1,449 | 5,216 | 1,057 | 9.3 |
| 69 | L1-worker | claudeopus46 | 3,767 | 1,027 | 4,794 | 1,189 | 9.0 |
| 70 | L1-worker | claudeopus46 | 3,767 | 1,402 | 5,169 | 1,267 | 11.0 |
| 71 | L0-main | claudeopus46 | 3,766 | 5,987 | 9,753 | 801 | 7.3 |
| 72 | L0-main | claudeopus46 | 13,598 | 95,634 | 109,232 | 7,734 | 55.3 |
| 73 | L0-main | claudeopus46 | 2,543 | 10,566 | 13,109 | 953 | 5.6 |
| 74 | L0-main | claudeopus46 | 2,320 | 9,966 | 12,286 | 1,591 | 13.8 |
| 75 | L0-main | claudeopus46 | 1,156 | 15,716 | 16,872 | 3,296 | 17.0 |
| 76 | L0-main | claudeopus46 | 1,292 | 10,563 | 11,855 | 1,451 | 11.7 |

