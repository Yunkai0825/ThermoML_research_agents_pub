# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 5 | 29,181 | 17,291 | 4,870 | 46,472 | 9,294 | 30.9 | claudeopus46 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| L1-worker | 16 | 173,719 | 89,110 | 17,757 | 262,829 | 16,426 | 121.8 | claudeopus46 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| verdict | 1 | 972 | 3,866 | 1,010 | 4,838 | 4,838 | 7.9 | claudeopus46 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| L0-main | 5 | 29,181 | 38,081 | 10,268 | 67,262 | 13,452 | 57.2 | claudeopus46 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| L1-worker | 17 | 218,232 | 157,836 | 30,845 | 376,068 | 22,121 | 195.4 | claudeopus46 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| verdict | 1 | 972 | 7,928 | 1,105 | 8,900 | 8,900 | 9.6 | claudeopus46 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| L0-main | 5 | 29,181 | 36,231 | 9,788 | 65,412 | 13,082 | 54.6 | claudeopus46 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| L1-worker | 19 | 307,258 | 256,619 | 35,814 | 563,877 | 29,677 | 225.0 | claudeopus46 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| verdict | 1 | 972 | 7,454 | 1,164 | 8,426 | 8,426 | 9.9 | claudeopus46 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| L0-main | 5 | 29,181 | 35,583 | 8,677 | 64,764 | 12,952 | 54.8 | claudeopus46 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| L1-worker | 10 | 130,744 | 87,611 | 15,483 | 218,355 | 21,835 | 113.0 | claudeopus46 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| verdict | 1 | 972 | 6,542 | 1,116 | 7,514 | 7,514 | 9.4 | claudeopus46 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| L0-main | 5 | 29,181 | 24,709 | 6,193 | 53,890 | 10,778 | 41.0 | claudeopus46 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| L1-worker | 12 | 179,024 | 68,868 | 13,839 | 247,892 | 20,657 | 99.7 | claudeopus46 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| verdict | 1 | 972 | 5,092 | 1,127 | 6,064 | 6,064 | 9.8 | claudeopus46 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| L0-main | 5 | 29,181 | 35,877 | 7,347 | 65,058 | 13,011 | 49.6 | claudeopus46 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| L1-worker | 11 | 154,884 | 102,556 | 17,414 | 257,440 | 23,403 | 125.0 | claudeopus46 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| verdict | 1 | 972 | 5,812 | 1,092 | 6,784 | 6,784 | 8.7 | claudeopus46 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| **TOTAL** | **121** | **1,344,779** | **987,066** | **184,909** | **2,331,845** | **249,214** | **1,223.3** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| `search_blocks` | 5 | 1 | 1 | 1 | 1 | 5 | 54 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| `resolve_property_ids` | 0 | 6 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| `search_blocks` | 1 | 1 | 0 | 0 | 1 | 1 | 1 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| `search_blocks` | 1 | 10 | 2 | 2 | 25 | 50 | 575 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `search_blocks` | 1 | 1 | 0 | 0 | 2 | 2 | 2 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `search_blocks` | 1 | 9 | 2 | 1 | 12 | 27 | 346 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `resolve_property_ids` | 0 | 13 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `search_blocks` | 1 | 1 | 0 | 0 | 6 | 6 | 6 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `resolve_property_ids` | 0 | 3 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `search_blocks` | 1 | 1 | 0 | 0 | 7 | 7 | 7 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| `search_blocks` | 2 | 1 | 1 | 1 | 1 | 2 | 25 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| `search_blocks` | 2 | 1 | 1 | 1 | 1 | 1 | 15 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| `search_blocks` | 2 | 1 | 1 | 1 | 1 | 2 | 18 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| **TOTAL** | **18** | **50** | **9** | **7** | **58** | **104** | **1,050** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | --- | --- |
| Unique References | 25 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Unique Compounds | 5 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Unique Properties | 16 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Unique Measurements | 26 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Unique Phases | 2 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Unique Variables | 3 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Unique Constraints | 2 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Unique parent blocks | 55 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Explicit block/subsystem targets | 55 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Subsystem targets | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| Target-matched data points | 630 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| GLOBlit_7259 |  | search_blocks |
| GLOBlit_8264 |  | search_blocks |
| GLOBlit_618 |  | search_blocks |
| GLOBlit_2207 |  | search_blocks |
| GLOBlit_2950 |  | search_blocks |
| GLOBlit_2959 |  | search_blocks |
| GLOBlit_3799 |  | search_blocks |
| GLOBlit_4207 |  | search_blocks |
| GLOBlit_6343 |  | search_blocks |
| GLOBlit_6589 |  | search_blocks |
| GLOBlit_7516 |  | search_blocks |
| GLOBlit_8285 |  | search_blocks |
| GLOBcomp_312 | ethylene carbonate | search_blocks |
| GLOBprop_10 | Molar enthalpy of transition or fusion, kJ/mol | search_blocks |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks |
| GLOBprop_12 | Normal melting temperature, K | resolve_property_ids, search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBprop_23 | Critical temperature, K | resolve_property_ids, search_blocks |
| GLOBprop_25 | Critical pressure, kPa | search_blocks |
| GLOBprop_26 |  | resolve_property_ids |
| GLOBprop_16 |  | resolve_property_ids |
| GLOBprop_11 |  | resolve_property_ids |
| GLOBprop_20 |  | resolve_property_ids |
| GLOBprop_57 |  | resolve_property_ids |
| GLOBprop_92 |  | resolve_property_ids |
| GLOBprop_58 |  | resolve_property_ids |
| GLOBprop_82 |  | resolve_property_ids |
| GLOBprop_93 |  | resolve_property_ids |
| GLOBprop_31 |  | resolve_property_ids |
| GLOBprop_14 |  | resolve_property_ids |
| GLOBmeas_132 | Molar enthalpy of transition or fusion, kJ/mol | search_blocks |
| GLOBmeas_269 | Molar enthalpy of transition or fusion, kJ/mol | search_blocks |
| GLOBmeas_23 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks |
| GLOBmeas_16 | Normal melting temperature, K | search_blocks |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_63 | Normal melting temperature, K | search_blocks |
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_130 | Normal melting temperature, K | search_blocks |
| GLOBmeas_33 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_57 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_198 | Critical temperature, K | search_blocks |
| GLOBmeas_243 | Normal melting temperature, K | search_blocks |
| GLOBmeas_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_5 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBphase_2 |  | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBphase_15 |  | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique References | 12 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Unique Compounds | 1 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Unique Properties | 20 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Unique Measurements | 16 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Unique Phases | 3 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Unique Variables | 2 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Unique Constraints | 1 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Unique parent blocks | 27 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Explicit block/subsystem targets | 27 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Subsystem targets | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| Target-matched data points | 354 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| GLOBlit_2251 |  | search_blocks |
| GLOBlit_1484 |  | search_blocks |
| GLOBlit_1560 |  | search_blocks |
| GLOBlit_2207 |  | search_blocks |
| GLOBlit_2959 |  | search_blocks |
| GLOBlit_7175 |  | search_blocks |
| GLOBlit_8264 |  | search_blocks |
| GLOBlit_9437 |  | search_blocks |
| GLOBcomp_62 | dimethyl carbonate | search_blocks |
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBprop_12 |  | resolve_property_ids, search_blocks |
| GLOBprop_26 |  | resolve_property_ids |
| GLOBprop_22 |  | resolve_property_ids |
| GLOBmeas_135 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBmeas_16 | Normal melting temperature, K | search_blocks |
| GLOBmeas_63 | Normal melting temperature, K | search_blocks |
| GLOBmeas_130 | Normal melting temperature, K | search_blocks |
| GLOBmeas_243 | Normal melting temperature, K | search_blocks |
| GLOBmeas_154 | Normal melting temperature, K | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBphase_2 |  | search_blocks |
| GLOBphase_7 |  | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| Unique References | 8 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| Unique Compounds | 1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| Unique Properties | 4 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| Unique Measurements | 6 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| Unique Phases | 3 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| Unique Variables | 1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| Unique parent blocks | 8 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| Explicit block/subsystem targets | 8 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| Subsystem targets | 0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| Target-matched data points | 8 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| GLOBlit_8264 |  | search_blocks |
| GLOBcomp_312 | ethylene carbonate | search_blocks |
| GLOBcomp_62 | dimethyl carbonate | search_blocks |
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBmeas_230 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique References | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Unique Compounds | 2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Unique Properties | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Unique Measurements | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Unique Phases | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Unique Variables | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Unique Constraints | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Unique parent blocks | 2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Explicit block/subsystem targets | 2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Subsystem targets | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| Target-matched data points | 25 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| GLOBlit_8264 |  | search_blocks |
| GLOBcomp_312 | ethylene carbonate | search_blocks |
| GLOBcomp_146 | 4-methyl-1,3-dioxolan-2-one | search_blocks |
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBmeas_230 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique References | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Unique Compounds | 2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Unique Properties | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Unique Measurements | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Unique Phases | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Unique Variables | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Unique Constraints | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Unique parent blocks | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Explicit block/subsystem targets | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Subsystem targets | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| Target-matched data points | 15 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| GLOBlit_8264 |  | search_blocks |
| GLOBcomp_146 | 4-methyl-1,3-dioxolan-2-one | search_blocks |
| GLOBcomp_62 | dimethyl carbonate | search_blocks |
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBmeas_230 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique References | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Unique Compounds | 2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Unique Properties | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Unique Measurements | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Unique Phases | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Unique Variables | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Unique Constraints | 1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Unique parent blocks | 2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Explicit block/subsystem targets | 2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Subsystem targets | 0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| Target-matched data points | 18 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| **TOTAL** | **1,421** |  |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1007/s10765-010-0860-3 | PROPblock_1 | declared | 3 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1007/s10765-010-0860-3 | PROPblock_2 | declared | 3 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.fluid.2006.04.001 | PROPblock_1 | declared | 2 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.fluid.2006.04.001 | PROPblock_2 | declared | 2 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.fluid.2008.03.013 | PROPblock_3 | declared | 18 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2005.01.017 | PROPblock_1 | declared | 8 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2005.03.019 | PROPblock_1 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2005.03.019 | PROPblock_2 | declared | 8 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2007.05.010 | PROPblock_5 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2007.05.010 | PROPblock_6 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2012.11.020 | PROPblock_1 | declared | 8 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2012.11.020 | PROPblock_2 | declared | 8 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2013.08.034 | PROPblock_4 | declared | 7 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2013.08.034 | PROPblock_5 | declared | 9 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2014.02.021 | PROPblock_3 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2014.07.004 | PROPblock_2 | declared | 6 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2015.08.013 | PROPblock_3 | declared | 6 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2016.09.008 | PROPblock_1 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.jct.2016.09.008 | PROPblock_2 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/acs.jced.5b00064 | PROPblock_7 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/acs.jced.5b00064 | PROPblock_8 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/acs.jced.6b00021 | PROPblock_14 | declared | 12 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/acs.jced.6b00021 | PROPblock_15 | declared | 67 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/acs.jced.7b00578 | PROPblock_7 | declared | 70 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/acs.jced.7b00578 | PROPblock_8 | declared | 21 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/acs.jced.7b01107 | PROPblock_5 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/acs.jced.7b01107 | PROPblock_6 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034134e | PROPblock_18 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034134e | PROPblock_19 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034134e | PROPblock_20 | declared | 140 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034134e | PROPblock_21 | declared | 55 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034134e | PROPblock_25 | declared | 13 | binary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034134e | PROPblock_40 | declared | 16 | binary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034134e | PROPblock_41 | declared | 2 | binary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034134e | PROPblock_45 | declared | 15 | binary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034134e | PROPblock_47 | declared | 8 | binary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034173q | PROPblock_3 | declared | 10 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034173q | PROPblock_4 | declared | 19 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034204h | PROPblock_1 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je034204h | PROPblock_2 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je0496903 | PROPblock_3 | declared | 5 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je0496903 | PROPblock_4 | declared | 5 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je0497395 | PROPblock_5 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je0497395 | PROPblock_6 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je049950g | PROPblock_1 | declared | 25 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je050183a | PROPblock_13 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je050183a | PROPblock_14 | declared | 2 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je050183a | PROPblock_15 | declared | 2 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je050183a | PROPblock_16 | declared | 2 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je050444g | PROPblock_10 | declared | 2 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je050444g | PROPblock_11 | declared | 2 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je050444g | PROPblock_12 | declared | 2 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je050444g | PROPblock_9 | declared | 27 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je1005483 | PROPblock_4 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1021/je1005483 | PROPblock_5 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10.1016/j.fluid.2008.03.013 | 2 | 38 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1016/j.fluid.2018.05.033 | 3 | 3 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1016/j.jct.2008.05.001 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1016/j.jct.2008.05.012 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1016/j.jct.2012.12.025 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1016/j.jct.2014.07.004 | 1 | 5 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1016/j.tca.2016.09.007 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1021/acs.jced.5b00338 | 3 | 13 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1021/acs.jced.7b00578 | 6 | 113 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1021/acs.jced.8b00298 | 2 | 2 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1021/je034134e | 4 | 156 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1021/je034173q | 2 | 12 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |  |  |
| 10.1016/j.fluid.2008.03.013 | PROPblock_1 | declared | 29 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.fluid.2008.03.013 | PROPblock_2 | declared | 9 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.fluid.2018.05.033 | PROPblock_7 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.fluid.2018.05.033 | PROPblock_8 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.fluid.2018.05.033 | PROPblock_9 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.jct.2008.05.001 | PROPblock_1 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.jct.2008.05.012 | PROPblock_6 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.jct.2012.12.025 | PROPblock_1 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.jct.2014.07.004 | PROPblock_1 | declared | 5 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.tca.2016.09.007 | PROPblock_1 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.5b00338 | PROPblock_6 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.5b00338 | PROPblock_7 | declared | 9 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.5b00338 | PROPblock_8 | declared | 3 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.7b00578 | PROPblock_1 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.7b00578 | PROPblock_2 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.7b00578 | PROPblock_3 | declared | 30 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.7b00578 | PROPblock_4 | declared | 54 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.7b00578 | PROPblock_5 | declared | 18 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.7b00578 | PROPblock_6 | declared | 9 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.8b00298 | PROPblock_69 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/acs.jced.8b00298 | PROPblock_70 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/je034134e | PROPblock_5 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/je034134e | PROPblock_6 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/je034134e | PROPblock_7 | declared | 34 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/je034134e | PROPblock_8 | declared | 120 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/je034173q | PROPblock_1 | declared | 4 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1021/je034173q | PROPblock_2 | declared | 8 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10.1016/j.fluid.2014.05.033 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |  |  |
| 10.1016/j.fluid.2014.09.024 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |  |  |
| 10.1016/j.fluid.2018.05.033 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |  |  |
| 10.1016/j.fluid.2018.09.023 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |  |  |
| 10.1016/j.jct.2008.05.012 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |  |  |
| 10.1021/acs.jced.7b00295 | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |  |  |
| 10.1021/je034134e | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |  |  |
| 10.1021/je101199g | 1 | 1 | unary | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |  |  |
| 10.1016/j.fluid.2014.05.033 | PROPblock_4 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10.1016/j.fluid.2014.09.024 | PROPblock_4 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10.1016/j.fluid.2018.05.033 | PROPblock_3 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10.1016/j.fluid.2018.09.023 | PROPblock_5 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10.1016/j.jct.2008.05.012 | PROPblock_5 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10.1021/acs.jced.7b00295 | PROPblock_1 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10.1021/je034134e | PROPblock_10 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10.1021/je101199g | PROPblock_4 | declared | 1 | unary | — | search_blocks | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10.1021/je034134e | 2 | 25 | binary | search_blocks | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |  |  |
| 10.1021/je034134e | PROPblock_33 | declared | 14 | binary | — | search_blocks | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 10.1021/je034134e | PROPblock_34 | declared | 11 | binary | — | search_blocks | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 10.1021/je034134e | 1 | 15 | binary | search_blocks | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |  |  |
| 10.1021/je034134e | PROPblock_45 | declared | 15 | binary | — | search_blocks | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 10.1021/je034134e | 2 | 18 | binary | search_blocks | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |  |  |
| 10.1021/je034134e | PROPblock_40 | declared | 16 | binary | — | search_blocks | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 10.1021/je034134e | PROPblock_41 | declared | 2 | binary | — | search_blocks | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| **TOTAL** | **40** | **412** | **1,041** |  |  |  |  |


## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | --- | ---: | --- |
| 1 | 1 | `search_blocks` | compound=GLOBcomp_146, limit=50, property=GLOBprop… | 874 | DISCARD ←in 39 | 816 | 15.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 2 | 2 | `search_blocks` | compound=GLOBcomp_146, limit=50, property=GLOBprop… | 651 | KEEP ←in 7,698 | 621 | 17.4 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 3 | 2 | `resolve_property_ids` | limit=20, min_score=40, purpose=Find alternative p… | 529 | KEEP ←in 689 | 529 | 7.7 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 4 | 3 | `search_blocks` | compound=GLOBcomp_146, limit=50, property=GLOBprop… | 645 | KEEP ←in 1,022 | 630 | 8.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 5 | 3 | `search_blocks` | compound=GLOBcomp_146, limit=50, property=GLOBprop… | 814 | DISCARD ←in 39 | 756 | 8.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 6 | 3 | `search_blocks` | compound=GLOBcomp_146, limit=50, purpose=Find all … | 967 | KEEP ←in 26,502 | 847 | 15.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 7 | 4 | `inspect_block_table` | block_number=PROPblock_19, literature=GLOBlit_8264… | 618 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 8 | 1 | `L1_query` | context=PC = GLOBcomp_146, formula C4…, id_catalog… | 6,412 | — | — | 131.4 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 1 | 1 | `search_blocks` | compound=GLOBcomp_312, limit=50, property=GLOBprop… | 895 | DISCARD ←in 39 | 837 | 13.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 2 | 1 | `search_blocks` | compound=GLOBcomp_312, limit=50, property=GLOBprop… | 847 | KEEP ←in 1,964 | 847 | 10.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 3 | 2 | `search_blocks` | compound=GLOBcomp_312, limit=50, purpose=Find all … | 760 | KEEP ←in 13,547 | 745 | 22.7 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 4 | 2 | `resolve_property_ids` | purpose=Find correct property ID for …, queries=['… | 435 | KEEP ←in 1,313 | 435 | 6.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 5 | 3 | `inspect_block_table` | block_number=PROPblock_9, literature=GLOBlit_2207,… | 630 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 6 | 3 | `inspect_block_table` | block_number=PROPblock_6, literature=GLOBlit_2959,… | 628 | — | — | 0.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 7 | 3 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_6343,… | 619 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 8 | 4 | `inspect_block_table` | block_number=PROPblock_6, literature=GLOBlit_6589,… | 618 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 9 | 4 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_7259,… | 624 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10 | 4 | `search_blocks` | compound=GLOBcomp_312, limit=10, property=GLOBprop… | 1,236 | KEEP ←in 5,472 | 1236 | 20.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 11 | 5 | `inspect_block_table` | block_number=PROPblock_6, literature=GLOBlit_8264,… | 608 | — | — | 0.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 12 | 5 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_7259,… | 686 | — | — | 0.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 13 | 5 | `inspect_block_table` | block_number=PROPblock_5, literature=GLOBlit_8264,… | 685 | — | — | 0.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 14 | 1 | `L1_query` | context=EC = ethylene carbonate, CAS …, id_catalog… | 33,138 | — | — | 212.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 1 | 1 | `search_blocks` | compound=GLOBcomp_62, limit=50, property=GLOBprop_… | 665 | KEEP ←in 1,223 | 635 | 12.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 2 | 2 | `inspect_block_table` | block_number=GLOBlit_2251::PROPblock_5, purpose=Ge… | 710 | — | — | 0.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 3 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Find alternative p… | 600 | KEEP ←in 422 | 600 | 6.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 4 | 3 | `search_blocks` | compound=GLOBcomp_62, limit=50, property=GLOBprop_… | 1,137 | KEEP ←in 6,322 | 1137 | 12.4 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 5 | 5 | `inspect_block_table` | block_number=GLOBlit_1484::PROPblock_4, purpose=Gr… | 630 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 6 | 5 | `inspect_block_table` | block_number=GLOBlit_1560::PROPblock_4, purpose=Gr… | 624 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 7 | 5 | `inspect_block_table` | block_number=GLOBlit_2207::PROPblock_3, purpose=Gr… | 630 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 8 | 5 | `inspect_block_table` | block_number=GLOBlit_2959::PROPblock_5, purpose=Gr… | 625 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 9 | 5 | `inspect_block_table` | block_number=GLOBlit_7175::PROPblock_1, purpose=Gr… | 624 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10 | 5 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_10, purpose=G… | 609 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 11 | 5 | `inspect_block_table` | block_number=GLOBlit_9437::PROPblock_4, purpose=Gr… | 620 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 12 | 7 | `inspect_block_table` | block_number=GLOBlit_1484::PROPblock_4, purpose=Gr… | 630 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 13 | 7 | `inspect_block_table` | block_number=GLOBlit_1560::PROPblock_4, purpose=Gr… | 624 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 14 | 7 | `inspect_block_table` | block_number=GLOBlit_2207::PROPblock_3, purpose=Gr… | 630 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 15 | 7 | `inspect_block_table` | block_number=GLOBlit_2959::PROPblock_5, purpose=Gr… | 625 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 16 | 7 | `inspect_block_table` | block_number=GLOBlit_7175::PROPblock_1, purpose=Gr… | 624 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 17 | 7 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_10, purpose=G… | 609 | — | — | 0.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 18 | 7 | `inspect_block_table` | block_number=GLOBlit_9437::PROPblock_4, purpose=Gr… | 620 | — | — | 0.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 19 | 8 | `inspect_block_table` | block_number=GLOBlit_1484::PROPblock_4, purpose=Gr… | 630 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 20 | 8 | `inspect_block_table` | block_number=GLOBlit_2959::PROPblock_5, purpose=Gr… | 625 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 21 | 8 | `inspect_block_table` | block_number=GLOBlit_7175::PROPblock_1, purpose=Gr… | 624 | — | — | 0.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 22 | 8 | `inspect_block_table` | block_number=GLOBlit_2207::PROPblock_3, purpose=Gr… | 630 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 23 | 8 | `inspect_block_table` | block_number=GLOBlit_1560::PROPblock_4, purpose=Gr… | 624 | — | — | 0.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 24 | 8 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_10, purpose=G… | 609 | — | — | 0.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 25 | 8 | `inspect_block_table` | block_number=GLOBlit_9437::PROPblock_4, purpose=Gr… | 620 | — | — | 0.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 26 | 9 | `inspect_block_table` | block_number=GLOBlit_1484::PROPblock_4, purpose=Gr… | 630 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 27 | 9 | `inspect_block_table` | block_number=GLOBlit_2959::PROPblock_5, purpose=Gr… | 625 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 28 | 9 | `inspect_block_table` | block_number=GLOBlit_7175::PROPblock_1, purpose=Gr… | 624 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 29 | 10 | `inspect_block_table` | block_number=GLOBlit_1560::PROPblock_4, purpose=Gr… | 624 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 30 | 10 | `inspect_block_table` | block_number=GLOBlit_2207::PROPblock_3, purpose=Gr… | 630 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 31 | 10 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_10, purpose=G… | 609 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 32 | 10 | `inspect_block_table` | block_number=GLOBlit_9437::PROPblock_4, purpose=Gr… | 620 | — | — | 0.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 33 | 1 | `L1_query` | context=DMC = dimethyl carbonate, exp…, id_catalog… | 33,345 | — | — | 231.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 1 | 1 | `search_blocks` | compound=['GLOBcomp_312', 'GLOBcomp_62…, limit=50,… | 1,161 | KEEP ←in 3,348 | 1161 | 21.2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 2 | 2 | `inspect_block_table` | block_number=PROPblock_33, literature=GLOBlit_8264… | 1,385 | — | — | 0.2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 3 | 2 | `inspect_block_table` | block_number=PROPblock_34, literature=GLOBlit_8264… | 1,429 | — | — | 0.2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 4 | 1 | `L1_query` | context=Looking for liquidus curves, …, id_catalog… | 23,242 | — | — | 109.3 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 1 | 1 | `search_blocks` | compound=['GLOBcomp_312', 'GLOBcomp_14…, limit=50,… | 1,358 | KEEP ←in 1,770 | 1328 | 20.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 2 | 2 | `inspect_block_table` | block_number=PROPblock_45, literature=GLOBlit_8264… | 1,484 | — | — | 0.9 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 3 | 3 | `inspect_block_table` | block_number=PROPblock_45, literature=GLOBlit_8264… | 426 | — | — | 0.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 4 | 4 | `inspect_block_table` | block_number=PROPblock_45, literature=GLOBlit_8264… | 1,552 | — | — | 0.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 5 | 5 | `inspect_block_table` | block_number=PROPblock_45, literature=GLOBlit_8264… | 1,211 | — | — | 1.2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 6 | 1 | `L1_query` | context=Looking for liquidus curves, …, id_catalog… | 15,424 | — | — | 105.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 1 | 1 | `search_blocks` | compound=['GLOBcomp_62', 'GLOBcomp_146…, limit=50,… | 1,218 | KEEP ←in 3,064 | 1218 | 23.6 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 2 | 2 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_40, purpose=R… | 1,367 | — | — | 0.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 3 | 2 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_41, purpose=R… | 923 | — | — | 0.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 4 | 3 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_40, purpose=G… | 1,483 | — | — | 0.3 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 5 | 3 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_40, purpose=G… | 1,565 | — | — | 0.3 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 6 | 1 | `L1_query` | context=Looking for liquidus curves, …, id_catalog… | 26,039 | — | — | 126.8 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| **TOTAL** | **312** |  |  | **189,091** |  | **14,378** | **1,169.8** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 11,581 | 853 | 12,434 | 1,320 | 8.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,321 | 25,461 | 737 | 5.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 3 | L1-worker | claudeopus46 | 3,767 | 480 | 4,247 | 1,244 | 8.7 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 4 | L1-worker | claudeopus46 | 24,140 | 2,695 | 26,835 | 1,335 | 7.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 5 | L1-worker | claudeopus46 | 3,767 | 8,070 | 11,837 | 2,109 | 15.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 6 | L1-worker | claudeopus46 | 3,767 | 875 | 4,642 | 1,137 | 6.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 7 | L1-worker | claudeopus46 | 24,140 | 4,617 | 28,757 | 1,381 | 6.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 8 | L1-worker | claudeopus46 | 3,767 | 1,351 | 5,118 | 907 | 6.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 9 | L1-worker | claudeopus46 | 3,767 | 401 | 4,168 | 947 | 7.4 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 10 | L1-worker | claudeopus46 | 3,767 | 26,857 | 30,624 | 1,693 | 14.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 11 | L1-worker | claudeopus46 | 24,140 | 7,906 | 32,046 | 1,264 | 10.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 12 | L1-worker | claudeopus46 | 24,140 | 9,102 | 33,242 | 1,320 | 9.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 13 | L1-worker | claudeopus46 | 24,140 | 13,201 | 37,341 | 1,166 | 5.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 14 | L1-worker | claudeopus46 | 2,543 | 2,739 | 5,282 | 523 | 3.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 15 | L1-worker | claudeopus46 | 2,320 | 1,297 | 3,617 | 678 | 3.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 16 | L1-worker | claudeopus46 | 627 | 1,177 | 1,804 | 777 | 4.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 17 | L1-worker | claudeopus46 | 787 | 7,021 | 7,808 | 539 | 5.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 18 | L0-main | claudeopus46 | 11,581 | 9,144 | 20,725 | 2,152 | 12.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 19 | L0-main | claudeopus46 | 2,320 | 1,935 | 4,255 | 521 | 3.4 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 20 | L0-main | claudeopus46 | 2,543 | 2,620 | 5,163 | 524 | 4.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 21 | L0-main | claudeopus46 | 1,156 | 2,739 | 3,895 | 353 | 3.0 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 22 | verdict | claudeopus46 | 972 | 3,866 | 4,838 | 1,010 | 7.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_3) |
| 1 | L0-main | claudeopus46 | 11,581 | 820 | 12,401 | 1,592 | 9.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,448 | 25,588 | 1,428 | 7.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 3 | L1-worker | claudeopus46 | 3,767 | 482 | 4,249 | 1,498 | 9.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 4 | L1-worker | claudeopus46 | 3,767 | 2,400 | 6,167 | 1,364 | 9.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 5 | L1-worker | claudeopus46 | 24,140 | 3,867 | 28,007 | 1,620 | 8.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 6 | L1-worker | claudeopus46 | 3,767 | 13,912 | 17,679 | 1,573 | 12.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 7 | L1-worker | claudeopus46 | 3,767 | 1,498 | 5,265 | 827 | 5.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 8 | L1-worker | claudeopus46 | 24,140 | 5,840 | 29,980 | 2,683 | 15.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 9 | L1-worker | claudeopus46 | 24,140 | 8,609 | 32,749 | 1,339 | 8.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 10 | L1-worker | claudeopus46 | 3,767 | 5,824 | 9,591 | 1,542 | 12.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 11 | L1-worker | claudeopus46 | 24,140 | 11,933 | 36,073 | 1,801 | 11.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 12 | L1-worker | claudeopus46 | 24,140 | 14,773 | 38,913 | 2,325 | 16.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 13 | L1-worker | claudeopus46 | 24,140 | 20,130 | 44,270 | 2,310 | 14.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 14 | L1-worker | claudeopus46 | 24,140 | 25,472 | 49,612 | 5,277 | 33.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 15 | L1-worker | claudeopus46 | 2,320 | 2,950 | 5,270 | 989 | 6.0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 16 | L1-worker | claudeopus46 | 627 | 2,830 | 3,457 | 989 | 6.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 17 | L1-worker | claudeopus46 | 2,543 | 4,519 | 7,062 | 2,600 | 9.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 18 | L1-worker | claudeopus46 | 787 | 31,349 | 32,136 | 680 | 7.0 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 19 | L0-main | claudeopus46 | 11,581 | 22,784 | 34,365 | 3,250 | 22.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 20 | L0-main | claudeopus46 | 2,320 | 3,088 | 5,408 | 904 | 4.8 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 21 | L0-main | claudeopus46 | 2,543 | 3,740 | 6,283 | 1,590 | 8.4 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 22 | L0-main | claudeopus46 | 1,156 | 7,649 | 8,805 | 2,932 | 12.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 23 | verdict | claudeopus46 | 972 | 7,928 | 8,900 | 1,105 | 9.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_1) |
| 1 | L0-main | claudeopus46 | 11,581 | 820 | 12,401 | 1,392 | 8.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,239 | 25,379 | 716 | 5.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 3 | L1-worker | claudeopus46 | 3,767 | 1,585 | 5,352 | 909 | 6.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 4 | L1-worker | claudeopus46 | 24,140 | 2,401 | 26,541 | 4,672 | 27.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 5 | L1-worker | claudeopus46 | 3,767 | 606 | 4,373 | 905 | 6.0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 6 | L1-worker | claudeopus46 | 24,140 | 4,438 | 28,578 | 682 | 5.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 7 | L1-worker | claudeopus46 | 3,767 | 6,684 | 10,451 | 1,406 | 11.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 8 | L1-worker | claudeopus46 | 24,140 | 6,104 | 30,244 | 2,075 | 12.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 9 | L1-worker | claudeopus46 | 24,140 | 14,761 | 38,901 | 1,763 | 8.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 10 | L1-worker | claudeopus46 | 24,140 | 17,979 | 42,119 | 715 | 4.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 11 | L1-worker | claudeopus46 | 24,140 | 19,479 | 43,619 | 3,590 | 21.0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 12 | L1-worker | claudeopus46 | 24,140 | 21,446 | 45,586 | 3,073 | 16.4 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 13 | L1-worker | claudeopus46 | 24,140 | 24,729 | 48,869 | 2,586 | 17.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 14 | L1-worker | claudeopus46 | 24,140 | 27,477 | 51,617 | 1,256 | 7.2 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 15 | L1-worker | claudeopus46 | 24,140 | 30,849 | 54,989 | 1,958 | 14.3 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 16 | L1-worker | claudeopus46 | 24,140 | 36,474 | 60,614 | 4,461 | 32.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 17 | L1-worker | claudeopus46 | 2,320 | 2,623 | 4,943 | 672 | 5.1 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 18 | L1-worker | claudeopus46 | 627 | 2,503 | 3,130 | 1,075 | 6.6 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 19 | L1-worker | claudeopus46 | 2,543 | 3,983 | 6,526 | 2,713 | 10.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 20 | L1-worker | claudeopus46 | 787 | 31,259 | 32,046 | 587 | 6.0 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 21 | L0-main | claudeopus46 | 11,581 | 21,901 | 33,482 | 2,905 | 20.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 22 | L0-main | claudeopus46 | 2,320 | 2,729 | 5,049 | 858 | 3.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 23 | L0-main | claudeopus46 | 2,543 | 3,381 | 5,924 | 1,488 | 7.4 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 24 | L0-main | claudeopus46 | 1,156 | 7,400 | 8,556 | 3,145 | 13.5 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 25 | verdict | claudeopus46 | 972 | 7,454 | 8,426 | 1,164 | 9.9 | Find pure-component melting temperature (or normal melting p (query_runs/run_2) |
| 1 | L0-main | claudeopus46 | 11,581 | 918 | 12,499 | 1,357 | 7.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,281 | 25,421 | 826 | 5.6 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 3 | L1-worker | claudeopus46 | 3,767 | 3,774 | 7,541 | 1,604 | 13.5 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 4 | L1-worker | claudeopus46 | 24,140 | 2,921 | 27,061 | 1,147 | 7.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 5 | L1-worker | claudeopus46 | 24,140 | 6,516 | 30,656 | 2,480 | 18.0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 6 | L1-worker | claudeopus46 | 24,140 | 13,315 | 37,455 | 2,836 | 19.7 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 7 | L1-worker | claudeopus46 | 24,140 | 20,701 | 44,841 | 3,146 | 21.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 8 | L1-worker | claudeopus46 | 2,543 | 6,592 | 9,135 | 982 | 6.6 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 9 | L1-worker | claudeopus46 | 627 | 5,070 | 5,697 | 803 | 6.6 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 10 | L1-worker | claudeopus46 | 2,320 | 5,190 | 7,510 | 914 | 7.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 11 | L1-worker | claudeopus46 | 787 | 22,251 | 23,038 | 745 | 7.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 12 | L0-main | claudeopus46 | 11,581 | 21,190 | 32,771 | 4,654 | 30.9 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 13 | L0-main | claudeopus46 | 2,543 | 4,392 | 6,935 | 718 | 5.0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 14 | L0-main | claudeopus46 | 2,320 | 3,642 | 5,962 | 1,078 | 6.8 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 15 | L0-main | claudeopus46 | 1,156 | 5,441 | 6,597 | 870 | 4.7 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 16 | verdict | claudeopus46 | 972 | 6,542 | 7,514 | 1,116 | 9.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_4) |
| 1 | L0-main | claudeopus46 | 11,581 | 948 | 12,529 | 1,415 | 7.6 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,326 | 25,466 | 926 | 5.9 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 3 | L1-worker | claudeopus46 | 3,767 | 2,242 | 6,009 | 1,601 | 11.2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 4 | L1-worker | claudeopus46 | 24,140 | 3,190 | 27,330 | 776 | 6.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 5 | L1-worker | claudeopus46 | 24,140 | 5,186 | 29,326 | 1,137 | 8.6 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 6 | L1-worker | claudeopus46 | 24,140 | 6,155 | 30,295 | 1,885 | 13.7 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 7 | L1-worker | claudeopus46 | 24,140 | 8,209 | 32,349 | 942 | 8.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 8 | L1-worker | claudeopus46 | 24,140 | 9,936 | 34,076 | 1,926 | 14.9 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 9 | L1-worker | claudeopus46 | 24,140 | 14,446 | 38,586 | 1,884 | 10.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 10 | L1-worker | claudeopus46 | 2,543 | 3,462 | 6,005 | 559 | 4.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 11 | L1-worker | claudeopus46 | 2,320 | 2,015 | 4,335 | 790 | 5.0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 12 | L1-worker | claudeopus46 | 627 | 1,895 | 2,522 | 923 | 5.7 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 13 | L1-worker | claudeopus46 | 787 | 10,806 | 11,593 | 490 | 5.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 14 | L0-main | claudeopus46 | 11,581 | 14,623 | 26,204 | 2,584 | 19.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 15 | L0-main | claudeopus46 | 2,543 | 3,219 | 5,762 | 650 | 5.3 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 16 | L0-main | claudeopus46 | 2,320 | 2,439 | 4,759 | 1,119 | 5.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 17 | L0-main | claudeopus46 | 1,156 | 3,480 | 4,636 | 425 | 3.6 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 18 | verdict | claudeopus46 | 972 | 5,092 | 6,064 | 1,127 | 9.8 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_5) |
| 1 | L0-main | claudeopus46 | 11,581 | 948 | 12,529 | 1,535 | 8.8 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,459 | 25,599 | 923 | 5.8 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 3 | L1-worker | claudeopus46 | 3,767 | 3,518 | 7,285 | 1,599 | 11.8 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 4 | L1-worker | claudeopus46 | 24,140 | 3,184 | 27,324 | 1,082 | 6.7 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 5 | L1-worker | claudeopus46 | 24,140 | 6,203 | 30,343 | 1,422 | 10.4 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 6 | L1-worker | claudeopus46 | 24,140 | 10,007 | 34,147 | 2,656 | 18.8 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 7 | L1-worker | claudeopus46 | 24,140 | 16,243 | 40,383 | 2,880 | 21.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 8 | L1-worker | claudeopus46 | 24,140 | 22,360 | 46,500 | 2,978 | 21.7 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 9 | L1-worker | claudeopus46 | 2,543 | 6,767 | 9,310 | 1,074 | 6.2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 10 | L1-worker | claudeopus46 | 627 | 5,067 | 5,694 | 852 | 6.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 11 | L1-worker | claudeopus46 | 2,320 | 5,187 | 7,507 | 1,066 | 7.8 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 12 | L1-worker | claudeopus46 | 787 | 22,561 | 23,348 | 882 | 8.6 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 13 | L0-main | claudeopus46 | 11,581 | 22,850 | 34,431 | 3,547 | 25.0 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 14 | L0-main | claudeopus46 | 2,543 | 3,940 | 6,483 | 709 | 5.2 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 15 | L0-main | claudeopus46 | 2,320 | 3,160 | 5,480 | 816 | 5.5 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 16 | L0-main | claudeopus46 | 1,156 | 4,979 | 6,135 | 740 | 5.1 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| 17 | verdict | claudeopus46 | 972 | 5,812 | 6,784 | 1,092 | 8.7 | Find solid-liquid equilibrium (SLE), liquidus, freezing poin (query_runs/run_6) |
| **TOTAL** |  |  | **1,344,779** | **987,066** | **2,331,845** | **184,909** | **1,223.3** |  |
