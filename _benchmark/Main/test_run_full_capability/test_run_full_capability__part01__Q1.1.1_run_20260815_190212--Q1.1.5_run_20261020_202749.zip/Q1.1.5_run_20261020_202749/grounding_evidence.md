# Data grounding evidence

- generated: 2026-10-20T20:57:39
- gate verdict: 28 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_19 | GLOBlit_8264 | NO | — | 1 |
| PROPblock_33 | GLOBlit_8264 | NO | — | 14 |
| PROPblock_34 | GLOBlit_8264 | NO | — | 11 |
| PROPblock_4 | GLOBlit_1484 | NO | — | 1 |
| PROPblock_40 | GLOBlit_8264 | NO | — | 16 |
| PROPblock_41 | GLOBlit_8264 | NO | — | 2 |
| PROPblock_45 | GLOBlit_8264 | NO | — | 15 |
| PROPblock_6 | GLOBlit_2959 | NO | — | 1 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 308.53 | PROPblock_6 + PROPblock_4 + PROPblock_19 | uninspected_block | — |
| 0.21 | PROPblock_6 + PROPblock_4 + PROPblock_19 | uninspected_block | — |
| 278.16 | PROPblock_6 + PROPblock_4 + PROPblock_19 | uninspected_block | — |
| 0.16 | PROPblock_6 + PROPblock_4 + PROPblock_19 | uninspected_block | — |
| 220.3 | PROPblock_6 + PROPblock_4 + PROPblock_19 | uninspected_block | — |
| 1.0 | PROPblock_6 + PROPblock_4 + PROPblock_19 | uninspected_block | — |
| 308.53 | PROPblock_19 | uninspected_block | — |
| 314.45 | PROPblock_19 | uninspected_block | — |
| 277.06 | PROPblock_19 | uninspected_block | — |
| 278.2 | PROPblock_19 | uninspected_block | — |
| 101.3 | PROPblock_19 | uninspected_block | — |
| 2.0 | PROPblock_19 | uninspected_block | — |
| 253.15 | PROPblock_19 | uninspected_block | — |
| 0.2768 | PROPblock_34 | uninspected_block | — |
| 278.2 | PROPblock_34 | uninspected_block | — |
| 265.3 | PROPblock_34 | uninspected_block | — |
| 14 | PROPblock_33 | uninspected_block | — |
| 0.3478 | PROPblock_33 | uninspected_block | — |
| 1.0 | PROPblock_33 | uninspected_block | — |
| 268.4 | PROPblock_33 | uninspected_block | — |
| 311.2 | PROPblock_33 | uninspected_block | — |
| 0.28 | PROPblock_33 | uninspected_block | — |
| 0.35 | PROPblock_33 | uninspected_block | — |
| 265.3 | PROPblock_33 | uninspected_block | — |
| 2.0 | PROPblock_33 | uninspected_block | — |
| 0.2768 | PROPblock_33 | uninspected_block | — |
| 268.4 | PROPblock_34 | uninspected_block | — |
| 2.0 | PROPblock_34 | uninspected_block | — |
| 0.3478 | PROPblock_34 | uninspected_block | — |
| 265 | PROPblock_33 | uninspected_block | — |
| 268 | PROPblock_33 | uninspected_block | — |
| 253.15 | PROPblock_33 | uninspected_block | — |
| 253.15 | PROPblock_33 | uninspected_block | — |
| 16 | PROPblock_40 | uninspected_block | — |
| 0.2499 | PROPblock_40 | uninspected_block | — |
| 1.0 | PROPblock_40 | uninspected_block | — |
| 225.4 | PROPblock_40 | uninspected_block | — |
| 277.2 | PROPblock_40 | uninspected_block | — |
| 0.1678 | PROPblock_41 | uninspected_block | — |
| 211.6 | PROPblock_41 | uninspected_block | — |
| 0.1998 | PROPblock_41 | uninspected_block | — |
| 217.2 | PROPblock_41 | uninspected_block | — |
| 0.17 | PROPblock_41 | uninspected_block | — |
| 0.25 | PROPblock_41 | uninspected_block | — |
| 211.6 | PROPblock_41 | uninspected_block | — |
| 253.15 | PROPblock_41 | uninspected_block | — |
| 220.3 | PROPblock_41 | uninspected_block | — |
| 253.15 | PROPblock_41 | uninspected_block | — |
| 253.15 | PROPblock_40 | uninspected_block | — |
| 0.5011 | PROPblock_40 | uninspected_block | — |
| 250.5 | PROPblock_40 | uninspected_block | — |
| 0.5521 | PROPblock_40 | uninspected_block | — |
| 254.6 | PROPblock_40 | uninspected_block | — |
| 250.5 | PROPblock_40 | uninspected_block | — |
| 253.15 | PROPblock_40 | uninspected_block | — |
| 254.6 | PROPblock_40 | uninspected_block | — |
| 0.53 | PROPblock_40 | uninspected_block | — |
| 0.5011 | PROPblock_40 | uninspected_block | — |
| 253.15 | PROPblock_40 | uninspected_block | — |
| 250.5 | PROPblock_40 | uninspected_block | — |
| 254.6 | PROPblock_40 | uninspected_block | — |
| 250.5 | PROPblock_40 | uninspected_block | — |
| 0.5521 | PROPblock_40 | uninspected_block | — |
| 0.5011 | PROPblock_40 | uninspected_block | — |
| 253.15 | PROPblock_40 | uninspected_block | — |
| 0.53 | PROPblock_40 | uninspected_block | — |
| 0.47 | PROPblock_40 | uninspected_block | — |
| 0.53 | PROPblock_40 | uninspected_block | — |
| 15 | PROPblock_45 | uninspected_block | — |
| 0.3001 | PROPblock_45 | uninspected_block | — |
| 1.0 | PROPblock_45 | uninspected_block | — |
| 253.6 | PROPblock_45 | uninspected_block | — |
| 311.2 | PROPblock_45 | uninspected_block | — |
| 253.6 | PROPblock_45 | uninspected_block | — |
| 2.0 | PROPblock_45 | uninspected_block | — |
| 0.3001 | PROPblock_45 | uninspected_block | — |
| 220.3 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 0.30 | PROPblock_45 | uninspected_block | — |
| 0.3001 | PROPblock_45 | uninspected_block | — |
| 253.6 | PROPblock_45 | uninspected_block | — |
| 0.45 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 0.30 | PROPblock_45 | uninspected_block | — |
| 0.70 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 265 | PROPblock_45 | uninspected_block | — |
| 268 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 211.6 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 0.53 | PROPblock_45 | uninspected_block | — |
| 253.6 | PROPblock_45 | uninspected_block | — |
| 0.30 | PROPblock_45 | uninspected_block | — |
| 0.30 | PROPblock_45 | uninspected_block | — |
| 220.3 | PROPblock_45 | uninspected_block | — |
| 253.6 | PROPblock_45 | uninspected_block | — |
| 0.30 | PROPblock_45 | uninspected_block | — |
| 211.6 | PROPblock_45 | uninspected_block | — |
| 217.2 | PROPblock_45 | uninspected_block | — |
| 211.6 | PROPblock_45 | uninspected_block | — |
| 0.17 | PROPblock_45 | uninspected_block | — |
| 0.25 | PROPblock_45 | uninspected_block | — |
| 0.28 | PROPblock_45 | uninspected_block | — |
| 0.35 | PROPblock_45 | uninspected_block | — |
| 265.3 | PROPblock_45 | uninspected_block | — |
| 268.4 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 0.05 | PROPblock_45 | uninspected_block | — |
| 0.02 | PROPblock_45 | uninspected_block | — |
| 0.03 | PROPblock_45 | uninspected_block | — |
| 308.53 | PROPblock_6 | uninspected_block | — |
| 0.21 | PROPblock_6 | uninspected_block | — |
| 278.16 | PROPblock_4 | uninspected_block | — |
| 0.16 | PROPblock_4 | uninspected_block | — |
| 308.53 | PROPblock_19 | uninspected_block | — |
| 0.21 | PROPblock_19 | uninspected_block | — |
| 278.16 | PROPblock_19 | uninspected_block | — |
| 0.16 | PROPblock_19 | uninspected_block | — |
| 308.53 | PROPblock_19 | uninspected_block | — |
| 0.21 | PROPblock_19 | uninspected_block | — |
| 278.16 | PROPblock_19 | uninspected_block | — |
| 0.16 | PROPblock_19 | uninspected_block | — |
| 308.53 | PROPblock_19 | uninspected_block | — |
| 314.45 | PROPblock_19 | uninspected_block | — |
| 277.06 | PROPblock_19 | uninspected_block | — |
| 278.2 | PROPblock_19 | uninspected_block | — |
| 0.2768 | PROPblock_34 | uninspected_block | — |
| 278.2 | PROPblock_34 | uninspected_block | — |
| 265.3 | PROPblock_34 | uninspected_block | — |
| 0.2768 | PROPblock_34 | uninspected_block | — |
| 278.2 | PROPblock_34 | uninspected_block | — |
| 265.3 | PROPblock_34 | uninspected_block | — |
| 14 | PROPblock_33 | uninspected_block | — |
| 0.3478 | PROPblock_33 | uninspected_block | — |
| 1.0 | PROPblock_33 | uninspected_block | — |
| 268.4 | PROPblock_33 | uninspected_block | — |
| 0.3478 | PROPblock_33 | uninspected_block | — |
| 1.0 | PROPblock_33 | uninspected_block | — |
| 268.4 | PROPblock_33 | uninspected_block | — |
| 311.2 | PROPblock_33 | uninspected_block | — |
| 268.4 | PROPblock_34 | uninspected_block | — |
| 2.0 | PROPblock_34 | uninspected_block | — |
| 0.3478 | PROPblock_34 | uninspected_block | — |
| 2.0 | PROPblock_34 | uninspected_block | — |
| 265 | PROPblock_33 | uninspected_block | — |
| 268 | PROPblock_33 | uninspected_block | — |
| 253.15 | PROPblock_33 | uninspected_block | — |
| 253.15 | PROPblock_33 | uninspected_block | — |
| 268 | PROPblock_33 | uninspected_block | — |
| 16 | PROPblock_40 | uninspected_block | — |
| 0.2499 | PROPblock_40 | uninspected_block | — |
| 1.0 | PROPblock_40 | uninspected_block | — |
| 225.4 | PROPblock_40 | uninspected_block | — |
| 0.2499 | PROPblock_40 | uninspected_block | — |
| 1.0 | PROPblock_40 | uninspected_block | — |
| 225.4 | PROPblock_40 | uninspected_block | — |
| 277.2 | PROPblock_40 | uninspected_block | — |
| 0.1678 | PROPblock_41 | uninspected_block | — |
| 211.6 | PROPblock_41 | uninspected_block | — |
| 0.1998 | PROPblock_41 | uninspected_block | — |
| 217.2 | PROPblock_41 | uninspected_block | — |
| 0.1678 | PROPblock_41 | uninspected_block | — |
| 211.6 | PROPblock_41 | uninspected_block | — |
| 0.1998 | PROPblock_41 | uninspected_block | — |
| 217.2 | PROPblock_41 | uninspected_block | — |
| 253.15 | PROPblock_40 | uninspected_block | — |
| 0.5011 | PROPblock_40 | uninspected_block | — |
| 250.5 | PROPblock_40 | uninspected_block | — |
| 0.5521 | PROPblock_40 | uninspected_block | — |
| 254.6 | PROPblock_40 | uninspected_block | — |
| 0.53 | PROPblock_40 | uninspected_block | — |
| 0.47 | PROPblock_40 | uninspected_block | — |
| 15 | PROPblock_45 | uninspected_block | — |
| 0.3001 | PROPblock_45 | uninspected_block | — |
| 1.0 | PROPblock_45 | uninspected_block | — |
| 253.6 | PROPblock_45 | uninspected_block | — |
| 311.2 | PROPblock_45 | uninspected_block | — |
| 2.0 | PROPblock_45 | uninspected_block | — |
| 220.3 | PROPblock_45 | uninspected_block | — |
| 253.15 | PROPblock_45 | uninspected_block | — |
| 0.30 | PROPblock_45 | uninspected_block | — |
| 0.45 | PROPblock_45 | uninspected_block | — |
| 0.70 | PROPblock_45 | uninspected_block | — |
| 265 | PROPblock_45 | uninspected_block | — |
| 268 | PROPblock_45 | uninspected_block | — |
| 211.6 | PROPblock_45 | uninspected_block | — |
| 0.53 | PROPblock_45 | uninspected_block | — |
| 217.2 | PROPblock_45 | uninspected_block | — |
| 0.17 | PROPblock_45 | uninspected_block | — |
| 0.25 | PROPblock_45 | uninspected_block | — |
| 0.28 | PROPblock_45 | uninspected_block | — |
| 0.35 | PROPblock_45 | uninspected_block | — |
| 265.3 | PROPblock_45 | uninspected_block | — |
| 268.4 | PROPblock_45 | uninspected_block | — |
| 0.05 | PROPblock_45 | uninspected_block | — |
| 0.02 | PROPblock_45 | uninspected_block | — |
| 0.03 | PROPblock_45 | uninspected_block | — |
| 308.53 | PROPblock_6 | uninspected_block | — |
| 0.21 | PROPblock_6 | uninspected_block | — |
| 278.16 | PROPblock_4 | uninspected_block | — |
| 0.16 | PROPblock_4 | uninspected_block | — |

## Violations

- **UNINSPECTED_BLOCK** PROPblock_6 + PROPblock_4 + PROPblock_19: PROPblock_6 + PROPblock_4 + PROPblock_19 is quoted with data values (308.53, 0.21, 278.16, 0.16, …) but was never inspected in this run (values 308.53, 0.21, 278.16, 0.16 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_19: PROPblock_19 is quoted with data values (308.53, 314.45, 277.06, 278.2, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_34: PROPblock_34 is quoted with data values (0.2768, 278.2, 265.3, …) but was never inspected in this run (values 0.2768, 278.2, 265.3 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_33: PROPblock_33 is quoted with data values (14, 0.3478, 1.0, 268.4, …) but was never inspected in this run (values 0.3478, 1.0, 268.4, 311.2 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_34: PROPblock_34 is quoted with data values (268.4, 2.0, 0.3478, …) but was never inspected in this run (values 2.0 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_33: PROPblock_33 is quoted with data values (265, 268, 253.15, 253.15, …) but was never inspected in this run (values 268 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_40: PROPblock_40 is quoted with data values (16, 0.2499, 1.0, 225.4, …) but was never inspected in this run (values 0.2499, 1.0, 225.4, 277.2 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_41: PROPblock_41 is quoted with data values (0.1678, 211.6, 0.1998, 217.2, …) but was never inspected in this run (values 0.1678, 211.6, 0.1998, 217.2 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_40: PROPblock_40 is quoted with data values (253.15, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_40: PROPblock_40 is quoted with data values (0.5011, 250.5, 0.5521, 254.6, …) but was never inspected in this run (values 0.5011, 250.5, 0.5521, 254.6 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_40: PROPblock_40 is quoted with data values (250.5, 253.15, 254.6, 0.53, …) but was never inspected in this run (values 250.5, 254.6, 0.5011, 250.5 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_45: PROPblock_45 is quoted with data values (15, 0.3001, 1.0, 253.6, …) but was never inspected in this run (values 0.3001, 1.0, 253.6, 311.2 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_45: PROPblock_45 is quoted with data values (253.15, 253.15, 265, 268, …) but was never inspected in this run (values 253.6, 0.30 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_45: PROPblock_45 is quoted with data values (0.30, 220.3, 253.6, 0.30, …) but was never inspected in this run (values 0.30, 253.6, 0.30, 0.25 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_6: PROPblock_6 is quoted with data values (308.53, 0.21, …) but was never inspected in this run (values 308.53, 0.21 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_4: PROPblock_4 is quoted with data values (278.16, 0.16, …) but was never inspected in this run (values 278.16, 0.16 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_19: PROPblock_19 is quoted with data values (308.53, 0.21, 278.16, 0.16, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_19: PROPblock_19 is quoted with data values (308.53, 314.45, 277.06, 278.2, …) but was never inspected in this run
- **UNINSPECTED_BLOCK** PROPblock_34: PROPblock_34 is quoted with data values (0.2768, 278.2, 265.3, 0.2768, …) but was never inspected in this run (values 0.2768, 278.2, 265.3, 0.2768 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_33: PROPblock_33 is quoted with data values (14, 0.3478, 1.0, 268.4, …) but was never inspected in this run (values 0.3478, 1.0, 268.4, 0.3478 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_34: PROPblock_34 is quoted with data values (268.4, 2.0, 0.3478, 2.0, …) but was never inspected in this run (values 2.0, 2.0 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_33: PROPblock_33 is quoted with data values (265, 268, 253.15, 253.15, …) but was never inspected in this run (values 268, 268 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_40: PROPblock_40 is quoted with data values (16, 0.2499, 1.0, 225.4, …) but was never inspected in this run (values 0.2499, 1.0, 225.4, 0.2499 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_41: PROPblock_41 is quoted with data values (0.1678, 211.6, 0.1998, 217.2, …) but was never inspected in this run (values 0.1678, 211.6, 0.1998, 217.2 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_40: PROPblock_40 is quoted with data values (253.15, 0.5011, 250.5, 0.5521, …) but was never inspected in this run (values 0.5011, 250.5, 0.5521, 254.6 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_45: PROPblock_45 is quoted with data values (15, 0.3001, 1.0, 253.6, …) but was never inspected in this run (values 0.3001, 1.0, 253.6, 311.2 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_6: PROPblock_6 is quoted with data values (308.53, 0.21, …) but was never inspected in this run (values 308.53, 0.21 verified against the database — inspection is still mandatory)
- **UNINSPECTED_BLOCK** PROPblock_4: PROPblock_4 is quoted with data values (278.16, 0.16, …) but was never inspected in this run (values 278.16, 0.16 verified against the database — inspection is still mandatory)

## Inspections (verbatim)

_none in this run_