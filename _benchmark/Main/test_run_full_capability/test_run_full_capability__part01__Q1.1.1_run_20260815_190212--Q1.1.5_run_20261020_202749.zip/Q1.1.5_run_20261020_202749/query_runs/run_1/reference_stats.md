# Reference Stats — query-agent

**Run started:** 2026-10-20 20:30:46
**Wall time (at last flush):** 275.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 29,181 | 38,081 | 10,268 | 67,262 | 13,452 | 57.2 | claudeopus46 |
| L1-worker | 17 | 218,232 | 157,836 | 30,845 | 376,068 | 22,121 | 195.4 | claudeopus46 |
| verdict | 1 | 972 | 7,928 | 1,105 | 8,900 | 8,900 | 9.6 | claudeopus46 |
| **TOTAL** | **23** | **248,385** | **203,845** | **42,218** | **452,230** | **19,662** | **262.2** | |

**Estimated tokens:** ~113,057 input + ~10,554 output = ~123,611 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 0 | 0 | 2 | 2 | 2 |
| `search_blocks` | 1 | 9 | 2 | 1 | 12 | 27 | 346 |
| `resolve_property_ids` | 0 | 13 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 0 | 0 | 6 | 6 | 6 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **3** | **24** | **2** | **1** | **20** | **35** | **354** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (12 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_7259 |  | search_blocks |
| GLOBlit_8264 |  | search_blocks |
| GLOBlit_618 |  | search_blocks |
| GLOBlit_2207 |  | search_blocks |
| GLOBlit_2950 |  | search_blocks |
| GLOBlit_2959 |  | search_blocks |
| GLOBlit_3799 |  | search_blocks |
| GLOBlit_4207 |  | search_blocks |
| GLOBlit_6343 |  | search_blocks |
| GLOBlit_6589 |  | search_blocks |
| GLOBlit_7516 |  | search_blocks |
| GLOBlit_8285 |  | search_blocks |

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_312 | ethylene carbonate | search_blocks |

#### Properties (20 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_10 | Molar enthalpy of transition or fusion, kJ/mol | search_blocks |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks |
| GLOBprop_12 | Normal melting temperature, K | resolve_property_ids, search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBprop_23 | Critical temperature, K | resolve_property_ids, search_blocks |
| GLOBprop_25 | Critical pressure, kPa | search_blocks |
| GLOBprop_26 |  | resolve_property_ids |
| GLOBprop_16 |  | resolve_property_ids |
| GLOBprop_11 |  | resolve_property_ids |
| GLOBprop_20 |  | resolve_property_ids |
| GLOBprop_57 |  | resolve_property_ids |
| GLOBprop_92 |  | resolve_property_ids |
| GLOBprop_58 |  | resolve_property_ids |
| GLOBprop_82 |  | resolve_property_ids |
| GLOBprop_93 |  | resolve_property_ids |
| GLOBprop_31 |  | resolve_property_ids |
| GLOBprop_14 |  | resolve_property_ids |

#### Measurements (16 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_132 | Molar enthalpy of transition or fusion, kJ/mol | search_blocks |
| GLOBmeas_269 | Molar enthalpy of transition or fusion, kJ/mol | search_blocks |
| GLOBmeas_23 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks |
| GLOBmeas_16 | Normal melting temperature, K | search_blocks |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_63 | Normal melting temperature, K | search_blocks |
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_130 | Normal melting temperature, K | search_blocks |
| GLOBmeas_33 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_57 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_198 | Critical temperature, K | search_blocks |
| GLOBmeas_243 | Normal melting temperature, K | search_blocks |
| GLOBmeas_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_5 | Vapor or sublimation pressure, kPa | search_blocks |

#### Phases (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_2 |  | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBphase_15 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 12 |
| Unique Compounds | 1 |
| Unique Properties | 20 |
| Unique Measurements | 16 |
| Unique Phases | 3 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Total DOIs | 12 |
| Unique parent blocks | 27 |
| Explicit block/subsystem targets | 27 |
| Subsystem targets | 0 |
| Target-matched data points | 354 |

---

## 3. DOI & Block References

**Unique DOIs:** 12  |  **Parent blocks:** 27  |  **Explicit targets:** 27  |  **Subsystems:** 0  |  **Target-matched datapoints:** 346

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2008.03.013 | 2 | 38 | unary | search_blocks |
| 10.1016/j.fluid.2018.05.033 | 3 | 3 | unary | search_blocks |
| 10.1016/j.jct.2008.05.001 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2008.05.012 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2012.12.025 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2014.07.004 | 1 | 5 | unary | search_blocks |
| 10.1016/j.tca.2016.09.007 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.5b00338 | 3 | 13 | unary | search_blocks |
| 10.1021/acs.jced.7b00578 | 6 | 113 | unary | search_blocks |
| 10.1021/acs.jced.8b00298 | 2 | 2 | unary | search_blocks |
| 10.1021/je034134e | 4 | 156 | unary | search_blocks |
| 10.1021/je034173q | 2 | 12 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2008.03.013 | PROPblock_1 | declared | 29 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.03.013 | PROPblock_2 | declared | 9 | unary | — | search_blocks |
| 10.1016/j.fluid.2018.05.033 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2018.05.033 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2018.05.033 | PROPblock_9 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2008.05.001 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2008.05.012 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2012.12.025 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2014.07.004 | PROPblock_1 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.tca.2016.09.007 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00338 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00338 | PROPblock_7 | declared | 9 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00338 | PROPblock_8 | declared | 3 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00578 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00578 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00578 | PROPblock_3 | declared | 30 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00578 | PROPblock_4 | declared | 54 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00578 | PROPblock_5 | declared | 18 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00578 | PROPblock_6 | declared | 9 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00298 | PROPblock_69 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00298 | PROPblock_70 | declared | 1 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_7 | declared | 34 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_8 | declared | 120 | unary | — | search_blocks |
| 10.1021/je034173q | PROPblock_1 | declared | 4 | unary | — | search_blocks |
| 10.1021/je034173q | PROPblock_2 | declared | 8 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_blocks` | compound=GLOBcomp_312, limit=50, property=GLOBprop… | 895 | DISCARD ←in 39 | 837 | 13.3 |
| 2 | 1 | `search_blocks` | compound=GLOBcomp_312, limit=50, property=GLOBprop… | 847 | KEEP ←in 1,964 | 847 | 10.1 |
| 3 | 2 | `search_blocks` | compound=GLOBcomp_312, limit=50, purpose=Find all … | 760 | KEEP ←in 13,547 | 745 | 22.7 |
| 4 | 2 | `resolve_property_ids` | purpose=Find correct property ID for …, queries=['… | 435 | KEEP ←in 1,313 | 435 | 6.8 |
| 5 | 3 | `inspect_block_table` | block_number=PROPblock_9, literature=GLOBlit_2207,… | 630 | — | — | 0.1 |
| 6 | 3 | `inspect_block_table` | block_number=PROPblock_6, literature=GLOBlit_2959,… | 628 | — | — | 0.2 |
| 7 | 3 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_6343,… | 619 | — | — | 0.1 |
| 8 | 4 | `inspect_block_table` | block_number=PROPblock_6, literature=GLOBlit_6589,… | 618 | — | — | 0.1 |
| 9 | 4 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_7259,… | 624 | — | — | 0.1 |
| 10 | 4 | `search_blocks` | compound=GLOBcomp_312, limit=10, property=GLOBprop… | 1,236 | KEEP ←in 5,472 | 1236 | 20.6 |
| 11 | 5 | `inspect_block_table` | block_number=PROPblock_6, literature=GLOBlit_8264,… | 608 | — | — | 0.2 |
| 12 | 5 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_7259,… | 686 | — | — | 0.2 |
| 13 | 5 | `inspect_block_table` | block_number=PROPblock_5, literature=GLOBlit_8264,… | 685 | — | — | 0.2 |
| 14 | 1 | `L1_query` | context=EC = ethylene carbonate, CAS …, id_catalog… | 33,138 | — | — | 212.3 |
| | | **TOTAL (14 tools)** | | **42,409** | | **4,100** | **287.0** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 820 | 12,401 | 1,592 | 9.3 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,448 | 25,588 | 1,428 | 7.5 |
| 3 | L1-worker | claudeopus46 | 3,767 | 482 | 4,249 | 1,498 | 9.9 |
| 4 | L1-worker | claudeopus46 | 3,767 | 2,400 | 6,167 | 1,364 | 9.3 |
| 5 | L1-worker | claudeopus46 | 24,140 | 3,867 | 28,007 | 1,620 | 8.9 |
| 6 | L1-worker | claudeopus46 | 3,767 | 13,912 | 17,679 | 1,573 | 12.5 |
| 7 | L1-worker | claudeopus46 | 3,767 | 1,498 | 5,265 | 827 | 5.6 |
| 8 | L1-worker | claudeopus46 | 24,140 | 5,840 | 29,980 | 2,683 | 15.8 |
| 9 | L1-worker | claudeopus46 | 24,140 | 8,609 | 32,749 | 1,339 | 8.8 |
| 10 | L1-worker | claudeopus46 | 3,767 | 5,824 | 9,591 | 1,542 | 12.2 |
| 11 | L1-worker | claudeopus46 | 24,140 | 11,933 | 36,073 | 1,801 | 11.5 |
| 12 | L1-worker | claudeopus46 | 24,140 | 14,773 | 38,913 | 2,325 | 16.3 |
| 13 | L1-worker | claudeopus46 | 24,140 | 20,130 | 44,270 | 2,310 | 14.8 |
| 14 | L1-worker | claudeopus46 | 24,140 | 25,472 | 49,612 | 5,277 | 33.3 |
| 15 | L1-worker | claudeopus46 | 2,320 | 2,950 | 5,270 | 989 | 6.0 |
| 16 | L1-worker | claudeopus46 | 627 | 2,830 | 3,457 | 989 | 6.2 |
| 17 | L1-worker | claudeopus46 | 2,543 | 4,519 | 7,062 | 2,600 | 9.8 |
| 18 | L1-worker | claudeopus46 | 787 | 31,349 | 32,136 | 680 | 7.0 |
| 19 | L0-main | claudeopus46 | 11,581 | 22,784 | 34,365 | 3,250 | 22.1 |
| 20 | L0-main | claudeopus46 | 2,320 | 3,088 | 5,408 | 904 | 4.8 |
| 21 | L0-main | claudeopus46 | 2,543 | 3,740 | 6,283 | 1,590 | 8.4 |
| 22 | L0-main | claudeopus46 | 1,156 | 7,649 | 8,805 | 2,932 | 12.6 |
| 23 | verdict | claudeopus46 | 972 | 7,928 | 8,900 | 1,105 | 9.6 |

