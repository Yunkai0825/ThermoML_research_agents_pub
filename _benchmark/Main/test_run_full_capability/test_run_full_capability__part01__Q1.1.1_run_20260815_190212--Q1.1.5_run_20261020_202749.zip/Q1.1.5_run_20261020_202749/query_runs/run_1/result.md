# Delegated query run — result

**Question:** Find pure-component melting temperature (or normal melting point, fusion temperature, SLE temperature at x=1 or x=0) data for ethylene carbonate (GLOBcomp_312). Report all blocks with temperatures, uncertainties, and DOIs.

**Iterations:** 2  |  **Elapsed:** 244.3s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Pure-Component Melting Temperature of Ethylene Carbonate

Ethylene carbonate (C₃H₄O₃, CAS 96-49-1) has **six independent measurements** of the **normal melting temperature** (crystal → liquid transition) reported in the ThermoML database. All uncertainties are expanded combined uncertainties (U) at the 95% confidence level.

### Normal Melting Temperature

| # | DOI | Literature ID | Block | T_melt (K) | ±U (K) | Method |
|---|-----|---------------|-------|------------|--------|--------|
| 1 | 10.1016/j.fluid.2018.05.033 | GLOBlit_2207 | PROPblock_9 | 310.56 | 0.77 | Phase equilibration |
| 2 | 10.1016/j.jct.2008.05.012 | GLOBlit_2959 | PROPblock_6 | 308.53 | 0.21 | Heating/cooling curves |
| 3 | 10.1016/j.tca.2016.09.007 | GLOBlit_6343 | PROPblock_1 | 311.15 | 1 | DTA |
| 4 | 10.1021/acs.jced.5b00338 | GLOBlit_6589 | PROPblock_6 | 314.45 | 6 | DTA |
| 5 | 10.1021/acs.jced.7b00578 | GLOBlit_7259 | PROPblock_1 | 309.13 | 0.7 | DTA |
| 6 | 10.1021/je034134e | GLOBlit_8264 | PROPblock_6 | 311.2 | 1 | DTA |

**Key observations:**

- Five of the six values cluster tightly in the range **308.53–311.2 K**, consistent with the commonly cited melting point of ethylene carbonate (~309–311 K).
- The **most precise measurement** is **308.53 ± 0.21 K** (GLOBlit_2959, heating/cooling curve method).
- The value of **314.45 K** (GLOBlit_6589) carries a large uncertainty of ±6 K, so it is statistically consistent with the other measurements within its stated bounds.
- No data were found under GLOBprop_11 (solid–liquid equilibrium temperature) for pure ethylene carbonate; all melting temperature data are stored under GLOBprop_12 (normal melting temperature).

### Molar Enthalpy of Fusion (bonus data)

Two of the above publications also report the **molar enthalpy of the crystal → liquid transition**:

| # | DOI | Literature ID | Block | ΔH_fus (kJ/mol) | ±U (kJ/mol) | Method |
|---|-----|---------------|-------|-----------------|-------------|--------|
| 1 | 10.1021/acs.jced.7b00578 | GLOBlit_7259 | PROPblock_2 | 13.5 | 0.7 | DSC |
| 2 | 10.1021/je034134e | GLOBlit_8264 | PROPblock_5 | 13.02 | 0.85 | DSC |

The two enthalpy of fusion values (13.02 and 13.5 kJ/mol) are mutually consistent and originate from the same publications that report melting temperatures of 309.13 K and 311.2 K, respectively.

### Chemistry context

Ethylene carbonate is a cyclic carbonate ester widely used as a high-permittivity co-solvent in lithium-ion battery electrolytes. Its relatively high melting point (~309–311 K, i.e., ~36–38 °C) means it is a solid at room temperature, which is why it is typically blended with lower-melting carbonates such as dimethyl carbonate or diethyl carbonate to form liquid electrolyte formulations. The moderate enthalpy of fusion (~13 kJ/mol) reflects the moderate intermolecular interactions (dipole–dipole and some ring-stacking) in the crystalline phase.

### Core claims

- Six independent ThermoML measurements of the normal melting temperature of ethylene carbonate (CAS 96-49-1) are reported, with five of six values clustering in the range 308.53–311.2 K.
- The most precise measurement is 308.53 ± 0.21 K (GLOBlit_2959, heating/cooling curve method).
- The outlying value of 314.45 K (GLOBlit_6589) carries a large uncertainty of ±6 K and is statistically consistent with the other measurements within its stated bounds.
- Two measurements of the molar enthalpy of fusion are reported: 13.5 ± 0.7 kJ/mol (GLOBlit_7259) and 13.02 ± 0.85 kJ/mol (GLOBlit_8264), which are mutually consistent.
- All melting temperature data are stored under GLOBprop_12 (normal melting temperature); no data were found under GLOBprop_11 (solid–liquid equilibrium temperature) for pure ethylene carbonate.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2207 | 10.1016/j.fluid.2018.05.033 | PROPblock_9 |  | Provides a normal melting temperature of 310.56 K for pure ethylene carbonate via phase equilibration, directly supporting the answer's first table entry. |
| GLOBlit_2959 | 10.1016/j.jct.2008.05.012 | PROPblock_6 |  | Provides the most precise normal melting temperature of 308.53 K for pure ethylene carbonate via heating/cooling curves, cited in the answer as the most precise measurement. |
| GLOBlit_6343 | 10.1016/j.tca.2016.09.007 | PROPblock_1 |  | Provides a normal melting temperature of 311.15 K for pure ethylene carbonate via DTA, contributing to the answer's compilation of six independent measurements. |
| GLOBlit_6589 | 10.1021/acs.jced.5b00338 | PROPblock_6 |  | Provides a normal melting temperature of 314.45 K for pure ethylene carbonate via DTA; the answer notes its large uncertainty of ±6 K makes it statistically consistent with the other values. |
| GLOBlit_7259 | 10.1021/acs.jced.7b00578 | PROPblock_1 |  | Provides a normal melting temperature of 309.13 K for pure ethylene carbonate via DTA, one of the six independent measurements in the answer. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_6 |  | Provides a normal melting temperature of 311.2 K for pure ethylene carbonate via DTA, contributing to the answer's compilation and consistent with the cluster of values around 309–311 K. |
| GLOBlit_7259 | 10.1021/acs.jced.7b00578 | PROPblock_2 |  | Provides the molar enthalpy of fusion of 13.5 kJ/mol for pure ethylene carbonate via DSC, supporting the bonus enthalpy of fusion data in the answer. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_5 |  | Provides the molar enthalpy of fusion of 13.02 kJ/mol for pure ethylene carbonate via DSC, supporting the bonus enthalpy of fusion data and showing consistency with the 13.5 kJ/mol value. |

### Suggested follow-ups

- Search for solid-liquid equilibrium (SLE) data of ethylene carbonate with common co-solvents (e.g., dimethyl carbonate, diethyl carbonate) to map the eutectic phase diagram relevant to battery electrolyte formulations.
- Compare the molar enthalpy of fusion (~13 kJ/mol) with values for structurally related cyclic carbonates such as propylene carbonate or vinylene carbonate.
- Investigate whether any ThermoML entries report heat capacity data (Cp) for crystalline and liquid ethylene carbonate near the melting point to enable thermodynamic consistency checks.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "prop",
    "global_id": "GLOBprop_12",
    "registry_id": "normal_melting_temperature_k",
    "name": "Normal melting temperature, K"
  }
]
```

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1016/j.fluid.2018.05.033",
    "block_number": "PROPblock_9",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "310.56",
        "normal_melting_temperature_k_U": "0.77"
      }
    ],
    "inspection_id": "INSP_829cab2fd0ad",
    "lit_num_id": "GLOBlit_2207"
  },
  {
    "doi": "10.1016/j.jct.2008.05.012",
    "block_number": "PROPblock_6",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "308.53",
        "normal_melting_temperature_k_U": "0.21"
      }
    ],
    "inspection_id": "INSP_fe473fd52394",
    "lit_num_id": "GLOBlit_2959"
  },
  {
    "doi": "10.1016/j.tca.2016.09.007",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "311.15",
        "normal_melting_temperature_k_U": "1"
      }
    ],
    "inspection_id": "INSP_3262379f54a2",
    "lit_num_id": "GLOBlit_6343"
  },
  {
    "doi": "10.1021/acs.jced.5b00338",
    "block_number": "PROPblock_6",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "314.45",
        "normal_melting_temperature_k_U": "6"
      }
    ],
    "inspection_id": "INSP_97ef67d2d928",
    "lit_num_id": "GLOBlit_6589"
  },
  {
    "doi": "10.1021/acs.jced.7b00578",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "309.13",
        "normal_melting_temperature_k_U": "0.7"
      }
    ],
    "inspection_id": "INSP_24b4e4a513e0",
    "lit_num_id": "GLOBlit_7259"
  },
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_6",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "311.2",
        "normal_melting_temperature_k_U": "1"
      }
    ],
    "inspection_id": "INSP_0a6d0e46da2d",
    "lit_num_id": "GLOBlit_8264"
  },
  {
    "doi": "10.1021/acs.jced.7b00578",
    "block_number": "PROPblock_2",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "molar_enthalpy_of_transition_or_fusion_kj_mol",
      "molar_enthalpy_of_transition_or_fusion_kj_mol_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "molar_enthalpy_of_transition_or_fusion_kj_mol": "13.5",
        "molar_enthalpy_of_transition_or_fusion_kj_mol_U": "0.7"
      }
    ],
    "inspection_id": "INSP_2f2aaf84b6b5",
    "lit_num_id": "GLOBlit_7259"
  },
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_5",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "molar_enthalpy_of_transition_or_fusion_kj_mol",
      "molar_enthalpy_of_transition_or_fusion_kj_mol_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "molar_enthalpy_of_transition_or_fusion_kj_mol": "13.02",
        "molar_enthalpy_of_transition_or_fusion_kj_mol_U": "0.85"
      }
    ],
    "inspection_id": "INSP_1af46cf36b3c",
    "lit_num_id": "GLOBlit_8264"
  }
]
```
