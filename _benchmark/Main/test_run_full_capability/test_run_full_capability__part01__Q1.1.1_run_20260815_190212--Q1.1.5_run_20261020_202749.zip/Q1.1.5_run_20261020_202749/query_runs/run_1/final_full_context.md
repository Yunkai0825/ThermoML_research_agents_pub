## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Numerical Grounding (MANDATORY)

- Every number in your answer (values, compositions, T/p conditions,
  uncertainties, counts, aggregates) must be copied VERBATIM from an
  L1_query result in THIS session, at source precision. Chemistry knowledge
  may guide interpretation — it must never supply a numeric value.
- If L1 returned only aggregates or ranges, report them AS aggregates.
  NEVER write out "representative" per-point values, rows, or smooth-grid
  compositions (0.1, 0.2, …) that no tool result contains — that is
  fabrication even when block/DOI citations are correct.
- Never fill a gap with a plausible number; state the gap. "Row-level
  values were not retrieved" is a valid answer.
- A rejected or errored call has NO result — never write or imagine one.
- L1 envelopes include `data_inspections` — verbatim inspected data
  tables. Quote data points only from those tables or the L1 answer
  verbatim; when a needed sub-block is missing, dispatch an L1 query that
  inspects it (workers have a mandatory `inspect_block_table` gate).
- Write plain markdown tables; delivery hardcode auto-enriches every answer
  table with a leading row-id column and a hardcoded table identifier (e.g.
  `Q#1_Table#2_Row#3`), so never invent such ids — and keep existing ids
  verbatim when quoting an upstream table.
- Chemical insights must stay grounded in the data you present: a
  comparative claim (higher/lower than a baseline or average) must hold
  arithmetically for the values quoted in your answer — otherwise keep
  the insight qualitative.
- Upstream results may carry UNVERIFIED flags. If a flagged value matters
  for your task, resolve it first (re-inspect / re-query its block anchor);
  otherwise treat it with caution under these same rules — never repeat an
  unverified number as verified.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |
| GLOBprop_42 | Relative permittivity (various frequencies) | — |
| GLOBprop_44 | Relative permittivity (zero frequency / static dielectric constant) | — |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| prop | GLOBprop_12 | normal_melting_temperature_k | Normal melting temperature, K |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find pure-component melting temperature (solid-liquid equilibrium temperature, fusion temperature) data for ethylene car → stored as L1_query_1 · validation: FLAGGED(1)

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: FLAGGED(1)

**Summary:**

Six ThermoML blocks report the normal melting temperature (GLOBprop_12) of pure ethylene carbonate (GLOBcomp_312, CAS 96-49-1). Reported values: GLOBlit_2207::PROPblock_9 = 310.56 ± 0.77 K; GLOBlit_2959::PROPblock_6 = 308.53 ± 0.21 K; GLOBlit_6343::PROPblock_1 = 311.15 ± 1 K; GLOBlit_6589::PROPblock_6 = 314.45 ± 6 K; GLOBlit_7259::PROPblock_1 = 309.13 ± 0.7 K; GLOBlit_8264::PROPblock_6 = 311.2 ± 1 K. Most values cluster around 309–311 K; the 314.45 K value carries a large uncertainty making it consistent with the others. The most precise measurement is 308.53 ± 0.21 K from GLOBlit_2959::PROPblock_6. Two blocks also report the molar enthalpy of fusion (GLOBprop_10): GLOBlit_7259::PROPblock_2 = 13.5 ± 0.7 kJ/mol and GLOBlit_8264::PROPblock_5 = 13.02 ± 0.85 kJ/mol. No blocks were found under GLOBprop_11 (solid-liquid equilibrium temperature) for pure ethylene carbonate. All uncertainties are expanded combined uncertainties at the 95% confidence level.

**Answer:**

#### Pure-Component Melting Temperature Data for Ethylene Carbonate (GLOBcomp_312)

Ethylene carbonate (C₃H₄O₃, CAS 96-49-1) has **six ThermoML blocks** reporting the **normal melting temperature** (GLOBprop_12) as a pure (unary) component. All uncertainties are expanded combined uncertainties (U) at the 95% confidence level.

##### Normal Melting Temperature (GLOBprop_12)

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *T_melt (K)* | *±U (K)* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「1」 | 「10.1016/j.fluid.2018.05.033」 | 「GLOBlit_2207」 | 「PROPblock_9」 | 「310.56」 | 「0.77」 |
| WM_L1#1_Table#1_Row#2 | 「2」 | 「10.1016/j.jct.2008.05.012」 | 「GLOBlit_2959」 | 「PROPblock_6」 | 「308.53」 | 「0.21」 |
| WM_L1#1_Table#1_Row#3 | 「3」 | 「10.1016/j.tca.2016.09.007」 | 「GLOBlit_6343」 | 「PROPblock_1」 | 「311.15」 | 「1」 |
| WM_L1#1_Table#1_Row#4 | 「4」 | 「10.1021/acs.jced.5b00338」 | 「GLOBlit_6589」 | 「PROPblock_6」 | 「314.45」 | 「6」 |
| WM_L1#1_Table#1_Row#5 | 「5」 | 「10.1021/acs.jced.7b00578」 | 「GLOBlit_7259」 | 「PROPblock_1」 | 「309.13」 | 「0.7」 |
| WM_L1#1_Table#1_Row#6 | 「6」 | 「10.1021/je034134e」 | 「GLOBlit_8264」 | 「PROPblock_6」 | 「311.2」 | 「1」 |

Most values cluster around 309–311 K, consistent with the commonly cited melting point of ethylene carbonate. The value of 314.45 K (GLOBlit_6589::PROPblock_6) carries a large uncertainty of ±6 K, making it consistent with the other measurements within its stated uncertainty bounds. The most precise measurement is 308.53 ± 0.21 K from GLOBlit_2959::PROPblock_6 (heating/cooling curve method).

##### Molar Enthalpy of Fusion (GLOBprop_10)

Two blocks also report the **molar enthalpy of the crystal→liquid transition** for pure ethylene carbonate:

**WM_L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *ΔH_fus (kJ/mol)* | *±U (kJ/mol)* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「1」 | 「10.1021/acs.jced.7b00578」 | 「GLOBlit_7259」 | 「PROPblock_2」 | 「13.5」 | 「0.7」 |
| WM_L1#1_Table#2_Row#2 | 「2」 | 「10.1021/je034134e」 | 「GLOBlit_8264」 | 「PROPblock_5」 | 「13.02」 | 「0.85」 |

These enthalpy of fusion blocks do not contain an explicit melting temperature variable or constraint within their data tables; however, they originate from the same publications that also report the melting temperature in separate blocks (GLOBlit_7259::PROPblock_1 and GLOBlit_8264::PROPblock_6, respectively).

**Note:** No blocks were found under GLOBprop_11 (solid-liquid equilibrium temperature) for pure ethylene carbonate. All melting temperature data are stored under GLOBprop_12 (normal melting temperature).

**Core claims:**
- Six ThermoML blocks report the normal melting temperature (GLOBprop_12) of pure ethylene carbonate (CAS 96-49-1), with values of 310.56 ± 0.77 K, 308.53 ± 0.21 K, 311.15 ± 1 K, 314.45 ± 6 K, 309.13 ± 0.7 K, and 311.2 ± 1 K; most values cluster around 309–311 K, consistent with the commonly cited melting point.
- The most precise melting temperature measurement is 308.53 ± 0.21 K (GLOBlit_2959::PROPblock_6), and the outlier value of 314.45 ± 6 K (GLOBlit_6589::PROPblock_6) is consistent with the other measurements within its large stated uncertainty.
- Two blocks report the molar enthalpy of fusion for pure ethylene carbonate: 13.5 ± 0.7 kJ/mol (GLOBlit_7259::PROPblock_2) and 13.02 ± 0.85 kJ/mol (GLOBlit_8264::PROPblock_5).
- No blocks were found under GLOBprop_11 (solid-liquid equilibrium temperature) for pure ethylene carbonate; all melting temperature data are stored under GLOBprop_12 (normal melting temperature).

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_2207」 | 「PROPblock_9」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 310.56 ± 0.77 K.」 |
| WM_L1#1_Table#4 | 「GLOBlit_2959」 | 「PROPblock_6」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 308.53 ± 0.21 K, the most precise measurement found.」 |
| WM_L1#1_Table#5 | 「GLOBlit_6343」 | 「PROPblock_1」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 311.15 ± 1 K.」 |
| WM_L1#1_Table#6 | 「GLOBlit_6589」 | 「PROPblock_6」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 314.45 ± 6 K.」 |
| WM_L1#1_Table#7 | 「GLOBlit_7259」 | 「PROPblock_1」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 309.13 ± 0.7 K.」 |
| WM_L1#1_Table#8 | 「GLOBlit_8264」 | 「PROPblock_6」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 311.2 ± 1 K.」 |
| WM_L1#1_Table#9 | 「GLOBlit_7259」 | 「PROPblock_2」 | 「GLOBcomp_312」 | 「GLOBprop_10」 | 「Molar enthalpy of fusion of pure ethylene carbonate reported as 13.5 ± 0.7 kJ/mol.」 |
| WM_L1#1_Table#10 | 「GLOBlit_8264」 | 「PROPblock_5」 | 「GLOBcomp_312」 | 「GLOBprop_10」 | 「Molar enthalpy of fusion of pure ethylene carbonate reported as 13.02 ± 0.85 kJ/mol.」 |

*Not stored here: 8 verbatim data_inspections table(s); 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(1) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **MISATTRIBUTED_VALUE** PROPblock_1: 314.45 does not belong to PROPblock_1; it matches only GLOBlit_6589::PROPblock_6 (inspected this run)



</memory>

## User
[Purpose: Find pure melting point of EC]
Find pure-component melting temperature (or normal melting point, fusion temperature, SLE temperature at x=1 or x=0) data for ethylene carbonate (GLOBcomp_312). Report all blocks with temperatures, uncertainties, and DOIs.

[Context: EC = GLOBcomp_312, formula C3H4O3, SMILES O=C1OCCO1. Literature value ~309-311 K.]

## Assistant
<summary>Dispatching L1 query to find pure-component melting/fusion temperature data for ethylene carbonate (GLOBcomp_312), looking for GLOBprop_11 (solid-liquid equilibrium temperature) in pure-component blocks.</summary>
<tool_call>L1_query(instruction=Search for proper…, id_catalog=GLOBcomp_312 = et…, context=EC = eth…)</tool_call>

## User
<tool_result>
<subagent_answer>
### L1#1 — L1_query return

**Status:** status=success

**Summary:**

Six ThermoML blocks report the normal melting temperature (GLOBprop_12) of pure ethylene carbonate (GLOBcomp_312, CAS 96-49-1). Reported values: GLOBlit_2207::PROPblock_9 = 310.56 ± 0.77 K; GLOBlit_2959::PROPblock_6 = 308.53 ± 0.21 K; GLOBlit_6343::PROPblock_1 = 311.15 ± 1 K; GLOBlit_6589::PROPblock_6 = 314.45 ± 6 K; GLOBlit_7259::PROPblock_1 = 309.13 ± 0.7 K; GLOBlit_8264::PROPblock_6 = 311.2 ± 1 K. Most values cluster around 309–311 K; the 314.45 K value carries a large uncertainty making it consistent with the others. The most precise measurement is 308.53 ± 0.21 K from GLOBlit_2959::PROPblock_6. Two blocks also report the molar enthalpy of fusion (GLOBprop_10): GLOBlit_7259::PROPblock_2 = 13.5 ± 0.7 kJ/mol and GLOBlit_8264::PROPblock_5 = 13.02 ± 0.85 kJ/mol. No blocks were found under GLOBprop_11 (solid-liquid equilibrium temperature) for pure ethylene carbonate. All uncertainties are expanded combined uncertainties at the 95% confidence level.

**Answer:**

#### Pure-Component Melting Temperature Data for Ethylene Carbonate (GLOBcomp_312)

Ethylene carbonate (C₃H₄O₃, CAS 96-49-1) has **six ThermoML blocks** reporting the **normal melting temperature** (GLOBprop_12) as a pure (unary) component. All uncertainties are expanded combined uncertainties (U) at the 95% confidence level.

##### Normal Melting Temperature (GLOBprop_12)

**L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *T_melt (K)* | *±U (K)* |
|---|---|---|---|---|---|---|
| L1#1_Table#1_Row#1 | 「1」 | 「10.1016/j.fluid.2018.05.033」 | 「GLOBlit_2207」 | 「PROPblock_9」 | 「310.56」 | 「0.77」 |
| L1#1_Table#1_Row#2 | 「2」 | 「10.1016/j.jct.2008.05.012」 | 「GLOBlit_2959」 | 「PROPblock_6」 | 「308.53」 | 「0.21」 |
| L1#1_Table#1_Row#3 | 「3」 | 「10.1016/j.tca.2016.09.007」 | 「GLOBlit_6343」 | 「PROPblock_1」 | 「311.15」 | 「1」 |
| L1#1_Table#1_Row#4 | 「4」 | 「10.1021/acs.jced.5b00338」 | 「GLOBlit_6589」 | 「PROPblock_6」 | 「314.45」 | 「6」 |
| L1#1_Table#1_Row#5 | 「5」 | 「10.1021/acs.jced.7b00578」 | 「GLOBlit_7259」 | 「PROPblock_1」 | 「309.13」 | 「0.7」 |
| L1#1_Table#1_Row#6 | 「6」 | 「10.1021/je034134e」 | 「GLOBlit_8264」 | 「PROPblock_6」 | 「311.2」 | 「1」 |

Most values cluster around 309–311 K, consistent with the commonly cited melting point of ethylene carbonate. The value of 314.45 K (GLOBlit_6589::PROPblock_6) carries a large uncertainty of ±6 K, making it consistent with the other measurements within its stated uncertainty bounds. The most precise measurement is 308.53 ± 0.21 K from GLOBlit_2959::PROPblock_6 (heating/cooling curve method).

##### Molar Enthalpy of Fusion (GLOBprop_10)

Two blocks also report the **molar enthalpy of the crystal→liquid transition** for pure ethylene carbonate:

**L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *ΔH_fus (kJ/mol)* | *±U (kJ/mol)* |
|---|---|---|---|---|---|---|
| L1#1_Table#2_Row#1 | 「1」 | 「10.1021/acs.jced.7b00578」 | 「GLOBlit_7259」 | 「PROPblock_2」 | 「13.5」 | 「0.7」 |
| L1#1_Table#2_Row#2 | 「2」 | 「10.1021/je034134e」 | 「GLOBlit_8264」 | 「PROPblock_5」 | 「13.02」 | 「0.85」 |

These enthalpy of fusion blocks do not contain an explicit melting temperature variable or constraint within their data tables; however, they originate from the same publications that also report the melting temperature in separate blocks (GLOBlit_7259::PROPblock_1 and GLOBlit_8264::PROPblock_6, respectively).

**Note:** No blocks were found under GLOBprop_11 (solid-liquid equilibrium temperature) for pure ethylene carbonate. All melting temperature data are stored under GLOBprop_12 (normal melting temperature).

---
[UNGROUNDED DATA FLAGS] The following quoted values could not be verified against any verbatim data inspection in this run and must be treated as UNVERIFIED:
- **MISATTRIBUTED_VALUE** PROPblock_1: 314.45 does not belong to PROPblock_1; it matches only GLOBlit_6589::PROPblock_6 (inspected this run)
  fix (required — this IS a database value, under a different block): `re-anchor 314.45 to GLOBlit_6589::PROPblock_6 — no new tool call needed`
Inspected so far: PROPblock_1, PROPblock_2, PROPblock_5, PROPblock_6, PROPblock_9

**Core claims:**
- Six ThermoML blocks report the normal melting temperature (GLOBprop_12) of pure ethylene carbonate (CAS 96-49-1), with values of 310.56 ± 0.77 K, 308.53 ± 0.21 K, 311.15 ± 1 K, 314.45 ± 6 K, 309.13 ± 0.7 K, and 311.2 ± 1 K; most values cluster around 309–311 K, consistent with the commonly cited melting point.
- The most precise melting temperature measurement is 308.53 ± 0.21 K (GLOBlit_2959::PROPblock_6), and the outlier value of 314.45 ± 6 K (GLOBlit_6589::PROPblock_6) is consistent with the other measurements within its large stated uncertainty.
- Two blocks report the molar enthalpy of fusion for pure ethylene carbonate: 13.5 ± 0.7 kJ/mol (GLOBlit_7259::PROPblock_2) and 13.02 ± 0.85 kJ/mol (GLOBlit_8264::PROPblock_5).
- No blocks were found under GLOBprop_11 (solid-liquid equilibrium temperature) for pure ethylene carbonate; all melting temperature data are stored under GLOBprop_12 (normal melting temperature).

**Core ID updates:**
- add GLOBprop_12 — Normal melting temperature, K (registry: normal_melting_temperature_k)

#### Core blocks found — verbatim ledger

```ledger
**L1#1_Table#3_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_2207 | lit_id: 2018-oh-gu-0 | doi: 10.1016/j.fluid.2018.05.033
block: PROPblock_9 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: ethylene carbonate (C3H4O3; GLOBcomp_312; DOIcomp_3; InChIKey KMTRUDSVKNLOMY-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure ethylene carbonate reported as 310.56 ± 0.77 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#3_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=Phase equilibration (GLOBmeas_16) · range=310.56–310.56 · mean=310.56 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#4_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_2959 | lit_id: 2008-wac-sch-0 | doi: 10.1016/j.jct.2008.05.012
block: PROPblock_6 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: ethylene carbonate (C3H4O3; GLOBcomp_312; DOIcomp_6; InChIKey KMTRUDSVKNLOMY-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure ethylene carbonate reported as 308.53 ± 0.21 K, the most precise measurement found.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#4_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=Heating/Cooling curves (GLOBmeas_63) · range=308.53–308.53 · mean=308.53 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#5_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_6343 | lit_id: 2016-duh-lee-0 | doi: 10.1016/j.tca.2016.09.007
block: PROPblock_1 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: ethylene carbonate (C3H4O3; GLOBcomp_312; DOIcomp_1; InChIKey KMTRUDSVKNLOMY-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure ethylene carbonate reported as 311.15 ± 1 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#5_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=DTA (GLOBmeas_130) · range=311.15–311.15 · mean=311.15 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#6_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_6589 | lit_id: 2016-hof-mig-0 | doi: 10.1021/acs.jced.5b00338
block: PROPblock_6 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: ethylene carbonate (C3H4O3; GLOBcomp_312; DOIcomp_2; InChIKey KMTRUDSVKNLOMY-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure ethylene carbonate reported as 314.45 ± 6 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#6_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=DTA (GLOBmeas_130) · range=314.45–314.45 · mean=314.45 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#7_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_7259 | lit_id: 2017-pok-ste-1 | doi: 10.1021/acs.jced.7b00578
block: PROPblock_1 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: ethylene carbonate (C3H4O3; GLOBcomp_312; DOIcomp_1; InChIKey KMTRUDSVKNLOMY-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure ethylene carbonate reported as 309.13 ± 0.7 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#7_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=DTA (GLOBmeas_130) · range=309.13–309.13 · mean=309.13 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#8_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_8264 | lit_id: 2004-din--0 | doi: 10.1021/je034134e
block: PROPblock_6 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: ethylene carbonate (C3H4O3; GLOBcomp_312; DOIcomp_2; InChIKey KMTRUDSVKNLOMY-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure ethylene carbonate reported as 311.2 ± 1 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#8_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=DTA:UFactor:2 (GLOBmeas_243) · range=311.2–311.2 · mean=311.2 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#9_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_7259 | lit_id: 2017-pok-ste-1 | doi: 10.1021/acs.jced.7b00578
block: PROPblock_2 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: ethylene carbonate (C3H4O3; GLOBcomp_312; DOIcomp_1; InChIKey KMTRUDSVKNLOMY-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_10
description: Molar enthalpy of fusion of pure ethylene carbonate reported as 13.5 ± 0.7 kJ/mol.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#9_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_10」 | 「Molar enthalpy of transition or fusion, kJ/mol」 | 「method=DSC (GLOBmeas_132) · range=13.5–13.5 · mean=13.5 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#10_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_8264 | lit_id: 2004-din--0 | doi: 10.1021/je034134e
block: PROPblock_5 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: ethylene carbonate (C3H4O3; GLOBcomp_312; DOIcomp_2; InChIKey KMTRUDSVKNLOMY-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_10
description: Molar enthalpy of fusion of pure ethylene carbonate reported as 13.02 ± 0.85 kJ/mol.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#10_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_10」 | 「Molar enthalpy of transition or fusion, kJ/mol」 | 「method=DSC:UFactor:2 (GLOBmeas_269) · range=13.02–13.02 · mean=13.02 · n=1 · phase=Crystal」 |
```

#### Data inspections — verbatim ledger

```ledger
**L1#1_Table#11_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_2207 | doi: 10.1016/j.fluid.2018.05.033 | block: PROPblock_9
table_mode: complete | inspection_id: INSP_829cab2fd0ad | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#11_Row#1 | 「BLKpoint_1」 | 「310.56」 | 「0.77」 |
```

```ledger
**L1#1_Table#12_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_2959 | doi: 10.1016/j.jct.2008.05.012 | block: PROPblock_6
table_mode: complete | inspection_id: INSP_fe473fd52394 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#12_Row#1 | 「BLKpoint_1」 | 「308.53」 | 「0.21」 |
```

```ledger
**L1#1_Table#13_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_6343 | doi: 10.1016/j.tca.2016.09.007 | block: PROPblock_1
table_mode: complete | inspection_id: INSP_3262379f54a2 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#13_Row#1 | 「BLKpoint_1」 | 「311.15」 | 「1」 |
```

```ledger
**L1#1_Table#14_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_6589 | doi: 10.1021/acs.jced.5b00338 | block: PROPblock_6
table_mode: complete | inspection_id: INSP_97ef67d2d928 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#14_Row#1 | 「BLKpoint_1」 | 「314.45」 | 「6」 |
```

```ledger
**L1#1_Table#15_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_7259 | doi: 10.1021/acs.jced.7b00578 | block: PROPblock_1
table_mode: complete | inspection_id: INSP_24b4e4a513e0 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#15_Row#1 | 「BLKpoint_1」 | 「309.13」 | 「0.7」 |
```

```ledger
**L1#1_Table#16_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_8264 | doi: 10.1021/je034134e | block: PROPblock_6
table_mode: complete | inspection_id: INSP_0a6d0e46da2d | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#16_Row#1 | 「BLKpoint_1」 | 「311.2」 | 「1」 |
```

```ledger
**L1#1_Table#17_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_7259 | doi: 10.1021/acs.jced.7b00578 | block: PROPblock_2
table_mode: complete | inspection_id: INSP_2f2aaf84b6b5 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *molar_enthalpy_of_transition_or_fusion_kj_mol* | *molar_enthalpy_of_transition_or_fusion_kj_mol_U* |
|---|---|---|---|
| L1#1_Table#17_Row#1 | 「BLKpoint_1」 | 「13.5」 | 「0.7」 |
```

```ledger
**L1#1_Table#18_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_8264 | doi: 10.1021/je034134e | block: PROPblock_5
table_mode: complete | inspection_id: INSP_1af46cf36b3c | rows_shown: 1

| *row_id* | *BLKpoint_id* | *molar_enthalpy_of_transition_or_fusion_kj_mol* | *molar_enthalpy_of_transition_or_fusion_kj_mol_U* |
|---|---|---|---|
| L1#1_Table#18_Row#1 | 「BLKpoint_1」 | 「13.02」 | 「0.85」 |
```
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<reasoning>
The L1 query has returned comprehensive data. All values have been verified through data inspections. The MISATTRIBUTED_VALUE flag from the earlier run has been resolved - 314.45 K correctly belongs to GLOBlit_6589::PROPblock_6, not PROPblock_1. All data is now grounded. I can provide the final answer.
</reasoning>

<answer>

## Pure-Component Melting Temperature of Ethylene Carbonate

Ethylene carbonate (C₃H₄O₃, CAS 96-49-1) has **six independent measurements** of the **normal melting temperature** (crystal → liquid transition) reported in the ThermoML database. All uncertainties are expanded combined uncertainties (U) at the 95% confidence level.

### Normal Melting Temperature

| # | DOI | Literature ID | Block | T_melt (K) | ±U (K) | Method |
|---|-----|---------------|-------|------------|--------|--------|
| 1 | 10.1016/j.fluid.2018.05.033 | GLOBlit_2207 | PROPblock_9 | 310.56 | 0.77 | Phase equilibration |
| 2 | 10.1016/j.jct.2008.05.012 | GLOBlit_2959 | PROPblock_6 | 308.53 | 0.21 | Heating/cooling curves |
| 3 | 10.1016/j.tca.2016.09.007 | GLOBlit_6343 | PROPblock_1 | 311.15 | 1 | DTA |
| 4 | 10.1021/acs.jced.5b00338 | GLOBlit_6589 | PROPblock_6 | 314.45 | 6 | DTA |
| 5 | 10.1021/acs.jced.7b00578 | GLOBlit_7259 | PROPblock_1 | 309.13 | 0.7 | DTA |
| 6 | 10.1021/je034134e | GLOBlit_8264 | PROPblock_6 | 311.2 | 1 | DTA |

**Key observations:**

- Five of the six values cluster tightly in the range **308.53–311.2 K**, consistent with the commonly cited melting point of ethylene carbonate (~309–311 K).
- The **most precise measurement** is **308.53 ± 0.21 K** (GLOBlit_2959, heating/cooling curve method).
- The value of **314.45 K** (GLOBlit_6589) carries a large uncertainty of ±6 K, so it is statistically consistent with the other measurements within its stated bounds.
- No data were found under GLOBprop_11 (solid–liquid equilibrium temperature) for pure ethylene carbonate; all melting temperature data are stored under GLOBprop_12 (normal melting temperature).

### Molar Enthalpy of Fusion (bonus data)

Two of the above publications also report the **molar enthalpy of the crystal → liquid transition**:

| # | DOI | Literature ID | Block | ΔH_fus (kJ/mol) | ±U (kJ/mol) | Method |
|---|-----|---------------|-------|-----------------|-------------|--------|
| 1 | 10.1021/acs.jced.7b00578 | GLOBlit_7259 | PROPblock_2 | 13.5 | 0.7 | DSC |
| 2 | 10.1021/je034134e | GLOBlit_8264 | PROPblock_5 | 13.02 | 0.85 | DSC |

The two enthalpy of fusion values (13.02 and 13.5 kJ/mol) are mutually consistent and originate from the same publications that report melting temperatures of 309.13 K and 311.2 K, respectively.

### Chemistry context

Ethylene carbonate is a cyclic carbonate ester widely used as a high-permittivity co-solvent in lithium-ion battery electrolytes. Its relatively high melting point (~309–311 K, i.e., ~36–38 °C) means it is a solid at room temperature, which is why it is typically blended with lower-melting carbonates such as dimethyl carbonate or diethyl carbonate to form liquid electrolyte formulations. The moderate enthalpy of fusion (~13 kJ/mol) reflects the moderate intermolecular interactions (dipole–dipole and some ring-stacking) in the crystalline phase.

</answer>