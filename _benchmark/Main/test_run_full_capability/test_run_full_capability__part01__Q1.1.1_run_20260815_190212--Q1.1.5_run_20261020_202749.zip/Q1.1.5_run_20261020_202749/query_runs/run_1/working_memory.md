# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| prop | GLOBprop_12 | normal_melting_temperature_k | Normal melting temperature, K |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find pure-component melting temperature (solid-liquid equilibrium temperature, fusion temperature) data for ethylene car → stored as L1_query_1 · validation: FLAGGED(1)

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: FLAGGED(1)

**Summary:**

Six ThermoML blocks report the normal melting temperature (GLOBprop_12) of pure ethylene carbonate (GLOBcomp_312, CAS 96-49-1). Reported values: GLOBlit_2207::PROPblock_9 = 310.56 ± 0.77 K; GLOBlit_2959::PROPblock_6 = 308.53 ± 0.21 K; GLOBlit_6343::PROPblock_1 = 311.15 ± 1 K; GLOBlit_6589::PROPblock_6 = 314.45 ± 6 K; GLOBlit_7259::PROPblock_1 = 309.13 ± 0.7 K; GLOBlit_8264::PROPblock_6 = 311.2 ± 1 K. Most values cluster around 309–311 K; the 314.45 K value carries a large uncertainty making it consistent with the others. The most precise measurement is 308.53 ± 0.21 K from GLOBlit_2959::PROPblock_6. Two blocks also report the molar enthalpy of fusion (GLOBprop_10): GLOBlit_7259::PROPblock_2 = 13.5 ± 0.7 kJ/mol and GLOBlit_8264::PROPblock_5 = 13.02 ± 0.85 kJ/mol. No blocks were found under GLOBprop_11 (solid-liquid equilibrium temperature) for pure ethylene carbonate. All uncertainties are expanded combined uncertainties at the 95% confidence level.

**Answer:**

#### Pure-Component Melting Temperature Data for Ethylene Carbonate (GLOBcomp_312)

Ethylene carbonate (C₃H₄O₃, CAS 96-49-1) has **six ThermoML blocks** reporting the **normal melting temperature** (GLOBprop_12) as a pure (unary) component. All uncertainties are expanded combined uncertainties (U) at the 95% confidence level.

##### Normal Melting Temperature (GLOBprop_12)

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *T_melt (K)* | *±U (K)* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「1」 | 「10.1016/j.fluid.2018.05.033」 | 「GLOBlit_2207」 | 「PROPblock_9」 | 「310.56」 | 「0.77」 |
| WM_L1#1_Table#1_Row#2 | 「2」 | 「10.1016/j.jct.2008.05.012」 | 「GLOBlit_2959」 | 「PROPblock_6」 | 「308.53」 | 「0.21」 |
| WM_L1#1_Table#1_Row#3 | 「3」 | 「10.1016/j.tca.2016.09.007」 | 「GLOBlit_6343」 | 「PROPblock_1」 | 「311.15」 | 「1」 |
| WM_L1#1_Table#1_Row#4 | 「4」 | 「10.1021/acs.jced.5b00338」 | 「GLOBlit_6589」 | 「PROPblock_6」 | 「314.45」 | 「6」 |
| WM_L1#1_Table#1_Row#5 | 「5」 | 「10.1021/acs.jced.7b00578」 | 「GLOBlit_7259」 | 「PROPblock_1」 | 「309.13」 | 「0.7」 |
| WM_L1#1_Table#1_Row#6 | 「6」 | 「10.1021/je034134e」 | 「GLOBlit_8264」 | 「PROPblock_6」 | 「311.2」 | 「1」 |

Most values cluster around 309–311 K, consistent with the commonly cited melting point of ethylene carbonate. The value of 314.45 K (GLOBlit_6589::PROPblock_6) carries a large uncertainty of ±6 K, making it consistent with the other measurements within its stated uncertainty bounds. The most precise measurement is 308.53 ± 0.21 K from GLOBlit_2959::PROPblock_6 (heating/cooling curve method).

##### Molar Enthalpy of Fusion (GLOBprop_10)

Two blocks also report the **molar enthalpy of the crystal→liquid transition** for pure ethylene carbonate:

**WM_L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *ΔH_fus (kJ/mol)* | *±U (kJ/mol)* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「1」 | 「10.1021/acs.jced.7b00578」 | 「GLOBlit_7259」 | 「PROPblock_2」 | 「13.5」 | 「0.7」 |
| WM_L1#1_Table#2_Row#2 | 「2」 | 「10.1021/je034134e」 | 「GLOBlit_8264」 | 「PROPblock_5」 | 「13.02」 | 「0.85」 |

These enthalpy of fusion blocks do not contain an explicit melting temperature variable or constraint within their data tables; however, they originate from the same publications that also report the melting temperature in separate blocks (GLOBlit_7259::PROPblock_1 and GLOBlit_8264::PROPblock_6, respectively).

**Note:** No blocks were found under GLOBprop_11 (solid-liquid equilibrium temperature) for pure ethylene carbonate. All melting temperature data are stored under GLOBprop_12 (normal melting temperature).

**Core claims:**
- Six ThermoML blocks report the normal melting temperature (GLOBprop_12) of pure ethylene carbonate (CAS 96-49-1), with values of 310.56 ± 0.77 K, 308.53 ± 0.21 K, 311.15 ± 1 K, 314.45 ± 6 K, 309.13 ± 0.7 K, and 311.2 ± 1 K; most values cluster around 309–311 K, consistent with the commonly cited melting point.
- The most precise melting temperature measurement is 308.53 ± 0.21 K (GLOBlit_2959::PROPblock_6), and the outlier value of 314.45 ± 6 K (GLOBlit_6589::PROPblock_6) is consistent with the other measurements within its large stated uncertainty.
- Two blocks report the molar enthalpy of fusion for pure ethylene carbonate: 13.5 ± 0.7 kJ/mol (GLOBlit_7259::PROPblock_2) and 13.02 ± 0.85 kJ/mol (GLOBlit_8264::PROPblock_5).
- No blocks were found under GLOBprop_11 (solid-liquid equilibrium temperature) for pure ethylene carbonate; all melting temperature data are stored under GLOBprop_12 (normal melting temperature).

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_2207」 | 「PROPblock_9」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 310.56 ± 0.77 K.」 |
| WM_L1#1_Table#4 | 「GLOBlit_2959」 | 「PROPblock_6」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 308.53 ± 0.21 K, the most precise measurement found.」 |
| WM_L1#1_Table#5 | 「GLOBlit_6343」 | 「PROPblock_1」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 311.15 ± 1 K.」 |
| WM_L1#1_Table#6 | 「GLOBlit_6589」 | 「PROPblock_6」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 314.45 ± 6 K.」 |
| WM_L1#1_Table#7 | 「GLOBlit_7259」 | 「PROPblock_1」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 309.13 ± 0.7 K.」 |
| WM_L1#1_Table#8 | 「GLOBlit_8264」 | 「PROPblock_6」 | 「GLOBcomp_312」 | 「GLOBprop_12」 | 「Normal melting temperature of pure ethylene carbonate reported as 311.2 ± 1 K.」 |
| WM_L1#1_Table#9 | 「GLOBlit_7259」 | 「PROPblock_2」 | 「GLOBcomp_312」 | 「GLOBprop_10」 | 「Molar enthalpy of fusion of pure ethylene carbonate reported as 13.5 ± 0.7 kJ/mol.」 |
| WM_L1#1_Table#10 | 「GLOBlit_8264」 | 「PROPblock_5」 | 「GLOBcomp_312」 | 「GLOBprop_10」 | 「Molar enthalpy of fusion of pure ethylene carbonate reported as 13.02 ± 0.85 kJ/mol.」 |

*Not stored here: 8 verbatim data_inspections table(s); 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(1) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **MISATTRIBUTED_VALUE** PROPblock_1: 314.45 does not belong to PROPblock_1; it matches only GLOBlit_6589::PROPblock_6 (inspected this run)


