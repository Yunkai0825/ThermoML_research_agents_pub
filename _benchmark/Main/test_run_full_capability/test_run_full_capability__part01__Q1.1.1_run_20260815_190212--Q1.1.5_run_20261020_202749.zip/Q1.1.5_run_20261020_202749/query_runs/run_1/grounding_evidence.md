# Data grounding evidence

- generated: 2026-10-20T20:34:51
- gate verdict: 11 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | GLOBlit_6343 | yes | INSP_3262379f54a2, INSP_24b4e4a513e0 | 1 |
| PROPblock_2 | GLOBlit_7259 | yes | INSP_2f2aaf84b6b5 | 1 |
| PROPblock_5 | GLOBlit_8264 | yes | INSP_1af46cf36b3c | 1 |
| PROPblock_6 | GLOBlit_2959 | yes | INSP_fe473fd52394, INSP_97ef67d2d928, INSP_0a6d0e46da2d | 1 |
| PROPblock_9 | GLOBlit_2207 | yes | INSP_829cab2fd0ad | 1 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 310.56 | PROPblock_9 + PROPblock_6 + PROPblock_1 | verified | — |
| 0.77 | PROPblock_9 + PROPblock_6 + PROPblock_1 | verified | — |
| 308.53 | PROPblock_9 + PROPblock_6 + PROPblock_1 | verified | — |
| 0.21 | PROPblock_9 + PROPblock_6 + PROPblock_1 | verified | — |
| 311.15 | PROPblock_9 + PROPblock_6 + PROPblock_1 | verified | — |
| 314.45 | PROPblock_9 + PROPblock_6 + PROPblock_1 | verified | — |
| 309.13 | PROPblock_9 + PROPblock_6 + PROPblock_1 | verified | — |
| 0.7 | PROPblock_9 + PROPblock_6 + PROPblock_1 | verified | — |
| 311.2 | PROPblock_9 + PROPblock_6 + PROPblock_1 | verified | — |
| 308.53 | PROPblock_1 | misattributed | PROPblock_6 |
| 311.2 | PROPblock_1 | verified | — |
| 309 | PROPblock_1 | verified | — |
| 311 | PROPblock_1 | verified | — |
| 308.53 | PROPblock_1 | misattributed | PROPblock_6 |
| 0.21 | PROPblock_1 | misattributed | PROPblock_6 |
| 314.45 | PROPblock_1 | misattributed | PROPblock_6 |
| 13.5 | PROPblock_2 + PROPblock_5 | verified | — |
| 0.7 | PROPblock_2 + PROPblock_5 | verified | — |
| 13.02 | PROPblock_2 + PROPblock_5 | verified | — |
| 0.85 | PROPblock_2 + PROPblock_5 | verified | — |
| 13.02 | PROPblock_5 | verified | — |
| 13.5 | PROPblock_5 | misattributed | PROPblock_2 |
| 309.13 | PROPblock_5 | misattributed | PROPblock_1 |
| 311.2 | PROPblock_5 | ambiguous | 2 sources |
| 309 | PROPblock_5 | ambiguous | 2 sources |
| 311 | PROPblock_5 | ambiguous | 3 sources |
| 36 | PROPblock_5 | ungrounded | — |
| 38 | PROPblock_5 | ungrounded | — |
| 13 | PROPblock_5 | verified | — |

## Violations

- **MISATTRIBUTED_VALUE** PROPblock_1: 308.53 does not belong to PROPblock_1; it matches only GLOBlit_2959::PROPblock_6 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 308.53 does not belong to PROPblock_1; it matches only GLOBlit_2959::PROPblock_6 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 0.21 does not belong to PROPblock_1; it matches only GLOBlit_2959::PROPblock_6 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 314.45 does not belong to PROPblock_1; it matches only GLOBlit_2959::PROPblock_6 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 13.5 does not belong to PROPblock_5; it matches only GLOBlit_7259::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 309.13 does not belong to PROPblock_5; it matches only GLOBlit_6343::PROPblock_1 (inspected this run)
- **AMBIGUOUS_VALUE** PROPblock_5: 311.2 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** PROPblock_5: 309 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** PROPblock_5: 311 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** PROPblock_5: 36 (near '…ytes. Its relatively high melting point (~309–311 K, i.e., ~…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 38 (near '…s. Its relatively high melting point (~309–311 K, i.e., ~36–…') matches no inspected row/stat, database table, or other source of PROPblock_5

## Inspections (verbatim)

### INSP_829cab2fd0ad — GLOBlit_2207::PROPblock_9 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_fe473fd52394 — GLOBlit_2959::PROPblock_6 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_3262379f54a2 — GLOBlit_6343::PROPblock_1 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_97ef67d2d928 — GLOBlit_6589::PROPblock_6 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_24b4e4a513e0 — GLOBlit_7259::PROPblock_1 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_0a6d0e46da2d — GLOBlit_8264::PROPblock_6 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_2f2aaf84b6b5 — GLOBlit_7259::PROPblock_2 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_1af46cf36b3c — GLOBlit_8264::PROPblock_5 (complete, 1 rows shown)

_structured envelope entry (no markdown)_
