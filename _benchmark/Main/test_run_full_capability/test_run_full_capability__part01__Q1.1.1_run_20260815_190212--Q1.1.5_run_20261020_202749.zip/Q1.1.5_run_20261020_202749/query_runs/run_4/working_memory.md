# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find solid-liquid equilibrium (SLE) temperature data for the binary mixture of ethylene carbonate (EC) and dimethyl carb → stored as L1_query_1 · validation: FLAGGED(5)

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: FLAGGED(5)

**Summary:**

Solid-liquid equilibrium (SLE) temperatures for the binary mixture ethylene carbonate (EC) + dimethyl carbonate (DMC) were measured by DTA at 101.3 kPa (DOI 10.1021/je034134e, GLOBlit_8264), with an expanded uncertainty U = 2.0 K (95% confidence). The system exhibits a classic eutectic phase diagram reported in two data blocks. The DMC-rich liquidus branch (PROPblock_34) contains 11 points spanning x(EC) = 0 to 0.2768 with T_SLE from 278.2 K (pure DMC melting point) down to 265.3 K. The EC-rich liquidus branch (PROPblock_33) contains 14 points spanning x(EC) = 0.3478 to 1.0 with T_SLE from 268.4 K up to 311.2 K (pure EC melting point). The eutectic composition lies between x(EC) ≈ 0.28 and 0.35, with a eutectic temperature near 265–268 K. Both branches show near-linear behavior.

**Answer:**

#### Solid-Liquid Equilibrium (SLE) Temperature Data for Ethylene Carbonate (EC) + Dimethyl Carbonate (DMC) Binary Mixture

**Source:** DOI 10.1021/je034134e (GLOBlit_8264)

The SLE data for the EC + DMC binary system were measured by DTA (Differential Thermal Analysis) at a pressure of 101.3 kPa. The system exhibits a eutectic, with two liquidus branches reported in separate data blocks. All temperatures carry an expanded uncertainty of U = 2.0 K (95% confidence level).

---

##### DMC-Rich Liquidus Branch (PROPblock_34)
This branch spans x(EC) = 0 to 0.2768, with the SLE temperature decreasing monotonically as EC is added to pure DMC (freezing point depression of DMC).

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *x(EC) (mole fraction, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「0.0000」 | 「278.2」 | 「2.0」 |
| WM_L1#1_Table#1_Row#2 | 「0.0501」 | 「274.8」 | 「2.0」 |
| WM_L1#1_Table#1_Row#3 | 「0.0770」 | 「273.6」 | 「2.0」 |
| WM_L1#1_Table#1_Row#4 | 「0.1011」 | 「272.7」 | 「2.0」 |
| WM_L1#1_Table#1_Row#5 | 「0.1258」 | 「271.6」 | 「2.0」 |
| WM_L1#1_Table#1_Row#6 | 「0.1515」 | 「270.7」 | 「2.0」 |
| WM_L1#1_Table#1_Row#7 | 「0.1761」 | 「269.4」 | 「2.0」 |
| WM_L1#1_Table#1_Row#8 | 「0.2013」 | 「268.8」 | 「2.0」 |
| WM_L1#1_Table#1_Row#9 | 「0.2246」 | 「267.3」 | 「2.0」 |
| WM_L1#1_Table#1_Row#10 | 「0.2489」 | 「266.4」 | 「2.0」 |
| WM_L1#1_Table#1_Row#11 | 「0.2768」 | 「265.3」 | 「2.0」 |

(Complete: 11 of 11 data points shown.)

The pure DMC melting point from this block is 278.2 K (at x(EC) = 0), and the lowest SLE temperature on this branch is 265.3 K at x(EC) = 0.2768.

---

##### EC-Rich Liquidus Branch (PROPblock_33)
This branch spans x(EC) = 0.3478 to 1.0, with the SLE temperature increasing monotonically from the eutectic region up to the melting point of pure EC.

**WM_L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *x(EC) (mole fraction, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「0.3478」 | 「268.4」 | 「2.0」 |
| WM_L1#1_Table#2_Row#2 | 「0.4016」 | 「271.7」 | 「2.0」 |
| WM_L1#1_Table#2_Row#3 | 「0.5505」 | 「283.8」 | 「2.0」 |
| WM_L1#1_Table#2_Row#4 | 「0.6513」 | 「289.4」 | 「2.0」 |
| WM_L1#1_Table#2_Row#5 | 「0.7009」 | 「291.6」 | 「2.0」 |
| WM_L1#1_Table#2_Row#6 | 「0.7505」 | 「295.1」 | 「2.0」 |
| WM_L1#1_Table#2_Row#7 | 「0.8467」 | 「299.8」 | 「2.0」 |
| WM_L1#1_Table#2_Row#8 | 「1.0000」 | 「311.2」 | 「2.0」 |

(RDP-compressed: 8 of 14 data points shown; the full block contains 14 points spanning x(EC) = 0.3478–1.0, T = 268.4–311.2 K.)

The pure EC melting point from this block is 311.2 K (at x(EC) = 1), and the lowest SLE temperature on this branch is 268.4 K at x(EC) = 0.3478.

---

##### Chemistry Insight

The data describe a classic eutectic phase diagram:

- **Pure DMC melting point (PROPblock_34):** 278.2 K at x(EC) = 0
- **Pure EC melting point (PROPblock_33):** 311.2 K at x(EC) = 1
- **Eutectic region:** The lowest recorded SLE temperature on the DMC-rich branch (PROPblock_34) is 265.3 K at x(EC) = 0.2768, and the lowest on the EC-rich branch (PROPblock_33) is 268.4 K at x(EC) = 0.3478, placing the eutectic composition between x(EC) ≈ 0.28 and 0.35, with a eutectic temperature near 265–268 K.

Both branches show near-linear behavior (R² > 0.99). The freezing point depression relative to the pure components is substantial (derived by subtraction of inspected endpoint values): DMC is depressed by approximately 12.9 K (278.2 from PROPblock_34 minus 265.3 from PROPblock_34) and EC by approximately 42.8 K (311.2 from PROPblock_33 minus 268.4 from PROPblock_33). This significant mutual freezing point depression reflects the strong liquid-phase miscibility of these two carbonates, which is directly relevant to their widespread use as co-solvents in lithium-ion battery electrolytes where low-temperature performance is critical.

**Core claims:**
- SLE data for the ethylene carbonate (EC) + dimethyl carbonate (DMC) binary system (DOI 10.1021/je034134e) were measured by DTA at 101.3 kPa with an expanded uncertainty U = 2.0 K (95% confidence level).
- The system exhibits a classic eutectic phase diagram: the DMC-rich liquidus branch spans x(EC) = 0 to 0.2768 with T_SLE decreasing from 278.2 K (pure DMC melting point) to 265.3 K; the EC-rich liquidus branch spans x(EC) = 0.3478 to 1.0 with T_SLE increasing from 268.4 K to 311.2 K (pure EC melting point).
- The eutectic composition lies between x(EC) ≈ 0.28 and 0.35, with a eutectic temperature near 265–268 K.
- Several derived values (12.9 K and 42.8 K freezing-point depressions) and certain cross-block attributions were flagged as UNVERIFIED or MISATTRIBUTED, meaning their provenance could not be fully confirmed within the inspection run.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_8264」 | 「PROPblock_34」 | 「GLOBcomp_312, GLOBcomp_62」 | 「GLOBprop_11」 | 「DMC-rich liquidus branch of the EC+DMC SLE phase diagram, providing 11 solid-liquid equilibrium temperature data points from x(EC)=0 to 0.2768 at 101.3 kPa with U=2.0 K.」 |
| WM_L1#1_Table#4 | 「GLOBlit_8264」 | 「PROPblock_33」 | 「GLOBcomp_312, GLOBcomp_62」 | 「GLOBprop_11」 | 「EC-rich liquidus branch of the EC+DMC SLE phase diagram, providing 14 solid-liquid equilibrium temperature data points from x(EC)=0.3478 to 1.0 at 101.3 kPa with U=2.0 K.」 |

*Not stored here: 2 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(5) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **MISATTRIBUTED_VALUE** PROPblock_33: 265 does not belong to PROPblock_33; it matches only GLOBlit_8264::PROPblock_34 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_33: 12.9 (near '…spected endpoint values): DMC is depressed by approximately …') matches no inspected row/stat, database table, or other source of PROPblock_33
- **MISATTRIBUTED_VALUE** PROPblock_33: 278.2 does not belong to PROPblock_33; it matches only GLOBlit_8264::PROPblock_34 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_34: 42.8 (near '…) and EC by approximately 42.8 K (311.2 from…') matches no inspected row/stat, database table, or other source of PROPblock_34
- **MISATTRIBUTED_VALUE** PROPblock_34: 311.2 does not belong to PROPblock_34; it matches only GLOBlit_8264::PROPblock_33 (inspected this run)


