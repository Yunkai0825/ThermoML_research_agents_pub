# Data grounding evidence

- generated: 2026-10-20T20:36:03
- gate verdict: 14 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_33 | GLOBlit_8264 | yes | INSP_dc7f01aaa8f4 | 14 |
| PROPblock_34 | GLOBlit_8264 | yes | INSP_f7a6d7dbdf0d | 11 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 0.2768 | PROPblock_34 | verified | — |
| 0.0000 | PROPblock_34 | verified | — |
| 278.2 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.0501 | PROPblock_34 | verified | — |
| 274.8 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.0770 | PROPblock_34 | verified | — |
| 273.6 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.1011 | PROPblock_34 | verified | — |
| 272.7 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.1258 | PROPblock_34 | verified | — |
| 271.6 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.1515 | PROPblock_34 | verified | — |
| 270.7 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.1761 | PROPblock_34 | verified | — |
| 269.4 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.2013 | PROPblock_34 | verified | — |
| 268.8 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.2246 | PROPblock_34 | verified | — |
| 267.3 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.2489 | PROPblock_34 | verified | — |
| 266.4 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 0.2768 | PROPblock_34 | verified | — |
| 265.3 | PROPblock_34 | verified | — |
| 2.0 | PROPblock_34 | verified | — |
| 278.2 | PROPblock_34 | verified | — |
| 265.3 | PROPblock_34 | verified | — |
| 0.2768 | PROPblock_34 | verified | — |
| 0.3478 | PROPblock_33 | verified | — |
| 1.0 | PROPblock_33 | verified | — |
| 14 | PROPblock_33 | ungrounded | — |
| 0.3478 | PROPblock_33 | verified | — |
| 268.4 | PROPblock_33 | verified | — |
| 2.0 | PROPblock_33 | verified | — |
| 0.4016 | PROPblock_33 | verified | — |
| 271.7 | PROPblock_33 | verified | — |
| 2.0 | PROPblock_33 | verified | — |
| 0.5505 | PROPblock_33 | verified | — |
| 283.8 | PROPblock_33 | verified | — |
| 2.0 | PROPblock_33 | verified | — |
| 0.6513 | PROPblock_33 | verified | — |
| 289.4 | PROPblock_33 | verified | — |
| 2.0 | PROPblock_33 | verified | — |
| 0.7009 | PROPblock_33 | verified | — |
| 291.6 | PROPblock_33 | verified | — |
| 2.0 | PROPblock_33 | verified | — |
| 0.7505 | PROPblock_33 | verified | — |
| 295.1 | PROPblock_33 | verified | — |
| 2.0 | PROPblock_33 | verified | — |
| 0.8467 | PROPblock_33 | verified | — |
| 299.8 | PROPblock_33 | verified | — |
| 2.0 | PROPblock_33 | verified | — |
| 1.0000 | PROPblock_33 | verified | — |
| 311.2 | PROPblock_33 | verified | — |
| 2.0 | PROPblock_33 | verified | — |
| 311.2 | PROPblock_33 | verified | — |
| 1.0 | PROPblock_33 | verified | — |
| 268.4 | PROPblock_33 | verified | — |
| 0.3478 | PROPblock_33 | verified | — |
| 0.28 | PROPblock_33 | verified | — |
| 0.35 | PROPblock_33 | verified | — |
| 265 | PROPblock_33 | misattributed | PROPblock_34 |
| 268 | PROPblock_33 | verified | — |
| 265.3 | PROPblock_33 | misattributed | PROPblock_34 |
| 0.2768 | PROPblock_33 | misattributed | PROPblock_34 |
| 268.4 | PROPblock_34 | misattributed | PROPblock_33 |
| 0.3478 | PROPblock_34 | misattributed | PROPblock_33 |
| 12.9 | PROPblock_33 | ungrounded | — |
| 278.2 | PROPblock_33 | misattributed | PROPblock_34 |
| 265.3 | PROPblock_33 | misattributed | PROPblock_34 |
| 42.8 | PROPblock_34 | ungrounded | — |
| 311.2 | PROPblock_34 | misattributed | PROPblock_33 |
| 268.4 | PROPblock_34 | misattributed | PROPblock_33 |
| 265 | PROPblock_33 | misattributed | PROPblock_34 |
| 0.2768 | PROPblock_34 + PROPblock_33 | verified | — |
| 265.3 | PROPblock_34 + PROPblock_33 | verified | — |
| 278.2 | PROPblock_34 + PROPblock_33 | verified | — |
| 0.3478 | PROPblock_34 + PROPblock_33 | verified | — |
| 1.0 | PROPblock_34 + PROPblock_33 | verified | — |
| 268.4 | PROPblock_34 + PROPblock_33 | verified | — |
| 311.2 | PROPblock_34 + PROPblock_33 | verified | — |
| 14 | PROPblock_34 + PROPblock_33 | ungrounded | — |

## Violations

- **UNGROUNDED_LITERAL** PROPblock_33: 14 (near '…of EC upon addition of DMC, spanning x(EC) = 0.3478 to 1.0 (…') matches no inspected row/stat, database table, or other source of PROPblock_33
- **MISATTRIBUTED_VALUE** PROPblock_33: 265 does not belong to PROPblock_33; it matches only GLOBlit_8264::PROPblock_34 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_33: 265.3 does not belong to PROPblock_33; it matches only GLOBlit_8264::PROPblock_34 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_33: 0.2768 does not belong to PROPblock_33; it matches only GLOBlit_8264::PROPblock_34 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_34: 268.4 does not belong to PROPblock_34; it matches only GLOBlit_8264::PROPblock_33 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_34: 0.3478 does not belong to PROPblock_34; it matches only GLOBlit_8264::PROPblock_33 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_33: 12.9 (near '…bstantial on both sides: DMC's melting point drops by about …') matches no inspected row/stat, database table, or other source of PROPblock_33
- **MISATTRIBUTED_VALUE** PROPblock_33: 278.2 does not belong to PROPblock_33; it matches only GLOBlit_8264::PROPblock_34 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_33: 265.3 does not belong to PROPblock_33; it matches only GLOBlit_8264::PROPblock_34 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_34: 42.8 (near '…he DMC-rich branch, while EC's melting point drops by about …') matches no inspected row/stat, database table, or other source of PROPblock_34
- **MISATTRIBUTED_VALUE** PROPblock_34: 311.2 does not belong to PROPblock_34; it matches only GLOBlit_8264::PROPblock_33 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_34: 268.4 does not belong to PROPblock_34; it matches only GLOBlit_8264::PROPblock_33 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_33: 265 does not belong to PROPblock_33; it matches only GLOBlit_8264::PROPblock_34 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_34 + PROPblock_33: 14 (near '…| SLE temperature ( ) | x(EC) = 0.3478–1.0 | 268.4–311.2 | 1…') matches no inspected row/stat, database table, or other source of PROPblock_34 + PROPblock_33

## Inspections (verbatim)

### INSP_dc7f01aaa8f4 — GLOBlit_8264::PROPblock_33 (rdp, 8 rows shown)

_structured envelope entry (no markdown)_

### INSP_f7a6d7dbdf0d — GLOBlit_8264::PROPblock_34 (complete, 11 rows shown)

_structured envelope entry (no markdown)_
