# Reference Stats — query-agent

**Run started:** 2026-10-20 20:33:34
**Wall time (at last flush):** 170.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 29,181 | 35,583 | 8,677 | 64,764 | 12,952 | 54.8 | claudeopus46 |
| L1-worker | 10 | 130,744 | 87,611 | 15,483 | 218,355 | 21,835 | 113.0 | claudeopus46 |
| verdict | 1 | 972 | 6,542 | 1,116 | 7,514 | 7,514 | 9.4 | claudeopus46 |
| **TOTAL** | **16** | **160,897** | **129,736** | **25,276** | **290,633** | **18,164** | **177.2** | |

**Estimated tokens:** ~72,658 input + ~6,319 output = ~78,977 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 2 | 1 | 1 | 1 | 1 | 2 | 25 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **1** | **1** | **1** | **1** | **2** | **25** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8264 |  | search_blocks |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_312 | ethylene carbonate | search_blocks |
| GLOBcomp_62 | dimethyl carbonate | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_230 | Solid-liquid equilibrium temperature, K | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 1 |
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Unique Constraints | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 2 |
| Explicit block/subsystem targets | 2 |
| Subsystem targets | 0 |
| Target-matched data points | 25 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 2  |  **Explicit targets:** 2  |  **Subsystems:** 0  |  **Target-matched datapoints:** 25

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je034134e | 2 | 25 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je034134e | PROPblock_33 | declared | 14 | binary | — | search_blocks |
| 10.1021/je034134e | PROPblock_34 | declared | 11 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_blocks` | compound=['GLOBcomp_312', 'GLOBcomp_62…, limit=50,… | 1,161 | KEEP ←in 3,348 | 1161 | 21.2 |
| 2 | 2 | `inspect_block_table` | block_number=PROPblock_33, literature=GLOBlit_8264… | 1,385 | — | — | 0.2 |
| 3 | 2 | `inspect_block_table` | block_number=PROPblock_34, literature=GLOBlit_8264… | 1,429 | — | — | 0.2 |
| 4 | 1 | `L1_query` | context=Looking for liquidus curves, …, id_catalog… | 23,242 | — | — | 109.3 |
| | | **TOTAL (4 tools)** | | **27,217** | | **1,161** | **130.9** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 918 | 12,499 | 1,357 | 7.4 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,281 | 25,421 | 826 | 5.6 |
| 3 | L1-worker | claudeopus46 | 3,767 | 3,774 | 7,541 | 1,604 | 13.5 |
| 4 | L1-worker | claudeopus46 | 24,140 | 2,921 | 27,061 | 1,147 | 7.4 |
| 5 | L1-worker | claudeopus46 | 24,140 | 6,516 | 30,656 | 2,480 | 18.0 |
| 6 | L1-worker | claudeopus46 | 24,140 | 13,315 | 37,455 | 2,836 | 19.7 |
| 7 | L1-worker | claudeopus46 | 24,140 | 20,701 | 44,841 | 3,146 | 21.4 |
| 8 | L1-worker | claudeopus46 | 2,543 | 6,592 | 9,135 | 982 | 6.6 |
| 9 | L1-worker | claudeopus46 | 627 | 5,070 | 5,697 | 803 | 6.6 |
| 10 | L1-worker | claudeopus46 | 2,320 | 5,190 | 7,510 | 914 | 7.1 |
| 11 | L1-worker | claudeopus46 | 787 | 22,251 | 23,038 | 745 | 7.1 |
| 12 | L0-main | claudeopus46 | 11,581 | 21,190 | 32,771 | 4,654 | 30.9 |
| 13 | L0-main | claudeopus46 | 2,543 | 4,392 | 6,935 | 718 | 5.0 |
| 14 | L0-main | claudeopus46 | 2,320 | 3,642 | 5,962 | 1,078 | 6.8 |
| 15 | L0-main | claudeopus46 | 1,156 | 5,441 | 6,597 | 870 | 4.7 |
| 16 | verdict | claudeopus46 | 972 | 6,542 | 7,514 | 1,116 | 9.4 |

