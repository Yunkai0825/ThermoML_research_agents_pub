# Delegated query run — result

**Question:** Find solid-liquid equilibrium (SLE), liquidus, freezing point, or fusion temperature data for the binary mixture of ethylene carbonate (GLOBcomp_312) and dimethyl carbonate (GLOBcomp_62). Report all blocks with temperatures, compositions, uncertainties, and DOIs.

**Iterations:** 2  |  **Elapsed:** 149.1s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Solid-Liquid Equilibrium (SLE) Data for Ethylene Carbonate (EC) + Dimethyl Carbonate (DMC)

**Source:** DOI 10.1021/je034134e (GLOBlit_8264)

The SLE temperatures for the EC + DMC binary system were measured by Differential Thermal Analysis (DTA) at a pressure of 101.3 kPa. The system exhibits a classic eutectic phase diagram, reported across two data blocks. All temperatures carry an expanded uncertainty of **U = 2.0 K** (95% confidence level).

---

### DMC-Rich Liquidus Branch (PROPblock_34)

This branch covers the freezing point depression of DMC upon addition of EC, spanning x(EC) = 0 to 0.2768 (11 data points, complete):

| x(EC) (mole fraction, liquid) | T_SLE (K) | U (K) |
|:---:|:---:|:---:|
| 0.0000 | 278.2 | 2.0 |
| 0.0501 | 274.8 | 2.0 |
| 0.0770 | 273.6 | 2.0 |
| 0.1011 | 272.7 | 2.0 |
| 0.1258 | 271.6 | 2.0 |
| 0.1515 | 270.7 | 2.0 |
| 0.1761 | 269.4 | 2.0 |
| 0.2013 | 268.8 | 2.0 |
| 0.2246 | 267.3 | 2.0 |
| 0.2489 | 266.4 | 2.0 |
| 0.2768 | 265.3 | 2.0 |

- **Pure DMC melting point:** 278.2 K (at x(EC) = 0)
- **Lowest T on this branch:** 265.3 K at x(EC) = 0.2768

---

### EC-Rich Liquidus Branch (PROPblock_33)

This branch covers the freezing point depression of EC upon addition of DMC, spanning x(EC) = 0.3478 to 1.0 (14 data points total; 8 representative points shown below from RDP compression):

| x(EC) (mole fraction, liquid) | T_SLE (K) | U (K) |
|:---:|:---:|:---:|
| 0.3478 | 268.4 | 2.0 |
| 0.4016 | 271.7 | 2.0 |
| 0.5505 | 283.8 | 2.0 |
| 0.6513 | 289.4 | 2.0 |
| 0.7009 | 291.6 | 2.0 |
| 0.7505 | 295.1 | 2.0 |
| 0.8467 | 299.8 | 2.0 |
| 1.0000 | 311.2 | 2.0 |

- **Pure EC melting point:** 311.2 K (at x(EC) = 1.0)
- **Lowest T on this branch:** 268.4 K at x(EC) = 0.3478

---

### Eutectic Region

The eutectic composition lies between x(EC) ≈ 0.28 and 0.35, in the gap between the two measured liquidus branches. The eutectic temperature is approximately 265–268 K, bounded by the lowest measured points on each branch:
- 265.3 K at x(EC) = 0.2768 (PROPblock_34, DMC-rich side)
- 268.4 K at x(EC) = 0.3478 (PROPblock_33, EC-rich side)

### Chemistry Insight

The EC + DMC system forms a simple eutectic with no intermediate solid phases. The freezing point depression is substantial on both sides: DMC's melting point drops by about 12.9 K (computed: 278.2 − 265.3, both from PROPblock_34) across the DMC-rich branch, while EC's melting point drops by about 42.8 K (computed: 311.2 − 268.4, both from PROPblock_33) across the EC-rich branch. The much larger depression on the EC side reflects the asymmetry typical of systems where one component (EC) has a significantly higher melting point. This mutual freezing point depression is directly relevant to lithium-ion battery electrolyte formulation, where EC/DMC mixtures are standard co-solvents chosen specifically because the eutectic temperature (~265 K / −8 °C) is far below either pure component's melting point, enabling liquid-phase operation over a wide temperature range.

**Block summary:**

| Block | Literature | Compounds | Property | Composition range | T range (K) | Points |
|---|---|---|---|---|---|---|
| PROPblock_34 | GLOBlit_8264 (10.1021/je034134e) | EC (GLOBcomp_312) + DMC (GLOBcomp_62) | SLE temperature (GLOBprop_11) | x(EC) = 0–0.2768 | 265.3–278.2 | 11 |
| PROPblock_33 | GLOBlit_8264 (10.1021/je034134e) | EC (GLOBcomp_312) + DMC (GLOBcomp_62) | SLE temperature (GLOBprop_11) | x(EC) = 0.3478–1.0 | 268.4–311.2 | 14 |

### Core claims

- SLE temperatures for the ethylene carbonate (EC) + dimethyl carbonate (DMC) binary system were measured by DTA at 101.3 kPa, with an expanded uncertainty of U = 2.0 K (95% confidence level), sourced from DOI 10.1021/je034134e.
- The system exhibits a simple eutectic phase diagram with no intermediate solid phases, comprising a DMC-rich liquidus branch (x(EC) = 0 to 0.2768, T_SLE = 278.2 to 265.3 K, 11 points) and an EC-rich liquidus branch (x(EC) = 0.3478 to 1.0, T_SLE = 268.4 to 311.2 K, 14 points).
- The pure DMC melting point is 278.2 K and the pure EC melting point is 311.2 K.
- The eutectic composition lies between x(EC) ≈ 0.28 and 0.35, with the eutectic temperature approximately 265–268 K, bounded by the lowest measured points on each branch: 265.3 K at x(EC) = 0.2768 and 268.4 K at x(EC) = 0.3478.
- The freezing point depression is substantially larger on the EC-rich side (about 42.8 K) than on the DMC-rich side (about 12.9 K), reflecting the asymmetry of the system.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_34 |  | Provides the DMC-rich liquidus branch of the EC + DMC SLE phase diagram with 11 data points spanning x(EC) = 0–0.2768 and T = 265.3–278.2 K, including the pure DMC melting point and the approach to the eutectic from the DMC side. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_33 |  | Provides the EC-rich liquidus branch of the EC + DMC SLE phase diagram with 14 data points spanning x(EC) = 0.3478–1.0 and T = 268.4–311.2 K, including the pure EC melting point and the approach to the eutectic from the EC side. |

### Suggested follow-ups

- Search for additional SLE data for EC+DMC from other literature sources to compare eutectic temperature and composition estimates.
- Look for excess enthalpy or activity coefficient data for the EC+DMC system to support thermodynamic modeling of the liquidus curves.
- Check for ternary SLE data involving EC, DMC, and a third carbonate solvent (e.g., EMC or PC) relevant to battery electrolyte optimization.

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_33",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<ethylene carbonate>",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "mole_fraction_<ethylene carbonate>": "0.3478",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "268.4",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "mole_fraction_<ethylene carbonate>": "0.4016",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "271.7",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "mole_fraction_<ethylene carbonate>": "0.5505",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "283.8",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "mole_fraction_<ethylene carbonate>": "0.6513",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "289.4",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "mole_fraction_<ethylene carbonate>": "0.7009",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "291.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "mole_fraction_<ethylene carbonate>": "0.7505",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "295.1",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "mole_fraction_<ethylene carbonate>": "0.8467",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "299.8",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "mole_fraction_<ethylene carbonate>": "1",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "311.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      }
    ],
    "inspection_id": "INSP_dc7f01aaa8f4",
    "lit_num_id": "GLOBlit_8264"
  },
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_34",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<ethylene carbonate>",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "mole_fraction_<ethylene carbonate>": "0",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "278.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "mole_fraction_<ethylene carbonate>": "0.0501",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "274.8",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "mole_fraction_<ethylene carbonate>": "0.077",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "273.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "mole_fraction_<ethylene carbonate>": "0.1011",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "272.7",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "mole_fraction_<ethylene carbonate>": "0.1258",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "271.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "mole_fraction_<ethylene carbonate>": "0.1515",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "270.7",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "mole_fraction_<ethylene carbonate>": "0.1761",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "269.4",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "mole_fraction_<ethylene carbonate>": "0.2013",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "268.8",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "mole_fraction_<ethylene carbonate>": "0.2246",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "267.3",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "mole_fraction_<ethylene carbonate>": "0.2489",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "266.4",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "mole_fraction_<ethylene carbonate>": "0.2768",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "265.3",
        "solidliquid_equilibrium_temperature_k_U": "2"
      }
    ],
    "inspection_id": "INSP_f7a6d7dbdf0d",
    "lit_num_id": "GLOBlit_8264"
  }
]
```
