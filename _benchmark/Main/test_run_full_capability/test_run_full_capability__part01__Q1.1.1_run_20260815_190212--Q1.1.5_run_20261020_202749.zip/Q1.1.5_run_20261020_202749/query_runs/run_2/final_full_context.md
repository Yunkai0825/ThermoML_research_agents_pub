## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Numerical Grounding (MANDATORY)

- Every number in your answer (values, compositions, T/p conditions,
  uncertainties, counts, aggregates) must be copied VERBATIM from an
  L1_query result in THIS session, at source precision. Chemistry knowledge
  may guide interpretation — it must never supply a numeric value.
- If L1 returned only aggregates or ranges, report them AS aggregates.
  NEVER write out "representative" per-point values, rows, or smooth-grid
  compositions (0.1, 0.2, …) that no tool result contains — that is
  fabrication even when block/DOI citations are correct.
- Never fill a gap with a plausible number; state the gap. "Row-level
  values were not retrieved" is a valid answer.
- A rejected or errored call has NO result — never write or imagine one.
- L1 envelopes include `data_inspections` — verbatim inspected data
  tables. Quote data points only from those tables or the L1 answer
  verbatim; when a needed sub-block is missing, dispatch an L1 query that
  inspects it (workers have a mandatory `inspect_block_table` gate).
- Write plain markdown tables; delivery hardcode auto-enriches every answer
  table with a leading row-id column and a hardcoded table identifier (e.g.
  `Q#1_Table#2_Row#3`), so never invent such ids — and keep existing ids
  verbatim when quoting an upstream table.
- Chemical insights must stay grounded in the data you present: a
  comparative claim (higher/lower than a baseline or average) must hold
  arithmetically for the values quoted in your answer — otherwise keep
  the insight qualitative.
- Upstream results may carry UNVERIFIED flags. If a flagged value matters
  for your task, resolve it first (re-inspect / re-query its block anchor);
  otherwise treat it with caution under these same rules — never repeat an
  unverified number as verified.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |
| GLOBprop_42 | Relative permittivity (various frequencies) | — |
| GLOBprop_44 | Relative permittivity (zero frequency / static dielectric constant) | — |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find pure-component melting temperature (solid-liquid equilibrium temperature) data for dimethyl carbonate (DMC) → stored as L1_query_1 · validation: FLAGGED(1)

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: FLAGGED(1)

**Summary:**

Eight independent ThermoML measurements of the pure-component melting (fusion) temperature of dimethyl carbonate (DMC, GLOBcomp_62) are reported under two property definitions (solid-liquid equilibrium temperature GLOBprop_11 and normal melting temperature GLOBprop_12), all at atmospheric pressure for the crystal-to-liquid transition. Reported values range from 277.06 K to 278.2 K. Specific values: 278.11 ± 4 K (GLOBlit_2251, GLOBprop_11, visual observation); 278.16 ± 0.16 K (GLOBlit_1484, visual observation); 278.2 ± 0.4 K (GLOBlit_1560, visual observation); 277.52 ± 0.77 K (GLOBlit_2207, phase equilibration); 277.06 ± 0.6 K (GLOBlit_2959, heating/cooling curves); 277.57 ± 0.7 K (GLOBlit_7175, DTA); 278.2 ± 1 K (GLOBlit_8264, DTA); 278.16 ± 0.62 K (GLOBlit_9437, visual observation). The most precise measurement is 278.16 ± 0.16 K from GLOBlit_1484. All uncertainties are at the 95% confidence level. A data-flag note indicates that the value 277.06 K was misattributed to PROPblock_10 in the answer but actually belongs to GLOBlit_2959 PROPblock_5.

**Answer:**

#### Pure-Component Melting Temperature of Dimethyl Carbonate (DMC)

The ThermoML database contains melting/fusion temperature data for pure dimethyl carbonate (GLOBcomp_62) under two property definitions:

##### 1. Solid-Liquid Equilibrium Temperature (GLOBprop_11)

One data block was found:

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *DOI* | *Block* | *T_melt (K)* | *±U (K)* | *P (kPa)* | *Method* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「10.1016/j.fluid.2018.09.023 [GLOBlit_2251]」 | 「PROPblock_5」 | 「278.11」 | 「4」 | 「101」 | 「Visual observation」 |

##### 2. Normal Melting Temperature (GLOBprop_12)

Seven literature sources report this property, all at 1 atm (crystal → liquid transition):

**WM_L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *DOI* | *Block* | *GLOBlit* | *T_melt (K)* | *±U (K)* | *Method* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「10.1016/j.fluid.2014.05.033」 | 「PROPblock_4」 | 「GLOBlit_1484」 | 「278.16」 | 「0.16」 | 「Visual observation」 |
| WM_L1#1_Table#2_Row#2 | 「10.1016/j.fluid.2014.09.024」 | 「PROPblock_4」 | 「GLOBlit_1560」 | 「278.2」 | 「0.4」 | 「Visual observation」 |
| WM_L1#1_Table#2_Row#3 | 「10.1016/j.fluid.2018.05.033」 | 「PROPblock_3」 | 「GLOBlit_2207」 | 「277.52」 | 「0.77」 | 「Phase equilibration」 |
| WM_L1#1_Table#2_Row#4 | 「10.1016/j.jct.2008.05.012」 | 「PROPblock_5」 | 「GLOBlit_2959」 | 「277.06」 | 「0.6」 | 「Heating/cooling curves」 |
| WM_L1#1_Table#2_Row#5 | 「10.1021/acs.jced.7b00295」 | 「PROPblock_1」 | 「GLOBlit_7175」 | 「277.57」 | 「0.7」 | 「DTA」 |
| WM_L1#1_Table#2_Row#6 | 「10.1021/je034134e」 | 「PROPblock_10」 | 「GLOBlit_8264」 | 「278.2」 | 「1」 | 「DTA」 |
| WM_L1#1_Table#2_Row#7 | 「10.1021/je101199g」 | 「PROPblock_4」 | 「GLOBlit_9437」 | 「278.16」 | 「0.62」 | 「Visual observation」 |

##### Summary

Across all 8 independent measurements (both property IDs), the reported melting temperature of pure DMC ranges from 277.06 K (GLOBlit_2959, PROPblock_5) to 278.2 K (GLOBlit_1560, PROPblock_4 and GLOBlit_8264, PROPblock_10). All uncertainties are reported at the 95% confidence level. The most precise measurement is from GLOBlit_1484 (PROPblock_4, 10.1016/j.fluid.2014.05.033) at 278.16 ± 0.16 K. All measurements were performed on unary (pure component) systems at atmospheric pressure, observing the crystal-to-liquid phase transition.

**Core claims:**
- The ThermoML database contains 8 independent measurements of the melting temperature of pure dimethyl carbonate (DMC) at atmospheric pressure, spanning a range from 277.06 K to 278.2 K, with all uncertainties reported at the 95% confidence level.
- The most precise reported measurement is 278.16 ± 0.16 K (from DOI 10.1016/j.fluid.2014.05.033, GLOBlit_1484, visual observation method).
- One value (277.06 K) was flagged as misattributed to PROPblock_10 in the answer's own ungrounded-data audit; it actually belongs to GLOBlit_2251::PROPblock_5, so the attribution in the summary table for that entry is unreliable.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_2251」 | 「PROPblock_5」 | 「GLOBcomp_62」 | 「GLOBprop_11」 | 「Solid-liquid equilibrium temperature of pure dimethyl carbonate measured at 101 kPa by visual observation, reporting 278.11 ± 4 K.」 |
| WM_L1#1_Table#4 | 「GLOBlit_1484」 | 「PROPblock_4」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 278.16 ± 0.16 K by visual observation; most precise measurement found.」 |
| WM_L1#1_Table#5 | 「GLOBlit_1560」 | 「PROPblock_4」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 278.2 ± 0.4 K by visual observation.」 |
| WM_L1#1_Table#6 | 「GLOBlit_2207」 | 「PROPblock_3」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 277.52 ± 0.77 K by phase equilibration.」 |
| WM_L1#1_Table#7 | 「GLOBlit_2959」 | 「PROPblock_5」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 277.06 ± 0.6 K by heating/cooling curves; lowest value found.」 |
| WM_L1#1_Table#8 | 「GLOBlit_7175」 | 「PROPblock_1」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 277.57 ± 0.7 K by DTA.」 |
| WM_L1#1_Table#9 | 「GLOBlit_8264」 | 「PROPblock_10」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 278.2 ± 1 K by DTA.」 |
| WM_L1#1_Table#10 | 「GLOBlit_9437」 | 「PROPblock_4」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 278.16 ± 0.62 K by visual observation.」 |

*Not stored here: 8 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(1) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **MISATTRIBUTED_VALUE** PROPblock_10: 277.06 does not belong to PROPblock_10; it matches only GLOBlit_2251::PROPblock_5 (inspected this run)



</memory>

## User
[Purpose: Find pure melting point of DMC]
Find pure-component melting temperature (or normal melting point, fusion temperature, SLE temperature at x=1 or x=0) data for dimethyl carbonate (GLOBcomp_62). Report all blocks with temperatures, uncertainties, and DOIs.

[Context: DMC = GLOBcomp_62, formula C3H6O3, SMILES COC(=O)OC. Literature value ~277-278 K.]

## Assistant
<summary>Dispatching L1 query to find pure-component melting point (solid-liquid equilibrium temperature, GLOBprop_11) data for dimethyl carbonate (GLOBcomp_62).</summary>
<tool_call>L1_query(instruction=Search for proper…, id_catalog=GLOBcomp_62 = dim…, context=DMC = di…)</tool_call>

## User
<tool_result>
<subagent_answer>
### L1#1 — L1_query return

**Status:** status=success

**Summary:**

Eight independent ThermoML measurements of the pure-component melting (fusion) temperature of dimethyl carbonate (DMC, GLOBcomp_62) are reported under two property definitions (solid-liquid equilibrium temperature GLOBprop_11 and normal melting temperature GLOBprop_12), all at atmospheric pressure for the crystal-to-liquid transition. Reported values range from 277.06 K to 278.2 K. Specific values: 278.11 ± 4 K (GLOBlit_2251, GLOBprop_11, visual observation); 278.16 ± 0.16 K (GLOBlit_1484, visual observation); 278.2 ± 0.4 K (GLOBlit_1560, visual observation); 277.52 ± 0.77 K (GLOBlit_2207, phase equilibration); 277.06 ± 0.6 K (GLOBlit_2959, heating/cooling curves); 277.57 ± 0.7 K (GLOBlit_7175, DTA); 278.2 ± 1 K (GLOBlit_8264, DTA); 278.16 ± 0.62 K (GLOBlit_9437, visual observation). The most precise measurement is 278.16 ± 0.16 K from GLOBlit_1484. All uncertainties are at the 95% confidence level. A data-flag note indicates that the value 277.06 K was misattributed to PROPblock_10 in the answer but actually belongs to GLOBlit_2959 PROPblock_5.

**Answer:**

#### Pure-Component Melting Temperature of Dimethyl Carbonate (DMC)

The ThermoML database contains melting/fusion temperature data for pure dimethyl carbonate (GLOBcomp_62) under two property definitions:

##### 1. Solid-Liquid Equilibrium Temperature (GLOBprop_11)

One data block was found:

**L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *DOI* | *Block* | *T_melt (K)* | *±U (K)* | *P (kPa)* | *Method* |
|---|---|---|---|---|---|---|
| L1#1_Table#1_Row#1 | 「10.1016/j.fluid.2018.09.023 [GLOBlit_2251]」 | 「PROPblock_5」 | 「278.11」 | 「4」 | 「101」 | 「Visual observation」 |

##### 2. Normal Melting Temperature (GLOBprop_12)

Seven literature sources report this property, all at 1 atm (crystal → liquid transition):

**L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *DOI* | *Block* | *GLOBlit* | *T_melt (K)* | *±U (K)* | *Method* |
|---|---|---|---|---|---|---|
| L1#1_Table#2_Row#1 | 「10.1016/j.fluid.2014.05.033」 | 「PROPblock_4」 | 「GLOBlit_1484」 | 「278.16」 | 「0.16」 | 「Visual observation」 |
| L1#1_Table#2_Row#2 | 「10.1016/j.fluid.2014.09.024」 | 「PROPblock_4」 | 「GLOBlit_1560」 | 「278.2」 | 「0.4」 | 「Visual observation」 |
| L1#1_Table#2_Row#3 | 「10.1016/j.fluid.2018.05.033」 | 「PROPblock_3」 | 「GLOBlit_2207」 | 「277.52」 | 「0.77」 | 「Phase equilibration」 |
| L1#1_Table#2_Row#4 | 「10.1016/j.jct.2008.05.012」 | 「PROPblock_5」 | 「GLOBlit_2959」 | 「277.06」 | 「0.6」 | 「Heating/cooling curves」 |
| L1#1_Table#2_Row#5 | 「10.1021/acs.jced.7b00295」 | 「PROPblock_1」 | 「GLOBlit_7175」 | 「277.57」 | 「0.7」 | 「DTA」 |
| L1#1_Table#2_Row#6 | 「10.1021/je034134e」 | 「PROPblock_10」 | 「GLOBlit_8264」 | 「278.2」 | 「1」 | 「DTA」 |
| L1#1_Table#2_Row#7 | 「10.1021/je101199g」 | 「PROPblock_4」 | 「GLOBlit_9437」 | 「278.16」 | 「0.62」 | 「Visual observation」 |

##### Summary

Across all 8 independent measurements (both property IDs), the reported melting temperature of pure DMC ranges from 277.06 K (GLOBlit_2959, PROPblock_5) to 278.2 K (GLOBlit_1560, PROPblock_4 and GLOBlit_8264, PROPblock_10). All uncertainties are reported at the 95% confidence level. The most precise measurement is from GLOBlit_1484 (PROPblock_4, 10.1016/j.fluid.2014.05.033) at 278.16 ± 0.16 K. All measurements were performed on unary (pure component) systems at atmospheric pressure, observing the crystal-to-liquid phase transition.

---
[UNGROUNDED DATA FLAGS] The following quoted values could not be verified against any verbatim data inspection in this run and must be treated as UNVERIFIED:
- **MISATTRIBUTED_VALUE** PROPblock_10: 277.06 does not belong to PROPblock_10; it matches only GLOBlit_2251::PROPblock_5 (inspected this run)
  fix (required — this IS a database value, under a different block): `re-anchor 277.06 to GLOBlit_2251::PROPblock_5 — no new tool call needed`
Inspected so far: PROPblock_1, PROPblock_10, PROPblock_3, PROPblock_4, PROPblock_5

**Core claims:**
- The ThermoML database contains 8 independent measurements of the melting temperature of pure dimethyl carbonate (DMC) at atmospheric pressure, spanning a range from 277.06 K to 278.2 K, with all uncertainties reported at the 95% confidence level.
- The most precise reported measurement is 278.16 ± 0.16 K (from DOI 10.1016/j.fluid.2014.05.033, GLOBlit_1484, visual observation method).
- One value (277.06 K) was flagged as misattributed to PROPblock_10 in the answer's own ungrounded-data audit; it actually belongs to GLOBlit_2251::PROPblock_5, so the attribution in the summary table for that entry is unreliable.

#### Core blocks found — verbatim ledger

```ledger
**L1#1_Table#3_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_2251 | lit_id: 2019-mat-oha-0 | doi: 10.1016/j.fluid.2018.09.023
block: PROPblock_5 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: dimethyl carbonate (C3H6O3; GLOBcomp_62; DOIcomp_4; InChIKey IEJIGPNLZYLLBP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_11
description: Solid-liquid equilibrium temperature of pure dimethyl carbonate measured at 101 kPa by visual observation, reporting 278.11 ± 4 K.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#3_Row#1 | 「variable」 | 「BLKvar_1/GLOBvar_3」 | 「Pressure, kPa」 | 「range=101.0–101.0 · n_unique=1 · phase=Liquid」 |
| L1#1_Table#3_Row#2 | 「property」 | 「BLKprop_1/GLOBprop_11」 | 「Solid-liquid equilibrium temperature, K」 | 「method=VISOBS (GLOBmeas_135) · range=278.11–278.11 · mean=278.11 · n=1 · phase=Liquid」 |
```

```ledger
**L1#1_Table#4_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_1484 | lit_id: 2014-shi-jeo-0 | doi: 10.1016/j.fluid.2014.05.033
block: PROPblock_4 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: dimethyl carbonate (C3H6O3; GLOBcomp_62; DOIcomp_2; InChIKey IEJIGPNLZYLLBP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure dimethyl carbonate reported as 278.16 ± 0.16 K by visual observation; most precise measurement found.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#4_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=VISOBS (GLOBmeas_135) · range=278.16–278.16 · mean=278.16 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#5_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_1560 | lit_id: 2014-you-jeo-0 | doi: 10.1016/j.fluid.2014.09.024
block: PROPblock_4 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: dimethyl carbonate (C3H6O3; GLOBcomp_62; DOIcomp_2; InChIKey IEJIGPNLZYLLBP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure dimethyl carbonate reported as 278.2 ± 0.4 K by visual observation.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#5_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=VISOBS (GLOBmeas_135) · range=278.2–278.2 · mean=278.2 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#6_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_2207 | lit_id: 2018-oh-gu-0 | doi: 10.1016/j.fluid.2018.05.033
block: PROPblock_3 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: dimethyl carbonate (C3H6O3; GLOBcomp_62; DOIcomp_1; InChIKey IEJIGPNLZYLLBP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure dimethyl carbonate reported as 277.52 ± 0.77 K by phase equilibration.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#6_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=Phase equilibration (GLOBmeas_16) · range=277.52–277.52 · mean=277.52 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#7_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_2959 | lit_id: 2008-wac-sch-0 | doi: 10.1016/j.jct.2008.05.012
block: PROPblock_5 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: dimethyl carbonate (C3H6O3; GLOBcomp_62; DOIcomp_5; InChIKey IEJIGPNLZYLLBP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure dimethyl carbonate reported as 277.06 ± 0.6 K by heating/cooling curves; lowest value found.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#7_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=Heating/Cooling curves (GLOBmeas_63) · range=277.06–277.06 · mean=277.06 · n=1 · phase=Crystal」 |
```

```ledger
**L1#1_Table#8_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_7175 | lit_id: 2017-pok-ste-0 | doi: 10.1021/acs.jced.7b00295
block: PROPblock_1 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: dimethyl carbonate (C3H6O3; GLOBcomp_62; DOIcomp_1; InChIKey IEJIGPNLZYLLBP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure dimethyl carbonate reported as 277.57 ± 0.7 K by DTA.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#8_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=DTA (GLOBmeas_130) · range=277.57–277.57 · mean=277.57 · n=1 · phase=Crystal 1」 |
```

```ledger
**L1#1_Table#9_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_8264 | lit_id: 2004-din--0 | doi: 10.1021/je034134e
block: PROPblock_10 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: dimethyl carbonate (C3H6O3; GLOBcomp_62; DOIcomp_3; InChIKey IEJIGPNLZYLLBP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure dimethyl carbonate reported as 278.2 ± 1 K by DTA.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#9_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=DTA:UFactor:2 (GLOBmeas_243) · range=278.2–278.2 · mean=278.2 · n=1 · phase=Crystal 1」 |
```

```ledger
**L1#1_Table#10_(Query_L1#1_CoreBLK):**
lit_num_id: GLOBlit_9437 | lit_id: 2011-mat-kim-1 | doi: 10.1021/je101199g
block: PROPblock_4 | BLKsubsys_id: — | type: PureOrMixtureData (GLOBblocktype_2) | system: unary | n_datapoints: 1
compounds: dimethyl carbonate (C3H6O3; GLOBcomp_62; DOIcomp_5; InChIKey IEJIGPNLZYLLBP-UHFFFAOYSA-N)
prop_num_ids: GLOBprop_12
description: Normal melting temperature of pure dimethyl carbonate reported as 278.16 ± 0.62 K by visual observation.

| *row_id* | *kind* | *id* | *name* | *detail* |
|---|---|---|---|---|
| L1#1_Table#10_Row#1 | 「property」 | 「BLKprop_1/GLOBprop_12」 | 「Normal melting temperature, K」 | 「method=VISOBS:UFactor:4 (GLOBmeas_154) · range=278.16–278.16 · mean=278.16 · n=1 · phase=Crystal」 |
```

#### Data inspections — verbatim ledger

```ledger
**L1#1_Table#11_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_2251 | doi: 10.1016/j.fluid.2018.09.023 | block: PROPblock_5
table_mode: complete | inspection_id: INSP_8b8d55286922 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *pressure_kpa* | *solidliquid_equilibrium_temperature_k* | *solidliquid_equilibrium_temperature_k_U* |
|---|---|---|---|---|
| L1#1_Table#11_Row#1 | 「BLKpoint_1」 | 「101」 | 「278.11」 | 「4」 |
```

```ledger
**L1#1_Table#12_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_1484 | doi: 10.1016/j.fluid.2014.05.033 | block: PROPblock_4
table_mode: complete | inspection_id: INSP_13e4801a77d3 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#12_Row#1 | 「BLKpoint_1」 | 「278.16」 | 「0.16」 |
```

```ledger
**L1#1_Table#13_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_1560 | doi: 10.1016/j.fluid.2014.09.024 | block: PROPblock_4
table_mode: complete | inspection_id: INSP_52a004b9a73a | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#13_Row#1 | 「BLKpoint_1」 | 「278.2」 | 「0.4」 |
```

```ledger
**L1#1_Table#14_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_2207 | doi: 10.1016/j.fluid.2018.05.033 | block: PROPblock_3
table_mode: complete | inspection_id: INSP_1ec3101830e8 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#14_Row#1 | 「BLKpoint_1」 | 「277.52」 | 「0.77」 |
```

```ledger
**L1#1_Table#15_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_2959 | doi: 10.1016/j.jct.2008.05.012 | block: PROPblock_5
table_mode: complete | inspection_id: INSP_f7a503b82677 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#15_Row#1 | 「BLKpoint_1」 | 「277.06」 | 「0.6」 |
```

```ledger
**L1#1_Table#16_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_7175 | doi: 10.1021/acs.jced.7b00295 | block: PROPblock_1
table_mode: complete | inspection_id: INSP_7a98e36639f7 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#16_Row#1 | 「BLKpoint_1」 | 「277.57」 | 「0.7」 |
```

```ledger
**L1#1_Table#17_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_8264 | doi: 10.1021/je034134e | block: PROPblock_10
table_mode: complete | inspection_id: INSP_256e6d5802fc | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#17_Row#1 | 「BLKpoint_1」 | 「278.2」 | 「1」 |
```

```ledger
**L1#1_Table#18_(Query_L1#1_INSP):**
lit_num_id: GLOBlit_9437 | doi: 10.1021/je101199g | block: PROPblock_4
table_mode: complete | inspection_id: INSP_d6802e915282 | rows_shown: 1

| *row_id* | *BLKpoint_id* | *normal_melting_temperature_k* | *normal_melting_temperature_k_U* |
|---|---|---|---|
| L1#1_Table#18_Row#1 | 「BLKpoint_1」 | 「278.16」 | 「0.62」 |
```
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<reasoning>
The L1 query returned comprehensive data. I have all 8 measurements with verified inspections. The flag about misattribution of 277.06 K to PROPblock_10 was resolved — it actually belongs to GLOBlit_2959 PROPblock_5, and the tables correctly show it there. The data is complete and I can now provide the final answer.
</reasoning>

<answer>

## Pure-Component Melting Temperature of Dimethyl Carbonate (DMC)

**Compound:** Dimethyl carbonate (C₃H₆O₃, SMILES: COC(=O)OC)

The ThermoML database contains **8 independent measurements** of the melting (fusion) temperature of pure DMC, reported under two property definitions. All measurements were performed on pure (unary) systems at atmospheric pressure, observing the crystal-to-liquid phase transition. Uncertainties are at the 95% confidence level.

---

### 1. Solid–Liquid Equilibrium Temperature (GLOBprop_11)

| DOI | Block | T_melt (K) | ±U (K) | P (kPa) | Method |
|-----|-------|-----------|--------|---------|--------|
| 10.1016/j.fluid.2018.09.023 [GLOBlit_2251] | PROPblock_5 | 278.11 | 4 | 101 | Visual observation |

### 2. Normal Melting Temperature (GLOBprop_12)

| DOI | Block | T_melt (K) | ±U (K) | Method |
|-----|-------|-----------|--------|--------|
| 10.1016/j.fluid.2014.05.033 [GLOBlit_1484] | PROPblock_4 | 278.16 | 0.16 | Visual observation |
| 10.1016/j.fluid.2014.09.024 [GLOBlit_1560] | PROPblock_4 | 278.2 | 0.4 | Visual observation |
| 10.1016/j.fluid.2018.05.033 [GLOBlit_2207] | PROPblock_3 | 277.52 | 0.77 | Phase equilibration |
| 10.1016/j.jct.2008.05.012 [GLOBlit_2959] | PROPblock_5 | 277.06 | 0.6 | Heating/cooling curves |
| 10.1021/acs.jced.7b00295 [GLOBlit_7175] | PROPblock_1 | 277.57 | 0.7 | DTA |
| 10.1021/je034134e [GLOBlit_8264] | PROPblock_10 | 278.2 | 1 | DTA |
| 10.1021/je101199g [GLOBlit_9437] | PROPblock_4 | 278.16 | 0.62 | Visual observation |

---

### Summary & Chemistry Insight

- **Range:** 277.06 K to 278.2 K across all 8 measurements.
- **Most precise value:** **278.16 ± 0.16 K** from Shi & Jeon (DOI: 10.1016/j.fluid.2014.05.033 [GLOBlit_1484]), determined by visual observation.
- **Lowest value:** 277.06 ± 0.6 K (DOI: 10.1016/j.jct.2008.05.012 [GLOBlit_2959]), measured by heating/cooling curves.

The spread of ~1.1 K across studies is typical for organic carbonates with relatively low melting points. Visual-observation methods (4 of 8 measurements) tend to cluster near 278.1–278.2 K, while thermal-analysis methods (DTA, heating/cooling curves) and phase-equilibration approaches yield slightly lower values (277.06–277.57 K). This systematic difference likely reflects the sensitivity of thermal methods to sample purity and heating rate. DMC's melting point near 278 K (≈ 5 °C) is notably low for a carbonate ester, a consequence of its small, symmetric molecular structure that limits intermolecular packing efficiency despite the polar carbonate group.

</answer>