# Reference Stats — query-agent

**Run started:** 2026-10-20 20:30:46
**Wall time (at last flush):** 294.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 29,181 | 36,231 | 9,788 | 65,412 | 13,082 | 54.6 | claudeopus46 |
| L1-worker | 19 | 307,258 | 256,619 | 35,814 | 563,877 | 29,677 | 225.0 | claudeopus46 |
| verdict | 1 | 972 | 7,454 | 1,164 | 8,426 | 8,426 | 9.9 | claudeopus46 |
| **TOTAL** | **25** | **337,411** | **300,304** | **46,766** | **637,715** | **25,508** | **289.5** | |

**Estimated tokens:** ~159,428 input + ~11,691 output = ~171,119 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 1 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 3 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 0 | 0 | 7 | 7 | 7 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **5** | **1** | **0** | **8** | **8** | **8** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2251 |  | search_blocks |
| GLOBlit_1484 |  | search_blocks |
| GLOBlit_1560 |  | search_blocks |
| GLOBlit_2207 |  | search_blocks |
| GLOBlit_2959 |  | search_blocks |
| GLOBlit_7175 |  | search_blocks |
| GLOBlit_8264 |  | search_blocks |
| GLOBlit_9437 |  | search_blocks |

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_62 | dimethyl carbonate | search_blocks |

#### Properties (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBprop_12 |  | resolve_property_ids, search_blocks |
| GLOBprop_26 |  | resolve_property_ids |
| GLOBprop_22 |  | resolve_property_ids |

#### Measurements (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_135 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBmeas_16 | Normal melting temperature, K | search_blocks |
| GLOBmeas_63 | Normal melting temperature, K | search_blocks |
| GLOBmeas_130 | Normal melting temperature, K | search_blocks |
| GLOBmeas_243 | Normal melting temperature, K | search_blocks |
| GLOBmeas_154 | Normal melting temperature, K | search_blocks |

#### Phases (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |
| GLOBphase_2 |  | search_blocks |
| GLOBphase_7 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 8 |
| Unique Compounds | 1 |
| Unique Properties | 4 |
| Unique Measurements | 6 |
| Unique Phases | 3 |
| Unique Variables | 1 |
| Total DOIs | 8 |
| Unique parent blocks | 8 |
| Explicit block/subsystem targets | 8 |
| Subsystem targets | 0 |
| Target-matched data points | 8 |

---

## 3. DOI & Block References

**Unique DOIs:** 8  |  **Parent blocks:** 8  |  **Explicit targets:** 8  |  **Subsystems:** 0  |  **Target-matched datapoints:** 8

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2014.05.033 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2014.09.024 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2018.05.033 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2018.09.023 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2008.05.012 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.7b00295 | 1 | 1 | unary | search_blocks |
| 10.1021/je034134e | 1 | 1 | unary | search_blocks |
| 10.1021/je101199g | 1 | 1 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2014.05.033 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2014.09.024 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2018.05.033 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2018.09.023 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2008.05.012 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00295 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_10 | declared | 1 | unary | — | search_blocks |
| 10.1021/je101199g | PROPblock_4 | declared | 1 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_blocks` | compound=GLOBcomp_62, limit=50, property=GLOBprop_… | 665 | KEEP ←in 1,223 | 635 | 12.6 |
| 2 | 2 | `inspect_block_table` | block_number=GLOBlit_2251::PROPblock_5, purpose=Ge… | 710 | — | — | 0.6 |
| 3 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Find alternative p… | 600 | KEEP ←in 422 | 600 | 6.6 |
| 4 | 3 | `search_blocks` | compound=GLOBcomp_62, limit=50, property=GLOBprop_… | 1,137 | KEEP ←in 6,322 | 1137 | 12.4 |
| 5 | 5 | `inspect_block_table` | block_number=GLOBlit_1484::PROPblock_4, purpose=Gr… | 630 | — | — | 0.1 |
| 6 | 5 | `inspect_block_table` | block_number=GLOBlit_1560::PROPblock_4, purpose=Gr… | 624 | — | — | 0.1 |
| 7 | 5 | `inspect_block_table` | block_number=GLOBlit_2207::PROPblock_3, purpose=Gr… | 630 | — | — | 0.1 |
| 8 | 5 | `inspect_block_table` | block_number=GLOBlit_2959::PROPblock_5, purpose=Gr… | 625 | — | — | 0.1 |
| 9 | 5 | `inspect_block_table` | block_number=GLOBlit_7175::PROPblock_1, purpose=Gr… | 624 | — | — | 0.1 |
| 10 | 5 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_10, purpose=G… | 609 | — | — | 0.1 |
| 11 | 5 | `inspect_block_table` | block_number=GLOBlit_9437::PROPblock_4, purpose=Gr… | 620 | — | — | 0.1 |
| 12 | 7 | `inspect_block_table` | block_number=GLOBlit_1484::PROPblock_4, purpose=Gr… | 630 | — | — | 0.1 |
| 13 | 7 | `inspect_block_table` | block_number=GLOBlit_1560::PROPblock_4, purpose=Gr… | 624 | — | — | 0.1 |
| 14 | 7 | `inspect_block_table` | block_number=GLOBlit_2207::PROPblock_3, purpose=Gr… | 630 | — | — | 0.1 |
| 15 | 7 | `inspect_block_table` | block_number=GLOBlit_2959::PROPblock_5, purpose=Gr… | 625 | — | — | 0.1 |
| 16 | 7 | `inspect_block_table` | block_number=GLOBlit_7175::PROPblock_1, purpose=Gr… | 624 | — | — | 0.1 |
| 17 | 7 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_10, purpose=G… | 609 | — | — | 0.2 |
| 18 | 7 | `inspect_block_table` | block_number=GLOBlit_9437::PROPblock_4, purpose=Gr… | 620 | — | — | 0.2 |
| 19 | 8 | `inspect_block_table` | block_number=GLOBlit_1484::PROPblock_4, purpose=Gr… | 630 | — | — | 0.1 |
| 20 | 8 | `inspect_block_table` | block_number=GLOBlit_2959::PROPblock_5, purpose=Gr… | 625 | — | — | 0.1 |
| 21 | 8 | `inspect_block_table` | block_number=GLOBlit_7175::PROPblock_1, purpose=Gr… | 624 | — | — | 0.2 |
| 22 | 8 | `inspect_block_table` | block_number=GLOBlit_2207::PROPblock_3, purpose=Gr… | 630 | — | — | 0.1 |
| 23 | 8 | `inspect_block_table` | block_number=GLOBlit_1560::PROPblock_4, purpose=Gr… | 624 | — | — | 0.2 |
| 24 | 8 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_10, purpose=G… | 609 | — | — | 0.2 |
| 25 | 8 | `inspect_block_table` | block_number=GLOBlit_9437::PROPblock_4, purpose=Gr… | 620 | — | — | 0.3 |
| 26 | 9 | `inspect_block_table` | block_number=GLOBlit_1484::PROPblock_4, purpose=Gr… | 630 | — | — | 0.1 |
| 27 | 9 | `inspect_block_table` | block_number=GLOBlit_2959::PROPblock_5, purpose=Gr… | 625 | — | — | 0.1 |
| 28 | 9 | `inspect_block_table` | block_number=GLOBlit_7175::PROPblock_1, purpose=Gr… | 624 | — | — | 0.1 |
| 29 | 10 | `inspect_block_table` | block_number=GLOBlit_1560::PROPblock_4, purpose=Gr… | 624 | — | — | 0.1 |
| 30 | 10 | `inspect_block_table` | block_number=GLOBlit_2207::PROPblock_3, purpose=Gr… | 630 | — | — | 0.1 |
| 31 | 10 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_10, purpose=G… | 609 | — | — | 0.1 |
| 32 | 10 | `inspect_block_table` | block_number=GLOBlit_9437::PROPblock_4, purpose=Gr… | 620 | — | — | 0.1 |
| 33 | 1 | `L1_query` | context=DMC = dimethyl carbonate, exp…, id_catalog… | 33,345 | — | — | 231.5 |
| | | **TOTAL (33 tools)** | | **53,905** | | **2,372** | **267.2** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 820 | 12,401 | 1,392 | 8.9 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,239 | 25,379 | 716 | 5.3 |
| 3 | L1-worker | claudeopus46 | 3,767 | 1,585 | 5,352 | 909 | 6.9 |
| 4 | L1-worker | claudeopus46 | 24,140 | 2,401 | 26,541 | 4,672 | 27.3 |
| 5 | L1-worker | claudeopus46 | 3,767 | 606 | 4,373 | 905 | 6.0 |
| 6 | L1-worker | claudeopus46 | 24,140 | 4,438 | 28,578 | 682 | 5.6 |
| 7 | L1-worker | claudeopus46 | 3,767 | 6,684 | 10,451 | 1,406 | 11.5 |
| 8 | L1-worker | claudeopus46 | 24,140 | 6,104 | 30,244 | 2,075 | 12.5 |
| 9 | L1-worker | claudeopus46 | 24,140 | 14,761 | 38,901 | 1,763 | 8.3 |
| 10 | L1-worker | claudeopus46 | 24,140 | 17,979 | 42,119 | 715 | 4.9 |
| 11 | L1-worker | claudeopus46 | 24,140 | 19,479 | 43,619 | 3,590 | 21.0 |
| 12 | L1-worker | claudeopus46 | 24,140 | 21,446 | 45,586 | 3,073 | 16.4 |
| 13 | L1-worker | claudeopus46 | 24,140 | 24,729 | 48,869 | 2,586 | 17.1 |
| 14 | L1-worker | claudeopus46 | 24,140 | 27,477 | 51,617 | 1,256 | 7.2 |
| 15 | L1-worker | claudeopus46 | 24,140 | 30,849 | 54,989 | 1,958 | 14.3 |
| 16 | L1-worker | claudeopus46 | 24,140 | 36,474 | 60,614 | 4,461 | 32.5 |
| 17 | L1-worker | claudeopus46 | 2,320 | 2,623 | 4,943 | 672 | 5.1 |
| 18 | L1-worker | claudeopus46 | 627 | 2,503 | 3,130 | 1,075 | 6.6 |
| 19 | L1-worker | claudeopus46 | 2,543 | 3,983 | 6,526 | 2,713 | 10.5 |
| 20 | L1-worker | claudeopus46 | 787 | 31,259 | 32,046 | 587 | 6.0 |
| 21 | L0-main | claudeopus46 | 11,581 | 21,901 | 33,482 | 2,905 | 20.9 |
| 22 | L0-main | claudeopus46 | 2,320 | 2,729 | 5,049 | 858 | 3.9 |
| 23 | L0-main | claudeopus46 | 2,543 | 3,381 | 5,924 | 1,488 | 7.4 |
| 24 | L0-main | claudeopus46 | 1,156 | 7,400 | 8,556 | 3,145 | 13.5 |
| 25 | verdict | claudeopus46 | 972 | 7,454 | 8,426 | 1,164 | 9.9 |

