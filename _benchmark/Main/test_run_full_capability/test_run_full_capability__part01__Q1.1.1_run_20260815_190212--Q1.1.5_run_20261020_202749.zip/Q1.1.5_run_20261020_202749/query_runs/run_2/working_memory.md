# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find pure-component melting temperature (solid-liquid equilibrium temperature) data for dimethyl carbonate (DMC) → stored as L1_query_1 · validation: FLAGGED(1)

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: FLAGGED(1)

**Summary:**

Eight independent ThermoML measurements of the pure-component melting (fusion) temperature of dimethyl carbonate (DMC, GLOBcomp_62) are reported under two property definitions (solid-liquid equilibrium temperature GLOBprop_11 and normal melting temperature GLOBprop_12), all at atmospheric pressure for the crystal-to-liquid transition. Reported values range from 277.06 K to 278.2 K. Specific values: 278.11 ± 4 K (GLOBlit_2251, GLOBprop_11, visual observation); 278.16 ± 0.16 K (GLOBlit_1484, visual observation); 278.2 ± 0.4 K (GLOBlit_1560, visual observation); 277.52 ± 0.77 K (GLOBlit_2207, phase equilibration); 277.06 ± 0.6 K (GLOBlit_2959, heating/cooling curves); 277.57 ± 0.7 K (GLOBlit_7175, DTA); 278.2 ± 1 K (GLOBlit_8264, DTA); 278.16 ± 0.62 K (GLOBlit_9437, visual observation). The most precise measurement is 278.16 ± 0.16 K from GLOBlit_1484. All uncertainties are at the 95% confidence level. A data-flag note indicates that the value 277.06 K was misattributed to PROPblock_10 in the answer but actually belongs to GLOBlit_2959 PROPblock_5.

**Answer:**

#### Pure-Component Melting Temperature of Dimethyl Carbonate (DMC)

The ThermoML database contains melting/fusion temperature data for pure dimethyl carbonate (GLOBcomp_62) under two property definitions:

##### 1. Solid-Liquid Equilibrium Temperature (GLOBprop_11)

One data block was found:

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *DOI* | *Block* | *T_melt (K)* | *±U (K)* | *P (kPa)* | *Method* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「10.1016/j.fluid.2018.09.023 [GLOBlit_2251]」 | 「PROPblock_5」 | 「278.11」 | 「4」 | 「101」 | 「Visual observation」 |

##### 2. Normal Melting Temperature (GLOBprop_12)

Seven literature sources report this property, all at 1 atm (crystal → liquid transition):

**WM_L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *DOI* | *Block* | *GLOBlit* | *T_melt (K)* | *±U (K)* | *Method* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「10.1016/j.fluid.2014.05.033」 | 「PROPblock_4」 | 「GLOBlit_1484」 | 「278.16」 | 「0.16」 | 「Visual observation」 |
| WM_L1#1_Table#2_Row#2 | 「10.1016/j.fluid.2014.09.024」 | 「PROPblock_4」 | 「GLOBlit_1560」 | 「278.2」 | 「0.4」 | 「Visual observation」 |
| WM_L1#1_Table#2_Row#3 | 「10.1016/j.fluid.2018.05.033」 | 「PROPblock_3」 | 「GLOBlit_2207」 | 「277.52」 | 「0.77」 | 「Phase equilibration」 |
| WM_L1#1_Table#2_Row#4 | 「10.1016/j.jct.2008.05.012」 | 「PROPblock_5」 | 「GLOBlit_2959」 | 「277.06」 | 「0.6」 | 「Heating/cooling curves」 |
| WM_L1#1_Table#2_Row#5 | 「10.1021/acs.jced.7b00295」 | 「PROPblock_1」 | 「GLOBlit_7175」 | 「277.57」 | 「0.7」 | 「DTA」 |
| WM_L1#1_Table#2_Row#6 | 「10.1021/je034134e」 | 「PROPblock_10」 | 「GLOBlit_8264」 | 「278.2」 | 「1」 | 「DTA」 |
| WM_L1#1_Table#2_Row#7 | 「10.1021/je101199g」 | 「PROPblock_4」 | 「GLOBlit_9437」 | 「278.16」 | 「0.62」 | 「Visual observation」 |

##### Summary

Across all 8 independent measurements (both property IDs), the reported melting temperature of pure DMC ranges from 277.06 K (GLOBlit_2959, PROPblock_5) to 278.2 K (GLOBlit_1560, PROPblock_4 and GLOBlit_8264, PROPblock_10). All uncertainties are reported at the 95% confidence level. The most precise measurement is from GLOBlit_1484 (PROPblock_4, 10.1016/j.fluid.2014.05.033) at 278.16 ± 0.16 K. All measurements were performed on unary (pure component) systems at atmospheric pressure, observing the crystal-to-liquid phase transition.

**Core claims:**
- The ThermoML database contains 8 independent measurements of the melting temperature of pure dimethyl carbonate (DMC) at atmospheric pressure, spanning a range from 277.06 K to 278.2 K, with all uncertainties reported at the 95% confidence level.
- The most precise reported measurement is 278.16 ± 0.16 K (from DOI 10.1016/j.fluid.2014.05.033, GLOBlit_1484, visual observation method).
- One value (277.06 K) was flagged as misattributed to PROPblock_10 in the answer's own ungrounded-data audit; it actually belongs to GLOBlit_2251::PROPblock_5, so the attribution in the summary table for that entry is unreliable.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_2251」 | 「PROPblock_5」 | 「GLOBcomp_62」 | 「GLOBprop_11」 | 「Solid-liquid equilibrium temperature of pure dimethyl carbonate measured at 101 kPa by visual observation, reporting 278.11 ± 4 K.」 |
| WM_L1#1_Table#4 | 「GLOBlit_1484」 | 「PROPblock_4」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 278.16 ± 0.16 K by visual observation; most precise measurement found.」 |
| WM_L1#1_Table#5 | 「GLOBlit_1560」 | 「PROPblock_4」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 278.2 ± 0.4 K by visual observation.」 |
| WM_L1#1_Table#6 | 「GLOBlit_2207」 | 「PROPblock_3」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 277.52 ± 0.77 K by phase equilibration.」 |
| WM_L1#1_Table#7 | 「GLOBlit_2959」 | 「PROPblock_5」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 277.06 ± 0.6 K by heating/cooling curves; lowest value found.」 |
| WM_L1#1_Table#8 | 「GLOBlit_7175」 | 「PROPblock_1」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 277.57 ± 0.7 K by DTA.」 |
| WM_L1#1_Table#9 | 「GLOBlit_8264」 | 「PROPblock_10」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 278.2 ± 1 K by DTA.」 |
| WM_L1#1_Table#10 | 「GLOBlit_9437」 | 「PROPblock_4」 | 「GLOBcomp_62」 | 「GLOBprop_12」 | 「Normal melting temperature of pure dimethyl carbonate reported as 278.16 ± 0.62 K by visual observation.」 |

*Not stored here: 8 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(1) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **MISATTRIBUTED_VALUE** PROPblock_10: 277.06 does not belong to PROPblock_10; it matches only GLOBlit_2251::PROPblock_5 (inspected this run)


