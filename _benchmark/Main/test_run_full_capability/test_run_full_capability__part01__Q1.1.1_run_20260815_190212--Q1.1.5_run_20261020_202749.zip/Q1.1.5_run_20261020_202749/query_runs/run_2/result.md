# Delegated query run — result

**Question:** Find pure-component melting temperature (or normal melting point, fusion temperature, SLE temperature at x=1 or x=0) data for dimethyl carbonate (GLOBcomp_62). Report all blocks with temperatures, uncertainties, and DOIs.

**Iterations:** 2  |  **Elapsed:** 262.1s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Pure-Component Melting Temperature of Dimethyl Carbonate (DMC)

**Compound:** Dimethyl carbonate (C₃H₆O₃, SMILES: COC(=O)OC)

The ThermoML database contains **8 independent measurements** of the melting (fusion) temperature of pure DMC, reported under two property definitions. All measurements were performed on pure (unary) systems at atmospheric pressure, observing the crystal-to-liquid phase transition. Uncertainties are at the 95% confidence level.

---

### 1. Solid–Liquid Equilibrium Temperature (GLOBprop_11)

| DOI | Block | T_melt (K) | ±U (K) | P (kPa) | Method |
|-----|-------|-----------|--------|---------|--------|
| 10.1016/j.fluid.2018.09.023 [GLOBlit_2251] | PROPblock_5 | 278.11 | 4 | 101 | Visual observation |

### 2. Normal Melting Temperature (GLOBprop_12)

| DOI | Block | T_melt (K) | ±U (K) | Method |
|-----|-------|-----------|--------|--------|
| 10.1016/j.fluid.2014.05.033 [GLOBlit_1484] | PROPblock_4 | 278.16 | 0.16 | Visual observation |
| 10.1016/j.fluid.2014.09.024 [GLOBlit_1560] | PROPblock_4 | 278.2 | 0.4 | Visual observation |
| 10.1016/j.fluid.2018.05.033 [GLOBlit_2207] | PROPblock_3 | 277.52 | 0.77 | Phase equilibration |
| 10.1016/j.jct.2008.05.012 [GLOBlit_2959] | PROPblock_5 | 277.06 | 0.6 | Heating/cooling curves |
| 10.1021/acs.jced.7b00295 [GLOBlit_7175] | PROPblock_1 | 277.57 | 0.7 | DTA |
| 10.1021/je034134e [GLOBlit_8264] | PROPblock_10 | 278.2 | 1 | DTA |
| 10.1021/je101199g [GLOBlit_9437] | PROPblock_4 | 278.16 | 0.62 | Visual observation |

---

### Summary & Chemistry Insight

- **Range:** 277.06 K to 278.2 K across all 8 measurements.
- **Most precise value:** **278.16 ± 0.16 K** from Shi & Jeon (DOI: 10.1016/j.fluid.2014.05.033 [GLOBlit_1484]), determined by visual observation.
- **Lowest value:** 277.06 ± 0.6 K (DOI: 10.1016/j.jct.2008.05.012 [GLOBlit_2959]), measured by heating/cooling curves.

The spread of ~1.1 K across studies is typical for organic carbonates with relatively low melting points. Visual-observation methods (4 of 8 measurements) tend to cluster near 278.1–278.2 K, while thermal-analysis methods (DTA, heating/cooling curves) and phase-equilibration approaches yield slightly lower values (277.06–277.57 K). This systematic difference likely reflects the sensitivity of thermal methods to sample purity and heating rate. DMC's melting point near 278 K (≈ 5 °C) is notably low for a carbonate ester, a consequence of its small, symmetric molecular structure that limits intermolecular packing efficiency despite the polar carbonate group.

### Core claims

- The ThermoML database contains 8 independent measurements of the melting temperature of pure dimethyl carbonate (COC(=O)OC), all performed on pure unary systems at atmospheric pressure, spanning a range of 277.06 K to 278.2 K.
- The most precise reported value is 278.16 ± 0.16 K (DOI: 10.1016/j.fluid.2014.05.033), determined by visual observation.
- Visual-observation methods (4 of 8 measurements) cluster near 278.1–278.2 K, while thermal-analysis methods (DTA, heating/cooling curves) and phase-equilibration approaches yield slightly lower values (277.06–277.57 K), a systematic difference likely reflecting sensitivity to sample purity and heating rate.
- The total spread of ~1.1 K across studies is typical for organic carbonates with relatively low melting points.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2251 | 10.1016/j.fluid.2018.09.023 | PROPblock_5 |  | Provides a solid-liquid equilibrium temperature of 278.11 K for pure dimethyl carbonate measured by visual observation at 101 kPa, contributing one of the eight independent melting point measurements in the answer. |
| GLOBlit_1484 | 10.1016/j.fluid.2014.05.033 | PROPblock_4 |  | Reports the most precise normal melting temperature of 278.16 K for pure dimethyl carbonate by visual observation, identified in the answer as the most precise value with ±0.16 K uncertainty. |
| GLOBlit_1560 | 10.1016/j.fluid.2014.09.024 | PROPblock_4 |  | Provides a normal melting temperature of 278.2 K for pure dimethyl carbonate by visual observation, contributing to the cluster of visual-observation values near 278.1–278.2 K discussed in the answer. |
| GLOBlit_2207 | 10.1016/j.fluid.2018.05.033 | PROPblock_3 |  | Reports a normal melting temperature of 277.52 K for pure dimethyl carbonate by phase equilibration, contributing one of the lower-valued measurements discussed in the answer's comparison of methods. |
| GLOBlit_2959 | 10.1016/j.jct.2008.05.012 | PROPblock_5 |  | Reports the lowest normal melting temperature of 277.06 K for pure dimethyl carbonate by heating/cooling curves, establishing the lower bound of the 277.06–278.2 K range cited in the answer. |
| GLOBlit_7175 | 10.1021/acs.jced.7b00295 | PROPblock_1 |  | Provides a normal melting temperature of 277.57 K for pure dimethyl carbonate by DTA, contributing to the thermal-analysis cluster of values discussed in the answer. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_10 |  | Reports a normal melting temperature of 278.2 K for pure dimethyl carbonate by DTA, tying for the highest value in the reported range and contributing to the answer's compilation. |
| GLOBlit_9437 | 10.1021/je101199g | PROPblock_4 |  | Reports a normal melting temperature of 278.16 K for pure dimethyl carbonate by visual observation, corroborating the value from GLOBlit_1484 and contributing to the answer's eight independent measurements. |

### Suggested follow-ups

- Compare DMC melting point with other linear carbonates (diethyl carbonate, ethyl methyl carbonate) to assess structural effects on fusion temperature.
- Investigate whether any of the cited studies also report enthalpy of fusion for DMC, which would complement the melting temperature data.
- Check for SLE phase diagram data in binary DMC + solvent systems to see if the eutectic extrapolations are consistent with these pure-component melting points.

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1016/j.fluid.2018.09.023",
    "block_number": "PROPblock_5",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "pressure_kpa": "101",
        "solidliquid_equilibrium_temperature_k": "278.11",
        "solidliquid_equilibrium_temperature_k_U": "4"
      }
    ],
    "inspection_id": "INSP_8b8d55286922",
    "lit_num_id": "GLOBlit_2251"
  },
  {
    "doi": "10.1016/j.fluid.2014.05.033",
    "block_number": "PROPblock_4",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "278.16",
        "normal_melting_temperature_k_U": "0.16"
      }
    ],
    "inspection_id": "INSP_13e4801a77d3",
    "lit_num_id": "GLOBlit_1484"
  },
  {
    "doi": "10.1016/j.fluid.2014.09.024",
    "block_number": "PROPblock_4",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "278.2",
        "normal_melting_temperature_k_U": "0.4"
      }
    ],
    "inspection_id": "INSP_52a004b9a73a",
    "lit_num_id": "GLOBlit_1560"
  },
  {
    "doi": "10.1016/j.fluid.2018.05.033",
    "block_number": "PROPblock_3",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "277.52",
        "normal_melting_temperature_k_U": "0.77"
      }
    ],
    "inspection_id": "INSP_1ec3101830e8",
    "lit_num_id": "GLOBlit_2207"
  },
  {
    "doi": "10.1016/j.jct.2008.05.012",
    "block_number": "PROPblock_5",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "277.06",
        "normal_melting_temperature_k_U": "0.6"
      }
    ],
    "inspection_id": "INSP_f7a503b82677",
    "lit_num_id": "GLOBlit_2959"
  },
  {
    "doi": "10.1021/acs.jced.7b00295",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "277.57",
        "normal_melting_temperature_k_U": "0.7"
      }
    ],
    "inspection_id": "INSP_7a98e36639f7",
    "lit_num_id": "GLOBlit_7175"
  },
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_10",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "278.2",
        "normal_melting_temperature_k_U": "1"
      }
    ],
    "inspection_id": "INSP_256e6d5802fc",
    "lit_num_id": "GLOBlit_8264"
  },
  {
    "doi": "10.1021/je101199g",
    "block_number": "PROPblock_4",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "278.16",
        "normal_melting_temperature_k_U": "0.62"
      }
    ],
    "inspection_id": "INSP_d6802e915282",
    "lit_num_id": "GLOBlit_9437"
  }
]
```
