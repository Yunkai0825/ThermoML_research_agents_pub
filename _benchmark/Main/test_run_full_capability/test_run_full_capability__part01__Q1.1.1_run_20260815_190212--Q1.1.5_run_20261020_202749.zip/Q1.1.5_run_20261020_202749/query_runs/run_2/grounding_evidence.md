# Data grounding evidence

- generated: 2026-10-20T20:35:09
- gate verdict: 7 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | GLOBlit_7175 | yes | INSP_7a98e36639f7 | 1 |
| PROPblock_10 | GLOBlit_8264 | yes | INSP_256e6d5802fc | 1 |
| PROPblock_3 | GLOBlit_2207 | yes | INSP_1ec3101830e8 | 1 |
| PROPblock_4 | GLOBlit_1484 | yes | INSP_13e4801a77d3, INSP_52a004b9a73a, INSP_d6802e915282 | 1 |
| PROPblock_5 | GLOBlit_2251 | yes | INSP_8b8d55286922, INSP_f7a503b82677 | 1 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 278.11 | PROPblock_5 | verified | — |
| 101 | PROPblock_5 | verified | — |
| 278.16 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 0.16 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 278.2 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 0.4 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 277.52 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 0.77 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 277.06 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 0.6 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 277.57 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 0.7 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 278.2 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 278.16 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 0.62 | PROPblock_4 + PROPblock_3 + PROPblock_5 + PROPblock_1 + PROPblock_10 | verified | — |
| 277.06 | PROPblock_10 | misattributed | PROPblock_5 |
| 278.2 | PROPblock_10 | verified | — |
| 278.16 | PROPblock_10 | verified | — |
| 0.16 | PROPblock_10 | misattributed | PROPblock_4 |
| 277.06 | PROPblock_10 | misattributed | PROPblock_5 |
| 0.6 | PROPblock_10 | ambiguous | 2 sources |
| 1.1 | PROPblock_10 | ungrounded | — |
| 278.1 | PROPblock_10 | verified | — |
| 278.2 | PROPblock_10 | verified | — |
| 277.06 | PROPblock_10 | misattributed | PROPblock_5 |
| 277.57 | PROPblock_10 | misattributed | PROPblock_1 |
| 278 | PROPblock_10 | verified | — |

## Violations

- **MISATTRIBUTED_VALUE** PROPblock_10: 277.06 does not belong to PROPblock_10; it matches only GLOBlit_2251::PROPblock_5 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_10: 0.16 does not belong to PROPblock_10; it matches only GLOBlit_1484::PROPblock_4 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_10: 277.06 does not belong to PROPblock_10; it matches only GLOBlit_2251::PROPblock_5 (inspected this run)
- **AMBIGUOUS_VALUE** PROPblock_10: 0.6 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** PROPblock_10: 1.1 (near '…[ ]), measured by heating/cooling curves.  The spread of ~1.…') matches no inspected row/stat, database table, or other source of PROPblock_10
- **MISATTRIBUTED_VALUE** PROPblock_10: 277.06 does not belong to PROPblock_10; it matches only GLOBlit_2251::PROPblock_5 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_10: 277.57 does not belong to PROPblock_10; it matches only GLOBlit_7175::PROPblock_1 (inspected this run)

## Inspections (verbatim)

### INSP_8b8d55286922 — GLOBlit_2251::PROPblock_5 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_13e4801a77d3 — GLOBlit_1484::PROPblock_4 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_52a004b9a73a — GLOBlit_1560::PROPblock_4 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_1ec3101830e8 — GLOBlit_2207::PROPblock_3 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_f7a503b82677 — GLOBlit_2959::PROPblock_5 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_7a98e36639f7 — GLOBlit_7175::PROPblock_1 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_256e6d5802fc — GLOBlit_8264::PROPblock_10 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_d6802e915282 — GLOBlit_9437::PROPblock_4 (complete, 1 rows shown)

_structured envelope entry (no markdown)_
