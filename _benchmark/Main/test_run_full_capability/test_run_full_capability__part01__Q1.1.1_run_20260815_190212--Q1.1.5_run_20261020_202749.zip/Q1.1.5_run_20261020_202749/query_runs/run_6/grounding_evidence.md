# Data grounding evidence

- generated: 2026-10-20T20:38:24
- gate verdict: 2 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_40 | GLOBlit_8264 | yes | INSP_943c93eced38, INSP_69ee531f6a5f, INSP_f5f29a8c704e | 16 |
| PROPblock_41 | GLOBlit_8264 | yes | INSP_a90a8822f2c9 | 2 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 16 | PROPblock_40 | ungrounded | — |
| 0.2499 | PROPblock_40 | verified | — |
| 225.4 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.3003 | PROPblock_40 | verified | — |
| 232.2 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.3496 | PROPblock_40 | verified | — |
| 237.7 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.4027 | PROPblock_40 | verified | — |
| 243.0 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.4498 | PROPblock_40 | verified | — |
| 246.9 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.5011 | PROPblock_40 | verified | — |
| 250.5 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.5521 | PROPblock_40 | verified | — |
| 254.6 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.6071 | PROPblock_40 | verified | — |
| 257.5 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.6621 | PROPblock_40 | verified | — |
| 261.2 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.6996 | PROPblock_40 | verified | — |
| 263.2 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.7501 | PROPblock_40 | verified | — |
| 265.9 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.7993 | PROPblock_40 | verified | — |
| 268.2 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.8501 | PROPblock_40 | verified | — |
| 270.6 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.8998 | PROPblock_40 | verified | — |
| 272.7 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 0.9491 | PROPblock_40 | verified | — |
| 274.9 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 1.0000 | PROPblock_40 | verified | — |
| 277.2 | PROPblock_40 | verified | — |
| 2.0 | PROPblock_40 | verified | — |
| 277.2 | PROPblock_40 | verified | — |
| 1.0 | PROPblock_40 | verified | — |
| 225.4 | PROPblock_40 | verified | — |
| 0.2499 | PROPblock_40 | verified | — |
| 0.1678 | PROPblock_41 | verified | — |
| 211.6 | PROPblock_41 | verified | — |
| 2.0 | PROPblock_41 | verified | — |
| 0.1998 | PROPblock_41 | verified | — |
| 217.2 | PROPblock_41 | verified | — |
| 2.0 | PROPblock_41 | verified | — |
| 277.2 | PROPblock_40 | verified | — |
| 0.2499 | PROPblock_40 | verified | — |
| 225.4 | PROPblock_40 | verified | — |
| 0.1678 | PROPblock_41 | verified | — |
| 211.6 | PROPblock_41 | verified | — |
| 0.1998 | PROPblock_41 | verified | — |
| 217.2 | PROPblock_41 | verified | — |
| 0.17 | PROPblock_41 | verified | — |
| 0.25 | PROPblock_41 | misattributed | PROPblock_40 |
| 211.6 | PROPblock_41 | verified | — |

## Violations

- **UNGROUNDED_LITERAL** PROPblock_40: 16 (near '…— Crystal 1 (DMC-rich liquidus branch, 16 data points)  This…') matches no inspected row/stat, database table, or other source of PROPblock_40
- **MISATTRIBUTED_VALUE** PROPblock_41: 0.25 does not belong to PROPblock_41; it matches only GLOBlit_8264::PROPblock_40 (inspected this run)

## Inspections (verbatim)

### INSP_943c93eced38 — GLOBlit_8264::PROPblock_40 (rdp, 8 rows shown)

_structured envelope entry (no markdown)_

### INSP_a90a8822f2c9 — GLOBlit_8264::PROPblock_41 (complete, 2 rows shown)

_structured envelope entry (no markdown)_

### INSP_69ee531f6a5f — GLOBlit_8264::PROPblock_40 (complete, 6 rows shown)

_structured envelope entry (no markdown)_

### INSP_f5f29a8c704e — GLOBlit_8264::PROPblock_40 (complete, 8 rows shown)

_structured envelope entry (no markdown)_
