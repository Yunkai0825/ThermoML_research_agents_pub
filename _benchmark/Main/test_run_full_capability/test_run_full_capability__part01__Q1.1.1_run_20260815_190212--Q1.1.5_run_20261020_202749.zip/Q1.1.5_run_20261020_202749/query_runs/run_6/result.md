# Delegated query run — result

**Question:** Find solid-liquid equilibrium (SLE), liquidus, freezing point, or fusion temperature data for the binary mixture of dimethyl carbonate (GLOBcomp_62) and propylene carbonate (GLOBcomp_146, 4-methyl-1,3-dioxolan-2-one). Report all blocks with temperatures, compositions, uncertainties, and DOIs.

**Iterations:** 2  |  **Elapsed:** 161.3s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Solid–Liquid Equilibrium (SLE) Temperature Data for Dimethyl Carbonate + Propylene Carbonate

**Source:** DOI 10.1021/je034134e (GLOBlit_8264)

The ThermoML database contains SLE temperature data for the binary system of **dimethyl carbonate (DMC)** and **propylene carbonate (PC, 4-methyl-1,3-dioxolan-2-one)**, reported in two data blocks corresponding to two crystallization branches of a simple eutectic phase diagram. All measurements were performed at a pressure of **101.3 kPa**, with an expanded combined uncertainty of **±2.0 K** (95% confidence level). The measurement method is differential thermal analysis (DTA).

---

### PROPblock_40 — Crystal 1 (DMC-rich liquidus branch, 16 data points)

This block covers the liquidus curve where **solid DMC** is in equilibrium with the liquid mixture (phase: Liquid + Crystal 1). The SLE temperature increases monotonically with DMC mole fraction.

| x(DMC, liquid) | T_SLE (K) | U (K) |
|:-:|:-:|:-:|
| 0.2499 | 225.4 | 2.0 |
| 0.3003 | 232.2 | 2.0 |
| 0.3496 | 237.7 | 2.0 |
| 0.4027 | 243.0 | 2.0 |
| 0.4498 | 246.9 | 2.0 |
| 0.5011 | 250.5 | 2.0 |
| 0.5521 | 254.6 | 2.0 |
| 0.6071 | 257.5 | 2.0 |
| 0.6621 | 261.2 | 2.0 |
| 0.6996 | 263.2 | 2.0 |
| 0.7501 | 265.9 | 2.0 |
| 0.7993 | 268.2 | 2.0 |
| 0.8501 | 270.6 | 2.0 |
| 0.8998 | 272.7 | 2.0 |
| 0.9491 | 274.9 | 2.0 |
| 1.0000 | 277.2 | 2.0 |

The pure DMC melting point is **277.2 K** (x_DMC = 1.0). The lowest liquidus temperature in this branch is **225.4 K** at x_DMC = 0.2499, approaching the eutectic composition.

---

### PROPblock_41 — Crystal 2 (PC-rich liquidus branch, 2 data points)

This block covers the liquidus curve where **solid PC** is in equilibrium with the liquid mixture (phase: Liquid + Crystal 2).

| x(DMC, liquid) | T_SLE (K) | U (K) |
|:-:|:-:|:-:|
| 0.1678 | 211.6 | 2.0 |
| 0.1998 | 217.2 | 2.0 |

---

### Chemical Insight

The two branches together outline a **simple eutectic phase diagram** for the DMC + PC binary system:

- **Crystal 1 branch** (PROPblock_40): DMC crystallizes out of solution. The liquidus spans from pure DMC (277.2 K) down to x_DMC = 0.2499 (225.4 K), showing significant freezing point depression as PC is added.
- **Crystal 2 branch** (PROPblock_41): PC crystallizes out on the PC-rich side, with only two measured points at x_DMC = 0.1678 (211.6 K) and x_DMC = 0.1998 (217.2 K).
- **Eutectic point**: The eutectic lies between x_DMC ≈ 0.17 and x_DMC ≈ 0.25, at a temperature below 211.6 K (the lowest recorded SLE temperature, from PROPblock_41).
- The DMC-rich liquidus shows **near-linear behavior** at high DMC concentrations, suggesting relatively ideal solution behavior in that region, with increasing deviation from linearity as the eutectic composition is approached. This is consistent with the structural similarity of these two cyclic/linear organic carbonates, which share similar intermolecular interaction types (dipole–dipole, dispersion) but differ in molecular size and symmetry.

### Core claims

- The ThermoML database (DOI 10.1021/je034134e) contains SLE temperature data for the binary system dimethyl carbonate (DMC) + propylene carbonate (PC), measured by differential thermal analysis at 101.3 kPa with an expanded combined uncertainty of ±2.0 K (95% confidence level).
- The phase diagram is a simple eutectic system with two liquidus branches: a DMC-rich branch (Crystal 1, 16 data points) spanning x(DMC) = 0.2499 at 225.4 K to pure DMC at 277.2 K, and a PC-rich branch (Crystal 2, 2 data points) at x(DMC) = 0.1678 (211.6 K) and x(DMC) = 0.1998 (217.2 K).
- The eutectic point lies between x(DMC) ≈ 0.17 and x(DMC) ≈ 0.25, at a temperature below 211.6 K.
- The pure DMC melting point reported is 277.2 K at x(DMC) = 1.0.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_40 |  | Provides the DMC-rich liquidus branch (Crystal 1) of the SLE phase diagram for dimethyl carbonate + propylene carbonate, with 16 data points spanning x(DMC) = 0.2499–1.0 and T = 225.4–277.2 K at 101.3 kPa, directly reproduced in the answer table. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_41 |  | Provides the PC-rich liquidus branch (Crystal 2) of the same SLE phase diagram, with 2 data points at x(DMC) = 0.1678–0.1998 and T = 211.6–217.2 K at 101.3 kPa, completing the eutectic diagram presented in the answer. |

### Suggested follow-ups

- Compare the eutectic temperature and composition with ideal-solution predictions using the van't Hoff equation and pure-component fusion enthalpies of DMC and PC.
- Search for additional SLE data on the PC-rich side (x_DMC < 0.17) to better locate the eutectic point.
- Look for excess Gibbs energy or activity coefficient data for the DMC+PC system to model deviations from ideal liquidus behavior.

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_40",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<dimethyl carbonate>",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "mole_fraction_<dimethyl carbonate>": "0.2499",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "225.4",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "mole_fraction_<dimethyl carbonate>": "0.3003",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "232.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "mole_fraction_<dimethyl carbonate>": "0.4027",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "243",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "mole_fraction_<dimethyl carbonate>": "0.5521",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "254.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "mole_fraction_<dimethyl carbonate>": "0.6071",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "257.5",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "mole_fraction_<dimethyl carbonate>": "0.6621",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "261.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "mole_fraction_<dimethyl carbonate>": "0.7501",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "265.9",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_16",
        "mole_fraction_<dimethyl carbonate>": "1",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "277.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      }
    ],
    "inspection_id": "INSP_943c93eced38",
    "lit_num_id": "GLOBlit_8264"
  },
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_41",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<dimethyl carbonate>",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "mole_fraction_<dimethyl carbonate>": "0.1678",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "211.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "mole_fraction_<dimethyl carbonate>": "0.1998",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "217.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      }
    ],
    "inspection_id": "INSP_a90a8822f2c9",
    "lit_num_id": "GLOBlit_8264"
  },
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_40",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<dimethyl carbonate>",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_2",
        "mole_fraction_<dimethyl carbonate>": "0.3003",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "232.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "mole_fraction_<dimethyl carbonate>": "0.3496",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "237.7",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "mole_fraction_<dimethyl carbonate>": "0.4027",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "243",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "mole_fraction_<dimethyl carbonate>": "0.4498",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "246.9",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "mole_fraction_<dimethyl carbonate>": "0.5011",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "250.5",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "mole_fraction_<dimethyl carbonate>": "0.5521",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "254.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      }
    ],
    "inspection_id": "INSP_69ee531f6a5f",
    "lit_num_id": "GLOBlit_8264"
  },
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_40",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<dimethyl carbonate>",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_9",
        "mole_fraction_<dimethyl carbonate>": "0.6621",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "261.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "mole_fraction_<dimethyl carbonate>": "0.6996",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "263.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "mole_fraction_<dimethyl carbonate>": "0.7501",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "265.9",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "mole_fraction_<dimethyl carbonate>": "0.7993",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "268.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "mole_fraction_<dimethyl carbonate>": "0.8501",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "270.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "mole_fraction_<dimethyl carbonate>": "0.8998",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "272.7",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "mole_fraction_<dimethyl carbonate>": "0.9491",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "274.9",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_16",
        "mole_fraction_<dimethyl carbonate>": "1",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "277.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      }
    ],
    "inspection_id": "INSP_f5f29a8c704e",
    "lit_num_id": "GLOBlit_8264"
  }
]
```
