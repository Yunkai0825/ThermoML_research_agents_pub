# Reference Stats — query-agent

**Run started:** 2026-10-20 20:35:43
**Wall time (at last flush):** 181.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 29,181 | 35,877 | 7,347 | 65,058 | 13,011 | 49.6 | claudeopus46 |
| L1-worker | 11 | 154,884 | 102,556 | 17,414 | 257,440 | 23,403 | 125.0 | claudeopus46 |
| verdict | 1 | 972 | 5,812 | 1,092 | 6,784 | 6,784 | 8.7 | claudeopus46 |
| **TOTAL** | **17** | **185,037** | **144,245** | **25,853** | **329,282** | **19,369** | **183.3** | |

**Estimated tokens:** ~82,320 input + ~6,463 output = ~88,783 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 2 | 1 | 1 | 1 | 1 | 2 | 18 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **1** | **1** | **1** | **1** | **2** | **18** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8264 |  | search_blocks |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_146 | 4-methyl-1,3-dioxolan-2-one | search_blocks |
| GLOBcomp_62 | dimethyl carbonate | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_230 | Solid-liquid equilibrium temperature, K | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 1 |
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Unique Constraints | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 2 |
| Explicit block/subsystem targets | 2 |
| Subsystem targets | 0 |
| Target-matched data points | 18 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 2  |  **Explicit targets:** 2  |  **Subsystems:** 0  |  **Target-matched datapoints:** 18

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je034134e | 2 | 18 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je034134e | PROPblock_40 | declared | 16 | binary | — | search_blocks |
| 10.1021/je034134e | PROPblock_41 | declared | 2 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_blocks` | compound=['GLOBcomp_62', 'GLOBcomp_146…, limit=50,… | 1,218 | KEEP ←in 3,064 | 1218 | 23.6 |
| 2 | 2 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_40, purpose=R… | 1,367 | — | — | 0.1 |
| 3 | 2 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_41, purpose=R… | 923 | — | — | 0.1 |
| 4 | 3 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_40, purpose=G… | 1,483 | — | — | 0.3 |
| 5 | 3 | `inspect_block_table` | block_number=GLOBlit_8264::PROPblock_40, purpose=G… | 1,565 | — | — | 0.3 |
| 6 | 1 | `L1_query` | context=Looking for liquidus curves, …, id_catalog… | 26,039 | — | — | 126.8 |
| | | **TOTAL (6 tools)** | | **32,595** | | **1,218** | **151.2** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 948 | 12,529 | 1,535 | 8.8 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,459 | 25,599 | 923 | 5.8 |
| 3 | L1-worker | claudeopus46 | 3,767 | 3,518 | 7,285 | 1,599 | 11.8 |
| 4 | L1-worker | claudeopus46 | 24,140 | 3,184 | 27,324 | 1,082 | 6.7 |
| 5 | L1-worker | claudeopus46 | 24,140 | 6,203 | 30,343 | 1,422 | 10.4 |
| 6 | L1-worker | claudeopus46 | 24,140 | 10,007 | 34,147 | 2,656 | 18.8 |
| 7 | L1-worker | claudeopus46 | 24,140 | 16,243 | 40,383 | 2,880 | 21.1 |
| 8 | L1-worker | claudeopus46 | 24,140 | 22,360 | 46,500 | 2,978 | 21.7 |
| 9 | L1-worker | claudeopus46 | 2,543 | 6,767 | 9,310 | 1,074 | 6.2 |
| 10 | L1-worker | claudeopus46 | 627 | 5,067 | 5,694 | 852 | 6.1 |
| 11 | L1-worker | claudeopus46 | 2,320 | 5,187 | 7,507 | 1,066 | 7.8 |
| 12 | L1-worker | claudeopus46 | 787 | 22,561 | 23,348 | 882 | 8.6 |
| 13 | L0-main | claudeopus46 | 11,581 | 22,850 | 34,431 | 3,547 | 25.0 |
| 14 | L0-main | claudeopus46 | 2,543 | 3,940 | 6,483 | 709 | 5.2 |
| 15 | L0-main | claudeopus46 | 2,320 | 3,160 | 5,480 | 816 | 5.5 |
| 16 | L0-main | claudeopus46 | 1,156 | 4,979 | 6,135 | 740 | 5.1 |
| 17 | verdict | claudeopus46 | 972 | 5,812 | 6,784 | 1,092 | 8.7 |

