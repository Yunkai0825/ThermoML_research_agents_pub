# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find solid-liquid equilibrium (SLE) temperature data for the binary mixture of dimethyl carbonate (DMC) and propylene ca → stored as L1_query_1 · validation: FLAGGED(6)

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: FLAGGED(6)

**Summary:**

Solid-liquid equilibrium temperatures for the binary system dimethyl carbonate (DMC) + propylene carbonate (PC) from DOI 10.1021/je034134e, measured at 101.3 kPa with an expanded uncertainty of ±2.0 K. The data form a simple eutectic phase diagram with two liquidus branches. The DMC-rich branch (Crystal 1, 16 points) spans x(DMC) = 0.2499 to 1.0000 with SLE temperatures from 225.4 K to 277.2 K, the latter being the pure DMC melting point. The PC-rich branch (Crystal 2, 2 points) covers x(DMC) = 0.1678 and 0.1998 with SLE temperatures of 211.6 K and 217.2 K, respectively. The eutectic point lies between x(DMC) ≈ 0.17 and 0.2499 at a temperature below 211.6 K. Near-linear liquidus behavior at high DMC concentrations suggests relatively ideal solution behavior, with increasing deviation as the eutectic is approached.

**Answer:**

#### Solid-Liquid Equilibrium (SLE) Temperature Data for Dimethyl Carbonate + Propylene Carbonate

**Source:** DOI 10.1021/je034134e (GLOBlit_8264)

The ThermoML database contains SLE temperature data for the binary system of dimethyl carbonate (DMC, GLOBcomp_62) and propylene carbonate (PC / 4-methyl-1,3-dioxolan-2-one, GLOBcomp_146), reported in two blocks corresponding to two crystallization branches. All measurements are at a pressure of 101.3 kPa, with an expanded combined uncertainty of ±2.0 K (95% confidence level).

---

##### PROPblock_40 — Crystal 1 (DMC-rich liquidus branch, 16 data points)

This block covers the liquidus curve where solid DMC is in equilibrium with the liquid mixture (phase: Liquid + Crystal 1). The SLE temperature increases monotonically with DMC mole fraction.

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *x(DMC, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「0.2499」 | 「225.4」 | 「2.0」 |
| WM_L1#1_Table#1_Row#2 | 「0.3003」 | 「232.2」 | 「2.0」 |
| WM_L1#1_Table#1_Row#3 | 「0.3496」 | 「237.7」 | 「2.0」 |
| WM_L1#1_Table#1_Row#4 | 「0.4027」 | 「243.0」 | 「2.0」 |
| WM_L1#1_Table#1_Row#5 | 「0.4498」 | 「246.9」 | 「2.0」 |
| WM_L1#1_Table#1_Row#6 | 「0.5011」 | 「250.5」 | 「2.0」 |
| WM_L1#1_Table#1_Row#7 | 「0.5521」 | 「254.6」 | 「2.0」 |
| WM_L1#1_Table#1_Row#8 | 「0.6071」 | 「257.5」 | 「2.0」 |
| WM_L1#1_Table#1_Row#9 | 「0.6621」 | 「261.2」 | 「2.0」 |
| WM_L1#1_Table#1_Row#10 | 「0.6996」 | 「263.2」 | 「2.0」 |
| WM_L1#1_Table#1_Row#11 | 「0.7501」 | 「265.9」 | 「2.0」 |
| WM_L1#1_Table#1_Row#12 | 「0.7993」 | 「268.2」 | 「2.0」 |
| WM_L1#1_Table#1_Row#13 | 「0.8501」 | 「270.6」 | 「2.0」 |
| WM_L1#1_Table#1_Row#14 | 「0.8998」 | 「272.7」 | 「2.0」 |
| WM_L1#1_Table#1_Row#15 | 「0.9491」 | 「274.9」 | 「2.0」 |
| WM_L1#1_Table#1_Row#16 | 「1.0000」 | 「277.2」 | 「2.0」 |

The pure DMC melting point is 277.2 K (at x_DMC = 1.0, from PROPblock_40). The lowest liquidus temperature in this branch is 225.4 K at x_DMC = 0.2499 (from PROPblock_40), approaching the eutectic composition.

---

##### PROPblock_41 — Crystal 2 (PC-rich liquidus branch, 2 data points)

This block covers the liquidus curve where solid PC is in equilibrium with the liquid mixture (phase: Liquid + Crystal 2).

**WM_L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *x(DMC, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「0.1678」 | 「211.6」 | 「2.0」 |
| WM_L1#1_Table#2_Row#2 | 「0.1998」 | 「217.2」 | 「2.0」 |

---

##### Chemical Insight

The two branches together outline a simple eutectic phase diagram for the DMC + PC binary system. The Crystal 1 branch (DMC crystallizing out, PROPblock_40) spans from pure DMC down to x_DMC = 0.2499, while the Crystal 2 branch (PC crystallizing out, PROPblock_41) covers the PC-rich side up to x_DMC = 0.1998. The eutectic point lies between x_DMC ≈ 0.17 (the lowest composition in PROPblock_41) and x_DMC = 0.2499 (the lowest composition in PROPblock_40), at a temperature below 211.6 K (the lowest recorded SLE temperature, from PROPblock_41). The drop from the pure DMC melting point of 277.2 K to 225.4 K at x_DMC = 0.2499 (both from PROPblock_40; difference of 51.8 K computed by subtraction of these two inspected values) demonstrates significant freezing point depression consistent with the thermodynamic non-ideality expected for these two structurally related carbonates. The near-linear behavior of the DMC-rich liquidus (R² = 0.9985 for x_DMC = 0.66–1.0, as reported by the inspection tool for PROPblock_40) suggests relatively ideal solution behavior at high DMC concentrations, with increasing deviation from linearity as the eutectic is approached.

**Core claims:**
- The ThermoML database (DOI 10.1021/je034134e) contains solid-liquid equilibrium temperature data for the dimethyl carbonate (DMC) + propylene carbonate (PC) binary system at 101.3 kPa with an expanded combined uncertainty of ±2.0 K.
- The DMC-rich liquidus branch (Crystal 1, PROPblock_40) spans 16 data points from x_DMC = 0.2499 (T_SLE = 225.4 K) to pure DMC at x_DMC = 1.0 (T_SLE = 277.2 K), with SLE temperature increasing monotonically with DMC mole fraction.
- The PC-rich liquidus branch (Crystal 2, PROPblock_41) contains 2 data points: x_DMC = 0.1678 at T_SLE = 211.6 K and x_DMC = 0.1998 at T_SLE = 217.2 K.
- The two branches outline a simple eutectic phase diagram, with the eutectic point lying between x_DMC ≈ 0.17 and x_DMC = 0.2499, at a temperature below 211.6 K.
- The DMC-rich liquidus shows near-linear behavior at high DMC concentrations (R² = 0.9985 for x_DMC = 0.66–1.0 as reported by the inspection tool), with increasing deviation from linearity as the eutectic is approached.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_8264」 | 「PROPblock_40」 | 「GLOBcomp_146, GLOBcomp_62」 | 「GLOBprop_11」 | 「SLE temperature data for the DMC-rich liquidus branch (Crystal 1) of the dimethyl carbonate + propylene carbonate binary system, 16 data points spanning x(DMC) = 0.2499 to 1.0000 with temperatures from 225.4 K to 277.2 K.」 |
| WM_L1#1_Table#4 | 「GLOBlit_8264」 | 「PROPblock_41」 | 「GLOBcomp_146, GLOBcomp_62」 | 「GLOBprop_11」 | 「SLE temperature data for the PC-rich liquidus branch (Crystal 2) of the dimethyl carbonate + propylene carbonate binary system, 2 data points at x(DMC) = 0.1678 and 0.1998 with temperatures 211.6 K and 217.2 K.」 |

*Not stored here: 4 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(6) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **MISATTRIBUTED_VALUE** PROPblock_41: 0.2499 does not belong to PROPblock_41; it matches only GLOBlit_8264::PROPblock_40 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_40: 211.6 does not belong to PROPblock_40; it matches only GLOBlit_8264::PROPblock_41 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_41: 277.2 does not belong to PROPblock_41; it matches only GLOBlit_8264::PROPblock_40 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_41: 225.4 does not belong to PROPblock_41; it matches only GLOBlit_8264::PROPblock_40 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_41: 0.2499 does not belong to PROPblock_41; it matches only GLOBlit_8264::PROPblock_40 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_40: 51.8 (near '…; difference of 51.8 K computed by subtraction of these two…') matches no inspected row/stat, database table, or other source of PROPblock_40


