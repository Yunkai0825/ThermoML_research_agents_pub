# Reference Stats — query-agent

**Run started:** 2026-10-20 20:35:22
**Wall time (at last flush):** 151.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 29,181 | 24,709 | 6,193 | 53,890 | 10,778 | 41.0 | claudeopus46 |
| L1-worker | 12 | 179,024 | 68,868 | 13,839 | 247,892 | 20,657 | 99.7 | claudeopus46 |
| verdict | 1 | 972 | 5,092 | 1,127 | 6,064 | 6,064 | 9.8 | claudeopus46 |
| **TOTAL** | **18** | **209,177** | **98,669** | **21,159** | **307,846** | **17,102** | **150.5** | |

**Estimated tokens:** ~76,961 input + ~5,289 output = ~82,250 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 2 | 1 | 1 | 1 | 1 | 1 | 15 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **1** | **1** | **1** | **1** | **1** | **15** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8264 |  | search_blocks |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_312 | ethylene carbonate | search_blocks |
| GLOBcomp_146 | 4-methyl-1,3-dioxolan-2-one | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_230 | Solid-liquid equilibrium temperature, K | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 1 |
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Unique Constraints | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 15 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 15

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je034134e | 1 | 15 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je034134e | PROPblock_45 | declared | 15 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_blocks` | compound=['GLOBcomp_312', 'GLOBcomp_14…, limit=50,… | 1,358 | KEEP ←in 1,770 | 1328 | 20.4 |
| 2 | 2 | `inspect_block_table` | block_number=PROPblock_45, literature=GLOBlit_8264… | 1,484 | — | — | 0.9 |
| 3 | 3 | `inspect_block_table` | block_number=PROPblock_45, literature=GLOBlit_8264… | 426 | — | — | 0.1 |
| 4 | 4 | `inspect_block_table` | block_number=PROPblock_45, literature=GLOBlit_8264… | 1,552 | — | — | 0.1 |
| 5 | 5 | `inspect_block_table` | block_number=PROPblock_45, literature=GLOBlit_8264… | 1,211 | — | — | 1.2 |
| 6 | 1 | `L1_query` | context=Looking for liquidus curves, …, id_catalog… | 15,424 | — | — | 105.4 |
| | | **TOTAL (6 tools)** | | **21,455** | | **1,328** | **128.1** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 948 | 12,529 | 1,415 | 7.6 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,326 | 25,466 | 926 | 5.9 |
| 3 | L1-worker | claudeopus46 | 3,767 | 2,242 | 6,009 | 1,601 | 11.2 |
| 4 | L1-worker | claudeopus46 | 24,140 | 3,190 | 27,330 | 776 | 6.4 |
| 5 | L1-worker | claudeopus46 | 24,140 | 5,186 | 29,326 | 1,137 | 8.6 |
| 6 | L1-worker | claudeopus46 | 24,140 | 6,155 | 30,295 | 1,885 | 13.7 |
| 7 | L1-worker | claudeopus46 | 24,140 | 8,209 | 32,349 | 942 | 8.4 |
| 8 | L1-worker | claudeopus46 | 24,140 | 9,936 | 34,076 | 1,926 | 14.9 |
| 9 | L1-worker | claudeopus46 | 24,140 | 14,446 | 38,586 | 1,884 | 10.4 |
| 10 | L1-worker | claudeopus46 | 2,543 | 3,462 | 6,005 | 559 | 4.1 |
| 11 | L1-worker | claudeopus46 | 2,320 | 2,015 | 4,335 | 790 | 5.0 |
| 12 | L1-worker | claudeopus46 | 627 | 1,895 | 2,522 | 923 | 5.7 |
| 13 | L1-worker | claudeopus46 | 787 | 10,806 | 11,593 | 490 | 5.4 |
| 14 | L0-main | claudeopus46 | 11,581 | 14,623 | 26,204 | 2,584 | 19.1 |
| 15 | L0-main | claudeopus46 | 2,543 | 3,219 | 5,762 | 650 | 5.3 |
| 16 | L0-main | claudeopus46 | 2,320 | 2,439 | 4,759 | 1,119 | 5.4 |
| 17 | L0-main | claudeopus46 | 1,156 | 3,480 | 4,636 | 425 | 3.6 |
| 18 | verdict | claudeopus46 | 972 | 5,092 | 6,064 | 1,127 | 9.8 |

