# Delegated query run — result

**Question:** Find solid-liquid equilibrium (SLE), liquidus, freezing point, or fusion temperature data for the binary mixture of ethylene carbonate (GLOBcomp_312) and propylene carbonate (GLOBcomp_146, 4-methyl-1,3-dioxolan-2-one). Report all blocks with temperatures, compositions, uncertainties, and DOIs.

**Iterations:** 2  |  **Elapsed:** 132.5s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Solid-Liquid Equilibrium (Liquidus) Data for Ethylene Carbonate + Propylene Carbonate Binary System

### Source

**Ding et al. (2004)**  
DOI: 10.1021/je034134e [GLOBlit_8264]  
Block: PROPblock_45  
Method: Differential Thermal Analysis (DTA)  
Pressure: 101.3 kPa (fixed)  
Expanded combined uncertainty: U = 2 K (95% confidence level)  
Phases: Liquid + Crystal

---

### Complete Liquidus Curve — 15 Data Points

| x(EC) (mole fraction, liquid) | T_SLE (K) | U (K) |
|:-----------------------------:|:---------:|:-----:|
| 0.3001 | 253.6 | 2 |
| 0.3498 | 255.1 | 2 |
| 0.4003 | 257.1 | 2 |
| 0.4504 | 265.6 | 2 |
| 0.5005 | 270.6 | 2 |
| 0.5506 | 273.9 | 2 |
| 0.5965 | 279.8 | 2 |
| 0.6499 | 284.0 | 2 |
| 0.6999 | 288.2 | 2 |
| 0.7492 | 290.8 | 2 |
| 0.7991 | 294.0 | 2 |
| 0.8492 | 297.8 | 2 |
| 0.8995 | 301.8 | 2 |
| 0.9354 | 304.6 | 2 |
| 1.0000 | 311.2 | 2 |

---

### Chemical Insight

This is the only dataset found in the ThermoML database for the SLE of the ethylene carbonate (EC) + propylene carbonate (PC) binary system. Key observations:

1. **Monotonic, near-linear liquidus:** The SLE temperature rises steadily from 253.6 K at x(EC) = 0.3001 to 311.2 K for pure EC (x(EC) = 1.0000), spanning a range of ~57.6 K. This near-linear behavior is consistent with relatively ideal solid-liquid equilibrium, expected for two structurally similar cyclic carbonates differing only by a methyl group on the dioxolane ring.

2. **EC-rich branch only:** The data cover only the EC-rich side of the phase diagram (x(EC) ≥ 0.30), corresponding to crystallization of EC from the liquid mixture. No PC-rich branch data are reported.

3. **Eutectic point not directly measured:** The lowest reported SLE temperature is 253.6 K at x(EC) = 0.3001, suggesting the eutectic lies at or below this composition. The eutectic temperature and composition are not directly available from this dataset.

4. **Practical relevance:** EC (melting point 311.2 K / 38 °C) is a key electrolyte solvent in lithium-ion batteries. Blending with PC (which has a much lower melting point, ~−49 °C) depresses the freezing point substantially — by nearly 58 K at x(EC) ≈ 0.30 — enabling low-temperature battery operation while retaining EC's high dielectric constant.

### Core claims

- The only SLE (liquidus) dataset found in the ThermoML database for the ethylene carbonate (EC) + propylene carbonate (PC) binary system is from Ding et al. (2004) (DOI: 10.1021/je034134e), measured by differential thermal analysis at 101.3 kPa with an expanded combined uncertainty of U = 2 K.
- The dataset comprises 15 data points covering the EC-rich branch of the liquidus from x(EC) = 0.3001 (T = 253.6 K) to x(EC) = 1.0000 (T = 311.2 K), showing a monotonic, near-linear increase in SLE temperature with increasing EC mole fraction.
- Only the EC-rich side of the phase diagram (x(EC) ≥ 0.30) is covered; no PC-rich branch data are reported, and the eutectic point is not directly measured, though the lowest reported SLE temperature of 253.6 K at x(EC) = 0.3001 suggests the eutectic lies at or below this composition.
- The near-linear liquidus behavior is consistent with relatively ideal solid-liquid equilibrium, expected for two structurally similar cyclic carbonates differing only by a methyl group on the dioxolane ring.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_45 |  | This block provides all 15 solid-liquid equilibrium (liquidus) data points for the ethylene carbonate + propylene carbonate binary system, covering mole fractions 0.3001–1.0 and temperatures 253.6–311.2 K at 101.3 kPa, which constitute the entirety of the answer's tabulated data. |

### Suggested follow-ups

- Search for the PC-rich branch of the EC+PC SLE phase diagram (x(EC) < 0.30) in other ThermoML or literature sources to locate the eutectic point.
- Look for excess enthalpy or activity coefficient data for EC+PC mixtures to assess ideality of mixing and compare with the near-linear liquidus behavior observed.
- Check for ternary SLE data involving EC, PC, and a third solvent (e.g., DMC or DEC) relevant to lithium-ion battery electrolyte formulation.

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_45",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<ethylene carbonate>",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "mole_fraction_<ethylene carbonate>": "0.3001",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "253.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "mole_fraction_<ethylene carbonate>": "0.4003",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "257.1",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "mole_fraction_<ethylene carbonate>": "0.4504",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "265.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "mole_fraction_<ethylene carbonate>": "0.5005",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "270.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "mole_fraction_<ethylene carbonate>": "0.5506",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "273.9",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "mole_fraction_<ethylene carbonate>": "0.5965",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "279.8",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "mole_fraction_<ethylene carbonate>": "0.6999",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "288.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "mole_fraction_<ethylene carbonate>": "0.8492",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "297.8",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "mole_fraction_<ethylene carbonate>": "0.9354",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "304.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "mole_fraction_<ethylene carbonate>": "1",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "311.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      }
    ],
    "inspection_id": "INSP_b805d4f37345",
    "lit_num_id": "GLOBlit_8264"
  },
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_45",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<ethylene carbonate>",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_8",
        "mole_fraction_<ethylene carbonate>": "0.6499",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "284",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "mole_fraction_<ethylene carbonate>": "0.6999",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "288.2",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "mole_fraction_<ethylene carbonate>": "0.7492",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "290.8",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "mole_fraction_<ethylene carbonate>": "0.7991",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "294",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "mole_fraction_<ethylene carbonate>": "0.8492",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "297.8",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "mole_fraction_<ethylene carbonate>": "0.8995",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "301.8",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "mole_fraction_<ethylene carbonate>": "0.9354",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "304.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      }
    ],
    "inspection_id": "INSP_5d610228f5b3",
    "lit_num_id": "GLOBlit_8264"
  },
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_45",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<ethylene carbonate>",
      "pressure_kpa",
      "solidliquid_equilibrium_temperature_k",
      "solidliquid_equilibrium_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "mole_fraction_<ethylene carbonate>": "0.3001",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "253.6",
        "solidliquid_equilibrium_temperature_k_U": "2"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "mole_fraction_<ethylene carbonate>": "0.3498",
        "pressure_kpa": "101.3",
        "solidliquid_equilibrium_temperature_k": "255.1",
        "solidliquid_equilibrium_temperature_k_U": "2"
      }
    ],
    "inspection_id": "INSP_0e5c7ceb1888",
    "lit_num_id": "GLOBlit_8264"
  }
]
```
