# Data grounding evidence

- generated: 2026-10-20T20:37:35
- gate verdict: 5 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_45 | GLOBlit_8264 | yes | INSP_b805d4f37345, INSP_5d610228f5b3, INSP_0e5c7ceb1888 | 15 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 101.3 | PROPblock_45 | verified | — |
| 15 | PROPblock_45 | ungrounded | — |
| 0.3001 | PROPblock_45 | verified | — |
| 253.6 | PROPblock_45 | verified | — |
| 0.3498 | PROPblock_45 | verified | — |
| 255.1 | PROPblock_45 | verified | — |
| 0.4003 | PROPblock_45 | verified | — |
| 257.1 | PROPblock_45 | verified | — |
| 0.4504 | PROPblock_45 | verified | — |
| 265.6 | PROPblock_45 | verified | — |
| 0.5005 | PROPblock_45 | verified | — |
| 270.6 | PROPblock_45 | verified | — |
| 0.5506 | PROPblock_45 | verified | — |
| 273.9 | PROPblock_45 | verified | — |
| 0.5965 | PROPblock_45 | verified | — |
| 279.8 | PROPblock_45 | verified | — |
| 0.6499 | PROPblock_45 | verified | — |
| 284.0 | PROPblock_45 | verified | — |
| 0.6999 | PROPblock_45 | verified | — |
| 288.2 | PROPblock_45 | verified | — |
| 0.7492 | PROPblock_45 | verified | — |
| 290.8 | PROPblock_45 | verified | — |
| 0.7991 | PROPblock_45 | verified | — |
| 294.0 | PROPblock_45 | verified | — |
| 0.8492 | PROPblock_45 | verified | — |
| 297.8 | PROPblock_45 | verified | — |
| 0.8995 | PROPblock_45 | verified | — |
| 301.8 | PROPblock_45 | verified | — |
| 0.9354 | PROPblock_45 | verified | — |
| 304.6 | PROPblock_45 | verified | — |
| 1.0000 | PROPblock_45 | verified | — |
| 311.2 | PROPblock_45 | verified | — |
| 253.6 | PROPblock_45 | verified | — |
| 0.3001 | PROPblock_45 | verified | — |
| 311.2 | PROPblock_45 | verified | — |
| 1.0000 | PROPblock_45 | verified | — |
| 57.6 | PROPblock_45 | ungrounded | — |
| 0.30 | PROPblock_45 | verified | — |
| 253.6 | PROPblock_45 | verified | — |
| 0.3001 | PROPblock_45 | verified | — |
| 311.2 | PROPblock_45 | verified | — |
| 38 | PROPblock_45 | ungrounded | — |
| -49 | PROPblock_45 | ungrounded | — |
| 58 | PROPblock_45 | ungrounded | — |
| 0.30 | PROPblock_45 | verified | — |

## Violations

- **UNGROUNDED_LITERAL** PROPblock_45: 15 (near '…hases: Liquid + Crystal  ---  ### Complete Liquidus Curve — …') matches no inspected row/stat, database table, or other source of PROPblock_45
- **UNGROUNDED_LITERAL** PROPblock_45: 57.6 (near '…311.2 K for pure EC (x(EC) = 1.0000), spanning a range of ~5…') matches no inspected row/stat, database table, or other source of PROPblock_45
- **UNGROUNDED_LITERAL** PROPblock_45: 38 (near '…t.  4. **Practical relevance:** EC (melting point 311.2 K / …') matches no inspected row/stat, database table, or other source of PROPblock_45
- **UNGROUNDED_LITERAL** PROPblock_45: -49 (near '…s. Blending with PC (which has a much lower melting point, ~…') matches no inspected row/stat, database table, or other source of PROPblock_45
- **UNGROUNDED_LITERAL** PROPblock_45: 58 (near '…°C) depresses the freezing point substantially — by nearly 5…') matches no inspected row/stat, database table, or other source of PROPblock_45

## Inspections (verbatim)

### INSP_b805d4f37345 — GLOBlit_8264::PROPblock_45 (rdp, 10 rows shown)

_structured envelope entry (no markdown)_

### INSP_5d610228f5b3 — GLOBlit_8264::PROPblock_45 (complete, 7 rows shown)

_structured envelope entry (no markdown)_

### INSP_0e5c7ceb1888 — GLOBlit_8264::PROPblock_45 (complete, 2 rows shown)

_structured envelope entry (no markdown)_
