# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find solid-liquid equilibrium (SLE) temperature data for the binary mixture of ethylene carbonate (EC) and propylene car → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

Solid-liquid equilibrium (liquidus) temperature data for the ethylene carbonate (EC) + propylene carbonate (PC) binary system were found in the ThermoML database from Ding et al. (2004), DOI 10.1021/je034134e [GLOBlit_8264], block PROPblock_45, measured by DTA at 101.3 kPa with an expanded combined uncertainty U = 2 K (95% confidence level). The dataset contains 15 liquidus points covering the EC-rich branch from x(EC) = 0.3001 (T = 253.6 K) to pure EC at x(EC) = 1.0000 (T = 311.2 K). The SLE temperature increases monotonically and near-linearly over this composition range, indicating relatively ideal behavior for these two structurally similar cyclic carbonates. No data below x(EC) = 0.30 are reported, so the eutectic point is not directly available from these measurements, though the lowest measured temperature (253.6 K at x(EC) = 0.3001) suggests the eutectic lies at or below this composition.

**Answer:**

#### Solid-Liquid Equilibrium Temperature Data for Ethylene Carbonate + Propylene Carbonate Binary System

One dataset was found in the ThermoML database for the SLE temperature (liquidus curve) of the ethylene carbonate (EC) + propylene carbonate (PC) binary system.

**Source:** Ding et al. (2004), DOI: 10.1021/je034134e [GLOBlit_8264]

**Block:** PROPblock_45  
**Method:** DTA (GLOBmeas_230)  
**Pressure:** 101.3 kPa (fixed constraint)  
**Uncertainty:** Expanded combined uncertainty U = 2 K (95% confidence level)  
**Phases:** Liquid + Crystal

##### Complete Liquidus Data (15 points)

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *x(EC) (mole fraction, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「0.3001」 | 「253.6」 | 「2」 |
| WM_L1#1_Table#1_Row#2 | 「0.3498」 | 「255.1」 | 「2」 |
| WM_L1#1_Table#1_Row#3 | 「0.4003」 | 「257.1」 | 「2」 |
| WM_L1#1_Table#1_Row#4 | 「0.4504」 | 「265.6」 | 「2」 |
| WM_L1#1_Table#1_Row#5 | 「0.5005」 | 「270.6」 | 「2」 |
| WM_L1#1_Table#1_Row#6 | 「0.5506」 | 「273.9」 | 「2」 |
| WM_L1#1_Table#1_Row#7 | 「0.5965」 | 「279.8」 | 「2」 |
| WM_L1#1_Table#1_Row#8 | 「0.6499」 | 「284.0」 | 「2」 |
| WM_L1#1_Table#1_Row#9 | 「0.6999」 | 「288.2」 | 「2」 |
| WM_L1#1_Table#1_Row#10 | 「0.7492」 | 「290.8」 | 「2」 |
| WM_L1#1_Table#1_Row#11 | 「0.7991」 | 「294.0」 | 「2」 |
| WM_L1#1_Table#1_Row#12 | 「0.8492」 | 「297.8」 | 「2」 |
| WM_L1#1_Table#1_Row#13 | 「0.8995」 | 「301.8」 | 「2」 |
| WM_L1#1_Table#1_Row#14 | 「0.9354」 | 「304.6」 | 「2」 |
| WM_L1#1_Table#1_Row#15 | 「1.0000」 | 「311.2」 | 「2」 |

##### Chemical Insight

The liquidus curve is monotonically increasing and near-linear (R² = 0.9921) over the measured composition range from x(EC) = 0.3001 to pure EC. The SLE temperature rises from 253.6 K at x(EC) = 0.3001 to 311.2 K for pure ethylene carbonate (x(EC) = 1.0). The data covers only the EC-rich branch of the liquidus (x(EC) ≥ 0.30), which corresponds to the crystallization of EC from the liquid mixture. No data points below x(EC) = 0.30 are reported in this dataset, so the eutectic point composition and temperature are not directly available from these measurements, though the lowest measured temperature (253.6 K at x(EC) = 0.3001) suggests the eutectic lies at or below this composition. The near-linear behavior indicates relatively ideal solid-liquid equilibrium behavior in this system of two structurally similar cyclic carbonates.

**Core claims:**
- A single ThermoML dataset (Ding et al. 2004, DOI: 10.1021/je034134e) reports 15 solid-liquid equilibrium (liquidus) temperature points for the ethylene carbonate + propylene carbonate binary system, measured by DTA at 101.3 kPa with an expanded combined uncertainty U = 2 K (95% confidence level).
- The liquidus data cover the EC mole-fraction range x(EC) = 0.3001 to 1.0000, with T_SLE rising monotonically from 253.6 K at x(EC) = 0.3001 to 311.2 K for pure EC.
- Only the EC-rich branch of the liquidus (x(EC) ≥ 0.30) is covered; the eutectic point composition and temperature are not directly available from these measurements.
- The lowest measured SLE temperature is 253.6 K at x(EC) = 0.3001, suggesting the eutectic lies at or below this composition.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#2 | 「GLOBlit_8264」 | 「PROPblock_45」 | 「GLOBcomp_312, GLOBcomp_146」 | 「GLOBprop_11」 | 「Solid-liquid equilibrium temperature (liquidus curve) for the ethylene carbonate + propylene carbonate binary system, 15 data points from x(EC)=0.3001 to 1.0000, measured by DTA at 101.3 kPa.」 |

*Not stored here: 3 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


