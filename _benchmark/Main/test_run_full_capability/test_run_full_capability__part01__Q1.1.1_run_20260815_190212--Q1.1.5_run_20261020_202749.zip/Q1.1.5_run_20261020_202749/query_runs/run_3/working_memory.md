# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| prop | GLOBprop_12 | normal_melting_temperature_k | Normal melting temperature, K |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find pure-component melting temperature (solid-liquid equilibrium temperature) data for propylene carbonate → stored as L1_query_1 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: PASS

**Summary:**

The ThermoML database contains one pure-component melting temperature measurement for propylene carbonate (4-methyl-1,3-dioxolan-2-one, GLOBcomp_146). The datum, from DOI 10.1021/je034134e (GLOBlit_8264, PROPblock_19), reports a normal melting temperature (GLOBprop_12) of 220.3 K with an expanded combined uncertainty of 1.0 K at the 95% confidence level, measured by differential thermal analysis (DTA, GLOBmeas_243) at atmospheric pressure. No triple point temperature (GLOBprop_16) data exists for propylene carbonate in the database. Binary solid-liquid equilibrium (liquidus) data for propylene carbonate with co-solvents such as ethyl methyl carbonate are present from the same reference but report mixture SLE curves, not the pure-component melting point.

**Answer:**

The ThermoML database contains one pure-component melting temperature measurement for propylene carbonate (4-methyl-1,3-dioxolan-2-one, GLOBcomp_146):

**Normal melting temperature (GLOBprop_12)**

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *Source* | *DOI* | *Block* | *Value (K)* | *Uncertainty U (K)* | *Method* |
|---|---|---|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「GLOBlit_8264」 | 「10.1021/je034134e」 | 「PROPblock_19」 | 「220.3」 | 「±1.0 (k=95%, propagation)」 | 「DTA (GLOBmeas_243)」 |

This is the only pure-component (unary) melting point datum for propylene carbonate in the database. The measurement was made by differential thermal analysis (DTA), with the phase transition from crystal to liquid reported at atmospheric pressure (1 atm, air). The expanded combined uncertainty is 1.0 K at the 95% confidence level, evaluated by the data file compiler.

No triple point temperature (GLOBprop_16) data was found for propylene carbonate. The database also contains binary solid-liquid equilibrium (liquidus) data for propylene carbonate with various co-solvents (e.g., ethyl methyl carbonate) from the same reference (GLOBlit_8264), but those blocks report the SLE curve of the mixture rather than the pure-component melting point.

**Core claims:**
- The ThermoML database contains exactly one pure-component melting temperature measurement for propylene carbonate (4-methyl-1,3-dioxolan-2-one): 220.3 K with an expanded combined uncertainty of ±1.0 K (95% confidence level), measured by differential thermal analysis (DTA) at atmospheric pressure, from DOI 10.1021/je034134e.
- No triple point temperature data for propylene carbonate was found in the ThermoML database.
- Binary solid-liquid equilibrium (liquidus) data for propylene carbonate with various co-solvents exist in the same reference but report mixture SLE curves rather than the pure-component melting point.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#2 | 「GLOBlit_8264」 | 「PROPblock_19」 | 「GLOBcomp_146」 | 「GLOBprop_12」 | 「Pure-component normal melting temperature of propylene carbonate measured by DTA, reporting 220.3 ± 1.0 K.」 |

*Not stored here: 1 verbatim data_inspections table(s); 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


