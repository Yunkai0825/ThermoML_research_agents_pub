# Reference Stats — query-agent

**Run started:** 2026-10-20 20:30:46
**Wall time (at last flush):** 167.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 29,181 | 17,291 | 4,870 | 46,472 | 9,294 | 30.9 | claudeopus46 |
| L1-worker | 16 | 173,719 | 89,110 | 17,757 | 262,829 | 16,426 | 121.8 | claudeopus46 |
| verdict | 1 | 972 | 3,866 | 1,010 | 4,838 | 4,838 | 7.9 | claudeopus46 |
| **TOTAL** | **22** | **203,872** | **110,267** | **23,637** | **314,139** | **14,279** | **160.6** | |

**Estimated tokens:** ~78,534 input + ~5,909 output = ~84,443 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 5 | 1 | 1 | 1 | 1 | 5 | 54 |
| `resolve_property_ids` | 0 | 6 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 0 | 0 | 1 | 1 | 1 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 10 | 2 | 2 | 25 | 50 | 575 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **7** | **18** | **3** | **3** | **27** | **56** | **630** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (25 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8264 |  | search_blocks |
| GLOBlit_105 |  | search_blocks |
| GLOBlit_379 |  | search_blocks |
| GLOBlit_618 |  | search_blocks |
| GLOBlit_2499 |  | search_blocks |
| GLOBlit_2526 |  | search_blocks |
| GLOBlit_2831 |  | search_blocks |
| GLOBlit_3774 |  | search_blocks |
| GLOBlit_3983 |  | search_blocks |
| GLOBlit_4125 |  | search_blocks |
| GLOBlit_4207 |  | search_blocks |
| GLOBlit_4467 |  | search_blocks |
| GLOBlit_4814 |  | search_blocks |
| GLOBlit_6517 |  | search_blocks |
| GLOBlit_6823 |  | search_blocks |
| GLOBlit_7259 |  | search_blocks |
| GLOBlit_7414 |  | search_blocks |
| GLOBlit_8285 |  | search_blocks |
| GLOBlit_8298 |  | search_blocks |
| GLOBlit_8423 |  | search_blocks |
| GLOBlit_8448 |  | search_blocks |
| GLOBlit_8549 |  | search_blocks |
| GLOBlit_8658 |  | search_blocks |
| GLOBlit_8790 |  | search_blocks |
| GLOBlit_9239 |  | search_blocks |

#### Compounds (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_146 | 4-methyl-1,3-dioxolan-2-one | search_blocks |
| GLOBcomp_708 | ethyl methyl carbonate | search_blocks |
| GLOBcomp_62 | dimethyl carbonate | search_blocks |
| GLOBcomp_312 | ethylene carbonate | search_blocks |
| GLOBcomp_103 | diethyl carbonate | search_blocks |

#### Properties (16 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBprop_12 |  | resolve_property_ids, search_blocks |
| GLOBprop_26 |  | resolve_property_ids |
| GLOBprop_38 |  | resolve_property_ids |
| GLOBprop_89 |  | resolve_property_ids |
| GLOBprop_91 |  | resolve_property_ids |
| GLOBprop_16 |  | resolve_property_ids |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks |
| GLOBprop_8 | Speed of sound, m/s | search_blocks |
| GLOBprop_83 | Self diffusion coefficient, m2/s | search_blocks |
| GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBprop_14 | Boiling temperature at pressure P, K | search_blocks |
| GLOBprop_10 | Molar enthalpy of transition or fusion, kJ/mol | search_blocks |

#### Measurements (26 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_230 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBmeas_243 | Normal melting temperature, K | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_23 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_147 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks |
| GLOBmeas_143 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_33 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_5 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_82 | Self diffusion coefficient, m2/s | search_blocks |
| GLOBmeas_57 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_269 | Molar enthalpy of transition or fusion, kJ/mol | search_blocks |
| GLOBmeas_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_153 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_171 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks |
| GLOBmeas_835 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_12 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_277 | Speed of sound, m/s | search_blocks |

#### Phases (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |
| GLOBphase_2 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 25 |
| Unique Compounds | 5 |
| Unique Properties | 16 |
| Unique Measurements | 26 |
| Unique Phases | 2 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Total DOIs | 25 |
| Unique parent blocks | 55 |
| Explicit block/subsystem targets | 55 |
| Subsystem targets | 0 |
| Target-matched data points | 630 |

---

## 3. DOI & Block References

**Unique DOIs:** 25  |  **Parent blocks:** 55  |  **Explicit targets:** 55  |  **Subsystems:** 0  |  **Target-matched datapoints:** 629

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-010-0860-3 | 2 | 6 | unary | search_blocks |
| 10.1016/j.fluid.2006.04.001 | 2 | 4 | unary | search_blocks |
| 10.1016/j.fluid.2008.03.013 | 1 | 18 | unary | search_blocks |
| 10.1016/j.jct.2005.01.017 | 1 | 8 | unary | search_blocks |
| 10.1016/j.jct.2005.03.019 | 2 | 9 | unary | search_blocks |
| 10.1016/j.jct.2007.05.010 | 2 | 2 | unary | search_blocks |
| 10.1016/j.jct.2012.11.020 | 2 | 16 | unary | search_blocks |
| 10.1016/j.jct.2013.08.034 | 2 | 16 | unary | search_blocks |
| 10.1016/j.jct.2014.02.021 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2014.07.004 | 1 | 6 | unary | search_blocks |
| 10.1016/j.jct.2015.08.013 | 1 | 6 | unary | search_blocks |
| 10.1016/j.jct.2016.09.008 | 2 | 2 | unary | search_blocks |
| 10.1021/acs.jced.5b00064 | 2 | 2 | unary | search_blocks |
| 10.1021/acs.jced.6b00021 | 2 | 79 | unary | search_blocks |
| 10.1021/acs.jced.7b00578 | 2 | 91 | unary | search_blocks |
| 10.1021/acs.jced.7b01107 | 2 | 2 | unary | search_blocks |
| 10.1021/je034134e | 9 | 251 | binary, unary | search_blocks |
| 10.1021/je034173q | 2 | 29 | unary | search_blocks |
| 10.1021/je034204h | 2 | 2 | unary | search_blocks |
| 10.1021/je0496903 | 2 | 10 | unary | search_blocks |
| 10.1021/je0497395 | 2 | 2 | unary | search_blocks |
| 10.1021/je049950g | 1 | 25 | unary | search_blocks |
| 10.1021/je050183a | 4 | 7 | unary | search_blocks |
| 10.1021/je050444g | 4 | 33 | unary | search_blocks |
| 10.1021/je1005483 | 2 | 2 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-010-0860-3 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1007/s10765-010-0860-3 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.04.001 | PROPblock_1 | declared | 2 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.04.001 | PROPblock_2 | declared | 2 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.03.013 | PROPblock_3 | declared | 18 | unary | — | search_blocks |
| 10.1016/j.jct.2005.01.017 | PROPblock_1 | declared | 8 | unary | — | search_blocks |
| 10.1016/j.jct.2005.03.019 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2005.03.019 | PROPblock_2 | declared | 8 | unary | — | search_blocks |
| 10.1016/j.jct.2007.05.010 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2007.05.010 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2012.11.020 | PROPblock_1 | declared | 8 | unary | — | search_blocks |
| 10.1016/j.jct.2012.11.020 | PROPblock_2 | declared | 8 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.034 | PROPblock_4 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.034 | PROPblock_5 | declared | 9 | unary | — | search_blocks |
| 10.1016/j.jct.2014.02.021 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2014.07.004 | PROPblock_2 | declared | 6 | unary | — | search_blocks |
| 10.1016/j.jct.2015.08.013 | PROPblock_3 | declared | 6 | unary | — | search_blocks |
| 10.1016/j.jct.2016.09.008 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2016.09.008 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00064 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00064 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.6b00021 | PROPblock_14 | declared | 12 | unary | — | search_blocks |
| 10.1021/acs.jced.6b00021 | PROPblock_15 | declared | 67 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00578 | PROPblock_7 | declared | 70 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00578 | PROPblock_8 | declared | 21 | unary | — | search_blocks |
| 10.1021/acs.jced.7b01107 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.7b01107 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_18 | declared | 1 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_19 | declared | 1 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_20 | declared | 140 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_21 | declared | 55 | unary | — | search_blocks |
| 10.1021/je034134e | PROPblock_25 | declared | 13 | binary | — | search_blocks |
| 10.1021/je034134e | PROPblock_40 | declared | 16 | binary | — | search_blocks |
| 10.1021/je034134e | PROPblock_41 | declared | 2 | binary | — | search_blocks |
| 10.1021/je034134e | PROPblock_45 | declared | 15 | binary | — | search_blocks |
| 10.1021/je034134e | PROPblock_47 | declared | 8 | binary | — | search_blocks |
| 10.1021/je034173q | PROPblock_3 | declared | 10 | unary | — | search_blocks |
| 10.1021/je034173q | PROPblock_4 | declared | 19 | unary | — | search_blocks |
| 10.1021/je034204h | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1021/je034204h | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0496903 | PROPblock_3 | declared | 5 | unary | — | search_blocks |
| 10.1021/je0496903 | PROPblock_4 | declared | 5 | unary | — | search_blocks |
| 10.1021/je0497395 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0497395 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1021/je049950g | PROPblock_1 | declared | 25 | unary | — | search_blocks |
| 10.1021/je050183a | PROPblock_13 | declared | 1 | unary | — | search_blocks |
| 10.1021/je050183a | PROPblock_14 | declared | 2 | unary | — | search_blocks |
| 10.1021/je050183a | PROPblock_15 | declared | 2 | unary | — | search_blocks |
| 10.1021/je050183a | PROPblock_16 | declared | 2 | unary | — | search_blocks |
| 10.1021/je050444g | PROPblock_10 | declared | 2 | unary | — | search_blocks |
| 10.1021/je050444g | PROPblock_11 | declared | 2 | unary | — | search_blocks |
| 10.1021/je050444g | PROPblock_12 | declared | 2 | unary | — | search_blocks |
| 10.1021/je050444g | PROPblock_9 | declared | 27 | unary | — | search_blocks |
| 10.1021/je1005483 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1021/je1005483 | PROPblock_5 | declared | 1 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_blocks` | compound=GLOBcomp_146, limit=50, property=GLOBprop… | 874 | DISCARD ←in 39 | 816 | 15.6 |
| 2 | 2 | `search_blocks` | compound=GLOBcomp_146, limit=50, property=GLOBprop… | 651 | KEEP ←in 7,698 | 621 | 17.4 |
| 3 | 2 | `resolve_property_ids` | limit=20, min_score=40, purpose=Find alternative p… | 529 | KEEP ←in 689 | 529 | 7.7 |
| 4 | 3 | `search_blocks` | compound=GLOBcomp_146, limit=50, property=GLOBprop… | 645 | KEEP ←in 1,022 | 630 | 8.8 |
| 5 | 3 | `search_blocks` | compound=GLOBcomp_146, limit=50, property=GLOBprop… | 814 | DISCARD ←in 39 | 756 | 8.9 |
| 6 | 3 | `search_blocks` | compound=GLOBcomp_146, limit=50, purpose=Find all … | 967 | KEEP ←in 26,502 | 847 | 15.5 |
| 7 | 4 | `inspect_block_table` | block_number=PROPblock_19, literature=GLOBlit_8264… | 618 | — | — | 0.1 |
| 8 | 1 | `L1_query` | context=PC = GLOBcomp_146, formula C4…, id_catalog… | 6,412 | — | — | 131.4 |
| | | **TOTAL (8 tools)** | | **11,510** | | **4,199** | **205.4** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 853 | 12,434 | 1,320 | 8.2 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,321 | 25,461 | 737 | 5.1 |
| 3 | L1-worker | claudeopus46 | 3,767 | 480 | 4,247 | 1,244 | 8.7 |
| 4 | L1-worker | claudeopus46 | 24,140 | 2,695 | 26,835 | 1,335 | 7.9 |
| 5 | L1-worker | claudeopus46 | 3,767 | 8,070 | 11,837 | 2,109 | 15.5 |
| 6 | L1-worker | claudeopus46 | 3,767 | 875 | 4,642 | 1,137 | 6.9 |
| 7 | L1-worker | claudeopus46 | 24,140 | 4,617 | 28,757 | 1,381 | 6.8 |
| 8 | L1-worker | claudeopus46 | 3,767 | 1,351 | 5,118 | 907 | 6.8 |
| 9 | L1-worker | claudeopus46 | 3,767 | 401 | 4,168 | 947 | 7.4 |
| 10 | L1-worker | claudeopus46 | 3,767 | 26,857 | 30,624 | 1,693 | 14.2 |
| 11 | L1-worker | claudeopus46 | 24,140 | 7,906 | 32,046 | 1,264 | 10.5 |
| 12 | L1-worker | claudeopus46 | 24,140 | 9,102 | 33,242 | 1,320 | 9.8 |
| 13 | L1-worker | claudeopus46 | 24,140 | 13,201 | 37,341 | 1,166 | 5.1 |
| 14 | L1-worker | claudeopus46 | 2,543 | 2,739 | 5,282 | 523 | 3.3 |
| 15 | L1-worker | claudeopus46 | 2,320 | 1,297 | 3,617 | 678 | 3.6 |
| 16 | L1-worker | claudeopus46 | 627 | 1,177 | 1,804 | 777 | 4.3 |
| 17 | L1-worker | claudeopus46 | 787 | 7,021 | 7,808 | 539 | 5.9 |
| 18 | L0-main | claudeopus46 | 11,581 | 9,144 | 20,725 | 2,152 | 12.1 |
| 19 | L0-main | claudeopus46 | 2,320 | 1,935 | 4,255 | 521 | 3.4 |
| 20 | L0-main | claudeopus46 | 2,543 | 2,620 | 5,163 | 524 | 4.2 |
| 21 | L0-main | claudeopus46 | 1,156 | 2,739 | 3,895 | 353 | 3.0 |
| 22 | verdict | claudeopus46 | 972 | 3,866 | 4,838 | 1,010 | 7.9 |

