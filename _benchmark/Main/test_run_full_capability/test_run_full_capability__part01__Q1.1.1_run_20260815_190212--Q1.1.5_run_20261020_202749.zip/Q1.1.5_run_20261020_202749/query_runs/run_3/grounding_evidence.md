# Data grounding evidence

- generated: 2026-10-20T20:33:19
- gate verdict: 4 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_19 | GLOBlit_8264 | yes | INSP_692ba020dacf | 1 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 220.3 | PROPblock_19 | verified | — |
| 1.0 | PROPblock_19 | verified | — |
| 1.0 | PROPblock_19 | verified | — |
| 220.3 | PROPblock_19 | verified | — |
| -52.9 | PROPblock_19 | ungrounded | — |
| 218 | PROPblock_19 | ungrounded | — |
| 224 | PROPblock_19 | ungrounded | — |
| 309 | PROPblock_19 | ungrounded | — |

## Violations

- **UNGROUNDED_LITERAL** PROPblock_19: -52.9 (near '…r.  ### Chemistry context  The reported value of 220.3 K (≈ …') matches no inspected row/stat, database table, or other source of PROPblock_19
- **UNGROUNDED_LITERAL** PROPblock_19: 218 (near '…is consistent with the commonly cited literature range of ~2…') matches no inspected row/stat, database table, or other source of PROPblock_19
- **UNGROUNDED_LITERAL** PROPblock_19: 224 (near '…consistent with the commonly cited literature range of ~218–…') matches no inspected row/stat, database table, or other source of PROPblock_19
- **UNGROUNDED_LITERAL** PROPblock_19: 309 (near '…ompared to the symmetric ethylene carbonate (melting point ~…') matches no inspected row/stat, database table, or other source of PROPblock_19

## Inspections (verbatim)

### INSP_692ba020dacf — GLOBlit_8264::PROPblock_19 (complete, 1 rows shown)

_structured envelope entry (no markdown)_
