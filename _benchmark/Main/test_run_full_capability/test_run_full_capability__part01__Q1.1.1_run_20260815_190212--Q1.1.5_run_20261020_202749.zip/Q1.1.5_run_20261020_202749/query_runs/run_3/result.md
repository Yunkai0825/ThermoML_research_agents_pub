# Delegated query run — result

**Question:** Find pure-component melting temperature (or normal melting point, fusion temperature, SLE temperature at x=1 or x=0) data for propylene carbonate (GLOBcomp_146, 4-methyl-1,3-dioxolan-2-one). Report all blocks with temperatures, uncertainties, and DOIs.

**Iterations:** 2  |  **Elapsed:** 152.1s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Pure-Component Melting Temperature of Propylene Carbonate

The ThermoML database contains **one** pure-component melting temperature measurement for propylene carbonate (4-methyl-1,3-dioxolan-2-one, C₄H₆O₃):

| Source (DOI) | Block | Value (K) | Uncertainty | Method |
|---|---|---|---|---|
| 10.1021/je034134e | PROPblock_19 | **220.3** | ±1.0 K (expanded, 95% confidence) | Differential Thermal Analysis (DTA) |

### Details

- **Compound:** Propylene carbonate (4-methyl-1,3-dioxolan-2-one; InChIKey RUOJZAUFBMNUDX-UHFFFAOYSA-N)
- **Property:** Normal melting temperature (crystal → liquid transition)
- **Conditions:** Atmospheric pressure (1 atm, air)
- **Uncertainty:** The expanded combined uncertainty of 1.0 K at the 95% confidence level was evaluated by the data file compiler.

### Chemistry context

The reported value of 220.3 K (≈ −52.9 °C) is consistent with the commonly cited literature range of ~218–224 K for propylene carbonate. PC's relatively low melting point for a cyclic carbonate reflects the asymmetry introduced by the methyl substituent on the 1,3-dioxolan-2-one ring, which disrupts crystal packing compared to the symmetric ethylene carbonate (melting point ~309 K). This low melting point is one reason propylene carbonate is widely used as a liquid solvent in lithium-ion battery electrolytes and industrial applications even at sub-ambient temperatures.

### Additional notes

- **No triple point temperature** data for propylene carbonate was found in the database.
- Binary solid–liquid equilibrium (liquidus) data for propylene carbonate with co-solvents (e.g., ethyl methyl carbonate) exist in the same reference, but those blocks report the mixture SLE curve rather than the pure-component melting point.

### Core claims

- The ThermoML database contains one pure-component melting temperature measurement for propylene carbonate (4-methyl-1,3-dioxolan-2-one), reported as 220.3 K with an expanded combined uncertainty of ±1.0 K at the 95% confidence level, from DOI 10.1021/je034134e.
- The measurement was obtained by Differential Thermal Analysis (DTA) at atmospheric pressure.
- No triple point temperature data for propylene carbonate was found in the database.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_19 |  | This block provides the sole pure-component normal melting temperature of propylene carbonate (220.3 K with ±1.0 K expanded uncertainty via DTA), which is the central datum reported in the answer. |

### Suggested follow-ups

- Search for triple point temperature data for propylene carbonate in additional ThermoML sources.
- Compare with binary SLE data in the same reference (10.1021/je034134e) to verify consistency of the pure-component endpoint.
- Cross-check against other databases (e.g., NIST WebBook) for additional pure-component melting point measurements of propylene carbonate.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "prop",
    "global_id": "GLOBprop_12",
    "registry_id": "normal_melting_temperature_k",
    "name": "Normal melting temperature, K"
  }
]
```

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1021/je034134e",
    "block_number": "PROPblock_19",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "normal_melting_temperature_k",
      "normal_melting_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "normal_melting_temperature_k": "220.3",
        "normal_melting_temperature_k_U": "1"
      }
    ],
    "inspection_id": "INSP_692ba020dacf",
    "lit_num_id": "GLOBlit_8264"
  }
]
```
