# Answer

**Question:** Using ThermoML, which binary mixtures of ethylene carbonate, dimethyl carbonate and propylene carbonate remain liquid at 253.15 K, and over what composition range? Report the pure-component melting temperatures and the eutectic temperatures with their uncertainties and sources, and say what the data cannot determine.

**[run statistics removed]**

---

## Answer

## Binary Carbonate Mixtures: Liquid Ranges at 253.15 K

### Pure-Component Melting Temperatures

| Compound | T_melt (K) | U (K) | Source | Block |
|---|---|---|---|---|
| **Ethylene carbonate (EC)** | 308.53 | 0.21 | GLOBlit_2959 / DOI: 10.1016/j.jct.2008.05.012 | PROPblock_6 |
| **Dimethyl carbonate (DMC)** | 278.16 | 0.16 | GLOBlit_1484 / DOI: 10.1016/j.fluid.2014.05.033 | PROPblock_4 |
| **Propylene carbonate (PC)** | 220.3 | 1.0 | GLOBlit_8264 / DOI: 10.1021/je034134e | PROPblock_19 |

These are the most precise values available in ThermoML for each compound. EC has six independent measurements in the database (range 308.53–314.45 K); DMC has eight (range 277.06–278.2 K); PC has only one. All are normal melting temperatures at atmospheric pressure; uncertainties are expanded combined uncertainties at the 95 % confidence level.

All three binary SLE (liquidus) datasets come from a single source: **Ding et al. (2004)**, DOI 10.1021/je034134e (GLOBlit_8264), measured by differential thermal analysis (DTA) at 101.3 kPa with U = 2.0 K (95 % confidence).

---

### 1. Ethylene Carbonate + Dimethyl Carbonate — **Entirely solid at 253.15 K**

The EC + DMC system forms a simple eutectic. Two liquidus branches were measured:

- **DMC-rich branch** (PROPblock_34, 11 points): x(EC) = 0 to 0.2768, T = 278.2 down to 265.3 K
- **EC-rich branch** (PROPblock_33, 14 points): x(EC) = 0.3478 to 1.0, T = 268.4 up to 311.2 K

The eutectic lies in the unmeasured gap between x(EC) ≈ 0.28 and 0.35. The lowest measured liquidus temperatures bounding the eutectic are 265.3 ± 2.0 K at x(EC) = 0.2768 (PROPblock_34) and 268.4 ± 2.0 K at x(EC) = 0.3478 (PROPblock_33). The eutectic temperature is therefore approximately **265–268 K**, which is well above 253.15 K. Below the eutectic the system is completely solid, so **no composition of EC + DMC remains liquid at 253.15 K**.

---

### 2. Dimethyl Carbonate + Propylene Carbonate — **Liquid over a wide range**

This system also forms a simple eutectic:

- **DMC-rich branch** (PROPblock_40, 16 points): x(DMC) = 0.2499 to 1.0, T = 225.4 to 277.2 K
- **PC-rich branch** (PROPblock_41, 2 points): x(DMC) = 0.1678 at 211.6 K and x(DMC) = 0.1998 at 217.2 K

The eutectic lies between x(DMC) ≈ 0.17 and 0.25, at a temperature **below 211.6 K** — well below 253.15 K. Pure PC melts at 220.3 K, also far below 253.15 K.

The inspected rows of PROPblock_40 nearest to 253.15 K are:

| BLKpoint | x(DMC) | T_SLE (K) | U (K) |
|---|---|---|---|
| BLKpoint_6 | 0.5011 | 250.5 | 2 |
| BLKpoint_7 | 0.5521 | 254.6 | 2 |

Since 250.5 K < 253.15 K < 254.6 K, linear interpolation between these two inspected rows gives the liquidus crossing at approximately x(DMC) ≈ 0.53 (derived: 0.5011 + (253.15 − 250.5)/(254.6 − 250.5) × (0.5521 − 0.5011)).

**Result:** The DMC + PC mixture is liquid at 253.15 K for all compositions from **pure PC [x(DMC) = 0] up to approximately x(DMC) ≈ 0.53** (x(PC) ≈ 0.47). Above x(DMC) ≈ 0.53, solid DMC begins to crystallise.

---

### 3. Ethylene Carbonate + Propylene Carbonate — **Liquid on the PC-rich side**

Only the EC-rich liquidus branch is available (PROPblock_45, 15 points), covering x(EC) = 0.3001 to 1.0, T = 253.6 to 311.2 K. The lowest measured liquidus temperature is **253.6 ± 2.0 K at x(EC) = 0.3001**.

Since pure PC melts at 220.3 K (well below 253.15 K), the mixture is liquid at 253.15 K from pure PC up to approximately **x(EC) ≈ 0.30**, where the EC-rich liquidus just crosses the target temperature (the lowest measured point at x(EC) = 0.3001 has T = 253.6 K, only 0.45 K above 253.15 K).

**Result:** The EC + PC mixture is liquid at 253.15 K for compositions from **pure PC [x(EC) = 0] up to approximately x(EC) ≈ 0.30** (x(PC) ≈ 0.70).

---

### Summary Table

| Binary system | Eutectic T (K) | Liquid at 253.15 K? | Liquid composition range at 253.15 K |
|---|---|---|---|
| EC + DMC | ~265–268 (> 253.15 K) | **No** — entirely solid | None |
| DMC + PC | < 211.6 (≪ 253.15 K) | **Yes** | x(DMC) = 0 to ~0.53 |
| EC + PC | Not determined (< 253.6 K) | **Yes** | x(EC) = 0 to ~0.30 |

---

### What the Data Cannot Determine

1. **EC + PC eutectic temperature and composition:** The PC-rich liquidus branch was not measured. Only the EC-rich branch (x(EC) ≥ 0.30) is available. The eutectic temperature is constrained to lie between 220.3 K (pure PC melting point) and 253.6 K (lowest measured liquidus point) but cannot be pinpointed. The eutectic composition is unknown beyond x(EC) < 0.30.

2. **DMC + PC eutectic temperature (precise):** Only two points exist on the PC-rich branch (211.6 K and 217.2 K). The eutectic temperature is constrained to be below 211.6 K but is not directly measured. The eutectic composition is bounded between x(DMC) ≈ 0.17 and 0.25 but not pinpointed.

3. **EC + DMC eutectic (precise):** The eutectic falls in the unmeasured gap x(EC) ≈ 0.28–0.35. Its temperature is bounded between 265.3 and 268.4 K but not directly measured.

4. **Solid-phase identity:** The DTA method reports liquidus temperatures but does not characterise the solid phases (polymorphs, solid solutions, or solvates). The data assume simple eutectic behaviour with no solid miscibility.

5. **Composition precision at 253.15 K:** The upper composition limits for the liquid region in EC + PC and DMC + PC at exactly 253.15 K are derived by interpolation between measured points spaced ~0.05 in mole fraction, so they carry an uncertainty of at least ±0.02–0.03 in mole fraction in addition to the ±2 K temperature uncertainty.

6. **Single data source for binary SLE:** All binary SLE data originate from a single publication (Ding et al., DOI 10.1021/je034134e). No independent verification from other ThermoML sources is available for any of the three binary liquidus curves.

---

### Sources

- Literature ID: GLOBlit_8264 | DOI: 10.1021/je034134e | Blocks: PROPblock_33 & PROPblock_34 (EC+DMC SLE); PROPblock_40 & PROPblock_41 (DMC+PC SLE); PROPblock_45 (EC+PC SLE); PROPblock_19 (PC melting)
- Literature ID: GLOBlit_2959 | DOI: 10.1016/j.jct.2008.05.012 | Block: PROPblock_6 | EC melting (308.53 ± 0.21 K)
- Literature ID: GLOBlit_1484 | DOI: 10.1016/j.fluid.2014.05.033 | Block: PROPblock_4 | DMC melting (278.16 ± 0.16 K)





















### Core claims

- At 253.15 K, the EC + DMC binary system is entirely solid because its eutectic temperature (~265–268 K) lies well above 253.15 K; no composition remains liquid.
- At 253.15 K, the DMC + PC binary system is liquid from pure PC [x(DMC) = 0] up to approximately x(DMC) ≈ 0.53, above which solid DMC crystallises; the eutectic temperature is below 211.6 K.
- At 253.15 K, the EC + PC binary system is liquid from pure PC [x(EC) = 0] up to approximately x(EC) ≈ 0.30, where the lowest measured EC-rich liquidus point is 253.6 ± 2.0 K at x(EC) = 0.3001.
- All binary SLE liquidus data originate from a single source (Ding et al., DOI 10.1021/je034134e, DTA at 101.3 kPa, U = 2.0 K at 95 % confidence), with no independent ThermoML verification available.
- The upper mole-fraction limits for the liquid region in DMC + PC and EC + PC at 253.15 K are interpolated between measured points spaced ~0.05 in mole fraction and carry uncertainty of at least ±0.02–0.03 in mole fraction.
- Pure-component melting temperatures used are EC = 308.53 ± 0.21 K, DMC = 278.16 ± 0.16 K, and PC = 220.3 ± 1.0 K.
- The EC + PC eutectic temperature and composition are not determined; the eutectic temperature is constrained between 220.3 K and 253.6 K, and the eutectic composition is only bounded to x(EC) < 0.30.


**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2959 | 10.1016/j.jct.2008.05.012 | PROPblock_6 |  | Provides the normal melting temperature of ethylene carbonate (308.53 K), used as a pure-component reference point for assessing the EC+DMC and EC+PC phase diagrams relative to 253.15 K. |
| GLOBlit_1484 | 10.1016/j.fluid.2014.05.033 | PROPblock_4 |  | Provides the normal melting temperature of dimethyl carbonate (278.16 K), used as a pure-component reference point for assessing the DMC-containing binary phase diagrams relative to 253.15 K. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_19 |  | Provides the normal melting temperature of propylene carbonate (220.3 K), establishing that pure PC is liquid at 253.15 K and serving as a reference for the PC-containing binary systems. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_33 |  | Provides the EC-rich liquidus branch of the EC+DMC binary SLE (14 points, x(EC) 0.3478–1.0, T 268.4–311.2 K), used to bound the eutectic temperature from above and conclude that the entire EC+DMC system is solid at 253.15 K. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_34 |  | Provides the DMC-rich liquidus branch of the EC+DMC binary SLE (11 points, x(EC) 0.0–0.2768, T 265.3–278.2 K), used to bound the eutectic temperature from the DMC side and confirm the eutectic is ~265–268 K, above 253.15 K. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_40 |  | Provides the DMC-rich liquidus branch of the DMC+PC binary SLE (16 points, x(DMC) 0.2499–1.0, T 225.4–277.2 K), used to interpolate the liquidus crossing at 253.15 K and determine the upper liquid composition limit at approximately x(DMC) ≈ 0.53. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_41 |  | Provides the PC-rich liquidus branch of the DMC+PC binary SLE (2 points, x(DMC) 0.1678–0.1998, T 211.6–217.2 K), used to establish that the eutectic temperature is below 211.6 K and that the PC-rich side is entirely liquid at 253.15 K. |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_45 |  | Provides the EC-rich liquidus branch of the EC+PC binary SLE (15 points, x(EC) 0.3001–1.0, T 253.6–311.2 K), used to determine that the liquidus crosses 253.15 K near x(EC) ≈ 0.30 and that compositions below this are liquid at 253.15 K. |

---

<!-- END OF REVIEW COPY. Later generated run appendices are separate execution evidence. -->
