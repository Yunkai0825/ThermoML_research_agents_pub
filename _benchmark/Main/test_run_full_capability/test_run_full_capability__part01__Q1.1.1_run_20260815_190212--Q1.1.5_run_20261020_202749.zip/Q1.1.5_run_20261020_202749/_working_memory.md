# Working Memory

**ROOT:** `N:\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Main\test_run_r1_1_20261020\Q1.1.5_run_20261020_202749`

### History
- [menu:browse] {'text': "I need to explore the submenus to see the actual t
- [menu:run] resolve_compound_ids → OK
- [menu:run] resolve_compound_ids → OK
- [parallel:6 tasks]
-   [query:pure_melting_EC] "Find pure-component melting temperature (or normal melting point, fusion tempera" (244s, 2 iters, validation=PASS verdict=## Verdict
No significant gaps)
-   [query:pure_melting_DMC] "Find pure-component melting temperature (or normal melting point, fusion tempera" (262s, 2 iters, validation=PASS verdict=## Verdict
The answer is compr)
-   [query:pure_melting_PC] "Find pure-component melting temperature (or normal melting point, fusion tempera" (152s, 2 iters, validation=PASS verdict=## Verdict
The answer appears )
-   [query:SLE_EC_DMC] "Find solid-liquid equilibrium (SLE), liquidus, freezing point, or fusion tempera" (149s, 2 iters, validation=PASS verdict=## Verdict
The answer appears )
-   [query:SLE_EC_PC] "Find solid-liquid equilibrium (SLE), liquidus, freezing point, or fusion tempera" (132s, 2 iters, validation=PASS verdict=## Verdict
The answer appears )
-   [query:SLE_DMC_PC] "Find solid-liquid equilibrium (SLE), liquidus, freezing point, or fusion tempera" (161s, 2 iters, validation=PASS verdict=## Verdict
The answer appears )
- [parallel:auto-compacted] 6 per-task reports (agentic, targets ALL, philosophy elicited)
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → ERROR: nearest must be {"column": alias, "value": number, "k": 1..8}
- [menu:run] inspect_block_table → ERROR: nearest must be {"column": alias, "value": number, "k": 1..8}
- [menu:run] inspect_block_table → ERROR: nearest must be {"column": alias, "value": number, "k": 1..8}
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → ERROR: nearest must be {"column": alias, "value": number, "k": 1..8}
- [menu:run] inspect_block_table → ERROR: nearest column error: unknown column alias 'Temperature'
- [menu:run] inspect_block_table → ERROR: nearest column error: unknown column alias 'Temperature'
- [menu:run] inspect_block_table → ERROR: nearest column error: unknown column alias 'Temperature'
- [menu:run] inspect_block_table → ERROR: nearest column error: unknown column alias 'Temperature'
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → ERROR: nearest column error: unknown column alias 'prop'
- [menu:run] inspect_block_table → ERROR: nearest column error: unknown column alias 'prop'
- [menu:run] inspect_block_table → ERROR: nearest column error: unknown column alias 'prop'
- [menu:run] inspect_block_table → ERROR: nearest column error: unknown column alias 'prop'
- [menu:run] inspect_block_table → ERROR: nearest column error: unknown column alias 'prop'
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK

### Query Agent Results

#### pure_melting_EC
**pure_melting_EC** — confidence: high · validation: PASS

**Answer:**

#### Pure-Component Melting Temperature of Ethylene Carbonate

Ethylene carbonate (C₃H₄O₃, CAS 96-49-1) has **six independent measurements** of the **normal melting temperature** (crystal → liquid transition) reported in the ThermoML database. All uncertainties are expanded combined uncertainties (U) at the 95% confidence level.

##### Normal Melting Temperature

**WM_Q#3_Table#1_(Main_Q#3_Answer):**

| *row_id* | *#* | *DOI* | *Literature ID* | *Block* | *T_melt (K)* | *±U (K)* | *Method* |
|---|---|---|---|---|---|---|---|
| WM_Q#3_Table#1_Row#1 | 「1」 | 「10.1016/j.fluid.2018.05.033」 | 「GLOBlit_2207」 | 「PROPblock_9」 | 「310.56」 | 「0.77」 | 「Phase equilibration」 |
| WM_Q#3_Table#1_Row#2 | 「2」 | 「10.1016/j.jct.2008.05.012」 | 「GLOBlit_2959」 | 「PROPblock_6」 | 「308.53」 | 「0.21」 | 「Heating/cooling curves」 |
| WM_Q#3_Table#1_Row#3 | 「3」 | 「10.1016/j.tca.2016.09.007」 | 「GLOBlit_6343」 | 「PROPblock_1」 | 「311.15」 | 「1」 | 「DTA」 |
| WM_Q#3_Table#1_Row#4 | 「4」 | 「10.1021/acs.jced.5b00338」 | 「GLOBlit_6589」 | 「PROPblock_6」 | 「314.45」 | 「6」 | 「DTA」 |
| WM_Q#3_Table#1_Row#5 | 「5」 | 「10.1021/acs.jced.7b00578」 | 「GLOBlit_7259」 | 「PROPblock_1」 | 「309.13」 | 「0.7」 | 「DTA」 |
| WM_Q#3_Table#1_Row#6 | 「6」 | 「10.1021/je034134e」 | 「GLOBlit_8264」 | 「PROPblock_6」 | 「311.2」 | 「1」 | 「DTA」 |

**Key observations:**

- Five of the six values cluster tightly in the range **308.53–311.2 K**, consistent with the commonly cited melting point of ethylene carbonate (~309–311 K).
- The **most precise measurement** is **308.53 ± 0.21 K** (GLOBlit_2959, heating/cooling curve method).
- The value of **314.45 K** (GLOBlit_6589) carries a large uncertainty of ±6 K, so it is statistically consistent with the other measurements within its stated bounds.
- No data were found under GLOBprop_11 (solid–liquid equilibrium temperature) for pure ethylene carbonate; all melting temperature data are stored under GLOBprop_12 (normal melting temperature).

##### Molar Enthalpy of Fusion (bonus data)

Two of the above publications also report the **molar enthalpy of the crystal → liquid transition**:

**WM_Q#3_Table#2_(Main_Q#3_Answer):**

| *row_id* | *#* | *DOI* | *Literature ID* | *Block* | *ΔH_fus (kJ/mol)* | *±U (kJ/mol)* | *Method* |
|---|---|---|---|---|---|---|---|
| WM_Q#3_Table#2_Row#1 | 「1」 | 「10.1021/acs.jced.7b00578」 | 「GLOBlit_7259」 | 「PROPblock_2」 | 「13.5」 | 「0.7」 | 「DSC」 |
| WM_Q#3_Table#2_Row#2 | 「2」 | 「10.1021/je034134e」 | 「GLOBlit_8264」 | 「PROPblock_5」 | 「13.02」 | 「0.85」 | 「DSC」 |

The two enthalpy of fusion values (13.02 and 13.5 kJ/mol) are mutually consistent and originate from the same publications that report melting temperatures of 309.13 K and 311.2 K, respectively.

##### Chemistry context

Ethylene carbonate is a cyclic carbonate ester widely used as a high-permittivity co-solvent in lithium-ion battery electrolytes. Its relatively high melting point (~309–311 K, i.e., ~36–38 °C) means it is a solid at room temperature, which is why it is typically blended with lower-melting carbonates such as dimethyl carbonate or diethyl carbonate to form liquid electrolyte formulations. The moderate enthalpy of fusion (~13 kJ/mol) reflects the moderate intermolecular interactions (dipole–dipole and some ring-stacking) in the crystalline phase.

**Core claims:**
- Six independent ThermoML measurements of the normal melting temperature of ethylene carbonate (CAS 96-49-1) are reported, with five of six values clustering in the range 308.53–311.2 K.
- The most precise measurement is 308.53 ± 0.21 K (GLOBlit_2959, heating/cooling curve method).
- The outlying value of 314.45 K (GLOBlit_6589) carries a large uncertainty of ±6 K and is statistically consistent with the other measurements within its stated bounds.
- Two measurements of the molar enthalpy of fusion are reported: 13.5 ± 0.7 kJ/mol (GLOBlit_7259) and 13.02 ± 0.85 kJ/mol (GLOBlit_8264), which are mutually consistent.
- All melting temperature data are stored under GLOBprop_12 (normal melting temperature); no data were found under GLOBprop_11 (solid–liquid equilibrium temperature) for pure ethylene carbonate.

**Sources:**

**WM_Q#3_Table#3_(Main_Q#3_Sources):**

| *row_id* | *lit_num_id* | *block* | *doi* | *BLKsubsys_id* | *description* |
|---|---|---|---|---|---|
| WM_Q#3_Table#3_Row#1 | 「GLOBlit_2207」 | 「PROPblock_9」 | 「10.1016/j.fluid.2018.05.033」 | 「—」 | 「Provides a normal melting temperature of 310.56 K for pure ethylene carbonate via phase equilibration, directly supporting the answer's first table entry.」 |
| WM_Q#3_Table#3_Row#2 | 「GLOBlit_2959」 | 「PROPblock_6」 | 「10.1016/j.jct.2008.05.012」 | 「—」 | 「Provides the most precise normal melting temperature of 308.53 K for pure ethylene carbonate via heating/cooling curves, cited in the answer as the most precise measurement.」 |
| WM_Q#3_Table#3_Row#3 | 「GLOBlit_6343」 | 「PROPblock_1」 | 「10.1016/j.tca.2016.09.007」 | 「—」 | 「Provides a normal melting temperature of 311.15 K for pure ethylene carbonate via DTA, contributing to the answer's compilation of six independent measurements.」 |
| WM_Q#3_Table#3_Row#4 | 「GLOBlit_6589」 | 「PROPblock_6」 | 「10.1021/acs.jced.5b00338」 | 「—」 | 「Provides a normal melting temperature of 314.45 K for pure ethylene carbonate via DTA; the answer notes its large uncertainty of ±6 K makes it statistically consistent with the other values.」 |
| WM_Q#3_Table#3_Row#5 | 「GLOBlit_7259」 | 「PROPblock_1」 | 「10.1021/acs.jced.7b00578」 | 「—」 | 「Provides a normal melting temperature of 309.13 K for pure ethylene carbonate via DTA, one of the six independent measurements in the answer.」 |
| WM_Q#3_Table#3_Row#6 | 「GLOBlit_8264」 | 「PROPblock_6」 | 「10.1021/je034134e」 | 「—」 | 「Provides a normal melting temperature of 311.2 K for pure ethylene carbonate via DTA, contributing to the answer's compilation and consistent with the cluster of values around 309–311 K.」 |
| WM_Q#3_Table#3_Row#7 | 「GLOBlit_7259」 | 「PROPblock_2」 | 「10.1021/acs.jced.7b00578」 | 「—」 | 「Provides the molar enthalpy of fusion of 13.5 kJ/mol for pure ethylene carbonate via DSC, supporting the bonus enthalpy of fusion data in the answer.」 |
| WM_Q#3_Table#3_Row#8 | 「GLOBlit_8264」 | 「PROPblock_5」 | 「10.1021/je034134e」 | 「—」 | 「Provides the molar enthalpy of fusion of 13.02 kJ/mol for pure ethylene carbonate via DSC, supporting the bonus enthalpy of fusion data and showing consistency with the 13.5 kJ/mol value.」 |

**Follow-up suggestions:**
- Search for solid-liquid equilibrium (SLE) data of ethylene carbonate with common co-solvents (e.g., dimethyl carbonate, diethyl carbonate) to map the eutectic phase diagram relevant to battery electrolyte formulations.
- Compare the molar enthalpy of fusion (~13 kJ/mol) with values for structurally related cyclic carbonates such as propylene carbonate or vinylene carbonate.
- Investigate whether any ThermoML entries report heat capacity data (Cp) for crystalline and liquid ethylene carbonate near the melting point to enable thermodynamic consistency checks.

*Not stored here: 8 verbatim data_inspections table(s); 1 id_catalog_snapshot row(s) (catalog is merged separately). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


#### pure_melting_DMC
**pure_melting_DMC** — confidence: high · validation: PASS

**Answer:**

#### Pure-Component Melting Temperature of Dimethyl Carbonate (DMC)

**Compound:** Dimethyl carbonate (C₃H₆O₃, SMILES: COC(=O)OC)

The ThermoML database contains **8 independent measurements** of the melting (fusion) temperature of pure DMC, reported under two property definitions. All measurements were performed on pure (unary) systems at atmospheric pressure, observing the crystal-to-liquid phase transition. Uncertainties are at the 95% confidence level.

---

##### 1. Solid–Liquid Equilibrium Temperature (GLOBprop_11)

**WM_Q#1_Table#1_(Main_Q#1_Answer):**

| *row_id* | *DOI* | *Block* | *T_melt (K)* | *±U (K)* | *P (kPa)* | *Method* |
|---|---|---|---|---|---|---|
| WM_Q#1_Table#1_Row#1 | 「10.1016/j.fluid.2018.09.023 [GLOBlit_2251]」 | 「PROPblock_5」 | 「278.11」 | 「4」 | 「101」 | 「Visual observation」 |

##### 2. Normal Melting Temperature (GLOBprop_12)

**WM_Q#1_Table#2_(Main_Q#1_Answer):**

| *row_id* | *DOI* | *Block* | *T_melt (K)* | *±U (K)* | *Method* |
|---|---|---|---|---|---|
| WM_Q#1_Table#2_Row#1 | 「10.1016/j.fluid.2014.05.033 [GLOBlit_1484]」 | 「PROPblock_4」 | 「278.16」 | 「0.16」 | 「Visual observation」 |
| WM_Q#1_Table#2_Row#2 | 「10.1016/j.fluid.2014.09.024 [GLOBlit_1560]」 | 「PROPblock_4」 | 「278.2」 | 「0.4」 | 「Visual observation」 |
| WM_Q#1_Table#2_Row#3 | 「10.1016/j.fluid.2018.05.033 [GLOBlit_2207]」 | 「PROPblock_3」 | 「277.52」 | 「0.77」 | 「Phase equilibration」 |
| WM_Q#1_Table#2_Row#4 | 「10.1016/j.jct.2008.05.012 [GLOBlit_2959]」 | 「PROPblock_5」 | 「277.06」 | 「0.6」 | 「Heating/cooling curves」 |
| WM_Q#1_Table#2_Row#5 | 「10.1021/acs.jced.7b00295 [GLOBlit_7175]」 | 「PROPblock_1」 | 「277.57」 | 「0.7」 | 「DTA」 |
| WM_Q#1_Table#2_Row#6 | 「10.1021/je034134e [GLOBlit_8264]」 | 「PROPblock_10」 | 「278.2」 | 「1」 | 「DTA」 |
| WM_Q#1_Table#2_Row#7 | 「10.1021/je101199g [GLOBlit_9437]」 | 「PROPblock_4」 | 「278.16」 | 「0.62」 | 「Visual observation」 |

---

##### Summary & Chemistry Insight

- **Range:** 277.06 K to 278.2 K across all 8 measurements.
- **Most precise value:** **278.16 ± 0.16 K** from Shi & Jeon (DOI: 10.1016/j.fluid.2014.05.033 [GLOBlit_1484]), determined by visual observation.
- **Lowest value:** 277.06 ± 0.6 K (DOI: 10.1016/j.jct.2008.05.012 [GLOBlit_2959]), measured by heating/cooling curves.

The spread of ~1.1 K across studies is typical for organic carbonates with relatively low melting points. Visual-observation methods (4 of 8 measurements) tend to cluster near 278.1–278.2 K, while thermal-analysis methods (DTA, heating/cooling curves) and phase-equilibration approaches yield slightly lower values (277.06–277.57 K). This systematic difference likely reflects the sensitivity of thermal methods to sample purity and heating rate. DMC's melting point near 278 K (≈ 5 °C) is notably low for a carbonate ester, a consequence of its small, symmetric molecular structure that limits intermolecular packing efficiency despite the polar carbonate group.

**Core claims:**
- The ThermoML database contains 8 independent measurements of the melting temperature of pure dimethyl carbonate (COC(=O)OC), all performed on pure unary systems at atmospheric pressure, spanning a range of 277.06 K to 278.2 K.
- The most precise reported value is 278.16 ± 0.16 K (DOI: 10.1016/j.fluid.2014.05.033), determined by visual observation.
- Visual-observation methods (4 of 8 measurements) cluster near 278.1–278.2 K, while thermal-analysis methods (DTA, heating/cooling curves) and phase-equilibration approaches yield slightly lower values (277.06–277.57 K), a systematic difference likely reflecting sensitivity to sample purity and heating rate.
- The total spread of ~1.1 K across studies is typical for organic carbonates with relatively low melting points.

**Sources:**

**WM_Q#1_Table#3_(Main_Q#1_Sources):**

| *row_id* | *lit_num_id* | *block* | *doi* | *BLKsubsys_id* | *description* |
|---|---|---|---|---|---|
| WM_Q#1_Table#3_Row#1 | 「GLOBlit_2251」 | 「PROPblock_5」 | 「10.1016/j.fluid.2018.09.023」 | 「—」 | 「Provides a solid-liquid equilibrium temperature of 278.11 K for pure dimethyl carbonate measured by visual observation at 101 kPa, contributing one of the eight independent melting point measurements in the answer.」 |
| WM_Q#1_Table#3_Row#2 | 「GLOBlit_1484」 | 「PROPblock_4」 | 「10.1016/j.fluid.2014.05.033」 | 「—」 | 「Reports the most precise normal melting temperature of 278.16 K for pure dimethyl carbonate by visual observation, identified in the answer as the most precise value with ±0.16 K uncertainty.」 |
| WM_Q#1_Table#3_Row#3 | 「GLOBlit_1560」 | 「PROPblock_4」 | 「10.1016/j.fluid.2014.09.024」 | 「—」 | 「Provides a normal melting temperature of 278.2 K for pure dimethyl carbonate by visual observation, contributing to the cluster of visual-observation values near 278.1–278.2 K discussed in the answer.」 |
| WM_Q#1_Table#3_Row#4 | 「GLOBlit_2207」 | 「PROPblock_3」 | 「10.1016/j.fluid.2018.05.033」 | 「—」 | 「Reports a normal melting temperature of 277.52 K for pure dimethyl carbonate by phase equilibration, contributing one of the lower-valued measurements discussed in the answer's comparison of methods.」 |
| WM_Q#1_Table#3_Row#5 | 「GLOBlit_2959」 | 「PROPblock_5」 | 「10.1016/j.jct.2008.05.012」 | 「—」 | 「Reports the lowest normal melting temperature of 277.06 K for pure dimethyl carbonate by heating/cooling curves, establishing the lower bound of the 277.06–278.2 K range cited in the answer.」 |
| WM_Q#1_Table#3_Row#6 | 「GLOBlit_7175」 | 「PROPblock_1」 | 「10.1021/acs.jced.7b00295」 | 「—」 | 「Provides a normal melting temperature of 277.57 K for pure dimethyl carbonate by DTA, contributing to the thermal-analysis cluster of values discussed in the answer.」 |
| WM_Q#1_Table#3_Row#7 | 「GLOBlit_8264」 | 「PROPblock_10」 | 「10.1021/je034134e」 | 「—」 | 「Reports a normal melting temperature of 278.2 K for pure dimethyl carbonate by DTA, tying for the highest value in the reported range and contributing to the answer's compilation.」 |
| WM_Q#1_Table#3_Row#8 | 「GLOBlit_9437」 | 「PROPblock_4」 | 「10.1021/je101199g」 | 「—」 | 「Reports a normal melting temperature of 278.16 K for pure dimethyl carbonate by visual observation, corroborating the value from GLOBlit_1484 and contributing to the answer's eight independent measurements.」 |

**Follow-up suggestions:**
- Compare DMC melting point with other linear carbonates (diethyl carbonate, ethyl methyl carbonate) to assess structural effects on fusion temperature.
- Investigate whether any of the cited studies also report enthalpy of fusion for DMC, which would complement the melting temperature data.
- Check for SLE phase diagram data in binary DMC + solvent systems to see if the eutectic extrapolations are consistent with these pure-component melting points.

*Not stored here: 8 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


#### pure_melting_PC
**pure_melting_PC** — confidence: high · validation: PASS

**Answer:**

#### Pure-Component Melting Temperature of Propylene Carbonate

The ThermoML database contains **one** pure-component melting temperature measurement for propylene carbonate (4-methyl-1,3-dioxolan-2-one, C₄H₆O₃):

**WM_Q#2_Table#1_(Main_Q#2_Answer):**

| *row_id* | *Source (DOI)* | *Block* | *Value (K)* | *Uncertainty* | *Method* |
|---|---|---|---|---|---|
| WM_Q#2_Table#1_Row#1 | 「10.1021/je034134e」 | 「PROPblock_19」 | 「**220.3**」 | 「±1.0 K (expanded, 95% confidence)」 | 「Differential Thermal Analysis (DTA)」 |

##### Details

- **Compound:** Propylene carbonate (4-methyl-1,3-dioxolan-2-one; InChIKey RUOJZAUFBMNUDX-UHFFFAOYSA-N)
- **Property:** Normal melting temperature (crystal → liquid transition)
- **Conditions:** Atmospheric pressure (1 atm, air)
- **Uncertainty:** The expanded combined uncertainty of 1.0 K at the 95% confidence level was evaluated by the data file compiler.

##### Chemistry context

The reported value of 220.3 K (≈ −52.9 °C) is consistent with the commonly cited literature range of ~218–224 K for propylene carbonate. PC's relatively low melting point for a cyclic carbonate reflects the asymmetry introduced by the methyl substituent on the 1,3-dioxolan-2-one ring, which disrupts crystal packing compared to the symmetric ethylene carbonate (melting point ~309 K). This low melting point is one reason propylene carbonate is widely used as a liquid solvent in lithium-ion battery electrolytes and industrial applications even at sub-ambient temperatures.

##### Additional notes

- **No triple point temperature** data for propylene carbonate was found in the database.
- Binary solid–liquid equilibrium (liquidus) data for propylene carbonate with co-solvents (e.g., ethyl methyl carbonate) exist in the same reference, but those blocks report the mixture SLE curve rather than the pure-component melting point.

**Core claims:**
- The ThermoML database contains one pure-component melting temperature measurement for propylene carbonate (4-methyl-1,3-dioxolan-2-one), reported as 220.3 K with an expanded combined uncertainty of ±1.0 K at the 95% confidence level, from DOI 10.1021/je034134e.
- The measurement was obtained by Differential Thermal Analysis (DTA) at atmospheric pressure.
- No triple point temperature data for propylene carbonate was found in the database.

**Sources:**

**WM_Q#2_Table#2_(Main_Q#2_Sources):**

| *row_id* | *lit_num_id* | *block* | *doi* | *BLKsubsys_id* | *description* |
|---|---|---|---|---|---|
| WM_Q#2_Table#2_Row#1 | 「GLOBlit_8264」 | 「PROPblock_19」 | 「10.1021/je034134e」 | 「—」 | 「This block provides the sole pure-component normal melting temperature of propylene carbonate (220.3 K with ±1.0 K expanded uncertainty via DTA), which is the central datum reported in the answer.」 |

**Follow-up suggestions:**
- Search for triple point temperature data for propylene carbonate in additional ThermoML sources.
- Compare with binary SLE data in the same reference (10.1021/je034134e) to verify consistency of the pure-component endpoint.
- Cross-check against other databases (e.g., NIST WebBook) for additional pure-component melting point measurements of propylene carbonate.

*Not stored here: 1 verbatim data_inspections table(s); 1 id_catalog_snapshot row(s) (catalog is merged separately). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


#### SLE_EC_DMC
**SLE_EC_DMC** — confidence: high · validation: PASS

**Answer:**

#### Solid-Liquid Equilibrium (SLE) Data for Ethylene Carbonate (EC) + Dimethyl Carbonate (DMC)

**Source:** DOI 10.1021/je034134e (GLOBlit_8264)

The SLE temperatures for the EC + DMC binary system were measured by Differential Thermal Analysis (DTA) at a pressure of 101.3 kPa. The system exhibits a classic eutectic phase diagram, reported across two data blocks. All temperatures carry an expanded uncertainty of **U = 2.0 K** (95% confidence level).

---

##### DMC-Rich Liquidus Branch (PROPblock_34)

This branch covers the freezing point depression of DMC upon addition of EC, spanning x(EC) = 0 to 0.2768 (11 data points, complete):

**WM_Q#4_Table#1_(Main_Q#4_Answer):**

| *row_id* | *x(EC) (mole fraction, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_Q#4_Table#1_Row#1 | 「0.0000」 | 「278.2」 | 「2.0」 |
| WM_Q#4_Table#1_Row#2 | 「0.0501」 | 「274.8」 | 「2.0」 |
| WM_Q#4_Table#1_Row#3 | 「0.0770」 | 「273.6」 | 「2.0」 |
| WM_Q#4_Table#1_Row#4 | 「0.1011」 | 「272.7」 | 「2.0」 |
| WM_Q#4_Table#1_Row#5 | 「0.1258」 | 「271.6」 | 「2.0」 |
| WM_Q#4_Table#1_Row#6 | 「0.1515」 | 「270.7」 | 「2.0」 |
| WM_Q#4_Table#1_Row#7 | 「0.1761」 | 「269.4」 | 「2.0」 |
| WM_Q#4_Table#1_Row#8 | 「0.2013」 | 「268.8」 | 「2.0」 |
| WM_Q#4_Table#1_Row#9 | 「0.2246」 | 「267.3」 | 「2.0」 |
| WM_Q#4_Table#1_Row#10 | 「0.2489」 | 「266.4」 | 「2.0」 |
| WM_Q#4_Table#1_Row#11 | 「0.2768」 | 「265.3」 | 「2.0」 |

- **Pure DMC melting point:** 278.2 K (at x(EC) = 0)
- **Lowest T on this branch:** 265.3 K at x(EC) = 0.2768

---

##### EC-Rich Liquidus Branch (PROPblock_33)

This branch covers the freezing point depression of EC upon addition of DMC, spanning x(EC) = 0.3478 to 1.0 (14 data points total; 8 representative points shown below from RDP compression):

**WM_Q#4_Table#2_(Main_Q#4_Answer):**

| *row_id* | *x(EC) (mole fraction, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_Q#4_Table#2_Row#1 | 「0.3478」 | 「268.4」 | 「2.0」 |
| WM_Q#4_Table#2_Row#2 | 「0.4016」 | 「271.7」 | 「2.0」 |
| WM_Q#4_Table#2_Row#3 | 「0.5505」 | 「283.8」 | 「2.0」 |
| WM_Q#4_Table#2_Row#4 | 「0.6513」 | 「289.4」 | 「2.0」 |
| WM_Q#4_Table#2_Row#5 | 「0.7009」 | 「291.6」 | 「2.0」 |
| WM_Q#4_Table#2_Row#6 | 「0.7505」 | 「295.1」 | 「2.0」 |
| WM_Q#4_Table#2_Row#7 | 「0.8467」 | 「299.8」 | 「2.0」 |
| WM_Q#4_Table#2_Row#8 | 「1.0000」 | 「311.2」 | 「2.0」 |

- **Pure EC melting point:** 311.2 K (at x(EC) = 1.0)
- **Lowest T on this branch:** 268.4 K at x(EC) = 0.3478

---

##### Eutectic Region

The eutectic composition lies between x(EC) ≈ 0.28 and 0.35, in the gap between the two measured liquidus branches. The eutectic temperature is approximately 265–268 K, bounded by the lowest measured points on each branch:
- 265.3 K at x(EC) = 0.2768 (PROPblock_34, DMC-rich side)
- 268.4 K at x(EC) = 0.3478 (PROPblock_33, EC-rich side)

##### Chemistry Insight

The EC + DMC system forms a simple eutectic with no intermediate solid phases. The freezing point depression is substantial on both sides: DMC's melting point drops by about 12.9 K (computed: 278.2 − 265.3, both from PROPblock_34) across the DMC-rich branch, while EC's melting point drops by about 42.8 K (computed: 311.2 − 268.4, both from PROPblock_33) across the EC-rich branch. The much larger depression on the EC side reflects the asymmetry typical of systems where one component (EC) has a significantly higher melting point. This mutual freezing point depression is directly relevant to lithium-ion battery electrolyte formulation, where EC/DMC mixtures are standard co-solvents chosen specifically because the eutectic temperature (~265 K / −8 °C) is far below either pure component's melting point, enabling liquid-phase operation over a wide temperature range.

**Block summary:**

**WM_Q#4_Table#3_(Main_Q#4_Answer):**

| *row_id* | *Block* | *Literature* | *Compounds* | *Property* | *Composition range* | *T range (K)* | *Points* |
|---|---|---|---|---|---|---|---|
| WM_Q#4_Table#3_Row#1 | 「PROPblock_34」 | 「GLOBlit_8264 (10.1021/je034134e)」 | 「EC (GLOBcomp_312) + DMC (GLOBcomp_62)」 | 「SLE temperature (GLOBprop_11)」 | 「x(EC) = 0–0.2768」 | 「265.3–278.2」 | 「11」 |
| WM_Q#4_Table#3_Row#2 | 「PROPblock_33」 | 「GLOBlit_8264 (10.1021/je034134e)」 | 「EC (GLOBcomp_312) + DMC (GLOBcomp_62)」 | 「SLE temperature (GLOBprop_11)」 | 「x(EC) = 0.3478–1.0」 | 「268.4–311.2」 | 「14」 |

**Core claims:**
- SLE temperatures for the ethylene carbonate (EC) + dimethyl carbonate (DMC) binary system were measured by DTA at 101.3 kPa, with an expanded uncertainty of U = 2.0 K (95% confidence level), sourced from DOI 10.1021/je034134e.
- The system exhibits a simple eutectic phase diagram with no intermediate solid phases, comprising a DMC-rich liquidus branch (x(EC) = 0 to 0.2768, T_SLE = 278.2 to 265.3 K, 11 points) and an EC-rich liquidus branch (x(EC) = 0.3478 to 1.0, T_SLE = 268.4 to 311.2 K, 14 points).
- The pure DMC melting point is 278.2 K and the pure EC melting point is 311.2 K.
- The eutectic composition lies between x(EC) ≈ 0.28 and 0.35, with the eutectic temperature approximately 265–268 K, bounded by the lowest measured points on each branch: 265.3 K at x(EC) = 0.2768 and 268.4 K at x(EC) = 0.3478.
- The freezing point depression is substantially larger on the EC-rich side (about 42.8 K) than on the DMC-rich side (about 12.9 K), reflecting the asymmetry of the system.

**Sources:**

**WM_Q#4_Table#4_(Main_Q#4_Sources):**

| *row_id* | *lit_num_id* | *block* | *doi* | *BLKsubsys_id* | *description* |
|---|---|---|---|---|---|
| WM_Q#4_Table#4_Row#1 | 「GLOBlit_8264」 | 「PROPblock_34」 | 「10.1021/je034134e」 | 「—」 | 「Provides the DMC-rich liquidus branch of the EC + DMC SLE phase diagram with 11 data points spanning x(EC) = 0–0.2768 and T = 265.3–278.2 K, including the pure DMC melting point and the approach to the eutectic from the DMC side.」 |
| WM_Q#4_Table#4_Row#2 | 「GLOBlit_8264」 | 「PROPblock_33」 | 「10.1021/je034134e」 | 「—」 | 「Provides the EC-rich liquidus branch of the EC + DMC SLE phase diagram with 14 data points spanning x(EC) = 0.3478–1.0 and T = 268.4–311.2 K, including the pure EC melting point and the approach to the eutectic from the EC side.」 |

**Follow-up suggestions:**
- Search for additional SLE data for EC+DMC from other literature sources to compare eutectic temperature and composition estimates.
- Look for excess enthalpy or activity coefficient data for the EC+DMC system to support thermodynamic modeling of the liquidus curves.
- Check for ternary SLE data involving EC, DMC, and a third carbonate solvent (e.g., EMC or PC) relevant to battery electrolyte optimization.

*Not stored here: 2 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


#### SLE_EC_PC
**SLE_EC_PC** — confidence: high · validation: PASS

**Answer:**

#### Solid-Liquid Equilibrium (Liquidus) Data for Ethylene Carbonate + Propylene Carbonate Binary System

##### Source

**Ding et al. (2004)**  
DOI: 10.1021/je034134e [GLOBlit_8264]  
Block: PROPblock_45  
Method: Differential Thermal Analysis (DTA)  
Pressure: 101.3 kPa (fixed)  
Expanded combined uncertainty: U = 2 K (95% confidence level)  
Phases: Liquid + Crystal

---

##### Complete Liquidus Curve — 15 Data Points

**WM_Q#5_Table#1_(Main_Q#5_Answer):**

| *row_id* | *x(EC) (mole fraction, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_Q#5_Table#1_Row#1 | 「0.3001」 | 「253.6」 | 「2」 |
| WM_Q#5_Table#1_Row#2 | 「0.3498」 | 「255.1」 | 「2」 |
| WM_Q#5_Table#1_Row#3 | 「0.4003」 | 「257.1」 | 「2」 |
| WM_Q#5_Table#1_Row#4 | 「0.4504」 | 「265.6」 | 「2」 |
| WM_Q#5_Table#1_Row#5 | 「0.5005」 | 「270.6」 | 「2」 |
| WM_Q#5_Table#1_Row#6 | 「0.5506」 | 「273.9」 | 「2」 |
| WM_Q#5_Table#1_Row#7 | 「0.5965」 | 「279.8」 | 「2」 |
| WM_Q#5_Table#1_Row#8 | 「0.6499」 | 「284.0」 | 「2」 |
| WM_Q#5_Table#1_Row#9 | 「0.6999」 | 「288.2」 | 「2」 |
| WM_Q#5_Table#1_Row#10 | 「0.7492」 | 「290.8」 | 「2」 |
| WM_Q#5_Table#1_Row#11 | 「0.7991」 | 「294.0」 | 「2」 |
| WM_Q#5_Table#1_Row#12 | 「0.8492」 | 「297.8」 | 「2」 |
| WM_Q#5_Table#1_Row#13 | 「0.8995」 | 「301.8」 | 「2」 |
| WM_Q#5_Table#1_Row#14 | 「0.9354」 | 「304.6」 | 「2」 |
| WM_Q#5_Table#1_Row#15 | 「1.0000」 | 「311.2」 | 「2」 |

---

##### Chemical Insight

This is the only dataset found in the ThermoML database for the SLE of the ethylene carbonate (EC) + propylene carbonate (PC) binary system. Key observations:

1. **Monotonic, near-linear liquidus:** The SLE temperature rises steadily from 253.6 K at x(EC) = 0.3001 to 311.2 K for pure EC (x(EC) = 1.0000), spanning a range of ~57.6 K. This near-linear behavior is consistent with relatively ideal solid-liquid equilibrium, expected for two structurally similar cyclic carbonates differing only by a methyl group on the dioxolane ring.

2. **EC-rich branch only:** The data cover only the EC-rich side of the phase diagram (x(EC) ≥ 0.30), corresponding to crystallization of EC from the liquid mixture. No PC-rich branch data are reported.

3. **Eutectic point not directly measured:** The lowest reported SLE temperature is 253.6 K at x(EC) = 0.3001, suggesting the eutectic lies at or below this composition. The eutectic temperature and composition are not directly available from this dataset.

4. **Practical relevance:** EC (melting point 311.2 K / 38 °C) is a key electrolyte solvent in lithium-ion batteries. Blending with PC (which has a much lower melting point, ~−49 °C) depresses the freezing point substantially — by nearly 58 K at x(EC) ≈ 0.30 — enabling low-temperature battery operation while retaining EC's high dielectric constant.

**Core claims:**
- The only SLE (liquidus) dataset found in the ThermoML database for the ethylene carbonate (EC) + propylene carbonate (PC) binary system is from Ding et al. (2004) (DOI: 10.1021/je034134e), measured by differential thermal analysis at 101.3 kPa with an expanded combined uncertainty of U = 2 K.
- The dataset comprises 15 data points covering the EC-rich branch of the liquidus from x(EC) = 0.3001 (T = 253.6 K) to x(EC) = 1.0000 (T = 311.2 K), showing a monotonic, near-linear increase in SLE temperature with increasing EC mole fraction.
- Only the EC-rich side of the phase diagram (x(EC) ≥ 0.30) is covered; no PC-rich branch data are reported, and the eutectic point is not directly measured, though the lowest reported SLE temperature of 253.6 K at x(EC) = 0.3001 suggests the eutectic lies at or below this composition.
- The near-linear liquidus behavior is consistent with relatively ideal solid-liquid equilibrium, expected for two structurally similar cyclic carbonates differing only by a methyl group on the dioxolane ring.

**Sources:**

**WM_Q#5_Table#2_(Main_Q#5_Sources):**

| *row_id* | *lit_num_id* | *block* | *doi* | *BLKsubsys_id* | *description* |
|---|---|---|---|---|---|
| WM_Q#5_Table#2_Row#1 | 「GLOBlit_8264」 | 「PROPblock_45」 | 「10.1021/je034134e」 | 「—」 | 「This block provides all 15 solid-liquid equilibrium (liquidus) data points for the ethylene carbonate + propylene carbonate binary system, covering mole fractions 0.3001–1.0 and temperatures 253.6–311.2 K at 101.3 kPa, which constitute the entirety of the answer's tabulated data.」 |

**Follow-up suggestions:**
- Search for the PC-rich branch of the EC+PC SLE phase diagram (x(EC) < 0.30) in other ThermoML or literature sources to locate the eutectic point.
- Look for excess enthalpy or activity coefficient data for EC+PC mixtures to assess ideality of mixing and compare with the near-linear liquidus behavior observed.
- Check for ternary SLE data involving EC, PC, and a third solvent (e.g., DMC or DEC) relevant to lithium-ion battery electrolyte formulation.

*Not stored here: 3 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


#### SLE_DMC_PC
**SLE_DMC_PC** — confidence: high · validation: PASS

**Answer:**

#### Solid–Liquid Equilibrium (SLE) Temperature Data for Dimethyl Carbonate + Propylene Carbonate

**Source:** DOI 10.1021/je034134e (GLOBlit_8264)

The ThermoML database contains SLE temperature data for the binary system of **dimethyl carbonate (DMC)** and **propylene carbonate (PC, 4-methyl-1,3-dioxolan-2-one)**, reported in two data blocks corresponding to two crystallization branches of a simple eutectic phase diagram. All measurements were performed at a pressure of **101.3 kPa**, with an expanded combined uncertainty of **±2.0 K** (95% confidence level). The measurement method is differential thermal analysis (DTA).

---

##### PROPblock_40 — Crystal 1 (DMC-rich liquidus branch, 16 data points)

This block covers the liquidus curve where **solid DMC** is in equilibrium with the liquid mixture (phase: Liquid + Crystal 1). The SLE temperature increases monotonically with DMC mole fraction.

**WM_Q#6_Table#1_(Main_Q#6_Answer):**

| *row_id* | *x(DMC, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_Q#6_Table#1_Row#1 | 「0.2499」 | 「225.4」 | 「2.0」 |
| WM_Q#6_Table#1_Row#2 | 「0.3003」 | 「232.2」 | 「2.0」 |
| WM_Q#6_Table#1_Row#3 | 「0.3496」 | 「237.7」 | 「2.0」 |
| WM_Q#6_Table#1_Row#4 | 「0.4027」 | 「243.0」 | 「2.0」 |
| WM_Q#6_Table#1_Row#5 | 「0.4498」 | 「246.9」 | 「2.0」 |
| WM_Q#6_Table#1_Row#6 | 「0.5011」 | 「250.5」 | 「2.0」 |
| WM_Q#6_Table#1_Row#7 | 「0.5521」 | 「254.6」 | 「2.0」 |
| WM_Q#6_Table#1_Row#8 | 「0.6071」 | 「257.5」 | 「2.0」 |
| WM_Q#6_Table#1_Row#9 | 「0.6621」 | 「261.2」 | 「2.0」 |
| WM_Q#6_Table#1_Row#10 | 「0.6996」 | 「263.2」 | 「2.0」 |
| WM_Q#6_Table#1_Row#11 | 「0.7501」 | 「265.9」 | 「2.0」 |
| WM_Q#6_Table#1_Row#12 | 「0.7993」 | 「268.2」 | 「2.0」 |
| WM_Q#6_Table#1_Row#13 | 「0.8501」 | 「270.6」 | 「2.0」 |
| WM_Q#6_Table#1_Row#14 | 「0.8998」 | 「272.7」 | 「2.0」 |
| WM_Q#6_Table#1_Row#15 | 「0.9491」 | 「274.9」 | 「2.0」 |
| WM_Q#6_Table#1_Row#16 | 「1.0000」 | 「277.2」 | 「2.0」 |

The pure DMC melting point is **277.2 K** (x_DMC = 1.0). The lowest liquidus temperature in this branch is **225.4 K** at x_DMC = 0.2499, approaching the eutectic composition.

---

##### PROPblock_41 — Crystal 2 (PC-rich liquidus branch, 2 data points)

This block covers the liquidus curve where **solid PC** is in equilibrium with the liquid mixture (phase: Liquid + Crystal 2).

**WM_Q#6_Table#2_(Main_Q#6_Answer):**

| *row_id* | *x(DMC, liquid)* | *T_SLE (K)* | *U (K)* |
|---|---|---|---|
| WM_Q#6_Table#2_Row#1 | 「0.1678」 | 「211.6」 | 「2.0」 |
| WM_Q#6_Table#2_Row#2 | 「0.1998」 | 「217.2」 | 「2.0」 |

---

##### Chemical Insight

The two branches together outline a **simple eutectic phase diagram** for the DMC + PC binary system:

- **Crystal 1 branch** (PROPblock_40): DMC crystallizes out of solution. The liquidus spans from pure DMC (277.2 K) down to x_DMC = 0.2499 (225.4 K), showing significant freezing point depression as PC is added.
- **Crystal 2 branch** (PROPblock_41): PC crystallizes out on the PC-rich side, with only two measured points at x_DMC = 0.1678 (211.6 K) and x_DMC = 0.1998 (217.2 K).
- **Eutectic point**: The eutectic lies between x_DMC ≈ 0.17 and x_DMC ≈ 0.25, at a temperature below 211.6 K (the lowest recorded SLE temperature, from PROPblock_41).
- The DMC-rich liquidus shows **near-linear behavior** at high DMC concentrations, suggesting relatively ideal solution behavior in that region, with increasing deviation from linearity as the eutectic composition is approached. This is consistent with the structural similarity of these two cyclic/linear organic carbonates, which share similar intermolecular interaction types (dipole–dipole, dispersion) but differ in molecular size and symmetry.

**Core claims:**
- The ThermoML database (DOI 10.1021/je034134e) contains SLE temperature data for the binary system dimethyl carbonate (DMC) + propylene carbonate (PC), measured by differential thermal analysis at 101.3 kPa with an expanded combined uncertainty of ±2.0 K (95% confidence level).
- The phase diagram is a simple eutectic system with two liquidus branches: a DMC-rich branch (Crystal 1, 16 data points) spanning x(DMC) = 0.2499 at 225.4 K to pure DMC at 277.2 K, and a PC-rich branch (Crystal 2, 2 data points) at x(DMC) = 0.1678 (211.6 K) and x(DMC) = 0.1998 (217.2 K).
- The eutectic point lies between x(DMC) ≈ 0.17 and x(DMC) ≈ 0.25, at a temperature below 211.6 K.
- The pure DMC melting point reported is 277.2 K at x(DMC) = 1.0.

**Sources:**

**WM_Q#6_Table#3_(Main_Q#6_Sources):**

| *row_id* | *lit_num_id* | *block* | *doi* | *BLKsubsys_id* | *description* |
|---|---|---|---|---|---|
| WM_Q#6_Table#3_Row#1 | 「GLOBlit_8264」 | 「PROPblock_40」 | 「10.1021/je034134e」 | 「—」 | 「Provides the DMC-rich liquidus branch (Crystal 1) of the SLE phase diagram for dimethyl carbonate + propylene carbonate, with 16 data points spanning x(DMC) = 0.2499–1.0 and T = 225.4–277.2 K at 101.3 kPa, directly reproduced in the answer table.」 |
| WM_Q#6_Table#3_Row#2 | 「GLOBlit_8264」 | 「PROPblock_41」 | 「10.1021/je034134e」 | 「—」 | 「Provides the PC-rich liquidus branch (Crystal 2) of the same SLE phase diagram, with 2 data points at x(DMC) = 0.1678–0.1998 and T = 211.6–217.2 K at 101.3 kPa, completing the eutectic diagram presented in the answer.」 |

**Follow-up suggestions:**
- Compare the eutectic temperature and composition with ideal-solution predictions using the van't Hoff equation and pure-component fusion enthalpies of DMC and PC.
- Search for additional SLE data on the PC-rich side (x_DMC < 0.17) to better locate the eutectic point.
- Look for excess Gibbs energy or activity coefficient data for the DMC+PC system to model deviations from ideal liquidus behavior.

*Not stored here: 4 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


### Parallel Compaction Reports

#### Compaction 1
**Philosophy (agentic, targets ALL, philosophy elicited):** Keep all numerical SLE/melting temperature values with their corresponding mole fractions (compositions), pressures, uncertainties, and DOIs. For pure-component results, keep all reported melting temperatures with uncertainties and DOIs. For binary SLE results, keep every (composition, temperature) data point, eutectic points, and DOIs. Drop verbose metadata, repeated schema descriptions, property definitions, and any non-SLE/non-melting-point properties.

##### [pure_melting_EC]
Six independent normal melting temperature measurements for pure ethylene carbonate (GLOBcomp_312, GLOBprop_12) were found, clustering in 308.53–311.2 K (one outlier at 314.45 ± 6 K). The most precise value is 308.53 ± 0.21 K.

### Normal Melting Temperature (GLOBprop_12)

| GLOBlit | DOI | Block | T_melt (K) | U (K) |
|---|---|---|---|---|
| GLOBlit_2207 | 10.1016/j.fluid.2018.05.033 | PROPblock_9 | 310.56 | 0.77 |
| GLOBlit_2959 | 10.1016/j.jct.2008.05.012 | PROPblock_6 | 308.53 | 0.21 |
| GLOBlit_6343 | 10.1016/j.tca.2016.09.007 | PROPblock_1 | 311.15 | 1 |
| GLOBlit_6589 | 10.1021/acs.jced.5b00338 | PROPblock_6 | 314.45 | 6 |
| GLOBlit_7259 | 10.1021/acs.jced.7b00578 | PROPblock_1 | 309.13 | 0.7 |
| GLOBlit_8264 | 10.1021/je034134e | PROPblock_6 | 311.2 | 1 |

### Molar

##### [pure_melting_DMC]
**Summary:** Eight independent pure-component melting temperature measurements for dimethyl carbonate (GLOBcomp_62) were found, spanning 277.06–278.2 K. The most precise value is 278.16 ± 0.16 K (GLOBlit_1484).

| GLOBlit ID | DOI | Block | T_melt (K) | ±U (K) | Property |
|---|---|---|---|---|---|
| GLOBlit_2251 | 10.1016/j.fluid.2018.09.023 | PROPblock_5 | 278.11 | 4 | GLOBprop_11 (SLE T) |
| GLOBlit_1484 | 10.1016/j.fluid.2014.05.033 | PROPblock_4 | 278.16 | 0.16 | GLOBprop_12 (Normal melting T) |
| GLOBlit_1560 | 10.1016/j.fluid.2014.09.024 | PROPblock_4 | 278.2 | 0.4 | GLOBprop_12 |
| GLOBlit_2207 | 10.1016/j.fluid.2018.05.033 | PROPblock_3 | 277.52 | 0.77 | GLOBprop_12 |
| GLOBlit_2959 | 10.1016/j.jct.2008.05.012 | PROPblock_5 | 277.06 | 0.6 | GLOBprop_12 |
| GLOB

##### [pure_melting_PC]
**Summary:** The ThermoML database contains one pure-component melting temperature for propylene carbonate (GLOBcomp_146): **220.3 ± 1.0 K**, from DOI 10.1021/je034134e, block PROPblock_19 (GLOBlit_8264), measured by DTA at atmospheric pressure.

| DOI | GLOBlit | Block | Property | T_melt (K) | U (K) | Method |
|---|---|---|---|---|---|---|
| 10.1021/je034134e | GLOBlit_8264 | PROPblock_19 | Normal melting temperature (GLOBprop_12) | 220.3 | 1.0 | DTA |

- **Single data point:** BLKpoint_1 — 220.3 K, expanded combined uncertainty ±1.0 K (95% confidence).
- No triple-point temperature data found for PC.

##### [SLE_EC_DMC]
**Summary:** Binary SLE data for EC (GLOBcomp_312) + DMC (GLOBcomp_62) found in DOI **10.1021/je034134e** (GLOBlit_8264), property GLOBprop_11, measured by DTA at 101.3 kPa with U = 2.0 K. Two liquidus branches form a simple eutectic (T_eut ≈ 265–268 K, x(EC) ≈ 0.28–0.35). PROPblock_33 (EC-rich) has 14 points total but only 8 shown (RDP-compressed); PROPblock_34 (DMC-rich) is complete with 11 points.

### PROPblock_34 — DMC-rich branch (complete, 11 pts)

| x(EC) | T_SLE (K) | U (K) |
|---|---|---|
| 0 | 278.2 | 2 |
| 0.0501 | 274.8 | 2 |
| 0.077 | 273.6 | 2 |
| 0.1011 | 272.7 | 2 |
| 0.1258 | 271.6 | 2 |
| 0.1515 | 270.7 | 2 |
| 0.1761 | 269.4 | 2

##### [SLE_EC_PC]
**Verdict:** One SLE (liquidus) dataset found for EC+PC binary — Ding et al. (2004), DOI 10.1021/je034134e, block PROPblock_45 (GLOBlit_8264). 15 data points covering the EC-rich branch at 101.3 kPa, U = 2 K.

### SLE Liquidus Data — EC (GLOBcomp_312) + PC (GLOBcomp_146)

| BLKpoint_id | x(EC) | T_SLE (K) | U (K) | P (kPa) |
|:-----------:|:-----:|:---------:|:-----:|:-------:|
| BLKpoint_1  | 0.3001 | 253.6 | 2 | 101.3 |
| BLKpoint_2  | 0.3498 | 255.1 | 2 | 101.3 |
| BLKpoint_3  | 0.4003 | 257.1 | 2 | 101.3 |
| BLKpoint_4  | 0.4504 | 265.6 | 2 | 101.3 |
| BLKpoint_5  | 0.5005 | 270.6 | 2 | 101.3 |
| BLKpoint_6  | 0.5506 | 273.9 | 2 | 101.3 |
| BLKpoint_7  | 0.5965 | 279.8 | 2 | 101.3 |
| BLKpoint_8  | 0.6499 |

##### [SLE_DMC_PC]
Binary SLE data for DMC (GLOBcomp_62) + PC (GLOBcomp_146) found in one source: DOI **10.1021/je034134e** (GLOBlit_8264). Simple eutectic system with two liquidus branches (18 total points), all at **101.3 kPa**, uncertainty **±2.0 K**. Eutectic lies between x(DMC) ≈ 0.17–0.25, below 211.6 K.

### PROPblock_40 — DMC-rich liquidus (Crystal 1, 16 pts)

| x(DMC) | T_SLE (K) |
|---------|-----------|
| 0.2499 | 225.4 |
| 0.3003 | 232.2 |
| 0.3496 | 237.7 |
| 0.4027 | 243 |
| 0.4498 | 246.9 |
| 0.5011 | 250.5 |
| 0.5521 | 254.6 |
| 0.6071 | 257.5 |
| 0.6621 | 261.2 |
| 0.6996 | 263.2 |
| 0.7501 | 265.9 |
| 0.7993 | 268.2 |
| 0.8501 | 270.6 |
| 0.8998 | 272.7 |
| 0.9491 | 274.9 |
| 1.0000 | 277.
