1. Should generic pure-solvent baselines inherit the preceding mixture-source citations, or be checked as uncited pure-system data?

   **Your reply:** A — Use independent pure-component archive records; retain unknown original attribution (Recommended)
