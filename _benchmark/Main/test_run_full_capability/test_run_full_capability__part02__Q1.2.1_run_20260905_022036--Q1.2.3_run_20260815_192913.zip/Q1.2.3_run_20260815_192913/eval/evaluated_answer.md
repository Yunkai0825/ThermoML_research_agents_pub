# Main Agent Run — [run id removed] (Round 1)

**Question:** At 303.15 K and 81.5 kPa, give me a Redlich–Kister correlation for the viscosity of liquid methanol + ethanol as a function of methanol mole fraction. Define the fitted viscosity basis, then report the equation, polynomial order, coefficients with units, R², RMSE, and composition range.

**[run statistics removed]**

---

## Answer

## Redlich–Kister Correlation for the Dynamic Viscosity of Liquid Methanol + Ethanol at 303.15 K and 81.5 kPa

### Fitted Viscosity Basis

Because dynamic viscosity is a transport property that does not combine linearly with composition, the **Arrhenius (logarithmic) mixing rule** is used. The quantity fitted by the Redlich–Kister expansion is the **excess of ln η**, defined as:

$$\Delta \ln\eta = \ln\eta_{\text{mix}} - \bigl[x_1 \ln\eta_1^* + x_2 \ln\eta_2^*\bigr]$$

where *x*₁ is the mole fraction of methanol (component 1), *x*₂ = 1 − *x*₁ is the mole fraction of ethanol (component 2), and η₁\* and η₂\* are the pure-component viscosities.

### Pure-Component Viscosities

| Component | Block | η\* (Pa·s) |
|---|---|---|
| Methanol (*x*₁) | PROPblock_8 | 0.000525 |
| Ethanol (*x*₂) | PROPblock_2 | 0.000994 |

### Equation

The Redlich–Kister expansion for the excess quantity is:

$$\Delta \ln\eta = x_1 \, x_2 \sum_{k=0}^{n} A_k \,(x_1 - x_2)^k$$

The full mixture viscosity is then recovered as:

$$\eta_{\text{mix}} = \exp\!\Bigl[x_1 \ln\eta_1^* + x_2 \ln\eta_2^* + x_1\,x_2 \sum_{k=0}^{n} A_k\,(x_1 - x_2)^k\Bigr]$$

### Polynomial Order and Coefficients (BIC-Selected)

The Bayesian Information Criterion (BIC) selects a **2nd-order** polynomial (3 coefficients). All coefficients are **dimensionless** because they multiply the excess of ln η:

| Coefficient | Value |
|---|---|
| A₀ | 0.0396991 |
| A₁ | 0.0275633 |
| A₂ | −0.0218724 |

### Goodness of Fit

| Metric | Value |
|---|---|
| R² | 0.982166 |
| RMSE | 0.000473597 Pa·s |
| BIC | −176.27 |
| Number of mixture data points | 12 |

The RMSE is reported in the original viscosity units (Pa·s) after back-transformation from the ln η domain. BIC model comparison confirmed that order 2 provides the best balance of fit quality and parsimony — higher orders (3–5) yielded negligible R² improvement with worsening BIC.

### Composition Range

The 12 mixture data points in PROPblock_16 span methanol mole fraction **x₁ = 0.0417 to 0.9166** at irregular spacing.

### Chemistry Insight

Methanol and ethanol are structurally similar small primary alcohols with comparable hydrogen-bonding character. The small, positive A₀ (≈ 0.040) indicates a slight **positive deviation** from Arrhenius-ideal mixing — the mixture is marginally more viscous than the logarithmic ideal prediction, consistent with a weak enhancement of hydrogen-bond networking when the two alcohols are mixed. The modest magnitudes of A₁ and A₂ reflect the near-symmetric mixing behavior expected for two molecules of similar size and polarity.

The PROPblock_16 data show viscosity decreasing monotonically from 0.000968 Pa·s at x₁ = 0.0417 (BLKpoint_1 in PROPblock_16) to 0.000556 Pa·s at x₁ = 0.9166 (BLKpoint_12 in PROPblock_16). This trend is consistent with methanol's lower pure-component viscosity (η\* = 0.000525 Pa·s, PROPblock_8) compared to ethanol's (η\* = 0.000994 Pa·s, PROPblock_2).

### Data Source

All data originate from a single publication measured by capillary tube (Ostwald–Ubbelohde) viscometry:

- **Literature ID:** GLOBlit_11337 | **DOI:** 10.1021/je800633a
  - **PROPblock_16** — 12 binary mixture viscosity data points (methanol + ethanol, liquid phase, 303.15 K, 81.5 kPa; x₁ = 0.0417–0.9166, η = 0.000556–0.000968 Pa·s)
  - **PROPblock_8** — Pure methanol viscosity endpoint (η\* = 0.000525 Pa·s at 303.15 K, 81.5 kPa)
  - **PROPblock_2** — Pure ethanol viscosity endpoint (η\* = 0.000994 Pa·s at 303.15 K, 81.5 kPa)

### Session Output Files

- Fit data CSV: `10_1021_je800633a_BPROPblock_16_T303.1_fit.csv`
- Excess property CSV: `10_1021_je800633a_BPROPblock_16_T303.1_excess.csv`
- Fit plot: `10_1021_je800633a_BPROPblock_16_T303.1_fit.png`
- Excess plot: `10_1021_je800633a_BPROPblock_16_T303.1_excess.png`









### Core claims

- A Redlich–Kister expansion of order 2 (3 coefficients) was fitted to the excess of ln η for liquid methanol + ethanol at 303.15 K and 81.5 kPa, with dimensionless coefficients A₀ = 0.0396991, A₁ = 0.0275633, A₂ = −0.0218724, selected by BIC over higher orders.
- Pure-component dynamic viscosities used as endpoints are 0.000525 Pa·s for methanol and 0.000994 Pa·s for ethanol at 303.15 K and 81.5 kPa.
- The fit covers 12 mixture data points spanning methanol mole fraction x₁ = 0.0417 to 0.9166, with R² = 0.982166 and RMSE = 0.000473597 Pa·s.
- The small positive A₀ indicates a slight positive deviation from Arrhenius-ideal mixing, consistent with weak enhancement of hydrogen-bond networking between the two structurally similar primary alcohols.
- Mixture viscosity decreases monotonically from 0.000968 Pa·s at x₁ = 0.0417 to 0.000556 Pa·s at x₁ = 0.9166, consistent with methanol's lower pure-component viscosity relative to ethanol's.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11337 | 10.1021/je800633a | PROPblock_16 |  | Provides the 12 binary mixture viscosity data points (methanol + ethanol, 303.15 K, 81.5 kPa, x₁ = 0.0417–0.9166, η = 0.000556–0.000968 Pa·s) that were fitted by the Redlich–Kister expansion of Δ ln η. |
| GLOBlit_11337 | 10.1021/je800633a | PROPblock_8 |  | Supplies the pure methanol viscosity endpoint (η* = 0.000525 Pa·s at 303.15 K, 81.5 kPa) used as the x₁ = 1 reference in the Arrhenius mixing rule. |
| GLOBlit_11337 | 10.1021/je800633a | PROPblock_2 |  | Supplies the pure ethanol viscosity endpoint (η* = 0.000994 Pa·s at 303.15 K, 81.5 kPa) used as the x₂ = 1 reference in the Arrhenius mixing rule. |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
