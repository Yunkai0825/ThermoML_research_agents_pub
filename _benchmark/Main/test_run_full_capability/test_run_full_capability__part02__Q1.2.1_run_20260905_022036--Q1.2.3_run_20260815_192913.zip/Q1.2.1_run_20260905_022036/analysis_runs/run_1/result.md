# Analysis Run — 20260905_022910 (Round 1)

**Question:** [Purpose: Obtain a Redlich-Kister correlation for density of ethanol+water mixtures at 25°C]
Fit a Redlich-Kister polynomial to the density of liquid ethanol + water at 25°C (298.15 K) as a function of ethanol mole fraction. Report the fitted equation, polynomial order, coefficients with units, R², RMSE, and composition range.

[Context: The user wants density (kg/m³ or g/cm³) of ethanol+water liquid mixtures at 25°C. Search for ThermoML data covering this binary system, then fit a Redlich-Kister polynomial to the excess or total density. Ethanol = C2H5OH, Water = H2O. Report all fitting details.]

**Time:** 469.9s | **Iterations:** 14 | **Tools:** 13

---

## Answer

## Redlich-Kister Correlation for Density of Ethanol + Water at 298.15 K

### Data Source

- **DOI:** 10.1016/j.fluid.2004.11.019 (GLOBlit_220)
- **Block:** PROPblock_2
- **System:** ethanol (GLOBcomp_2) + water (GLOBcomp_1), liquid phase
- **Conditions:** T = 298.15 K, P = 100 kPa (atmospheric)
- **Data points used:** 47 mixture compositions (from 810 total rows spanning multiple T and P)
- **Composition range:** x(ethanol) = 0.003 to 1.0 (mole fraction)
- **Measurement method:** Vibrating-tube densimeter (GLOBmeas_138)

### Pure-Component Densities

| Component | ρ* (kg/m³) | Source |
|-----------|-----------|--------|
| Water | 992.083 | Block edge value (direct/good) |
| Ethanol | 785.7 | Block edge value (direct/good) |

### Fitted Equation

The total density is expressed as:

$$\rho(x_1) = x_1 \, \rho_1^* + x_2 \, \rho_2^* + x_1 \, x_2 \sum_{k=0}^{n} A_k (x_1 - x_2)^k$$

where x₁ = mole fraction of ethanol, x₂ = 1 − x₁, ρ₁* = 785.7 kg/m³ (pure ethanol), ρ₂* = 992.083 kg/m³ (pure water), and the mixing rule is **linear** (appropriate for density).

### BIC-Selected Polynomial Order and Coefficients

| Parameter | Value |
|-----------|-------|
| **BIC-selected order** | **3** |
| A₀ | −120.557 kg/m³ |
| A₁ | 18.568 kg/m³ |
| A₂ | 43.919 kg/m³ |
| A₃ | −31.351 kg/m³ |
| **R²** | **0.997283** |
| **RMSE** | **0.4748 kg/m³** |
| **BIC** | **−54.62** |

### Model Selection Summary

| Order | BIC | R² | RMSE (kg/m³) |
|-------|---------|----------|------------|
| 0 | 47.60 | 0.969419 | 1.593 |
| 1 | 48.19 | 0.971469 | 1.538 |
| 2 | −33.56 | 0.995383 | 0.619 |
| 3 | **−54.62** | **0.997283** | **0.475** |
| 4 | −52.17 | 0.997362 | 0.468 |
| 5 | −53.77 | 0.997651 | 0.441 |

The BIC criterion selects order 3 as optimal — orders 4 and 5 provide negligible improvement in R² while incurring a complexity penalty.

### Chemistry Insight

The large negative A₀ coefficient (−120.6 kg/m³) reflects the well-known **volume contraction** upon mixing ethanol and water: hydrogen-bonding reorganization allows water molecules to partially fill the voids in ethanol's structure, producing a mixture denser than the mole-fraction-weighted average of the pure components. The asymmetry captured by A₁ through A₃ indicates that the maximum deviation from ideal (linear) mixing occurs at water-rich compositions (roughly x(ethanol) ≈ 0.3–0.4), consistent with the composition range where the ethanol–water hydrogen-bond network undergoes the most dramatic restructuring.

Representative data points at 298.15 K, 100 kPa (from inspected block rows):

| x(ethanol) | ρ (kg/m³) |
|------------|-----------|
| 0.003 | 995.3 |
| 0.2502 | 918.5 |
| 0.4501 | 868.8 |
| 0.6967 | 825.2 |
| 1.000 | 785.7 |

### Output Files

- **Fit data CSV:** `10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv`
- **Excess property CSV:** `10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv`
- **Fit plot:** `10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png`
- **Excess plot:** `10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png`

### Core claims

- Liquid density of ethanol + water at 298.15 K and 100 kPa was correlated using a Redlich-Kister expansion with a linear (mole-fraction-weighted) ideal mixing rule, fitted to 47 mixture compositions spanning x(ethanol) = 0.003 to 1.0, with pure-component densities of 785.7 kg/m³ (ethanol) and 992.083 kg/m³ (water).
- BIC model selection favors a 3rd-order Redlich-Kister polynomial with coefficients A₀ = −120.557 kg/m³, A₁ = 18.568 kg/m³, A₂ = 43.919 kg/m³, A₃ = −31.351 kg/m³, yielding R² = 0.997283, RMSE = 0.4748 kg/m³, and BIC = −54.62; orders 4 and 5 provide negligible improvement in R² while incurring a complexity penalty.
- The large negative A₀ coefficient reflects volume contraction upon mixing ethanol and water due to hydrogen-bonding reorganization, and the asymmetry captured by higher-order coefficients indicates the maximum deviation from ideal mixing occurs at water-rich compositions (roughly x(ethanol) ≈ 0.3–0.4).

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 |  | This block provides binary ethanol + water mass density data (810 points, 298.15–348.15 K, 100–40000 kPa, x = 0.003–1.0) from which the 47 data points at T = 298.15 K and P = 100 kPa were extracted to fit the Redlich-Kister correlation of order 3 with R² = 0.997283 and RMSE = 0.475 kg/m³. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_220 | PROPblock_2 | GLOBprop_1 | 3 | -120.55681029600882; 18.567625256466393; 43.91912836453406; -31.35056319853136 | 0.997283 | 0.47476545853553287 | 47 | 298.15 | linear |  | 10.1016/j.fluid.2004.11.019 |

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored. 1 entr(ies); verbatim rows below.

- INSP_689860323003 — GLOBlit_220::PROPblock_2 · rdp · 25 rows

```json
[
  {
    "doi": "10.1016/j.fluid.2004.11.019",
    "block_number": "PROPblock_2",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "pressure_kpa",
      "mole_fraction_<ethanol>",
      "mass_density_kg_m3"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "298.15",
        "pressure_kpa": "100",
        "mole_fraction_<ethanol>": "0.003",
        "mass_density_kg_m3": "995.3"
      },
      {
        "BLKpoint_id": "BLKpoint_38",
        "temperature_k": "298.15",
        "pressure_kpa": "100",
        "mole_fraction_<ethanol>": "0.2502",
        "mass_density_kg_m3": "918.5"
      },
      {
        "BLKpoint_id": "BLKpoint_43",
        "temperature_k": "298.15",
        "pressure_kpa": "100",
        "mole_fraction_<ethanol>": "0.4501",
        "mass_density_kg_m3": "868.8"
      },
      {
        "BLKpoint_id": "BLKpoint_48",
        "temperature_k": "298.15",
        "pressure_kpa": "100",
        "mole_fraction_<ethanol>": "0.6967",
        "mass_density_kg_m3": "825.2"
      },
      {
        "BLKpoint_id": "BLKpoint_54",
        "temperature_k": "298.15",
        "pressure_kpa": "100",
        "mole_fraction_<ethanol>": "1",
        "mass_density_kg_m3": "785.7"
      },
      {
        "BLKpoint_id": "BLKpoint_55",
        "temperature_k": "298.15",
        "pressure_kpa": "10000",
        "mole_fraction_<ethanol>": "0.003",
        "mass_density_kg_m3": "999.8"
      },
      {
        "BLKpoint_id": "BLKpoint_92",
        "temperature_k": "298.15",
        "pressure_kpa": "10000",
        "mole_fraction_<ethanol>": "0.2502",
        "mass_density_kg_m3": "923.3"
      },
      {
        "BLKpoint_id": "BLKpoint_97",
        "temperature_k": "298.15",
        "pressure_kpa": "10000",
        "mole_fraction_<ethanol>": "0.4501",
        "mass_density_kg_m3": "874.7"
      },
      {
        "BLKpoint_id": "BLKpoint_102",
        "temperature_k": "298.15",
        "pressure_kpa": "10000",
        "mole_fraction_<ethanol>": "0.6967",
        "mass_density_kg_m3": "832.3"
      },
      {
        "BLKpoint_id": "BLKpoint_108",
        "temperature_k": "298.15",
        "pressure_kpa": "10000",
        "mole_fraction_<ethanol>": "1",
        "mass_density_kg_m3": "794"
      },
      {
        "BLKpoint_id": "BLKpoint_109",
        "temperature_k": "298.15",
        "pressure_kpa": "20000",
        "mole_fraction_<ethanol>": "0.003",
        "mass_density_kg_m3": "1004.2"
      },
      {
        "BLKpoint_id": "BLKpoint_146",
        "temperature_k": "298.15",
        "pressure_kpa": "20000",
        "mole_fraction_<ethanol>": "0.2502",
        "mass_density_kg_m3": "928"
      },
      {
        "BLKpoint_id": "BLKpoint_151",
        "temperature_k": "298.15",
        "pressure_kpa": "20000",
        "mole_fraction_<ethanol>": "0.4501",
        "mass_density_kg_m3": "880.4"
      },
      {
        "BLKpoint_id": "BLKpoint_156",
        "temperature_k": "298.15",
        "pressure_kpa": "20000",
        "mole_fraction_<ethanol>": "0.6967",
        "mass_density_kg_m3": "839"
      },
      {
        "BLKpoint_id": "BLKpoint_162",
        "temperature_k": "298.15",
        "pressure_kpa": "20000",
        "mole_fraction_<ethanol>": "1",
        "mass_density_kg_m3": "801.9"
      },
      {
        "BLKpoint_id": "BLKpoint_163",
        "temperature_k": "298.15",
        "pressure_kpa": "30000",
        "mole_fraction_<ethanol>": "0.003",
        "mass_density_kg_m3": "1008.5"
      },
      {
        "BLKpoint_id": "BLKpoint_199",
        "temperature_k": "298.15",
        "pressure_kpa": "30000",
        "mole_fraction_<ethanol>": "0.2269",
        "mass_density_kg_m3": "938.7"
      },
      {
        "BLKpoint_id": "BLKpoint_205",
        "temperature_k": "298.15",
        "pressure_kpa": "30000",
        "mole_fraction_<ethanol>": "0.4501",
        "mass_density_kg_m3": "885.7"
      },
      {
        "BLKpoint_id": "BLKpoint_210",
        "temperature_k": "298.15",
        "pressure_kpa": "30000",
        "mole_fraction_<ethanol>": "0.6967",
        "mass_density_kg_m3": "845.1"
      },
      {
        "BLKpoint_id": "BLKpoint_216",
        "temperature_k": "298.15",
        "pressure_kpa": "30000",
        "mole_fraction_<ethanol>": "1",
        "mass_density_kg_m3": "808.9"
      },
      {
        "BLKpoint_id": "BLKpoint_217",
        "temperature_k": "298.15",
        "pressure_kpa": "40000",
        "mole_fraction_<ethanol>": "0.003",
        "mass_density_kg_m3": "1012.7"
      },
      {
        "BLKpoint_id": "BLKpoint_253",
        "temperature_k": "298.15",
        "pressure_kpa": "40000",
        "mole_fraction_<ethanol>": "0.2269",
        "mass_density_kg_m3": "942.9"
      },
      {
        "BLKpoint_id": "BLKpoint_259",
        "temperature_k": "298.15",
        "pressure_kpa": "40000",
        "mole_fraction_<ethanol>": "0.4501",
        "mass_density_kg_m3": "890.8"
      },
      {
        "BLKpoint_id": "BLKpoint_264",
        "temperature_k": "298.15",
        "pressure_kpa": "40000",
        "mole_fraction_<ethanol>": "0.6967",
        "mass_density_kg_m3": "851"
      },
      {
        "BLKpoint_id": "BLKpoint_270",
        "temperature_k": "298.15",
        "pressure_kpa": "40000",
        "mole_fraction_<ethanol>": "1",
        "mass_density_kg_m3": "815.7"
      }
    ],
    "inspection_id": "INSP_689860323003",
    "lit_num_id": "GLOBlit_220"
  }
]
```

---

## Verdict

**Data Quality**
The agent used ThermoML data from a real DOI with 47 mixture compositions at 298.15 K — appropriate source. However, multiple `fit_block` calls returned short responses (~259–324 chars), suggesting failures or minimal output, until call 12 (852 chars) apparently succeeded. The representative data points (e.g., x=0.003→995.3, x=0.2502→918.5) cannot be verified against tool results since inspect_block returned limited data. The pure water density of 992.083 kg/m³ is suspect (literature: ~997.05 kg/m³), suggesting a possible data or extraction error. Composition basis appears to be mole fraction — acceptable. No fabrication flag triggered since fit_block did return results.

**Fit Quality**
Order 3 selected by BIC is reasonable. R²=0.997 and RMSE=0.475 kg/m³ are acceptable but the anomalous pure-water density raises concern about underlying data quality.

**Scientific Verdict**
The methodology is sound but the pure-water density (~992 vs ~997 kg/m³) is a red flag — possibly a data issue in the source block. Users should verify pure-component endpoints before applying this correlation. The negative A₀ correctly captures volume contraction physics.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260905_022036\analysis_runs\run_1\data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260905_022036\analysis_runs\run_1\data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260905_022036\analysis_runs\run_1\plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260905_022036\analysis_runs\run_1\plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1