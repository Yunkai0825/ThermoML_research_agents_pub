# Working Memory

**ROOT:** `N:\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Main\test_run_r1_1_20261020\Q3.7_run_20261020_210056`

### History
- [menu:browse] {'text': 'I need to explore the submenus to see the actual t
- [menu:run] search_id_alignment → OK
- [menu:run] search_id_alignment → OK
- [query:Q1] "Find all vapor pressure (saturation pressure) data blocks and critical property " (459s, 3 iters, validation=PASS verdict=## Verdict
The answer is compr)
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → ERROR: where filter error: unknown column alias 'complete'
- [menu:run] inspect_block_table → ERROR: where filter error: unknown column alias 'complete'
- [menu:run] inspect_block_table → ERROR: where filter error: unknown column alias 'complete'
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK
- [menu:run] inspect_block_table → OK

### Query Agent Results

#### Q1
**Q1** — confidence: high · validation: PASS

**Answer:**

#### Vapor Pressure and Critical Property Data for R1234ze(E) in ThermoML

##### Compound
**trans-1,3,3,3-Tetrafluoropropene (R1234ze(E))** — CAS 29118-24-9, formula C₃H₂F₄

---

##### Vapor Pressure Data Blocks (GLOBprop_5)

Seven data blocks containing pure-component vapor/sublimation pressure measurements were identified and inspected:

**WM_Q#1_Table#1_(Main_Q#1_Answer):**

| *row_id* | *#* | *Literature ID* | *Block* | *DOI* | *Points* | *T range (K)* | *P range (kPa)* | *Uncertainty* |
|---|---|---|---|---|---|---|---|---|
| WM_Q#1_Table#1_Row#1 | 「1」 | 「GLOBlit_1271」 | 「PROPblock_2」 | 「10.1016/j.fluid.2013.06.017」 | 「4」 | 「258.15–288.15」 | 「120.2–364.2」 | 「1–1.1 kPa」 |
| WM_Q#1_Table#1_Row#2 | 「2」 | 「GLOBlit_3800」 | 「PROPblock_2」 | 「10.1016/j.jct.2012.12.026」 | 「4」 | 「258.15–288.15」 | 「120.2–364.2」 | 「1–1.1 kPa」 |
| WM_Q#1_Table#1_Row#3 | 「3」 | 「GLOBlit_1990」 | 「PROPblock_3」 | 「10.1016/j.fluid.2016.10.011」 | 「9」 | 「283.145–323.141」 | 「308.6–997.8」 | 「1.1–1.8 kPa」 |
| WM_Q#1_Table#1_Row#4 | 「4」 | 「GLOBlit_4997」 | 「PROPblock_1」 | 「10.1016/j.jct.2017.03.032」 | 「11」 | 「280.15–330.126」 | 「276.5–1178.1」 | 「20–20.1 kPa」 |
| WM_Q#1_Table#1_Row#5 | 「5」 | 「GLOBlit_2136」 | 「PROPblock_3」 | 「10.1016/j.fluid.2017.12.030」 | 「15」 | 「303.146–373.137」 | 「578.14–3026.83」 | 「—」 |
| WM_Q#1_Table#1_Row#6 | 「6」 | 「GLOBlit_5488」 | 「PROPblock_1」 | 「10.1016/j.jct.2019.03.016」 | 「9」 | 「298.221–338.102」 | 「499.4–1434.8」 | 「8.1 kPa」 |
| WM_Q#1_Table#1_Row#7 | 「7」 | 「GLOBlit_5520」 | 「PROPblock_1」 | 「10.1016/j.jct.2019.04.020」 | 「4」 | 「293.15–323.14」 | 「427.4–997.8」 | 「5.1–5.3 kPa」 |

**Total: 56 data points** across 7 blocks from 7 DOIs, spanning **258.15–373.137 K** and **120.2–3026.83 kPa**.

**Note:** GLOBlit_1271 and GLOBlit_3800 contain identical data (same four T/P pairs). These two blocks provide the lowest-temperature data and are the only ones that bracket 273.15 K.

###### Data Nearest to 273.15 K

From GLOBlit_1271 (PROPblock_2, DOI: 10.1016/j.fluid.2013.06.017):

**WM_Q#1_Table#2_(Main_Q#1_Answer):**

| *row_id* | *T (K)* | *P (kPa)* | *U(P) (kPa)* |
|---|---|---|---|
| WM_Q#1_Table#2_Row#1 | 「258.15」 | 「120.2」 | 「1」 |
| WM_Q#1_Table#2_Row#2 | 「268.15」 | 「179.3」 | 「1」 |
| WM_Q#1_Table#2_Row#3 | 「278.15」 | 「259.2」 | 「1.1」 |
| WM_Q#1_Table#2_Row#4 | 「288.15」 | 「364.2」 | 「1.1」 |

No block contains a measurement at exactly 273.15 K. The target temperature is bracketed between **179.3 kPa at 268.15 K** and **259.2 kPa at 278.15 K**.

---

##### Critical Property Data

A single literature source was found:

**GLOBlit_11766** — DOI: 10.1021/je900696z

**WM_Q#1_Table#3_(Main_Q#1_Answer):**

| *row_id* | *Block* | *Property* | *Value* | *Uncertainty (95%)* | *Method* |
|---|---|---|---|---|---|
| WM_Q#1_Table#3_Row#1 | 「PROPblock_1」 | 「Critical temperature」 | 「382.51 K」 | 「± 0.06 K」 | 「Visual observation (unstirred cell)」 |
| WM_Q#1_Table#3_Row#2 | 「PROPblock_2」 | 「Critical density」 | 「486 kg/m³」 | 「± 8 kg/m³」 | 「Rectilinear diameter」 |

**No critical pressure data was found** in the ThermoML database for R1234ze(E).

---

##### Chemistry Insight

R1234ze(E) is a low-GWP hydrofluoroolefin refrigerant being adopted as a replacement for R-134a. Its vapor pressure rises steeply with temperature — from 120.2 kPa at 258.15 K to 3026.83 kPa at 373.137 K across the collected data, approaching the critical temperature of 382.51 K. The wide temperature coverage (258.15–373.137 K, spanning ~115 K) across the seven identified blocks is well suited for Clausius–Clapeyron or Antoine-type fitting to estimate the vapor pressure at 273.15 K and the enthalpy of vaporization. The absence of critical pressure in ThermoML means that complete critical-point characterization would require supplementary data from other sources.

**Core claims:**
- Seven ThermoML data blocks from seven DOIs provide a total of 56 pure-component vapor pressure data points for trans-1,3,3,3-tetrafluoropropene (R1234ze(E), CAS 29118-24-9), spanning 258.15–373.137 K and 120.2–3026.83 kPa.
- GLOBlit_1271 and GLOBlit_3800 contain identical data (same four T/P pairs) and are the only blocks that bracket 273.15 K, with 179.3 kPa at 268.15 K and 259.2 kPa at 278.15 K; no block contains a measurement at exactly 273.15 K.
- A single ThermoML source (GLOBlit_11766, DOI 10.1021/je900696z) reports a critical temperature of 382.51 K (± 0.06 K) and a critical density of 486 kg/m³ (± 8 kg/m³) for R1234ze(E); no critical pressure data was found in the ThermoML database.
- The absence of critical pressure in ThermoML means complete critical-point characterization of R1234ze(E) would require supplementary data from other sources.

**Sources:**

**WM_Q#1_Table#4_(Main_Q#1_Sources):**

| *row_id* | *lit_num_id* | *block* | *doi* | *BLKsubsys_id* | *description* |
|---|---|---|---|---|---|
| WM_Q#1_Table#4_Row#1 | 「GLOBlit_1271」 | 「PROPblock_2」 | 「10.1016/j.fluid.2013.06.017」 | 「—」 | 「Provides 4 vapor pressure data points for R1234ze(E) from 258.15–288.15 K (120.2–364.2 kPa), which bracket 273.15 K and supply the lowest-temperature coverage among all blocks.」 |
| WM_Q#1_Table#4_Row#2 | 「GLOBlit_3800」 | 「PROPblock_2」 | 「10.1016/j.jct.2012.12.026」 | 「—」 | 「Provides 4 vapor pressure data points identical in range (258.15–288.15 K, 120.2–364.2 kPa) to GLOBlit_1271; the answer correctly notes the duplication and uses both as independent literature sources.」 |
| WM_Q#1_Table#4_Row#3 | 「GLOBlit_1990」 | 「PROPblock_3」 | 「10.1016/j.fluid.2016.10.011」 | 「—」 | 「Contributes 9 vapor pressure points for R1234ze(E) over 283.145–323.141 K (308.6–997.8 kPa), extending coverage above the low-temperature blocks and supporting Antoine/Clausius–Clapeyron fitting.」 |
| WM_Q#1_Table#4_Row#4 | 「GLOBlit_4997」 | 「PROPblock_1」 | 「10.1016/j.jct.2017.03.032」 | 「—」 | 「Supplies 11 vapor pressure data points over 280.15–330.126 K (276.5–1178.1 kPa), adding breadth to the dataset and overlapping with other blocks for cross-validation.」 |
| WM_Q#1_Table#4_Row#5 | 「GLOBlit_2136」 | 「PROPblock_3」 | 「10.1016/j.fluid.2017.12.030」 | 「—」 | 「Provides 15 vapor pressure points at higher temperatures (303.146–373.137 K, 578.14–3026.83 kPa), extending coverage toward the critical point and contributing the most data points of any single block.」 |
| WM_Q#1_Table#4_Row#6 | 「GLOBlit_5488」 | 「PROPblock_1」 | 「10.1016/j.jct.2019.03.016」 | 「—」 | 「Contributes 9 vapor pressure data points over 298.221–338.102 K (499.4–1434.8 kPa) measured via ISOPVT method, providing an independent methodology cross-check.」 |
| WM_Q#1_Table#4_Row#7 | 「GLOBlit_5520」 | 「PROPblock_1」 | 「10.1016/j.jct.2019.04.020」 | 「—」 | 「Adds 4 vapor pressure points over 293.15–323.14 K (427.4–997.8 kPa), supplementing the mid-range temperature coverage for R1234ze(E).」 |
| WM_Q#1_Table#4_Row#8 | 「GLOBlit_11766」 | 「PROPblock_1」 | 「10.1021/je900696z」 | 「—」 | 「Provides the critical temperature of R1234ze(E) as 382.51 K ± 0.06 K by visual observation, directly supporting the critical property section of the answer.」 |
| WM_Q#1_Table#4_Row#9 | 「GLOBlit_11766」 | 「PROPblock_2」 | 「10.1021/je900696z」 | 「—」 | 「Provides the critical density of R1234ze(E) as 486 kg/m³ ± 8 kg/m³ by rectilinear diameter method, completing the available critical property data reported in the answer.」 |

**Follow-up suggestions:**
- Perform Clausius-Clapeyron interpolation using the GLOBlit_1271 data points at 268.15 K and 278.15 K to estimate the vapor pressure at 273.15 K.
- Fit an Antoine equation to all 56 vapor pressure data points across the seven blocks to obtain a continuous vapor pressure curve and estimate enthalpy of vaporization.
- Search external databases (e.g., NIST WebBook, REFPROP) for the critical pressure of R1234ze(E), since no critical pressure data was found in ThermoML.
- Investigate whether the duplicate data in GLOBlit_1271 and GLOBlit_3800 should be deduplicated before fitting to avoid biasing the regression.

*Not stored here: 9 verbatim data_inspections table(s); 1 id_catalog_snapshot row(s) (catalog is merged separately). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.

