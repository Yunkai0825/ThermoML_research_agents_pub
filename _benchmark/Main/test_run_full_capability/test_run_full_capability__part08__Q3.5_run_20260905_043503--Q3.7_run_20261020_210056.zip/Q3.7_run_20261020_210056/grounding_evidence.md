# Data grounding evidence

- generated: 2026-10-20T21:26:12
- gate verdict: 147 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | GLOBlit_4997 | yes | INSP_33d54cf85a58, INSP_942f6268dd5f, INSP_d3978b936aac, INSP_d81b2ce3ce7d | 11 |
| PROPblock_2 | GLOBlit_1271 | yes | INSP_39220659004a, INSP_a9ecd5098faf, INSP_38a33696c8fe | 4 |
| PROPblock_3 | GLOBlit_1990 | yes | INSP_11b045341450, INSP_55a961167d2a | 9 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 258.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 288.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 120.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 364.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 258.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 288.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 120.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 364.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 283.145 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 323.141 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 308.6 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 997.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 280.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 330.126 | PROPblock_2 + PROPblock_3 + PROPblock_1 | uninspected_value | PROPblock_1 |
| 276.5 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1178.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | uninspected_value | PROPblock_1 |
| 20 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 20.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 303.146 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 373.137 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 578.14 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 3026.83 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1.35 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 4.84 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 298.221 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 338.102 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 499.4 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1434.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 8.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 293.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 323.14 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 427.4 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 997.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 5.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 5.3 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 15 | PROPblock_1 | ungrounded | — |
| 258.15 | PROPblock_2 | verified | — |
| 268.15 | PROPblock_2 | verified | — |
| 278.15 | PROPblock_2 | verified | — |
| 288.15 | PROPblock_2 | verified | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 382.51 | PROPblock_2 | misattributed | PROPblock_1 |
| 0.06 | PROPblock_2 | misattributed | PROPblock_1 |
| 486 | PROPblock_1 | misattributed | PROPblock_2 |
| 273.15 | PROPblock_2 | ungrounded | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 268.15 | PROPblock_2 | verified | — |
| 278.15 | PROPblock_2 | verified | — |
| 268.15 | PROPblock_2 | verified | — |
| 179.3 | PROPblock_2 | verified | — |
| 1.0 | PROPblock_2 | verified | — |
| 278.15 | PROPblock_2 | verified | — |
| 259.2 | PROPblock_2 | verified | — |
| 1.1 | PROPblock_2 | verified | — |
| 3.7292e-3 | PROPblock_2 | ungrounded | — |
| 179.3 | PROPblock_2 | verified | — |
| 5.1893 | PROPblock_2 | ungrounded | — |
| 3.5952e-3 | PROPblock_2 | ungrounded | — |
| 259.2 | PROPblock_2 | verified | — |
| 5.5578 | PROPblock_2 | ungrounded | — |
| 3.6610e-3 | PROPblock_2 | ungrounded | — |
| 3.6610 | PROPblock_2 | ungrounded | — |
| 3.7292 | PROPblock_2 | ungrounded | — |
| 3.5952 | PROPblock_2 | ungrounded | — |
| 3.7292 | PROPblock_2 | ungrounded | — |
| 0.509 | PROPblock_2 | ungrounded | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 5.1893 | PROPblock_2 | ungrounded | — |
| 0.509 | PROPblock_2 | ungrounded | — |
| 5.5578 | PROPblock_2 | ungrounded | — |
| 5.1893 | PROPblock_2 | ungrounded | — |
| 5.1893 | PROPblock_2 | ungrounded | — |
| 0.1876 | PROPblock_2 | ungrounded | — |
| 5.377 | PROPblock_2 | ungrounded | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 217 | PROPblock_2 | ungrounded | — |
| 1.0 | PROPblock_2 | verified | — |
| 1.1 | PROPblock_2 | verified | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 217 | PROPblock_2 | ungrounded | — |
| 276.5 | PROPblock_1 | verified | — |
| 280.15 | PROPblock_1 | verified | — |
| 20 | PROPblock_1 | verified | — |
| 308.6 | PROPblock_3 | verified | — |
| 283.145 | PROPblock_3 | verified | — |
| 1.1 | PROPblock_3 | verified | — |
| 271 | PROPblock_3 | ungrounded | — |
| 280.15 | PROPblock_3 | misattributed | PROPblock_1 |
| 306 | PROPblock_3 | ungrounded | — |
| 283.145 | PROPblock_3 | verified | — |
| 273.15 | PROPblock_3 | ungrounded | — |
| 258.15 | PROPblock_2 | verified | — |
| 268.15 | PROPblock_2 | verified | — |
| 278.15 | PROPblock_2 | verified | — |
| 288.15 | PROPblock_2 | verified | — |
| 120.2 | PROPblock_2 | verified | — |
| 179.3 | PROPblock_2 | verified | — |
| 259.2 | PROPblock_2 | verified | — |
| 364.2 | PROPblock_2 | verified | — |
| 258.15 | PROPblock_2 | verified | — |
| 268.15 | PROPblock_2 | verified | — |
| 23.0 | PROPblock_2 | ungrounded | — |
| 120.2 | PROPblock_2 | verified | — |
| 179.3 | PROPblock_2 | verified | — |
| 268.15 | PROPblock_2 | verified | — |
| 278.15 | PROPblock_2 | verified | — |
| 22.9 | PROPblock_2 | ungrounded | — |
| 179.3 | PROPblock_2 | verified | — |
| 259.2 | PROPblock_2 | verified | — |
| 278.15 | PROPblock_2 | verified | — |
| 288.15 | PROPblock_2 | verified | — |
| 22.7 | PROPblock_2 | ungrounded | — |
| 259.2 | PROPblock_2 | verified | — |
| 364.2 | PROPblock_2 | verified | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 268.15 | PROPblock_2 | verified | — |
| 278.15 | PROPblock_2 | verified | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 22.9 | PROPblock_2 | ungrounded | — |
| 0.3 | PROPblock_2 | verified | — |
| 0.1 | PROPblock_2 | verified | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 0.71 | PROPblock_2 | misattributed | PROPblock_1 |
| 273.15 | PROPblock_2 | ungrounded | — |
| 382.51 | PROPblock_3 | misattributed | PROPblock_1 |
| 373.137 | PROPblock_1 | misattributed | PROPblock_3 |
| 368.152 | PROPblock_3 | verified | — |
| 2741.03 | PROPblock_3 | verified | — |
| 373.137 | PROPblock_3 | verified | — |
| 3026.83 | PROPblock_3 | verified | — |
| 3026.83 | PROPblock_3 | verified | — |
| 2741.03 | PROPblock_3 | verified | — |
| -2750 | PROPblock_3 | ungrounded | — |
| 382.51 | PROPblock_3 | misattributed | PROPblock_1 |
| 3026.83 | PROPblock_3 | verified | — |
| -2750 | PROPblock_3 | ungrounded | — |
| 8.016 | PROPblock_3 | ungrounded | — |
| 0.182 | PROPblock_3 | ungrounded | — |
| 8.198 | PROPblock_3 | ungrounded | — |
| 8.198 | PROPblock_3 | ungrounded | — |
| 3640 | PROPblock_3 | ungrounded | — |
| 3.64 | PROPblock_3 | ungrounded | — |
| 353.142 | PROPblock_3 | verified | — |
| 2008.42 | PROPblock_3 | verified | — |
| 373.137 | PROPblock_3 | verified | — |
| 3026.83 | PROPblock_3 | verified | — |
| -2704 | PROPblock_3 | ungrounded | — |
| 8.195 | PROPblock_3 | ungrounded | — |
| 3627 | PROPblock_3 | ungrounded | — |
| 3.63 | PROPblock_3 | ungrounded | — |
| 13 | PROPblock_3 | verified | — |
| 50 | PROPblock_3 | ungrounded | — |
| 382.51 | PROPblock_3 | misattributed | PROPblock_1 |
| 3630 | PROPblock_3 | ungrounded | — |
| 50 | PROPblock_3 | ungrounded | — |
| 3.63 | PROPblock_3 | ungrounded | — |
| 0.05 | PROPblock_3 | verified | — |
| 3632 | PROPblock_3 | ungrounded | — |
| 288 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 364.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 364.7 | PROPblock_2 + PROPblock_3 + PROPblock_1 | uninspected_value | PROPblock_3 |
| 0.5 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 0.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 293 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 428.0 | PROPblock_2 + PROPblock_3 + PROPblock_1 | uninspected_value | PROPblock_3 |
| 427.4 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 0.6 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 0.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 298 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 499.0 | PROPblock_2 + PROPblock_3 + PROPblock_1 | uninspected_value | PROPblock_3 |
| 499.4 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 0.4 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 0.0 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 303 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 578.9 | PROPblock_2 + PROPblock_3 + PROPblock_1 | uninspected_value | PROPblock_3 |
| 577.6 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 578.14 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 584.6 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 7.0 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 313 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 767.4 | PROPblock_2 + PROPblock_3 + PROPblock_1 | uninspected_value | PROPblock_3 |
| 765.3 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 766.43 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 766.4 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 2.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 0.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 323 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 997.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 997.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 997.42 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 989.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 8.0 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 0.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 0.5 | PROPblock_3 | uninspected_value | PROPblock_3 |
| 8.1 | PROPblock_1 | verified | — |
| 20 | PROPblock_1 | verified | — |
| 276.5 | PROPblock_1 | verified | — |
| 280.15 | PROPblock_1 | verified | — |
| 271 | PROPblock_1 | ungrounded | — |
| 20 | PROPblock_1 | verified | — |
| 273.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 217 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 268.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 278.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 273.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 22.9 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 0.3 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 382.51 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 3630 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 3.63 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 50 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 0.05 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 330.126 | PROPblock_1 | uninspected_value | PROPblock_1 |
| 330.126 | GLOBlit_4997::PROPblock_1 | uninspected_value | PROPblock_1 |
| 1178.1 | PROPblock_1 | uninspected_value | PROPblock_1 |
| 1178.1 | GLOBlit_4997::PROPblock_1 | uninspected_value | PROPblock_1 |
| 15 | PROPblock_1 | ungrounded | — |
| 280.15 | PROPblock_1 | verified | — |
| 330.126 | PROPblock_1 | uninspected_value | PROPblock_1 |
| 276.5 | PROPblock_1 | verified | — |
| 1178.1 | PROPblock_1 | uninspected_value | PROPblock_1 |
| 20 | PROPblock_1 | verified | — |
| 20.1 | PROPblock_1 | uninspected_value | PROPblock_1 |
| 15 | PROPblock_1 | ungrounded | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 382.51 | PROPblock_2 | misattributed | PROPblock_1 |
| 382.51 | GLOBlit_4997::PROPblock_1 | verified | — |
| 0.06 | PROPblock_2 | misattributed | PROPblock_1 |
| 0.06 | GLOBlit_4997::PROPblock_1 | verified | — |
| 486 | PROPblock_1 | misattributed | PROPblock_2 |
| 486 | GLOBlit_1271::PROPblock_2 | verified | — |
| 74 | GLOBlit_1271::PROPblock_2 | ungrounded | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 3.7292e-3 | PROPblock_2 | ungrounded | — |
| 5.1893 | PROPblock_2 | ungrounded | — |
| 3.5952e-3 | PROPblock_2 | ungrounded | — |
| 5.5578 | PROPblock_2 | ungrounded | — |
| 3.6610e-3 | PROPblock_2 | ungrounded | — |
| 3.6610 | PROPblock_2 | ungrounded | — |
| 3.7292 | PROPblock_2 | ungrounded | — |
| 3.5952 | PROPblock_2 | ungrounded | — |
| 0.509 | PROPblock_2 | ungrounded | — |
| 0.1876 | PROPblock_2 | ungrounded | — |
| 5.377 | PROPblock_2 | ungrounded | — |
| 217 | PROPblock_2 | ungrounded | — |
| 23.0 | PROPblock_2 | ungrounded | — |
| 22.9 | PROPblock_2 | ungrounded | — |
| 22.7 | PROPblock_2 | ungrounded | — |
| 0.71 | PROPblock_2 | misattributed | PROPblock_1 |
| 271 | PROPblock_3 | ungrounded | — |
| 280.15 | PROPblock_3 | misattributed | PROPblock_1 |
| 306 | PROPblock_3 | ungrounded | — |
| 273.15 | PROPblock_3 | ungrounded | — |
| 382.51 | PROPblock_3 | misattributed | PROPblock_1 |
| -2750 | PROPblock_3 | ungrounded | — |
| 8.016 | PROPblock_3 | ungrounded | — |
| 0.182 | PROPblock_3 | ungrounded | — |
| 8.198 | PROPblock_3 | ungrounded | — |
| 3640 | PROPblock_3 | ungrounded | — |
| 3.64 | PROPblock_3 | ungrounded | — |
| -2704 | PROPblock_3 | ungrounded | — |
| 8.195 | PROPblock_3 | ungrounded | — |
| 3627 | PROPblock_3 | ungrounded | — |
| 3.63 | PROPblock_3 | ungrounded | — |
| 50 | PROPblock_3 | ungrounded | — |
| 3630 | PROPblock_3 | ungrounded | — |
| 3632 | PROPblock_3 | ungrounded | — |
| 0.5 | PROPblock_3 | uninspected_value | PROPblock_3 |
| 373.137 | PROPblock_1 | misattributed | PROPblock_3 |
| 271 | PROPblock_1 | ungrounded | — |
| 364.7 | PROPblock_1 | misattributed | PROPblock_3 |
| 428.0 | PROPblock_1 | misattributed | PROPblock_3 |
| 499.0 | PROPblock_1 | misattributed | PROPblock_3 |
| 578.9 | PROPblock_1 | misattributed | PROPblock_3 |
| 7.0 | PROPblock_1 | ungrounded | — |
| 767.4 | PROPblock_1 | misattributed | PROPblock_3 |
| 2.1 | PROPblock_1 | ungrounded | — |
| 273.15 | PROPblock_1 | ungrounded | — |
| 217 | PROPblock_1 | ungrounded | — |
| 22.9 | PROPblock_1 | ungrounded | — |
| 3630 | PROPblock_1 | ungrounded | — |
| 3.63 | PROPblock_1 | ungrounded | — |
| 50 | PROPblock_1 | ungrounded | — |

## Violations

- **UNINSPECTED_VALUE** PROPblock_2 + PROPblock_3 + PROPblock_1: 330.126 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** PROPblock_2 + PROPblock_3 + PROPblock_1: 1178.1 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 15 (near '…280.15–330.126 | 276.5–1178.1 | 20–20.1 | | 5 |   |   |   | …') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_1: 15 (near '…ected values from the respective blocks. The point count of …') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…These are the only blocks whose temperature ranges bracket 2…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **MISATTRIBUTED_VALUE** PROPblock_2: 382.51 does not belong to PROPblock_2; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_2: 0.06 does not belong to PROPblock_2; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 486 does not belong to PROPblock_1; it matches only GLOBlit_1271::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…**not reported** in ThermoML  ---  ### 1. Vapor Pressure at …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…) that bracket the target temperature of 273.15 K (a user-sp…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.7292e-3 (near '…derived from the two inspected points above): - 1/268.15 = 3…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.1893 (near '…cted points above): - 1/268.15 = 3.7292e-3 K-1; ln(179.3) = …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.5952e-3 (near '…- 1/268.15 = 3.7292e-3 K-1; ln(179.3) = 5.1893 - 1/278.15 = …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.5578 (near '…ln(179.3) = 5.1893 - 1/278.15 = 3.5952e-3 K-1; ln(259.2) = 5…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.6610e-3 (near '…- 1/278.15 = 3.5952e-3 K-1; ln(259.2) = 5.5578 - 1/273.15 = …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.6610 (near '…ved from the target temperature) - Interpolation fraction: (…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.7292 (near '…the target temperature) - Interpolation fraction: (3.6610 - …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.5952 (near '…t temperature) - Interpolation fraction: (3.6610 - 3.7292)/(…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.7292 (near '…ture) - Interpolation fraction: (3.6610 - 3.7292)/(3.5952 - …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 0.509 (near '…terpolation fraction: (3.6610 - 3.7292)/(3.5952 - 3.7292) = …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…3.6610 - 3.7292)/(3.5952 - 3.7292) = 0.509 (derived) - ln P(…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.1893 (near '…292)/(3.5952 - 3.7292) = 0.509 (derived) - ln P(273.15 K) = …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 0.509 (near '…952 - 3.7292) = 0.509 (derived) - ln P(273.15 K) = 5.1893 + …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.5578 (near '…292) = 0.509 (derived) - ln P(273.15 K) = 5.1893 + 0.509 × (…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.1893 (near '…509 (derived) - ln P(273.15 K) = 5.1893 + 0.509 × (5.5578 - …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.1893 (near '…ed) - ln P(273.15 K) = 5.1893 + 0.509 × (5.5578 - 5.1893) = …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 0.1876 (near '…P(273.15 K) = 5.1893 + 0.509 × (5.5578 - 5.1893) = 5.1893 + …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.377 (near '…K) = 5.1893 + 0.509 × (5.5578 - 5.1893) = 5.1893 + 0.1876 = …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…(5.5578 - 5.1893) = 5.1893 + 0.1876 = 5.377 (derived) - **P(…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 217 (near '…1893) = 5.1893 + 0.1876 = 5.377 (derived) - **P(273.15 K) ≈ …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…combined uncertainty is ±3 kPa (derived), yielding:  > **P(2…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 217 (near '…certainty is ±3 kPa (derived), yielding:  > **P(273.15 K) = …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_3: 271 (near '…t from the   bracketing points to these temperatures gives ~…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **MISATTRIBUTED_VALUE** PROPblock_3: 280.15 does not belong to PROPblock_3; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_3: 306 (near '…oints to these temperatures gives ~271 kPa at 280.15 K and ~…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 273.15 (near '…eir uncertainties.  ---  ### 2. Enthalpy of Vaporization at …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_2: 23.0 (near '…mol) | Derivation basis | |---|---|---| | 258.15 – 268.15 | …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 22.9 (near '…d) | From inspected 120.2 & 179.3 kPa | | 268.15 – 278.15 | …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 22.7 (near '…d) | From inspected 179.3 & 259.2 kPa | | 278.15 – 288.15 | …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…ing temperature as expected thermodynamically. The value at …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…15 K (midpoint of the 268.15–278.15 K pair) is:  > **ΔH_vap(…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 22.9 (near '…nt of the 268.15–278.15 K pair) is:  > **ΔH_vap(273.15 K) = …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…each 10 K interval. These are reasonable approximations at 2…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **MISATTRIBUTED_VALUE** PROPblock_2: 0.71 does not belong to PROPblock_2; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…K where the reduced temperature T/T_c ≈ 0.71 (derived from 2…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **MISATTRIBUTED_VALUE** PROPblock_3: 382.51 does not belong to PROPblock_3; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 373.137 does not belong to PROPblock_1; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_3: -2750 (near '…d): [ln(3026.83) - ln(2741.03)] / [1/373.137 - 1/368.152] = …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **MISATTRIBUTED_VALUE** PROPblock_3: 382.51 does not belong to PROPblock_3; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_3: -2750 (near '…(all following values derived):   ln(P_c) = ln(3026.83) + (-…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 8.016 (near '…:   ln(P_c) = ln(3026.83) + (-2750)(1/382.51 - 1/373.137) = …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 0.182 (near '…_c) = ln(3026.83) + (-2750)(1/382.51 - 1/373.137) = 8.016 + …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 8.198 (near '…(3026.83) + (-2750)(1/382.51 - 1/373.137) = 8.016 + 0.182 = …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 8.198 (near '…1/382.51 - 1/373.137) = 8.016 + 0.182 = 8.198 - **P_c ≈ exp(…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3640 (near '…- 1/373.137) = 8.016 + 0.182 = 8.198 - **P_c ≈ exp(8.198) ≈ …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3.64 (near '…) = 8.016 + 0.182 = 8.198 - **P_c ≈ exp(8.198) ≈ 3640 kPa ≈ …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: -2704 (near '…): - Slope = -2704 (derived); ln(P_c) = 8.195 (derived); P…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 8.195 (near '…): - Slope = -2704 (derived); ln(P_c) = 8.195 (derived); P_c…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3627 (near '…- Slope = -2704 (derived); ln(P_c) = 8.195 (derived); P_c ≈ …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3.63 (near '…2704 (derived); ln(P_c) = 8.195 (derived); P_c ≈ 3627 kPa ≈ …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 50 (near '…trapolation beyond the data, a conservative uncertainty is ±…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **MISATTRIBUTED_VALUE** PROPblock_3: 382.51 does not belong to PROPblock_3; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_3: 3630 (near '…tive uncertainty is ±50 kPa (derived):  > **P_c(382.51 K) ≈ …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 50 (near '…certainty is ±50 kPa (derived):  > **P_c(382.51 K) ≈ 3630 ± …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3.63 (near '…y is ±50 kPa (derived):  > **P_c(382.51 K) ≈ 3630 ± 50 kPa (…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3632 (near '…ROP value for R1234ze(E) critical pressure is approximately …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNINSPECTED_VALUE** PROPblock_2 + PROPblock_3 + PROPblock_1: 364.7 exists in PROPblock_3's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** PROPblock_2 + PROPblock_3 + PROPblock_1: 428.0 exists in PROPblock_3's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** PROPblock_2 + PROPblock_3 + PROPblock_1: 499.0 exists in PROPblock_3's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** PROPblock_2 + PROPblock_3 + PROPblock_1: 578.9 exists in PROPblock_3's database table but was never shown in an inspection of this run
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 7.0 (near '…(0.08%) | | ~303 | — | 578.9 | — | 577.6 | 578.14 | 584.6 | …') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNINSPECTED_VALUE** PROPblock_2 + PROPblock_3 + PROPblock_1: 767.4 exists in PROPblock_3's database table but was never shown in an inspection of this run
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 2.1 (near '…(1.2%) | | ~313 | — | 767.4 | — | 765.3 | 766.43 | 766.4 | 2…') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNINSPECTED_VALUE** PROPblock_3: 0.5 exists in PROPblock_3's database table but was never shown in an inspection of this run
- **UNGROUNDED_LITERAL** PROPblock_1: 271 (near '…K is consistent with the Clausius–Clapeyron prediction of ~2…') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 273.15 (near '…hod | Key inspected data source | |---|---|---|---|---| | P(…') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 217 (near '…spected data source | |---|---|---|---|---| | P(273.15 K) | …') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 273.15 (near '…tion |  ,   (inspected 268.15 & 278.15 K points) | | ΔH_vap(…') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 22.9 (near '…(inspected 268.15 & 278.15 K points) | | ΔH_vap(273.15 K) | …') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 3630 (near '…n slope |  ,   (all 4 inspected points) | | P_c(382.51 K) | …') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 3.63 (near '…,   (all 4 inspected points) | | P_c(382.51 K) | 3630 kPa / …') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 50 (near '…ints) | | P_c(382.51 K) | 3630 kPa / 3.63 MPa (derived) | ± …') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNINSPECTED_VALUE** PROPblock_1: 330.126 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** GLOBlit_4997::PROPblock_1: 330.126 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** PROPblock_1: 1178.1 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** GLOBlit_4997::PROPblock_1: 1178.1 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNGROUNDED_LITERAL** PROPblock_1: 15 (near '…: 15 (near '…280.15–330.126 | 276.5–1178.1 |…') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNINSPECTED_VALUE** PROPblock_1: 330.126 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** PROPblock_1: 1178.1 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** PROPblock_1: 20.1 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNGROUNDED_LITERAL** PROPblock_1: 15 (near '…: 15 (near '…ected values from the respectiv…') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…: 273.15 (near '…These are the only blocks whose…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **MISATTRIBUTED_VALUE** PROPblock_2: 382.51 does not belong to PROPblock_2; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_2: 0.06 does not belong to PROPblock_2; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 486 does not belong to PROPblock_1; it matches only GLOBlit_1271::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_1271::PROPblock_2: 74 (near '…::  — no new tool call needed` - … and 74 more of the same k…') matches no inspected row/stat, database table, or other source of GLOBlit_1271::PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…: 273.15, 3.7292e-3, 5.1893, 3.5952e-3, 5.5578,…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.7292e-3 (near '…: 273.15, 3.7292e-3, 5.1893, 3.5952e-3, 5.5578, 3.6610e-3,…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.1893 (near '…: 273.15, 3.7292e-3, 5.1893, 3.5952e-3, 5.5578, 3.6610e-3, 3…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.5952e-3 (near '…: 273.15, 3.7292e-3, 5.1893, 3.5952e-3, 5.5578, 3.6610e-3, 3…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.5578 (near '…: 273.15, 3.7292e-3, 5.1893, 3.5952e-3, 5.5578, 3.6610e-3, 3…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.6610e-3 (near '…: 273.15, 3.7292e-3, 5.1893, 3.5952e-3, 5.5578, 3.6610e-3, 3…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.6610 (near '…: 273.15, 3.7292e-3, 5.1893, 3.5952e-3, 5.5578, 3.6610e-3, 3…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.7292 (near '…5, 3.7292e-3, 5.1893, 3.5952e-3, 5.5578, 3.6610e-3, 3.6610, …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 3.5952 (near '…2e-3, 5.1893, 3.5952e-3, 5.5578, 3.6610e-3, 3.6610, 3.7292, …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 0.509 (near '…1893, 3.5952e-3, 5.5578, 3.6610e-3, 3.6610, 3.7292, 3.5952, …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 0.1876 (near '….5952e-3, 5.5578, 3.6610e-3, 3.6610, 3.7292, 3.5952, 0.509, …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 5.377 (near '…, 5.5578, 3.6610e-3, 3.6610, 3.7292, 3.5952, 0.509, 0.1876, …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 217 (near '…8, 3.6610e-3, 3.6610, 3.7292, 3.5952, 0.509, 0.1876, 5.377, …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 23.0 (near '…6610e-3, 3.6610, 3.7292, 3.5952, 0.509, 0.1876, 5.377, 217, …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 22.9 (near '…3, 3.6610, 3.7292, 3.5952, 0.509, 0.1876, 5.377, 217, 23.0, …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 22.7 (near '…610, 3.7292, 3.5952, 0.509, 0.1876, 5.377, 217, 23.0, 22.9, …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **MISATTRIBUTED_VALUE** PROPblock_2: 0.71 does not belong to PROPblock_2; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_3: 271 (near '…: 271, 280.15, 306, 273.15, 382.51, -2750, 8.…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **MISATTRIBUTED_VALUE** PROPblock_3: 280.15 does not belong to PROPblock_3; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_3: 306 (near '…: 271, 280.15, 306, 273.15, 382.51, -2750, 8.016, 0.182, 8…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 273.15 (near '…: 271, 280.15, 306, 273.15, 382.51, -2750, 8.016, 0.182, 8.1…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **MISATTRIBUTED_VALUE** PROPblock_3: 382.51 does not belong to PROPblock_3; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_3: -2750 (near '…: 271, 280.15, 306, 273.15, 382.51, -2750, 8.016, 0.182, 8.1…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 8.016 (near '…: 271, 280.15, 306, 273.15, 382.51, -2750, 8.016, 0.182, 8.1…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 0.182 (near '…: 271, 280.15, 306, 273.15, 382.51, -2750, 8.016, 0.182, 8.1…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 8.198 (near '…: 271, 280.15, 306, 273.15, 382.51, -2750, 8.016, 0.182, 8.1…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3640 (near '…1, 280.15, 306, 273.15, 382.51, -2750, 8.016, 0.182, 8.198, …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3.64 (near '….15, 306, 273.15, 382.51, -2750, 8.016, 0.182, 8.198, 3640, …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: -2704 (near '…06, 273.15, 382.51, -2750, 8.016, 0.182, 8.198, 3640, 3.64, …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 8.195 (near '….15, 382.51, -2750, 8.016, 0.182, 8.198, 3640, 3.64, -2704, …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3627 (near '…2.51, -2750, 8.016, 0.182, 8.198, 3640, 3.64, -2704, 8.195, …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3.63 (near '…-2750, 8.016, 0.182, 8.198, 3640, 3.64, -2704, 8.195, 3627, …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 50 (near '…8.016, 0.182, 8.198, 3640, 3.64, -2704, 8.195, 3627, 3.63, 5…') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3630 (near '…16, 0.182, 8.198, 3640, 3.64, -2704, 8.195, 3627, 3.63, 50, …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNGROUNDED_LITERAL** PROPblock_3: 3632 (near '…182, 8.198, 3640, 3.64, -2704, 8.195, 3627, 3.63, 50, 3630, …') matches no inspected row/stat, database table, or other source of PROPblock_3
- **UNINSPECTED_VALUE** PROPblock_3: 0.5 exists in PROPblock_3's database table but was never shown in an inspection of this run
- **MISATTRIBUTED_VALUE** PROPblock_1: 373.137 does not belong to PROPblock_1; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_1: 271 (near '…: 373.137, 271;…') matches no inspected row/stat, database table, or other source of PROPblock_1
- **MISATTRIBUTED_VALUE** PROPblock_1: 364.7 does not belong to PROPblock_1; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 428.0 does not belong to PROPblock_1; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 499.0 does not belong to PROPblock_1; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 578.9 does not belong to PROPblock_1; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_1: 7.0 (near '…: 364.7, 428.0, 499.0, 578.9, 7.0, 767.4, 2.1, 273.15, 217, …') matches no inspected row/stat, database table, or other source of PROPblock_1
- **MISATTRIBUTED_VALUE** PROPblock_1: 767.4 does not belong to PROPblock_1; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_1: 2.1 (near '…: 364.7, 428.0, 499.0, 578.9, 7.0, 767.4, 2.1, 273.15, 217, …') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_1: 273.15 (near '…: 364.7, 428.0, 499.0, 578.9, 7.0, 767.4, 2.1, 273.15, 217, …') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_1: 217 (near '…: 364.7, 428.0, 499.0, 578.9, 7.0, 767.4, 2.1, 273.15, 217, …') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_1: 22.9 (near '…: 364.7, 428.0, 499.0, 578.9, 7.0, 767.4, 2.1, 273.15, 217, …') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_1: 3630 (near '…7, 428.0, 499.0, 578.9, 7.0, 767.4, 2.1, 273.15, 217, 22.9, …') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_1: 3.63 (near '….0, 499.0, 578.9, 7.0, 767.4, 2.1, 273.15, 217, 22.9, 3630, …') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_1: 50 (near '…9.0, 578.9, 7.0, 767.4, 2.1, 273.15, 217, 22.9, 3630, 3.63, …') matches no inspected row/stat, database table, or other source of PROPblock_1

## Inspections (verbatim)

### INSP_39220659004a — GLOBlit_1271::PROPblock_2 (complete, 4 rows shown)

_structured envelope entry (no markdown)_

### INSP_a9ecd5098faf — GLOBlit_3800::PROPblock_2 (complete, 4 rows shown)

_structured envelope entry (no markdown)_

### INSP_33d54cf85a58 — GLOBlit_4997::PROPblock_1 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_11b045341450 — GLOBlit_1990::PROPblock_3 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_55a961167d2a — GLOBlit_2136::PROPblock_3 (rdp, 9 rows shown)

_structured envelope entry (no markdown)_

### INSP_942f6268dd5f — GLOBlit_11766::PROPblock_1 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_38a33696c8fe — GLOBlit_11766::PROPblock_2 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_d3978b936aac — GLOBlit_5488::PROPblock_1 (complete, 9 rows shown)

_structured envelope entry (no markdown)_

### INSP_d81b2ce3ce7d — GLOBlit_5520::PROPblock_1 (complete, 4 rows shown)

_structured envelope entry (no markdown)_
