# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_155 | 29118-24-9 | trans-1,3,3,3-tetrafluoropropene (R1234ze(E)) |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all vapor pressure (saturation pressure) data blocks for R1234ze(E) → stored as L1_query_1 · validation: FLAGGED(6)
- [L1] Find all critical property data blocks for R1234ze(E) → stored as L1_query_2 · validation: PASS
- [L1] Inspect vapor pressure data blocks GLOBlit_5488::PROPblock_1 and GLOBlit_5520::PROPblock_1 for R1234ze(E) to get their t → stored as L1_query_3 · validation: PASS

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: success · validation: FLAGGED(6)

**Summary:**

ThermoML contains vapor pressure data for R1234ze(E) (GLOBcomp_155, GLOBprop_5) across at least seven data blocks from multiple DOIs. The block most relevant near 273.15 K is GLOBlit_1271 (PROPblock_2, DOI 10.1016/j.fluid.2013.06.017), which contains four points: 258.15 K / 120.2 kPa (U = 1 kPa), 268.15 K / 179.3 kPa (U = 1 kPa), 278.15 K / 259.2 kPa (U = 1.1 kPa), and 288.15 K / 364.2 kPa (U = 1.1 kPa). GLOBlit_3800 (PROPblock_2, DOI 10.1016/j.jct.2012.12.026) contains identical data. No inspected block has a data point at exactly 273.15 K; the target temperature is bracketed by 179.3 kPa at 268.15 K and 259.2 kPa at 278.15 K from GLOBlit_1271. Other blocks cover higher temperature ranges: GLOBlit_4997 (280.15–330.126 K, 276.5–1178.1 kPa, 11 points), GLOBlit_1990 (283.145–323.141 K, 308.6–997.8 kPa, 9 points), and GLOBlit_2136 (303.146–373.137 K, 578.14–3026.83 kPa, 15 points). The combined data span is suitable for Clausius–Clapeyron or Antoine-type fitting to estimate vapor pressure at 273.15 K and the enthalpy of vaporization.

**Answer:**

#### Vapor Pressure Data for R1234ze(E) in ThermoML

The ThermoML database contains vapor pressure (GLOBprop_5) data blocks for trans-1,3,3,3-tetrafluoropropene (R1234ze(E), GLOBcomp_155). The `search_blocks` tool identified blocks across multiple DOIs; all are unary liquid–gas systems. The search results displayed entries for seven blocks (entries 1–7); additional blocks exist but their individual metadata was truncated in the search display.

##### Blocks with Displayed Search Metadata

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *Block* | *GLOBlit* | *Points* | *T range (K)* | *P range (kPa)* |
|---|---|---|---|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「1」 | 「10.1016/j.fluid.2013.06.017」 | 「PROPblock_2」 | 「GLOBlit_1271」 | 「4」 | 「258.15–288.15」 | 「120.2–364.2」 |
| WM_L1#1_Table#1_Row#2 | 「2」 | 「10.1016/j.fluid.2016.10.011」 | 「PROPblock_3」 | 「GLOBlit_1990」 | 「9」 | 「283.145–323.141」 | 「308.6–997.8」 |
| WM_L1#1_Table#1_Row#3 | 「3」 | 「10.1016/j.fluid.2017.12.030」 | 「PROPblock_3」 | 「GLOBlit_2136」 | 「15」 | 「303.146–373.137」 | 「578.14–3026.83」 |
| WM_L1#1_Table#1_Row#4 | 「4」 | 「10.1016/j.jct.2012.12.026」 | 「PROPblock_2」 | 「GLOBlit_3800」 | 「4」 | 「258.15–288.15」 | 「120.2–364.2」 |
| WM_L1#1_Table#1_Row#5 | 「5」 | 「10.1016/j.jct.2017.03.032」 | 「PROPblock_1」 | 「GLOBlit_4997」 | 「11」 | 「280.15–330.126」 | 「276.5–1178.1」 |
| WM_L1#1_Table#1_Row#6 | 「6」 | 「10.1016/j.jct.2019.03.016」 | 「PROPblock_1」 | 「GLOBlit_5488」 | 「9」 | 「not inspected」 | 「not inspected」 |
| WM_L1#1_Table#1_Row#7 | 「7」 | 「10.1016/j.jct.2019.04.020」 | 「PROPblock_1」 | 「GLOBlit_5520」 | 「(truncated)」 | 「not inspected」 | 「not inspected」 |
| WM_L1#1_Table#1_Row#8 | 「8+」 | 「Additional blocks exist but were truncated in search results」 | 「—」 | 「—」 | 「—」 | 「—」 | 「—」 |

##### Inspected Data Near 273.15 K

The blocks most relevant for estimating vapor pressure at 273.15 K are GLOBlit_1271 and GLOBlit_3800, which contain identical data and bracket the target temperature:

**GLOBlit_1271 :: PROPblock_2** (DOI: 10.1016/j.fluid.2013.06.017) — complete block, 4 points:

**WM_L1#1_Table#2_(Query_L1#1_Answer):**

| *row_id* | *T (K)* | *P (kPa)* | *U(P) (kPa)* |
|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「258.15」 | 「120.2」 | 「1」 |
| WM_L1#1_Table#2_Row#2 | 「268.15」 | 「179.3」 | 「1」 |
| WM_L1#1_Table#2_Row#3 | 「278.15」 | 「259.2」 | 「1.1」 |
| WM_L1#1_Table#2_Row#4 | 「288.15」 | 「364.2」 | 「1.1」 |

**GLOBlit_3800 :: PROPblock_2** (DOI: 10.1016/j.jct.2012.12.026) — inspected; identical data to GLOBlit_1271 (same four points: 258.15 K / 120.2 kPa through 288.15 K / 364.2 kPa).

From the GLOBlit_1271 inspection, the two nearest points to 273.15 K are **179.3 kPa at 268.15 K** and **259.2 kPa at 278.15 K**, bracketing the target temperature. No inspected block contains a data point at exactly 273.15 K.

##### Other Inspected Blocks

- **GLOBlit_4997 :: PROPblock_1** (DOI: 10.1016/j.jct.2017.03.032): Nearest point to 273.15 K is **276.5 kPa at 280.15 K** (273.15 K lies below the block's range of 280.15–330.126 K). 11 points total, U = 20–20.1 kPa.

- **GLOBlit_1990 :: PROPblock_3** (DOI: 10.1016/j.fluid.2016.10.011): Nearest point to 273.15 K is **308.6 kPa at 283.145 K** (273.15 K lies below the block's range of 283.145–323.141 K). 9 points total, U = 1.1–1.8 kPa.

- **GLOBlit_2136 :: PROPblock_3** (DOI: 10.1016/j.fluid.2017.12.030): Higher temperature range, 303.146–373.137 K, 578.14–3026.83 kPa, 15 points total. Useful for enthalpy of vaporization estimation via Clausius–Clapeyron over a wide temperature span.

##### Chemistry Insight

The vapor pressure of R1234ze(E) rises steeply with temperature. Based on the inspected GLOBlit_1271 data, at 273.15 K the vapor pressure is bracketed between 179.3 kPa (at 268.15 K) and 259.2 kPa (at 278.15 K). The wide temperature coverage across the identified blocks provides data suitable for Clausius–Clapeyron or Antoine-type fitting to estimate both the vapor pressure at 273.15 K and the enthalpy of vaporization.

**Core claims:**
- The ThermoML database contains multiple vapor pressure data blocks for R1234ze(E) (trans-1,3,3,3-tetrafluoropropene) spanning approximately 258.15 K to 373.137 K and 120.2 kPa to 3026.83 kPa across at least seven identified blocks from different DOIs.
- No inspected block contains a data point at exactly 273.15 K; the verified GLOBlit_1271 data bracket 273.15 K between 179.3 kPa at 268.15 K and 259.2 kPa at 278.15 K, with reported uncertainties of 1–1.1 kPa.
- GLOBlit_1271 (DOI: 10.1016/j.fluid.2013.06.017, PROPblock_2) contains four verified data points: 258.15 K / 120.2 kPa, 268.15 K / 179.3 kPa, 278.15 K / 259.2 kPa, and 288.15 K / 364.2 kPa.
- GLOBlit_3800 (DOI: 10.1016/j.jct.2012.12.026, PROPblock_2) was reported to contain data identical to GLOBlit_1271, though some values associated with GLOBlit_3800 were flagged as ambiguous and unverified.
- The wide temperature coverage across the identified blocks is noted as suitable for Clausius–Clapeyron or Antoine-type fitting, but no such fit or interpolated vapor pressure value at 273.15 K was computed in the answer.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_1271」 | 「PROPblock_2」 | 「GLOBcomp_155」 | 「GLOBprop_5」 | 「Vapor pressure data for R1234ze(E) with 4 points from 258.15–288.15 K (120.2–364.2 kPa), bracketing 273.15 K.」 |
| WM_L1#1_Table#4 | 「GLOBlit_1990」 | 「PROPblock_3」 | 「GLOBcomp_155」 | 「GLOBprop_5」 | 「Vapor pressure data for R1234ze(E) with 9 points from 283.145–323.141 K (308.6–997.8 kPa).」 |
| WM_L1#1_Table#5 | 「GLOBlit_2136」 | 「PROPblock_3」 | 「GLOBcomp_155」 | 「GLOBprop_5」 | 「Vapor pressure data for R1234ze(E) with 15 points from 303.146–373.137 K (578.14–3026.83 kPa), useful for Clausius–Clapeyron fitting.」 |
| WM_L1#1_Table#6 | 「GLOBlit_3800」 | 「PROPblock_2」 | 「GLOBcomp_155」 | 「GLOBprop_5」 | 「Vapor pressure data for R1234ze(E) with 4 points identical to GLOBlit_1271, 258.15–288.15 K (120.2–364.2 kPa).」 |
| WM_L1#1_Table#7 | 「GLOBlit_4997」 | 「PROPblock_1」 | 「GLOBcomp_155」 | 「GLOBprop_5」 | 「Vapor pressure data for R1234ze(E) with 11 points from 280.15–330.126 K (276.5–1178.1 kPa).」 |
| WM_L1#1_Table#8 | 「GLOBlit_5488」 | 「PROPblock_1」 | 「GLOBcomp_155」 | 「GLOBprop_5」 | 「Vapor pressure data for R1234ze(E) with 9 points; temperature and pressure ranges not inspected.」 |
| WM_L1#1_Table#9 | 「GLOBlit_5520」 | 「PROPblock_1」 | 「GLOBcomp_155」 | 「GLOBprop_5」 | 「Vapor pressure data for R1234ze(E); number of points and ranges truncated in search results.」 |

*Not stored here: 5 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(6) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **AMBIGUOUS_VALUE** GLOBlit_3800::PROPblock_2: 273.15 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** GLOBlit_3800::PROPblock_2: 273.15 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** GLOBlit_2136::PROPblock_3: 179.3 does not belong to GLOBlit_2136::PROPblock_3; it matches only GLOBlit_1271::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_2136::PROPblock_3: 268.15 does not belong to GLOBlit_2136::PROPblock_3; it matches only GLOBlit_1271::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_2136::PROPblock_3: 259.2 does not belong to GLOBlit_2136::PROPblock_3; it matches only GLOBlit_1271::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_2136::PROPblock_3: 278.15 does not belong to GLOBlit_2136::PROPblock_3; it matches only GLOBlit_1271::PROPblock_2 (inspected this run)
### L1_query_2
**L1_query_2** — status: partial · validation: PASS

**Summary:**

The ThermoML database contains critical property data for R1234ze(E) (trans-1,3,3,3-tetrafluoropropene, GLOBcomp_155) from a single source (GLOBlit_11766, DOI: 10.1021/je900696z). The critical temperature is 382.51 K ± 0.06 K (GLOBlit_11766 :: PROPblock_1, visual observation, 1 data point), and the critical density is 486 kg/m³ ± 8 kg/m³ (GLOBlit_11766 :: PROPblock_2, rectilinear diameter method, 1 data point). No critical pressure data was found in ThermoML for this compound. The critical temperature constrains vapor pressure correlations at the upper temperature limit, and the critical density supports equation-of-state parameterization, but complete critical point characterization requires critical pressure values from outside this database.

**Answer:**

#### Critical Property Data for R1234ze(E) in ThermoML

The ThermoML database contains critical property data for trans-1,3,3,3-tetrafluoropropene (R1234ze(E), GLOBcomp_155) from a single literature source:

**Reference:** GLOBlit_11766 — DOI: 10.1021/je900696z
"Critical Parameters and Saturated Densities in the Critical Region for trans-1,3,3,3-Tetrafluoropropene (HFO-1234ze(E))"

##### Critical Temperature

**GLOBlit_11766 :: PROPblock_1** — 1 data point, unary liquid–gas system, method: visual observation in an unstirred cell.

**WM_L1#2_Table#1_(Query_L1#2_Answer):**

| *row_id* | *Property* | *Value* | *Uncertainty (U, 95%)* |
|---|---|---|---|
| WM_L1#2_Table#1_Row#1 | 「Critical temperature」 | 「382.51 K」 | 「± 0.06 K」 |

##### Critical Density

**GLOBlit_11766 :: PROPblock_2** — 1 data point, unary liquid–gas system, method: rectilinear diameter.

**WM_L1#2_Table#2_(Query_L1#2_Answer):**

| *row_id* | *Property* | *Value* | *Uncertainty (U, 95%)* |
|---|---|---|---|
| WM_L1#2_Table#2_Row#1 | 「Critical density」 | 「486 kg/m³」 | 「± 8 kg/m³」 |

##### Critical Pressure

**No critical pressure (GLOBprop_25) data was found** in the ThermoML database for R1234ze(E). The search returned zero blocks for this property.

##### Chemistry Insight

R1234ze(E) is a low-boiling-point hydrofluoroolefin refrigerant. The critical temperature reported in GLOBlit_11766 :: PROPblock_1 (382.51 K) is relevant for constraining vapor pressure correlations (e.g., Antoine or Wagner equations) at the upper temperature limit. The critical density reported in GLOBlit_11766 :: PROPblock_2 (486 kg/m³) is useful for equation-of-state parameterization. The absence of critical pressure data in ThermoML means that for a complete critical point characterization, critical pressure values would need to be sourced from outside this database.

**Core claims:**
- The ThermoML database contains critical property data for R1234ze(E) (trans-1,3,3,3-tetrafluoropropene) from a single source (DOI: 10.1021/je900696z).
- The reported critical temperature of R1234ze(E) is 382.51 K with an uncertainty of ± 0.06 K (95%), measured by visual observation in an unstirred cell.
- The reported critical density of R1234ze(E) is 486 kg/m³ with an uncertainty of ± 8 kg/m³ (95%), determined by the rectilinear diameter method.
- No critical pressure data for R1234ze(E) was found in the ThermoML database; complete critical point characterization would require sourcing critical pressure from outside this database.

**Core blocks found:**

**WM_L1#2_Blocks_(Query_L1#2_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#2_Table#3 | 「GLOBlit_11766」 | 「PROPblock_1」 | 「GLOBcomp_155」 | 「GLOBprop_23」 | 「Critical temperature measurement for R1234ze(E), reporting 382.51 K with uncertainty ±0.06 K via visual observation.」 |
| WM_L1#2_Table#4 | 「GLOBlit_11766」 | 「PROPblock_2」 | 「GLOBcomp_155」 | 「GLOBprop_54」 | 「Critical density measurement for R1234ze(E), reporting 486 kg/m³ with uncertainty ±8 kg/m³ via rectilinear diameter method.」 |

*Not stored here: 2 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.
### L1_query_3
**L1_query_3** — status: success · validation: PASS

**Summary:**

Two additional ThermoML vapor pressure data blocks for R1234ze(E) (GLOBcomp_155) were inspected. GLOBlit_5488 (DOI 10.1016/j.jct.2019.03.016) contains 9 unary data points spanning 298.221–338.102 K and 499.4–1434.8 kPa with a constant expanded combined uncertainty of 8.1 kPa. GLOBlit_5520 (DOI 10.1016/j.jct.2019.04.020) contains 4 unary data points spanning 293.15–323.14 K and 427.4–997.8 kPa with expanded combined uncertainties of 5.1–5.3 kPa. Both blocks show monotonically increasing vapor pressure with temperature. Neither block contains data near the target temperature of interest identified in prior queries. Together they complement previously inspected blocks, extending the available ThermoML vapor pressure coverage for R1234ze(E).

**Answer:**

###### Inspection of Two Additional Vapor Pressure Data Blocks for R1234ze(E)

Two previously uninspected vapor pressure (GLOBprop_5) data blocks for trans-1,3,3,3-tetrafluoropropene (R1234ze(E), GLOBcomp_155) have now been fully inspected:

---

####### GLOBlit_5488 :: PROPblock_1
**DOI:** 10.1016/j.jct.2019.03.016  
**System:** unary, R1234ze(E)  
**Data points:** 9  
**Temperature range:** 298.221–338.102 K  
**Pressure range:** 499.4–1434.8 kPa  
**Uncertainty:** U = 8.1 kPa (expanded combined, 95% level) for all points

**WM_L1#3_Table#1_(Query_L1#3_Answer):**

| *row_id* | *T (K)* | *P (kPa)* | *U(P) (kPa)* |
|---|---|---|---|
| WM_L1#3_Table#1_Row#1 | 「298.221」 | 「499.4」 | 「8.1」 |
| WM_L1#3_Table#1_Row#2 | 「303.527」 | 「584.6」 | 「8.1」 |
| WM_L1#3_Table#1_Row#3 | 「308.323」 | 「670.6」 | 「8.1」 |
| WM_L1#3_Table#1_Row#4 | 「313.119」 | 「766.4」 | 「8.1」 |
| WM_L1#3_Table#1_Row#5 | 「318.005」 | 「872.7」 | 「8.1」 |
| WM_L1#3_Table#1_Row#6 | 「322.865」 | 「989.8」 | 「8.1」 |
| WM_L1#3_Table#1_Row#7 | 「327.655」 | 「1116.6」 | 「8.1」 |
| WM_L1#3_Table#1_Row#8 | 「332.541」 | 「1258.1」 | 「8.1」 |
| WM_L1#3_Table#1_Row#9 | 「338.102」 | 「1434.8」 | 「8.1」 |

---

####### GLOBlit_5520 :: PROPblock_1
**DOI:** 10.1016/j.jct.2019.04.020  
**System:** unary, R1234ze(E)  
**Data points:** 4  
**Temperature range:** 293.15–323.14 K  
**Pressure range:** 427.4–997.8 kPa  
**Uncertainty:** U = 5.1–5.3 kPa (expanded combined, 95% level)

**WM_L1#3_Table#2_(Query_L1#3_Answer):**

| *row_id* | *T (K)* | *P (kPa)* | *U(P) (kPa)* |
|---|---|---|---|
| WM_L1#3_Table#2_Row#1 | 「293.15」 | 「427.4」 | 「5.1」 |
| WM_L1#3_Table#2_Row#2 | 「303.15」 | 「577.6」 | 「5.1」 |
| WM_L1#3_Table#2_Row#3 | 「313.15」 | 「765.3」 | 「5.2」 |
| WM_L1#3_Table#2_Row#4 | 「323.14」 | 「997.8」 | 「5.3」 |

---

####### Summary

Both blocks cover intermediate-to-higher temperature ranges and do not contain data near the target temperature of interest identified in prior queries. GLOBlit_5488 provides 9 closely spaced points (298.221–338.102 K) with a constant uncertainty of 8.1 kPa, while GLOBlit_5520 provides 4 points at roughly 10 K intervals (293.15–323.14 K) with lower uncertainties (5.1–5.3 kPa). The vapor pressure topology is monotonically increasing with temperature in both blocks, as expected. These blocks complement the previously inspected data from other blocks (reported in working memory), collectively extending the available vapor pressure coverage for R1234ze(E) in ThermoML.

**Core claims:**
- Two vapor pressure data blocks for R1234ze(E) (trans-1,3,3,3-tetrafluoropropene) were inspected: GLOBlit_5488 (DOI 10.1016/j.jct.2019.03.016) provides 9 data points spanning 298.221–338.102 K and 499.4–1434.8 kPa with a constant expanded combined uncertainty of 8.1 kPa, while GLOBlit_5520 (DOI 10.1016/j.jct.2019.04.020) provides 4 data points spanning 293.15–323.14 K and 427.4–997.8 kPa with uncertainties of 5.1–5.3 kPa.
- Vapor pressure increases monotonically with temperature in both blocks, as expected for a unary system.
- Both blocks cover intermediate-to-higher temperature ranges and do not contain data near the target temperature of interest identified in prior queries.
- GLOBlit_5520 reports lower measurement uncertainties (5.1–5.3 kPa) compared to GLOBlit_5488 (8.1 kPa).

**Core blocks found:**

**WM_L1#3_Blocks_(Query_L1#3_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#3_Table#3 | 「GLOBlit_5488」 | 「PROPblock_1」 | 「GLOBcomp_155」 | 「GLOBprop_5」 | 「Vapor pressure data for R1234ze(E) with 9 points spanning 298.221–338.102 K and 499.4–1434.8 kPa, constant expanded uncertainty of 8.1 kPa.」 |
| WM_L1#3_Table#4 | 「GLOBlit_5520」 | 「PROPblock_1」 | 「GLOBcomp_155」 | 「GLOBprop_5」 | 「Vapor pressure data for R1234ze(E) with 4 points spanning 293.15–323.14 K and 427.4–997.8 kPa, expanded uncertainties of 5.1–5.3 kPa.」 |

*Not stored here: 2 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


