# Delegated query run — result

**Question:** Find all vapor pressure (saturation pressure) data blocks and critical property data blocks for GLOBcomp_155 (trans-1,3,3,3-tetrafluoropropene, R1234ze(E)). I need the block IDs, DOIs, temperature ranges, and number of data points for each block.

**Iterations:** 3  |  **Elapsed:** 458.8s  |  **Tools:** 4  |  **Timed out:** False

---

## Answer

## Vapor Pressure and Critical Property Data for R1234ze(E) in ThermoML

### Compound
**trans-1,3,3,3-Tetrafluoropropene (R1234ze(E))** — CAS 29118-24-9, formula C₃H₂F₄

---

### Vapor Pressure Data Blocks (GLOBprop_5)

Seven data blocks containing pure-component vapor/sublimation pressure measurements were identified and inspected:

| # | Literature ID | Block | DOI | Points | T range (K) | P range (kPa) | Uncertainty |
|---|---|---|---|---:|---|---|---|
| 1 | GLOBlit_1271 | PROPblock_2 | 10.1016/j.fluid.2013.06.017 | 4 | 258.15–288.15 | 120.2–364.2 | 1–1.1 kPa |
| 2 | GLOBlit_3800 | PROPblock_2 | 10.1016/j.jct.2012.12.026 | 4 | 258.15–288.15 | 120.2–364.2 | 1–1.1 kPa |
| 3 | GLOBlit_1990 | PROPblock_3 | 10.1016/j.fluid.2016.10.011 | 9 | 283.145–323.141 | 308.6–997.8 | 1.1–1.8 kPa |
| 4 | GLOBlit_4997 | PROPblock_1 | 10.1016/j.jct.2017.03.032 | 11 | 280.15–330.126 | 276.5–1178.1 | 20–20.1 kPa |
| 5 | GLOBlit_2136 | PROPblock_3 | 10.1016/j.fluid.2017.12.030 | 15 | 303.146–373.137 | 578.14–3026.83 | — |
| 6 | GLOBlit_5488 | PROPblock_1 | 10.1016/j.jct.2019.03.016 | 9 | 298.221–338.102 | 499.4–1434.8 | 8.1 kPa |
| 7 | GLOBlit_5520 | PROPblock_1 | 10.1016/j.jct.2019.04.020 | 4 | 293.15–323.14 | 427.4–997.8 | 5.1–5.3 kPa |

**Total: 56 data points** across 7 blocks from 7 DOIs, spanning **258.15–373.137 K** and **120.2–3026.83 kPa**.

**Note:** GLOBlit_1271 and GLOBlit_3800 contain identical data (same four T/P pairs). These two blocks provide the lowest-temperature data and are the only ones that bracket 273.15 K.

#### Data Nearest to 273.15 K

From GLOBlit_1271 (PROPblock_2, DOI: 10.1016/j.fluid.2013.06.017):

| T (K) | P (kPa) | U(P) (kPa) |
|------:|--------:|----------:|
| 258.15 | 120.2 | 1 |
| 268.15 | 179.3 | 1 |
| 278.15 | 259.2 | 1.1 |
| 288.15 | 364.2 | 1.1 |

No block contains a measurement at exactly 273.15 K. The target temperature is bracketed between **179.3 kPa at 268.15 K** and **259.2 kPa at 278.15 K**.

---

### Critical Property Data

A single literature source was found:

**GLOBlit_11766** — DOI: 10.1021/je900696z

| Block | Property | Value | Uncertainty (95%) | Method |
|---|---|---|---|---|
| PROPblock_1 | Critical temperature | 382.51 K | ± 0.06 K | Visual observation (unstirred cell) |
| PROPblock_2 | Critical density | 486 kg/m³ | ± 8 kg/m³ | Rectilinear diameter |

**No critical pressure data was found** in the ThermoML database for R1234ze(E).

---

### Chemistry Insight

R1234ze(E) is a low-GWP hydrofluoroolefin refrigerant being adopted as a replacement for R-134a. Its vapor pressure rises steeply with temperature — from 120.2 kPa at 258.15 K to 3026.83 kPa at 373.137 K across the collected data, approaching the critical temperature of 382.51 K. The wide temperature coverage (258.15–373.137 K, spanning ~115 K) across the seven identified blocks is well suited for Clausius–Clapeyron or Antoine-type fitting to estimate the vapor pressure at 273.15 K and the enthalpy of vaporization. The absence of critical pressure in ThermoML means that complete critical-point characterization would require supplementary data from other sources.

### Core claims

- Seven ThermoML data blocks from seven DOIs provide a total of 56 pure-component vapor pressure data points for trans-1,3,3,3-tetrafluoropropene (R1234ze(E), CAS 29118-24-9), spanning 258.15–373.137 K and 120.2–3026.83 kPa.
- GLOBlit_1271 and GLOBlit_3800 contain identical data (same four T/P pairs) and are the only blocks that bracket 273.15 K, with 179.3 kPa at 268.15 K and 259.2 kPa at 278.15 K; no block contains a measurement at exactly 273.15 K.
- A single ThermoML source (GLOBlit_11766, DOI 10.1021/je900696z) reports a critical temperature of 382.51 K (± 0.06 K) and a critical density of 486 kg/m³ (± 8 kg/m³) for R1234ze(E); no critical pressure data was found in the ThermoML database.
- The absence of critical pressure in ThermoML means complete critical-point characterization of R1234ze(E) would require supplementary data from other sources.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_1271 | 10.1016/j.fluid.2013.06.017 | PROPblock_2 |  | Provides 4 vapor pressure data points for R1234ze(E) from 258.15–288.15 K (120.2–364.2 kPa), which bracket 273.15 K and supply the lowest-temperature coverage among all blocks. |
| GLOBlit_3800 | 10.1016/j.jct.2012.12.026 | PROPblock_2 |  | Provides 4 vapor pressure data points identical in range (258.15–288.15 K, 120.2–364.2 kPa) to GLOBlit_1271; the answer correctly notes the duplication and uses both as independent literature sources. |
| GLOBlit_1990 | 10.1016/j.fluid.2016.10.011 | PROPblock_3 |  | Contributes 9 vapor pressure points for R1234ze(E) over 283.145–323.141 K (308.6–997.8 kPa), extending coverage above the low-temperature blocks and supporting Antoine/Clausius–Clapeyron fitting. |
| GLOBlit_4997 | 10.1016/j.jct.2017.03.032 | PROPblock_1 |  | Supplies 11 vapor pressure data points over 280.15–330.126 K (276.5–1178.1 kPa), adding breadth to the dataset and overlapping with other blocks for cross-validation. |
| GLOBlit_2136 | 10.1016/j.fluid.2017.12.030 | PROPblock_3 |  | Provides 15 vapor pressure points at higher temperatures (303.146–373.137 K, 578.14–3026.83 kPa), extending coverage toward the critical point and contributing the most data points of any single block. |
| GLOBlit_5488 | 10.1016/j.jct.2019.03.016 | PROPblock_1 |  | Contributes 9 vapor pressure data points over 298.221–338.102 K (499.4–1434.8 kPa) measured via ISOPVT method, providing an independent methodology cross-check. |
| GLOBlit_5520 | 10.1016/j.jct.2019.04.020 | PROPblock_1 |  | Adds 4 vapor pressure points over 293.15–323.14 K (427.4–997.8 kPa), supplementing the mid-range temperature coverage for R1234ze(E). |
| GLOBlit_11766 | 10.1021/je900696z | PROPblock_1 |  | Provides the critical temperature of R1234ze(E) as 382.51 K ± 0.06 K by visual observation, directly supporting the critical property section of the answer. |
| GLOBlit_11766 | 10.1021/je900696z | PROPblock_2 |  | Provides the critical density of R1234ze(E) as 486 kg/m³ ± 8 kg/m³ by rectilinear diameter method, completing the available critical property data reported in the answer. |

### Suggested follow-ups

- Perform Clausius-Clapeyron interpolation using the GLOBlit_1271 data points at 268.15 K and 278.15 K to estimate the vapor pressure at 273.15 K.
- Fit an Antoine equation to all 56 vapor pressure data points across the seven blocks to obtain a continuous vapor pressure curve and estimate enthalpy of vaporization.
- Search external databases (e.g., NIST WebBook, REFPROP) for the critical pressure of R1234ze(E), since no critical pressure data was found in ThermoML.
- Investigate whether the duplicate data in GLOBlit_1271 and GLOBlit_3800 should be deduplicated before fitting to avoid biasing the regression.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_155",
    "registry_id": "29118-24-9",
    "name": "trans-1,3,3,3-tetrafluoropropene (R1234ze(E))"
  }
]
```

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1016/j.fluid.2013.06.017",
    "block_number": "PROPblock_2",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "258.15",
        "vapor_or_sublimation_pressure_kpa": "120.2",
        "vapor_or_sublimation_pressure_kpa_U": "1"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "268.15",
        "vapor_or_sublimation_pressure_kpa": "179.3",
        "vapor_or_sublimation_pressure_kpa_U": "1"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "278.15",
        "vapor_or_sublimation_pressure_kpa": "259.2",
        "vapor_or_sublimation_pressure_kpa_U": "1.1"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "288.15",
        "vapor_or_sublimation_pressure_kpa": "364.2",
        "vapor_or_sublimation_pressure_kpa_U": "1.1"
      }
    ],
    "inspection_id": "INSP_39220659004a",
    "lit_num_id": "GLOBlit_1271"
  },
  {
    "doi": "10.1016/j.jct.2012.12.026",
    "block_number": "PROPblock_2",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "258.15",
        "vapor_or_sublimation_pressure_kpa": "120.2",
        "vapor_or_sublimation_pressure_kpa_U": "1"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "268.15",
        "vapor_or_sublimation_pressure_kpa": "179.3",
        "vapor_or_sublimation_pressure_kpa_U": "1"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "278.15",
        "vapor_or_sublimation_pressure_kpa": "259.2",
        "vapor_or_sublimation_pressure_kpa_U": "1.1"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "288.15",
        "vapor_or_sublimation_pressure_kpa": "364.2",
        "vapor_or_sublimation_pressure_kpa_U": "1.1"
      }
    ],
    "inspection_id": "INSP_a9ecd5098faf",
    "lit_num_id": "GLOBlit_3800"
  },
  {
    "doi": "10.1016/j.jct.2017.03.032",
    "block_number": "PROPblock_1",
    "table_mode": "nearest",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "280.15",
        "vapor_or_sublimation_pressure_kpa": "276.5",
        "vapor_or_sublimation_pressure_kpa_U": "20"
      }
    ],
    "inspection_id": "INSP_33d54cf85a58",
    "lit_num_id": "GLOBlit_4997"
  },
  {
    "doi": "10.1016/j.fluid.2016.10.011",
    "block_number": "PROPblock_3",
    "table_mode": "nearest",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "283.145",
        "vapor_or_sublimation_pressure_kpa": "308.6",
        "vapor_or_sublimation_pressure_kpa_U": "1.1"
      }
    ],
    "inspection_id": "INSP_11b045341450",
    "lit_num_id": "GLOBlit_1990"
  },
  {
    "doi": "10.1016/j.fluid.2017.12.030",
    "block_number": "PROPblock_3",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "303.146",
        "vapor_or_sublimation_pressure_kpa": "578.14",
        "vapor_or_sublimation_pressure_kpa_U": "1.35"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "313.139",
        "vapor_or_sublimation_pressure_kpa": "766.43",
        "vapor_or_sublimation_pressure_kpa_U": "1.54"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "323.139",
        "vapor_or_sublimation_pressure_kpa": "997.42",
        "vapor_or_sublimation_pressure_kpa_U": "1.81"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "333.139",
        "vapor_or_sublimation_pressure_kpa": "1276.95",
        "vapor_or_sublimation_pressure_kpa_U": "2.16"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "343.128",
        "vapor_or_sublimation_pressure_kpa": "1611.05",
        "vapor_or_sublimation_pressure_kpa_U": "2.61"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "353.142",
        "vapor_or_sublimation_pressure_kpa": "2008.42",
        "vapor_or_sublimation_pressure_kpa_U": "3.24"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "358.144",
        "vapor_or_sublimation_pressure_kpa": "2233.01",
        "vapor_or_sublimation_pressure_kpa_U": "3.6"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "temperature_k": "368.152",
        "vapor_or_sublimation_pressure_kpa": "2741.03",
        "vapor_or_sublimation_pressure_kpa_U": "4.4"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "temperature_k": "373.137",
        "vapor_or_sublimation_pressure_kpa": "3026.83",
        "vapor_or_sublimation_pressure_kpa_U": "4.84"
      }
    ],
    "inspection_id": "INSP_55a961167d2a",
    "lit_num_id": "GLOBlit_2136"
  },
  {
    "doi": "10.1021/je900696z",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "critical_temperature_k",
      "critical_temperature_k_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "critical_temperature_k": "382.51",
        "critical_temperature_k_U": "0.06"
      }
    ],
    "inspection_id": "INSP_942f6268dd5f",
    "lit_num_id": "GLOBlit_11766"
  },
  {
    "doi": "10.1021/je900696z",
    "block_number": "PROPblock_2",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "critical_density_kg_m3",
      "critical_density_kg_m3_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "critical_density_kg_m3": "486",
        "critical_density_kg_m3_U": "8"
      }
    ],
    "inspection_id": "INSP_38a33696c8fe",
    "lit_num_id": "GLOBlit_11766"
  },
  {
    "doi": "10.1016/j.jct.2019.03.016",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "338.102",
        "vapor_or_sublimation_pressure_kpa": "1434.8",
        "vapor_or_sublimation_pressure_kpa_U": "8.1"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "332.541",
        "vapor_or_sublimation_pressure_kpa": "1258.1",
        "vapor_or_sublimation_pressure_kpa_U": "8.1"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "327.655",
        "vapor_or_sublimation_pressure_kpa": "1116.6",
        "vapor_or_sublimation_pressure_kpa_U": "8.1"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "322.865",
        "vapor_or_sublimation_pressure_kpa": "989.8",
        "vapor_or_sublimation_pressure_kpa_U": "8.1"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "318.005",
        "vapor_or_sublimation_pressure_kpa": "872.7",
        "vapor_or_sublimation_pressure_kpa_U": "8.1"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "313.119",
        "vapor_or_sublimation_pressure_kpa": "766.4",
        "vapor_or_sublimation_pressure_kpa_U": "8.1"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "308.323",
        "vapor_or_sublimation_pressure_kpa": "670.6",
        "vapor_or_sublimation_pressure_kpa_U": "8.1"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "303.527",
        "vapor_or_sublimation_pressure_kpa": "584.6",
        "vapor_or_sublimation_pressure_kpa_U": "8.1"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "298.221",
        "vapor_or_sublimation_pressure_kpa": "499.4",
        "vapor_or_sublimation_pressure_kpa_U": "8.1"
      }
    ],
    "inspection_id": "INSP_d3978b936aac",
    "lit_num_id": "GLOBlit_5488"
  },
  {
    "doi": "10.1016/j.jct.2019.04.020",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "293.15",
        "vapor_or_sublimation_pressure_kpa": "427.4",
        "vapor_or_sublimation_pressure_kpa_U": "5.1"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "303.15",
        "vapor_or_sublimation_pressure_kpa": "577.6",
        "vapor_or_sublimation_pressure_kpa_U": "5.1"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "765.3",
        "vapor_or_sublimation_pressure_kpa_U": "5.2"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "323.14",
        "vapor_or_sublimation_pressure_kpa": "997.8",
        "vapor_or_sublimation_pressure_kpa_U": "5.3"
      }
    ],
    "inspection_id": "INSP_d81b2ce3ce7d",
    "lit_num_id": "GLOBlit_5520"
  }
]
```
