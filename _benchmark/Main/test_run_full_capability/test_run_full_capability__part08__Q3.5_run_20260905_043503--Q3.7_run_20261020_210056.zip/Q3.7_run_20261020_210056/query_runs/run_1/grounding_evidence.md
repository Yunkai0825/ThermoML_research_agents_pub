# Data grounding evidence

- generated: 2026-10-20T21:12:24
- gate verdict: 17 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | GLOBlit_4997 | yes | INSP_33d54cf85a58, INSP_942f6268dd5f, INSP_d3978b936aac, INSP_d81b2ce3ce7d | 11 |
| PROPblock_2 | GLOBlit_1271 | yes | INSP_39220659004a, INSP_a9ecd5098faf, INSP_38a33696c8fe | 4 |
| PROPblock_3 | GLOBlit_1990 | yes | INSP_11b045341450, INSP_55a961167d2a | 9 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 258.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 288.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 120.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 364.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 258.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 288.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 120.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 364.2 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 283.145 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 323.141 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 308.6 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 997.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 280.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 330.126 | PROPblock_2 + PROPblock_3 + PROPblock_1 | uninspected_value | PROPblock_1 |
| 276.5 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1178.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | uninspected_value | PROPblock_1 |
| 20 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 20.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | ungrounded | — |
| 303.146 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 373.137 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 578.14 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 3026.83 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 298.221 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 338.102 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 499.4 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 1434.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 8.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 293.15 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 323.14 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 427.4 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 997.8 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 5.1 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 5.3 | PROPblock_2 + PROPblock_3 + PROPblock_1 | verified | — |
| 56 | PROPblock_1 | ungrounded | — |
| 258.15 | PROPblock_1 | misattributed | PROPblock_2 |
| 373.137 | PROPblock_1 | misattributed | PROPblock_3 |
| 120.2 | PROPblock_1 | misattributed | PROPblock_2 |
| 3026.83 | PROPblock_1 | misattributed | PROPblock_3 |
| 273.15 | PROPblock_1 | ungrounded | — |
| 273.15 | PROPblock_1 | ungrounded | — |
| 258.15 | PROPblock_2 | verified | — |
| 120.2 | PROPblock_2 | verified | — |
| 268.15 | PROPblock_2 | verified | — |
| 179.3 | PROPblock_2 | verified | — |
| 278.15 | PROPblock_2 | verified | — |
| 259.2 | PROPblock_2 | verified | — |
| 1.1 | PROPblock_2 | verified | — |
| 288.15 | PROPblock_2 | verified | — |
| 364.2 | PROPblock_2 | verified | — |
| 1.1 | PROPblock_2 | verified | — |
| 273.15 | PROPblock_2 | ungrounded | — |
| 179.3 | PROPblock_2 | verified | — |
| 268.15 | PROPblock_2 | verified | — |
| 259.2 | PROPblock_2 | verified | — |
| 278.15 | PROPblock_2 | verified | — |
| 382.51 | PROPblock_1 + PROPblock_2 | verified | — |
| 0.06 | PROPblock_1 + PROPblock_2 | verified | — |
| 486 | PROPblock_1 + PROPblock_2 | verified | — |
| 120.2 | PROPblock_2 | verified | — |
| 258.15 | PROPblock_2 | verified | — |
| 3026.83 | PROPblock_2 | misattributed | PROPblock_3 |
| 373.137 | PROPblock_2 | misattributed | PROPblock_3 |
| 382.51 | PROPblock_2 | misattributed | PROPblock_1 |
| 258.15 | PROPblock_2 | verified | — |
| 373.137 | PROPblock_2 | misattributed | PROPblock_3 |
| 115 | PROPblock_2 | ungrounded | — |
| 273.15 | PROPblock_2 | ungrounded | — |

## Violations

- **UNINSPECTED_VALUE** PROPblock_2 + PROPblock_3 + PROPblock_1: 330.126 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNINSPECTED_VALUE** PROPblock_2 + PROPblock_3 + PROPblock_1: 1178.1 exists in PROPblock_1's database table but was never shown in an inspection of this run
- **UNGROUNDED_LITERAL** PROPblock_2 + PROPblock_3 + PROPblock_1: 15 (near '…15–330.126 | 276.5–1178.1 | 20–20.1 kPa | | 5 |   |   |   | …') matches no inspected row/stat, database table, or other source of PROPblock_2 + PROPblock_3 + PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_1: 56 (near '…**Total: 56 data points** across 7 blocks from 7 DO…') matches no inspected row/stat, database table, or other source of PROPblock_1
- **MISATTRIBUTED_VALUE** PROPblock_1: 258.15 does not belong to PROPblock_1; it matches only GLOBlit_1271::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 373.137 does not belong to PROPblock_1; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 120.2 does not belong to PROPblock_1; it matches only GLOBlit_1271::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_1: 3026.83 does not belong to PROPblock_1; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_1: 273.15 (near '…lowest-temperature data and are the only ones that bracket 2…') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_1: 273.15 (near '…the only ones that bracket 273.15 K.  #### Data Nearest to 2…') matches no inspected row/stat, database table, or other source of PROPblock_1
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…No block contains a measurement at exactly 273.15 K. The tar…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **MISATTRIBUTED_VALUE** PROPblock_2: 3026.83 does not belong to PROPblock_2; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_2: 373.137 does not belong to PROPblock_2; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_2: 382.51 does not belong to PROPblock_2; it matches only GLOBlit_4997::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_2: 373.137 does not belong to PROPblock_2; it matches only GLOBlit_1990::PROPblock_3 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_2: 115 (near '…The wide temperature coverage (258.15–373.137 K, spanning ~1…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_2: 273.15 (near '…n or Antoine-type fitting to estimate the vapor pressure at …') matches no inspected row/stat, database table, or other source of PROPblock_2

## Inspections (verbatim)

### INSP_39220659004a — GLOBlit_1271::PROPblock_2 (complete, 4 rows shown)

_structured envelope entry (no markdown)_

### INSP_a9ecd5098faf — GLOBlit_3800::PROPblock_2 (complete, 4 rows shown)

_structured envelope entry (no markdown)_

### INSP_33d54cf85a58 — GLOBlit_4997::PROPblock_1 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_11b045341450 — GLOBlit_1990::PROPblock_3 (nearest, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_55a961167d2a — GLOBlit_2136::PROPblock_3 (rdp, 9 rows shown)

_structured envelope entry (no markdown)_

### INSP_942f6268dd5f — GLOBlit_11766::PROPblock_1 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_38a33696c8fe — GLOBlit_11766::PROPblock_2 (complete, 1 rows shown)

_structured envelope entry (no markdown)_

### INSP_d3978b936aac — GLOBlit_5488::PROPblock_1 (complete, 9 rows shown)

_structured envelope entry (no markdown)_

### INSP_d81b2ce3ce7d — GLOBlit_5520::PROPblock_1 (complete, 4 rows shown)

_structured envelope entry (no markdown)_
