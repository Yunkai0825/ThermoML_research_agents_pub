# Reference Stats — query-agent

**Run started:** 2026-10-20 21:04:45
**Wall time (at last flush):** 497.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 40,762 | 64,491 | 15,710 | 105,253 | 17,542 | 98.2 | claudeopus46 |
| L1-worker | 32 | 420,139 | 359,732 | 61,237 | 779,871 | 24,370 | 397.3 | claudeopus46 |
| verdict | 1 | 972 | 9,208 | 1,143 | 10,180 | 10,180 | 9.6 | claudeopus46 |
| **TOTAL** | **39** | **461,873** | **433,431** | **78,090** | **895,304** | **22,956** | **505.1** | |

**Estimated tokens:** ~223,826 input + ~19,522 output = ~243,348 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 1 | 1 | 1 | 0 | 13 | 13 | 258 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 1 | 1 | 1 | 0 | 13 | 13 | 258 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 3 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 2 | 0 | 0 | 1 | 2 | 2 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **3** | **7** | **2** | **0** | **27** | **28** | **518** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (14 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_1271 |  | search_blocks, search_system_registry |
| GLOBlit_1990 |  | search_blocks, search_system_registry |
| GLOBlit_2136 |  | search_blocks, search_system_registry |
| GLOBlit_3800 |  | search_blocks, search_system_registry |
| GLOBlit_4997 |  | search_blocks, search_system_registry |
| GLOBlit_5488 |  | search_blocks, search_system_registry |
| GLOBlit_5520 |  | search_blocks, search_system_registry |
| GLOBlit_6801 |  | search_blocks, search_system_registry |
| GLOBlit_6982 |  | search_blocks, search_system_registry |
| GLOBlit_7376 |  | search_blocks, search_system_registry |
| GLOBlit_9743 |  | search_blocks, search_system_registry |
| GLOBlit_9836 |  | search_blocks, search_system_registry |
| GLOBlit_11799 |  | search_blocks, search_system_registry |
| GLOBlit_11766 |  | search_blocks |

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_155 | trans-1,3,3,3-tetrafluoropropene | search_blocks, search_system_registry |

#### Properties (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBprop_23 |  | resolve_property_ids, search_blocks |
| GLOBprop_25 |  | resolve_property_ids |
| GLOBprop_54 |  | resolve_property_ids, search_blocks |

#### Measurements (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_276 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_5 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_37 | Critical temperature, K | search_blocks |
| GLOBmeas_115 | Critical density, kg/m3 | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_2 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 14 |
| Unique Compounds | 1 |
| Unique Properties | 4 |
| Unique Measurements | 5 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 14 |
| Unique parent blocks | 15 |
| Explicit block/subsystem targets | 15 |
| Subsystem targets | 0 |
| Target-matched data points | 518 |

---

## 3. DOI & Block References

**Unique DOIs:** 14  |  **Parent blocks:** 15  |  **Explicit targets:** 15  |  **Subsystems:** 0  |  **Target-matched datapoints:** 260

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2013.06.017 | 1 | 4 | unary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2016.10.011 | 1 | 9 | unary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.12.030 | 1 | 15 | unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.12.026 | 1 | 4 | unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.03.032 | 1 | 11 | unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.03.016 | 1 | 9 | unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.04.020 | 1 | 4 | unary | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b01039 | 1 | 18 | unary | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00673 | 1 | 89 | unary | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00964 | 1 | 5 | unary | search_blocks, search_system_registry |
| 10.1021/je2011055 | 1 | 4 | unary | search_blocks, search_system_registry |
| 10.1021/je300240k | 1 | 78 | unary | search_blocks, search_system_registry |
| 10.1021/je900696z | 2 | 2 | unary | search_blocks |
| 10.1021/je900756g | 1 | 8 | unary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2013.06.017 | PROPblock_2 | declared | 4 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2016.10.011 | PROPblock_3 | declared | 9 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.12.030 | PROPblock_3 | declared | 15 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.12.026 | PROPblock_2 | declared | 4 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.03.032 | PROPblock_1 | declared | 11 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.03.016 | PROPblock_1 | declared | 9 | unary | 1 | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.04.020 | PROPblock_1 | declared | 4 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b01039 | PROPblock_1 | declared | 18 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00673 | PROPblock_1 | declared | 89 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00964 | PROPblock_2 | declared | 5 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/je2011055 | PROPblock_1 | declared | 4 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/je300240k | PROPblock_1 | declared | 78 | unary | 1 | search_blocks, search_system_registry |
| 10.1021/je900696z | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1021/je900696z | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1021/je900756g | PROPblock_1 | declared | 8 | unary | 1 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `memory_catalog_add` | global_id=GLOBcomp_155, name=trans-1,3,3,3-tetrafl… | 2 | — | — | 0.0 |
| 2 | 1 | `search_blocks` | compound=GLOBcomp_155, limit=50, property=GLOBprop… | 1,080 | KEEP ←in 6,833 | 1065 | 22.1 |
| 3 | 2 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_1271,… | 903 | — | — | 0.2 |
| 4 | 2 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_3800,… | 901 | — | — | 0.1 |
| 5 | 2 | `search_system_registry` | compound=GLOBcomp_155, limit=50, property=GLOBprop… | 1,076 | KEEP ←in 8,589 | 1076 | 22.2 |
| 6 | 3 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_4997,… | 911 | — | — | 0.1 |
| 7 | 3 | `inspect_block_table` | block_number=PROPblock_3, literature=GLOBlit_1990,… | 909 | — | — | 0.1 |
| 8 | 3 | `inspect_block_table` | block_number=PROPblock_3, literature=GLOBlit_2136,… | 1,234 | — | — | 0.2 |
| 9 | 1 | `L1_query` | context=Looking for pure-component va…, id_catalog… | 41,321 | — | — | 210.9 |
| 10 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Find global IDs fo… | 281 | KEEP ←in 377 | 281 | 3.8 |
| 11 | 3 | `search_blocks` | compound=GLOBcomp_155, limit=50, property=['GLOBpr… | 996 | KEEP ←in 1,888 | 964 | 17.2 |
| 12 | 4 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_11766… | 611 | — | — | 0.1 |
| 13 | 4 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_11766… | 593 | — | — | 0.3 |
| 14 | 1 | `L1_query` | context=Looking for critical point da…, id_catalog… | 10,274 | — | — | 131.0 |
| 15 | 1 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_5488,… | 1,112 | — | — | 0.1 |
| 16 | 1 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_5520,… | 932 | — | — | 0.1 |
| 17 | 2 | `L1_query` | context=These two blocks were identif…, id_catalog… | 14,997 | — | — | 52.0 |
| | | **TOTAL (17 tools)** | | **78,133** | | **3,386** | **460.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 11,581 | 1,138 | 12,719 | 2,451 | 12.9 |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,318 | 25,458 | 670 | 5.8 |
| 3 | L1-worker | claudeopus46 | 3,767 | 7,214 | 10,981 | 1,393 | 13.1 |
| 4 | L1-worker | claudeopus46 | 24,140 | 2,891 | 27,031 | 1,894 | 12.7 |
| 5 | L1-worker | claudeopus46 | 3,767 | 8,997 | 12,764 | 1,403 | 12.7 |
| 6 | L1-worker | claudeopus46 | 24,140 | 6,706 | 30,846 | 2,302 | 14.8 |
| 7 | L1-worker | claudeopus46 | 24,140 | 10,791 | 34,931 | 5,269 | 36.5 |
| 8 | L1-worker | claudeopus46 | 24,140 | 22,817 | 46,957 | 5,787 | 38.7 |
| 9 | L1-worker | claudeopus46 | 24,140 | 35,331 | 59,471 | 5,356 | 34.8 |
| 10 | L1-worker | claudeopus46 | 2,320 | 5,818 | 8,138 | 1,148 | 8.9 |
| 11 | L1-worker | claudeopus46 | 627 | 5,698 | 6,325 | 1,060 | 9.5 |
| 12 | L1-worker | claudeopus46 | 2,543 | 7,172 | 9,715 | 2,338 | 11.6 |
| 13 | L1-worker | claudeopus46 | 787 | 40,749 | 41,536 | 695 | 7.9 |
| 14 | L1-worker | claudeopus46 | 24,140 | 10,493 | 34,633 | 764 | 5.6 |
| 15 | L1-worker | claudeopus46 | 24,140 | 11,625 | 35,765 | 751 | 4.7 |
| 16 | L1-worker | claudeopus46 | 3,767 | 607 | 4,374 | 406 | 3.7 |
| 17 | L1-worker | claudeopus46 | 24,140 | 11,448 | 35,588 | 10,234 | 47.7 |
| 18 | L1-worker | claudeopus46 | 3,767 | 2,345 | 6,112 | 1,245 | 9.6 |
| 19 | L1-worker | claudeopus46 | 24,140 | 13,062 | 37,202 | 1,194 | 7.4 |
| 20 | L1-worker | claudeopus46 | 24,140 | 15,034 | 39,174 | 1,661 | 10.6 |
| 21 | L1-worker | claudeopus46 | 24,140 | 19,288 | 43,428 | 1,699 | 7.6 |
| 22 | L1-worker | claudeopus46 | 24,140 | 23,861 | 48,001 | 2,373 | 13.6 |
| 23 | L1-worker | claudeopus46 | 2,543 | 3,131 | 5,674 | 776 | 4.0 |
| 24 | L1-worker | claudeopus46 | 627 | 1,670 | 2,297 | 768 | 4.1 |
| 25 | L1-worker | claudeopus46 | 2,320 | 1,790 | 4,110 | 699 | 4.6 |
| 26 | L1-worker | claudeopus46 | 787 | 10,905 | 11,692 | 580 | 6.1 |
| 27 | L0-main | claudeopus46 | 11,581 | 16,468 | 28,049 | 2,774 | 19.2 |
| 28 | L1-worker | claudeopus46 | 24,140 | 15,183 | 39,323 | 1,024 | 6.7 |
| 29 | L1-worker | claudeopus46 | 24,140 | 17,875 | 42,015 | 1,940 | 13.6 |
| 30 | L1-worker | claudeopus46 | 24,140 | 24,704 | 48,844 | 2,724 | 19.4 |
| 31 | L1-worker | claudeopus46 | 2,543 | 3,794 | 6,337 | 863 | 4.9 |
| 32 | L1-worker | claudeopus46 | 627 | 1,955 | 2,582 | 761 | 5.0 |
| 33 | L1-worker | claudeopus46 | 2,320 | 2,075 | 4,395 | 850 | 5.4 |
| 34 | L1-worker | claudeopus46 | 787 | 13,385 | 14,172 | 610 | 6.0 |
| 35 | L0-main | claudeopus46 | 11,581 | 29,863 | 41,444 | 4,412 | 32.3 |
| 36 | L0-main | claudeopus46 | 2,320 | 3,301 | 5,621 | 944 | 5.6 |
| 37 | L0-main | claudeopus46 | 2,543 | 4,271 | 6,814 | 1,774 | 9.4 |
| 38 | L0-main | claudeopus46 | 1,156 | 9,450 | 10,606 | 3,355 | 18.8 |
| 39 | verdict | claudeopus46 | 972 | 9,208 | 10,180 | 1,143 | 9.6 |

