# Reference Stats — main-agent

**Run started:** 2026-10-20 21:00:56
**Wall time (at last flush):** 1,565.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 24 | 239,943 | 609,955 | 138,513 | 849,898 | 35,412 | 924.9 | claudeopus46 |
| L0-menu-planner | 1 | 1,013 | 1,515 | 2,497 | 2,528 | 2,528 | 15.0 | claudesonnet46 |
| L1-worker | 13 | 48,971 | 12,913 | 14,654 | 61,884 | 4,760 | 106.5 | claudeopus46 |
| **TOTAL** | **38** | **289,927** | **624,383** | **155,664** | **914,310** | **24,060** | **1046.4** | |

**Estimated tokens:** ~228,577 input + ~38,916 output = ~267,493 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `browse_subagent_tools` | purpose=Find vapor pressure data for …, tasks=1) S… | 2,497 | — | — | 32.1 |
| 2 | 4 | `run_subagent_tool` | kwargs={'query': '29118-24-9', 'enti…, purpose=Res… | 645 | — | — | 10.5 |
| 3 | 4 | `run_subagent_tool` | kwargs={'query': 'trans-1,3,3,3-tetr…, purpose=Res… | 295 | — | — | 4.4 |
| 4 | 6 | `run_query_agent` | context=Compound ID: GLOBcomp_155, Na…, purpose=Id… | 32,655 | — | — | 498.3 |
| 5 | 8 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_1990'…, purpose=Ret… | 785 | — | — | 6.8 |
| 6 | 8 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_4997'…, purpose=Ret… | 809 | — | — | 7.2 |
| 7 | 8 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_2136'…, purpose=Ret… | 1,201 | — | — | 11.3 |
| 8 | 9 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_1990'…, purpose=Get… | 791 | — | — | 11.1 |
| 9 | 9 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_4997'…, purpose=Get… | 672 | — | — | 8.3 |
| 10 | 9 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_2136'…, purpose=Get… | 642 | — | — | 9.3 |
| 11 | 10 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_1990'…, purpose=Ret… | 772 | — | — | 7.6 |
| 12 | 10 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_4997'…, purpose=Ret… | 860 | — | — | 7.3 |
| 13 | 10 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_2136'…, purpose=Ret… | 1,285 | — | — | 11.1 |
| 14 | 13 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_4997'…, purpose=Ret… | 974 | — | — | 8.0 |
| 15 | 15 | `run_subagent_tool` | kwargs={'literature': 'GLOBlit_4997'…, purpose=Gro… | 637 | — | — | 9.3 |
| | | **TOTAL (15 tools)** | | **45,520** | | **0** | **642.6** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 13,598 | 486 | 14,084 | 1,277 | 7.5 |
| 2 | L0-main | claudeopus46 | 13,598 | 1,489 | 15,087 | 14,637 | 71.8 |
| 3 | L0-menu-planner | claudesonnet46 | 1,013 | 1,515 | 2,528 | 2,497 | 15.0 |
| 4 | L0-main | claudeopus46 | 13,598 | 3,932 | 17,530 | 14,343 | 74.0 |
| 5 | L0-main | claudeopus46 | 13,598 | 5,293 | 18,891 | 1,064 | 6.9 |
| 6 | L1-worker | claudeopus46 | 3,767 | 289 | 4,056 | 929 | 8.6 |
| 7 | L1-worker | claudeopus46 | 3,767 | 488 | 4,255 | 480 | 4.2 |
| 8 | L0-main | claudeopus46 | 3,766 | 1,237 | 5,003 | 469 | 4.7 |
| 9 | L0-main | claudeopus46 | 13,598 | 5,444 | 19,042 | 1,037 | 7.8 |
| 10 | L0-main | claudeopus46 | 13,598 | 6,079 | 19,677 | 1,367 | 7.4 |
| 11 | L0-main | claudeopus46 | 13,598 | 29,781 | 43,379 | 11,579 | 83.1 |
| 12 | L0-main | claudeopus46 | 13,598 | 31,672 | 45,270 | 1,395 | 7.5 |
| 13 | L1-worker | claudeopus46 | 3,767 | 1,270 | 5,037 | 1,013 | 6.6 |
| 14 | L1-worker | claudeopus46 | 3,767 | 1,347 | 5,114 | 1,038 | 6.9 |
| 15 | L1-worker | claudeopus46 | 3,767 | 1,399 | 5,166 | 1,483 | 11.1 |
| 16 | L0-main | claudeopus46 | 3,766 | 3,144 | 6,910 | 1,159 | 10.0 |
| 17 | L0-main | claudeopus46 | 13,598 | 32,043 | 45,641 | 3,172 | 20.2 |
| 18 | L1-worker | claudeopus46 | 3,767 | 531 | 4,298 | 1,594 | 10.9 |
| 19 | L1-worker | claudeopus46 | 3,767 | 535 | 4,302 | 1,010 | 8.1 |
| 20 | L1-worker | claudeopus46 | 3,767 | 540 | 4,307 | 1,362 | 9.2 |
| 21 | L0-main | claudeopus46 | 3,766 | 2,453 | 6,219 | 1,460 | 8.6 |
| 22 | L0-main | claudeopus46 | 13,598 | 34,056 | 47,654 | 1,866 | 10.6 |
| 23 | L1-worker | claudeopus46 | 3,767 | 1,271 | 5,038 | 986 | 7.5 |
| 24 | L1-worker | claudeopus46 | 3,767 | 1,348 | 5,115 | 1,087 | 7.2 |
| 25 | L1-worker | claudeopus46 | 3,767 | 1,400 | 5,167 | 1,552 | 11.0 |
| 26 | L0-main | claudeopus46 | 3,766 | 3,267 | 7,033 | 1,048 | 8.8 |
| 27 | L0-main | claudeopus46 | 13,598 | 35,576 | 49,174 | 11,659 | 82.7 |
| 28 | L0-main | claudeopus46 | 13,598 | 47,635 | 61,233 | 12,780 | 97.7 |
| 29 | L0-main | claudeopus46 | 13,598 | 66,222 | 79,820 | 12,619 | 91.1 |
| 30 | L1-worker | claudeopus46 | 3,767 | 1,372 | 5,139 | 1,186 | 7.8 |
| 31 | L0-main | claudeopus46 | 13,598 | 67,862 | 81,460 | 11,061 | 79.6 |
| 32 | L0-main | claudeopus46 | 13,598 | 84,835 | 98,433 | 14,660 | 105.0 |
| 33 | L1-worker | claudeopus46 | 3,767 | 1,123 | 4,890 | 934 | 7.4 |
| 34 | L0-main | claudeopus46 | 13,598 | 86,111 | 99,709 | 11,795 | 83.5 |
| 35 | L0-main | claudeopus46 | 2,543 | 16,150 | 18,693 | 1,105 | 7.1 |
| 36 | L0-main | claudeopus46 | 2,320 | 15,548 | 17,868 | 1,775 | 14.5 |
| 37 | L0-main | claudeopus46 | 1,156 | 21,697 | 22,853 | 3,632 | 21.4 |
| 38 | L0-main | claudeopus46 | 1,292 | 7,943 | 9,235 | 1,554 | 13.4 |

