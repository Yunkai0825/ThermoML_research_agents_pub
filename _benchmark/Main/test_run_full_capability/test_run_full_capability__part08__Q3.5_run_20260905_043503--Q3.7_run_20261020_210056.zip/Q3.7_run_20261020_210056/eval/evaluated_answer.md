# Answer

**Question:** For trans-1,3,3,3-tetrafluoropropene (R1234ze(E)), use the vapour-pressure data in ThermoML to estimate the vapour pressure and the enthalpy of vaporization at 273.15 K, and estimate the critical pressure at the reported critical temperature; give uncertainties, state your approximations, and say which data sets agree.

**[run statistics removed]**

---

## Answer

## Vapor Pressure, Enthalpy of Vaporization, and Critical Pressure of R1234ze(E) from ThermoML Data

### Compound
**trans-1,3,3,3-Tetrafluoropropene (R1234ze(E))**, CAS 29118-24-9, molecular formula C₃H₂F₄, molar mass 114.04 g/mol (derived from formula).

---

### Data Sources

Seven ThermoML data blocks from seven literature sources provide a total of 56 pure-component vapor pressure data points. A single additional source provides critical temperature and critical density. No critical pressure data exists in ThermoML for this compound.

| # | Literature ID | Block | DOI | Points | T range (K) | P range (kPa) | U(P) (kPa) |
|---|---|---|---|---|---|---|---|
| 1 | GLOBlit_1271 | PROPblock_2 | 10.1016/j.fluid.2013.06.017 | 4 | 258.15–288.15 | 120.2–364.2 | 1–1.1 |
| 2 | GLOBlit_3800 | PROPblock_2 | 10.1016/j.jct.2012.12.026 | 4 | 258.15–288.15 | 120.2–364.2 | 1–1.1 |
| 3 | GLOBlit_1990 | PROPblock_3 | 10.1016/j.fluid.2016.10.011 | 9 | 283.145–323.141 | 308.6–997.8 | 1.1–1.8 |
| 4 | GLOBlit_4997 | PROPblock_1 | 10.1016/j.jct.2017.03.032 | 11 | 280.15–330.126 | 276.5–1178.1 | 20–20.1 |
| 5 | GLOBlit_2136 | PROPblock_3 | 10.1016/j.fluid.2017.12.030 | 15 (9 inspected via RDP sampling) | 303.146–373.137 | 578.14–3026.83 | 1.35–4.84 |
| 6 | GLOBlit_5488 | PROPblock_1 | 10.1016/j.jct.2019.03.016 | 9 | 298.221–338.102 | 499.4–1434.8 | 8.1 |
| 7 | GLOBlit_5520 | PROPblock_1 | 10.1016/j.jct.2019.04.020 | 4 | 293.15–323.14 | 427.4–997.8 | 5.1–5.3 |

All T/P range endpoints in the table above are inspected values from the respective blocks. The point count of 15 for GLOBlit_2136 is the block metadata count (9 of those points were inspected via RDP sampling in this session).

**Note:** GLOBlit_1271 (PROPblock_2) and GLOBlit_3800 (PROPblock_2) contain identical data (same four T/P pairs at 258.15, 268.15, 278.15, 288.15 K — all inspected in both blocks). These are the only blocks whose temperature ranges bracket 273.15 K, which is the user's target temperature and is not itself a measured point in any ThermoML block.

**Critical properties** (GLOBlit_11766, DOI: 10.1021/je900696z):
- Critical temperature: T_c = 382.51 ± 0.06 K (visual observation; from GLOBlit_11766, PROPblock_1, inspected)
- Critical density: ρ_c = 486 ± 8 kg/m³ (rectilinear diameter; from GLOBlit_11766, PROPblock_2, inspected)
- Critical pressure: **not reported** in ThermoML

---

### 1. Vapor Pressure at 273.15 K

**Method:** Clausius–Clapeyron interpolation using the two inspected data points from GLOBlit_1271 (PROPblock_2) that bracket the target temperature of 273.15 K (a user-specified target, not a database value).

**Approximations:**
- The Clausius–Clapeyron equation, ln P = A − B/T (where B = ΔH_vap/R), is assumed valid over the 10 K interpolation interval.
- The vapor is treated as an ideal gas and the molar volume of the liquid is neglected relative to the vapor.
- ΔH_vap is assumed constant over the narrow interpolation range (268.15–278.15 K).

**Bracketing data** (from GLOBlit_1271, PROPblock_2, inspected):

| T (K) | P (kPa) | U(P) (kPa) |
|---|---|---|
| 268.15 | 179.3 | 1.0 |
| 278.15 | 259.2 | 1.1 |

**Calculation** (all intermediate values are derived from the two inspected points above):
- 1/268.15 = 3.7292 × 10⁻³ K⁻¹; ln(179.3) = 5.1893
- 1/278.15 = 3.5952 × 10⁻³ K⁻¹; ln(259.2) = 5.5578
- 1/273.15 = 3.6610 × 10⁻³ K⁻¹ (derived from the target temperature)
- Interpolation fraction: (3.6610 − 3.7292)/(3.5952 − 3.7292) = 0.509 (derived)
- ln P(273.15 K) = 5.1893 + 0.509 × (5.5578 − 5.1893) = 5.1893 + 0.1876 = 5.377 (derived)
- **P(273.15 K) ≈ 217 kPa** (derived)

**Uncertainty estimate:** Propagating the inspected measurement uncertainties of ±1.0 and ±1.1 kPa through the interpolation gives an instrumental contribution of ~1 kPa (derived). The Clausius–Clapeyron model error over a 10 K interval is small. A conservative combined uncertainty is ±3 kPa (derived), yielding:

> **P(273.15 K) = 217 ± 3 kPa** (derived by Clausius–Clapeyron interpolation from inspected GLOBlit_1271 data)

**Cross-check with other blocks:** GLOBlit_4997 (PROPblock_1, inspected) reports 276.5 kPa at 280.15 K (U = 20 kPa) and GLOBlit_1990 (PROPblock_3, inspected) reports 308.6 kPa at 283.145 K (U = 1.1 kPa). Extrapolating the Clausius–Clapeyron fit from the GLOBlit_1271 bracketing points to these temperatures gives ~271 kPa at 280.15 K and ~306 kPa at 283.145 K (both derived), consistent with the measured values within their uncertainties.

---

### 2. Enthalpy of Vaporization at 273.15 K

**Method:** Clausius–Clapeyron slope from adjacent inspected data pairs in GLOBlit_1271 (PROPblock_2).

From ln(P₂/P₁) = (ΔH_vap/R)(1/T₁ − 1/T₂), using the four inspected data points at 258.15, 268.15, 278.15, and 288.15 K with pressures 120.2, 179.3, 259.2, and 364.2 kPa respectively (all from GLOBlit_1271, PROPblock_2):

| Pair (K) | ΔH_vap (kJ/mol) | Derivation basis |
|---|---|---|
| 258.15 – 268.15 | 23.0 (derived) | From inspected 120.2 & 179.3 kPa |
| 268.15 – 278.15 | 22.9 (derived) | From inspected 179.3 & 259.2 kPa |
| 278.15 – 288.15 | 22.7 (derived) | From inspected 259.2 & 364.2 kPa |

The three derived estimates are highly consistent, showing a slight decrease with increasing temperature as expected thermodynamically. The value at 273.15 K (midpoint of the 268.15–278.15 K pair) is:

> **ΔH_vap(273.15 K) = 22.9 ± 0.3 kJ/mol** (derived from inspected GLOBlit_1271 data)

where the uncertainty reflects the spread across the three pair estimates and the propagated measurement uncertainty (~0.1 kJ/mol from δP, derived).

**Approximations:** Same as Section 1 — ideal gas, negligible liquid volume, constant ΔH_vap over each 10 K interval. These are reasonable approximations at 273.15 K where the reduced temperature T/T_c ≈ 0.71 (derived from 273.15/382.51, using the inspected T_c from GLOBlit_11766 PROPblock_1) and the vapor density is low.

**Chemistry context:** This value is physically reasonable for a low-boiling fluorinated olefin refrigerant. R1234ze(E) is being adopted as a low-GWP replacement for R-134a (1,1,1,2-tetrafluoroethane), which has a similar ΔH_vap in this temperature range (general literature knowledge, not from this database).

---

### 3. Critical Pressure Estimate

**Method:** Clausius–Clapeyron extrapolation from the highest-temperature inspected vapor pressure data (GLOBlit_2136, PROPblock_3) to T_c = 382.51 K (inspected from GLOBlit_11766, PROPblock_1).

**Approximations:**
- Clausius–Clapeyron with constant ΔH_vap is used for extrapolation. This is a significant approximation near the critical point where ΔH_vap → 0, so the method will tend to **overestimate** P_c. However, the extrapolation distance is short (~9 K beyond the last inspected data point at 373.137 K), which limits the error.
- The ideal gas assumption breaks down near T_c, introducing additional systematic error.

**Calculation using the two highest-temperature inspected points from GLOBlit_2136 (PROPblock_3):**
- T₁ = 368.152 K, P₁ = 2741.03 kPa; T₂ = 373.137 K, P₂ = 3026.83 kPa (both inspected)
- Clausius–Clapeyron slope (derived): [ln(3026.83) − ln(2741.03)] / [1/373.137 − 1/368.152] = −2750
- Extrapolation to T_c = 382.51 K (inspected) (all following values derived):
  ln(P_c) = ln(3026.83) + (−2750)(1/382.51 − 1/373.137) = 8.016 + 0.182 = 8.198
- **P_c ≈ exp(8.198) ≈ 3640 kPa ≈ 3.64 MPa** (derived)

**Using a broader baseline** (inspected points at 353.142 K / 2008.42 kPa and 373.137 K / 3026.83 kPa from GLOBlit_2136, PROPblock_3):
- Slope = −2704 (derived); ln(P_c) = 8.195 (derived); P_c ≈ 3627 kPa ≈ 3.63 MPa (derived)

The two derived estimates agree within 13 kPa (derived). Given the approximations (constant ΔH_vap, ideal gas) and the ~9 K extrapolation beyond the data, a conservative uncertainty is ±50 kPa (derived):

> **P_c(382.51 K) ≈ 3630 ± 50 kPa (3.63 ± 0.05 MPa)** (derived by Clausius–Clapeyron extrapolation)

This is expected to be a slight overestimate because ΔH_vap decreases as T → T_c, meaning the true vapor pressure curve flattens relative to the Clausius–Clapeyron extrapolation. For reference, the NIST/REFPROP value for R1234ze(E) critical pressure is approximately 3632 kPa (external literature value, not from this database), which is consistent with this estimate.

---

### 4. Inter-Dataset Agreement

The inspected datasets show excellent mutual consistency at overlapping temperatures. All P values below are from inspected data points in the blocks indicated; differences and percentages are derived:

| Approx. T (K) | GLOBlit_1271 PROPblock_2 | GLOBlit_1990 PROPblock_3 | GLOBlit_4997 PROPblock_1 | GLOBlit_5520 PROPblock_1 | GLOBlit_2136 PROPblock_3 | GLOBlit_5488 PROPblock_1 | Max spread (derived) |
|---|---|---|---|---|---|---|---|
| ~288 | 364.2 | 364.7 | — | — | — | — | 0.5 kPa (0.14%) |
| ~293 | — | 428.0 | — | 427.4 | — | — | 0.6 kPa (0.14%) |
| ~298 | — | 499.0 | — | — | — | 499.4 | 0.4 kPa (0.08%) |
| ~303 | — | 578.9 | — | 577.6 | 578.14 | 584.6 | 7.0 kPa (1.2%) |
| ~313 | — | 767.4 | — | 765.3 | 766.43 | 766.4 | 2.1 kPa (0.27%) |
| ~323 | — | 997.8 | — | 997.8 | 997.42 | 989.8 | 8.0 kPa (0.80%) |

**Highly consistent group:** GLOBlit_1271/3800 (PROPblock_2), GLOBlit_1990 (PROPblock_3), GLOBlit_5520 (PROPblock_1), and GLOBlit_2136 (PROPblock_3) agree within 0.3% (typically 0.5–2 kPa, derived) at all overlapping temperatures. These four sources form a mutually reinforcing core dataset.

**Slightly offset:** GLOBlit_5488 (PROPblock_1) shows deviations of up to ~8 kPa (~1%, derived) from the core group, but these are within its stated expanded uncertainty of 8.1 kPa (inspected). This dataset is therefore consistent within its own error bars but is the least precise of the group.

**Largest uncertainty:** GLOBlit_4997 (PROPblock_1) has the largest stated uncertainty (20 kPa, inspected). Its inspected value of 276.5 kPa at 280.15 K is consistent with the Clausius–Clapeyron prediction of ~271 kPa (derived from GLOBlit_1271 fit), well within its 20 kPa uncertainty.

**Duplicate data:** GLOBlit_1271 (PROPblock_2) and GLOBlit_3800 (PROPblock_2) contain identical T/P values at all four temperatures (both fully inspected), confirming they report the same underlying measurements.

---

### Summary of Results

| Quantity | Value | Uncertainty | Method | Key inspected data source |
|---|---|---|---|---|
| P(273.15 K) | 217 kPa (derived) | ± 3 kPa (derived) | Clausius–Clapeyron interpolation | GLOBlit_1271, PROPblock_2 (inspected 268.15 & 278.15 K points) |
| ΔH_vap(273.15 K) | 22.9 kJ/mol (derived) | ± 0.3 kJ/mol (derived) | Clausius–Clapeyron slope | GLOBlit_1271, PROPblock_2 (all 4 inspected points) |
| P_c(382.51 K) | 3630 kPa / 3.63 MPa (derived) | ± 50 kPa / ± 0.05 MPa (derived) | Clausius–Clapeyron extrapolation | GLOBlit_2136, PROPblock_3 (inspected high-T points) + GLOBlit_11766, PROPblock_1 (inspected T_c) |

### Sources
- Literature ID: GLOBlit_1271 | DOI: 10.1016/j.fluid.2013.06.017 | Block: PROPblock_2 | System: R1234ze(E) pure
- Literature ID: GLOBlit_3800 | DOI: 10.1016/j.jct.2012.12.026 | Block: PROPblock_2 | System: R1234ze(E) pure
- Literature ID: GLOBlit_1990 | DOI: 10.1016/j.fluid.2016.10.011 | Block: PROPblock_3 | System: R1234ze(E) pure
- Literature ID: GLOBlit_4997 | DOI: 10.1016/j.jct.2017.03.032 | Block: PROPblock_1 | System: R1234ze(E) pure
- Literature ID: GLOBlit_2136 | DOI: 10.1016/j.fluid.2017.12.030 | Block: PROPblock_3 | System: R1234ze(E) pure
- Literature ID: GLOBlit_5488 | DOI: 10.1016/j.jct.2019.03.016 | Block: PROPblock_1 | System: R1234ze(E) pure
- Literature ID: GLOBlit_5520 | DOI: 10.1016/j.jct.2019.04.020 | Block: PROPblock_1 | System: R1234ze(E) pure
- Literature ID: GLOBlit_11766 | DOI: 10.1021/je900696z | Block: PROPblock_1, PROPblock_2 | System: R1234ze(E) pure






















### Core claims

- For trans-1,3,3,3-tetrafluoropropene (R1234ze(E), CAS 29118-24-9), seven ThermoML sources provide 56 pure-component vapor pressure data points spanning approximately 258–373 K, with excellent inter-dataset agreement (typically within 0.3%, up to ~1% for the least precise source) at overlapping temperatures.
- The vapor pressure at 273.15 K is derived by Clausius–Clapeyron interpolation between inspected data at 268.15 K (179.3 kPa) and 278.15 K (259.2 kPa) as P(273.15 K) = 217 ± 3 kPa; this is a derived value, not a direct measurement in the database.
- The enthalpy of vaporization at 273.15 K is derived from Clausius–Clapeyron slopes across three adjacent 10 K intervals (258–288 K) as ΔH_vap(273.15 K) = 22.9 ± 0.3 kJ/mol, with the three interval estimates (23.0, 22.9, 22.7 kJ/mol) showing a slight expected decrease with temperature.
- No critical pressure is reported in ThermoML for R1234ze(E); a Clausius–Clapeyron extrapolation from the highest-temperature inspected vapor pressure data (~373 K) to the inspected critical temperature T_c = 382.51 ± 0.06 K yields an estimated P_c ≈ 3630 ± 50 kPa (3.63 ± 0.05 MPa), expected to be a slight overestimate because ΔH_vap decreases approaching T_c.
- The Clausius–Clapeyron derivations assume ideal gas behavior, negligible liquid molar volume, and constant ΔH_vap over each interpolation/extrapolation interval; these approximations are reasonable at 273.15 K (reduced temperature T/T_c ≈ 0.71) but become less valid near the critical point.
- GLOBlit_1271 (PROPblock_2) and GLOBlit_3800 (PROPblock_2) contain identical data at all four inspected temperatures, confirming they report the same underlying measurements.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_1271 | 10.1016/j.fluid.2013.06.017 | PROPblock_2 |  | Primary source for the Clausius–Clapeyron interpolation to 273.15 K. Its 4 vapor pressure points (120.2–364.2 kPa at 258.15–288.15 K) bracket the target temperature and are used to derive P(273.15 K) ≈ 217 kPa and ΔH_vap ≈ 22.9 kJ/mol. |
| GLOBlit_3800 | 10.1016/j.jct.2012.12.026 | PROPblock_2 |  | Duplicate of GLOBlit_1271 PROPblock_2 with identical T/P values (120.2–364.2 kPa, 258.15–288.15 K), confirming the reproducibility of the primary bracketing data used for the interpolation. |
| GLOBlit_1990 | 10.1016/j.fluid.2016.10.011 | PROPblock_3 |  | Provides 9 vapor pressure points (308.6–997.8 kPa, 283.145–323.141 K) used for cross-checking the Clausius–Clapeyron extrapolation from GLOBlit_1271 and for inter-dataset consistency analysis at overlapping temperatures. |
| GLOBlit_4997 | 10.1016/j.jct.2017.03.032 | PROPblock_1 |  | Provides 11 vapor pressure points (276.5–1178.1 kPa, 280.15–330.126 K) used as a cross-check for the interpolated P(273.15 K) value; its 276.5 kPa at 280.15 K is consistent with the Clausius–Clapeyron prediction within its 20 kPa uncertainty. |
| GLOBlit_2136 | 10.1016/j.fluid.2017.12.030 | PROPblock_3 |  | Provides the highest-temperature vapor pressure data (578.14–3026.83 kPa, 303.146–373.137 K, 15 points) used for the Clausius–Clapeyron extrapolation to estimate P_c ≈ 3630 kPa at T_c = 382.51 K, and for inter-dataset consistency checks. |
| GLOBlit_5488 | 10.1016/j.jct.2019.03.016 | PROPblock_1 |  | Provides 9 vapor pressure points (499.4–1434.8 kPa, 298.221–338.102 K) used in the inter-dataset consistency analysis; shows deviations up to ~8 kPa from the core group, consistent within its stated 8.1 kPa uncertainty. |
| GLOBlit_5520 | 10.1016/j.jct.2019.04.020 | PROPblock_1 |  | Provides 4 vapor pressure points (427.4–997.8 kPa, 293.15–323.14 K) used in the inter-dataset consistency analysis, showing excellent agreement (within 0.3%) with the core dataset group. |
| GLOBlit_11766 | 10.1021/je900696z | PROPblock_1 |  | Provides the critical temperature T_c = 382.51 K used as the extrapolation target for the critical pressure estimate of 3630 kPa. |
| GLOBlit_11766 | 10.1021/je900696z | PROPblock_2 |  | Provides the critical density ρ_c = 486 kg/m³ reported in the answer as a supplementary critical property of R1234ze(E), complementing the critical temperature from PROPblock_1. |

---

<!-- END OF REVIEW COPY. Later generated run appendices are separate execution evidence. -->
