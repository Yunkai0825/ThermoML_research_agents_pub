# Main Agent Run — [run id removed] (Round 1)

**Question:** Water and dimethyl sulfoxide are known to interact strongly. Near 25 °C, at what DMSO composition is this interaction most evident in the measured thermodynamic or transport behavior, and what molecular picture explains it?

**[run statistics removed]**

---

## Answer

## Water + Dimethyl Sulfoxide: Composition of Maximum Interaction near 25 °C

### Key Finding

The strongest signature of water–DMSO interaction available in the ThermoML database is a **pronounced viscosity maximum** near **x(DMSO) ≈ 0.33–0.36** at 298.15 K. At this composition, the mixture viscosity is dramatically higher than that of either pure component — a hallmark of strongly non-ideal mixing driven by specific intermolecular interactions.

---

### Evidence from ThermoML Viscosity Data

Two independent datasets confirm this behavior:

#### Dataset 1 — GLOBlit_2781 :: PROPblock_3

DOI: 10.1016/j.jct.2006.12.012. Dynamic viscosity at 298.15 K and 101.0 kPa across the full mole-fraction range. The block contains 24 compositions at this temperature (18 of 24 rows shown after shape-preserving compression):

| x(DMSO) | η (Pa·s) |
|----------|-----------|
| 0 (pure water) | 0.0008901 |
| 0.0238 | 0.0010331 |
| 0.0489 | 0.0012576 |
| 0.1587 | 0.0025493 |
| 0.2036 | 0.0030165 |
| 0.2379 | 0.0033011 |
| 0.2768 | 0.0035372 |
| 0.3074 | 0.0036564 |
| 0.3335 | 0.0037144 |
| **0.3638** | **0.0037353** ← maximum |
| 0.3906 | 0.0037169 |
| 0.4412 | 0.0036062 |
| 0.5193 | 0.0033124 |
| 0.6195 | 0.0028832 |
| 0.6813 | 0.0026556 |
| 0.7595 | 0.0024317 |
| 0.8856 | 0.0021754 |
| 1 (pure DMSO) | 0.001996 |

The viscosity rises steeply from pure water, peaks at **x(DMSO) = 0.3638** with η = **0.0037353 Pa·s**, then decreases toward pure DMSO.

#### Dataset 2 — GLOBlit_11517 :: PROPblock_3

DOI: 10.1021/je9001027. Dynamic viscosity at 298.15 K and 101.0 kPa. All 7 compositions at this temperature:

| w(DMSO) | η (Pa·s) |
|----------|-----------|
| 0 | 0.00089 |
| 0.2 | 0.00134 |
| 0.4 | 0.002221 |
| 0.5 | 0.0028073 |
| **0.6** | **0.003421** ← maximum |
| 0.7 | 0.0023568 |
| 1 | 0.001966 |

The maximum at w(DMSO) = 0.6 corresponds to approximately x(DMSO) ≈ 0.33 (derived by converting mass fraction to mole fraction using M_DMSO = 78.13 g/mol and M_water = 18.015 g/mol), consistent with Dataset 1.

---

### How Large Is the Effect?

At the viscosity maximum (derived from the inspected Dataset 1 values):

- **η(mixture) / η(pure water)** = 0.0037353 / 0.0008901 ≈ **4.2×**
- **η(mixture) / η(pure DMSO)** = 0.0037353 / 0.001996 ≈ **1.9×**

The mixture is more than four times as viscous as pure water and nearly twice as viscous as pure DMSO — a remarkably large deviation from ideal mixing behavior.

---

### Other Properties in ThermoML

A thorough search of the ThermoML database for this binary system found **no excess molar enthalpy (H^E)** and **no excess molar volume (V^E)** data deposited for water + DMSO. The database does contain mass-density blocks and other properties (speed of sound, thermal conductivity, heat capacity) for this system, but the viscosity data provides the most direct and dramatic evidence of the interaction strength.

The closest enthalpy-related measurement is a **molar enthalpy of solution** of −5.38 kJ/mol at 298.15 K and 101 kPa for DMSO dissolved in water at a molality of 0.092 mol/kg (GLOBlit_5958, DOI: 10.1016/j.tca.2011.09.009, PROPblock_1). This measures the enthalpy change upon dissolving DMSO into water at very low concentration — a related but distinct quantity from the composition-dependent excess enthalpy of mixing across the full mole-fraction range.

---

### Molecular Picture

The viscosity maximum near **x(DMSO) ≈ 1/3** (i.e., one DMSO molecule for every two water molecules) points to the formation of **structured 1:2 DMSO–water hydration complexes**. The molecular explanation involves several key features:

1. **Strong hydrogen-bond acceptance by S=O:** The sulfinyl oxygen of DMSO is a powerful hydrogen-bond acceptor — significantly stronger than the oxygen in water itself. Each S=O group can accept two hydrogen bonds from two different water molecules, creating a well-defined 1 DMSO : 2 H₂O stoichiometric cluster.

2. **Network restructuring:** At x(DMSO) ≈ 0.33, essentially all water molecules are engaged in hydrogen bonding to DMSO rather than to other water molecules. The native three-dimensional hydrogen-bond network of water is replaced by a new, more structured arrangement of DMSO–water complexes. These complexes are larger and more rigid than either pure-component structure.

3. **Enhanced resistance to flow:** The bulky, strongly associated DMSO·2H₂O clusters interlock more effectively than the molecules in either pure liquid, dramatically increasing the resistance to shear flow. This is why the viscosity maximum is so pronounced — the mixture is far more viscous than a simple volume-weighted average of the pure components would predict.

4. **Asymmetric composition dependence:** The steep rise in viscosity from the water-rich side (where DMSO molecules are progressively incorporated into the water network) and the gentler decline toward pure DMSO (where excess DMSO molecules dilute the clusters) reflect the asymmetric nature of the interaction: DMSO disrupts and reorganizes the water network much more than water disrupts the DMSO liquid structure.

The broader literature confirms that this same composition (x ≈ 0.33) also corresponds to extrema in excess enthalpy (strongly exothermic) and excess volume (strongly negative) — all consistent with the 1:2 DMSO:water complexation picture. While H^E and V^E data are not available in ThermoML for this system, the viscosity data alone provides compelling quantitative evidence for this molecular interaction.

---

### Sources

- **GLOBlit_2781** | DOI: 10.1016/j.jct.2006.12.012 | Block: PROPblock_3 — Dynamic viscosity of water + DMSO, 24 mole-fraction compositions at 298.15 K, capillary tube method.
- **GLOBlit_11517** | DOI: 10.1021/je9001027 | Block: PROPblock_3 — Dynamic viscosity of water + DMSO, 7 mass-fraction compositions at 298.15 K, capillary tube method.
- **GLOBlit_5958** | DOI: 10.1016/j.tca.2011.09.009 | Block: PROPblock_1 — Molar enthalpy of solution of DMSO in water (−5.38 kJ/mol at 298.15 K, molality 0.092 mol/kg), isoperibol calorimetry.





















### Core claims

- Two independent ThermoML viscosity datasets for water + DMSO at 298.15 K show a pronounced viscosity maximum near x(DMSO) ≈ 0.33–0.36, consistent with strong non-ideal mixing driven by specific intermolecular interactions.
- In Dataset 1 (DOI: 10.1016/j.jct.2006.12.012), the viscosity peaks at x(DMSO) = 0.3638 with η = 0.0037353 Pa·s; in Dataset 2 (DOI: 10.1021/je9001027), the maximum occurs at w(DMSO) = 0.6 (approximately x(DMSO) ≈ 0.33) with η = 0.003421 Pa·s.
- No excess molar enthalpy (H^E) or excess molar volume (V^E) data for water + DMSO were found deposited in the ThermoML database; the viscosity data provides the most direct available ThermoML evidence of interaction strength.
- A molar enthalpy of solution of −5.38 kJ/mol at 298.15 K and 101 kPa for DMSO dissolved in water at a molality of 0.092 mol/kg was found (DOI: 10.1016/j.tca.2011.09.009), but this is a distinct quantity from composition-dependent excess enthalpy of mixing.
- The viscosity maximum near x(DMSO) ≈ 1/3 is interpreted as evidence for structured 1:2 DMSO:water hydration complexes formed via strong hydrogen-bond acceptance by the sulfinyl oxygen of DMSO.

**Confidence:** low

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3 |  | Provides dynamic viscosity of the water + DMSO binary across the full mole-fraction range at 298.15 K and 101.0 kPa (120 datapoints, 24 compositions at 298.15 K). The card confirms the viscosity maximum of 0.003735 Pa·s quoted in the answer, which is the primary evidence for the composition of maximum interaction near x(DMSO) ≈ 0.33–0.36. |
| GLOBlit_11517 | 10.1021/je9001027 | PROPblock_3 |  | Provides an independent viscosity dataset for water + DMSO at 298.15 K using mass-fraction composition (35 datapoints). The card confirms the maximum viscosity of 0.003421 Pa·s at w(DMSO) = 0.6, which converts to x(DMSO) ≈ 0.33, corroborating the composition of maximum interaction found in Dataset 1. |
| GLOBlit_5958 | 10.1016/j.tca.2011.09.009 | PROPblock_1 |  | Provides the molar enthalpy of solution of DMSO in water (−5.38 kJ/mol at 298.15 K, molality 0.092 mol/kg) as supplementary thermodynamic evidence of the exothermic DMSO–water interaction. The card confirms the single datapoint and isoperibol method quoted in the answer. |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
