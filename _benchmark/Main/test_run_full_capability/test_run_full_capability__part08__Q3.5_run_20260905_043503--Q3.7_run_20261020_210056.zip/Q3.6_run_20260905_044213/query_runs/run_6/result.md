# Delegated query run — result

**Question:** Find blocks with excess molar enthalpy (HE) data for the binary system water (GLOBcomp_1) + dimethyl sulfoxide (GLOBcomp_31) near 298.15 K. Report block numbers, literature IDs, DOIs, temperature ranges, and composition ranges.

**Iterations:** 2  |  **Elapsed:** 323.7s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Excess Molar Enthalpy (Hᴱ) Data for Water + DMSO near 298.15 K

### Result: No Data Found

A thorough search of the ThermoML database for **excess molar enthalpy (Hᴱ)** data for the binary system **water + dimethyl sulfoxide (DMSO)** found **no blocks** containing this specific property for this compound pair. This was confirmed across multiple search strategies (declared binary scope, subsystem scope, and broad unfiltered searches).

### What the Database Does Contain for Water + DMSO

The water + DMSO binary system is well-represented in the ThermoML database with **29 property blocks across 16 papers (1,601 data points)** spanning T = 253.15–393.15 K, but the available properties are:

| Property | Number of Blocks |
|----------|:---:|
| Mass density (kg/m³) | 9 |
| Speed of sound (m/s) | 3 |
| Viscosity (Pa·s) | 3 |
| Solid–liquid equilibrium temperature (K) | 3 |
| Boiling temperature at pressure P (K) | 2 |
| Mole fraction | 2 |
| Molar heat capacity at constant pressure (J/K/mol) | 1 |
| Apparent molar heat capacity (J/K/mol) | 1 |
| Molar enthalpy of solution (kJ/mol) | 1 |
| Thermal conductivity (W/m/K) | 1 |

None of these is the excess molar enthalpy of mixing.

### Closest Related Measurement

The closest enthalpy-related measurement found is a **molar enthalpy of solution** block:

- **Literature:** GLOBlit_5958 · DOI: 10.1016/j.tca.2011.09.009
- **Block:** PROPblock_1
- **System:** Water (solute) dissolved in DMSO (solvent)
- **Method:** Isoperibol calorimetry

This measures the enthalpy change upon dissolving water into DMSO at very low concentration — a related but distinct quantity from the composition-dependent excess molar enthalpy of mixing across the full mole-fraction range.

### Chemistry Context

Water + DMSO is well known in the broader literature for its strongly exothermic mixing, with Hᴱ reaching a deep minimum (on the order of −2 to −3 kJ/mol) near x(DMSO) ≈ 0.3–0.4 at 298.15 K, attributed to strong hydrogen bonding between water and the S=O group of DMSO. However, **no such composition-dependent Hᴱ curves are available in the ThermoML holdings** for this system.

### Core claims

- No excess molar enthalpy (Hᴱ) data for the binary system water + DMSO were found in the ThermoML database, despite thorough searching across multiple strategies.
- The ThermoML database does contain 29 property blocks across 16 papers (1,601 data points) for water + DMSO spanning T = 253.15–393.15 K, but these cover other properties such as mass density, speed of sound, viscosity, and solid–liquid equilibrium temperature — none of which is excess molar enthalpy of mixing.
- The closest enthalpy-related measurement found is a molar enthalpy of solution block (DOI: 10.1016/j.tca.2011.09.009) measuring the enthalpy change upon dissolving water into DMSO at very low concentration, which is a related but distinct quantity from composition-dependent excess molar enthalpy.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5958 | 10.1016/j.tca.2011.09.009 | PROPblock_1 |  | This block is the closest enthalpy-related measurement for the water + DMSO system in ThermoML, reporting a molar enthalpy of solution of -5.38 kJ/mol at 298.15 K via isoperibol calorimetry. The answer correctly identifies it as a related but distinct quantity from the requested excess molar enthalpy of mixing, and uses it to document what the database does contain. |

### Suggested follow-ups

- Search for excess molar enthalpy data for water+DMSO in other thermodynamic databases (e.g., NIST TDE, Dortmund Data Bank) which may hold the classic calorimetric HE curves for this system.
- Consider using the molar enthalpy of solution data from GLOBlit_5958 / PROPblock_1 as a limiting-dilution anchor point and supplement with literature HE values outside ThermoML.
- Search ThermoML for excess molar enthalpy data for water with other sulfoxides or structurally related aprotic solvents to compare mixing behavior.
