**Excess molar volume (VE) data for the binary system water + 1-propanol at 298.15 K was not found in the ThermoML database.**

### Search Summary

**Compounds resolved:**
- Water → GLOBcomp_1
- 1-Propanol (propan-1-ol) → GLOBcomp_5
- Excess molar volume → GLOBprop_28

**What was searched:**
1. Binary blocks with both water + 1-propanol filtered for excess molar volume (GLOBprop_28) — **0 results**, even with no temperature filter and both declared and subsystem scopes.

2. Excess molar volume blocks for 1-propanol with any binary partner — blocks were found, but none involve water. The available VE data for 1-propanol pairs with other co-solvents including:
   - 1-butyl-3-methylimidazolium nitrate (GLOBlit_3116, PROPblock_14)
   - 3-methylbutyl ethanoate (GLOBlit_3325, PROPblock_20)
   - 1-methylimidazolium acetate (GLOBlit_3540, PROPblock_23)
   - 2-pyrrolidinone (GLOBlit_5836, PROPblock_16)
   - formamide (GLOBlit_6063, PROPblock_7)
   - and one additional system (GLOBlit_8993)

3. Any binary data for water + 1-propanol (no property filter) — multiple blocks were found across numerous DOIs, covering properties including mass density (GLOBprop_1), mole fraction/VLE (GLOBprop_2), activity coefficient (GLOBprop_3), viscosity (GLOBprop_4), and others — but **excess molar volume is not among them**.

### Conclusion

The ThermoML database contains extensive thermodynamic data for the water + 1-propanol binary system (density, VLE, viscosity, activity coefficients, etc.) but does not include excess molar volume measurements for this particular pair. VE data for 1-propanol exists only with other co-solvents (ionic liquids, formamide, isoamyl acetate, 2-pyrrolidinone).

### Summary

Excess molar volume (VE) data for the binary system water + 1-propanol at 298.15 K was not found in the ThermoML database. The compounds were resolved as water (GLOBcomp_1) and 1-propanol (GLOBcomp_5), and excess molar volume corresponds to GLOBprop_28. Searching binary blocks containing both components filtered for GLOBprop_28 returned 0 results, even with no temperature filter. The database does contain extensive data for water + 1-propanol covering other properties such as mass density (GLOBprop_1), mole fraction/VLE (GLOBprop_2), activity coefficient (GLOBprop_3), and viscosity (GLOBprop_4), but excess molar volume is not among them. VE data for 1-propanol exists only paired with other co-solvents, including 1-butyl-3-methylimidazolium nitrate, 3-methylbutyl ethanoate, 1-methylimidazolium acetate, 2-pyrrolidinone, and formamide.

### Core claims

- Excess molar volume (VE) data for the binary system water + 1-propanol at 298.15 K was not found in the ThermoML database.
- The ThermoML database contains extensive thermodynamic data for the water + 1-propanol binary system (density, VLE, viscosity, activity coefficients, etc.) but does not include excess molar volume measurements for this pair.
- VE data for 1-propanol in the ThermoML database exists only with other co-solvents (ionic liquids, formamide, isoamyl acetate, 2-pyrrolidinone), not with water.

**Status:** no_results

---

## Core ID Updates (deterministic ledger)

Deterministic identifier updates; rendered by the browser.

```json
[
  {
    "action": "add",
    "core_GLOB_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "action": "add",
    "core_GLOB_id": "GLOBcomp_5",
    "registry_id": "propan-1-ol",
    "name": "propan-1-ol"
  },
  {
    "action": "add",
    "core_GLOB_id": "GLOBprop_28",
    "registry_id": "excess_molar_volume_m3_mol",
    "name": "Excess molar volume, m3/mol"
  }
]
```