1. Should those diagnostic declarations override the original calculated-value designations, or should the original designations govern while the conflicting source assignments are recorded?

   **Your reply:** A — Keep original roles and count diagnostic source errors separately from raw measurement matches/misses (Recommended)
