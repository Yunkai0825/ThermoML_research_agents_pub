# Analysis Run — [run id removed] (Round 1)

**Question:** What density should I expect for a liquid mixture containing one mole of ethanol per three moles of water at 310 K? Explain the measured evidence and correlation used for the prediction and give its applicable range.

**[run statistics removed]**

---

## Answer

## Predicted Density of Ethanol + Water at x_ethanol = 0.25, T = 310 K

**Short answer:** The expected mass density of a liquid mixture containing 1 mole of ethanol per 3 moles of water (x_ethanol = 0.25, x_water = 0.75) at 310 K is approximately **910 kg/m³** (≈ 0.910 g/cm³).

---

### Measured Evidence

The prediction is based on experimental density data for the binary ethanol–water system from:

**Primary source:** Khempirova et al., *J. Chem. Thermodyn.* **2018**, DOI [10.1016/j.jct.2018.02.022](https://doi.org/10.1016/j.jct.2018.02.022) (GLOBlit_5201), PROPblock_19.

This block contains **244 data points** of directly measured mass density (kg/m³) as a function of ethanol mole fraction at atmospheric pressure, spanning the full composition range (x_ethanol = 0 to 1). The data cover **four isotherms** including 298.15 K and 308.15 K, each with ~61 composition points — excellent coverage for Redlich-Kister fitting.

The density was measured by vibrating-tube densimetry and reported as a direct value (no reference subtraction needed). The data quality is high, with the RK fits achieving R² > 0.996 at both temperatures.

---

### Correlation Method: Redlich-Kister Polynomial

The composition dependence of density at each isotherm was fitted using a **Redlich-Kister (RK) polynomial with a linear mixing rule**:

$$\rho(x_1) = x_1 \rho_1^* + (1-x_1) \rho_2^* + x_1(1-x_1) \sum_{k=0}^{n} A_k (2x_1 - 1)^k$$

where x₁ = mole fraction of ethanol (component 1), and ρ₁\*, ρ₂\* are the pure-component densities extracted from the block endpoints.

#### Fit at T = 308.15 K (closest measured isotherm to 310 K)

| Parameter | Value |
|-----------|-------|
| Pure ethanol density | 777.919 kg/m³ |
| Pure water density | 993.558 kg/m³ |
| BIC-selected RK order | 5 |
| R² | 0.9975 |
| RMSE | 0.544 kg/m³ |
| Data points (mixture) | 56 |

**RK coefficients (A₀ through A₅):**
| A₀ | A₁ | A₂ | A₃ | A₄ | A₅ |
|----|----|----|----|----|-----|
| −142.149 | 44.111 | 40.689 | −68.812 | −61.546 | 74.489 |

**Prediction at x_ethanol = 0.25, T = 308.15 K:**
- Linear baseline: 0.25 × 777.92 + 0.75 × 993.56 = **939.65 kg/m³**
- Excess (deviation from linear): x₁(1−x₁) × Σ Aₖ(−0.5)^k = 0.1875 × (−151.61) = **−28.43 kg/m³**
- **ρ(0.25, 308.15 K) = 911.2 kg/m³**

#### Fit at T = 298.15 K (second bracketing isotherm)

| Parameter | Value |
|-----------|-------|
| Pure ethanol density | 786.593 kg/m³ |
| Pure water density | 996.569 kg/m³ |
| BIC-selected RK order | 5 |
| R² | 0.9966 |
| RMSE | 0.577 kg/m³ |
| Data points (mixture) | 56 |

**RK coefficients (A₀ through A₅):**
| A₀ | A₁ | A₂ | A₃ | A₄ | A₅ |
|----|----|----|----|----|-----|
| −130.607 | 36.494 | 52.028 | −83.606 | −73.710 | 95.576 |

**Prediction at x_ethanol = 0.25, T = 298.15 K:**
- Linear baseline: 0.25 × 786.59 + 0.75 × 996.57 = **944.08 kg/m³**
- Excess: 0.1875 × (−132.99) = **−24.94 kg/m³**
- **ρ(0.25, 298.15 K) = 919.1 kg/m³**

---

### Interpolation to 310 K

Since 310 K falls between the two measured isotherms (298.15 K and 308.15 K), a linear temperature interpolation gives:

- dρ/dT at x = 0.25: (911.2 − 919.1) / (308.15 − 298.15) = **−0.79 kg/(m³·K)**
- ρ(0.25, 310 K) = 911.2 + (−0.79) × (310 − 308.15) = **909.7 kg/m³**

This is a short (1.85 K) extrapolation beyond the 308.15 K isotherm, well within the reliability of the linear temperature trend.

### **Result: ρ ≈ 910 kg/m³ at x_ethanol = 0.25, T = 310 K, P = 101 kPa**

---

### Chemistry Insight

The large negative density deviation from linear mixing (about −28 kg/m³ at this composition, or roughly −3%) reflects the well-known **volume expansion upon mixing** ethanol and water. When ethanol molecules disrupt the hydrogen-bond network of water, the resulting restructuring of molecular packing leads to a mixture that is less dense than a simple weighted average of the pure components would predict. This effect is strongest near x_ethanol ≈ 0.3–0.4 (where the maximum excess volume occurs) and your composition (x = 0.25) sits on the water-rich side of this maximum.

### Applicable Range

The RK correlation is valid for:
- **Composition:** Full range, x_ethanol = 0 to 1 (mole fraction)
- **Temperature:** 298.15–308.15 K (fitted isotherms); short extrapolation to ~313 K is reasonable
- **Pressure:** Atmospheric (~101 kPa)
- **Phase:** Liquid (ethanol and water are fully miscible at all compositions under these conditions)

The RMSE of ~0.5 kg/m³ corresponds to an uncertainty of about ±0.05% in density, which is typical of high-quality vibrating-tube densimetry data.

### Core claims

- The predicted mass density of a liquid ethanol–water mixture at x_ethanol = 0.25, T = 310 K, and atmospheric pressure (~101 kPa) is approximately 910 kg/m³ (≈ 0.910 g/cm³).
- The prediction is based on Redlich-Kister polynomial fits (order 5, R² > 0.996, RMSE ≈ 0.5 kg/m³) to 244 experimental vibrating-tube densimetry data points from Khempirova et al. (J. Chem. Thermodyn., 2018) at 298.15 K and 308.15 K, with linear temperature interpolation/short extrapolation (1.85 K) to 310 K.
- At x_ethanol = 0.25 and 308.15 K, the density deviation from ideal (linear) mixing is approximately −28 kg/m³ (about −3%), reflecting volume expansion upon mixing due to disruption of water's hydrogen-bond network by ethanol.
- The correlation is valid over the full ethanol mole-fraction range (0 to 1) at atmospheric pressure and 298–308 K, with short extrapolation to ~313 K considered reasonable; the fitted RMSE of ~0.5 kg/m³ corresponds to an uncertainty of about ±0.05%.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19 |  | Binary ethanol + water mass density (kg/m³) measured by vibrating-tube densimetry. 244 data points covering mole fraction of ethanol from 0 to 1 at temperatures 293.15–308.15 K and pressure 92.3 kPa. Direct value response (BLKprop_1 / GLOBprop_1). RK fits performed at the 298.15 K and 308.15 K isotherms (56 mixture points each) to bracket and interpolate to the 310 K target. |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 |  | Binary ethanol + water mass density (kg/m³), 810 data points, temperatures 298.15–348.15 K, pressures 100–40000 kPa, mole fraction of ethanol 0.003–1. Inspected but RK fitting at individual isotherms near 310 K yielded 0 mixture points after constraint filtering; not used for the final prediction. |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_2 |  | Binary ethanol + water mass density reported as difference from pure solvent (reference_difference response), 565 data points, temperatures 298.15–573.15 K, pressures 390–30300 kPa, molality basis. Inspected but not used due to reference-difference response type and high-pressure conditions. |
| GLOBlit_11136 | 10.1021/je800150h | PROPblock_9 |  | Binary ethanol + water mass density (kg/m³), 108 data points, temperatures 268.1–323.15 K, pressure 101 kPa, mole fraction of water 0.1–0.9. Inspected as a candidate for additional temperature coverage but not fitted. |
| GLOBlit_1483 | 10.1016/j.fluid.2014.05.032 | PROPblock_1 |  | Binary ethanol + water mass density (kg/m³), 140 data points, temperatures 292.95–448.15 K, pressures 2450–40140 kPa, mole fraction of ethanol 0.0163–0.0946. Inspected but not used due to narrow composition range and high-pressure conditions. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5201 | PROPblock_19 | mass_density_kg_m3 | 5 | -142.149; 44.1112; 40.6894; -68.8116; -61.5464; 74.4891 | 0.997496 | 0.543792 | 56 | 308.15 | linear |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_5201 | PROPblock_19 | mass_density_kg_m3 | 5 | -130.607; 36.494; 52.0283; -83.6062; -73.7102; 95.5763 | 0.996578 | 0.576832 | 56 | 298.15 | linear |  | 10.1016/j.jct.2018.02.022 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
