# Analysis Run — [run id removed] (Round 1)

**Question:** At 25 °C, what Redlich–Kister correlation best represents the density of liquid methanol + water? Select the polynomial order by BIC and report the equation, coefficients and units, R², RMSE, BIC, and composition range.

**[run statistics removed]**

---

## Answer

## Redlich–Kister Correlation for the Density of Liquid Methanol + Water at 25 °C

### Data Source

The fit uses experimental mass-density data from:

**DOI 10.1016/j.jct.2007.05.004** (GLOBlit_2825), block PROPblock_10  
- Binary system: water (GLOBcomp_1) + methanol (GLOBcomp_4)  
- Temperature: 298.15 K (25 °C), constrained isotherm  
- Pressure: 101 kPa (atmospheric)  
- Composition range: full mole-fraction span, x(water) = 0 to 1  
- 11 interior mixture points + 2 pure-component endpoints (13 compositions total at this temperature, 39 rows across 3 temperatures in the block)  
- Measurement method: vibrating-tube densimeter  

### Pure-Component Endpoint Densities

| Component | ρ* (kg m⁻³) at 298.15 K |
|-----------|--------------------------|
| Water     | 997.05                   |
| Methanol  | 787.20                   |

(Extracted from the block's own edge rows.)

### Redlich–Kister Model

The density is represented with a **linear (mole-fraction-weighted) mixing rule** plus a Redlich–Kister deviation polynomial:

$$\rho(x_1) = x_1\,\rho_1^* + x_2\,\rho_2^* + x_1\,x_2\sum_{k=0}^{n} A_k\,(x_1 - x_2)^k$$

where  
- x₁ = mole fraction of water, x₂ = 1 − x₁ = mole fraction of methanol  
- ρ₁* = 997.05 kg m⁻³ (pure water), ρ₂* = 787.20 kg m⁻³ (pure methanol)  
- Units of all Aₖ coefficients: **kg m⁻³**

### BIC-Selected Order and Coefficients

The Bayesian Information Criterion selects **order 5** (6 coefficients):

| k | Aₖ (kg m⁻³) |
|---|-------------|
| 0 | −42.3108    |
| 1 |   2.4613    |
| 2 |   7.2809    |
| 3 |  −0.4197    |
| 4 | −46.1538    |
| 5 | −43.8431    |

### Goodness of Fit

| Metric | Value |
|--------|-------|
| R²     | 0.999796 |
| RMSE   | 0.0389 kg m⁻³ |
| BIC    | −57.07 |
| Data points (mixture) | 11 |

### BIC Comparison Across Orders

| Order | BIC    | R²       | RMSE (kg m⁻³) |
|-------|--------|----------|----------------|
| 0     |  2.56  | 0.8628   | 1.0075         |
| 1     |  3.22  | 0.8829   | 0.9308         |
| 2     | −1.47  | 0.9385   | 0.6744         |
| 3     | −12.24 | 0.9814   | 0.3707         |
| 4     | −29.48 | 0.9969   | 0.1519         |
| **5** | **−57.07** | **0.9998** | **0.0389** |

### Composition Range

The correlation is valid over the **full mole-fraction range**: x(water) = 0.0 to 1.0 (equivalently, x(methanol) = 0.0 to 1.0), at 298.15 K and 101 kPa.

### Chemistry Insight

The large negative leading coefficient A₀ ≈ −42.3 kg m⁻³ reflects the well-known **volume contraction** (negative excess volume) upon mixing methanol and water, driven by strong O–H···O hydrogen bonding between methanol and water molecules that allows more efficient molecular packing than in either pure liquid. The higher-order terms (especially A₄ and A₅, both strongly negative) capture the pronounced asymmetry of this contraction, which peaks closer to the water-rich side of the composition range. The fifth-order polynomial is needed to faithfully reproduce this asymmetric shape — lower orders leave systematic residuals of ~0.15–1.0 kg m⁻³.

### Output Files

- Fit data CSV and excess-property CSV are available in the session data directory.
- Fit plot and excess-property plot (PNG) are available in the session plots directory.

### Core claims

- A Redlich–Kister polynomial of order 5 (six coefficients) best fits the liquid density of methanol + water at 298.15 K and 101 kPa over the full mole-fraction range, as selected by the Bayesian Information Criterion (BIC = −57.07, R² = 0.999796, RMSE = 0.0389 kg m⁻³).
- The model uses a linear mole-fraction-weighted mixing rule with pure-component densities of 997.05 kg m⁻³ (water) and 787.20 kg m⁻³ (methanol), plus a Redlich–Kister deviation term x₁x₂ΣAₖ(x₁−x₂)^k with coefficients A₀ = −42.31, A₁ = 2.46, A₂ = 7.28, A₃ = −0.42, A₄ = −46.15, A₅ = −43.84 kg m⁻³.
- The large negative A₀ reflects the well-known volume contraction (negative excess volume) upon mixing methanol and water, attributed to strong hydrogen bonding enabling more efficient molecular packing.
- The strongly negative A₄ and A₅ coefficients capture the pronounced asymmetry of the volume contraction, which peaks closer to the water-rich side; lower-order fits leave systematic residuals of approximately 0.15–1.0 kg m⁻³.
- The fit is based on 11 interior mixture data points from vibrating-tube densimetry measurements reported in DOI 10.1016/j.jct.2007.05.004.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 |  | Mass density (GLOBprop_1, kg/m³) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1) mixture. 39 total data points across 3 temperatures (293.15–303.15 K), 13 unique compositions spanning x(water) = 0.0 to 1.0, P = 101 kPa. 11 interior mixture points at 298.15 K used for Redlich–Kister fitting. Density range 782.48–998.20 kg/m³. Measurement method: vibrating-tube densimeter (GLOBmeas_134). Liquid phase (GLOBphase_1). Pure-component endpoint densities at 298.15 K: water = 997.05 kg/m³, methanol = 787.20 kg/m³ (block-edge values). BIC-selected order 5 (BIC = −57.07) over orders 0–5. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_2825 | PROPblock_10 | mass density | 5 | -42.3108; 2.46129; 7.28093; -0.41971; -46.1538; -43.8431 | 0.999796 | 0.0388524 | 11 | 298.15 | linear |  | 10.1016/j.jct.2007.05.004 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
