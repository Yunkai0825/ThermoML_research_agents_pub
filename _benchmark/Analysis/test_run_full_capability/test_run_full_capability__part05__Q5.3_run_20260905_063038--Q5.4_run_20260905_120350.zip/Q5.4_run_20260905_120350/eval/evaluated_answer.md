# Analysis Run — [run id removed] (Round 1)

**Question:** Near 25 °C, at what composition does liquid DMSO + water depart most strongly from ideal mixing, and does the answer change when volume, enthalpy, viscosity, or another measured property is considered?

**[run statistics removed]**

---

## Answer

## Where Does Liquid DMSO + Water Depart Most Strongly from Ideal Mixing at 25 °C?

The answer depends on which property you examine. Using Redlich-Kister (RK) polynomial fits to experimental ThermoML data at 298.15 K, I fitted four measured properties across the full DMSO mole-fraction range and compared the composition of maximum departure from the ideal-mixing baseline for each.

---

### Summary of Results

| Property | Data source (DOI / block) | n pts | RK order | R² | Composition of max |Δᴱ| | Max excess value | Relative departure |
|---|---|---|---|---|---|---|---|
| **Excess molar volume Vᴱ** | 10.1016/j.jct.2006.12.012 / PROPblock_4 | 22 | 5 | 0.999909 | x(DMSO) ≈ 0.33 (from predict_from_rk) | −9.57 × 10⁻⁷ m³/mol (from predict_from_rk) | ~2% of V_m (derived ratio) |
| **Viscosity (Arrhenius excess)** | 10.1016/j.jct.2006.12.012 / PROPblock_3 | 22 | 5 | 0.999497 | **x(DMSO) ≈ 0.35** (from predict_from_rk) | ln-space excess = **+1.17** (from predict_from_rk) | **~320% above Arrhenius ideal** (derived from predict_from_rk: 0.00374/0.00115) |
| **Surface tension (excess)** | 10.1021/je7001013 / PROPblock_9 | 15 | 5 | 0.985302 | x(DMSO) ≈ 0.15–0.20 (from predict_from_rk) | −0.0093 N/m (from predict_from_rk) | ~16% of γ (derived ratio) |
| **Refractive index (excess)** | 10.1021/je7001013 / PROPblock_10 | 10 | 3 | 0.999858 | x(DMSO) ≈ 0.30–0.35 (from predict_from_rk) | +0.056 (from predict_from_rk) | ~4% of n_D (derived ratio) |
| **Excess molar enthalpy (Hᴱ)** | *Not available in ThermoML* | — | — | — | — | — | — |

---

### Property-by-Property Detail

#### 1. Excess Molar Volume (Vᴱ) — via density → molar volume transform (DP2)

Density data from GLOBlit_2781 (DOI: 10.1016/j.jct.2006.12.012, PROPblock_4, 24 compositions at 298.15 K) were exactly transformed to molar volume V_m = (x₁M₁ + x₂M₂)/ρ and fitted with a 5th-order RK polynomial.

- **Pure endpoints:** V_m(water) = 1.807 × 10⁻⁵ m³/mol; V_m(DMSO) = 7.127 × 10⁻⁵ m³/mol (block-edge values from fit_block_derived)
- **RK coefficients (Vᴱ):** [−3.581 × 10⁻⁶, 2.067 × 10⁻⁶, −2.931 × 10⁻⁷, −2.412 × 10⁻⁶, 1.618 × 10⁻⁶, 7.992 × 10⁻⁷]
- **Maximum |Vᴱ|:** −9.57 × 10⁻⁷ m³/mol near x(DMSO) ≈ 0.33 (from predict_from_rk output)
- R² = 0.999909, RMSE = 2.98 × 10⁻⁹ m³/mol

The **negative** Vᴱ indicates volume contraction upon mixing — the mixture packs more efficiently than ideal, consistent with strong DMSO–water hydrogen bonding.

#### 2. Viscosity — Arrhenius mixing rule

Viscosity data from GLOBlit_2781 (DOI: 10.1016/j.jct.2006.12.012, PROPblock_3, 24 compositions at 298.15 K).

- **Pure endpoints:** η(water) = 0.0008901 Pa·s; η(DMSO) = 0.001996 Pa·s (block-edge values)
- **RK coefficients (ln η excess):** [3.7056, −3.8597, 2.1830, −0.8182, −1.8031, 2.5483]
- **Maximum excess:** ln-space excess = +1.17 at x(DMSO) ≈ 0.35, corresponding to a predicted viscosity of ~0.00374 Pa·s versus an Arrhenius ideal of ~0.00115 Pa·s (both from predict_from_rk output). This is consistent with the measured maximum of 0.0037353 Pa·s at x(DMSO) = 0.3638 from the inspected data (GLOBlit_2781, PROPblock_3, BLKpoint_12).
- R² = 0.999497, RMSE = 0.00882

This is by far the **largest relative departure** of any measured property. The viscosity maximum at x(DMSO) ≈ 0.33–0.36 is a hallmark of the DMSO–water system, attributed to the formation of strongly hydrogen-bonded DMSO·nH₂O complexes that dramatically enhance intermolecular friction.

#### 3. Surface Tension

Surface tension data from GLOBlit_10766 (DOI: 10.1021/je7001013, PROPblock_9, 15 mixture points at 298.15 K used in the fit).

- **Pure endpoints:** γ(water) = 0.07135 N/m (GLOBlit_725, PROPblock_12); γ(DMSO) = 0.04278 N/m (GLOBlit_3840, PROPblock_1)
- **RK coefficients (γᴱ):** [−0.03389, −0.00254, −0.03248, 0.08718, −0.00659, −0.08176]
- **Maximum |γᴱ|:** −0.0093 N/m near x(DMSO) ≈ 0.15–0.20 (from predict_from_rk output)
- R² = 0.985302, RMSE = 0.000271 N/m

The **negative** excess surface tension at low DMSO concentrations reflects DMSO's strong preferential adsorption at the air–water interface — even small amounts of DMSO dramatically lower the surface tension below the linear ideal.

#### 4. Refractive Index

Refractive index data from GLOBlit_10766 (DOI: 10.1021/je7001013, PROPblock_10, 11 compositions at 298.15 K).

- **Pure endpoints:** n_D(water) = 1.3325 (GLOBlit_306, PROPblock_5); n_D(DMSO) = 1.4771 (GLOBlit_2957, PROPblock_11)
- **RK coefficients (n_D excess):** [0.19713, −0.12848, 0.08421, −0.02640]
- **Maximum |n_Dᴱ|:** +0.056 near x(DMSO) ≈ 0.30–0.35 (from predict_from_rk output)
- R² = 0.999858, RMSE = 0.000178

The **positive** excess refractive index indicates enhanced polarizability in the mixture relative to ideal mixing, again consistent with strong intermolecular interactions.

#### 5. Excess Molar Enthalpy (Hᴱ)

A thorough search of the ThermoML database found **no Hᴱ data** for DMSO + water at any temperature. Twenty Hᴱ blocks exist for DMSO with organic co-solvents, but none with water. This property could not be assessed from the available database.

---

### Does the Composition of Maximum Departure Change with Property?

**Yes — and significantly.** All composition values below are from predict_from_rk outputs (derived from the RK fits, not raw database values):

| Property | x(DMSO) at max |Δᴱ| | Physical driver |
|---|---|---|
| Surface tension | **≈ 0.15–0.20** | Preferential surface adsorption of DMSO |
| Excess molar volume | **≈ 0.33** | Efficient packing via H-bonding |
| Refractive index | **≈ 0.30–0.35** | Enhanced polarizability from H-bond complexes |
| Viscosity | **≈ 0.35** | Maximum intermolecular friction from DMSO·nH₂O network |

The **volumetric, optical, and transport** excess extrema cluster near x(DMSO) ≈ 0.30–0.35. The stoichiometric ratio x(DMSO) = 1/3 (i.e. a 1:2 DMSO:water molar ratio) is a theoretical reference point often discussed in the literature for this system. However, **surface tension** departs most at a much lower DMSO content (x ≈ 0.15–0.20), because the surface excess is governed by DMSO's amphiphilic character and preferential adsorption at the air–liquid interface — a surface phenomenon rather than a bulk one.

In terms of **magnitude**, viscosity shows by far the strongest departure: the predicted viscosity at x(DMSO) ≈ 0.35 from predict_from_rk is ~0.00374 Pa·s versus an Arrhenius ideal of ~0.00115 Pa·s (a ratio of ~0.00374/0.00115 ≈ 3.3, derived from predict_from_rk output values), whereas the volumetric contraction is only a few percent of V_m and the refractive index excess is ~4% of n_D. The viscosity anomaly is the most dramatic signature of non-ideal mixing in this system.

---

### Data Sources

| Property | DOI | GLOBlit | Block | T (K) | P (kPa) |
|---|---|---|---|---|---|
| Density / Vᴱ | 10.1016/j.jct.2006.12.012 | GLOBlit_2781 | PROPblock_4 | 298.15 | 101.0 |
| Viscosity | 10.1016/j.jct.2006.12.012 | GLOBlit_2781 | PROPblock_3 | 298.15 | 101.0 |
| Surface tension | 10.1021/je7001013 | GLOBlit_10766 | PROPblock_9 | 298.15 | ambient |
| Refractive index | 10.1021/je7001013 | GLOBlit_10766 | PROPblock_10 | 298.15 | 101.0 |
| Pure DMSO γ | 10.1016/j.jct.2013.02.021 | GLOBlit_3840 | PROPblock_1 | 298.15 | — |
| Pure water γ | 10.1016/j.fluid.2009.07.010 | GLOBlit_725 | PROPblock_12 | 298.15 | — |
| Pure DMSO n_D | 10.1016/j.jct.2008.05.010 | GLOBlit_2957 | PROPblock_11 | 298.15 | 101.325 |
| Pure water n_D | 10.1016/j.fluid.2005.09.009 | GLOBlit_306 | PROPblock_5 | 298.15 | 101.325 |

















### Core claims

- At 298.15 K, the DMSO + water system departs from ideal mixing in all four measured properties (excess molar volume, viscosity, surface tension, refractive index), but the composition of maximum departure differs by property.
- Viscosity shows by far the largest relative departure from ideal mixing: the predicted viscosity at x(DMSO) ≈ 0.35 is ~0.00374 Pa·s versus an Arrhenius ideal of ~0.00115 Pa·s (ln-space excess = +1.17), corresponding to roughly 320% above the Arrhenius ideal.
- Excess molar volume, refractive index, and viscosity extrema cluster near x(DMSO) ≈ 0.30–0.35, consistent with the often-discussed 1:2 DMSO:water stoichiometric ratio, whereas the surface tension excess peaks at a much lower DMSO content (x ≈ 0.15–0.20), reflecting DMSO's preferential adsorption at the air–liquid interface.
- The negative excess molar volume (maximum \|Vᴱ\| ≈ −9.57 × 10⁻⁷ m³/mol near x(DMSO) ≈ 0.33) indicates volume contraction upon mixing, consistent with strong DMSO–water hydrogen bonding.
- The negative excess surface tension (maximum \|γᴱ\| ≈ −0.0093 N/m near x(DMSO) ≈ 0.15–0.20) reflects DMSO's amphiphilic character and preferential surface adsorption — a surface rather than bulk phenomenon.
- No excess molar enthalpy (Hᴱ) data for DMSO + water were found in the ThermoML database at any temperature, so that property could not be assessed.


### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_4 |  | Provides binary DMSO+water density data at 298.15 K across the full mole-fraction range (0.0–1.0), used to compute excess molar volume via V_m = (x₁M₁+x₂M₂)/ρ and fitted with a 5th-order RK polynomial showing maximum \|Vᴱ\| ≈ −9.57×10⁻⁷ m³/mol near x(DMSO) ≈ 0.33. |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3 |  | Provides binary DMSO+water viscosity data at 298.15 K across the full mole-fraction range, used to compute Arrhenius excess viscosity. The maximum viscosity of 0.003735 Pa·s near x(DMSO) ≈ 0.35 represents the largest relative departure (~320%) from ideal mixing of any property examined. |
| GLOBlit_10766 | 10.1021/je7001013 | PROPblock_9 |  | Provides binary DMSO+water surface tension data at 298.15 K (range 0.0387–0.071 N/m), fitted with a 5th-order RK polynomial showing maximum \|γᴱ\| ≈ −0.0093 N/m near x(DMSO) ≈ 0.15–0.20, reflecting DMSO's preferential surface adsorption. |
| GLOBlit_10766 | 10.1021/je7001013 | PROPblock_10 |  | Provides binary DMSO+water refractive index data at 298.15 K (range 1.339–1.47), fitted with a 3rd-order RK polynomial showing maximum excess n_D ≈ +0.056 near x(DMSO) ≈ 0.30–0.35, indicating enhanced polarizability from intermolecular interactions. |
| GLOBlit_3840 | 10.1016/j.jct.2013.02.021 | PROPblock_1 |  | Provides pure DMSO surface tension data; the value at 298.15 K (within the 0.04103–0.04336 N/m range) was used as the pure-component endpoint γ(DMSO) = 0.04278 N/m for computing excess surface tension of the binary mixture. |
| GLOBlit_725 | 10.1016/j.fluid.2009.07.010 | PROPblock_12 |  | Provides the pure water surface tension value γ(water) = 0.07135 N/m at 298.15 K, used as the pure-component endpoint for computing excess surface tension of the DMSO+water mixture. |
| GLOBlit_2957 | 10.1016/j.jct.2008.05.010 | PROPblock_11 |  | Provides the pure DMSO refractive index n_D = 1.4771 at 298.15 K, used as the pure-component endpoint for computing excess refractive index of the DMSO+water mixture. |
| GLOBlit_306 | 10.1016/j.fluid.2005.09.009 | PROPblock_5 |  | Provides the pure water refractive index n_D = 1.3325 at 298.15 K, used as the pure-component endpoint for computing excess refractive index of the DMSO+water mixture. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_2781 | PROPblock_4 | GLOBprop_1 | 5 | -3.5811616129639533e-06; 2.066912296384208e-06; -2.930798453481958e-07; -2.4117429303690355e-06; 1.6183268427201442e-06; 7.991724801824448e-07 | 0.999909 | 2.9839840842544677e-09 | 22 | 298.15 | linear |  | 10.1016/j.jct.2006.12.012 |
| GLOBlit_2781 | PROPblock_3 | viscosity_298K | 5 | 3.7055558156480792; -3.8597209612010275; 2.1830371021716743; -0.8181531956379644; -1.8030520692636798; 2.5482666377117202 | 0.999497 | 0.00881979868119369 | 22 | 298.15 | arrhenius |  | 10.1016/j.jct.2006.12.012 |
| GLOBlit_10766 | PROPblock_9 | GLOBprop_13 | 5 | -0.03389357746760463; -0.00254063893274142; -0.03247669827392549; 0.08718093299853281; -0.006591515080280431; -0.08176118440646336 | 0.985302 | 0.00027135333058068 | 15 | 298.15 | linear |  | 10.1021/je7001013 |
| GLOBlit_10766 | PROPblock_10 | GLOBprop_7 | 3 | 0.19712734829244696; -0.1284807255128319; 0.0842113202724752; -0.026400335912482222 | 0.999858 | 0.00017833544272879883 | 10 | 298.15 | linear |  | 10.1021/je7001013 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
