# Analysis Run — [run id removed] (Round 1)

**Question:** What density should I expect for a liquid mixture containing one mole of ethanol per three moles of water at 310 K? Explain the measured evidence and correlation used for the prediction and give its applicable range.

**[run statistics removed]**

---

## Answer

## Predicted Density of Ethanol–Water (1 : 3 mol) at ~310 K

### Short answer

For a liquid mixture of **1 mol ethanol + 3 mol water** (x_ethanol = 0.25, x_water = 0.75 — derived from the user's stated 1 : 3 molar ratio, not a database datum), the Redlich-Kister correlation fitted to ThermoML experimental data predicts a mass density of approximately **917.3 kg/m³** (derived below from the RK formula applied to tool-returned coefficients and pure values) at the measured isotherm of **308.15 K** (inspected database temperature from PROPblock_9) and atmospheric pressure (101.0 kPa). The user's target of 310 K (user-specified, not a database temperature) is about 1.85 K above the fitted isotherm (computed: 310 − 308.15); because liquid density decreases with temperature, the value at exactly 310 K would be slightly lower, but no measured isotherm at exactly 310 K is available in the database for this system.

---

### Measured evidence

The prediction is based on **PROPblock_9** from DOI [10.1021/je800150h](https://doi.org/10.1021/je800150h) (GLOBlit_11136), which contains **108 mass-density data points** for the binary ethanol–water system measured by pycnometry at 101.0 kPa. The dataset spans:

- **Composition:** x(water) = 0.1 to 0.9 (from inspect_block)
- **Temperature:** 268.1 K to 323.15 K (from inspect_block)
- **Density range:** 774.3 to 977.3 kg/m³ (from inspect_block)

The 9 measured data points at the **T = 308.15 K** isotherm (inspected from PROPblock_9, INSP_38c2d7565fed) used for the fit are:

| x(water) | x(ethanol) | T (K) | ρ (kg/m³) | BLKpoint |
|-----------|------------|--------|-----------|----------|
| 0.1       | 0.9 (derived)       | 308.15 | 788.2     | BLKpoint_9 |
| 0.2       | 0.8 (derived)       | 308.15 | 801.4     | BLKpoint_21 |
| 0.3       | 0.7 (derived)       | 308.15 | 816       | BLKpoint_33 |
| 0.4       | 0.6 (derived)       | 308.15 | 831.4     | BLKpoint_45 |
| 0.5       | 0.5 (derived)       | 308.15 | 850.1     | BLKpoint_57 |
| 0.6       | 0.4 (derived)       | 308.15 | 871.4     | BLKpoint_69 |
| 0.7       | 0.3 (derived)       | 308.15 | 896.5     | BLKpoint_81 |
| 0.8       | 0.2 (derived)       | 308.15 | 923.8     | BLKpoint_93 |
| 0.9       | 0.1 (derived)       | 308.15 | 952.7     | BLKpoint_105 |

*(x(ethanol) values are derived as 1 − x(water).)*

### Pure-component endpoint values

Because the mixture block covers only x(water) = 0.1–0.9 (not the pure endpoints), pure-component densities were sourced from separate ThermoML measurements at 308.15 K (the closest measured temperature to the user's target in those pure-component blocks):

| Component | ρ* (kg/m³) | T (K)  | Source DOI                        | GLOBlit     |
|-----------|-----------|--------|-----------------------------------|-------------|
| Water     | 994.05    | 308.15 | 10.1016/j.fluid.2010.01.002       | GLOBlit_779 |
| Ethanol   | 776.51    | 308.15 | 10.1016/j.fluid.2005.10.022       | GLOBlit_323 |

These values are from inspected rows in the respective pure-component blocks (PROPblock_18 and PROPblock_2), not from PROPblock_9.

---

### Correlation: Redlich-Kister polynomial (linear mixing rule)

The density is modeled as:

**ρ(x₁) = x₁·ρ₁\* + x₂·ρ₂\* + x₁·x₂·Σᵢ Aᵢ·(x₁ − x₂)ⁱ**

where x₁ = x(ethanol), x₂ = x(water), and the linear baseline interpolates between the pure-component densities.

**Fit results (from fit_block, at the T = 308.15 K isotherm):**

| Parameter | Value |
|-----------|-------|
| BIC-selected order | 5 |
| R² | 0.999626 |
| RMSE | 0.158 kg/m³ |
| BIC | −19.98 |
| Data points fitted | 9 (mixture compositions) |

**Redlich-Kister coefficients A₀–A₅ (from fit_block output):**

| i | Aᵢ (kg/m³) |
|---|------------|
| 0 | −141.929 |
| 1 | −39.641 |
| 2 | 42.983 |
| 3 | 31.765 |
| 4 | −121.840 |
| 5 | −113.837 |

**Model-selection summary (from fit_block output):**

| Order | BIC    | R²       | RMSE    |
|-------|--------|----------|---------|
| 0     | 25.17  | 0.808565 | 3.584   |
| 1     | 9.23   | 0.974501 | 1.308   |
| 2     | 8.47   | 0.981637 | 1.110   |
| 3     | 5.61   | 0.989528 | 0.838   |
| 4     | −8.47  | 0.998285 | 0.339   |
| 5     | −19.98 | 0.999626 | 0.158   |

### Prediction at x(ethanol) = 0.25 (derived from user's 1 : 3 ratio)

Applying the RK formula at x₁ = 0.25 (ethanol), x₂ = 0.75 (water) — these compositions are derived from the user's stated 1 : 3 molar ratio, not database data:

All intermediate values below are **computed from the tool-returned RK coefficients and pure values**, not database data:

- **Linear baseline:** 0.25 × 776.51 + 0.75 × 994.05 = **939.7 kg/m³**
- **RK excess contribution:**
  x₁·x₂ = 0.1875; (x₁ − x₂) = −0.5
  Σ Aᵢ·(−0.5)ⁱ = (−141.929)·(1) + (−39.641)·(−0.5) + (42.983)·(0.25) + (31.765)·(−0.125) + (−121.840)·(0.0625) + (−113.837)·(−0.03125) ≈ −119.4
  Excess = 0.1875 × (−119.4) ≈ **−22.4 kg/m³**
- **Predicted density:** 939.7 − 22.4 ≈ **917.3 kg/m³**

Cross-check with predict_from_rk tool output: Y(x₁=0) = 994.05, Y(x₁=0.5) ≈ 849.798, Y(x₁=1) = 776.51, max |excess| = −36.0 kg/m³. The computed value at x₁ = 0.25 (917.3 kg/m³) is consistent with these bracketing values.

### Chemistry insight

The large negative excess density (about −22 kg/m³ at this composition — computed from the RK formula — and up to −36.0 kg/m³ near x_ethanol ≈ 0.4–0.5 per the predict_from_rk output) reflects the well-known **volume contraction** in ethanol–water mixtures. Hydrogen-bonding reorganization between ethanol and water molecules allows more efficient molecular packing than in either pure liquid, producing a mixture denser than the mole-fraction-weighted average of the pure components.

---

### Applicable range and limitations

| Dimension | Range |
|-----------|-------|
| **Composition** | x(water) = 0.1 to 0.9 (x(ethanol) = 0.1 to 0.9) |
| **Temperature** | Fitted isotherm: 308.15 K (inspected); full block spans 268.1–323.15 K |
| **Pressure** | 101.0 kPa (atmospheric) |

- The target composition x(ethanol) = 0.25 (derived from user's ratio) falls well within the fitted range (0.1–0.9).
- The user's target temperature of 310 K (user-specified) is not an exact measured isotherm in this block. The fit was performed at the nearest available isotherm of 308.15 K (inspected database value). For a more precise estimate at 310 K, one could fit additional isotherms from this block and interpolate, but no single isotherm at exactly 310 K exists in the ThermoML database for this system.
- The R² of 0.999626 and RMSE of 0.158 kg/m³ indicate an excellent fit, so the correlation uncertainty at x(ethanol) = 0.25 is well below 1 kg/m³.
- Extrapolation beyond x(water) = 0.1–0.9 is not recommended due to the high polynomial order (5th order).

### Output files

- **Fit data CSV:** `10_1021_je800150h_BPROPblock_9_T308.1_fit.csv`
- **Excess property CSV:** `10_1021_je800150h_BPROPblock_9_T308.1_excess.csv`
- **Fit plot:** `10_1021_je800150h_BPROPblock_9_T308.1_fit.png`
- **Excess plot:** `10_1021_je800150h_BPROPblock_9_T308.1_excess.png`






















### Core claims

- A 5th-order Redlich-Kister polynomial fitted to 9 ThermoML mass-density data points for ethanol–water at 308.15 K and 101.0 kPa (R² = 0.999626, RMSE = 0.158 kg/m³) predicts a density of approximately 917.3 kg/m³ at x(ethanol) = 0.25, x(water) = 0.75.
- The prediction is based on the nearest available measured isotherm of 308.15 K, not the user's target of 310 K; no measured isotherm at exactly 310 K exists in the database for this system, and the true density at 310 K would be slightly lower.
- The large negative excess density (approximately −22 kg/m³ at x(ethanol) = 0.25, and up to −36.0 kg/m³ near x(ethanol) ≈ 0.4–0.5) reflects volume contraction due to hydrogen-bonding reorganization in ethanol–water mixtures, making the mixture denser than the mole-fraction-weighted average of the pure components.
- Pure-component densities at 308.15 K used as endpoints were 776.51 kg/m³ for ethanol (DOI 10.1016/j.fluid.2005.10.022) and 994.05 kg/m³ for water (DOI 10.1016/j.fluid.2010.01.002), sourced from separate ThermoML blocks rather than from the mixture dataset.
- The fitted composition range is x(water) = 0.1 to 0.9; extrapolation beyond this range is not recommended due to the high polynomial order.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11136 | 10.1021/je800150h | PROPblock_9 |  | Primary data source: 108 mass-density points for the ethanol–water binary system spanning x(water) 0.1–0.9 and T 268.1–323.15 K at 101.0 kPa. The 9 data points at the 308.15 K isotherm were used to fit the 5th-order Redlich-Kister polynomial (R² = 0.999626, RMSE = 0.158 kg/m³) from which the density at x(ethanol) = 0.25 was predicted as ~917.3 kg/m³. |
| GLOBlit_779 | 10.1016/j.fluid.2010.01.002 | PROPblock_18 |  | Provides the pure-water density endpoint (994.05 kg/m³ at 308.15 K) needed for the linear mixing baseline of the Redlich-Kister fit, since PROPblock_9 only covers x(water) 0.1–0.9 and does not include pure-component endpoints. |
| GLOBlit_323 | 10.1016/j.fluid.2005.10.022 | PROPblock_2 |  | Provides the pure-ethanol density endpoint (776.51 kg/m³ at 308.15 K) needed for the linear mixing baseline of the Redlich-Kister fit, since PROPblock_9 only covers x(ethanol) 0.1–0.9 and does not include pure-component endpoints. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_11136 | PROPblock_9 | GLOBprop_1 | 5 | -141.92933561390174; -39.640763217445894; 42.98293988562761; 31.764761765987796; -121.8397268585265; -113.83742342682429 | 0.999626 | 0.1584208739800725 | 9 | 308.15 | linear |  | 10.1021/je800150h |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
