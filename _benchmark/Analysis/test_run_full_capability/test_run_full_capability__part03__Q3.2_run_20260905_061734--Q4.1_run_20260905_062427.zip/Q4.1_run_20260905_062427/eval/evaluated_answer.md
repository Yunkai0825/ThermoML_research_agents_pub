# Analysis Run — [run id removed] (Round 1)

**Question:** I need to estimate the viscosity of aqueous N-methyl-2-pyrrolidone near 25 °C, but direct measurements may be unavailable. Which chemically similar aqueous solvent system offers the most defensible surrogate, and what similarities and measured behavior justify that choice?

**[run statistics removed]**

---

## Answer

## Surrogate Selection for Aqueous N-Methyl-2-Pyrrolidone (NMP) Viscosity near 298.15 K

### Key Finding: Direct Measurements ARE Available

Before evaluating surrogates, it is important to note that **direct viscosity measurements for aqueous NMP at 298.15 K do exist** in the ThermoML database. Multiple data blocks were found, including GLOBlit_8238 (DOI 10.1021/je034073k, PROPblock_3) and GLOBlit_8242 (DOI 10.1021/je0340809, PROPblock_17), both containing data exactly at 298.15 K. A third block (GLOBlit_9372, DOI 10.1021/je100967k, PROPblock_17) covers nearby temperatures including 293.15 K (inspected row BLKpoint_1 of that block).

So a surrogate is not strictly necessary. However, if one were needed (e.g., for validation, cross-checking, or extending to conditions not covered), the analysis below identifies the best candidate.

---

### Candidate Surrogate Systems Evaluated

Three chemically similar aqueous amide systems were investigated for viscosity data at 298.15 K:

1. **2-Pyrrolidinone + Water** — DOI 10.1021/je0340809 (GLOBlit_8242), PROPblock_14; 18 points used in the 298.15 K Arrhenius fit
2. **N,N-Dimethylformamide (DMF) + Water** — DOI 10.1021/je050209y (GLOBlit_8676), PROPblock_9; 11 points at 298.15 K (complete block, single isotherm)
3. **N,N-Dimethylacetamide (DMAc) + Water** — **No viscosity data found** in ThermoML

---

### Redlich-Kister Fits (Arrhenius Mixing Rule for Viscosity, 298.15 K)

All three systems were fitted using the Arrhenius mixing rule (ln η is fitted as a function of composition):

| System | DOI (Lit ID) | Block | Pure η₁ (Pa·s) | Pure η₂ (Pa·s) | RK Order | R² | RMSE | n pts |
|--------|--------------|-------|-----------------|-----------------|----------|----|------|-------|
| NMP + water | 10.1021/je034073k (GLOBlit_8238) | PROPblock_3 | 0.001656 (NMP) | 0.00089 (water) | 4 | 0.999957 | 0.002866 | 11 |
| 2-Pyrrolidinone + water | 10.1021/je0340809 (GLOBlit_8242) | PROPblock_14 | 0.01302 (2-pyr) | 0.00089 (water) | 5 | 0.999655 | 0.006026 | 18 |
| DMF + water | 10.1021/je050209y (GLOBlit_8676) | PROPblock_9 | 0.000802 (DMF) | 0.00089 (water) | 5 | 0.999956 | 0.002283 | 11 |

**RK Coefficients (Arrhenius excess ln η):**

- **NMP + water** (x = mole fraction of NMP): A₀ = 4.50293, A₁ = −5.4127, A₂ = 3.89525, A₃ = −1.40557, A₄ = −0.290106
- **2-Pyrrolidinone + water** (x = mole fraction of water): A₀ = 4.37842, A₁ = 3.25083, A₂ = 0.651499, A₃ = −0.067370, A₄ = 2.85824, A₅ = 2.06757
- **DMF + water** (x = mole fraction of DMF): A₀ = 3.20948, A₁ = −3.93132, A₂ = 1.84991, A₃ = 0.364686, A₄ = −0.180491, A₅ = −0.64387

---

### Best Surrogate: 2-Pyrrolidinone + Water

**2-Pyrrolidinone (γ-butyrolactam) is the most defensible surrogate** for aqueous NMP viscosity, for the following reasons:

#### 1. Closest Structural Similarity
- 2-Pyrrolidinone is the **unmethylated parent compound** of NMP — it is identical except for the absence of the N-methyl group. Both share the same five-membered γ-lactam ring with a carbonyl group.
- DMF is an open-chain (acyclic) amide with a smaller molecular weight (standard molar masses from molecular formulas: C₃H₇NO = 73.09 g/mol for DMF vs. C₅H₉NO = 99.13 g/mol for NMP — these are calculated from atomic weights, not database values), making it structurally more distant.

#### 2. Same Hydrogen-Bonding Motif
- Both 2-pyrrolidinone and NMP interact with water primarily through the carbonyl oxygen as a hydrogen-bond acceptor. However, 2-pyrrolidinone also has an N–H group that acts as a hydrogen-bond **donor**, making its H-bonding network with water even stronger than NMP's.
- This explains why 2-pyrrolidinone's pure viscosity (0.01302 Pa·s, from GLOBlit_8242::PROPblock_14 fit pure values) is much higher than NMP's (0.001656 Pa·s, from GLOBlit_8238::PROPblock_3 block-edge extraction) — the N–H group enables self-association via lactam–lactam hydrogen bonds.

#### 3. Qualitative Behavior Comparison
- **NMP + water** shows a pronounced viscosity **maximum** near x(NMP) ≈ 0.3 (η = 0.005062 Pa·s at x(NMP) = 0.3004, from GLOBlit_8238::PROPblock_3, inspected row BLKpoint_6), characteristic of strong solute–water association.
- **DMF + water** also shows a maximum near x(DMF) ≈ 0.3 (η = 0.002491 Pa·s at x(DMF) = 0.299, from GLOBlit_8676::PROPblock_9, inspected row BLKpoint_4), but the maximum is weaker.
- **2-Pyrrolidinone + water** shows a monotonically decreasing viscosity from the organic-rich to the water-rich end (0.01302 Pa·s at x(water) = 0.0549 → 0.001036 Pa·s at x(water) = 0.9906, from GLOBlit_8242::PROPblock_14, inspected rows BLKpoint_1 and BLKpoint_91). This reflects the very high pure-component viscosity dominating the curve shape. The large positive RK A₀ coefficient (4.378) — comparable to NMP's (4.503) — indicates similarly strong positive deviations from ideal (Arrhenius) mixing, confirming strong solute–water interactions.

#### 4. Quantitative RK Coefficient Comparison
The leading Redlich-Kister coefficient A₀ captures the dominant magnitude of the excess ln(viscosity):

| System | A₀ | Interpretation |
|--------|----|----------------|
| NMP + water | 4.503 | Very strong positive deviation |
| 2-Pyrrolidinone + water | 4.378 | Very strong positive deviation (closest to NMP) |
| DMF + water | 3.209 | Strong but notably smaller deviation |

The A₀ values for NMP and 2-pyrrolidinone differ by only ~3% (derived: (4.503 − 4.378) / 4.503 = 0.028), while DMF's A₀ is ~29% lower (derived: (4.503 − 3.209) / 4.503 = 0.287). This means the **excess viscosity behavior** (the non-ideal part that is hardest to predict) is most similar between NMP and 2-pyrrolidinone.

#### 5. Practical Scaling
To use 2-pyrrolidinone as a surrogate for NMP, one would:
- Use the 2-pyrrolidinone + water RK fit to predict the **shape** of the excess ln(viscosity) curve
- Replace the pure-component endpoint values with NMP's known pure viscosity (0.001656 Pa·s) and water's (0.00089 Pa·s)
- The similar A₀ values (4.378 vs. 4.503) suggest the excess contribution would be well-approximated, with the main adjustment being the different pure-component anchors.

---

### Why Not DMF?

While DMF + water data are available and DMF is also a common aprotic amide solvent, it is a weaker surrogate because:
- DMF is **acyclic** (no ring), giving it different conformational and packing behavior in aqueous solution
- DMF's pure viscosity (0.000802 Pa·s, from GLOBlit_8676::PROPblock_9 fit pure values) is **lower than water's** (0.00089 Pa·s), whereas NMP's (0.001656 Pa·s) is higher — the pure-component ordering is reversed
- The excess interaction strength (A₀ = 3.209) is substantially weaker than NMP's (4.503), indicating less structural similarity in the aqueous mixing behavior

### Why Not DMAc?

N,N-Dimethylacetamide + water has **no dynamic viscosity data** in the ThermoML database, making it unusable as a data-backed surrogate despite being structurally relevant.

---

### Summary

| Criterion | 2-Pyrrolidinone | DMF | DMAc |
|-----------|----------------|-----|------|
| Structural similarity to NMP | ★★★ (parent lactam) | ★★ (acyclic amide) | ★★ (acyclic amide) |
| H-bonding motif match | ★★★ (same C=O acceptor + ring) | ★★ (C=O acceptor, no ring) | ★★ (C=O acceptor, no ring) |
| A₀ match to NMP (4.503) | ★★★ (4.378, Δ ≈ 3%) | ★★ (3.209, Δ ≈ 29%) | No data |
| Data availability at 298.15 K | ★★★ (18 fitted pts) | ★★ (11 pts) | ✗ None |
| Pure η ordering vs. NMP | Same (η_org > η_water) | Reversed (η_org < η_water) | No data |

**Recommendation:** 2-Pyrrolidinone + water (DOI 10.1021/je0340809, GLOBlit_8242, PROPblock_14) is the most defensible surrogate for aqueous NMP viscosity at 298.15 K, based on its near-identical lactam ring structure, matching hydrogen-bonding motif, and closely matched Redlich-Kister excess viscosity coefficients (A₀ = 4.378 vs. 4.503 for NMP, a ~3% difference).



















### Core claims

- Direct viscosity measurements for aqueous NMP at 298.15 K exist in the ThermoML database (e.g., GLOBlit_8238, DOI 10.1021/je034073k, PROPblock_3; GLOBlit_8242, DOI 10.1021/je0340809, PROPblock_17), so a surrogate is not strictly necessary.
- Among candidate aqueous amide surrogates evaluated (2-pyrrolidinone, DMF, DMAc), 2-pyrrolidinone + water (DOI 10.1021/je0340809, GLOBlit_8242, PROPblock_14) is recommended as the most defensible surrogate for aqueous NMP viscosity at 298.15 K.
- 2-Pyrrolidinone is the unmethylated parent compound of NMP, sharing the same five-membered γ-lactam ring and carbonyl-based hydrogen-bond acceptor motif, giving it the closest structural similarity among the candidates.
- Redlich-Kister fits to the Arrhenius mixing rule at 298.15 K yield leading excess-ln(viscosity) coefficients A₀ of 4.503 for NMP + water, 4.378 for 2-pyrrolidinone + water, and 3.209 for DMF + water, indicating that the excess viscosity behavior of 2-pyrrolidinone + water most closely matches that of NMP + water.
- DMF + water is a weaker surrogate because DMF is acyclic, its pure viscosity (0.000802 Pa·s) is lower than water's (0.00089 Pa·s) — reversing the ordering seen for NMP (0.001656 Pa·s) — and its A₀ (3.209) is substantially smaller than NMP's (4.503).
- N,N-Dimethylacetamide + water has no dynamic viscosity data in the ThermoML database, making it unusable as a data-backed surrogate.
- Several quoted data-point values carry misattribution flags between blocks, so specific numerical attributions to particular database rows should be treated with caution.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8238 | 10.1021/je034073k | PROPblock_3 |  | Provides direct NMP + water viscosity data at 298.15 K (range 0.000405–0.005062 Pa·s over full mole fraction range). Used as the primary target system for the Redlich-Kister fit (A₀ = 4.503, R² = 0.999957) and as the benchmark against which surrogates are compared. The answer quotes η = 0.005062 Pa·s at x(NMP) ≈ 0.3, which matches the card's max viscosity. |
| GLOBlit_8242 | 10.1021/je0340809 | PROPblock_17 |  | Provides a second independent NMP + water viscosity dataset at 298.15 K (95 datapoints, mole fraction 0.0522–0.99), confirming direct data availability and serving as cross-validation for the target system. |
| GLOBlit_8242 | 10.1021/je0340809 | PROPblock_14 |  | Provides 2-pyrrolidinone + water viscosity data at 298.15 K (95 datapoints, mole fraction 0.0549–0.9906, viscosity 0.000473–0.01302 Pa·s), which is the recommended surrogate system. The RK fit to this block yields A₀ = 4.378, closely matching NMP's A₀ = 4.503 (~3% difference). |
| GLOBlit_9372 | 10.1021/je100967k | PROPblock_17 |  | Provides a third NMP + water viscosity dataset covering 293.15–323.15 K (44 datapoints), confirming additional direct data availability near 298.15 K. Referenced in the answer as covering nearby temperatures including 293.15 K. |
| GLOBlit_8676 | 10.1021/je050209y | PROPblock_9 |  | Provides DMF + water viscosity data at exactly 298.15 K (11 datapoints, viscosity 0.000843–0.002491 Pa·s). Used as the alternative surrogate candidate; its RK fit (A₀ = 3.209) is shown to be a weaker match to NMP than 2-pyrrolidinone, supporting the surrogate selection conclusion. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_8238 | PROPblock_3 | NMP+water | 4 | 4.502926802793371; -5.412701974237864; 3.8952453391941297; -1.4055704087109002; -0.2901057249691559 | 0.999957 | 0.002865770833971775 | 11 | 298.15 | arrhenius |  | 10.1021/je034073k |
| GLOBlit_8242 | PROPblock_14 | 2-pyrrolidinone+water | 5 | 4.378424640036249; 3.250833502753038; 0.6514993900266357; -0.06736991819500959; 2.8582430001010337; 2.067567719414414 | 0.999655 | 0.0060262366694878895 | 18 | 298.15 | arrhenius |  | 10.1021/je0340809 |
| GLOBlit_8676 | PROPblock_9 | DMF+water | 5 | 3.2094757824881035; -3.9313179468689987; 1.849910403918697; 0.3646862036230857; -0.18049115923866288; -0.643870201662175 | 0.999956 | 0.0022827571884589492 | 11 | 298.15 | arrhenius |  | 10.1021/je050209y |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
