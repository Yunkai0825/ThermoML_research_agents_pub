# Analysis Run — [run id removed] (Round 1)

**Question:** At 25 °C, does the speed of sound in liquid ethanol + water deviate positively or negatively from ideal mixing, where is the deviation largest, and what molecular behavior explains its sign?

**[run statistics removed]**

---

## Answer

## Speed of Sound Deviation from Ideal Mixing in Ethanol + Water at 298.15 K

### Short answer

The speed of sound in liquid ethanol + water deviates **strongly positively** from ideal (linear mole-fraction) mixing at 298.15 K. The deviation is largest in the water-rich region, peaking near **x(ethanol) ≈ 0.10** with a maximum excess of about **+151 m/s**. This positive deviation arises from enhanced hydrogen-bond networking between ethanol and water molecules in the water-rich regime, which stiffens the liquid structure and raises its adiabatic bulk modulus relative to what a simple linear blend of the two pure liquids would give.

---

### Data source

**PROPblock_20** from GLOBlit_5201 (DOI: 10.1016/j.jct.2018.02.022)

- **System:** ethanol (C₂H₅OH) + water, binary liquid
- **Temperature:** 298.15 K isotherm selected from a 293–308 K dataset
- **Pressure:** 92.3 kPa
- **Data points used:** 33 mixture compositions + 2 pure endpoints (from 152 total across four temperatures)
- **Composition range:** x(ethanol) = 0 to 1 (full binary)

### Pure-component endpoints (block edges at 298.15 K)

| Component | Speed of sound (m/s) |
|-----------|---------------------|
| Water     | 1499.22             |
| Ethanol   | 1147.54             |

### Representative measured values at 298.15 K

These values are from the inspected data table of PROPblock_20 (L1#1_Table#5):

| x(ethanol) | u measured (m/s) |
|:----------:|:----------------:|
| 0          | 1496.99          |
| 0.0997     | 1618.97          |
| 0.1497     | 1600.11          |
| 0.3507     | 1426.17          |
| 0.5002     | 1337.91          |
| 1          | 1143.50          |

For comparison, the tool-returned ideal (linear) baseline at x = 0.5 is 1323.38 m/s, while the measured value at x = 0.5002 is 1337.91 m/s — confirming the positive deviation. The measured speed of sound exceeds the linear interpolation across the entire interior of the composition range, with the strongest enhancement in the water-rich region where the measured value of 1618.97 m/s at x = 0.0997 far exceeds the pure-water endpoint of 1499.22 m/s.

### Redlich-Kister fit

A 4th-order Redlich-Kister polynomial was selected by BIC minimisation:

$$u^{E}(x_1) = x_1(1-x_1)\sum_{k=0}^{4} A_k (2x_1 - 1)^k$$

where x₁ = mole fraction of ethanol.

| Parameter | Value |
|-----------|-------|
| A₀        | 47.720  |
| A₁        | −241.965 |
| A₂        | 744.598  |
| A₃        | −1251.739 |
| A₄        | 643.919  |
| R²        | 0.9928   |
| RMSE      | 5.01 m/s |
| BIC       | 123.88   |

From the RK prediction curve (101 grid points, tool-returned):

- **Maximum predicted speed of sound:** 1610.08 m/s at x(ethanol) ≈ 0.10
- **Maximum excess (deviation from linear baseline):** **+150.97 m/s** at x(ethanol) ≈ 0.10

### Sign and location of the deviation

| Feature | Value |
|---------|-------|
| Sign of deviation | **Positive** (measured > ideal over the entire binary interior) |
| Location of maximum deviation | x(ethanol) ≈ 0.10 (water-rich side) |
| Magnitude of maximum deviation | +150.97 m/s |

The deviation is strongly asymmetric: it is much larger on the water-rich side and nearly vanishes by x(ethanol) ≈ 0.5.

### Molecular explanation

The large **positive** deviation of speed of sound from ideal mixing in the water-rich region reflects the molecular-level restructuring that occurs when small amounts of ethanol are dissolved in water:

1. **Enhanced hydrogen-bond network.** At low ethanol concentrations, each ethanol molecule is fully solvated by water. The hydrophobic ethyl group promotes "hydrophobic hydration" — water molecules around the –CH₂CH₃ group form a more ordered, cage-like (clathrate-like) hydrogen-bond structure. This cooperative ordering stiffens the local liquid structure.

2. **Increased adiabatic bulk modulus.** Speed of sound is u = √(Kₛ/ρ), where Kₛ is the adiabatic bulk modulus and ρ is density. The enhanced H-bond ordering raises Kₛ more than the modest density change would lower u, producing a net increase in speed of sound above the linear interpolation.

3. **Asymmetry toward the water-rich side.** The clathrate-like hydration shells are most effective when water is the majority component and can fully surround each ethanol molecule. As ethanol concentration rises, the water network is progressively disrupted, the cooperative ordering is lost, and the deviation diminishes. By x(ethanol) ≈ 0.5 the mixture is essentially a disordered ethanol–water solution and the deviation is small.

4. **Contrast with volume and enthalpy.** The same hydrophobic hydration that stiffens the structure also produces the well-known negative excess volume (contraction on mixing) and negative excess enthalpy (exothermic mixing) in the water-rich region — all three excess properties are manifestations of the same cooperative hydrogen-bond enhancement around ethanol's alkyl group.

### Output files

- **Fit data CSV:** `10_1016_j_jct_2018_02_022_BPROPblock_20_T298.1_fit.csv`
- **Excess property CSV:** `10_1016_j_jct_2018_02_022_BPROPblock_20_T298.1_excess.csv`
- **Fit plot:** `10_1016_j_jct_2018_02_022_BPROPblock_20_T298.1_fit.png`
- **Excess plot:** `10_1016_j_jct_2018_02_022_BPROPblock_20_T298.1_excess.png`

### Core claims

- At 298.15 K and 92.3 kPa, the speed of sound in liquid ethanol + water deviates strongly positively from ideal (linear mole-fraction) mixing across the entire binary interior.
- The maximum excess speed of sound is +150.97 m/s, occurring near x(ethanol) ≈ 0.10 in the water-rich region, where the measured speed of sound (1618.97 m/s at x = 0.0997) far exceeds the pure-water endpoint of 1499.22 m/s.
- The deviation is strongly asymmetric, being largest on the water-rich side and nearly vanishing by x(ethanol) ≈ 0.5.
- A 4th-order Redlich-Kister polynomial, selected by BIC minimisation, fits the excess speed of sound with R² = 0.9928 and RMSE = 5.01 m/s.
- The positive deviation is attributed to hydrophobic hydration: at low ethanol concentrations, water forms ordered, clathrate-like hydrogen-bond structures around ethanol's alkyl group, raising the adiabatic bulk modulus and thus the speed of sound above the linear baseline.
- Pure-component speed-of-sound endpoints at 298.15 K are 1499.22 m/s for water and 1147.54 m/s for ethanol.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_20 |  | This block provides 152 speed-of-sound data points for the ethanol + water binary across the full mole-fraction range at temperatures including 298.15 K. It supplies the pure-component endpoints and mixture values used to compute the excess speed of sound, fit the Redlich-Kister polynomial, and establish the +151 m/s positive maximum deviation near x(ethanol) ≈ 0.10. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5201 | PROPblock_20 | GLOBprop_8 | 4 | 47.72007767043886; -241.96499846357335; 744.5982833791072; -1251.7389750015948; 643.919105041898 | 0.992788 | 5.0129896042325095 | 33 | 298.15 | linear |  | 10.1016/j.jct.2018.02.022 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
