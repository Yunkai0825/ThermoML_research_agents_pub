# Analysis Run — [run id removed] (Round 1)

**Question:** In an equimolar ethylene glycol + water + methanol liquid mixture near 25 °C, which binary interaction should contribute most strongly to the viscosity nonideality, and why?

**[run statistics removed]**

---

## Answer

## Which Binary Interaction Dominates Viscosity Nonideality in an Equimolar Ethylene Glycol + Water + Methanol Mixture at ~25 °C?

### Short Answer

The **water + methanol** binary interaction contributes most strongly to the viscosity nonideality, closely followed by **ethylene glycol + water**. The **ethylene glycol + methanol** pair contributes much less. In the equimolar ternary, the water–methanol pair accounts for the largest share of the total Arrhenius-excess ln(η), the EG–water pair is a close second, and the EG–methanol pair is much smaller.

---

### Approach: Binary Redlich-Kister Fits with Arrhenius Mixing Rule

For viscosity, the natural mixing rule is the **Arrhenius (logarithmic)** model:

ln(η_mix) = Σ xᵢ ln(ηᵢ*) + x₁x₂ Σₖ Aₖ(x₁ − x₂)ᵏ

The Redlich-Kister (RK) coefficients {A₀, A₁, …} quantify the **excess** ln(η) beyond the geometric-mean baseline. In an equimolar ternary (x₁ = x₂ = x₃ = ⅓), the Muggianu symmetric decomposition gives each binary pair a weight of xᵢ·xⱼ = 1/9, and since xᵢ = xⱼ at equimolar projection, only A₀ survives for each pair. Thus the dominant pair is the one with the **largest A₀**.

### Data Sources and RK Fits at 298.15 K

| Binary Pair | DOI | Block | lit_num_id | n (mixture pts) | RK Order | R² | RMSE | A₀ | A₁ | A₂ | A₃ |
|---|---|---|---|---|---|---|---|---|---|---|---|
| EG + water | 10.1016/j.jct.2018.02.022 | PROPblock_24 | GLOBlit_5201 | 19 | 3 | 0.99994 | 0.001320 | 2.39674 | −1.04444 | 0.668173 | −0.3209 |
| Water + methanol | 10.1016/j.jct.2007.05.004 | PROPblock_9 | GLOBlit_2825 | 11 | 3 | 0.99990 | 0.002050 | 2.53477 | 1.42214 | 1.33593 | 0.754488 |
| EG + methanol | 10.1016/j.fluid.2009.03.002 | PROPblock_1 | GLOBlit_692 | 3 | 0 | −4.95 | 0.03559 | 0.71473 | — | — | — |

**Pure-component viscosities at 298.15 K** (from block edges):

| Component | η* (Pa·s) | Source |
|---|---|---|
| 1,2-ethanediol (EG) | 0.016223 | PROPblock_24 edge |
| Water | 0.00089689 (EG+water block) / 0.00089 (water+MeOH block) | PROPblock_24 / PROPblock_9 edges |
| Methanol | 0.000545 | PROPblock_9 edge |

### Ranking the Binary Pairs by A₀

At equimolar binary composition (x₁ = x₂ = 0.5), only A₀ contributes to the Arrhenius excess: Δln(η) = 0.25 × A₀. The A₀ values from the RK fits directly rank the pairs:

| Binary Pair | A₀ (from RK fit) |
|---|---|
| Water + methanol | 2.53477 (largest) |
| EG + water | 2.39674 |
| EG + methanol | 0.71473 (smallest; poor fit — see caveat) |

Since A₀ is the sole contributor at equimolar composition, the **water + methanol** pair has the largest viscosity nonideality, followed closely by **EG + water**, with **EG + methanol** far behind.

### Ternary Decomposition (Equimolar, x_EG = x_water = x_MeOH = ⅓)

Using the Muggianu symmetric formalism, each binary pair contributes (1/9) × A₀ to the total Δln(η). Since the three A₀ values are 2.53477, 2.39674, and 0.71473 (all from the RK fits above), the pair with the largest A₀ — water + methanol — contributes the most, and the pair with the smallest A₀ — EG + methanol — contributes the least. The EG + water pair falls in between, close to water + methanol.

### Why Water + Methanol Dominates

1. **Largest A₀ coefficient (2.53477):** The water–methanol system exhibits a well-known viscosity maximum near x(water) ≈ 0.70, where η reaches 0.001554 Pa·s (inspected from PROPblock_9 at 298.15 K) — substantially higher than the Arrhenius baseline interpolation between pure water (0.00089 Pa·s) and pure methanol (0.000545 Pa·s). This reflects the formation of strong, stoichiometric-like hydrogen-bonded clusters that dramatically increase flow resistance beyond what the pure-component viscosities would predict.

2. **Comparable pure-component viscosities amplify the excess:** Because η*(water) and η*(methanol) differ by only a factor of ~1.6 (both values from inspected block edges of PROPblock_9), the Arrhenius baseline is relatively flat, making the positive deviation (the "hump") stand out as a large fractional excess. In contrast, for EG + water the pure viscosities differ much more (0.016223 vs 0.00089689, both from inspected PROPblock_24 edges), so much of the apparent nonlinearity is already captured by the logarithmic baseline.

3. **EG + methanol is weakly nonideal:** Despite EG being a strong hydrogen-bond donor/acceptor, its interaction with methanol produces a much smaller excess (A₀ = 0.71473 vs 2.4–2.5 for the other pairs). Methanol's single hydroxyl group can satisfy EG's hydrogen-bonding capacity less cooperatively than water's tetrahedral network.

### Important Caveat

The **EG + methanol** fit is based on only 3 mixture points at 298.15 K (the block covers mass fractions 0.0–0.75 of EG and does not extend to pure EG), yielding a poor fit (R² = −4.95). The pure EG viscosity (0.016223 Pa·s) was taken from the EG + water block (PROPblock_24). While the qualitative conclusion — that EG + methanol is the weakest interaction — is robust (the raw data show much less curvature in ln(η) vs composition), the precise A₀ = 0.71473 should be treated as approximate.

### Conclusion

In an equimolar ethylene glycol + water + methanol liquid mixture near 298.15 K, the **water–methanol binary interaction** contributes most strongly to viscosity nonideality (largest A₀ = 2.53477), narrowly exceeding the ethylene glycol–water interaction (A₀ = 2.39674). Both pairs exhibit large positive deviations from Arrhenius ideality driven by cooperative hydrogen-bonding networks, while the ethylene glycol–methanol pair is much weaker (A₀ = 0.71473). The dominance of the water–methanol pair reflects the pronounced viscosity maximum in that binary system, arising from the formation of strongly hydrogen-bonded water–methanol clusters that resist shear flow far more than either pure component alone.

### Core claims

- In an equimolar ethylene glycol + water + methanol liquid mixture near 298.15 K, the water–methanol binary interaction contributes most strongly to viscosity nonideality, as indicated by the largest Redlich-Kister A₀ coefficient of 2.53477, narrowly exceeding the ethylene glycol–water interaction (A₀ = 2.39674).
- The ethylene glycol–methanol pair contributes much less to viscosity nonideality (A₀ = 0.71473) compared to the other two binary pairs.
- At equimolar ternary composition (x = ⅓ each), the Muggianu symmetric decomposition weights each binary pair equally (xᵢ·xⱼ = 1/9), and only A₀ survives because xᵢ = xⱼ at equimolar projection, so the ranking is determined directly by A₀ magnitude.
- The dominance of the water–methanol pair is attributed to the pronounced viscosity maximum in that binary system near x(water) ≈ 0.70, reflecting cooperative hydrogen-bonded cluster formation that increases flow resistance well beyond the Arrhenius baseline.
- The ethylene glycol + methanol fit is based on only 3 mixture data points at 298.15 K with a poor fit (R² = −4.95), so the precise A₀ value of 0.71473 for that pair should be treated as approximate, though the qualitative conclusion of weak nonideality is considered robust.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | Provides binary viscosity data for 1,2-ethanediol + water at 298.15 K across the full mole-fraction range (0.0–1.0), yielding the Redlich-Kister A₀ = 2.39674 used to quantify the EG–water contribution to ternary viscosity nonideality. Also supplies the pure EG viscosity (0.016223 Pa·s) used in the analysis. |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9 |  | Provides binary viscosity data for methanol + water at 298.15 K across the full mole-fraction range, yielding the largest Redlich-Kister A₀ = 2.53477 that identifies the water–methanol pair as the dominant contributor to viscosity nonideality in the equimolar ternary mixture. |
| GLOBlit_692 | 10.1016/j.fluid.2009.03.002 | PROPblock_1 |  | Provides binary viscosity data for methanol + 1,2-ethanediol at 298.15 K (mass fraction 0.0–0.75), yielding A₀ = 0.71473 that confirms the EG–methanol pair is the weakest contributor to viscosity nonideality. The answer acknowledges the limited data (3 mixture points at 298.15 K) and poor fit quality as a caveat. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5201 | PROPblock_24 | EG_water | 3 | 2.3967401058713325; -1.0444436005853195; 0.6681733607879681; -0.3209004397507546 | 0.99994 | 0.0013198945265291695 | 19 | 298.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_2825 | PROPblock_9 | water_methanol | 3 | 2.5347737948671387; 1.4221357976838167; 1.3359303803324303; 0.7544881739992259 | 0.999903 | 0.0020496812938951637 | 11 | 298.15 | arrhenius |  | 10.1016/j.jct.2007.05.004 |
| GLOBlit_692 | PROPblock_1 | GLOBprop_4 | 0 | 0.7147271672751264 | -4.94932 | 0.03559043525961839 | 3 | 298.15 | arrhenius |  | 10.1016/j.fluid.2009.03.002 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
