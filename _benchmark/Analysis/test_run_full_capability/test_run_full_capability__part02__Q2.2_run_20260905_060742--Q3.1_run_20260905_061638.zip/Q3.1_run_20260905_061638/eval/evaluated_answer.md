# Analysis Run — [run id removed] (Round 1)

**Question:** At 25 °C, which liquid mixture—ethanol + water or methanol + water—shows the larger viscosity departure from ideal mixing, at what composition is it greatest, and what intermolecular interactions explain the difference?

**[run statistics removed]**

---

## Answer

## Viscosity Departure from Ideal Mixing: Ethanol + Water vs. Methanol + Water at 25 °C

### Summary

**Ethanol + water shows the larger viscosity departure from ideal (Arrhenius) mixing** — roughly 33% greater than methanol + water in the logarithmic excess. The maximum departure occurs at a mole fraction of ethanol ≈ 0.24 (i.e., x_water ≈ 0.76), deep in the water-rich region.

---

### Data Sources and Fitting

Both systems were fitted with Redlich-Kister (RK) polynomials using the Arrhenius mixing rule for viscosity, ln η_ideal = x₁ ln η₁ + x₂ ln η₂, with the excess represented as Δ ln η = Σ Aₖ (x₁ − x₂)^k.

| System | DOI | Block | Lit ID | T (K) | Data pts | RK order | R² | RMSE |
|--------|-----|-------|--------|--------|----------|----------|----|------|
| Ethanol + Water | 10.1016/j.jct.2018.02.022 | PROPblock_21 | GLOBlit_5201 | 298.15 | 23 | 4 | 0.999334 | 0.006613 |
| Methanol + Water | 10.1016/j.jct.2007.05.004 | PROPblock_9 | GLOBlit_2825 | 298.15 | 11 | 3 | 0.999903 | 0.002050 |

### Pure-Component Viscosities (block-edge values at 298.15 K)

| Component | η (Pa·s) | Source |
|-----------|----------|--------|
| Water | 0.00089689 (EtOH+W block) / 0.00089 (MeOH+W block) | Block edges |
| Ethanol | 0.0010914 | Block edge |
| Methanol | 0.000545 | Block edge |

### Redlich-Kister Coefficients (Arrhenius / ln-space)

**Ethanol + Water** (x₁ = mole fraction of ethanol):
A₀ = 2.728, A₁ = −2.493, A₂ = 2.550, A₃ = −2.448, A₄ = 1.536

**Methanol + Water** (x₁ = mole fraction of water):
A₀ = 2.535, A₁ = 1.422, A₂ = 1.336, A₃ = 0.754

### Maximum Viscosity Departure

| System | Max \|Δ ln η\| | Composition at max | η_max (Pa·s) |
|--------|----------------|--------------------|--------------|
| **Ethanol + Water** | **0.9446** | x(ethanol) = 0.24 | 0.002414 |
| Methanol + Water | 0.7083 | x(water) = 0.58 | 0.001324 |

The ethanol–water system's peak excess viscosity (Δ ln η = 0.945) is about **33% larger** than that of methanol–water (Δ ln η = 0.708). In absolute terms, the ethanol–water mixture reaches 0.00241 Pa·s — roughly 2.7× the viscosity of pure ethanol and 2.7× that of pure water — whereas methanol–water peaks at only 0.00132 Pa·s (about 2.4× pure methanol, 1.5× pure water).

### Intermolecular Interactions Explaining the Difference

Both alcohol–water mixtures exhibit **positive viscosity deviations** (η_mix > η_ideal), signaling that the mixture's intermolecular cohesion exceeds what a simple composition-weighted average of the pure liquids would predict. The key factors are:

1. **Hydrophobic hydration (clathrate-like water cages).** When an alcohol molecule is surrounded by water, the water molecules reorganize into ordered, cage-like structures around the hydrophobic alkyl group. Ethanol's **ethyl group (−CH₂CH₃)** is larger than methanol's **methyl group (−CH₃)**, so it induces a more extensive hydration shell. These structured water cages increase the effective hydrodynamic volume of the solute and resist shear flow, raising viscosity more strongly.

2. **Hydrogen-bonding network disruption and bridging.** Both alcohols can donate and accept hydrogen bonds with water, but the larger ethanol molecule disrupts the native water H-bond network over a wider spatial range. The resulting reorganization creates extended, cooperative H-bonded clusters (alcohol–water complexes) that are more viscous than either pure component. The asymmetry of the ethanol–water RK expansion (large odd-order coefficients A₁ = −2.49, A₃ = −2.45) reflects the strong skew of the viscosity maximum toward the water-rich side (x_ethanol ≈ 0.24), where hydrophobic hydration dominates.

3. **Composition of the maximum.** For ethanol–water, the maximum at x(ethanol) ≈ 0.24 corresponds roughly to a 1 : 3 ethanol : water molar ratio, consistent with the stoichiometry of clathrate-like hydration shells (each ethanol molecule coordinated by ~3 water molecules in the first shell). For methanol–water, the maximum departure is at x(water) = 0.58 (from the predict_from_rk tool result), reflecting the smaller hydration requirement of the methyl group compared to the ethyl group.

4. **Microheterogeneity.** Neutron-scattering and molecular-dynamics studies of alcohol–water mixtures show nanoscale segregation into alcohol-rich and water-rich domains. Ethanol–water exhibits more pronounced microheterogeneity than methanol–water because of the stronger amphiphilic character of ethanol, and the interfaces between these domains contribute additional resistance to flow.

In short, the larger hydrophobic moiety of ethanol amplifies every mechanism — hydrophobic hydration, H-bond network restructuring, and nanoscale segregation — that drives viscosity above the ideal-mixing baseline, making the ethanol–water departure roughly one-third greater than that of methanol–water at 298.15 K.

### Core claims

- At 298.15 K, ethanol + water shows a larger viscosity departure from ideal (Arrhenius) mixing than methanol + water, with a peak logarithmic excess Δ ln η of 0.9446 for ethanol + water versus 0.7083 for methanol + water — roughly 33% greater.
- The maximum viscosity departure for ethanol + water occurs at x(ethanol) ≈ 0.24 (water-rich region), where the mixture viscosity reaches 0.002414 Pa·s, while for methanol + water the maximum occurs at x(water) = 0.58, reaching 0.001324 Pa·s.
- Both systems exhibit positive viscosity deviations (η_mix > η_ideal), attributed to hydrophobic hydration (clathrate-like water cages around alkyl groups), hydrogen-bond network restructuring, and nanoscale segregation, all of which are amplified by ethanol's larger ethyl group compared to methanol's methyl group.
- The ethanol + water data were fitted with a 4th-order Redlich-Kister polynomial (R² = 0.999334, RMSE = 0.006613, 23 data points from DOI 10.1016/j.jct.2018.02.022), and the methanol + water data with a 3rd-order polynomial (R² = 0.999903, RMSE = 0.002050, 11 data points from DOI 10.1016/j.jct.2007.05.004).
- The strong asymmetry of the ethanol + water Redlich-Kister expansion (large odd-order coefficients A₁ = −2.493, A₃ = −2.448) reflects the skew of the viscosity maximum toward the water-rich side, consistent with hydrophobic hydration dominating at compositions near a 1:3 ethanol:water molar ratio.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21 |  | Provides binary ethanol + water viscosity data across the full mole-fraction range at temperatures spanning 298.15 K, used to fit the Redlich-Kister expansion and determine the maximum Arrhenius excess ln η of 0.9446 at x(ethanol) ≈ 0.24. |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9 |  | Provides binary methanol + water viscosity data across the full mole-fraction range at temperatures spanning 298.15 K, used to fit the Redlich-Kister expansion and determine the maximum Arrhenius excess ln η of 0.7083, enabling the quantitative comparison with the ethanol + water system. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5201 | PROPblock_21 | ethanol_water_viscosity_298K | 4 | 2.7279958938647066; -2.4925941810857495; 2.5500472215385774; -2.4477499128574456; 1.53644421556371 | 0.999334 | 0.006612838327445672 | 23 | 298.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_2825 | PROPblock_9 | methanol_water_viscosity_298K | 3 | 2.5347737948671387; 1.4221357976838167; 1.3359303803324303; 0.7544881739992259 | 0.999903 | 0.0020496812938951637 | 11 | 298.15 | arrhenius |  | 10.1016/j.jct.2007.05.004 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
