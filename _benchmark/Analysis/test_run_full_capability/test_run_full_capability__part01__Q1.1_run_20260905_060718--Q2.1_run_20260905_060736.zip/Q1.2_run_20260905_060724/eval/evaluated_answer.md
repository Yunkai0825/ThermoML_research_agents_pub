# Analysis Run — [run id removed] (Round 1)

**Question:** At 25 °C, what Redlich–Kister correlation best represents the density of liquid methanol + water? Select the polynomial order by BIC and report the equation, coefficients and units, R², RMSE, BIC, and composition range.

**[run statistics removed]**

---

## Answer

## Redlich–Kister Correlation for the Density of Liquid Methanol + Water at 298.15 K

### Data Source

The fit uses experimental mass density data from:

- **DOI:** 10.1016/j.jct.2007.05.004 (GLOBlit_2825 / PROPblock_10)
- **System:** methanol (GLOBcomp_4) + water (GLOBcomp_1), binary liquid
- **Temperature:** 298.15 K (constrained isotherm)
- **Pressure:** 101.0 kPa
- **Composition range:** x(water) = 0 to 1 (full mole-fraction range)
- **Data points used:** 11 mixture points plus pure endpoints at the 298.15 K isotherm (fit_block reported "Points: 11 mixture / 39 total" after constraining temperature)
- **Property response:** Direct value (absolute density, kg/m³)
- **Data priority:** DP1 — directly measured total mixture property

### Pure-Component Endpoints (from block edges at 298.15 K)

| Component | ρ* (kg/m³) |
|-----------|-----------|
| Water     | 997.05    |
| Methanol  | 787.2     |

### Redlich–Kister Equation

The density is represented with a **linear mixing rule** baseline plus a Redlich–Kister excess correction:

$$\rho(x_1) = x_1\,\rho_1^* + x_2\,\rho_2^* + x_1\,x_2\,\sum_{k=0}^{n} A_k\,(x_1 - x_2)^k$$

where:
- x₁ = mole fraction of **water** (component 1)
- x₂ = 1 − x₁ = mole fraction of **methanol** (component 2)
- ρ₁* = 997.05 kg/m³ (pure water)
- ρ₂* = 787.2 kg/m³ (pure methanol)

### BIC-Selected Polynomial Order and Coefficients

The **Bayesian Information Criterion (BIC)** selects **order 5** (6 coefficients) as optimal:

| k | Aₖ (kg/m³) |
|---|------------|
| 0 | −42.3108   |
| 1 |   2.46129  |
| 2 |   7.28093  |
| 3 |  −0.41971  |
| 4 | −46.1538   |
| 5 | −43.8431   |

### Fit Statistics

| Statistic | Value |
|-----------|-------|
| **R²**    | 0.999796 |
| **RMSE**  | 0.0388524 kg/m³ |
| **BIC**   | −57.07 |

### BIC Model Comparison (orders 0–5)

| Order | BIC    | R²       | RMSE (kg/m³) |
|-------|--------|----------|--------------|
| 0     |  2.56  | 0.862798 | 1.00745      |
| 1     |  3.22  | 0.882879 | 0.930813     |
| 2     | −1.47  | 0.938515 | 0.674419     |
| 3     | −12.24 | 0.981419 | 0.370747     |
| 4     | −29.48 | 0.996883 | 0.151854     |
| 5     | −57.07 | 0.999796 | 0.0388524    |

The BIC decreases monotonically from order 0 to order 5, with order 5 giving the lowest (most favorable) BIC of −57.07. The dramatic improvement from order 4 (BIC = −29.48) to order 5 (BIC = −57.07) indicates that the sixth coefficient captures significant remaining curvature in the density–composition relationship.

### Chemistry Insight

The methanol–water system is well known for strong, composition-dependent hydrogen-bonding interactions that produce pronounced non-ideal mixing. The negative leading coefficient A₀ = −42.3108 kg/m³ reflects the overall **volume contraction** (excess density) upon mixing — water's open tetrahedral network partially collapses as methanol molecules insert into it. The need for a 5th-order polynomial (rather than a simple symmetric parabola) reflects the **asymmetry** of this interaction: the density deviation from linearity is not symmetric about x = 0.5, peaking closer to the water-rich side where the disruption of water structure is most pronounced. Representative measured data at 298.15 K include ρ = 840.79 kg/m³ at x(water) = 0.2983 and ρ = 881.69 kg/m³ at x(water) = 0.5003, both lying above the linear interpolation between the pure endpoints, consistent with the well-documented negative excess molar volume of this system.

### Output Files

- **Fit data CSV:** `10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv`
- **Excess property CSV:** `10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv`
- **Fit plot:** `10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png`
- **Excess plot:** `10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png`

### Core claims

- A Redlich–Kister correlation for the liquid density of methanol + water at 298.15 K and 101.0 kPa was fitted using 11 mixture data points spanning x(water) = 0 to 1, with pure-component endpoints of 997.05 kg/m³ (water) and 787.2 kg/m³ (methanol).
- The Bayesian Information Criterion selects a 5th-order Redlich–Kister polynomial (6 coefficients) as optimal, with BIC = −57.07, R² = 0.999796, and RMSE = 0.0388524 kg/m³.
- The leading excess coefficient A₀ = −42.3108 kg/m³ is negative, reflecting overall volume contraction (excess density) upon mixing, consistent with the well-documented negative excess molar volume of the methanol–water system.
- The need for a 5th-order polynomial rather than a lower-order fit reflects pronounced asymmetry in the density–composition relationship, attributed to composition-dependent hydrogen-bonding interactions between methanol and water.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 |  | This block provides 39 mass density data points for the binary methanol + water system across 293.15–303.15 K and the full mole-fraction range at 101.0 kPa. The answer filters to the 298.15 K isotherm (11 mixture points plus endpoints) and fits a Redlich–Kister polynomial of order 5 to the density, yielding R² = 0.999796 and RMSE = 0.0389 kg/m³. The block's density range (782.48–998.2 kg/m³) is consistent with the pure-component endpoints used (787.2 and 997.05 kg/m³). |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_2825 | PROPblock_10 | GLOBprop_1 | 5 | -42.310757722792545; 2.461285361216577; 7.280933000115691; -0.4197102000547031; -46.153810492202304; -43.843096353659426 | 0.999796 | 0.03885240667464569 | 11 | 298.15 | linear |  | 10.1016/j.jct.2007.05.004 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
