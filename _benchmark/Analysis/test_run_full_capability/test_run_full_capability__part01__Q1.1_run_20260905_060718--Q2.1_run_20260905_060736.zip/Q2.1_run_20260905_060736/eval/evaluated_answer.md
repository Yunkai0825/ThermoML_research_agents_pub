# Analysis Run — [run id removed] (Round 1)

**Question:** I am preparing an equimolar DMF + water + acetonitrile liquid mixture at 25 °C. What viscosity should I expect? State whether the value is directly measured or estimated, and explain how the three binary interactions support the result.

**[run statistics removed]**

---

## Answer

## Estimated Viscosity of Equimolar DMF + Water + Acetonitrile at 25 °C

### Result

**Estimated viscosity: η ≈ 0.95 mPa·s (0.00095 Pa·s) at 298.15 K**

**This value is an ESTIMATE, not a direct measurement.** No ternary viscosity data for the DMF + water + acetonitrile system exists in the ThermoML database. The estimate was constructed by fitting Redlich-Kister (RK) polynomials (Arrhenius mixing rule) to measured binary viscosity data for all three constituent pairs, then combining them via the Muggianu symmetric ternary extension model.

---

### Method: Binary Decomposition → Muggianu Ternary Extension

Since no ternary data exist, the viscosity at the equimolar point (x_DMF = x_water = x_ACN = 1/3) was estimated by:

1. **Fitting** each binary pair's measured viscosity with RK polynomials in ln-space (Arrhenius mixing rule: ln η = x₁ ln η₁ + x₂ ln η₂ + x₁x₂ Σ Aₖ(x₁−x₂)ᵏ).
2. **Evaluating** each binary fit at the Muggianu-dilated composition (ξ = 0.5 for equimolar ternary).
3. **Combining** via the Muggianu formula:

   ln η_ternary = Σᵢ xᵢ ln ηᵢ + Σᵢ<ⱼ 4xᵢxⱼ · [excess_ij at ξ = 0.5]

---

### Three Binary Fits at 298.15 K

#### 1. DMF + Water — the dominant interaction

| Parameter | Value |
|-----------|-------|
| **Source** | DOI 10.1021/je050209y (GLOBlit_8676, PROPblock_9) |
| **Data points** | 11 (x_DMF = 0.05–0.9488) |
| **Pure values** | η_DMF = 0.00081 Pa·s; η_water = 0.0008901 Pa·s |
| **RK order (BIC)** | 5 |
| **RK coefficients** | [3.1881, −3.9583, 1.8651, 0.4219, −0.3040, −0.8155] |
| **R²** | 0.999949 |
| **RMSE** | 0.00247 |
| **η at x = 0.5** | **0.00188 Pa·s** |
| **ln-space excess at x

### Core claims

- The estimated viscosity of equimolar DMF + water + acetonitrile at 298.15 K is approximately 0.95 mPa·s (0.00095 Pa·s).
- This value is an estimate, not a direct measurement, because no ternary viscosity data for the DMF + water + acetonitrile system exist in the ThermoML database.
- The estimate was constructed by fitting Redlich-Kister polynomials (Arrhenius mixing rule) to measured binary viscosity data for all three constituent pairs, then combining them via the Muggianu symmetric ternary extension model.
- The DMF + water binary pair is identified as the dominant interaction, with a fitted viscosity at x = 0.5 of 0.00188 Pa·s at 298.15 K and an R² of 0.999949.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8676 | 10.1021/je050209y | PROPblock_9 |  | Provides 11 binary viscosity data points for DMF + water at 298.15 K (mole fraction 0.05–0.9488, viscosity 0.000843–0.002491 Pa·s), which were used to fit the Redlich-Kister polynomial for the dominant binary pair in the Muggianu ternary extension estimate. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_7481 | PROPblock_18 | DMF_acetonitrile | 4 | 0.5513356359260047; 0.1256065806672244; -0.5226832888477766; -0.309479033230341; 1.451545538546099 | 0.917516 | 0.007151559874569717 | 9 | 298.15 | arrhenius |  | 10.1021/acs.jced.8b00176 |
| GLOBlit_8676 | PROPblock_9 | DMF_water | 5 | 3.18809960434545; -3.958297732071694; 1.8651035997084322; 0.42185221958298424; -0.3040412382811535; -0.8155298539087938 | 0.999949 | 0.002465528073338755 | 11 | 298.15 | arrhenius |  | 10.1021/je050209y |
| GLOBlit_2602 | PROPblock_3 | water_acetonitrile | 5 | 0.044503164673406016; -1.1676159050933623; 0.25588834130719174; 0.25771976309102357; 1.1976207664272482; -1.7699045217468885 | 0.997253 | 0.005202139660061691 | 13 | 298.15 | arrhenius |  | 10.1016/j.jct.2005.08.009 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
