# Analysis Run — [run id removed] (Round 1)

**Question:** At 25 °C, how does the viscosity of liquid ethanol + water depart from ideal mixing across composition? Give me a Redlich–Kister correlation with the fitted equation, coefficients and units, polynomial order, fit quality, and valid composition range.

**[run statistics removed]**

---

## Answer

## Viscosity of Ethanol + Water at 298.15 K: Departure from Ideal Mixing via Redlich–Kister Correlation

### Physical Picture

Ethanol–water mixtures at 298.15 K exhibit a pronounced positive departure from ideal (Arrhenius) viscosity mixing. The viscosity passes through a maximum at intermediate compositions, reaching values roughly 2.5–3× the viscosity of either pure component. This non-ideality arises from enhanced hydrogen-bonding networks: water and ethanol form cooperative H-bond clusters in the intermediate composition region that resist shear flow more effectively than either pure liquid alone.

---

### Mixing Rule and Fitted Equation

For viscosity, the **Arrhenius (logarithmic) mixing rule** is used as the ideal baseline:

$$\ln\eta_{\text{mix}} = x_1 \ln\eta_1^* + x_2 \ln\eta_2^* + x_1\,x_2 \sum_{k=0}^{n} A_k\,(x_1 - x_2)^k$$

where $\eta_i^*$ are the pure-component viscosities, $x_1$ and $x_2$ are mole fractions, and the $A_k$ are the Redlich–Kister coefficients that capture the **departure from ideal Arrhenius mixing**. The RK polynomial $x_1 x_2 \sum A_k (x_1-x_2)^k$ is identically zero at the endpoints and represents the excess contribution $\ln\eta^E$.

---

### Fit 1 — GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004, PROPblock_11)

- **Temperature:** 298.15 K
- **Pressure:** 101.0 kPa
- **Composition variable:** $x_1$ = mole fraction of water; $x_2 = 1 - x_1$ (ethanol)
- **Data points at 298.15 K:** 10
- **Composition range:** $x_1 \in [0, 1]$ (full range)
- **Pure-component viscosities (block edges):**
  - $\eta^*_{\text{water}}$ = 0.00089 Pa·s
  - $\eta^*_{\text{ethanol}}$ = 0.001082 Pa·s

**BIC-selected polynomial order:** 5

**Redlich–Kister coefficients** (dimensionless, applied to ln η; from fit_block tool output):

| k | $A_k$ |
|---|-------|
| 0 | 2.57153 |
| 1 | 2.71063 |
| 2 | 3.05479 |
| 3 | 1.01473 |
| 4 | 0.587547 |
| 5 | 1.21846 |

**Fit quality:**
- R² = 0.999408
- RMSE = 0.006911 (on the ln η scale)

**Fitted equation (explicit; all coefficients from fit tool output):**

$$\ln\eta = x_1 \ln(0.00089) + (1-x_1)\ln(0.001082) + x_1(1-x_1)\bigl[2.57153 + 2.71063\,(2x_1-1) + 3.05479\,(2x_1-1)^2 + 1.01473\,(2x_1-1)^3 + 0.587547\,(2x_1-1)^4 + 1.21846\,(2x_1-1)^5\bigr]$$

where $x_1$ is the mole fraction of water and $\eta$ is in Pa·s.

---

### Fit 2 — GLOBlit_5201 (DOI: 10.1016/j.jct.2018.02.022, PROPblock_21)

- **Temperature:** 298.15 K
- **Pressure:** 92.3 kPa
- **Composition variable:** $x_1$ = mole fraction of ethanol; $x_2 = 1 - x_1$ (water)
- **Data points at 298.15 K:** 23
- **Composition range:** $x_1 \in [0, 1]$ (full range)
- **Pure-component viscosities (block edges):**
  - $\eta^*_{\text{ethanol}}$ = 0.0010914 Pa·s
  - $\eta^*_{\text{water}}$ = 0.00089689 Pa·s

**BIC-selected polynomial order:** 4

**Redlich–Kister coefficients** (dimensionless, applied to ln η; from fit_block tool output):

| k | $A_k$ |
|---|-------|
| 0 | 2.728 |
| 1 | −2.49259 |
| 2 | 2.55005 |
| 3 | −2.44775 |
| 4 | 1.53644 |

**Fit quality:**
- R² = 0.999334
- RMSE = 0.006613 (on the ln η scale)

**Fitted equation (explicit; all coefficients from fit tool output):**

$$\ln\eta = x_1 \ln(0.0010914) + (1-x_1)\ln(0.00089689) + x_1(1-x_1)\bigl[2.728 + (-2.49259)\,(2x_1-1) + 2.55005\,(2x_1-1)^2 + (-2.44775)\,(2x_1-1)^3 + 1.53644\,(2x_1-1)^4\bigr]$$

where $x_1$ is the mole fraction of ethanol and $\eta$ is in Pa·s.

---

### Comparison and Interpretation

| Feature | Fit 1 (GLOBlit_2825) | Fit 2 (GLOBlit_5201) |
|---------|----------------------|----------------------|
| DOI | 10.1016/j.jct.2007.05.004 | 10.1016/j.jct.2018.02.022 |
| Block | PROPblock_11 | PROPblock_21 |
| x-variable | x(water) | x(ethanol) |
| Points at 298.15 K | 10 | 23 |
| RK order (BIC) | 5 | 4 |
| R² | 0.999408 | 0.999334 |
| RMSE (ln η) | 0.006911 | 0.006613 |
| η(ethanol), Pa·s | 0.001082 | 0.0010914 |
| η(water), Pa·s | 0.00089 | 0.00089689 |

Both fits achieve R² > 0.999 and are mutually consistent. The leading RK coefficient $A_0 \approx 2.6$–2.7 is large and positive, confirming a strong positive departure from Arrhenius-ideal mixing — the mixture is substantially more viscous than the geometric-mean prediction. The higher-order coefficients capture the asymmetry of the viscosity maximum, which is skewed toward the water-rich side of the composition range (as evidenced by the large odd-order coefficients with alternating signs).

**Fit 2 (GLOBlit_5201)** is recommended as the primary correlation: it has more than twice as many data points (23 vs 10), achieves a slightly lower RMSE, and requires a lower polynomial order (4 vs 5), indicating a more parsimonious and robust representation.

### Valid Composition Range

Both correlations are valid over the **full mole-fraction range** $x \in [0, 1]$ at 298.15 K, as both source datasets span from pure component 1 to pure component 2.

### Output Files

- Fit data CSVs and excess-property CSVs for both blocks are available in the session output directory.
- Fit plots and excess-property plots (PNG) are also generated for visual inspection.

### Core claims

- Ethanol–water mixtures at 298.15 K exhibit a pronounced positive departure from Arrhenius-ideal viscosity mixing, with the mixture viscosity reaching roughly 2.5–3× the viscosity of either pure component at intermediate compositions.
- Two independent Redlich–Kister fits to ln η were obtained: Fit 1 (GLOBlit_2825, x₁ = mole fraction of water, 10 points, BIC-selected order 5, R² = 0.999408, RMSE = 0.006911) and Fit 2 (GLOBlit_5201, x₁ = mole fraction of ethanol, 23 points, BIC-selected order 4, R² = 0.999334, RMSE = 0.006613).
- The leading Redlich–Kister coefficient A₀ ≈ 2.6–2.7 (dimensionless, on the ln η scale) is large and positive in both fits, confirming the strong positive excess viscosity arising from enhanced hydrogen-bonding networks in the intermediate composition region.
- Large odd-order Redlich–Kister coefficients with alternating signs capture the asymmetry of the viscosity maximum, which is skewed toward the water-rich side of the composition range.
- Fit 2 (GLOBlit_5201) is recommended as the primary correlation because it has more than twice as many data points (23 vs 10), achieves a slightly lower RMSE, and requires a lower polynomial order (4 vs 5).
- Both correlations are valid over the full mole-fraction range x ∈ [0, 1] at 298.15 K and use pure-component viscosities of approximately 0.00089 Pa·s for water and approximately 0.00108–0.0010914 Pa·s for ethanol.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_11 |  | Provides binary ethanol–water viscosity data spanning the full mole-fraction range (0–1) at temperatures including 298.15 K and 101.0 kPa. The 10 data points at 298.15 K were used to obtain a 5th-order Redlich–Kister fit (R² = 0.999408) for the departure from Arrhenius-ideal viscosity mixing. |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21 |  | Provides binary ethanol–water viscosity data over the full mole-fraction range at temperatures including 298.15 K and 92.3 kPa. The 23 data points at 298.15 K yielded a 4th-order Redlich–Kister fit (R² = 0.999334, RMSE = 0.006613) and serves as the recommended primary correlation due to higher data density and lower polynomial order. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_2825 | PROPblock_11 | ethanol_water_GLOBlit_2825 | 5 | 2.5715296891028707; 2.7106335581252363; 3.054789275296448; 1.0147283695801146; 0.5875474593228343; 1.218456716213609 | 0.999408 | 0.006911011918291117 | 10 | 298.15 | arrhenius |  | 10.1016/j.jct.2007.05.004 |
| GLOBlit_5201 | PROPblock_21 | ethanol_water_GLOBlit_5201 | 4 | 2.7279958938647066; -2.4925941810857495; 2.5500472215385774; -2.4477499128574456; 1.53644421556371 | 0.999334 | 0.006612838327445672 | 23 | 298.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
