# Analysis Run — [run id removed] (Round 1)

**Question:** At 25 °C, what is the excess molar volume of liquid acetone + water across composition? Give me a Redlich–Kister correlation with its equation, coefficients and units, polynomial order, R², RMSE, and valid composition range.

**[run statistics removed]**

---

## Answer

## Excess Molar Volume of Acetone + Water at 25 °C (298.15 K)

### Data Source & Method

No directly measured excess molar volume (V^E) data exists in the ThermoML database for the acetone–water system. Instead, V^E was obtained via the **DP2 (exact pointwise transform)** route:

> Measured mass density ρ(x) → molar volume V_m = (x₁M₁ + x₂M₂)/ρ → excess molar volume V^E = V_m − (x₁V₁* + x₂V₂*)

where x₁ = mole fraction of acetone (M₁ = 58.08 g/mol) and x₂ = mole fraction of water (M₂ = 18.015 g/mol). Pure-component molar volumes V₁* and V₂* were extracted from the block's own edge rows at ~298.15 K.

Two independent density datasets were used, yielding two RK correlations:

---

### Redlich–Kister Equation

$$V^E(x_1) = x_1\,(1 - x_1)\,\sum_{k=0}^{n} A_k\,(2x_1 - 1)^k$$

where **x₁ = mole fraction of acetone** and V^E is in **m³/mol**.

---

### Fit 1 — Estrada-Baltazar et al. (2003)

| Item | Value |
|------|-------|
| **Source** | DOI: 10.1021/je030102f (GLOBlit_8129), PROPblock_5 |
| **Block scope** | 99 rows; T: 283.15–323.148 K; P: 101.325 kPa (block constraint); x₁(acetone): 0–1 |
| **Fit isotherm** | ~298.15 K (actual measured temperatures 298.145–298.146 K; ±0.5 K tolerance) |
| **Mixture data points used** | 9 |
| **BIC-selected RK order** | 5 |
| **R²** | 0.999603 |
| **RMSE** | 7.216 × 10⁻⁹ m³/mol |
| **BIC** | −324.26 |

**Coefficients (m³/mol):**

| k | Aₖ |
|---|-----|
| 0 | −5.82748 × 10⁻⁶ |
| 1 | +2.08967 × 10⁻⁶ |
| 2 | −6.47775 × 10⁻⁷ |
| 3 | +5.59084 × 10⁻⁷ |
| 4 | +6.79769 × 10⁻⁷ |
| 5 | −2.20656 × 10⁻⁶ |

**Pure-component molar volumes (block-edge values at ~298.15 K):**

| Component | V* (m³/mol) |
|-----------|-------------|
| Acetone | 7.4021 × 10⁻⁵ |
| Water | 1.8069 × 10⁻⁵ |

**Representative inspected density data at ~298.15 K (INSP_0e0ad8301fc4):**

| x₁(acetone) | T (K) | P (kPa) | ρ (kg/m³) |
|-------------|--------|---------|-----------|
| 0 | 298.146 | 101.325 | 997.019 |
| 0.2193 | 298.145 | 101.325 | 919.968 |
| 0.4986 | 298.146 | 101.325 | 853.436 |
| 0.7934 | 298.145 | 101.325 | 807.383 |
| 1 | 298.146 | 101.325 | 784.638 |

---

### Fit 2 — Endecott et al. (2007)

| Item | Value |
|------|-------|
| **Source** | DOI: 10.1021/je7000182 (GLOBlit_10721), PROPblock_6 |
| **Block scope** | 126 rows; T: 288.15–328.15 K; P: 101.0 kPa (block constraint); x₁(acetone): 0–1 |
| **Fit isotherm** | 298.15 K (±0.5 K tolerance) |
| **Mixture data points used** | 11 |
| **BIC-selected RK order** | 5 |
| **R²** | 0.999363 |
| **RMSE** | 1.008 × 10⁻⁸ m³/mol |
| **BIC** | −390.68 |

**Coefficients (m³/mol):**

| k | Aₖ |
|---|-----|
| 0 | −6.37692 × 10⁻⁶ |
| 1 | +3.20429 × 10⁻⁶ |
| 2 | −1.02112 × 10⁻⁶ |
| 3 | −4.07609 × 10⁻⁶ |
| 4 | −1.61733 × 10⁻⁶ |
| 5 | +7.52452 × 10⁻⁶ |

**Pure-component molar volumes (block-edge values at 298.15 K):**

| Component | V* (m³/mol) |
|-----------|-------------|
| Acetone | 7.4050 × 10⁻⁵ |
| Water | 1.8309 × 10⁻⁵ |

**Representative inspected density data at 298.15 K (INSP_7866cb853f00):**

| x₁(acetone) | T (K) | P (kPa) | ρ (kg/m³) |
|-------------|--------|---------|-----------|
| 0 | 298.15 | 101.0 | 997.06 |
| 0.05 | 298.15 | 101.0 | 977.21 |
| 0.2 | 298.15 | 101.0 | 927.37 |
| 0.4 | 298.15 | 101.0 | 874.80 |

---

### Valid Composition Range

Both fits cover the **full mole-fraction range**: x₁(acetone) = 0.0 to 1.0.

---

### BIC Model Selection Summary

Both datasets independently select **order 5** as optimal by BIC:

| Order | Fit 1 BIC | Fit 1 R² | Fit 2 BIC | Fit 2 R² |
|-------|-----------|----------|-----------|----------|
| 0 | −281.36 | 0.8419 | −332.56 | 0.6263 |
| 1 | −314.46 | 0.9969 | −354.81 | 0.9603 |
| 2 | −314.17 | 0.9975 | −367.34 | 0.9898 |
| 3 | −322.28 | 0.9992 | −371.33 | 0.9943 |
| 4 | −322.35 | 0.9994 | −373.42 | 0.9962 |
| 5 | −324.26 | 0.9996 | −390.68 | 0.9994 |

---

### Chemistry Insight

The leading coefficient A₀ is **negative** in both fits (−5.83 × 10⁻⁶ and −6.38 × 10⁻⁶ m³/mol), confirming that the acetone–water mixture exhibits **negative excess molar volume** (volume contraction on mixing). This is characteristic of systems with strong hydrogen-bonding interactions between the unlike molecules — acetone's carbonyl group acts as a hydrogen-bond acceptor for water. The asymmetry coefficients (A₁ > 0) indicate the V^E minimum is shifted toward the water-rich side, consistent with the structural reorganization of the water hydrogen-bond network upon acetone insertion.

### Output Files

Fit data CSVs, excess-property CSVs, and corresponding plots for both sources are available in the session output directory.















### Core claims

- No directly measured excess molar volume data for acetone–water exists in the ThermoML database; V^E was derived via pointwise transformation of measured mass density data using V^E = V_m − (x₁V₁* + x₂V₂*).
- Two independent density datasets (Estrada-Baltazar et al. 2003 and Endecott et al. 2007) were used to obtain Redlich–Kister fits of V^E at ~298.15 K and ambient pressure over the full acetone mole-fraction range (0 to 1).
- Both fits independently select RK order 5 as optimal by BIC, with R² values of 0.999603 (Fit 1, RMSE 7.216 × 10⁻⁹ m³/mol) and 0.999363 (Fit 2, RMSE 1.008 × 10⁻⁸ m³/mol).
- The leading RK coefficient A₀ is negative in both fits (−5.82748 × 10⁻⁶ m³/mol for Fit 1 and −6.37692 × 10⁻⁶ m³/mol for Fit 2), confirming that the acetone–water mixture exhibits negative excess molar volume (volume contraction on mixing).
- The positive asymmetry coefficient A₁ in both fits indicates the V^E minimum is shifted toward the water-rich side.


### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8129 | 10.1021/je030102f | PROPblock_5 |  | Provides binary acetone–water mass density data (99 rows, x₁ 0–1, T 283–323 K, P 101.325 kPa) from which the ~298.15 K isotherm (9 mixture points) was extracted and transformed via DP2 to excess molar volume, yielding the first order-5 Redlich–Kister fit with A₀ = −5.83 × 10⁻⁶ m³/mol. |
| GLOBlit_10721 | 10.1021/je7000182 | PROPblock_6 |  | Provides an independent binary acetone–water mass density dataset (126 rows, x₁ 0–1, T 288–328 K, P 101.0 kPa) from which the 298.15 K isotherm (11 mixture points) was extracted and transformed via DP2 to excess molar volume, yielding the second order-5 Redlich–Kister fit with A₀ = −6.38 × 10⁻⁶ m³/mol. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_8129 | PROPblock_5 | GLOBprop_1 | 5 | -5.82747594333321e-06; 2.089672081449314e-06; -6.477748240344595e-07; 5.590837275402922e-07; 6.797685763873029e-07; -2.2065551458247056e-06 | 0.999603 | 7.216018718041471e-09 | 9 | 298.15 | linear |  | 10.1021/je030102f |
| GLOBlit_10721 | PROPblock_6 | GLOBprop_1 | 5 | -6.376917107014555e-06; 3.2042920135098695e-06; -1.0211216409189943e-06; -4.076087910363181e-06; -1.6173254497776513e-06; 7.524516230088109e-06 | 0.999363 | 1.0084490086147612e-08 | 11 | 298.15 | linear |  | 10.1021/je7000182 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
