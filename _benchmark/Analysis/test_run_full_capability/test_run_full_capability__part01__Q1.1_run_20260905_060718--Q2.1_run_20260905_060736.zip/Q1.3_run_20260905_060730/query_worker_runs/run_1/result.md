**Excess molar volume data for acetone + water binary mixture at 298.15 K: Not found in the ThermoML database.**

A comprehensive search of the ThermoML database for the binary system acetone (GLOBcomp_9, C₃H₆O) + water (GLOBcomp_1, H₂O) with excess molar volume (GLOBprop_28) returned zero matching blocks — both with and without a temperature filter around 298.15 K.

The database does contain 16 data blocks for the acetone + water binary system, but they cover other properties:

| Property | GLOBprop ID | Blocks | Example DOI |
|---|---|---|---|
| Mass density (kg/m³) | GLOBprop_1 | 3 | 10.1016/j.tca.2006.01.008 (GLOBlit_5679) |
| Activity coefficient | GLOBprop_3 | 2 | 10.1021/je0495942 (GLOBlit_8381) |
| Refractive index (Na D-line) | GLOBprop_7 | 1 | 10.1016/j.tca.2006.01.008 (GLOBlit_5679) |
| Surface tension liquid-gas (N/m) | GLOBprop_13 | 1 | 10.1021/je7000182 (GLOBlit_10721) |
| Molar enthalpy of solution (kJ/mol) | GLOBprop_15 | 1 | 10.1016/j.tca.2010.07.017 (GLOBlit_5893) |
| Henry's Law constant (kPa) | GLOBprop_27 | 3 | 10.1016/j.fluid.2005.02.006 (GLOBlit_241) |
| Binary diffusion coefficient (m²/s) | GLOBprop_29 | 3 | — |

**Chemistry note:** While excess molar volume data is not directly available, the mass density data (GLOBprop_1, 243 data points across 3 blocks) could in principle be used to calculate excess molar volumes if pure-component densities are also available, since V^E = V_mix − Σ x_i V_i*. However, no pre-computed excess molar volume entries exist for this system in ThermoML.

### Summary

A comprehensive search of the ThermoML database for excess molar volume (GLOBprop_28) of the binary system acetone (GLOBcomp_9, C₃H₆O) + water (GLOBcomp_1, H₂O) at 298.15 K returned zero matching blocks. The database contains 16 data blocks for this binary system covering other properties—mass density (GLOBprop_1, 3 blocks), activity coefficient (GLOBprop_3, 2 blocks), refractive index (GLOBprop_7, 1 block), surface tension (GLOBprop_13, 1 block), molar enthalpy of solution (GLOBprop_15, 1 block), Henry's Law constant (GLOBprop_27, 3 blocks), and binary diffusion coefficient (GLOBprop_29, 3 blocks)—but none for excess molar volume. The mass density data (243 data points across 3 blocks) could in principle be used to calculate excess molar volumes if pure-component densities are available, but no pre-computed excess molar volume entries exist for this system in ThermoML.

### Core claims

- A comprehensive search of the ThermoML database for the binary system acetone + water with excess molar volume (GLOBprop_28) returned zero matching blocks, both with and without a temperature filter around 298.15 K.
- The database contains 16 data blocks for the acetone + water binary system covering other properties (mass density, activity coefficient, refractive index, surface tension, molar enthalpy of solution, Henry's Law constant, and binary diffusion coefficient), but no pre-computed excess molar volume entries exist.
- Mass density data (GLOBprop_1, 243 data points across 3 blocks) could in principle be used to calculate excess molar volumes if pure-component densities are also available, but such derived values are not present in the database.

**Status:** no_results