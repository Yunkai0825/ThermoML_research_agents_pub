# Analysis Run — 20260905_061759 (Round 1)

**Question:** At 25 °C, what is the excess molar volume of liquid acetone + water across composition? Give me a Redlich–Kister correlation with its equation, coefficients and units, polynomial order, R², RMSE, and valid composition range.

**Time:** 588.1s | **Iterations:** 29 | **Tools:** 25

---

## Answer

## Excess Molar Volume of Acetone + Water at 25 °C (298.15 K)

### Data Source & Method

No directly measured excess molar volume (V^E) data exists in the ThermoML database for the acetone–water system. Instead, V^E was obtained via the **DP2 (exact pointwise transform)** route:

> Measured mass density ρ(x) → molar volume V_m = (x₁M₁ + x₂M₂)/ρ → excess molar volume V^E = V_m − (x₁V₁* + x₂V₂*)

where x₁ = mole fraction of acetone (M₁ = 58.08 g/mol) and x₂ = mole fraction of water (M₂ = 18.015 g/mol). Pure-component molar volumes V₁* and V₂* were extracted from the block's own edge rows at ~298.15 K.

Two independent density datasets were used, yielding two RK correlations:

---

### Redlich–Kister Equation

$$V^E(x_1) = x_1\,(1 - x_1)\,\sum_{k=0}^{n} A_k\,(2x_1 - 1)^k$$

where **x₁ = mole fraction of acetone** and V^E is in **m³/mol**.

---

### Fit 1 — Estrada-Baltazar et al. (2003)

| Item | Value |
|------|-------|
| **Source** | DOI: 10.1021/je030102f (GLOBlit_8129), PROPblock_5 |
| **Block scope** | 99 rows; T: 283.15–323.148 K; P: 101.325 kPa (block constraint); x₁(acetone): 0–1 |
| **Fit isotherm** | ~298.15 K (actual measured temperatures 298.145–298.146 K; ±0.5 K tolerance) |
| **Mixture data points used** | 9 |
| **BIC-selected RK order** | 5 |
| **R²** | 0.999603 |
| **RMSE** | 7.216 × 10⁻⁹ m³/mol |
| **BIC** | −324.26 |

**Coefficients (m³/mol):**

| k | Aₖ |
|---|-----|
| 0 | −5.82748 × 10⁻⁶ |
| 1 | +2.08967 × 10⁻⁶ |
| 2 | −6.47775 × 10⁻⁷ |
| 3 | +5.59084 × 10⁻⁷ |
| 4 | +6.79769 × 10⁻⁷ |
| 5 | −2.20656 × 10⁻⁶ |

**Pure-component molar volumes (block-edge values at ~298.15 K):**

| Component | V* (m³/mol) |
|-----------|-------------|
| Acetone | 7.4021 × 10⁻⁵ |
| Water | 1.8069 × 10⁻⁵ |

**Representative inspected density data at ~298.15 K (INSP_0e0ad8301fc4):**

| x₁(acetone) | T (K) | P (kPa) | ρ (kg/m³) |
|-------------|--------|---------|-----------|
| 0 | 298.146 | 101.325 | 997.019 |
| 0.2193 | 298.145 | 101.325 | 919.968 |
| 0.4986 | 298.146 | 101.325 | 853.436 |
| 0.7934 | 298.145 | 101.325 | 807.383 |
| 1 | 298.146 | 101.325 | 784.638 |

---

### Fit 2 — Endecott et al. (2007)

| Item | Value |
|------|-------|
| **Source** | DOI: 10.1021/je7000182 (GLOBlit_10721), PROPblock_6 |
| **Block scope** | 126 rows; T: 288.15–328.15 K; P: 101.0 kPa (block constraint); x₁(acetone): 0–1 |
| **Fit isotherm** | 298.15 K (±0.5 K tolerance) |
| **Mixture data points used** | 11 |
| **BIC-selected RK order** | 5 |
| **R²** | 0.999363 |
| **RMSE** | 1.008 × 10⁻⁸ m³/mol |
| **BIC** | −390.68 |

**Coefficients (m³/mol):**

| k | Aₖ |
|---|-----|
| 0 | −6.37692 × 10⁻⁶ |
| 1 | +3.20429 × 10⁻⁶ |
| 2 | −1.02112 × 10⁻⁶ |
| 3 | −4.07609 × 10⁻⁶ |
| 4 | −1.61733 × 10⁻⁶ |
| 5 | +7.52452 × 10⁻⁶ |

**Pure-component molar volumes (block-edge values at 298.15 K):**

| Component | V* (m³/mol) |
|-----------|-------------|
| Acetone | 7.4050 × 10⁻⁵ |
| Water | 1.8309 × 10⁻⁵ |

**Representative inspected density data at 298.15 K (INSP_7866cb853f00):**

| x₁(acetone) | T (K) | P (kPa) | ρ (kg/m³) |
|-------------|--------|---------|-----------|
| 0 | 298.15 | 101.0 | 997.06 |
| 0.05 | 298.15 | 101.0 | 977.21 |
| 0.2 | 298.15 | 101.0 | 927.37 |
| 0.4 | 298.15 | 101.0 | 874.80 |

---

### Valid Composition Range

Both fits cover the **full mole-fraction range**: x₁(acetone) = 0.0 to 1.0.

---

### BIC Model Selection Summary

Both datasets independently select **order 5** as optimal by BIC:

| Order | Fit 1 BIC | Fit 1 R² | Fit 2 BIC | Fit 2 R² |
|-------|-----------|----------|-----------|----------|
| 0 | −281.36 | 0.8419 | −332.56 | 0.6263 |
| 1 | −314.46 | 0.9969 | −354.81 | 0.9603 |
| 2 | −314.17 | 0.9975 | −367.34 | 0.9898 |
| 3 | −322.28 | 0.9992 | −371.33 | 0.9943 |
| 4 | −322.35 | 0.9994 | −373.42 | 0.9962 |
| 5 | −324.26 | 0.9996 | −390.68 | 0.9994 |

---

### Chemistry Insight

The leading coefficient A₀ is **negative** in both fits (−5.83 × 10⁻⁶ and −6.38 × 10⁻⁶ m³/mol), confirming that the acetone–water mixture exhibits **negative excess molar volume** (volume contraction on mixing). This is characteristic of systems with strong hydrogen-bonding interactions between the unlike molecules — acetone's carbonyl group acts as a hydrogen-bond acceptor for water. The asymmetry coefficients (A₁ > 0) indicate the V^E minimum is shifted toward the water-rich side, consistent with the structural reorganization of the water hydrogen-bond network upon acetone insertion.

### Output Files

Fit data CSVs, excess-property CSVs, and corresponding plots for both sources are available in the session output directory.

---
[UNGROUNDED DATA FLAGS] The following quoted values could not be verified against any verbatim data inspection in this run and must be treated as UNVERIFIED:
- **UNINSPECTED_VALUE** PROPblock_5: 283.15 exists in PROPblock_5's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_8129::PROPblock_5", nearest={"column": "temperature_k", "value": 283.15})`
- **UNINSPECTED_VALUE** PROPblock_5: 323.148 exists in PROPblock_5's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_8129::PROPblock_5", nearest={"column": "temperature_k", "value": 323.148})`
- **UNINSPECTED_VALUE** PROPblock_6: 288.15 exists in PROPblock_6's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_10721::PROPblock_6", nearest={"column": "temperature_k", "value": 288.15})`
- **UNINSPECTED_VALUE** PROPblock_6: 328.15 exists in PROPblock_6's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_10721::PROPblock_6", nearest={"column": "temperature_k", "value": 328.15})`
- **UNINSPECTED_VALUE** PROPblock_6: 0.5 exists in PROPblock_6's database table but was never shown in an inspection of this run
  fix (required — this value IS in the cited block's database table): `inspect_block_table(block_number="GLOBlit_10721::PROPblock_6", nearest={"column": "mole_fraction_<acetone>", "value": 0.5})`
Inspected so far: PROPblock_5, PROPblock_6, PROPblock_8

### Core claims

- No directly measured excess molar volume data for acetone–water exists in the ThermoML database; V^E was derived via pointwise transformation of measured mass density data using V^E = V_m − (x₁V₁* + x₂V₂*).
- Two independent density datasets (Estrada-Baltazar et al. 2003 and Endecott et al. 2007) were used to obtain Redlich–Kister fits of V^E at ~298.15 K and ambient pressure over the full acetone mole-fraction range (0 to 1).
- Both fits independently select RK order 5 as optimal by BIC, with R² values of 0.999603 (Fit 1, RMSE 7.216 × 10⁻⁹ m³/mol) and 0.999363 (Fit 2, RMSE 1.008 × 10⁻⁸ m³/mol).
- The leading RK coefficient A₀ is negative in both fits (−5.82748 × 10⁻⁶ m³/mol for Fit 1 and −6.37692 × 10⁻⁶ m³/mol for Fit 2), confirming that the acetone–water mixture exhibits negative excess molar volume (volume contraction on mixing).
- The positive asymmetry coefficient A₁ in both fits indicates the V^E minimum is shifted toward the water-rich side.
- Several quoted block-scope boundary values (temperature and composition ranges) remain unverified against direct data inspection and carry UNVERIFIED flags.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8129 | 10.1021/je030102f | PROPblock_5 |  | Provides binary acetone–water mass density data (99 rows, x₁ 0–1, T 283–323 K, P 101.325 kPa) from which the ~298.15 K isotherm (9 mixture points) was extracted and transformed via DP2 to excess molar volume, yielding the first order-5 Redlich–Kister fit with A₀ = −5.83 × 10⁻⁶ m³/mol. |
| GLOBlit_10721 | 10.1021/je7000182 | PROPblock_6 |  | Provides an independent binary acetone–water mass density dataset (126 rows, x₁ 0–1, T 288–328 K, P 101.0 kPa) from which the 298.15 K isotherm (11 mixture points) was extracted and transformed via DP2 to excess molar volume, yielding the second order-5 Redlich–Kister fit with A₀ = −6.38 × 10⁻⁶ m³/mol. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_8129 | PROPblock_5 | GLOBprop_1 | 5 | -5.82747594333321e-06; 2.089672081449314e-06; -6.477748240344595e-07; 5.590837275402922e-07; 6.797685763873029e-07; -2.2065551458247056e-06 | 0.999603 | 7.216018718041471e-09 | 9 | 298.15 | linear |  | 10.1021/je030102f |
| GLOBlit_10721 | PROPblock_6 | GLOBprop_1 | 5 | -6.376917107014555e-06; 3.2042920135098695e-06; -1.0211216409189943e-06; -4.076087910363181e-06; -1.6173254497776513e-06; 7.524516230088109e-06 | 0.999363 | 1.0084490086147612e-08 | 11 | 298.15 | linear |  | 10.1021/je7000182 |

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored. 3 entr(ies); verbatim rows below.

- INSP_62e1df49db96 — GLOBlit_5679::PROPblock_8 · rdp · 9 rows
- INSP_7866cb853f00 — GLOBlit_10721::PROPblock_6 · nearest · 8 rows
- INSP_0e0ad8301fc4 — GLOBlit_8129::PROPblock_5 · nearest · 8 rows

```json
[
  {
    "doi": "10.1016/j.tca.2006.01.008",
    "block_number": "PROPblock_8",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<acetone>",
      "temperature_k",
      "pressure_kpa",
      "mass_density_kg_m3"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "mole_fraction_<acetone>": "0.0502",
        "temperature_k": "298.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "977"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "mole_fraction_<acetone>": "0.2496",
        "temperature_k": "298.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "911.8"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "mole_fraction_<acetone>": "0.3507",
        "temperature_k": "298.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "884.8"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "mole_fraction_<acetone>": "0.4509",
        "temperature_k": "298.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "862.1"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "mole_fraction_<acetone>": "0.5489",
        "temperature_k": "298.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "843.5"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "mole_fraction_<acetone>": "0.6506",
        "temperature_k": "298.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "827"
      },
      {
        "BLKpoint_id": "BLKpoint_17",
        "mole_fraction_<acetone>": "0.8011",
        "temperature_k": "298.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "806.2"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "mole_fraction_<acetone>": "0.8015",
        "temperature_k": "298.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "806.3"
      },
      {
        "BLKpoint_id": "BLKpoint_22",
        "mole_fraction_<acetone>": "0.9451",
        "temperature_k": "298.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "789.9"
      }
    ],
    "inspection_id": "INSP_62e1df49db96",
    "lit_num_id": "GLOBlit_5679"
  },
  {
    "doi": "10.1021/je7000182",
    "block_number": "PROPblock_6",
    "table_mode": "nearest",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "mole_fraction_<acetone>",
      "pressure_kpa",
      "mass_density_kg_m3"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_29",
        "temperature_k": "298.15",
        "mole_fraction_<acetone>": "0",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "997.06"
      },
      {
        "BLKpoint_id": "BLKpoint_30",
        "temperature_k": "298.15",
        "mole_fraction_<acetone>": "0.0099",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "992.55"
      },
      {
        "BLKpoint_id": "BLKpoint_31",
        "temperature_k": "298.15",
        "mole_fraction_<acetone>": "0.05",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "977.21"
      },
      {
        "BLKpoint_id": "BLKpoint_32",
        "temperature_k": "298.15",
        "mole_fraction_<acetone>": "0.1",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "959.83"
      },
      {
        "BLKpoint_id": "BLKpoint_33",
        "temperature_k": "298.15",
        "mole_fraction_<acetone>": "0.15",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "943.05"
      },
      {
        "BLKpoint_id": "BLKpoint_34",
        "temperature_k": "298.15",
        "mole_fraction_<acetone>": "0.2",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "927.37"
      },
      {
        "BLKpoint_id": "BLKpoint_35",
        "temperature_k": "298.15",
        "mole_fraction_<acetone>": "0.3",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "898.35"
      },
      {
        "BLKpoint_id": "BLKpoint_36",
        "temperature_k": "298.15",
        "mole_fraction_<acetone>": "0.4",
        "pressure_kpa": "101.0",
        "mass_density_kg_m3": "874.8"
      }
    ],
    "inspection_id": "INSP_7866cb853f00",
    "lit_num_id": "GLOBlit_10721"
  },
  {
    "doi": "10.1021/je030102f",
    "block_number": "PROPblock_5",
    "table_mode": "nearest",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<acetone>",
      "temperature_k",
      "pressure_kpa",
      "mass_density_kg_m3"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_22",
        "mole_fraction_<acetone>": "0.2193",
        "temperature_k": "298.145",
        "pressure_kpa": "101.325",
        "mass_density_kg_m3": "919.968"
      },
      {
        "BLKpoint_id": "BLKpoint_31",
        "mole_fraction_<acetone>": "0.2973",
        "temperature_k": "298.145",
        "pressure_kpa": "101.325",
        "mass_density_kg_m3": "899.375"
      },
      {
        "BLKpoint_id": "BLKpoint_40",
        "mole_fraction_<acetone>": "0.3998",
        "temperature_k": "298.145",
        "pressure_kpa": "101.325",
        "mass_density_kg_m3": "874.098"
      },
      {
        "BLKpoint_id": "BLKpoint_67",
        "mole_fraction_<acetone>": "0.6984",
        "temperature_k": "298.145",
        "pressure_kpa": "101.325",
        "mass_density_kg_m3": "820.292"
      },
      {
        "BLKpoint_id": "BLKpoint_76",
        "mole_fraction_<acetone>": "0.7934",
        "temperature_k": "298.145",
        "pressure_kpa": "101.325",
        "mass_density_kg_m3": "807.383"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "mole_fraction_<acetone>": "0",
        "temperature_k": "298.146",
        "pressure_kpa": "101.325",
        "mass_density_kg_m3": "997.019"
      },
      {
        "BLKpoint_id": "BLKpoint_49",
        "mole_fraction_<acetone>": "0.4986",
        "temperature_k": "298.146",
        "pressure_kpa": "101.325",
        "mass_density_kg_m3": "853.436"
      },
      {
        "BLKpoint_id": "BLKpoint_94",
        "mole_fraction_<acetone>": "1",
        "temperature_k": "298.146",
        "pressure_kpa": "101.325",
        "mass_density_kg_m3": "784.638"
      }
    ],
    "inspection_id": "INSP_0e0ad8301fc4",
    "lit_num_id": "GLOBlit_8129"
  }
]
```

---

## Verdict

**Data Quality**
The agent correctly derived V^E from measured mixture density data via the exact DP2 transform (fit_block_derived), which is the proper route when direct V^E data are unavailable. Two independent datasets were used. Composition basis is mole fraction. The tool trace confirms fit_block_derived calls (steps 17–18) returned successful RK fits with coefficients, R², and RMSE. Inspected density rows match those quoted. No fabrication detected.

**Fit Quality**
Order 5 selected by BIC with only 9–11 data points raises mild overfitting concern (6 parameters for 9 points). R² values (~0.9994–0.9996) and very low RMSE (~7–10 × 10⁻⁹ m³/mol) are excellent, but the high-order coefficients may be poorly constrained. Order 3 would be more parsimonious.

**Scientific Verdict**
Results are scientifically sound: V^E is negative across composition, consistent with strong acetone–water hydrogen bonding. The two independent fits agree on sign and magnitude of A₀ (~−6 × 10⁻⁶ m³/mol). Recommend cautious use of order-5 fits given limited data; order 3 may suffice for most applications.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.3_run_20260905_060730\data\10_1021_je030102f_BPROPblock_5_T298.1_fit.csv` — RK fit data — 10.1021/je030102f PROPblock_5_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.3_run_20260905_060730\data\10_1021_je030102f_BPROPblock_5_T298.1_excess.csv` — Excess property — 10.1021/je030102f PROPblock_5_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.3_run_20260905_060730\plots\10_1021_je030102f_BPROPblock_5_T298.1_fit.png` — RK fit plot — 10.1021/je030102f PROPblock_5_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.3_run_20260905_060730\plots\10_1021_je030102f_BPROPblock_5_T298.1_excess.png` — Excess plot — 10.1021/je030102f PROPblock_5_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.3_run_20260905_060730\data\10_1021_je7000182_BPROPblock_6_T298.1_fit.csv` — RK fit data — 10.1021/je7000182 PROPblock_6_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.3_run_20260905_060730\data\10_1021_je7000182_BPROPblock_6_T298.1_excess.csv` — Excess property — 10.1021/je7000182 PROPblock_6_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.3_run_20260905_060730\plots\10_1021_je7000182_BPROPblock_6_T298.1_fit.png` — RK fit plot — 10.1021/je7000182 PROPblock_6_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.3_run_20260905_060730\plots\10_1021_je7000182_BPROPblock_6_T298.1_excess.png` — Excess plot — 10.1021/je7000182 PROPblock_6_T298.1