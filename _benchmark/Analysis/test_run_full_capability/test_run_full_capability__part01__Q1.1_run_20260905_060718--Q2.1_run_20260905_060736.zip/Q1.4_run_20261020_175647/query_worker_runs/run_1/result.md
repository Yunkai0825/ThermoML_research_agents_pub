# Delegated Query L1 worker — result

**Question:** ## Purpose
Find excess molar enthalpy (Hᴱ) data blocks for benzene + cyclohexane at approximately 298.2 K and 100 kPa

## Instruction
Search for binary mixture blocks containing benzene and cyclohexane with excess molar enthalpy (GLOBprop_17). Filter for temperature near 298.2 K. Return DOIs, block numbers, temperature ranges, pressure, number of data points, and composition ranges.

## ID Catalog (from working memory)
[{"type": "prop", "global_id": "GLOBprop_17", "registry_id": "GLOBprop_17", "name": "Excess molar enthalpy"}]

**Iterations:** 9  |  **Elapsed:** 180.7s  |  **Tools:** 8  |  **Timed out:** False

---

## Answer

## Excess Molar Enthalpy (Hᴱ) Data for Benzene + Cyclohexane at ~298.2 K and ~100 kPa

### Key Finding

The ThermoML database **does** contain excess molar enthalpy data for benzene (GLOBcomp_14) + cyclohexane (GLOBcomp_13) at 298.2 K and 100 kPa, within block **GLOBlit_4181::PROPblock_2** (DOI: 10.1016/j.jct.2014.05.020).

### Block Overview (GLOBlit_4181::PROPblock_2)

| Field | Value |
|---|---|
| DOI | 10.1016/j.jct.2014.05.020 [GLOBlit_4181] |
| Block | PROPblock_2 |
| Property | GLOBprop_17 — Excess molar enthalpy (kJ/mol) |
| Method | GLOBmeas_12 — flow calorimetry |
| Phase | Liquid |
| Total points | 219 |
| T range | 298.2–523.2 K |
| P range | 100–25000 kPa |
| x(benzene) range | 0.1187–0.9585 |

At T = 298.2 K, there are 57 data points across four pressures (100, 5000, 15000, and 25000 kPa).

### Data at 298.2 K and 100 kPa (target conditions) — from GLOBlit_4181::PROPblock_2

| x(benzene) | Hᴱ (kJ/mol) | ±U (kJ/mol) |
|------------|-------------|-------------|
| 0.1191 | 0.3207 | 0.0143 |
| 0.2332 | 0.5517 | 0.0145 |
| 0.3426 | 0.7003 | 0.0134 |
| 0.4478 | 0.7782 | 0.0131 |
| 0.5488 | 0.7863 | 0.0131 |
| 0.6459 | 0.7353 | 0.0133 |
| 0.7394 | 0.6282 | 0.0139 |
| 0.9163 | 0.2636 | 0.0150 |

Uncertainties are expanded combined (U) at 95% confidence level.

### Data at 298.2 K and 5000 kPa — from GLOBlit_4181::PROPblock_2

| x(benzene) | Hᴱ (kJ/mol) | ±U (kJ/mol) |
|------------|-------------|-------------|
| 0.1189 | 0.318 | 0.0148 |
| 0.2882 | 0.6367 | 0.0139 |
| 0.3955 | 0.744 | 0.0134 |
| 0.4985 | 0.7873 | 0.0133 |
| 0.5976 | 0.7631 | 0.0133 |
| 0.6929 | 0.6925 | 0.0135 |
| 0.8293 | 0.4721 | 0.0149 |
| 0.9162 | 0.257 | 0.0158 |

### Other Blocks (not near target conditions)

| # | DOI | Block | lit_id | T (K) | P range (kPa) | Phase |
|---|-----|-------|--------|-------|---------------|-------|
| 2 | 10.1016/j.jct.2014.05.020 | PROPblock_3 | GLOBlit_4181 | 573.2 (fixed) | 15000–25000 | Fluid |
| 3 | 10.1016/j.jct.2014.07.016 | PROPblock_1 | GLOBlit_4217 | 558.2 | up to 14760 | Fluid |

These blocks are at much higher temperatures and are not relevant to the 298.2 K target. The lower pressure bound for GLOBlit_4217::PROPblock_1 was not verified in this run.

### Chemistry Insight (based on GLOBlit_4181::PROPblock_2 data)

The Hᴱ values are positive (endothermic mixing) across the entire composition range, with a maximum near x(benzene) ≈ 0.55 (approximate, based on the inspected rows above) where Hᴱ reaches 0.7863 kJ/mol at 100 kPa. The slightly asymmetric curve (maximum shifted toward benzene-rich compositions) reflects the disruption of cyclohexane's weak dispersion network by benzene's aromatic π-system. Comparing the 100 kPa and 5000 kPa data from GLOBlit_4181::PROPblock_2 at 298.2 K, the Hᴱ values are very similar (e.g., 0.7863 vs. 0.7873 kJ/mol near equimolar), indicating minimal pressure dependence of the excess enthalpy in the liquid phase at this temperature.

---
[UNGROUNDED DATA FLAGS] The following quoted values could not be verified against any verbatim data inspection in this run and must be treated as UNVERIFIED:
- **MISATTRIBUTED_VALUE** PROPblock_1: 298.2 does not belong to PROPblock_1; it matches only GLOBlit_4181::PROPblock_2 (inspected this run)
  fix (required — this IS a database value, under a different block): `re-anchor 298.2 to GLOBlit_4181::PROPblock_2 — no new tool call needed`
Inspected so far: PROPblock_1, PROPblock_2, PROPblock_3

### Summary

The ThermoML database contains excess molar enthalpy (Hᴱ) data for benzene + cyclohexane at 298.2 K and 100 kPa in block GLOBlit_4181::PROPblock_2 (DOI: 10.1016/j.jct.2014.05.020), measured by flow calorimetry. Eight data points at these conditions span x(benzene) from 0.1191 to 0.9163, with Hᴱ values (kJ/mol): 0.3207, 0.5517, 0.7003, 0.7782, 0.7863, 0.7353, 0.6282, and 0.2636, respectively, with expanded uncertainties (95% confidence) ranging from 0.0131 to 0.0150 kJ/mol. Mixing is endothermic across the entire composition range, with a maximum Hᴱ of 0.7863 kJ/mol near x(benzene) ≈ 0.55. The full block contains 219 points spanning 298.2–523.2 K and 100–25000 kPa. Comparison of 100 kPa and 5000 kPa data at 298.2 K shows minimal pressure dependence of Hᴱ in the liquid phase (e.g., 0.7863 vs. 0.7873 kJ/mol near equimolar). The slight asymmetry of the curve toward benzene-rich compositions reflects disruption of cyclohexane's dispersion network by benzene's aromatic π-system.

### Core claims

- The ThermoML database contains excess molar enthalpy (Hᴱ) data for benzene + cyclohexane at 298.2 K and 100 kPa in block GLOBlit_4181::PROPblock_2 (DOI: 10.1016/j.jct.2014.05.020), measured by flow calorimetry in the liquid phase.
- At 298.2 K and 100 kPa, Hᴱ is positive (endothermic mixing) across the entire composition range, with values ranging from 0.2636 kJ/mol at x(benzene) = 0.9163 to 0.7863 kJ/mol at x(benzene) = 0.5488, with expanded combined uncertainties (95% confidence) of approximately 0.013–0.015 kJ/mol.
- The Hᴱ maximum occurs near x(benzene) ≈ 0.55, indicating a slightly asymmetric curve shifted toward benzene-rich compositions.
- Comparing 100 kPa and 5000 kPa data at 298.2 K near equimolar composition (0.7863 vs. 0.7873 kJ/mol), the excess enthalpy shows minimal pressure dependence in the liquid phase at this temperature.

**Status:** success

---

## Core ID Updates (deterministic ledger)

Deterministic identifier updates; rendered by the browser.

```json
[
  {
    "action": "add",
    "core_GLOB_id": "GLOBcomp_14",
    "registry_id": "benzene",
    "name": "benzene"
  },
  {
    "action": "add",
    "core_GLOB_id": "GLOBcomp_13",
    "registry_id": "cyclohexane",
    "name": "cyclohexane"
  }
]
```

---

## Core Blocks Found (deterministic ledger)

Database-hydrated core block records; rendered by the browser.

```json
[
  {
    "lit_num_id": "GLOBlit_4181",
    "block_number": "PROPblock_2",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_14",
      "GLOBcomp_13"
    ],
    "prop_num_ids": [
      "GLOBprop_17"
    ],
    "description": "Excess molar enthalpy data for benzene + cyclohexane covering 298.2–523.2 K and 100–25000 kPa with 219 data points; the primary source for Hᴱ at the target conditions of 298.2 K and 100 kPa.",
    "doi": "10.1016/j.jct.2014.05.020",
    "lit_id": "2014-fan-tsu-0",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 219,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_14",
        "name": "benzene",
        "formula": "C6H6",
        "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
        "SMILES": "c1ccccc1",
        "sample_num": "DOIcompSample_3_1"
      },
      {
        "org_num": "DOIcomp_4",
        "comp_num_id": "GLOBcomp_13",
        "name": "cyclohexane",
        "formula": "C6H12",
        "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
        "SMILES": "C1CCCCC1",
        "sample_num": "DOIcompSample_4_1"
      }
    ],
    "solvents": [],
    "constraints": [],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_1",
        "var_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Temperature, K",
          "min": 298.2,
          "max": 523.2,
          "n_unique": 6
        },
        "range_min": 298.2,
        "range_max": 523.2
      },
      {
        "BLKvar_id": "BLKvar_2",
        "var_num_id": "GLOBvar_3",
        "var_id": "pressure_kpa",
        "name": "Pressure, kPa",
        "type": "ePressure",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_2",
          "name": "Pressure, kPa",
          "min": 100.0,
          "max": 25000.0,
          "n_unique": 4
        },
        "range_min": 100.0,
        "range_max": 25000.0
      },
      {
        "BLKvar_id": "BLKvar_3",
        "var_num_id": "GLOBvar_2",
        "var_id": "mole_fraction_DOIcomp_3",
        "name": "Mole fraction",
        "type": "eComponentComposition",
        "component_org_num": "DOIcomp_3",
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_3",
          "name": "Mole fraction",
          "min": 0.1187,
          "max": 0.9585,
          "n_unique": 63
        },
        "range_min": 0.1187,
        "range_max": 0.9585
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_17",
        "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
        "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
        "group": "ExcessPartialApparentEnergyProp",
        "component_org_num": null,
        "meas_num_id": "GLOBmeas_12",
        "meas_ID": "flow_calorimetry",
        "method_standard": "Flow calorimetry",
        "method_custom": null,
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "min": 0.0514,
          "max": 0.7893,
          "mean": 0.40095,
          "std": 0.199867,
          "n": 219
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": 0.0514,
        "range_max": 0.7893
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_2",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_3",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_14",
        "name": "benzene",
        "formula": "C6H6",
        "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
        "SMILES": "c1ccccc1",
        "sample_num": "DOIcompSample_3_1"
      },
      {
        "org_num": "DOIcomp_4",
        "comp_num_id": "GLOBcomp_13",
        "name": "cyclohexane",
        "formula": "C6H12",
        "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
        "SMILES": "C1CCCCC1",
        "sample_num": "DOIcompSample_4_1"
      }
    ],
    "parent_n_datapoints": 219,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  },
  {
    "lit_num_id": "GLOBlit_4181",
    "block_number": "PROPblock_3",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_14",
      "GLOBcomp_13"
    ],
    "prop_num_ids": [
      "GLOBprop_17"
    ],
    "description": "Excess molar enthalpy data for benzene + cyclohexane at 573.2 K and 15000–25000 kPa; noted as not relevant to the 298.2 K target.",
    "doi": "10.1016/j.jct.2014.05.020",
    "lit_id": "2014-fan-tsu-0",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 24,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_14",
        "name": "benzene",
        "formula": "C6H6",
        "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
        "SMILES": "c1ccccc1",
        "sample_num": "DOIcompSample_3_1"
      },
      {
        "org_num": "DOIcomp_4",
        "comp_num_id": "GLOBcomp_13",
        "name": "cyclohexane",
        "formula": "C6H12",
        "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
        "SMILES": "C1CCCCC1",
        "sample_num": "DOIcompSample_4_1"
      }
    ],
    "solvents": [],
    "constraints": [
      {
        "BLKconstr_id": "BLKconstr_1",
        "constr_num_id": "GLOBconstr_2",
        "constr_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "value": 573.2,
        "digits": 4,
        "component_org_num": null,
        "phase": {
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        }
      }
    ],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_3",
        "var_id": "pressure_kpa",
        "name": "Pressure, kPa",
        "type": "ePressure",
        "component_org_num": null,
        "phase": {
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Pressure, kPa",
          "min": 15000.0,
          "max": 25000.0,
          "n_unique": 2
        },
        "range_min": 15000.0,
        "range_max": 25000.0
      },
      {
        "BLKvar_id": "BLKvar_2",
        "var_num_id": "GLOBvar_2",
        "var_id": "mole_fraction_DOIcomp_3",
        "name": "Mole fraction",
        "type": "eComponentComposition",
        "component_org_num": "DOIcomp_3",
        "phase": {
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        "range": {
          "BLKvar_id": "BLKvar_2",
          "name": "Mole fraction",
          "min": 0.1187,
          "max": 0.9584,
          "n_unique": 23
        },
        "range_min": 0.1187,
        "range_max": 0.9584
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_17",
        "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
        "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
        "group": "ExcessPartialApparentEnergyProp",
        "component_org_num": null,
        "meas_num_id": "GLOBmeas_12",
        "meas_ID": "flow_calorimetry",
        "method_standard": "Flow calorimetry",
        "method_custom": null,
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "min": 0.0399,
          "max": 0.373,
          "mean": 0.22705,
          "std": 0.103854,
          "n": 24
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": 0.0399,
        "range_max": 0.373
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Fluid (supercritical or subcritical phases)",
        "phase_num_id": "GLOBphase_10",
        "phase_id": "fluid_supercritical_or_subcritical_phases"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Fluid (supercritical or subcritical phases)",
        "phase_num_id": "GLOBphase_10",
        "phase_id": "fluid_supercritical_or_subcritical_phases"
      },
      {
        "owner_id": "BLKvar_2",
        "role": "phase",
        "phase": "Fluid (supercritical or subcritical phases)",
        "phase_num_id": "GLOBphase_10",
        "phase_id": "fluid_supercritical_or_subcritical_phases"
      },
      {
        "owner_id": "BLKconstr_1",
        "role": "phase",
        "phase": "Fluid (supercritical or subcritical phases)",
        "phase_num_id": "GLOBphase_10",
        "phase_id": "fluid_supercritical_or_subcritical_phases"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_14",
        "name": "benzene",
        "formula": "C6H6",
        "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
        "SMILES": "c1ccccc1",
        "sample_num": "DOIcompSample_3_1"
      },
      {
        "org_num": "DOIcomp_4",
        "comp_num_id": "GLOBcomp_13",
        "name": "cyclohexane",
        "formula": "C6H12",
        "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
        "SMILES": "C1CCCCC1",
        "sample_num": "DOIcompSample_4_1"
      }
    ],
    "parent_n_datapoints": 24,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  },
  {
    "lit_num_id": "GLOBlit_4217",
    "block_number": "PROPblock_1",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_14",
      "GLOBcomp_13"
    ],
    "prop_num_ids": [
      "GLOBprop_17"
    ],
    "description": "Excess molar enthalpy data for benzene + cyclohexane at 558.2 K; noted as not relevant to the 298.2 K target.",
    "doi": "10.1016/j.jct.2014.07.016",
    "lit_id": "2014-fan-tsu-1",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 556,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_1",
        "comp_num_id": "GLOBcomp_14",
        "name": "benzene",
        "formula": "C6H6",
        "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
        "SMILES": "c1ccccc1",
        "sample_num": "DOIcompSample_1_1"
      },
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_13",
        "name": "cyclohexane",
        "formula": "C6H12",
        "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
        "SMILES": "C1CCCCC1",
        "sample_num": "DOIcompSample_2_1"
      }
    ],
    "solvents": [],
    "constraints": [],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_1",
        "var_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "component_org_num": null,
        "phase": {
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Temperature, K",
          "min": 558.2,
          "max": 573.2,
          "n_unique": 3
        },
        "range_min": 558.2,
        "range_max": 573.2
      },
      {
        "BLKvar_id": "BLKvar_2",
        "var_num_id": "GLOBvar_2",
        "var_id": "mole_fraction_DOIcomp_1",
        "name": "Mole fraction",
        "type": "eComponentComposition",
        "component_org_num": "DOIcomp_1",
        "phase": {
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        "range": {
          "BLKvar_id": "BLKvar_2",
          "name": "Mole fraction",
          "min": 0.119,
          "max": 0.916,
          "n_unique": 9
        },
        "range_min": 0.119,
        "range_max": 0.916
      },
      {
        "BLKvar_id": "BLKvar_3",
        "var_num_id": "GLOBvar_3",
        "var_id": "pressure_kpa",
        "name": "Pressure, kPa",
        "type": "ePressure",
        "component_org_num": null,
        "phase": {
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        "range": {
          "BLKvar_id": "BLKvar_3",
          "name": "Pressure, kPa",
          "min": 2870.0,
          "max": 15180.0,
          "n_unique": 355
        },
        "range_min": 2870.0,
        "range_max": 15180.0
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_17",
        "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
        "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
        "group": "ExcessPartialApparentEnergyProp",
        "component_org_num": null,
        "meas_num_id": "GLOBmeas_12",
        "meas_ID": "flow_calorimetry",
        "method_standard": "Flow calorimetry",
        "method_custom": null,
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "min": -0.372,
          "max": 3.257,
          "mean": 0.512282,
          "std": 0.44786,
          "n": 556
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": -0.372,
        "range_max": 3.257
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Fluid (supercritical or subcritical phases)",
        "phase_num_id": "GLOBphase_10",
        "phase_id": "fluid_supercritical_or_subcritical_phases"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Fluid (supercritical or subcritical phases)",
        "phase_num_id": "GLOBphase_10",
        "phase_id": "fluid_supercritical_or_subcritical_phases"
      },
      {
        "owner_id": "BLKvar_2",
        "role": "phase",
        "phase": "Fluid (supercritical or subcritical phases)",
        "phase_num_id": "GLOBphase_10",
        "phase_id": "fluid_supercritical_or_subcritical_phases"
      },
      {
        "owner_id": "BLKvar_3",
        "role": "phase",
        "phase": "Fluid (supercritical or subcritical phases)",
        "phase_num_id": "GLOBphase_10",
        "phase_id": "fluid_supercritical_or_subcritical_phases"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_1",
        "comp_num_id": "GLOBcomp_14",
        "name": "benzene",
        "formula": "C6H6",
        "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
        "SMILES": "c1ccccc1",
        "sample_num": "DOIcompSample_1_1"
      },
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_13",
        "name": "cyclohexane",
        "formula": "C6H12",
        "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
        "SMILES": "C1CCCCC1",
        "sample_num": "DOIcompSample_2_1"
      }
    ],
    "parent_n_datapoints": 556,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  }
]
```

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1016/j.jct.2014.05.020",
    "block_number": "PROPblock_3",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "pressure_kpa",
      "mole_fraction_<benzene>",
      "temperature_k",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.1188",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.1497",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.012"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.1763",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2106",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0119"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.3421",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3295",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0116"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.4471",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3683",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.5482",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.373",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.6454",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3436",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0116"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.7389",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2874",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0118"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.9584",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.0501",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0123"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.1187",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.1394",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0119"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.1762",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.1982",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0118"
      },
      {
        "BLKpoint_id": "BLKpoint_16",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.3418",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3089",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0116"
      },
      {
        "BLKpoint_id": "BLKpoint_17",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.4469",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.345",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.5479",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3491",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_19",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.6451",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3208",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_20",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.7388",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.268",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0117"
      },
      {
        "BLKpoint_id": "BLKpoint_24",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.9584",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.0399",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0119"
      }
    ],
    "inspection_id": "INSP_e8c97651c4fa",
    "lit_num_id": "GLOBlit_4181"
  },
  {
    "doi": "10.1016/j.jct.2014.07.016",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "mole_fraction_<benzene>",
      "pressure_kpa",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "3390",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.125",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "3940",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.281",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.219"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4120",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.607",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.621"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4290",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.989",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.389"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4510",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "-0.372",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.437"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4790",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.362",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.207"
      },
      {
        "BLKpoint_id": "BLKpoint_17",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "6470",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.21",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_25",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "14760",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.157",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_26",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "3360",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.167",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.152"
      },
      {
        "BLKpoint_id": "BLKpoint_29",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4010",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.587",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.606"
      },
      {
        "BLKpoint_id": "BLKpoint_31",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4310",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "3.257",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.367"
      },
      {
        "BLKpoint_id": "BLKpoint_34",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4550",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.085",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.652"
      },
      {
        "BLKpoint_id": "BLKpoint_35",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4640",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.173",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.326"
      },
      {
        "BLKpoint_id": "BLKpoint_38",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5090",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.657",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.163"
      },
      {
        "BLKpoint_id": "BLKpoint_40",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5930",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.511",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_46",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "13910",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.349",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_47",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "3190",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.145",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.154"
      },
      {
        "BLKpoint_id": "BLKpoint_50",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "3920",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.456",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.208"
      },
      {
        "BLKpoint_id": "BLKpoint_51",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4090",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.783",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.671"
      },
      {
        "BLKpoint_id": "BLKpoint_53",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4340",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "3.055",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.338"
      },
      {
        "BLKpoint_id": "BLKpoint_55",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4570",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.058",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.584"
      },
      {
        "BLKpoint_id": "BLKpoint_56",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4640",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.58",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.514"
      },
      {
        "BLKpoint_id": "BLKpoint_59",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4910",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.814",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.191"
      },
      {
        "BLKpoint_id": "BLKpoint_62",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "5690",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.601",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_66",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "8140",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.45",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_69",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "13600",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.386",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_70",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "3310",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.158",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_77",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4100",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.695",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.774"
      },
      {
        "BLKpoint_id": "BLKpoint_78",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4300",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.512",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.611"
      },
      {
        "BLKpoint_id": "BLKpoint_82",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4860",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.002",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.387"
      },
      {
        "BLKpoint_id": "BLKpoint_86",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5690",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.619",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.152"
      },
      {
        "BLKpoint_id": "BLKpoint_92",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "8110",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.454",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_96",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "14940",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.38",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_97",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "3110",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.11",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_100",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "3980",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.419",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.221"
      },
      {
        "BLKpoint_id": "BLKpoint_103",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "4390",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.282",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.347"
      },
      {
        "BLKpoint_id": "BLKpoint_108",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "4920",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.807",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.308"
      },
      {
        "BLKpoint_id": "BLKpoint_110",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "5510",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.619",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.153"
      },
      {
        "BLKpoint_id": "BLKpoint_114",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "8030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.417",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_117",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "13130",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.362",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_118",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "3290",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.107",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_121",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4120",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.419",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.32"
      },
      {
        "BLKpoint_id": "BLKpoint_125",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4650",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.158",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.347"
      },
      {
        "BLKpoint_id": "BLKpoint_126",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4800",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.928",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.52"
      },
      {
        "BLKpoint_id": "BLKpoint_128",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4960",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.665",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.182"
      },
      {
        "BLKpoint_id": "BLKpoint_130",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "5540",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.511",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.153"
      },
      {
        "BLKpoint_id": "BLKpoint_134",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "7560",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.359",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_138",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "14070",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.291",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_139",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "3270",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.021",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_142",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4230",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.125",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.209"
      },
      {
        "BLKpoint_id": "BLKpoint_144",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4440",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.562",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.162"
      },
      {
        "BLKpoint_id": "BLKpoint_146",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4700",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.296",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.172"
      },
      {
        "BLKpoint_id": "BLKpoint_149",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "5300",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.188",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_163",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "13700",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.083",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_164",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "3700",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.118",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_167",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4300",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.499",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.315"
      },
      {
        "BLKpoint_id": "BLKpoint_169",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4540",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.252",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.198"
      },
      {
        "BLKpoint_id": "BLKpoint_172",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4850",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "-0.112",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.176"
      },
      {
        "BLKpoint_id": "BLKpoint_174",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "5000",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.354",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.188"
      },
      {
        "BLKpoint_id": "BLKpoint_181",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "7360",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.195",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_184",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "13790",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.156",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_185",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "3200",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.099",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_188",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "3910",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.264",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.162"
      },
      {
        "BLKpoint_id": "BLKpoint_190",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "4240",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.589",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.405"
      },
      {
        "BLKpoint_id": "BLKpoint_192",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "4550",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.967",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.254"
      },
      {
        "BLKpoint_id": "BLKpoint_195",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "4830",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "-0.087",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.35"
      },
      {
        "BLKpoint_id": "BLKpoint_197",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "5000",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.686",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.221"
      },
      {
        "BLKpoint_id": "BLKpoint_201",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "5650",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.464",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_205",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "7010",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.351",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_209",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "12990",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.271",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_210",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "3440",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.159",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_214",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4240",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.644",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.46"
      },
      {
        "BLKpoint_id": "BLKpoint_216",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4550",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.116",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.154"
      },
      {
        "BLKpoint_id": "BLKpoint_218",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4800",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.255",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.175"
      },
      {
        "BLKpoint_id": "BLKpoint_220",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5010",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.978",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.234"
      },
      {
        "BLKpoint_id": "BLKpoint_224",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5440",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.67",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.152"
      },
      {
        "BLKpoint_id": "BLKpoint_227",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "6880",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.456",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_232",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "12410",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.348",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_233",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "3680",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.21",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.156"
      },
      {
        "BLKpoint_id": "BLKpoint_236",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4340",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.846",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.433"
      },
      {
        "BLKpoint_id": "BLKpoint_238",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4550",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.787",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.343"
      },
      {
        "BLKpoint_id": "BLKpoint_240",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4810",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.879",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.207"
      },
      {
        "BLKpoint_id": "BLKpoint_242",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4960",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.533",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.204"
      },
      {
        "BLKpoint_id": "BLKpoint_246",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5300",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.892",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.165"
      },
      {
        "BLKpoint_id": "BLKpoint_252",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "6030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.611",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_259",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "9110",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.429",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_262",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "14860",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.372",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_263",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "3520",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.119",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_266",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4200",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.353",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.182"
      },
      {
        "BLKpoint_id": "BLKpoint_269",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4700",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.239",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.224"
      },
      {
        "BLKpoint_id": "BLKpoint_271",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4900",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.763",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.156"
      },
      {
        "BLKpoint_id": "BLKpoint_272",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "5040",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.219",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.166"
      },
      {
        "BLKpoint_id": "BLKpoint_276",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "5420",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.656",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.169"
      },
      {
        "BLKpoint_id": "BLKpoint_279",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "6030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.484",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_285",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "12660",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.292",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_286",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "3460",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.071",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_289",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "4270",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.269",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.181"
      },
      {
        "BLKpoint_id": "BLKpoint_292",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "4610",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.824",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.185"
      },
      {
        "BLKpoint_id": "BLKpoint_295",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "4890",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.58",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.168"
      },
      {
        "BLKpoint_id": "BLKpoint_296",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "4970",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.16",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.189"
      },
      {
        "BLKpoint_id": "BLKpoint_298",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "5230",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.59",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.18"
      },
      {
        "BLKpoint_id": "BLKpoint_302",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "5800",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.383",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_309",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "11990",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.221",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_310",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "3400",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.042",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_314",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4260",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.104",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.159"
      },
      {
        "BLKpoint_id": "BLKpoint_318",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4790",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.407",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.157"
      },
      {
        "BLKpoint_id": "BLKpoint_325",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "6060",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.165",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_331",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "12810",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.092",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_332",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "3240",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.053",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_335",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4240",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.155",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.16"
      },
      {
        "BLKpoint_id": "BLKpoint_340",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4950",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.531",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_345",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "5410",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.157",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_348",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "5720",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.278",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_363",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "15060",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.15",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_364",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "3100",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.087",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_368",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4280",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.31",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.167"
      },
      {
        "BLKpoint_id": "BLKpoint_373",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.016",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_375",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5360",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.473",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.158"
      },
      {
        "BLKpoint_id": "BLKpoint_378",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5830",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.681",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_388",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "8190",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.415",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_394",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "15040",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.332",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_395",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "3030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.087",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_398",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4180",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.287",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.156"
      },
      {
        "BLKpoint_id": "BLKpoint_403",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "5060",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.05",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.162"
      },
      {
        "BLKpoint_id": "BLKpoint_408",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "5420",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.605",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_411",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "5740",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.829",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.153"
      },
      {
        "BLKpoint_id": "BLKpoint_415",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "6850",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.563",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_418",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "8320",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.458",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_422",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "15180",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.371",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_423",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "3110",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.09",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_427",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4380",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.347",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.183"
      },
      {
        "BLKpoint_id": "BLKpoint_433",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.999",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.168"
      },
      {
        "BLKpoint_id": "BLKpoint_436",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5330",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.703",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.179"
      },
      {
        "BLKpoint_id": "BLKpoint_440",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5720",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.902",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_447",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "6500",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.629",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_452",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "7730",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.494",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_459",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "15070",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.375",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_460",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "2870",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.058",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_465",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "4260",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.255",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.158"
      },
      {
        "BLKpoint_id": "BLKpoint_470",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "5020",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.857",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.178"
      },
      {
        "BLKpoint_id": "BLKpoint_474",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "5390",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.693",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.165"
      },
      {
        "BLKpoint_id": "BLKpoint_476",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "5630",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.931",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.159"
      },
      {
        "BLKpoint_id": "BLKpoint_484",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "6530",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.589",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_489",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "7730",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.463",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_494",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "15040",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.339",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_495",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "3350",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.07",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_498",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4440",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.261",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.164"
      },
      {
        "BLKpoint_id": "BLKpoint_505",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "5640",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.873",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.155"
      },
      {
        "BLKpoint_id": "BLKpoint_510",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "6410",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.531",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_517",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "7900",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.38",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_523",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "15090",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.277",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_524",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "3290",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.001",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_528",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4810",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.115",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.158"
      },
      {
        "BLKpoint_id": "BLKpoint_534",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "5530",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.381",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_540",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "6140",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.206",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_547",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "7340",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.123",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_556",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "14930",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.053",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      }
    ],
    "inspection_id": "INSP_c0757cb3625b",
    "lit_num_id": "GLOBlit_4217"
  },
  {
    "doi": "10.1016/j.jct.2014.05.020",
    "block_number": "PROPblock_2",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "pressure_kpa",
      "mole_fraction_<benzene>",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.1189",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.318",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0148"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.2882",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6367",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0139"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.3955",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.744",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0134"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.4985",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7873",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.5976",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7631",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.6929",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6925",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0135"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.8293",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.4721",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0149"
      },
      {
        "BLKpoint_id": "BLKpoint_17",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.9162",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.257",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0158"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.1188",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2988",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0143"
      },
      {
        "BLKpoint_id": "BLKpoint_20",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.2879",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6265",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_22",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.3951",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7434",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0135"
      },
      {
        "BLKpoint_id": "BLKpoint_24",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.4981",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7882",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_26",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.5972",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7678",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_28",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.6926",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6849",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0136"
      },
      {
        "BLKpoint_id": "BLKpoint_30",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.7845",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5495",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0144"
      },
      {
        "BLKpoint_id": "BLKpoint_32",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.9161",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2455",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0152"
      },
      {
        "BLKpoint_id": "BLKpoint_33",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.1187",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3012",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0144"
      },
      {
        "BLKpoint_id": "BLKpoint_34",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.2325",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5383",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_35",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.3418",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.698",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0134"
      },
      {
        "BLKpoint_id": "BLKpoint_36",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.4469",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7722",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0131"
      },
      {
        "BLKpoint_id": "BLKpoint_37",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.5479",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7837",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.013"
      },
      {
        "BLKpoint_id": "BLKpoint_38",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.6451",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7321",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_40",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.7843",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5515",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0143"
      },
      {
        "BLKpoint_id": "BLKpoint_42",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.916",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2483",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0154"
      },
      {
        "BLKpoint_id": "BLKpoint_205",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.1191",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3207",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0143"
      },
      {
        "BLKpoint_id": "BLKpoint_206",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.2332",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5517",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0145"
      },
      {
        "BLKpoint_id": "BLKpoint_208",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.3426",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7003",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0134"
      },
      {
        "BLKpoint_id": "BLKpoint_210",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.4478",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7782",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0131"
      },
      {
        "BLKpoint_id": "BLKpoint_212",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.5488",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7863",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0131"
      },
      {
        "BLKpoint_id": "BLKpoint_214",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.6459",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7353",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_216",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.7394",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6282",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0139"
      },
      {
        "BLKpoint_id": "BLKpoint_219",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.9163",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2636",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.015"
      }
    ],
    "inspection_id": "INSP_4d898e6d2a1a",
    "lit_num_id": "GLOBlit_4181"
  }
]
```
