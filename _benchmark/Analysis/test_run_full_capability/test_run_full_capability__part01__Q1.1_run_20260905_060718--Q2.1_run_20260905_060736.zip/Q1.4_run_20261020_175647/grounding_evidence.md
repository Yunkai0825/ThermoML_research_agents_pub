# Data grounding evidence

- generated: 2026-10-20T18:07:01
- gate verdict: OK

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_2 | GLOBlit_4181 | yes | INSP_4d898e6d2a1a | 219 |

## Fit artifacts (grounded rail)

| fit_id | heading | blocks | values pooled |
|---|---|---|---|
| FIT_12b055ee3385 | **RK Fit** — GLOBlit_4181 / DOI 10.1016/j.jct.2014.05.020 / PROPblock_2 @ declared | PROPblock_2 | 32 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 219 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| 298.2 | PROPblock_2 | verified | — |
| 100 | PROPblock_2 | verified | — |
| 15 | PROPblock_2 | verified | — |
| 298.2 | PROPblock_2 | verified | — |
| 100 | PROPblock_2 | verified | — |
| 0.1191 | PROPblock_2 | verified | — |
| 0.9163 | PROPblock_2 | verified | — |
| 0.2636 | PROPblock_2 | verified | — |
| 0.7863 | PROPblock_2 | verified | — |
| 0.993163 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| 0.01337 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| -168.36 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| 0.00305 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| -184.30 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| 0.00164 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| -193.37 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| 0.00111 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| -195.76 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| 0.000933 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| -198.48 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| 0.000779 | PROPblock_2 | fit_artifact | FIT_12b055ee3385 |
| 0.999644 | PROPblock_2 | verified | — |
| 0.999897 | PROPblock_2 | verified | — |
| 0.999953 | PROPblock_2 | verified | — |
| 0.999967 | PROPblock_2 | verified | — |
| 0.999977 | PROPblock_2 | verified | — |
| 0.0131 | PROPblock_2 | verified | — |
| 0.0131 | PROPblock_2 | verified | — |
| 0.0150 | PROPblock_2 | verified | — |

## Inspections (verbatim)

### INSP_e8c97651c4fa — GLOBlit_4181::PROPblock_3 (rdp, 16 rows shown)

_structured envelope entry (no markdown)_

### INSP_c0757cb3625b — GLOBlit_4217::PROPblock_1 (rdp, 157 rows shown)

_structured envelope entry (no markdown)_

### INSP_4d898e6d2a1a — GLOBlit_4181::PROPblock_2 (rdp, 32 rows shown)

_structured envelope entry (no markdown)_
