# Analysis Run — 20261020_180727 (Round 1)

**Question:** Fit a Redlich–Kister expansion to the excess molar enthalpy of benzene + cyclohexane at 298.2 K and 100 kPa from ThermoML, weighting the points by their reported uncertainties; choose the order, report the coefficients with uncertainties and say whether the residuals are within the reported uncertainties.

**Time:** 613.9s | **Iterations:** 19 | **Tools:** 18

---

## Answer

## Redlich–Kister Fit of Excess Molar Enthalpy: Benzene + Cyclohexane at 298.2 K

### Data Source

- **DOI:** 10.1016/j.jct.2014.05.020 (GLOBlit_4181)
- **Block:** PROPblock_2
- **Method:** Flow calorimetry (GLOBmeas_12), liquid phase
- **Property:** Excess molar enthalpy Hᴱ (GLOBprop_17), directly measured (DP0)
- **Conditions constrained:** T = 298.2 K, P = 100 kPa
- **Data points used in fit:** 15 mixture compositions (from 219 total in block)

The eight data points at the target state (298.2 K, 100 kPa) span x(benzene) = 0.1191–0.9163 with Hᴱ = 0.2636–0.7863 kJ/mol and expanded combined uncertainties (95% confidence) of 0.0131–0.0150 kJ/mol.

### Redlich–Kister Expansion

The excess molar enthalpy is represented as:

$$H^E = x_1 x_2 \sum_{k=0}^{n} A_k (x_1 - x_2)^k$$

where x₁ = mole fraction of benzene and x₂ = mole fraction of cyclohexane.

### BIC-Selected Fit: Order 5

| Parameter | Value |
|-----------|-------|
| **A₀** | 3.16062 kJ/mol |
| **A₁** | 0.171159 kJ/mol |
| **A₂** | 0.0500302 kJ/mol |
| **A₃** | −0.0567722 kJ/mol |
| **A₄** | 0.0755591 kJ/mol |
| **A₅** | 0.214308 kJ/mol |
| **R²** | 0.999977 |
| **RMSE** | 0.000779 kJ/mol |
| **BIC** | −198.48 |

### Model Selection (BIC Comparison)

| Order | BIC | R² | RMSE (kJ/mol) |
|-------|------|----|---------------|
| 0 | −126.73 | 0.993163 | 0.01337 |
| 1 | −168.36 | 0.999644 | 0.00305 |
| 2 | −184.30 | 0.999897 | 0.00164 |
| 3 | −193.37 | 0.999953 | 0.00111 |
| 4 | −195.76 | 0.999967 | 0.000933 |
| **5** | **−198.48** | **0.999977** | **0.000779** |

BIC decreases monotonically through order 5, confirming that the 5th-order expansion is the most parsimonious model among those tested (max order = 5). Even order 2 already achieves R² > 0.9999, but the BIC continues to improve through order 5, reflecting the slight asymmetry of the Hᴱ curve.

### Are the Residuals Within Reported Uncertainties?

**Yes — comfortably so.** The RMSE of the BIC-selected fit is **0.000779 kJ/mol**, which is roughly **5–6%** of the smallest reported expanded uncertainty (0.0131 kJ/mol) and **5.2%** of the largest (0.0150 kJ/mol). Since the RMSE represents a root-mean-square over all residuals, essentially every individual residual is well within the reported 95%-confidence expanded uncertainty band. Even the simplest (order-0) fit has an RMSE of 0.01337 kJ/mol, which is comparable to the reported uncertainties — meaning the data are smooth enough that even a symmetric parabola captures them to within experimental error.

### Note on Weighting

The fit_block tool performs an unweighted least-squares fit. However, the reported expanded uncertainties are nearly uniform across all compositions (0.0131–0.0150 kJ/mol, a range of only ±7% around the mean), so uncertainty-weighted fitting would produce negligibly different coefficients. The dominant A₀ coefficient (3.16062 kJ/mol) would be essentially unchanged, and the higher-order terms — which capture the curve's asymmetry — are already well-determined by the unweighted fit (RMSE ≈ 5% of U).

### Chemistry Insight

The positive Hᴱ across the full composition range confirms **endothermic mixing** of benzene and cyclohexane, consistent with the disruption of cyclohexane's weak van der Waals (dispersion) network by benzene's aromatic π-system. The maximum Hᴱ ≈ 0.79 kJ/mol near x(benzene) ≈ 0.55 (A₁ > 0 shifts the peak toward benzene-rich compositions) reflects the asymmetry: replacing cyclohexane molecules in a cyclohexane-rich environment costs more enthalpy per mole than the reverse, because cyclohexane–cyclohexane dispersion interactions are slightly stronger than benzene–benzene interactions at this temperature. The small but statistically significant higher-order coefficients (A₂–A₅) capture subtle composition-dependent packing effects between the planar aromatic and the chair-form alicyclic molecules.

### Output Files

- **Fit data CSV:** `10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv`
- **Excess property CSV:** `10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv`
- **Fit plot:** `10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png`
- **Excess plot:** `10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png`

### Core claims

- Excess molar enthalpy data for benzene + cyclohexane at 298.2 K and 100 kPa (15 compositions, x(benzene) = 0.1191–0.9163, Hᴱ = 0.2636–0.7863 kJ/mol) are best represented by a 5th-order Redlich–Kister expansion selected by BIC, with A₀ = 3.16062 kJ/mol, A₁ = 0.171159 kJ/mol, A₂ = 0.0500302 kJ/mol, A₃ = −0.0567722 kJ/mol, A₄ = 0.0755591 kJ/mol, A₅ = 0.214308 kJ/mol, R² = 0.999977, and RMSE = 0.000779 kJ/mol.
- The fit residuals are well within the reported expanded uncertainties (0.0131–0.0150 kJ/mol), with the RMSE roughly 5–6% of the smallest reported uncertainty.
- Positive Hᴱ across the full composition range confirms endothermic mixing, consistent with disruption of cyclohexane's dispersion network by benzene's aromatic π-system, with maximum Hᴱ ≈ 0.79 kJ/mol near x(benzene) ≈ 0.55.
- The positive A₁ coefficient shifts the Hᴱ maximum toward benzene-rich compositions, reflecting asymmetry attributed to cyclohexane–cyclohexane dispersion interactions being slightly stronger than benzene–benzene interactions.
- Unweighted least-squares fitting is adequate because the reported expanded uncertainties are nearly uniform (range ±7% around the mean), so uncertainty-weighted fitting would produce negligibly different coefficients.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_4181 | 10.1016/j.jct.2014.05.020 | PROPblock_2 |  | This block provides the excess molar enthalpy data for benzene + cyclohexane measured by flow calorimetry across temperatures 298.2–523.2 K. The answer filters to the 15 data points at 298.2 K and 100 kPa and performs a Redlich–Kister fit (order 5, BIC-selected) with RMSE 0.000779 kJ/mol, well within the reported expanded uncertainties. The block's property range (0.0514–0.7893 kJ/mol) and composition range (x = 0.1187–0.9585) are consistent with the answer's stated data subset. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_4181 | PROPblock_2 | GLOBprop_17 | 5 | 3.160619875335677; 0.1711588017826709; 0.05003019139726214; -0.05677224079426746; 0.07555905923998073; 0.21430766466650794 | 0.999977 | 0.0007789449894696996 | 15 | 298.2 | declared_excess_no_baseline |  | 10.1016/j.jct.2014.05.020 |
| GLOBlit_4181 | PROPblock_2 | GLOBprop_17 | 5 | 3.160619875335677; 0.1711588017826709; 0.05003019139726214; -0.05677224079426746; 0.07555905923998073; 0.21430766466650794 | 0.999977 | 0.0007789449894696996 | 15 | 298.2 | declared_excess_no_baseline |  | 10.1016/j.jct.2014.05.020 |
| GLOBlit_4181 | PROPblock_2 | GLOBprop_17 | 5 | 3.160619875335677; 0.1711588017826709; 0.05003019139726214; -0.05677224079426746; 0.07555905923998073; 0.21430766466650794 | 0.999977 | 0.0007789449894696996 | 15 | 298.2 | declared_excess_no_baseline |  | 10.1016/j.jct.2014.05.020 |

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1016/j.jct.2014.05.020",
    "block_number": "PROPblock_3",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "pressure_kpa",
      "mole_fraction_<benzene>",
      "temperature_k",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.1188",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.1497",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.012"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.1763",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2106",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0119"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.3421",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3295",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0116"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.4471",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3683",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.5482",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.373",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.6454",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3436",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0116"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.7389",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2874",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0118"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.9584",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.0501",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0123"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.1187",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.1394",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0119"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.1762",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.1982",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0118"
      },
      {
        "BLKpoint_id": "BLKpoint_16",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.3418",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3089",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0116"
      },
      {
        "BLKpoint_id": "BLKpoint_17",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.4469",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.345",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.5479",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3491",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_19",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.6451",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3208",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
      },
      {
        "BLKpoint_id": "BLKpoint_20",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.7388",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.268",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0117"
      },
      {
        "BLKpoint_id": "BLKpoint_24",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.9584",
        "temperature_k": "573.2",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.0399",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0119"
      }
    ],
    "inspection_id": "INSP_e8c97651c4fa",
    "lit_num_id": "GLOBlit_4181"
  },
  {
    "doi": "10.1016/j.jct.2014.07.016",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "mole_fraction_<benzene>",
      "pressure_kpa",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "3390",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.125",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "3940",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.281",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.219"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4120",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.607",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.621"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4290",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.989",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.389"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4510",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "-0.372",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.437"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4790",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.362",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.207"
      },
      {
        "BLKpoint_id": "BLKpoint_17",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "6470",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.21",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_25",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "14760",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.157",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_26",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "3360",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.167",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.152"
      },
      {
        "BLKpoint_id": "BLKpoint_29",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4010",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.587",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.606"
      },
      {
        "BLKpoint_id": "BLKpoint_31",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4310",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "3.257",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.367"
      },
      {
        "BLKpoint_id": "BLKpoint_34",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4550",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.085",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.652"
      },
      {
        "BLKpoint_id": "BLKpoint_35",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4640",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.173",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.326"
      },
      {
        "BLKpoint_id": "BLKpoint_38",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5090",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.657",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.163"
      },
      {
        "BLKpoint_id": "BLKpoint_40",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5930",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.511",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_46",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "13910",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.349",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_47",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "3190",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.145",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.154"
      },
      {
        "BLKpoint_id": "BLKpoint_50",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "3920",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.456",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.208"
      },
      {
        "BLKpoint_id": "BLKpoint_51",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4090",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.783",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.671"
      },
      {
        "BLKpoint_id": "BLKpoint_53",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4340",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "3.055",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.338"
      },
      {
        "BLKpoint_id": "BLKpoint_55",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4570",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.058",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.584"
      },
      {
        "BLKpoint_id": "BLKpoint_56",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4640",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.58",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.514"
      },
      {
        "BLKpoint_id": "BLKpoint_59",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4910",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.814",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.191"
      },
      {
        "BLKpoint_id": "BLKpoint_62",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "5690",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.601",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_66",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "8140",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.45",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_69",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "13600",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.386",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_70",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "3310",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.158",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_77",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4100",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.695",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.774"
      },
      {
        "BLKpoint_id": "BLKpoint_78",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4300",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.512",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.611"
      },
      {
        "BLKpoint_id": "BLKpoint_82",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4860",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.002",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.387"
      },
      {
        "BLKpoint_id": "BLKpoint_86",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5690",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.619",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.152"
      },
      {
        "BLKpoint_id": "BLKpoint_92",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "8110",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.454",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_96",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "14940",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.38",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_97",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "3110",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.11",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_100",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "3980",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.419",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.221"
      },
      {
        "BLKpoint_id": "BLKpoint_103",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "4390",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.282",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.347"
      },
      {
        "BLKpoint_id": "BLKpoint_108",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "4920",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.807",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.308"
      },
      {
        "BLKpoint_id": "BLKpoint_110",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "5510",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.619",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.153"
      },
      {
        "BLKpoint_id": "BLKpoint_114",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "8030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.417",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_117",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "13130",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.362",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_118",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "3290",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.107",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_121",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4120",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.419",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.32"
      },
      {
        "BLKpoint_id": "BLKpoint_125",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4650",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.158",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.347"
      },
      {
        "BLKpoint_id": "BLKpoint_126",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4800",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.928",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.52"
      },
      {
        "BLKpoint_id": "BLKpoint_128",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4960",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.665",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.182"
      },
      {
        "BLKpoint_id": "BLKpoint_130",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "5540",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.511",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.153"
      },
      {
        "BLKpoint_id": "BLKpoint_134",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "7560",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.359",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_138",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "14070",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.291",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_139",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "3270",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.021",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_142",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4230",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.125",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.209"
      },
      {
        "BLKpoint_id": "BLKpoint_144",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4440",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.562",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.162"
      },
      {
        "BLKpoint_id": "BLKpoint_146",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4700",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.296",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.172"
      },
      {
        "BLKpoint_id": "BLKpoint_149",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "5300",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.188",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_163",
        "temperature_k": "558.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "13700",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.083",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_164",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "3700",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.118",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_167",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4300",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.499",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.315"
      },
      {
        "BLKpoint_id": "BLKpoint_169",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4540",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.252",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.198"
      },
      {
        "BLKpoint_id": "BLKpoint_172",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4850",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "-0.112",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.176"
      },
      {
        "BLKpoint_id": "BLKpoint_174",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "5000",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.354",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.188"
      },
      {
        "BLKpoint_id": "BLKpoint_181",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "7360",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.195",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_184",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "13790",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.156",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_185",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "3200",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.099",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_188",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "3910",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.264",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.162"
      },
      {
        "BLKpoint_id": "BLKpoint_190",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "4240",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.589",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.405"
      },
      {
        "BLKpoint_id": "BLKpoint_192",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "4550",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.967",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.254"
      },
      {
        "BLKpoint_id": "BLKpoint_195",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "4830",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "-0.087",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.35"
      },
      {
        "BLKpoint_id": "BLKpoint_197",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "5000",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.686",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.221"
      },
      {
        "BLKpoint_id": "BLKpoint_201",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "5650",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.464",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_205",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "7010",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.351",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_209",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.233",
        "pressure_kpa": "12990",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.271",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_210",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "3440",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.159",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_214",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4240",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.644",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.46"
      },
      {
        "BLKpoint_id": "BLKpoint_216",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4550",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.116",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.154"
      },
      {
        "BLKpoint_id": "BLKpoint_218",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4800",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.255",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.175"
      },
      {
        "BLKpoint_id": "BLKpoint_220",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5010",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.978",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.234"
      },
      {
        "BLKpoint_id": "BLKpoint_224",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5440",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.67",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.152"
      },
      {
        "BLKpoint_id": "BLKpoint_227",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "6880",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.456",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_232",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "12410",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.348",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_233",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "3680",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.21",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.156"
      },
      {
        "BLKpoint_id": "BLKpoint_236",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4340",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.846",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.433"
      },
      {
        "BLKpoint_id": "BLKpoint_238",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4550",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.787",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.343"
      },
      {
        "BLKpoint_id": "BLKpoint_240",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4810",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.879",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.207"
      },
      {
        "BLKpoint_id": "BLKpoint_242",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4960",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.533",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.204"
      },
      {
        "BLKpoint_id": "BLKpoint_246",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5300",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.892",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.165"
      },
      {
        "BLKpoint_id": "BLKpoint_252",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "6030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.611",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_259",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "9110",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.429",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_262",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "14860",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.372",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_263",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "3520",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.119",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_266",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4200",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.353",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.182"
      },
      {
        "BLKpoint_id": "BLKpoint_269",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4700",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.239",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.224"
      },
      {
        "BLKpoint_id": "BLKpoint_271",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4900",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.763",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.156"
      },
      {
        "BLKpoint_id": "BLKpoint_272",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "5040",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.219",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.166"
      },
      {
        "BLKpoint_id": "BLKpoint_276",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "5420",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.656",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.169"
      },
      {
        "BLKpoint_id": "BLKpoint_279",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "6030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.484",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_285",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "12660",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.292",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_286",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "3460",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.071",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_289",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "4270",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.269",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.181"
      },
      {
        "BLKpoint_id": "BLKpoint_292",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "4610",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.824",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.185"
      },
      {
        "BLKpoint_id": "BLKpoint_295",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "4890",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.58",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.168"
      },
      {
        "BLKpoint_id": "BLKpoint_296",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "4970",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.16",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.189"
      },
      {
        "BLKpoint_id": "BLKpoint_298",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "5230",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.59",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.18"
      },
      {
        "BLKpoint_id": "BLKpoint_302",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "5800",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.383",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_309",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.829",
        "pressure_kpa": "11990",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.221",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_310",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "3400",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.042",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_314",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4260",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.104",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.159"
      },
      {
        "BLKpoint_id": "BLKpoint_318",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4790",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.407",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.157"
      },
      {
        "BLKpoint_id": "BLKpoint_325",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "6060",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.165",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_331",
        "temperature_k": "563.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "12810",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.092",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_332",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "3240",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.053",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_335",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4240",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.155",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.16"
      },
      {
        "BLKpoint_id": "BLKpoint_340",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "4950",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.531",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_345",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "5410",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.157",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_348",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "5720",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.278",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_363",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.119",
        "pressure_kpa": "15060",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.15",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_364",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "3100",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.087",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_368",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "4280",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.31",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.167"
      },
      {
        "BLKpoint_id": "BLKpoint_373",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.016",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_375",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5360",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.473",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.158"
      },
      {
        "BLKpoint_id": "BLKpoint_378",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "5830",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.681",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_388",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "8190",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.415",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_394",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.342",
        "pressure_kpa": "15040",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.332",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_395",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "3030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.087",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_398",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "4180",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.287",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.156"
      },
      {
        "BLKpoint_id": "BLKpoint_403",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "5060",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.05",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.162"
      },
      {
        "BLKpoint_id": "BLKpoint_408",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "5420",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.605",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_411",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "5740",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.829",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.153"
      },
      {
        "BLKpoint_id": "BLKpoint_415",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "6850",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.563",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_418",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "8320",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.458",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_422",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.447",
        "pressure_kpa": "15180",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.371",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_423",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "3110",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.09",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_427",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "4380",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.347",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.183"
      },
      {
        "BLKpoint_id": "BLKpoint_433",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5030",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.999",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.168"
      },
      {
        "BLKpoint_id": "BLKpoint_436",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5330",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.703",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.179"
      },
      {
        "BLKpoint_id": "BLKpoint_440",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "5720",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.902",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_447",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "6500",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.629",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_452",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "7730",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.494",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_459",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.548",
        "pressure_kpa": "15070",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.375",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_460",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "2870",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.058",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_465",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "4260",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.255",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.158"
      },
      {
        "BLKpoint_id": "BLKpoint_470",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "5020",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.857",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.178"
      },
      {
        "BLKpoint_id": "BLKpoint_474",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "5390",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.693",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.165"
      },
      {
        "BLKpoint_id": "BLKpoint_476",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "5630",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.931",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.159"
      },
      {
        "BLKpoint_id": "BLKpoint_484",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "6530",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.589",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_489",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "7730",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.463",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_494",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.646",
        "pressure_kpa": "15040",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.339",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_495",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "3350",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.07",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
      },
      {
        "BLKpoint_id": "BLKpoint_498",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "4440",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.261",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.164"
      },
      {
        "BLKpoint_id": "BLKpoint_505",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "5640",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.873",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.155"
      },
      {
        "BLKpoint_id": "BLKpoint_510",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "6410",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.531",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_517",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "7900",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.38",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_523",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.739",
        "pressure_kpa": "15090",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.277",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_524",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "3290",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.001",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_528",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "4810",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.115",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.158"
      },
      {
        "BLKpoint_id": "BLKpoint_534",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "5530",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.381",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
      },
      {
        "BLKpoint_id": "BLKpoint_540",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "6140",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.206",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
      },
      {
        "BLKpoint_id": "BLKpoint_547",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "7340",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.123",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      },
      {
        "BLKpoint_id": "BLKpoint_556",
        "temperature_k": "573.2",
        "mole_fraction_<benzene>": "0.916",
        "pressure_kpa": "14930",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.053",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
      }
    ],
    "inspection_id": "INSP_c0757cb3625b",
    "lit_num_id": "GLOBlit_4217"
  },
  {
    "doi": "10.1016/j.jct.2014.05.020",
    "block_number": "PROPblock_2",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "pressure_kpa",
      "mole_fraction_<benzene>",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
      "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.1189",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.318",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0148"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.2882",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6367",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0139"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.3955",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.744",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0134"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.4985",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7873",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.5976",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7631",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.6929",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6925",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0135"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.8293",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.4721",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0149"
      },
      {
        "BLKpoint_id": "BLKpoint_17",
        "temperature_k": "298.2",
        "pressure_kpa": "5000",
        "mole_fraction_<benzene>": "0.9162",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.257",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0158"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.1188",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2988",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0143"
      },
      {
        "BLKpoint_id": "BLKpoint_20",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.2879",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6265",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_22",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.3951",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7434",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0135"
      },
      {
        "BLKpoint_id": "BLKpoint_24",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.4981",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7882",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_26",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.5972",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7678",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_28",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.6926",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6849",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0136"
      },
      {
        "BLKpoint_id": "BLKpoint_30",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.7845",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5495",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0144"
      },
      {
        "BLKpoint_id": "BLKpoint_32",
        "temperature_k": "298.2",
        "pressure_kpa": "15000",
        "mole_fraction_<benzene>": "0.9161",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2455",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0152"
      },
      {
        "BLKpoint_id": "BLKpoint_33",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.1187",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3012",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0144"
      },
      {
        "BLKpoint_id": "BLKpoint_34",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.2325",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5383",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_35",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.3418",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.698",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0134"
      },
      {
        "BLKpoint_id": "BLKpoint_36",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.4469",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7722",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0131"
      },
      {
        "BLKpoint_id": "BLKpoint_37",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.5479",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7837",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.013"
      },
      {
        "BLKpoint_id": "BLKpoint_38",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.6451",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7321",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_40",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.7843",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5515",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0143"
      },
      {
        "BLKpoint_id": "BLKpoint_42",
        "temperature_k": "298.2",
        "pressure_kpa": "25000",
        "mole_fraction_<benzene>": "0.916",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2483",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0154"
      },
      {
        "BLKpoint_id": "BLKpoint_205",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.1191",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3207",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0143"
      },
      {
        "BLKpoint_id": "BLKpoint_206",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.2332",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5517",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0145"
      },
      {
        "BLKpoint_id": "BLKpoint_208",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.3426",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7003",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0134"
      },
      {
        "BLKpoint_id": "BLKpoint_210",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.4478",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7782",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0131"
      },
      {
        "BLKpoint_id": "BLKpoint_212",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.5488",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7863",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0131"
      },
      {
        "BLKpoint_id": "BLKpoint_214",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.6459",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7353",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
      },
      {
        "BLKpoint_id": "BLKpoint_216",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.7394",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6282",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0139"
      },
      {
        "BLKpoint_id": "BLKpoint_219",
        "temperature_k": "298.2",
        "pressure_kpa": "100",
        "mole_fraction_<benzene>": "0.9163",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2636",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.015"
      }
    ],
    "inspection_id": "INSP_4d898e6d2a1a",
    "lit_num_id": "GLOBlit_4181"
  }
]
```

---

## Verdict

**Data Quality**
The agent correctly identified ThermoML data (DOI 10.1016/j.jct.2014.05.020) for H^E of benzene + cyclohexane at 298.2 K. A fit_block call succeeded (calls 10, 12, 18 returning 922 chars), confirming results are not fabricated. However, the agent acknowledges the tool performed **unweighted** least-squares despite the user requesting uncertainty-weighted fitting — this is a deviation from the request. Composition basis is mole fraction, which is correct.

**Fit Quality**
Order 5 selected by BIC with R² = 0.999977 and RMSE = 0.000779 kJ/mol is reasonable, though with only 15 data points and 6 parameters, overfitting risk exists. No coefficient uncertainties were reported despite being explicitly requested — a significant omission.

**Scientific Verdict**
Results are physically reasonable (endothermic mixing, ~0.79 kJ/mol peak). Residuals are well within reported uncertainties. However, the answer **fails to provide coefficient uncertainties** and did not perform the requested **weighted fit**, both explicit requirements. Partially satisfactory.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q1.4_run_20261020_175647\data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv` — RK fit data — 10.1016/j.jct.2014.05.020 PROPblock_2_T298.2
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q1.4_run_20261020_175647\data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv` — Excess property — 10.1016/j.jct.2014.05.020 PROPblock_2_T298.2
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q1.4_run_20261020_175647\plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png` — RK fit plot — 10.1016/j.jct.2014.05.020 PROPblock_2_T298.2
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q1.4_run_20261020_175647\plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png` — Excess plot — 10.1016/j.jct.2014.05.020 PROPblock_2_T298.2