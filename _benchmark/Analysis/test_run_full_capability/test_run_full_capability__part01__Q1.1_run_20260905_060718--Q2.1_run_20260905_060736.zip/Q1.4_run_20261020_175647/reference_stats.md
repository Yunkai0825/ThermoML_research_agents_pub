# Reference Stats — analysis-agent

**Run started:** 2026-10-20 17:56:47
**Wall time (at last flush):** 640.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 23 | 442,980 | 882,456 | 37,283 | 1,325,436 | 57,627 | 372.6 | claudeopus46 |
| L1-worker | 16 | 234,838 | 130,906 | 25,906 | 365,744 | 22,859 | 189.7 | claudeopus46 |
| **TOTAL** | **39** | **677,818** | **1,013,362** | **63,189** | **1,691,180** | **43,363** | **562.3** | |

**Estimated tokens:** ~422,795 input + ~15,797 output = ~438,592 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 0 | 1 | 1 | 219 |
| `search_blocks` | 2 | 1 | 3 | 2 | 3 | 5 | 925 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 3 | 1 | 2 | 3 | 0 |
| **TOTAL** | **8** | **3** | **9** | **3** | **6** | **9** | **1,144** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_14 |  | query_thermoml, resolve_compound_ids, search_blocks |
| GLOBcomp_13 |  | query_thermoml, resolve_compound_ids, search_blocks |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_4181 |  | query_thermoml, search_blocks |
| GLOBlit_4217 |  | query_thermoml, search_blocks |
| GLOBlit_5166 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | query_thermoml, search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | query_thermoml, search_blocks |

#### Phases (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml, search_blocks |
| GLOBphase_10 |  | query_thermoml, search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | query_thermoml, search_blocks |
| GLOBvar_3 | Pressure, kPa | query_thermoml, search_blocks |
| GLOBvar_2 | Mole fraction | query_thermoml, search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | query_thermoml, search_blocks |
| GLOBconstr_3 | Mole fraction | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 3 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Unique Phases | 2 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Unique Block_Types | 1 |
| Total DOIs | 3 |
| Unique parent blocks | 5 |
| Explicit block/subsystem targets | 5 |
| Subsystem targets | 0 |
| Target-matched data points | 1,943 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 5  |  **Explicit targets:** 5  |  **Subsystems:** 0  |  **Target-matched datapoints:** 925

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2014.05.020 | 2 | 243 | binary | query_thermoml, search_blocks |
| 10.1016/j.jct.2014.07.016 | 1 | 556 | binary | query_thermoml, search_blocks |
| 10.1016/j.jct.2018.01.001 | 2 | 126 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2014.05.020 | PROPblock_2 | declared | 219 | binary | 2 | query_thermoml, search_blocks |
| 10.1016/j.jct.2014.05.020 | PROPblock_3 | declared | 24 | binary | 2 | query_thermoml, search_blocks |
| 10.1016/j.jct.2014.07.016 | PROPblock_1 | declared | 556 | binary | 2 | query_thermoml, search_blocks |
| 10.1016/j.jct.2018.01.001 | PROPblock_1 | declared | 95 | binary | — | search_blocks |
| 10.1016/j.jct.2018.01.001 | PROPblock_2 | declared | 31 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | purpose=Find compound IDs for benzene…, queries=['… | 197 | KEEP ←in 299 | 197 | 4.3 |
| 2 | 3 | `search_blocks` | compound=['GLOBcomp_14', 'GLOBcomp_13'], limit=50,… | 1,097 | KEEP ←in 3,026 | 1067 | 22.1 |
| 3 | 4 | `search_blocks` | compound=['GLOBcomp_14', 'GLOBcomp_13'], limit=50,… | 770 | KEEP ←in 7,687 | 770 | 21.7 |
| 4 | 6 | `inspect_block_table` | block_number=GLOBlit_4181::PROPblock_2, purpose=Gr… | 493 | — | — | 0.1 |
| 5 | 6 | `inspect_block_table` | block_number=GLOBlit_4181::PROPblock_3, purpose=Gr… | 1,951 | — | — | 0.1 |
| 6 | 6 | `inspect_block_table` | block_number=GLOBlit_4217::PROPblock_1, purpose=Gr… | 9,724 | — | — | 0.2 |
| 7 | 7 | `inspect_block_table` | block_number=GLOBlit_4181::PROPblock_2, purpose=Gr… | 3,152 | — | — | 0.1 |
| 8 | 1 | `query_thermoml` | id_catalog=[{'type': 'prop', 'global_id'…, instruc… | 94,870 | — | — | 198.0 |
| 9 | 4 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2014.0… | 1,681 | — | — | 0.3 |
| 10 | 8 | `fit_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2014.0… | 352 | — | — | 0.1 |
| 11 | 10 | `fit_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2014.0… | 922 | — | — | 2.3 |
| 12 | 12 | `fit_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2014.0… | 922 | — | — | 1.9 |
| 13 | 16 | `propose_fitting_plan` | block_number=PROPblock_2, composition_hint=mole_fr… | 898 | — | — | 0.1 |
| 14 | 18 | `fit_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2014.0… | 922 | — | — | 2.3 |
| | | **TOTAL (14 tools)** | | **117,951** | | **2,034** | **253.6** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 22,897 | 476 | 23,373 | 973 | 7.4 |
| 2 | L1-worker | claudeopus46 | 24,140 | 999 | 25,139 | 635 | 5.1 |
| 3 | L1-worker | claudeopus46 | 3,767 | 463 | 4,230 | 332 | 3.7 |
| 4 | L1-worker | claudeopus46 | 24,140 | 1,627 | 25,767 | 835 | 5.7 |
| 5 | L1-worker | claudeopus46 | 24,140 | 2,361 | 26,501 | 705 | 4.7 |
| 6 | L1-worker | claudeopus46 | 3,767 | 3,536 | 7,303 | 1,515 | 13.2 |
| 7 | L1-worker | claudeopus46 | 24,140 | 3,634 | 27,774 | 1,513 | 9.9 |
| 8 | L1-worker | claudeopus46 | 3,767 | 8,136 | 11,903 | 1,667 | 13.6 |
| 9 | L1-worker | claudeopus46 | 24,140 | 5,008 | 29,148 | 2,066 | 12.8 |
| 10 | L1-worker | claudeopus46 | 24,140 | 10,869 | 35,009 | 1,159 | 8.8 |
| 11 | L1-worker | claudeopus46 | 24,140 | 12,606 | 36,746 | 944 | 7.5 |
| 12 | L1-worker | claudeopus46 | 24,140 | 16,345 | 40,485 | 4,403 | 32.3 |
| 13 | L1-worker | claudeopus46 | 24,140 | 25,112 | 49,252 | 5,956 | 42.1 |
| 14 | L1-worker | claudeopus46 | 2,320 | 3,584 | 5,904 | 911 | 6.5 |
| 15 | L1-worker | claudeopus46 | 627 | 3,464 | 4,091 | 1,014 | 7.4 |
| 16 | L1-worker | claudeopus46 | 2,543 | 4,704 | 7,247 | 1,487 | 8.0 |
| 17 | L1-worker | claudeopus46 | 787 | 28,458 | 29,245 | 764 | 8.4 |
| 18 | L0-main | claudeopus46 | 22,897 | 39,383 | 62,280 | 1,090 | 10.8 |
| 19 | L0-main | claudeopus46 | 22,897 | 40,101 | 62,998 | 506 | 5.8 |
| 20 | L0-main | claudeopus46 | 22,897 | 40,752 | 63,649 | 586 | 5.5 |
| 21 | L0-main | claudeopus46 | 22,897 | 42,867 | 65,764 | 1,164 | 10.0 |
| 22 | L0-main | claudeopus46 | 22,897 | 43,576 | 66,473 | 1,012 | 7.9 |
| 23 | L0-main | claudeopus46 | 22,897 | 44,225 | 67,122 | 960 | 7.3 |
| 24 | L0-main | claudeopus46 | 22,897 | 44,911 | 67,808 | 891 | 8.9 |
| 25 | L0-main | claudeopus46 | 22,897 | 44,962 | 67,859 | 1,087 | 8.7 |
| 26 | L0-main | claudeopus46 | 22,897 | 45,739 | 68,636 | 1,293 | 7.9 |
| 27 | L0-main | claudeopus46 | 22,897 | 48,798 | 71,695 | 3,762 | 26.7 |
| 28 | L0-main | claudeopus46 | 22,897 | 49,623 | 72,520 | 939 | 96.0 |
| 29 | L0-main | claudeopus46 | 22,897 | 51,424 | 74,321 | 2,374 | 17.0 |
| 30 | L0-main | claudeopus46 | 22,897 | 52,191 | 75,088 | 940 | 9.0 |
| 31 | L0-main | claudeopus46 | 22,897 | 52,858 | 75,755 | 914 | 8.4 |
| 32 | L0-main | claudeopus46 | 22,897 | 53,604 | 76,501 | 1,012 | 7.7 |
| 33 | L0-main | claudeopus46 | 22,897 | 54,070 | 76,967 | 4,933 | 35.0 |
| 34 | L0-main | claudeopus46 | 22,897 | 54,794 | 77,691 | 1,242 | 10.1 |
| 35 | L0-main | claudeopus46 | 22,897 | 56,586 | 79,483 | 8,432 | 55.2 |
| 36 | L0-main | claudeopus46 | 2,543 | 4,950 | 7,493 | 153 | 3.4 |
| 37 | L0-main | claudeopus46 | 2,320 | 4,340 | 6,660 | 1,309 | 9.3 |
| 38 | L0-main | claudeopus46 | 1,156 | 5,548 | 6,704 | 635 | 5.4 |
| 39 | L0-main | claudeopus46 | 1,918 | 6,678 | 8,596 | 1,076 | 9.2 |

