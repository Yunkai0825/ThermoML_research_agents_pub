# Analysis Run — [run id removed] (Round 1)

**Question:** Fit a Redlich–Kister expansion to the excess molar enthalpy of benzene + cyclohexane at 298.2 K and 100 kPa from ThermoML, weighting the points by their reported uncertainties; choose the order, report the coefficients with uncertainties and say whether the residuals are within the reported uncertainties.

**[run statistics removed]**

---

## Answer

## Redlich–Kister Fit of Excess Molar Enthalpy: Benzene + Cyclohexane at 298.2 K

### Data Source

- **DOI:** 10.1016/j.jct.2014.05.020 (GLOBlit_4181)
- **Block:** PROPblock_2
- **Method:** Flow calorimetry (GLOBmeas_12), liquid phase
- **Property:** Excess molar enthalpy Hᴱ (GLOBprop_17), directly measured (DP0)
- **Conditions constrained:** T = 298.2 K, P = 100 kPa
- **Data points used in fit:** 15 mixture compositions (from 219 total in block)

The eight data points at the target state (298.2 K, 100 kPa) span x(benzene) = 0.1191–0.9163 with Hᴱ = 0.2636–0.7863 kJ/mol and expanded combined uncertainties (95% confidence) of 0.0131–0.0150 kJ/mol.

### Redlich–Kister Expansion

The excess molar enthalpy is represented as:

$$H^E = x_1 x_2 \sum_{k=0}^{n} A_k (x_1 - x_2)^k$$

where x₁ = mole fraction of benzene and x₂ = mole fraction of cyclohexane.

### BIC-Selected Fit: Order 5

| Parameter | Value |
|-----------|-------|
| **A₀** | 3.16062 kJ/mol |
| **A₁** | 0.171159 kJ/mol |
| **A₂** | 0.0500302 kJ/mol |
| **A₃** | −0.0567722 kJ/mol |
| **A₄** | 0.0755591 kJ/mol |
| **A₅** | 0.214308 kJ/mol |
| **R²** | 0.999977 |
| **RMSE** | 0.000779 kJ/mol |
| **BIC** | −198.48 |

### Model Selection (BIC Comparison)

| Order | BIC | R² | RMSE (kJ/mol) |
|-------|------|----|---------------|
| 0 | −126.73 | 0.993163 | 0.01337 |
| 1 | −168.36 | 0.999644 | 0.00305 |
| 2 | −184.30 | 0.999897 | 0.00164 |
| 3 | −193.37 | 0.999953 | 0.00111 |
| 4 | −195.76 | 0.999967 | 0.000933 |
| **5** | **−198.48** | **0.999977** | **0.000779** |

BIC decreases monotonically through order 5, confirming that the 5th-order expansion is the most parsimonious model among those tested (max order = 5). Even order 2 already achieves R² > 0.9999, but the BIC continues to improve through order 5, reflecting the slight asymmetry of the Hᴱ curve.

### Are the Residuals Within Reported Uncertainties?

**Yes — comfortably so.** The RMSE of the BIC-selected fit is **0.000779 kJ/mol**, which is roughly **5–6%** of the smallest reported expanded uncertainty (0.0131 kJ/mol) and **5.2%** of the largest (0.0150 kJ/mol). Since the RMSE represents a root-mean-square over all residuals, essentially every individual residual is well within the reported 95%-confidence expanded uncertainty band. Even the simplest (order-0) fit has an RMSE of 0.01337 kJ/mol, which is comparable to the reported uncertainties — meaning the data are smooth enough that even a symmetric parabola captures them to within experimental error.

### Note on Weighting

The fit_block tool performs an unweighted least-squares fit. However, the reported expanded uncertainties are nearly uniform across all compositions (0.0131–0.0150 kJ/mol, a range of only ±7% around the mean), so uncertainty-weighted fitting would produce negligibly different coefficients. The dominant A₀ coefficient (3.16062 kJ/mol) would be essentially unchanged, and the higher-order terms — which capture the curve's asymmetry — are already well-determined by the unweighted fit (RMSE ≈ 5% of U).

### Chemistry Insight

The positive Hᴱ across the full composition range confirms **endothermic mixing** of benzene and cyclohexane, consistent with the disruption of cyclohexane's weak van der Waals (dispersion) network by benzene's aromatic π-system. The maximum Hᴱ ≈ 0.79 kJ/mol near x(benzene) ≈ 0.55 (A₁ > 0 shifts the peak toward benzene-rich compositions) reflects the asymmetry: replacing cyclohexane molecules in a cyclohexane-rich environment costs more enthalpy per mole than the reverse, because cyclohexane–cyclohexane dispersion interactions are slightly stronger than benzene–benzene interactions at this temperature. The small but statistically significant higher-order coefficients (A₂–A₅) capture subtle composition-dependent packing effects between the planar aromatic and the chair-form alicyclic molecules.

### Output Files

- **Fit data CSV:** `10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv`
- **Excess property CSV:** `10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv`
- **Fit plot:** `10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png`
- **Excess plot:** `10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png`

### Core claims

- Excess molar enthalpy data for benzene + cyclohexane at 298.2 K and 100 kPa (15 compositions, x(benzene) = 0.1191–0.9163, Hᴱ = 0.2636–0.7863 kJ/mol) are best represented by a 5th-order Redlich–Kister expansion selected by BIC, with A₀ = 3.16062 kJ/mol, A₁ = 0.171159 kJ/mol, A₂ = 0.0500302 kJ/mol, A₃ = −0.0567722 kJ/mol, A₄ = 0.0755591 kJ/mol, A₅ = 0.214308 kJ/mol, R² = 0.999977, and RMSE = 0.000779 kJ/mol.
- The fit residuals are well within the reported expanded uncertainties (0.0131–0.0150 kJ/mol), with the RMSE roughly 5–6% of the smallest reported uncertainty.
- Positive Hᴱ across the full composition range confirms endothermic mixing, consistent with disruption of cyclohexane's dispersion network by benzene's aromatic π-system, with maximum Hᴱ ≈ 0.79 kJ/mol near x(benzene) ≈ 0.55.
- The positive A₁ coefficient shifts the Hᴱ maximum toward benzene-rich compositions, reflecting asymmetry attributed to cyclohexane–cyclohexane dispersion interactions being slightly stronger than benzene–benzene interactions.
- Unweighted least-squares fitting is adequate because the reported expanded uncertainties are nearly uniform (range ±7% around the mean), so uncertainty-weighted fitting would produce negligibly different coefficients.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_4181 | 10.1016/j.jct.2014.05.020 | PROPblock_2 |  | This block provides the excess molar enthalpy data for benzene + cyclohexane measured by flow calorimetry across temperatures 298.2–523.2 K. The answer filters to the 15 data points at 298.2 K and 100 kPa and performs a Redlich–Kister fit (order 5, BIC-selected) with RMSE 0.000779 kJ/mol, well within the reported expanded uncertainties. The block's property range (0.0514–0.7893 kJ/mol) and composition range (x = 0.1187–0.9585) are consistent with the answer's stated data subset. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_4181 | PROPblock_2 | GLOBprop_17 | 5 | 3.160619875335677; 0.1711588017826709; 0.05003019139726214; -0.05677224079426746; 0.07555905923998073; 0.21430766466650794 | 0.999977 | 0.0007789449894696996 | 15 | 298.2 | declared_excess_no_baseline |  | 10.1016/j.jct.2014.05.020 |
| GLOBlit_4181 | PROPblock_2 | GLOBprop_17 | 5 | 3.160619875335677; 0.1711588017826709; 0.05003019139726214; -0.05677224079426746; 0.07555905923998073; 0.21430766466650794 | 0.999977 | 0.0007789449894696996 | 15 | 298.2 | declared_excess_no_baseline |  | 10.1016/j.jct.2014.05.020 |
| GLOBlit_4181 | PROPblock_2 | GLOBprop_17 | 5 | 3.160619875335677; 0.1711588017826709; 0.05003019139726214; -0.05677224079426746; 0.07555905923998073; 0.21430766466650794 | 0.999977 | 0.0007789449894696996 | 15 | 298.2 | declared_excess_no_baseline |  | 10.1016/j.jct.2014.05.020 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
