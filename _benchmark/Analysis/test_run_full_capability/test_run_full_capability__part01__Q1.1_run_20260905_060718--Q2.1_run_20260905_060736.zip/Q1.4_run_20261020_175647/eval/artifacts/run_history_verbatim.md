# Tool History — analysis-agent

**Nest:** A
**Session:** 674ad86a
**Detailed log:** run_history_detailed.md — Argo events + verbatim agent outputs (join: session id; step tag `cN` ↔ event-row `cN`)
**Prompt:** Fit a Redlich–Kister expansion to the excess molar enthalpy of benzene + cyclohexane at 298.2 K and 100 kPa from ThermoML, weighting the points by their reported uncertainties; choose the order, report the coefficients with uncertainties and say whether the residuals are within the reported uncertainties.
**Started:** 2026-10-20 17:56:47  |  **Elapsed:** 640.6s  |  **Tool calls:** 25  |  **Nested sections:** 1

---

### Step 1 [A · c8]: `query_thermoml`

<details><summary>Arguments</summary>

```json
{
  "purpose": "Find excess molar enthalpy (Hᴱ) data blocks for benzene + cyclohexane at approximately 298.2 K and 100 kPa",
  "instruction": "Search for binary mixture blocks containing benzene and cyclohexane with excess molar enthalpy (GLOBprop_17). Filter for temperature near 298.2 K. Return DOIs, block numbers, temperature ranges, pressure, number of data points, and composition ranges.",
  "id_catalog": [
    {
      "type": "prop",
      "global_id": "GLOBprop_17",
      "registry_id": "GLOBprop_17",
      "name": "Excess molar enthalpy"
    }
  ]
}
```
</details>

- **Result:** 94,870 chars  |  **Time:** 198.0s  |  **Started:** 17:56:55 (t+7.6s)
- **Nested:** ↳ 7 tool calls in section 'L1_1' below

<details><summary>Result</summary>

```
[TOOL_RESULT_SIZE_WARNING: query_thermoml returned 94,624 characters after result processing; the target is 24,000. The full result follows — prefer narrower requests, and rely on your working memory for recall instead of re-running this call.]

<subagent_answer>
{
  "answer": "## Excess Molar Enthalpy (H\u1d31) Data for Benzene + Cyclohexane at ~298.2 K and ~100 kPa\n\n### Key Finding\n\nThe ThermoML database **does** contain excess molar enthalpy data for benzene (GLOBcomp_14) + cyclohexane (GLOBcomp_13) at 298.2 K and 100 kPa, within block **GLOBlit_4181::PROPblock_2** (DOI: 10.1016/j.jct.2014.05.020).\n\n### Block Overview (GLOBlit_4181::PROPblock_2)\n\n| Field | Value |\n|---|---|\n| DOI | 10.1016/j.jct.2014.05.020 [GLOBlit_4181] |\n| Block | PROPblock_2 |\n| Property | GLOBprop_17 \u2014 Excess molar enthalpy (kJ/mol) |\n| Method | GLOBmeas_12 \u2014 flow calorimetry |\n| Phase | Liquid |\n| Total points | 219 |\n| T range | 298.2\u2013523.2 K |\n| P range | 100\u201325000 kPa |\n| x(benzene) range | 0.1187\u20130.9585 |\n\nAt T = 298.2 K, there are 57 data points across four pressures (100, 5000, 15000, and 25000 kPa).\n\n### Data at 298.2 K and 100 kPa (target conditions) \u2014 from GLOBlit_4181::PROPblock_2\n\n| x(benzene) | H\u1d31 (kJ/mol) | \u00b1U (kJ/mol) |\n|------------|-------------|-------------|\n| 0.1191 | 0.3207 | 0.0143 |\n| 0.2332 | 0.5517 | 0.0145 |\n| 0.3426 | 0.7003 | 0.0134 |\n| 0.4478 | 0.7782 | 0.0131 |\n| 0.5488 | 0.7863 | 0.0131 |\n| 0.6459 | 0.7353 | 0.0133 |\n| 0.7394 | 0.6282 | 0.0139 |\n| 0.9163 | 0.2636 | 0.0150 |\n\nUncertainties are expanded combined (U) at 95% confidence level.\n\n### Data at 298.2 K and 5000 kPa \u2014 from GLOBlit_4181::PROPblock_2\n\n| x(benzene) | H\u1d31 (kJ/mol) | \u00b1U (kJ/mol) |\n|------------|-------------|-------------|\n| 0.1189 | 0.318 | 0.0148 |\n| 0.2882 | 0.6367 | 0.0139 |\n| 0.3955 | 0.744 | 0.0134 |\n| 0.4985 | 0.7873 | 0.0133 |\n| 0.5976 | 0.7631 | 0.0133 |\n| 0.6929 | 0.6925 | 0.0135 |\n| 0.8293 | 0.4721 | 0.0149 |\n| 0.9162 | 0.257 | 0.0158 |\n\n### Other Blocks (not near target conditions)\n\n| # | DOI | Block | lit_id | T (K) | P range (kPa) | Phase |\n|---|-----|-------|--------|-------|---------------|-------|\n| 2 | 10.1016/j.jct.2014.05.020 | PROPblock_3 | GLOBlit_4181 | 573.2 (fixed) | 15000\u201325000 | Fluid |\n| 3 | 10.1016/j.jct.2014.07.016 | PROPblock_1 | GLOBlit_4217 | 558.2 | up to 14760 | Fluid |\n\nThese blocks are at much higher temperatures and are not relevant to the 298.2 K target. The lower pressure bound for GLOBlit_4217::PROPblock_1 was not verified in this run.\n\n### Chemistry Insight (based on GLOBlit_4181::PROPblock_2 data)\n\nThe H\u1d31 values are positive (endothermic mixing) across the entire composition range, with a maximum near x(benzene) \u2248 0.55 (approximate, based on the inspected rows above) where H\u1d31 reaches 0.7863 kJ/mol at 100 kPa. The slightly asymmetric curve (maximum shifted toward benzene-rich compositions) reflects the disruption of cyclohexane's weak dispersion network by benzene's aromatic \u03c0-system. Comparing the 100 kPa and 5000 kPa data from GLOBlit_4181::PROPblock_2 at 298.2 K, the H\u1d31 values are very similar (e.g., 0.7863 vs. 0.7873 kJ/mol near equimolar), indicating minimal pressure dependence of the excess enthalpy in the liquid phase at this temperature.\n\n---\n[UNGROUNDED DATA FLAGS] The following quoted values could not be verified against any verbatim data inspection in this run and must be treated as UNVERIFIED:\n- **MISATTRIBUTED_VALUE** PROPblock_1: 298.2 does not belong to PROPblock_1; it matches only GLOBlit_4181::PROPblock_2 (inspected this run)\n  fix (required \u2014 this IS a database value, under a different block): `re-anchor 298.2 to GLOBlit_4181::PROPblock_2 \u2014 no new tool call needed`\nInspected so far: PROPblock_1, PROPblock_2, PROPblock_3",
  "core_claims": [
    "The ThermoML database contains excess molar enthalpy (H\u1d31) data for benzene + cyclohexane at 298.2 K and 100 kPa in block GLOBlit_4181::PROPblock_2 (DOI: 10.1016/j.jct.2014.05.020), measured by flow calorimetry in the liquid phase.",
    "At 298.2 K and 100 kPa, H\u1d31 is positive (endothermic mixing) across the entire composition range, with values ranging from 0.2636 kJ/mol at x(benzene) = 0.9163 to 0.7863 kJ/mol at x(benzene) = 0.5488, with expanded combined uncertainties (95% confidence) of approximately 0.013\u20130.015 kJ/mol.",
    "The H\u1d31 maximum occurs near x(benzene) \u2248 0.55, indicating a slightly asymmetric curve shifted toward benzene-rich compositions.",
    "Comparing 100 kPa and 5000 kPa data at 298.2 K near equimolar composition (0.7863 vs. 0.7873 kJ/mol), the excess enthalpy shows minimal pressure dependence in the liquid phase at this temperature."
  ],
  "status": "success",
  "summary": "The ThermoML database contains excess molar enthalpy (H\u1d31) data for benzene + cyclohexane at 298.2 K and 100 kPa in block GLOBlit_4181::PROPblock_2 (DOI: 10.1016/j.jct.2014.05.020), measured by flow calorimetry. Eight data points at these conditions span x(benzene) from 0.1191 to 0.9163, with H\u1d31 values (kJ/mol): 0.3207, 0.5517, 0.7003, 0.7782, 0.7863, 0.7353, 0.6282, and 0.2636, respectively, with expanded uncertainties (95% confidence) ranging from 0.0131 to 0.0150 kJ/mol. Mixing is endothermic across the entire composition range, with a maximum H\u1d31 of 0.7863 kJ/mol near x(benzene) \u2248 0.55. The full block contains 219 points spanning 298.2\u2013523.2 K and 100\u201325000 kPa. Comparison of 100 kPa and 5000 kPa data at 298.2 K shows minimal pressure dependence of H\u1d31 in the liquid phase (e.g., 0.7863 vs. 0.7873 kJ/mol near equimolar). The slight asymmetry of the curve toward benzene-rich compositions reflects disruption of cyclohexane's dispersion network by benzene's aromatic \u03c0-system.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_14",
      "registry_id": "benzene",
      "name": "benzene"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_13",
      "registry_id": "cyclohexane",
      "name": "cyclohexane"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_4181",
      "block_number": "PROPblock_2",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_13"
      ],
      "prop_num_ids": [
        "GLOBprop_17"
      ],
      "description": "Excess molar enthalpy data for benzene + cyclohexane covering 298.2\u2013523.2 K and 100\u201325000 kPa with 219 data points; the primary source for H\u1d31 at the target conditions of 298.2 K and 100 kPa.",
      "doi": "10.1016/j.jct.2014.05.020",
      "lit_id": "2014-fan-tsu-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 219,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": "c1ccccc1",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_13",
          "name": "cyclohexane",
          "formula": "C6H12",
          "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
          "SMILES": "C1CCCCC1",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.2,
            "max": 523.2,
            "n_unique": 6
          },
          "range_min": 298.2,
          "range_max": 523.2
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 100.0,
            "max": 25000.0,
            "n_unique": 4
          },
          "range_min": 100.0,
          "range_max": 25000.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Mole fraction",
            "min": 0.1187,
            "max": 0.9585,
            "n_unique": 63
          },
          "range_min": 0.1187,
          "range_max": 0.9585
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_17",
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_12",
          "meas_ID": "flow_calorimetry",
          "method_standard": "Flow calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "min": 0.0514,
            "max": 0.7893,
            "mean": 0.40095,
            "std": 0.199867,
            "n": 219
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0514,
          "range_max": 0.7893
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": "c1ccccc1",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_13",
          "name": "cyclohexane",
          "formula": "C6H12",
          "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
          "SMILES": "C1CCCCC1",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 219,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_4181",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_13"
      ],
      "prop_num_ids": [
        "GLOBprop_17"
      ],
      "description": "Excess molar enthalpy data for benzene + cyclohexane at 573.2 K and 15000\u201325000 kPa; noted as not relevant to the 298.2 K target.",
      "doi": "10.1016/j.jct.2014.05.020",
      "lit_id": "2014-fan-tsu-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 24,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": "c1ccccc1",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_13",
          "name": "cyclohexane",
          "formula": "C6H12",
          "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
          "SMILES": "C1CCCCC1",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 573.2,
          "digits": 4,
          "component_org_num": null,
          "phase": {
            "phase": "Fluid (supercritical or subcritical phases)",
            "phase_num_id": "GLOBphase_10",
            "phase_id": "fluid_supercritical_or_subcritical_phases"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Fluid (supercritical or subcritical phases)",
            "phase_num_id": "GLOBphase_10",
            "phase_id": "fluid_supercritical_or_subcritical_phases"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Pressure, kPa",
            "min": 15000.0,
            "max": 25000.0,
            "n_unique": 2
          },
          "range_min": 15000.0,
          "range_max": 25000.0
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Fluid (supercritical or subcritical phases)",
            "phase_num_id": "GLOBphase_10",
            "phase_id": "fluid_supercritical_or_subcritical_phases"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.1187,
            "max": 0.9584,
            "n_unique": 23
          },
          "range_min": 0.1187,
          "range_max": 0.9584
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_17",
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_12",
          "meas_ID": "flow_calorimetry",
          "method_standard": "Flow calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "min": 0.0399,
            "max": 0.373,
            "mean": 0.22705,
            "std": 0.103854,
            "n": 24
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0399,
          "range_max": 0.373
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": "c1ccccc1",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_13",
          "name": "cyclohexane",
          "formula": "C6H12",
          "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
          "SMILES": "C1CCCCC1",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 24,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_4217",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_13"
      ],
      "prop_num_ids": [
        "GLOBprop_17"
      ],
      "description": "Excess molar enthalpy data for benzene + cyclohexane at 558.2 K; noted as not relevant to the 298.2 K target.",
      "doi": "10.1016/j.jct.2014.07.016",
      "lit_id": "2014-fan-tsu-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 556,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": "c1ccccc1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_13",
          "name": "cyclohexane",
          "formula": "C6H12",
          "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
          "SMILES": "C1CCCCC1",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Fluid (supercritical or subcritical phases)",
            "phase_num_id": "GLOBphase_10",
            "phase_id": "fluid_supercritical_or_subcritical_phases"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 558.2,
            "max": 573.2,
            "n_unique": 3
          },
          "range_min": 558.2,
          "range_max": 573.2
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Fluid (supercritical or subcritical phases)",
            "phase_num_id": "GLOBphase_10",
            "phase_id": "fluid_supercritical_or_subcritical_phases"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.119,
            "max": 0.916,
            "n_unique": 9
          },
          "range_min": 0.119,
          "range_max": 0.916
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Fluid (supercritical or subcritical phases)",
            "phase_num_id": "GLOBphase_10",
            "phase_id": "fluid_supercritical_or_subcritical_phases"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Pressure, kPa",
            "min": 2870.0,
            "max": 15180.0,
            "n_unique": 355
          },
          "range_min": 2870.0,
          "range_max": 15180.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_17",
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_12",
          "meas_ID": "flow_calorimetry",
          "method_standard": "Flow calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "min": -0.372,
            "max": 3.257,
            "mean": 0.512282,
            "std": 0.44786,
            "n": 556
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": -0.372,
          "range_max": 3.257
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": "c1ccccc1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_13",
          "name": "cyclohexane",
          "formula": "C6H12",
          "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
          "SMILES": "C1CCCCC1",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 556,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ],
  "data_inspections": [
    {
      "doi": "10.1016/j.jct.2014.05.020",
      "block_number": "PROPblock_3",
      "table_mode": "rdp",
      "columns": [
        "BLKpoint_id",
        "pressure_kpa",
        "mole_fraction_<benzene>",
        "temperature_k",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U"
      ],
      "rows_shown": [
        {
          "BLKpoint_id": "BLKpoint_1",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.1188",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.1497",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.012"
        },
        {
          "BLKpoint_id": "BLKpoint_2",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.1763",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2106",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0119"
        },
        {
          "BLKpoint_id": "BLKpoint_4",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.3421",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3295",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0116"
        },
        {
          "BLKpoint_id": "BLKpoint_5",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.4471",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3683",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
        },
        {
          "BLKpoint_id": "BLKpoint_6",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.5482",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.373",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
        },
        {
          "BLKpoint_id": "BLKpoint_7",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.6454",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3436",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0116"
        },
        {
          "BLKpoint_id": "BLKpoint_8",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.7389",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2874",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0118"
        },
        {
          "BLKpoint_id": "BLKpoint_12",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.9584",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.0501",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0123"
        },
        {
          "BLKpoint_id": "BLKpoint_13",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.1187",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.1394",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0119"
        },
        {
          "BLKpoint_id": "BLKpoint_14",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.1762",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.1982",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0118"
        },
        {
          "BLKpoint_id": "BLKpoint_16",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.3418",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3089",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0116"
        },
        {
          "BLKpoint_id": "BLKpoint_17",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.4469",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.345",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
        },
        {
          "BLKpoint_id": "BLKpoint_18",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.5479",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3491",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
        },
        {
          "BLKpoint_id": "BLKpoint_19",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.6451",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3208",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0115"
        },
        {
          "BLKpoint_id": "BLKpoint_20",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.7388",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.268",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0117"
        },
        {
          "BLKpoint_id": "BLKpoint_24",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.9584",
          "temperature_k": "573.2",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.0399",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0119"
        }
      ],
      "inspection_id": "INSP_e8c97651c4fa",
      "lit_num_id": "GLOBlit_4181"
    },
    {
      "doi": "10.1016/j.jct.2014.07.016",
      "block_number": "PROPblock_1",
      "table_mode": "rdp",
      "columns": [
        "BLKpoint_id",
        "temperature_k",
        "mole_fraction_<benzene>",
        "pressure_kpa",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U"
      ],
      "rows_shown": [
        {
          "BLKpoint_id": "BLKpoint_1",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "3390",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.125",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_4",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "3940",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.281",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.219"
        },
        {
          "BLKpoint_id": "BLKpoint_5",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "4120",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.607",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.621"
        },
        {
          "BLKpoint_id": "BLKpoint_6",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "4290",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.989",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.389"
        },
        {
          "BLKpoint_id": "BLKpoint_8",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "4510",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "-0.372",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.437"
        },
        {
          "BLKpoint_id": "BLKpoint_10",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "4790",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.362",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.207"
        },
        {
          "BLKpoint_id": "BLKpoint_17",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "6470",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.21",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_25",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "14760",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.157",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_26",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "3360",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.167",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.152"
        },
        {
          "BLKpoint_id": "BLKpoint_29",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "4010",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.587",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.606"
        },
        {
          "BLKpoint_id": "BLKpoint_31",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "4310",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "3.257",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.367"
        },
        {
          "BLKpoint_id": "BLKpoint_34",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "4550",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.085",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.652"
        },
        {
          "BLKpoint_id": "BLKpoint_35",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "4640",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.173",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.326"
        },
        {
          "BLKpoint_id": "BLKpoint_38",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "5090",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.657",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.163"
        },
        {
          "BLKpoint_id": "BLKpoint_40",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "5930",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.511",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_46",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "13910",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.349",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_47",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "3190",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.145",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.154"
        },
        {
          "BLKpoint_id": "BLKpoint_50",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "3920",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.456",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.208"
        },
        {
          "BLKpoint_id": "BLKpoint_51",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "4090",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.783",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.671"
        },
        {
          "BLKpoint_id": "BLKpoint_53",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "4340",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "3.055",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.338"
        },
        {
          "BLKpoint_id": "BLKpoint_55",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "4570",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.058",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.584"
        },
        {
          "BLKpoint_id": "BLKpoint_56",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "4640",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.58",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.514"
        },
        {
          "BLKpoint_id": "BLKpoint_59",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "4910",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.814",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.191"
        },
        {
          "BLKpoint_id": "BLKpoint_62",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "5690",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.601",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
        },
        {
          "BLKpoint_id": "BLKpoint_66",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "8140",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.45",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_69",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "13600",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.386",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_70",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "3310",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.158",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
        },
        {
          "BLKpoint_id": "BLKpoint_77",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "4100",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.695",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.774"
        },
        {
          "BLKpoint_id": "BLKpoint_78",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "4300",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.512",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.611"
        },
        {
          "BLKpoint_id": "BLKpoint_82",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "4860",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.002",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.387"
        },
        {
          "BLKpoint_id": "BLKpoint_86",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "5690",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.619",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.152"
        },
        {
          "BLKpoint_id": "BLKpoint_92",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "8110",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.454",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_96",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "14940",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.38",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_97",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "3110",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.11",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
        },
        {
          "BLKpoint_id": "BLKpoint_100",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "3980",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.419",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.221"
        },
        {
          "BLKpoint_id": "BLKpoint_103",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "4390",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.282",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.347"
        },
        {
          "BLKpoint_id": "BLKpoint_108",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "4920",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.807",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.308"
        },
        {
          "BLKpoint_id": "BLKpoint_110",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "5510",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.619",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.153"
        },
        {
          "BLKpoint_id": "BLKpoint_114",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "8030",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.417",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_117",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "13130",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.362",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_118",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "3290",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.107",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_121",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "4120",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.419",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.32"
        },
        {
          "BLKpoint_id": "BLKpoint_125",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "4650",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.158",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.347"
        },
        {
          "BLKpoint_id": "BLKpoint_126",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "4800",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.928",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.52"
        },
        {
          "BLKpoint_id": "BLKpoint_128",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "4960",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.665",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.182"
        },
        {
          "BLKpoint_id": "BLKpoint_130",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "5540",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.511",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.153"
        },
        {
          "BLKpoint_id": "BLKpoint_134",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "7560",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.359",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_138",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "14070",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.291",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_139",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "3270",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.021",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_142",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "4230",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.125",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.209"
        },
        {
          "BLKpoint_id": "BLKpoint_144",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "4440",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.562",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.162"
        },
        {
          "BLKpoint_id": "BLKpoint_146",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "4700",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.296",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.172"
        },
        {
          "BLKpoint_id": "BLKpoint_149",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "5300",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.188",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_163",
          "temperature_k": "558.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "13700",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.083",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_164",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "3700",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.118",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_167",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "4300",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.499",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.315"
        },
        {
          "BLKpoint_id": "BLKpoint_169",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "4540",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.252",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.198"
        },
        {
          "BLKpoint_id": "BLKpoint_172",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "4850",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "-0.112",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.176"
        },
        {
          "BLKpoint_id": "BLKpoint_174",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "5000",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.354",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.188"
        },
        {
          "BLKpoint_id": "BLKpoint_181",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "7360",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.195",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_184",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "13790",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.156",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_185",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.233",
          "pressure_kpa": "3200",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.099",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_188",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.233",
          "pressure_kpa": "3910",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.264",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.162"
        },
        {
          "BLKpoint_id": "BLKpoint_190",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.233",
          "pressure_kpa": "4240",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.589",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.405"
        },
        {
          "BLKpoint_id": "BLKpoint_192",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.233",
          "pressure_kpa": "4550",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.967",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.254"
        },
        {
          "BLKpoint_id": "BLKpoint_195",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.233",
          "pressure_kpa": "4830",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "-0.087",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.35"
        },
        {
          "BLKpoint_id": "BLKpoint_197",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.233",
          "pressure_kpa": "5000",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.686",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.221"
        },
        {
          "BLKpoint_id": "BLKpoint_201",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.233",
          "pressure_kpa": "5650",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.464",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_205",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.233",
          "pressure_kpa": "7010",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.351",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_209",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.233",
          "pressure_kpa": "12990",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.271",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_210",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "3440",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.159",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_214",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "4240",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.644",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.46"
        },
        {
          "BLKpoint_id": "BLKpoint_216",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "4550",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "2.116",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.154"
        },
        {
          "BLKpoint_id": "BLKpoint_218",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "4800",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.255",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.175"
        },
        {
          "BLKpoint_id": "BLKpoint_220",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "5010",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.978",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.234"
        },
        {
          "BLKpoint_id": "BLKpoint_224",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "5440",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.67",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.152"
        },
        {
          "BLKpoint_id": "BLKpoint_227",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "6880",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.456",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_232",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "12410",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.348",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_233",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "3680",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.21",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.156"
        },
        {
          "BLKpoint_id": "BLKpoint_236",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "4340",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.846",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.433"
        },
        {
          "BLKpoint_id": "BLKpoint_238",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "4550",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.787",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.343"
        },
        {
          "BLKpoint_id": "BLKpoint_240",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "4810",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.879",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.207"
        },
        {
          "BLKpoint_id": "BLKpoint_242",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "4960",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.533",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.204"
        },
        {
          "BLKpoint_id": "BLKpoint_246",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "5300",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.892",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.165"
        },
        {
          "BLKpoint_id": "BLKpoint_252",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "6030",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.611",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_259",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "9110",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.429",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_262",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "14860",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.372",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_263",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "3520",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.119",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_266",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "4200",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.353",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.182"
        },
        {
          "BLKpoint_id": "BLKpoint_269",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "4700",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.239",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.224"
        },
        {
          "BLKpoint_id": "BLKpoint_271",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "4900",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.763",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.156"
        },
        {
          "BLKpoint_id": "BLKpoint_272",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "5040",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.219",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.166"
        },
        {
          "BLKpoint_id": "BLKpoint_276",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "5420",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.656",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.169"
        },
        {
          "BLKpoint_id": "BLKpoint_279",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "6030",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.484",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
        },
        {
          "BLKpoint_id": "BLKpoint_285",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "12660",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.292",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_286",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.829",
          "pressure_kpa": "3460",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.071",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_289",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.829",
          "pressure_kpa": "4270",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.269",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.181"
        },
        {
          "BLKpoint_id": "BLKpoint_292",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.829",
          "pressure_kpa": "4610",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.824",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.185"
        },
        {
          "BLKpoint_id": "BLKpoint_295",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.829",
          "pressure_kpa": "4890",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.58",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.168"
        },
        {
          "BLKpoint_id": "BLKpoint_296",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.829",
          "pressure_kpa": "4970",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.16",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.189"
        },
        {
          "BLKpoint_id": "BLKpoint_298",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.829",
          "pressure_kpa": "5230",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.59",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.18"
        },
        {
          "BLKpoint_id": "BLKpoint_302",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.829",
          "pressure_kpa": "5800",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.383",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_309",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.829",
          "pressure_kpa": "11990",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.221",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_310",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "3400",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.042",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_314",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "4260",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.104",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.159"
        },
        {
          "BLKpoint_id": "BLKpoint_318",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "4790",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.407",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.157"
        },
        {
          "BLKpoint_id": "BLKpoint_325",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "6060",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.165",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_331",
          "temperature_k": "563.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "12810",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.092",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_332",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "3240",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.053",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_335",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "4240",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.155",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.16"
        },
        {
          "BLKpoint_id": "BLKpoint_340",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "4950",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.531",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
        },
        {
          "BLKpoint_id": "BLKpoint_345",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "5410",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.157",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_348",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "5720",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.278",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_363",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.119",
          "pressure_kpa": "15060",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.15",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_364",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "3100",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.087",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_368",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "4280",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.31",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.167"
        },
        {
          "BLKpoint_id": "BLKpoint_373",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "5030",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.016",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_375",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "5360",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.473",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.158"
        },
        {
          "BLKpoint_id": "BLKpoint_378",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "5830",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.681",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_388",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "8190",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.415",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_394",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.342",
          "pressure_kpa": "15040",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.332",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_395",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "3030",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.087",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_398",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "4180",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.287",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.156"
        },
        {
          "BLKpoint_id": "BLKpoint_403",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "5060",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "1.05",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.162"
        },
        {
          "BLKpoint_id": "BLKpoint_408",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "5420",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.605",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_411",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "5740",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.829",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.153"
        },
        {
          "BLKpoint_id": "BLKpoint_415",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "6850",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.563",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_418",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "8320",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.458",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_422",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.447",
          "pressure_kpa": "15180",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.371",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_423",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "3110",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.09",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_427",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "4380",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.347",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.183"
        },
        {
          "BLKpoint_id": "BLKpoint_433",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "5030",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.999",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.168"
        },
        {
          "BLKpoint_id": "BLKpoint_436",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "5330",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.703",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.179"
        },
        {
          "BLKpoint_id": "BLKpoint_440",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "5720",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.902",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_447",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "6500",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.629",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
        },
        {
          "BLKpoint_id": "BLKpoint_452",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "7730",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.494",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_459",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.548",
          "pressure_kpa": "15070",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.375",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_460",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "2870",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.058",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_465",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "4260",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.255",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.158"
        },
        {
          "BLKpoint_id": "BLKpoint_470",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "5020",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.857",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.178"
        },
        {
          "BLKpoint_id": "BLKpoint_474",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "5390",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.693",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.165"
        },
        {
          "BLKpoint_id": "BLKpoint_476",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "5630",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.931",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.159"
        },
        {
          "BLKpoint_id": "BLKpoint_484",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "6530",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.589",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_489",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "7730",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.463",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_494",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.646",
          "pressure_kpa": "15040",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.339",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_495",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "3350",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.07",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.149"
        },
        {
          "BLKpoint_id": "BLKpoint_498",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "4440",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.261",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.164"
        },
        {
          "BLKpoint_id": "BLKpoint_505",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "5640",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.873",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.155"
        },
        {
          "BLKpoint_id": "BLKpoint_510",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "6410",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.531",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_517",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "7900",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.38",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_523",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.739",
          "pressure_kpa": "15090",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.277",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_524",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "3290",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.001",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_528",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "4810",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.115",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.158"
        },
        {
          "BLKpoint_id": "BLKpoint_534",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "5530",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.381",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.151"
        },
        {
          "BLKpoint_id": "BLKpoint_540",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "6140",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.206",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.15"
        },
        {
          "BLKpoint_id": "BLKpoint_547",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "7340",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.123",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        },
        {
          "BLKpoint_id": "BLKpoint_556",
          "temperature_k": "573.2",
          "mole_fraction_<benzene>": "0.916",
          "pressure_kpa": "14930",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.053",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.148"
        }
      ],
      "inspection_id": "INSP_c0757cb3625b",
      "lit_num_id": "GLOBlit_4217"
    },
    {
      "doi": "10.1016/j.jct.2014.05.020",
      "block_number": "PROPblock_2",
      "table_mode": "rdp",
      "columns": [
        "BLKpoint_id",
        "temperature_k",
        "pressure_kpa",
        "mole_fraction_<benzene>",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
        "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U"
      ],
      "rows_shown": [
        {
          "BLKpoint_id": "BLKpoint_1",
          "temperature_k": "298.2",
          "pressure_kpa": "5000",
          "mole_fraction_<benzene>": "0.1189",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.318",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0148"
        },
        {
          "BLKpoint_id": "BLKpoint_4",
          "temperature_k": "298.2",
          "pressure_kpa": "5000",
          "mole_fraction_<benzene>": "0.2882",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6367",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0139"
        },
        {
          "BLKpoint_id": "BLKpoint_6",
          "temperature_k": "298.2",
          "pressure_kpa": "5000",
          "mole_fraction_<benzene>": "0.3955",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.744",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0134"
        },
        {
          "BLKpoint_id": "BLKpoint_8",
          "temperature_k": "298.2",
          "pressure_kpa": "5000",
          "mole_fraction_<benzene>": "0.4985",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7873",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
        },
        {
          "BLKpoint_id": "BLKpoint_10",
          "temperature_k": "298.2",
          "pressure_kpa": "5000",
          "mole_fraction_<benzene>": "0.5976",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7631",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
        },
        {
          "BLKpoint_id": "BLKpoint_12",
          "temperature_k": "298.2",
          "pressure_kpa": "5000",
          "mole_fraction_<benzene>": "0.6929",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6925",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0135"
        },
        {
          "BLKpoint_id": "BLKpoint_15",
          "temperature_k": "298.2",
          "pressure_kpa": "5000",
          "mole_fraction_<benzene>": "0.8293",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.4721",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0149"
        },
        {
          "BLKpoint_id": "BLKpoint_17",
          "temperature_k": "298.2",
          "pressure_kpa": "5000",
          "mole_fraction_<benzene>": "0.9162",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.257",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0158"
        },
        {
          "BLKpoint_id": "BLKpoint_18",
          "temperature_k": "298.2",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.1188",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2988",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0143"
        },
        {
          "BLKpoint_id": "BLKpoint_20",
          "temperature_k": "298.2",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.2879",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6265",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0141"
        },
        {
          "BLKpoint_id": "BLKpoint_22",
          "temperature_k": "298.2",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.3951",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7434",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0135"
        },
        {
          "BLKpoint_id": "BLKpoint_24",
          "temperature_k": "298.2",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.4981",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7882",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
        },
        {
          "BLKpoint_id": "BLKpoint_26",
          "temperature_k": "298.2",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.5972",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7678",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
        },
        {
          "BLKpoint_id": "BLKpoint_28",
          "temperature_k": "298.2",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.6926",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6849",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0136"
        },
        {
          "BLKpoint_id": "BLKpoint_30",
          "temperature_k": "298.2",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.7845",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5495",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0144"
        },
        {
          "BLKpoint_id": "BLKpoint_32",
          "temperature_k": "298.2",
          "pressure_kpa": "15000",
          "mole_fraction_<benzene>": "0.9161",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2455",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0152"
        },
        {
          "BLKpoint_id": "BLKpoint_33",
          "temperature_k": "298.2",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.1187",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3012",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0144"
        },
        {
          "BLKpoint_id": "BLKpoint_34",
          "temperature_k": "298.2",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.2325",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5383",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0141"
        },
        {
          "BLKpoint_id": "BLKpoint_35",
          "temperature_k": "298.2",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.3418",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.698",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0134"
        },
        {
          "BLKpoint_id": "BLKpoint_36",
          "temperature_k": "298.2",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.4469",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7722",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0131"
        },
        {
          "BLKpoint_id": "BLKpoint_37",
          "temperature_k": "298.2",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.5479",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7837",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.013"
        },
        {
          "BLKpoint_id": "BLKpoint_38",
          "temperature_k": "298.2",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.6451",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7321",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
        },
        {
          "BLKpoint_id": "BLKpoint_40",
          "temperature_k": "298.2",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.7843",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5515",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0143"
        },
        {
          "BLKpoint_id": "BLKpoint_42",
          "temperature_k": "298.2",
          "pressure_kpa": "25000",
          "mole_fraction_<benzene>": "0.916",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2483",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0154"
        },
        {
          "BLKpoint_id": "BLKpoint_205",
          "temperature_k": "298.2",
          "pressure_kpa": "100",
          "mole_fraction_<benzene>": "0.1191",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.3207",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0143"
        },
        {
          "BLKpoint_id": "BLKpoint_206",
          "temperature_k": "298.2",
          "pressure_kpa": "100",
          "mole_fraction_<benzene>": "0.2332",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.5517",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0145"
        },
        {
          "BLKpoint_id": "BLKpoint_208",
          "temperature_k": "298.2",
          "pressure_kpa": "100",
          "mole_fraction_<benzene>": "0.3426",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7003",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0134"
        },
        {
          "BLKpoint_id": "BLKpoint_210",
          "temperature_k": "298.2",
          "pressure_kpa": "100",
          "mole_fraction_<benzene>": "0.4478",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7782",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0131"
        },
        {
          "BLKpoint_id": "BLKpoint_212",
          "temperature_k": "298.2",
          "pressure_kpa": "100",
          "mole_fraction_<benzene>": "0.5488",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7863",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0131"
        },
        {
          "BLKpoint_id": "BLKpoint_214",
          "temperature_k": "298.2",
          "pressure_kpa": "100",
          "mole_fraction_<benzene>": "0.6459",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.7353",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0133"
        },
        {
          "BLKpoint_id": "BLKpoint_216",
          "temperature_k": "298.2",
          "pressure_kpa": "100",
          "mole_fraction_<benzene>": "0.7394",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.6282",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.0139"
        },
        {
          "BLKpoint_id": "BLKpoint_219",
          "temperature_k": "298.2",
          "pressure_kpa": "100",
          "mole_fraction_<benzene>": "0.9163",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol": "0.2636",
          "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U": "0.015"
        }
      ],
      "inspection_id": "INSP_4d898e6d2a1a",
      "lit_num_id": "GLOBlit_4181"
    }
  ]
}
</subagent_answer>
```
</details>

---

### Step 2 [A · c9]: `inspect_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "purpose": "Verify column names and structure for fitting Hᴱ at 298.2 K, 100 kPa"
}
```
</details>

- **Result:** 295 chars  |  **Time:** 0.0s  |  **Started:** 18:00:24 (t+216.6s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ inspect_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to inspect_block: missing a required argument: 'tasks'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 3 [A · c10]: `inspect_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "purpose": "Verify column names and structure for RK fitting of Hᴱ at 298.2 K, 100 kPa",
  "tasks": [
    "inspect block structure"
  ]
}
```
</details>

- **Result:** 349 chars  |  **Time:** 0.0s  |  **Started:** 18:00:30 (t+222.5s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ inspect_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: inspect_block.tasks received ['inspect block structure'] (list); expected <class 'str'>; tool arguments are never coerced

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 4 [A · c11]: `inspect_block`

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "purpose": "Verify column names and structure for RK fitting of excess molar enthalpy at 298.2 K and 100 kPa",
  "tasks": "Inspect block columns, value ranges, and row count"
}
```
</details>

- **Result:** 1,681 chars  |  **Time:** 0.3s  |  **Started:** 18:00:35 (t+228.1s)

<details><summary>Result</summary>

```
**Block GLOBlit_4181 / DOI 10.1016/j.jct.2014.05.020 / PROPblock_2 @ declared** (PureOrMixtureData)
Compounds: benzene, cyclohexane | Rows: 219
x‑columns: ['mole_fraction_<benzene>'] | y‑columns: ['excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol']

**Property response semantics (reported metadata; values are not materialized here)**
- **BLKprop_1 / GLOBprop_17** `excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol` (excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol)
  - reported response: Direct value, X
  - measurement: GLOBmeas_12 / flow_calorimetry
  - property phase: Liquid (GLOBphase_1; liquid)
  - reference: none; T=unspecified K; P=unspecified kPa
  - reference phase: none
  - component_org_num: none

**Selected property response contract (inspection only; values are not materialized here)**
- **BLKprop_1 / GLOBprop_17** `excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol` (excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol)
  - reported response: Direct value, X [direct]
  - units: reported=kJ/mol; absolute=kJ/mol
  - preparation gate: reference_materialization=False; normalized_composition=False; supported=True
  - reference: none; T=unspecified K; P=unspecified kPa
  - property phase: Liquid (GLOBphase_1; liquid)
  - reference phase: none
  - component_org_num: none

| Column | Min | Max | Valid pts |
|--------|-----|-----|-----------|
| temperature_k | 298.2 | 523.2 | 219 |
| pressure_kpa | 100 | 25000 | 219 |
| mole_fraction_<benzene> | 0.1187 | 0.9585 | 219 |
| excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol | 0.0514 | 0.7893 | 219 |
| excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U | 0.0117 | 0.0158 | 219 |

```
</details>

---

### Step 5 [A · c12]: `fit_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess",
  "composition_hint": "mole_fraction",
  "max_rk_order": 5,
  "x_vars": [
    "Mole fraction of benzene"
  ],
  "y_props": [
    "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol"
  ],
  "x_vars_constrained": {
    "Temperature, K": {
      "value": 298.2,
      "tol": 0.5
    },
    "Pressure, kPa": {
      "value": 100,
      "tol": 1
    }
  }
}
```
</details>

- **Result:** 289 chars  |  **Time:** 0.0s  |  **Started:** 18:00:46 (t+238.5s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to fit_block: missing a required argument: 'purpose'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 6 [A · c13]: `fit_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess_enthalpy",
  "composition_hint": "mole_fraction",
  "max_rk_order": 5,
  "x_vars": [
    "Mole fraction of benzene"
  ],
  "y_props": [
    "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol"
  ],
  "x_vars_constrained": {
    "Temperature, K": {
      "value": 298.2,
      "tol": 0.5
    },
    "Pressure, kPa": {
      "value": 100,
      "tol": 1
    }
  },
  "purpose": "Fit Redlich-Kister expansion to excess molar enthalpy of benzene+cyclohexane at 298.2 K and 100 kPa"
}
```
</details>

- **Result:** 287 chars  |  **Time:** 0.0s  |  **Started:** 18:00:54 (t+246.5s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to fit_block: missing a required argument: 'tasks'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 7 [A · c14]: `fit_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess_enthalpy",
  "x_vars": [
    "Mole fraction of benzene"
  ],
  "y_props": [
    "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol"
  ],
  "x_vars_constrained": {
    "Temperature, K": {
      "value": 298.2,
      "tol": 0.5
    },
    "Pressure, kPa": {
      "value": 100,
      "tol": 1
    }
  },
  "max_rk_order": 5,
  "purpose": "Fit Redlich-Kister expansion to excess molar enthalpy of benzene+cyclohexane at 298.2 K and 100 kPa",
  "tasks": [
    "fit_rk"
  ]
}
```
</details>

- **Result:** 324 chars  |  **Time:** 0.0s  |  **Started:** 18:01:01 (t+253.9s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: fit_block.tasks received ['fit_rk'] (list); expected <class 'str'>; tool arguments are never coerced

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 8 [A · c15]: `fit_block`

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess_enthalpy",
  "max_rk_order": 5,
  "x_vars": [
    "Mole fraction of benzene"
  ],
  "y_props": [
    "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol"
  ],
  "x_vars_constrained": {
    "Temperature, K": {
      "value": 298.2,
      "tol": 0.5
    },
    "Pressure, kPa": {
      "value": 100,
      "tol": 1
    }
  },
  "purpose": "Fit Redlich-Kister polynomial to excess molar enthalpy of benzene + cyclohexane at 298.2 K and 100 kPa",
  "tasks": "fit_rk"
}
```
</details>

- **Result:** 352 chars  |  **Time:** 0.1s  |  **Started:** 18:01:10 (t+262.9s)

<details><summary>Result</summary>

```
**Fit error** (GLOBlit_4181 / DOI 10.1016/j.jct.2014.05.020 / PROPblock_2): Requested x column 'Mole fraction of benzene' not found in block
Columns available: ['BLKpoint_id', 'temperature_k', 'pressure_kpa', 'mole_fraction_<benzene>', 'excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol', 'excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U']

```
</details>

---

### Step 9 [A · c16]: `fit_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "max_rk_order": 5,
  "purpose": "Fit RK expansion to Hᴱ of benzene+cyclohexane at 298.2 K, 100 kPa",
  "tasks": [
    "fit_rk"
  ]
}
```
</details>

- **Result:** 324 chars  |  **Time:** 0.0s  |  **Started:** 18:01:19 (t+271.8s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: fit_block.tasks received ['fit_rk'] (list); expected <class 'str'>; tool arguments are never coerced

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 10 [A · c17]: `fit_block`

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess_enthalpy",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "max_rk_order": 5,
  "purpose": "Fit RK expansion to excess molar enthalpy of benzene+cyclohexane at 298.2 K and 100 kPa",
  "tasks": "fit_rk"
}
```
</details>

- **Result:** 922 chars  |  **Time:** 2.3s  |  **Started:** 18:01:27 (t+279.8s)

<details><summary>Result</summary>

```
**RK Fit** — GLOBlit_4181 / DOI 10.1016/j.jct.2014.05.020 / PROPblock_2 @ declared
Components: benzene, cyclohexane | Mixing rule: declared_excess_no_baseline
Points: 15 mixture / 219 total
Property response: BLKprop_1 / GLOBprop_17; kind=direct; equation=X = reported X; reference_sources=0; units=kJ/mol -> kJ/mol.

| Component | Pure value |
|-----------|-----------|
| benzene | 0.0 |
| cyclohexane | 0.0 |
Pure values: declared excess property: zero at pure limits

BIC-selected order: 5 | R² = 0.999977 | RMSE = 0.000778945 | BIC = -198.48
Coefficients: [3.16062, 0.171159, 0.0500302, -0.0567722, 0.0755591, 0.214308]

| Order | BIC | R² | RMSE |
|-------|-----|----|------|
| 0 | -126.73 | 0.993163 | 0.0133722 |
| 1 | -168.36 | 0.999644 | 0.00304989 |
| 2 | -184.30 | 0.999897 | 0.00163805 |
| 3 | -193.37 | 0.999953 | 0.00110627 |
| 4 | -195.76 | 0.999967 | 0.000933255 |
| 5 | -198.48 | 0.999977 | 0.000778945 |

```
</details>

---

### Step 11 [A · c18]: `fit_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess_enthalpy",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "max_rk_order": 5,
  "purpose": "Fit RK to HE benzene+cyclohexane at 298.2 K and 100 kPa only",
  "tasks": [
    "fit"
  ]
}
```
</details>

- **Result:** 321 chars  |  **Time:** 0.0s  |  **Started:** 18:02:56 (t+369.1s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: fit_block.tasks received ['fit'] (list); expected <class 'str'>; tool arguments are never coerced

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 12 [A · c19]: `fit_block`

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "max_rk_order": 5,
  "purpose": "Fit RK expansion to Hᴱ of benzene+cyclohexane at 298.2 K and 100 kPa only (8 points)",
  "tasks": "fit"
}
```
</details>

- **Result:** 922 chars  |  **Time:** 1.9s  |  **Started:** 18:04:33 (t+465.3s)

<details><summary>Result</summary>

```
**RK Fit** — GLOBlit_4181 / DOI 10.1016/j.jct.2014.05.020 / PROPblock_2 @ declared
Components: benzene, cyclohexane | Mixing rule: declared_excess_no_baseline
Points: 15 mixture / 219 total
Property response: BLKprop_1 / GLOBprop_17; kind=direct; equation=X = reported X; reference_sources=0; units=kJ/mol -> kJ/mol.

| Component | Pure value |
|-----------|-----------|
| benzene | 0.0 |
| cyclohexane | 0.0 |
Pure values: declared excess property: zero at pure limits

BIC-selected order: 5 | R² = 0.999977 | RMSE = 0.000778945 | BIC = -198.48
Coefficients: [3.16062, 0.171159, 0.0500302, -0.0567722, 0.0755591, 0.214308]

| Order | BIC | R² | RMSE |
|-------|-----|----|------|
| 0 | -126.73 | 0.993163 | 0.0133722 |
| 1 | -168.36 | 0.999644 | 0.00304989 |
| 2 | -184.30 | 0.999897 | 0.00163805 |
| 3 | -193.37 | 0.999953 | 0.00110627 |
| 4 | -195.76 | 0.999967 | 0.000933255 |
| 5 | -198.48 | 0.999977 | 0.000778945 |

```
</details>

---

### Step 13 [A · c20]: `propose_fitting_plan` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "property_hint": "excess_molar_enthalpy",
  "composition_hint": "mole_fraction"
}
```
</details>

- **Result:** 311 chars  |  **Time:** 0.0s  |  **Started:** 18:04:52 (t+484.4s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ propose_fitting_plan** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to propose_fitting_plan: missing a required argument: 'purpose'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 14 [A · c21]: `propose_fitting_plan` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "property_hint": "excess_molar_enthalpy",
  "composition_hint": "mole_fraction",
  "purpose": "Validate fitting plan for Hᴱ of benzene+cyclohexane at 298.2 K and 100 kPa"
}
```
</details>

- **Result:** 309 chars  |  **Time:** 0.0s  |  **Started:** 18:05:01 (t+493.5s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ propose_fitting_plan** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to propose_fitting_plan: missing a required argument: 'tasks'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 15 [A · c22]: `propose_fitting_plan` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "property_hint": "excess_molar_enthalpy",
  "composition_hint": "mole_fraction",
  "purpose": "Validate fitting plan to isolate 8 Hᴱ data points at 298.2 K and 100 kPa",
  "tasks": [
    "validate column selections and constraints"
  ]
}
```
</details>

- **Result:** 382 chars  |  **Time:** 0.0s  |  **Started:** 18:05:09 (t+502.0s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ propose_fitting_plan** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: propose_fitting_plan.tasks received ['validate column selections and constraints'] (list); expected <class 'str'>; tool arguments are never coerced

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 16 [A · c23]: `propose_fitting_plan`

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "property_hint": "excess_molar_enthalpy",
  "composition_hint": "mole_fraction",
  "purpose": "Validate fitting plan for Hᴱ of benzene+cyclohexane at 298.2 K and 100 kPa",
  "tasks": "Validate column selections and constraints for RK fit"
}
```
</details>

- **Result:** 898 chars  |  **Time:** 0.1s  |  **Started:** 18:05:17 (t+509.8s)

<details><summary>Result</summary>

```
**Fitting plan: valid**
  x_col: mole_fraction_<benzene> | y_col: excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol
  constraints: {'temperature_k': {'value': 298.2, 'tol': 0.5, 'nearest_in_data': 298.2, 'n_matching': 57}, 'pressure_kpa': {'value': 100, 'tol': 1, 'nearest_in_data': 100.0, 'n_matching': 15}}
**Selected property response contract (inspection only; values are not materialized here)**
- **BLKprop_1 / GLOBprop_17** `excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol` (excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol)
  - reported response: Direct value, X [direct]
  - units: reported=kJ/mol; absolute=kJ/mol
  - preparation gate: reference_materialization=False; normalized_composition=False; supported=True
  - reference: none; T=unspecified K; P=unspecified kPa
  - property phase: Liquid (GLOBphase_1; liquid)
  - reference phase: none
  - component_org_num: none

```
</details>

---

### Step 17 [A · c24]: `fit_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "max_rk_order": 5,
  "purpose": "Fit RK to HE benzene+cyclohexane at 298.2 K AND 100 kPa only",
  "tasks": [
    "fit"
  ]
}
```
</details>

- **Result:** 321 chars  |  **Time:** 0.0s  |  **Started:** 18:05:52 (t+545.0s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: fit_block.tasks received ['fit'] (list); expected <class 'str'>; tool arguments are never coerced

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---

### Step 18 [A · c25]: `fit_block`

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2014.05.020",
  "block_number": "PROPblock_2",
  "property_hint": "excess_molar_enthalpy",
  "property_type": "excess",
  "x_vars": [
    "mole_fraction_<benzene>"
  ],
  "y_props": [
    "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 298.2,
      "tol": 0.5
    },
    "pressure_kpa": {
      "value": 100,
      "tol": 1
    }
  },
  "max_rk_order": 5,
  "purpose": "Fit RK expansion to Hᴱ for benzene+cyclohexane at 298.2 K and 100 kPa",
  "tasks": "fit"
}
```
</details>

- **Result:** 922 chars  |  **Time:** 2.3s  |  **Started:** 18:06:02 (t+555.3s)

<details><summary>Result</summary>

```
**RK Fit** — GLOBlit_4181 / DOI 10.1016/j.jct.2014.05.020 / PROPblock_2 @ declared
Components: benzene, cyclohexane | Mixing rule: declared_excess_no_baseline
Points: 15 mixture / 219 total
Property response: BLKprop_1 / GLOBprop_17; kind=direct; equation=X = reported X; reference_sources=0; units=kJ/mol -> kJ/mol.

| Component | Pure value |
|-----------|-----------|
| benzene | 0.0 |
| cyclohexane | 0.0 |
Pure values: declared excess property: zero at pure limits

BIC-selected order: 5 | R² = 0.999977 | RMSE = 0.000778945 | BIC = -198.48
Coefficients: [3.16062, 0.171159, 0.0500302, -0.0567722, 0.0755591, 0.214308]

| Order | BIC | R² | RMSE |
|-------|-----|----|------|
| 0 | -126.73 | 0.993163 | 0.0133722 |
| 1 | -168.36 | 0.999644 | 0.00304989 |
| 2 | -184.30 | 0.999897 | 0.00163805 |
| 3 | -193.37 | 0.999953 | 0.00110627 |
| 4 | -195.76 | 0.999967 | 0.000933255 |
| 5 | -198.48 | 0.999977 | 0.000778945 |

```
</details>

---

## Nested tool calls — L1_1 (L1-query)

**Nest:** A - L1_1
**Parent:** `query_thermoml` — Step 1 [A · c8] relays this worker's result
**Started:** 17:56:55  |  **Ended:** 18:00:13  |  **Tool calls:** 7

---

### Step 1 [A - L1_1 · c1]: `resolve_compound_ids`

<details><summary>Arguments</summary>

```json
{
  "queries": [
    "benzene",
    "cyclohexane"
  ],
  "purpose": "Find compound IDs for benzene and cyclohexane",
  "tasks": "Resolve benzene and cyclohexane to GLOBcomp IDs"
}
```
</details>

- **Result:** 197 chars  |  **Time:** 4.3s  |  **Started:** 17:57:00 (t+12.8s)
- **Subagent:** KEEP in 299 → 197 chars (3.7s)
  - Both compounds resolved with exact name matches.

| Compound | ID | Formula | SMILES |
|---|---|---|---|
| benzene | GLOBcomp_14 | C6H6 | c1ccccc1 |
| cyclohexane | GLOBcomp_13 | C6H12 | C1CCCCC1 |

<details><summary>Result</summary>

```
Both compounds resolved with exact name matches.

| Compound | ID | Formula | SMILES |
|---|---|---|---|
| benzene | GLOBcomp_14 | C6H6 | c1ccccc1 |
| cyclohexane | GLOBcomp_13 | C6H12 | C1CCCCC1 |
```
</details>

---

### Step 3 [A - L1_1 · c2]: `search_blocks`

<details><summary>Arguments</summary>

```json
{
  "compound": [
    "GLOBcomp_14",
    "GLOBcomp_13"
  ],
  "property": "GLOBprop_17",
  "system_type": "binary",
  "temperature_range": [
    295.0,
    302.0
  ],
  "limit": 50,
  "purpose": "Find excess molar enthalpy data blocks for benzene + cyclohexane near 298.2 K",
  "tasks": "Return DOIs, block numbers, temperature ranges, pressure, number of data points, and composition ranges"
}
```
</details>

- **Result:** 1,097 chars  |  **Time:** 22.1s  |  **Started:** 17:57:15 (t+27.6s)
- **Subagent:** KEEP in 3,026 → 1,067 chars (13.3s)
  - **Summary:** One block found containing excess molar enthalpy (H_E) data for benzene + cyclohexane. The block (PROPblock_2, DOI `10.1016/j.jct.2014.05.020`) has 219 total points spanning 298.2–348.2 K

<details><summary>Result</summary>

```
**Summary:** One block found containing excess molar enthalpy (H_E) data for benzene + cyclohexane. The block (PROPblock_2, DOI `10.1016/j.jct.2014.05.020 [GLOBlit_4181]`) has 219 total points spanning 298.2–348.2 K at elevated pressures (5–25 MPa). At T = 298.2 K there are 24 data points across three pressures.

### Block Overview

| Field | Value |
|---|---|
| DOI | `10.1016/j.jct.2014.05.020 [GLOBlit_4181]` |
| Block | `PROPblock_2` |
| lit_id | `GLOBlit_4181` |
| Property | `GLOBprop_17` — Excess molar enthalpy (kJ/mol) |
| Method | `GLOBmeas_12` — flow calorimetry |
| Phase | Liquid |
| Total points | 219 |
| T range | 298.2–348.2 K |
| P range | 5000.0–25000.0 kPa |
| x(benzene) range | 0.1187–0.9162 |
| Compounds | `GLOBcomp_14` (benzene, DOIcomp_3), `GLOBcomp_13` (cyclohexane, DOIcomp_4) |

### Data at T = 298.2 K (24 points shown)

| P (kPa) | x(benzene) | H_E (kJ/mol) | ±U |
|---|---|---|---|
| 5000.0 | 0.1189 | 0.318 | 0.0148 |
| 5000.0 | 0.2882 | 0.6367 | 0.0139 |
| 5000.0 | 0.3955 | 0.744 | 0.0134 |
| 5000.0 | 0.4985 | 0.7873 | 0.0133 |
| 5000.0 | 0.5976 | 0.7631 | 0.
```
</details>

---

### Step 4 [A - L1_1 · c3]: `search_blocks`

<details><summary>Arguments</summary>

```json
{
  "compound": [
    "GLOBcomp_14",
    "GLOBcomp_13"
  ],
  "property": "GLOBprop_17",
  "system_type": "binary",
  "limit": 50,
  "purpose": "Find all excess molar enthalpy blocks for benzene+cyclohexane to check for atmospheric pressure data",
  "tasks": "Search without temperature restriction to find any blocks near 100 kPa"
}
```
</details>

- **Result:** 770 chars  |  **Time:** 21.7s  |  **Started:** 17:57:47 (t+59.8s)
- **Subagent:** KEEP in 7,687 → 770 chars (13.6s)
  - **No atmospheric-pressure excess molar enthalpy data found.** All 5 blocks for benzene + cyclohexane contain data exclusively at elevated pressures (lowest P = 1510.0 kPa ≈ 15 atm), far above the ~100

<details><summary>Result</summary>

```
**No atmospheric-pressure excess molar enthalpy data found.** All 5 blocks for benzene + cyclohexane contain data exclusively at elevated pressures (lowest P = 1510.0 kPa ≈ 15 atm), far above the ~100 kPa target. The ThermoML database does not appear to hold H^E data for this binary at atmospheric pressure.

| # | DOI | Block | lit_id | P range (kPa) | T range (K) | Phase | Pts |
|---|-----|-------|--------|---------------|-------------|-------|-----|
| 1 | 10.1016/j.jct.2014.05.020 | PROPblock_2 | GLOBlit_4181 | 5000.0–25000.0 | 298.2–348.2 | Liquid | 219 |
| 2 | 10.1016/j.jct.2014.05.020 | PROPblock_3 | GLOBlit_4181 | 15000.0–25000.0 | 573.2 (fixed) | Fluid | 24 |
| 3 | 10.1016/j.jct.2014.07.016 | PROPblock_1 | GLOBlit_4217 | 3190.0–14760.0 | 558.2 | Fluid |
```
</details>

---

### Step 6 [A - L1_1 · c4]: `inspect_block_table`

<details><summary>Arguments</summary>

```json
{
  "block_number": "GLOBlit_4181::PROPblock_2",
  "where": "Temperature BETWEEN 297 AND 300",
  "purpose": "Ground data values for benzene+cyclohexane H_E at 298.2 K",
  "tasks": "Return verbatim data rows at T~298.2 K"
}
```
</details>

- **Result:** 493 chars  |  **Time:** 0.1s  |  **Started:** 17:58:33 (t+105.4s)

<details><summary>Result</summary>

```
**inspect_block_table error** — where filter error: unknown column alias 'Temperature'

| alias | n_finite | min | max |
|---|---|---|---|
| temperature_k | 219 | 298.2 | 523.2 |
| pressure_kpa | 219 | 100 | 25000 |
| mole_fraction_benzene | 219 | 0.1187 | 0.9585 |
| excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol | 219 | 0.0514 | 0.7893 |
| excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_u | 219 | 0.0117 | 0.0158 |

Use these aliases in `where` / `nearest` with plain numbers.
```
</details>

---

### Step 6 [A - L1_1 · c5]: `inspect_block_table`

<details><summary>Arguments</summary>

```json
{
  "block_number": "GLOBlit_4181::PROPblock_3",
  "purpose": "Ground block metadata for PROPblock_3",
  "tasks": "Return block overview and data"
}
```
</details>

- **Result:** 1,951 chars  |  **Time:** 0.1s  |  **Started:** 17:58:33 (t+105.5s)

<details><summary>Result</summary>

```
**Data inspection** — 10.1016/j.jct.2014.05.020 [GLOBlit_4181] :: PROPblock_3 (binary: benzene + cyclohexane)
filter: none (whole block)
block constraints: temperature_k = 573.2
uncertainty: expanded combined (U), level 95 %, evaluated by Data file compiler

| BLKpoint_id | pressure_kpa | mole_fraction_<benzene> | temperature_k | excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol | excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U |
|---|---|---|---|---|---|
| BLKpoint_1 | 15000 | 0.1188 | 573.2 | 0.1497 | 0.012 |
| BLKpoint_2 | 15000 | 0.1763 | 573.2 | 0.2106 | 0.0119 |
| BLKpoint_4 | 15000 | 0.3421 | 573.2 | 0.3295 | 0.0116 |
| BLKpoint_5 | 15000 | 0.4471 | 573.2 | 0.3683 | 0.0115 |
| BLKpoint_6 | 15000 | 0.5482 | 573.2 | 0.373 | 0.0115 |
| BLKpoint_7 | 15000 | 0.6454 | 573.2 | 0.3436 | 0.0116 |
| BLKpoint_8 | 15000 | 0.7389 | 573.2 | 0.2874 | 0.0118 |
| BLKpoint_12 | 15000 | 0.9584 | 573.2 | 0.0501 | 0.0123 |
| BLKpoint_13 | 25000 | 0.1187 | 573.2 | 0.1394 | 0.0119 |
| BLKpoint_14 | 25000 | 0.1762 | 573.2 | 0.1982 | 0.0118 |
| BLKpoint_16 | 25000 | 0.3418 | 573.2 | 0.3089 | 0.0116 |
| BLKpoint_17 | 25000 | 0.4469 | 573.2 | 0.345 | 0.0115 |
| BLKpoint_18 | 25000 | 0.5479 | 573.2 | 0.3491 | 0.0115 |
| BLKpoint_19 | 25000 | 0.6451 | 573.2 | 0.3208 | 0.0115 |
| BLKpoint_20 | 25000 | 0.7388 | 573.2 | 0.268 | 0.0117 |
| BLKpoint_24 | 25000 | 0.9584 | 573.2 | 0.0399 | 0.0119 |

mode: RDP — 16 of 24 matched rows shown (shape-preserving; block has 24). Quote ONLY shown rows or the stats line; narrow `where` for other rows.
stats (matched, n=24): pressure_kpa 15000–25000 (n=24); mole_fraction_benzene 0.1187–0.9584 (n=24); temperature_k 573.2–573.2 (n=24); excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol 0.0399–0.373 (n=24); excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_u 0.0115–0.0123 (n=24)
inspection_id: INSP_e8c97651c4fa
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```
</details>

---

### Step 6 [A - L1_1 · c6]: `inspect_block_table`

<details><summary>Arguments</summary>

```json
{
  "block_number": "GLOBlit_4217::PROPblock_1",
  "purpose": "Ground block metadata for PROPblock_1 from GLOBlit_4217",
  "tasks": "Return block overview and data"
}
```
</details>

- **Result:** 9,724 chars  |  **Time:** 0.2s  |  **Started:** 17:58:33 (t+105.7s)

<details><summary>Result</summary>

```
**Data inspection** — 10.1016/j.jct.2014.07.016 [GLOBlit_4217] :: PROPblock_1 (binary: benzene + cyclohexane)
filter: none (whole block)
uncertainty: expanded combined (U), level 95 %, evaluated by Data file compiler

| BLKpoint_id | temperature_k | mole_fraction_<benzene> | pressure_kpa | excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol | excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U |
|---|---|---|---|---|---|
| BLKpoint_1 | 558.2 | 0.119 | 3390 | 0.125 | 0.149 |
| BLKpoint_4 | 558.2 | 0.119 | 3940 | 0.281 | 0.219 |
| BLKpoint_5 | 558.2 | 0.119 | 4120 | 0.607 | 0.621 |
| BLKpoint_6 | 558.2 | 0.119 | 4290 | 1.989 | 0.389 |
| BLKpoint_8 | 558.2 | 0.119 | 4510 | -0.372 | 0.437 |
| BLKpoint_10 | 558.2 | 0.119 | 4790 | 0.362 | 0.207 |
| BLKpoint_17 | 558.2 | 0.119 | 6470 | 0.21 | 0.148 |
| BLKpoint_25 | 558.2 | 0.119 | 14760 | 0.157 | 0.148 |
| BLKpoint_26 | 558.2 | 0.342 | 3360 | 0.167 | 0.152 |
| BLKpoint_29 | 558.2 | 0.342 | 4010 | 0.587 | 0.606 |
| BLKpoint_31 | 558.2 | 0.342 | 4310 | 3.257 | 0.367 |
| BLKpoint_34 | 558.2 | 0.342 | 4550 | 0.085 | 0.652 |
| BLKpoint_35 | 558.2 | 0.342 | 4640 | 1.173 | 0.326 |
| BLKpoint_38 | 558.2 | 0.342 | 5090 | 0.657 | 0.163 |
| BLKpoint_40 | 558.2 | 0.342 | 5930 | 0.511 | 0.15 |
| BLKpoint_46 | 558.2 | 0.342 | 13910 | 0.349 | 0.148 |
| BLKpoint_47 | 558.2 | 0.447 | 3190 | 0.145 | 0.154 |
| BLKpoint_50 | 558.2 | 0.447 | 3920 | 0.456 | 0.208 |
| BLKpoint_51 | 558.2 | 0.447 | 4090 | 0.783 | 0.671 |
| BLKpoint_53 | 558.2 | 0.447 | 4340 | 3.055 | 0.338 |
| BLKpoint_55 | 558.2 | 0.447 | 4570 | 0.058 | 0.584 |
| BLKpoint_56 | 558.2 | 0.447 | 4640 | 1.58 | 0.514 |
| BLKpoint_59 | 558.2 | 0.447 | 4910 | 0.814 | 0.191 |
| BLKpoint_62 | 558.2 | 0.447 | 5690 | 0.601 | 0.151 |
| BLKpoint_66 | 558.2 | 0.447 | 8140 | 0.45 | 0.148 |
| BLKpoint_69 | 558.2 | 0.447 | 13600 | 0.386 | 0.148 |
| BLKpoint_70 | 558.2 | 0.548 | 3310 | 0.158 | 0.151 |
| BLKpoint_77 | 558.2 | 0.548 | 4100 | 0.695 | 0.774 |
| BLKpoint_78 | 558.2 | 0.548 | 4300 | 2.512 | 0.611 |
| BLKpoint_82 | 558.2 | 0.548 | 4860 | 1.002 | 0.387 |
| BLKpoint_86 | 558.2 | 0.548 | 5690 | 0.619 | 0.152 |
| BLKpoint_92 | 558.2 | 0.548 | 8110 | 0.454 | 0.148 |
| BLKpoint_96 | 558.2 | 0.548 | 14940 | 0.38 | 0.148 |
| BLKpoint_97 | 558.2 | 0.646 | 3110 | 0.11 | 0.151 |
| BLKpoint_100 | 558.2 | 0.646 | 3980 | 0.419 | 0.221 |
| BLKpoint_103 | 558.2 | 0.646 | 4390 | 2.282 | 0.347 |
| BLKpoint_108 | 558.2 | 0.646 | 4920 | 0.807 | 0.308 |
| BLKpoint_110 | 558.2 | 0.646 | 5510 | 0.619 | 0.153 |
| BLKpoint_114 | 558.2 | 0.646 | 8030 | 0.417 | 0.149 |
| BLKpoint_117 | 558.2 | 0.646 | 13130 | 0.362 | 0.148 |
| BLKpoint_118 | 558.2 | 0.739 | 3290 | 0.107 | 0.15 |
| BLKpoint_121 | 558.2 | 0.739 | 4120 | 0.419 | 0.32 |
| BLKpoint_125 | 558.2 | 0.739 | 4650 | 2.158 | 0.347 |
| BLKpoint_126 | 558.2 | 0.739 | 4800 | 0.928 | 0.52 |
| BLKpoint_128 | 558.2 | 0.739 | 4960 | 0.665 | 0.182 |
| BLKpoint_130 | 558.2 | 0.739 | 5540 | 0.511 | 0.153 |
| BLKpoint_134 | 558.2 | 0.739 | 7560 | 0.359 | 0.148 |
| BLKpoint_138 | 558.2 | 0.739 | 14070 | 0.291 | 0.148 |
| BLKpoint_139 | 558.2 | 0.916 | 3270 | 0.021 | 0.148 |
| BLKpoint_142 | 558.2 | 0.916 | 4230 | 0.125 | 0.209 |
| BLKpoint_144 | 558.2 | 0.916 | 4440 | 0.562 | 0.162 |
| BLKpoint_146 | 558.2 | 0.916 | 4700 | 0.296 | 0.172 |
| BLKpoint_149 | 558.2 | 0.916 | 5300 | 0.188 | 0.15 |
| BLKpoint_163 | 558.2 | 0.916 | 13700 | 0.083 | 0.148 |
| BLKpoint_164 | 563.2 | 0.119 | 3700 | 0.118 | 0.15 |
| BLKpoint_167 | 563.2 | 0.119 | 4300 | 0.499 | 0.315 |
| BLKpoint_169 | 563.2 | 0.119 | 4540 | 1.252 | 0.198 |
| BLKpoint_172 | 563.2 | 0.119 | 4850 | -0.112 | 0.176 |
| BLKpoint_174 | 563.2 | 0.119 | 5000 | 0.354 | 0.188 |
| BLKpoint_181 | 563.2 | 0.119 | 7360 | 0.195 | 0.148 |
| BLKpoint_184 | 563.2 | 0.119 | 13790 | 0.156 | 0.148 |
| BLKpoint_185 | 563.2 | 0.233 | 3200 | 0.099 | 0.149 |
| BLKpoint_188 | 563.2 | 0.233 | 3910 | 0.264 | 0.162 |
| BLKpoint_190 | 563.2 | 0.233 | 4240 | 0.589 | 0.405 |
| BLKpoint_192 | 563.2 | 0.233 | 4550 | 1.967 | 0.254 |
| BLKpoint_195 | 563.2 | 0.233 | 4830 | -0.087 | 0.35 |
| BLKpoint_197 | 563.2 | 0.233 | 5000 | 0.686 | 0.221 |
| BLKpoint_201 | 563.2 | 0.233 | 5650 | 0.464 | 0.149 |
| BLKpoint_205 | 563.2 | 0.233 | 7010 | 0.351 | 0.148 |
| BLKpoint_209 | 563.2 | 0.233 | 12990 | 0.271 | 0.148 |
| BLKpoint_210 | 563.2 | 0.342 | 3440 | 0.159 | 0.15 |
| BLKpoint_214 | 563.2 | 0.342 | 4240 | 0.644 | 0.46 |
| BLKpoint_216 | 563.2 | 0.342 | 4550 | 2.116 | 0.154 |
| BLKpoint_218 | 563.2 | 0.342 | 4800 | 0.255 | 0.175 |
| BLKpoint_220 | 563.2 | 0.342 | 5010 | 0.978 | 0.234 |
| BLKpoint_224 | 563.2 | 0.342 | 5440 | 0.67 | 0.152 |
| BLKpoint_227 | 563.2 | 0.342 | 6880 | 0.456 | 0.148 |
| BLKpoint_232 | 563.2 | 0.342 | 12410 | 0.348 | 0.148 |
| BLKpoint_233 | 563.2 | 0.548 | 3680 | 0.21 | 0.156 |
| BLKpoint_236 | 563.2 | 0.548 | 4340 | 0.846 | 0.433 |
| BLKpoint_238 | 563.2 | 0.548 | 4550 | 1.787 | 0.343 |
| BLKpoint_240 | 563.2 | 0.548 | 4810 | 0.879 | 0.207 |
| BLKpoint_242 | 563.2 | 0.548 | 4960 | 1.533 | 0.204 |
| BLKpoint_246 | 563.2 | 0.548 | 5300 | 0.892 | 0.165 |
| BLKpoint_252 | 563.2 | 0.548 | 6030 | 0.611 | 0.15 |
| BLKpoint_259 | 563.2 | 0.548 | 9110 | 0.429 | 0.148 |
| BLKpoint_262 | 563.2 | 0.548 | 14860 | 0.372 | 0.148 |
| BLKpoint_263 | 563.2 | 0.739 | 3520 | 0.119 | 0.15 |
| BLKpoint_266 | 563.2 | 0.739 | 4200 | 0.353 | 0.182 |
| BLKpoint_269 | 563.2 | 0.739 | 4700 | 1.239 | 0.224 |
| BLKpoint_271 | 563.2 | 0.739 | 4900 | 0.763 | 0.156 |
| BLKpoint_272 | 563.2 | 0.739 | 5040 | 1.219 | 0.166 |
| BLKpoint_276 | 563.2 | 0.739 | 5420 | 0.656 | 0.169 |
| BLKpoint_279 | 563.2 | 0.739 | 6030 | 0.484 | 0.151 |
| BLKpoint_285 | 563.2 | 0.739 | 12660 | 0.292 | 0.148 |
| BLKpoint_286 | 563.2 | 0.829 | 3460 | 0.071 | 0.149 |
| BLKpoint_289 | 563.2 | 0.829 | 4270 | 0.269 | 0.181 |
| BLKpoint_292 | 563.2 | 0.829 | 4610 | 0.824 | 0.185 |
| BLKpoint_295 | 563.2 | 0.829 | 4890 | 0.58 | 0.168 |
| BLKpoint_296 | 563.2 | 0.829 | 4970 | 1.16 | 0.189 |
| BLKpoint_298 | 563.2 | 0.829 | 5230 | 0.59 | 0.18 |
| BLKpoint_302 | 563.2 | 0.829 | 5800 | 0.383 | 0.15 |
| BLKpoint_309 | 563.2 | 0.829 | 11990 | 0.221 | 0.15 |
| BLKpoint_310 | 563.2 | 0.916 | 3400 | 0.042 | 0.148 |
| BLKpoint_314 | 563.2 | 0.916 | 4260 | 0.104 | 0.159 |
| BLKpoint_318 | 563.2 | 0.916 | 4790 | 0.407 | 0.157 |
| BLKpoint_325 | 563.2 | 0.916 | 6060 | 0.165 | 0.149 |
| BLKpoint_331 | 563.2 | 0.916 | 12810 | 0.092 | 0.148 |
| BLKpoint_332 | 573.2 | 0.119 | 3240 | 0.053 | 0.148 |
| BLKpoint_335 | 573.2 | 0.119 | 4240 | 0.155 | 0.16 |
| BLKpoint_340 | 573.2 | 0.119 | 4950 | 0.531 | 0.151 |
| BLKpoint_345 | 573.2 | 0.119 | 5410 | 0.157 | 0.149 |
| BLKpoint_348 | 573.2 | 0.119 | 5720 | 0.278 | 0.149 |
| BLKpoint_363 | 573.2 | 0.119 | 15060 | 0.15 | 0.148 |
| BLKpoint_364 | 573.2 | 0.342 | 3100 | 0.087 | 0.149 |
| BLKpoint_368 | 573.2 | 0.342 | 4280 | 0.31 | 0.167 |
| BLKpoint_373 | 573.2 | 0.342 | 5030 | 1.016 | 0.15 |
| BLKpoint_375 | 573.2 | 0.342 | 5360 | 0.473 | 0.158 |
| BLKpoint_378 | 573.2 | 0.342 | 5830 | 0.681 | 0.149 |
| BLKpoint_388 | 573.2 | 0.342 | 8190 | 0.415 | 0.148 |
| BLKpoint_394 | 573.2 | 0.342 | 15040 | 0.332 | 0.148 |
| BLKpoint_395 | 573.2 | 0.447 | 3030 | 0.087 | 0.149 |
| BLKpoint_398 | 573.2 | 0.447 | 4180 | 0.287 | 0.156 |
| BLKpoint_403 | 573.2 | 0.447 | 5060 | 1.05 | 0.162 |
| BLKpoint_408 | 573.2 | 0.447 | 5420 | 0.605 | 0.149 |
| BLKpoint_411 | 573.2 | 0.447 | 5740 | 0.829 | 0.153 |
| BLKpoint_415 | 573.2 | 0.447 | 6850 | 0.563 | 0.149 |
| BLKpoint_418 | 573.2 | 0.447 | 8320 | 0.458 | 0.148 |
| BLKpoint_422 | 573.2 | 0.447 | 15180 | 0.371 | 0.148 |
| BLKpoint_423 | 573.2 | 0.548 | 3110 | 0.09 | 0.149 |
| BLKpoint_427 | 573.2 | 0.548 | 4380 | 0.347 | 0.183 |
| BLKpoint_433 | 573.2 | 0.548 | 5030 | 0.999 | 0.168 |
| BLKpoint_436 | 573.2 | 0.548 | 5330 | 0.703 | 0.179 |
| BLKpoint_440 | 573.2 | 0.548 | 5720 | 0.902 | 0.148 |
| BLKpoint_447 | 573.2 | 0.548 | 6500 | 0.629 | 0.151 |
| BLKpoint_452 | 573.2 | 0.548 | 7730 | 0.494 | 0.148 |
| BLKpoint_459 | 573.2 | 0.548 | 15070 | 0.375 | 0.148 |
| BLKpoint_460 | 573.2 | 0.646 | 2870 | 0.058 | 0.148 |
| BLKpoint_465 | 573.2 | 0.646 | 4260 | 0.255 | 0.158 |
| BLKpoint_470 | 573.2 | 0.646 | 5020 | 0.857 | 0.178 |
| BLKpoint_474 | 573.2 | 0.646 | 5390 | 0.693 | 0.165 |
| BLKpoint_476 | 573.2 | 0.646 | 5630 | 0.931 | 0.159 |
| BLKpoint_484 | 573.2 | 0.646 | 6530 | 0.589 | 0.149 |
| BLKpoint_489 | 573.2 | 0.646 | 7730 | 0.463 | 0.148 |
| BLKpoint_494 | 573.2 | 0.646 | 15040 | 0.339 | 0.148 |
| BLKpoint_495 | 573.2 | 0.739 | 3350 | 0.07 | 0.149 |
| BLKpoint_498 | 573.2 | 0.739 | 4440 | 0.261 | 0.164 |
| BLKpoint_505 | 573.2 | 0.739 | 5640 | 0.873 | 0.155 |
| BLKpoint_510 | 573.2 | 0.739 | 6410 | 0.531 | 0.15 |
| BLKpoint_517 | 573.2 | 0.739 | 7900 | 0.38 | 0.148 |
| BLKpoint_523 | 573.2 | 0.739 | 15090 | 0.277 | 0.148 |
| BLKpoint_524 | 573.2 | 0.916 | 3290 | 0.001 | 0.148 |
| BLKpoint_528 | 573.2 | 0.916 | 4810 | 0.115 | 0.158 |
| BLKpoint_534 | 573.2 | 0.916 | 5530 | 0.381 | 0.151 |
| BLKpoint_540 | 573.2 | 0.916 | 6140 | 0.206 | 0.15 |
| BLKpoint_547 | 573.2 | 0.916 | 7340 | 0.123 | 0.148 |
| BLKpoint_556 | 573.2 | 0.916 | 14930 | 0.053 | 0.148 |

mode: RDP — 157 of 556 matched rows shown (shape-preserving; block has 556). Quote ONLY shown rows or the stats line; narrow `where` for other rows.
stats (matched, n=556): temperature_k 558.2–573.2 (n=556); mole_fraction_benzene 0.119–0.916 (n=556); pressure_kpa 2870–15180 (n=556); excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol -0.372–3.257 (n=556); excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_u 0.148–0.929 (n=556)
inspection_id: INSP_c0757cb3625b
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```
</details>

**🔀 Stage compaction** (batch of 3 tools)
- 12,244 → 1,061 chars (−91%)

---

### Step 7 [A - L1_1 · c7]: `inspect_block_table`

<details><summary>Arguments</summary>

```json
{
  "block_number": "GLOBlit_4181::PROPblock_2",
  "where": "temperature_k BETWEEN 297 AND 300",
  "purpose": "Ground data values for benzene+cyclohexane H_E at 298.2 K",
  "tasks": "Inspect data rows at T~298.2 K to verify quoted values"
}
```
</details>

- **Result:** 3,152 chars  |  **Time:** 0.1s  |  **Started:** 17:58:41 (t+113.5s)

<details><summary>Result</summary>

```
**Data inspection** — 10.1016/j.jct.2014.05.020 [GLOBlit_4181] :: PROPblock_2 (binary: benzene + cyclohexane)
filter: where temperature_k BETWEEN 297 AND 300
uncertainty: expanded combined (U), level 95 %, evaluated by Data file compiler

| BLKpoint_id | temperature_k | pressure_kpa | mole_fraction_<benzene> | excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol | excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_U |
|---|---|---|---|---|---|
| BLKpoint_1 | 298.2 | 5000 | 0.1189 | 0.318 | 0.0148 |
| BLKpoint_4 | 298.2 | 5000 | 0.2882 | 0.6367 | 0.0139 |
| BLKpoint_6 | 298.2 | 5000 | 0.3955 | 0.744 | 0.0134 |
| BLKpoint_8 | 298.2 | 5000 | 0.4985 | 0.7873 | 0.0133 |
| BLKpoint_10 | 298.2 | 5000 | 0.5976 | 0.7631 | 0.0133 |
| BLKpoint_12 | 298.2 | 5000 | 0.6929 | 0.6925 | 0.0135 |
| BLKpoint_15 | 298.2 | 5000 | 0.8293 | 0.4721 | 0.0149 |
| BLKpoint_17 | 298.2 | 5000 | 0.9162 | 0.257 | 0.0158 |
| BLKpoint_18 | 298.2 | 15000 | 0.1188 | 0.2988 | 0.0143 |
| BLKpoint_20 | 298.2 | 15000 | 0.2879 | 0.6265 | 0.0141 |
| BLKpoint_22 | 298.2 | 15000 | 0.3951 | 0.7434 | 0.0135 |
| BLKpoint_24 | 298.2 | 15000 | 0.4981 | 0.7882 | 0.0133 |
| BLKpoint_26 | 298.2 | 15000 | 0.5972 | 0.7678 | 0.0133 |
| BLKpoint_28 | 298.2 | 15000 | 0.6926 | 0.6849 | 0.0136 |
| BLKpoint_30 | 298.2 | 15000 | 0.7845 | 0.5495 | 0.0144 |
| BLKpoint_32 | 298.2 | 15000 | 0.9161 | 0.2455 | 0.0152 |
| BLKpoint_33 | 298.2 | 25000 | 0.1187 | 0.3012 | 0.0144 |
| BLKpoint_34 | 298.2 | 25000 | 0.2325 | 0.5383 | 0.0141 |
| BLKpoint_35 | 298.2 | 25000 | 0.3418 | 0.698 | 0.0134 |
| BLKpoint_36 | 298.2 | 25000 | 0.4469 | 0.7722 | 0.0131 |
| BLKpoint_37 | 298.2 | 25000 | 0.5479 | 0.7837 | 0.013 |
| BLKpoint_38 | 298.2 | 25000 | 0.6451 | 0.7321 | 0.0133 |
| BLKpoint_40 | 298.2 | 25000 | 0.7843 | 0.5515 | 0.0143 |
| BLKpoint_42 | 298.2 | 25000 | 0.916 | 0.2483 | 0.0154 |
| BLKpoint_205 | 298.2 | 100 | 0.1191 | 0.3207 | 0.0143 |
| BLKpoint_206 | 298.2 | 100 | 0.2332 | 0.5517 | 0.0145 |
| BLKpoint_208 | 298.2 | 100 | 0.3426 | 0.7003 | 0.0134 |
| BLKpoint_210 | 298.2 | 100 | 0.4478 | 0.7782 | 0.0131 |
| BLKpoint_212 | 298.2 | 100 | 0.5488 | 0.7863 | 0.0131 |
| BLKpoint_214 | 298.2 | 100 | 0.6459 | 0.7353 | 0.0133 |
| BLKpoint_216 | 298.2 | 100 | 0.7394 | 0.6282 | 0.0139 |
| BLKpoint_219 | 298.2 | 100 | 0.9163 | 0.2636 | 0.015 |

mode: RDP — 32 of 57 matched rows shown (shape-preserving; block has 219). Quote ONLY shown rows or the stats line; narrow `where` for other rows.
stats (matched, n=57): temperature_k 298.2–298.2 (n=57); pressure_kpa 100–25000 (n=57); mole_fraction_benzene 0.1187–0.9163 (n=57); excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol 0.2455–0.7893 (n=57); excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_u 0.013–0.0158 (n=57)
stats (full block, n=219): temperature_k 298.2–523.2 (n=219); pressure_kpa 100–25000 (n=219); mole_fraction_benzene 0.1187–0.9585 (n=219); excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol 0.0514–0.7893 (n=219); excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol_u 0.0117–0.0158 (n=219)
inspection_id: INSP_4d898e6d2a1a
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```
</details>

---

## Stage Compaction Summary (1 events)

| Iter | Tools | Before | After | Reduction |
|------|-------|--------|-------|-----------|
| 6 | 3 | 12,244 | 1,061 | −91% |

## Tool Compaction Pipeline (13 calls)

| # | Tool | Pipeline | Native | Hardcoded | Agentic | Verdict | Native→Final | Section |
|--:|------|----------|-------:|----------:|--------:|---------|-------------:|---------|
| 1 | `resolve_compound_ids` | query | 600 | 299 | 197 | KEEP | −67% | L1_1 |
| 2 | `search_blocks` | query | 7,349 | 3,026 | 1,067 | KEEP | −85% | L1_1 |
| 3 | `search_blocks` | query | 35,046 | 7,687 | 770 | KEEP | −98% | L1_1 |
| 4 | `inspect_block_table` | query | 1,495 | 493 | 493 | SKIP | −67% | L1_1 |
| 5 | `inspect_block_table` | query | 8,306 | 1,936 | 1,936 | SKIP | −77% | L1_1 |
| 6 | `inspect_block_table` | query | 51,776 | 9,709 | 9,709 | SKIP | −81% | L1_1 |
| 7 | `inspect_block_table` | query | 13,599 | 3,137 | 3,137 | SKIP | −77% | L1_1 |
| 8 | `inspect_block` | analysis | 3,252 | 1,681 | 1,681 | SKIP | −48% | — |
| 9 | `fit_block` | analysis | 410 | 352 | 352 | SKIP | −14% | — |
| 10 | `fit_block` | analysis | 3,254 | 922 | 922 | SKIP | −72% | — |
| 11 | `fit_block` | analysis | 3,280 | 922 | 922 | SKIP | −72% | — |
| 12 | `propose_fitting_plan` | analysis | 1,488 | 898 | 898 | SKIP | −40% | — |
| 13 | `fit_block` | analysis | 3,280 | 922 | 922 | SKIP | −72% | — |

## Subagent Summary (3 events)

| Tool | Verdict | Input Chars | Output Chars | Time | Section |
|------|---------|-------------|-------------|------|---------|
| resolve_compound_ids | KEEP | 299 | 197 | 3.7s | L1_1 |
| search_blocks | KEEP | 3,026 | 1,067 | 13.3s | L1_1 |
| search_blocks | KEEP | 7,687 | 770 | 13.6s | L1_1 |

---

**Total:** 25 tool calls  |  Tool time: 253.6s  |  Wall: 640.6s  |  **Status:** OK


## Saved pipeline state: Completed Fits

The section below is copied verbatim from _working_memory.md; it is saved pipeline state.

~~~~text
### Completed Fits
  - 10.1016/j.jct.2014.05.020/PROPblock_2 (benzene, cyclohexane): RK order=5, R²=0.999977, RMSE=0.0007789449894696996, coeffs=[3.16062, 0.171159, 0.05003, -0.056772, 0.075559, 0.214308]
      response: direct via X = reported X | 0 reference source(s) | kJ/mol -> kJ/mol
      pure refs: benzene=0, cyclohexane=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png
  - 10.1016/j.jct.2014.05.020/PROPblock_2 (benzene, cyclohexane): RK order=5, R²=0.999977, RMSE=0.0007789449894696996, coeffs=[3.16062, 0.171159, 0.05003, -0.056772, 0.075559, 0.214308]
      response: direct via X = reported X | 0 reference source(s) | kJ/mol -> kJ/mol
      pure refs: benzene=0, cyclohexane=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png
  - 10.1016/j.jct.2014.05.020/PROPblock_2 (benzene, cyclohexane): RK order=5, R²=0.999977, RMSE=0.0007789449894696996, coeffs=[3.16062, 0.171159, 0.05003, -0.056772, 0.075559, 0.214308]
      response: direct via X = reported X | 0 reference source(s) | kJ/mol -> kJ/mol
      pure refs: benzene=0, cyclohexane=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png

~~~~
