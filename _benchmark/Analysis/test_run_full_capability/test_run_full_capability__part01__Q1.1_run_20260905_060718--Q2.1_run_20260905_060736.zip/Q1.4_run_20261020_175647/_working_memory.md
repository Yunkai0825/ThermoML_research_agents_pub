# Working Memory

**ROOT:** `N:\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q1.4_run_20261020_175647`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_14 | benzene | 0.0 |
| comp | GLOBcomp_13 | cyclohexane | 0.0 |
| prop | GLOBprop_17 | excessmolarenthalpymolarenthalpyofmixingkjmol |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_3 | pressurekpa |  |
| var | GLOBvar_2 | molefraction<benzene> |  |

### History
- [query_thermoml]
- [inspect_block]
- [fit_block] ERROR: Requested x column 'Mole fraction of benzene' not found in block
- [fit_block]
- [fit_block]
- [propose_fitting_plan]
- [fit_block]

### Query Results
#### query
**L1_query_1** — status: success · validation: FLAGGED(1)

**Summary:**

The ThermoML database contains excess molar enthalpy (Hᴱ) data for benzene + cyclohexane at 298.2 K and 100 kPa in block GLOBlit_4181::PROPblock_2 (DOI: 10.1016/j.jct.2014.05.020), measured by flow calorimetry. Eight data points at these conditions span x(benzene) from 0.1191 to 0.9163, with Hᴱ values (kJ/mol): 0.3207, 0.5517, 0.7003, 0.7782, 0.7863, 0.7353, 0.6282, and 0.2636, respectively, with expanded uncertainties (95% confidence) ranging from 0.0131 to 0.0150 kJ/mol. Mixing is endothermic across the entire composition range, with a maximum Hᴱ of 0.7863 kJ/mol near x(benzene) ≈ 0.55. The full block contains 219 points spanning 298.2–523.2 K and 100–25000 kPa. Comparison of 100 kPa and 5000 kPa data at 298.2 K shows minimal pressure dependence of Hᴱ in the liquid phase (e.g., 0.7863 vs. 0.7873 kJ/mol near equimolar). The slight asymmetry of the curve toward benzene-rich compositions reflects disruption of cyclohexane's dispersion network by benzene's aromatic π-system.

**Answer:**

#### Excess Molar Enthalpy (Hᴱ) Data for Benzene + Cyclohexane at ~298.2 K and ~100 kPa

##### Key Finding

The ThermoML database **does** contain excess molar enthalpy data for benzene (GLOBcomp_14) + cyclohexane (GLOBcomp_13) at 298.2 K and 100 kPa, within block **GLOBlit_4181::PROPblock_2** (DOI: 10.1016/j.jct.2014.05.020).

##### Block Overview (GLOBlit_4181::PROPblock_2)

**WM_L1#1_Table#1_(Analysis_L1#1_Answer):**

| *row_id* | *Field* | *Value* |
|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「DOI」 | 「10.1016/j.jct.2014.05.020 [GLOBlit_4181]」 |
| WM_L1#1_Table#1_Row#2 | 「Block」 | 「PROPblock_2」 |
| WM_L1#1_Table#1_Row#3 | 「Property」 | 「GLOBprop_17 — Excess molar enthalpy (kJ/mol)」 |
| WM_L1#1_Table#1_Row#4 | 「Method」 | 「GLOBmeas_12 — flow calorimetry」 |
| WM_L1#1_Table#1_Row#5 | 「Phase」 | 「Liquid」 |
| WM_L1#1_Table#1_Row#6 | 「Total points」 | 「219」 |
| WM_L1#1_Table#1_Row#7 | 「T range」 | 「298.2–523.2 K」 |
| WM_L1#1_Table#1_Row#8 | 「P range」 | 「100–25000 kPa」 |
| WM_L1#1_Table#1_Row#9 | 「x(benzene) range」 | 「0.1187–0.9585」 |

At T = 298.2 K, there are 57 data points across four pressures (100, 5000, 15000, and 25000 kPa).

##### Data at 298.2 K and 100 kPa (target conditions) — from GLOBlit_4181::PROPblock_2

**WM_L1#1_Table#2_(Analysis_L1#1_Answer):**

| *row_id* | *x(benzene)* | *Hᴱ (kJ/mol)* | *±U (kJ/mol)* |
|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「0.1191」 | 「0.3207」 | 「0.0143」 |
| WM_L1#1_Table#2_Row#2 | 「0.2332」 | 「0.5517」 | 「0.0145」 |
| WM_L1#1_Table#2_Row#3 | 「0.3426」 | 「0.7003」 | 「0.0134」 |
| WM_L1#1_Table#2_Row#4 | 「0.4478」 | 「0.7782」 | 「0.0131」 |
| WM_L1#1_Table#2_Row#5 | 「0.5488」 | 「0.7863」 | 「0.0131」 |
| WM_L1#1_Table#2_Row#6 | 「0.6459」 | 「0.7353」 | 「0.0133」 |
| WM_L1#1_Table#2_Row#7 | 「0.7394」 | 「0.6282」 | 「0.0139」 |
| WM_L1#1_Table#2_Row#8 | 「0.9163」 | 「0.2636」 | 「0.0150」 |

Uncertainties are expanded combined (U) at 95% confidence level.

##### Data at 298.2 K and 5000 kPa — from GLOBlit_4181::PROPblock_2

**WM_L1#1_Table#3_(Analysis_L1#1_Answer):**

| *row_id* | *x(benzene)* | *Hᴱ (kJ/mol)* | *±U (kJ/mol)* |
|---|---|---|---|
| WM_L1#1_Table#3_Row#1 | 「0.1189」 | 「0.318」 | 「0.0148」 |
| WM_L1#1_Table#3_Row#2 | 「0.2882」 | 「0.6367」 | 「0.0139」 |
| WM_L1#1_Table#3_Row#3 | 「0.3955」 | 「0.744」 | 「0.0134」 |
| WM_L1#1_Table#3_Row#4 | 「0.4985」 | 「0.7873」 | 「0.0133」 |
| WM_L1#1_Table#3_Row#5 | 「0.5976」 | 「0.7631」 | 「0.0133」 |
| WM_L1#1_Table#3_Row#6 | 「0.6929」 | 「0.6925」 | 「0.0135」 |
| WM_L1#1_Table#3_Row#7 | 「0.8293」 | 「0.4721」 | 「0.0149」 |
| WM_L1#1_Table#3_Row#8 | 「0.9162」 | 「0.257」 | 「0.0158」 |

##### Other Blocks (not near target conditions)

**WM_L1#1_Table#4_(Analysis_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *Block* | *lit_id* | *T (K)* | *P range (kPa)* | *Phase* |
|---|---|---|---|---|---|---|---|
| WM_L1#1_Table#4_Row#1 | 「2」 | 「10.1016/j.jct.2014.05.020」 | 「PROPblock_3」 | 「GLOBlit_4181」 | 「573.2 (fixed)」 | 「15000–25000」 | 「Fluid」 |
| WM_L1#1_Table#4_Row#2 | 「3」 | 「10.1016/j.jct.2014.07.016」 | 「PROPblock_1」 | 「GLOBlit_4217」 | 「558.2」 | 「up to 14760」 | 「Fluid」 |

These blocks are at much higher temperatures and are not relevant to the 298.2 K target. The lower pressure bound for GLOBlit_4217::PROPblock_1 was not verified in this run.

##### Chemistry Insight (based on GLOBlit_4181::PROPblock_2 data)

The Hᴱ values are positive (endothermic mixing) across the entire composition range, with a maximum near x(benzene) ≈ 0.55 (approximate, based on the inspected rows above) where Hᴱ reaches 0.7863 kJ/mol at 100 kPa. The slightly asymmetric curve (maximum shifted toward benzene-rich compositions) reflects the disruption of cyclohexane's weak dispersion network by benzene's aromatic π-system. Comparing the 100 kPa and 5000 kPa data from GLOBlit_4181::PROPblock_2 at 298.2 K, the Hᴱ values are very similar (e.g., 0.7863 vs. 0.7873 kJ/mol near equimolar), indicating minimal pressure dependence of the excess enthalpy in the liquid phase at this temperature.

**Core claims:**
- The ThermoML database contains excess molar enthalpy (Hᴱ) data for benzene + cyclohexane at 298.2 K and 100 kPa in block GLOBlit_4181::PROPblock_2 (DOI: 10.1016/j.jct.2014.05.020), measured by flow calorimetry in the liquid phase.
- At 298.2 K and 100 kPa, Hᴱ is positive (endothermic mixing) across the entire composition range, with values ranging from 0.2636 kJ/mol at x(benzene) = 0.9163 to 0.7863 kJ/mol at x(benzene) = 0.5488, with expanded combined uncertainties (95% confidence) of approximately 0.013–0.015 kJ/mol.
- The Hᴱ maximum occurs near x(benzene) ≈ 0.55, indicating a slightly asymmetric curve shifted toward benzene-rich compositions.
- Comparing 100 kPa and 5000 kPa data at 298.2 K near equimolar composition (0.7863 vs. 0.7873 kJ/mol), the excess enthalpy shows minimal pressure dependence in the liquid phase at this temperature.

**Core blocks found:**

**WM_L1#1_Blocks_(Analysis_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#5 | 「GLOBlit_4181」 | 「PROPblock_2」 | 「GLOBcomp_14, GLOBcomp_13」 | 「GLOBprop_17」 | 「Excess molar enthalpy data for benzene + cyclohexane covering 298.2–523.2 K and 100–25000 kPa with 219 data points; the primary source for Hᴱ at the target conditions of 298.2 K and 100 kPa.」 |
| WM_L1#1_Table#6 | 「GLOBlit_4181」 | 「PROPblock_3」 | 「GLOBcomp_14, GLOBcomp_13」 | 「GLOBprop_17」 | 「Excess molar enthalpy data for benzene + cyclohexane at 573.2 K and 15000–25000 kPa; noted as not relevant to the 298.2 K target.」 |
| WM_L1#1_Table#7 | 「GLOBlit_4217」 | 「PROPblock_1」 | 「GLOBcomp_14, GLOBcomp_13」 | 「GLOBprop_17」 | 「Excess molar enthalpy data for benzene + cyclohexane at 558.2 K; noted as not relevant to the 298.2 K target.」 |

*Not stored here: 3 verbatim data_inspections table(s); 2 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(1) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **MISATTRIBUTED_VALUE** PROPblock_1: 298.2 does not belong to PROPblock_1; it matches only GLOBlit_4181::PROPblock_2 (inspected this run)


### Inspected Blocks
- GLOBlit_4181 | 10.1016/j.jct.2014.05.020 | PROPblock_2: 219 rows; x=['mole_fraction_<benzene>']; y=['excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol']
    - BLKprop_1 / GLOBprop_17: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_17: kind=direct; materialize_reference=False; supported=True; units=kJ/mol -> kJ/mol

### Completed Fits
  - 10.1016/j.jct.2014.05.020/PROPblock_2 (benzene, cyclohexane): RK order=5, R²=0.999977, RMSE=0.0007789449894696996, coeffs=[3.16062, 0.171159, 0.05003, -0.056772, 0.075559, 0.214308]
      response: direct via X = reported X | 0 reference source(s) | kJ/mol -> kJ/mol
      pure refs: benzene=0, cyclohexane=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png
  - 10.1016/j.jct.2014.05.020/PROPblock_2 (benzene, cyclohexane): RK order=5, R²=0.999977, RMSE=0.0007789449894696996, coeffs=[3.16062, 0.171159, 0.05003, -0.056772, 0.075559, 0.214308]
      response: direct via X = reported X | 0 reference source(s) | kJ/mol -> kJ/mol
      pure refs: benzene=0, cyclohexane=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png
  - 10.1016/j.jct.2014.05.020/PROPblock_2 (benzene, cyclohexane): RK order=5, R²=0.999977, RMSE=0.0007789449894696996, coeffs=[3.16062, 0.171159, 0.05003, -0.056772, 0.075559, 0.214308]
      response: direct via X = reported X | 0 reference source(s) | kJ/mol -> kJ/mol
      pure refs: benzene=0, cyclohexane=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png

## Session Output Files

### data
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q1.4_run_20261020_175647\data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.csv` — RK fit data — 10.1016/j.jct.2014.05.020 PROPblock_2_T298.2
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q1.4_run_20261020_175647\data\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.csv` — Excess property — 10.1016/j.jct.2014.05.020 PROPblock_2_T298.2

### plot
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q1.4_run_20261020_175647\plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_fit.png` — RK fit plot — 10.1016/j.jct.2014.05.020 PROPblock_2_T298.2
- `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q1.4_run_20261020_175647\plots\10_1016_j_jct_2014_05_020_BPROPblock_2_T298.2_excess.png` — Excess plot — 10.1016/j.jct.2014.05.020 PROPblock_2_T298.2

