# Registered deterministic fitting tool calls — verbatim

This archive contains only calls to the six registered fitting tools. Native tool arguments, fixed-tool results, validation failures, and exact saved agent-visible result bodies appear below. A Preview or compacted summary is labeled as such and is not a complete numeric result. The full run history is context and provenance only.


### Step 5 [A · c11]: `fit_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2018.02.022",
  "block_number": "PROPblock_21",
  "property_hint": "viscosity",
  "property_type": "viscosity",
  "mixing_rule": "arrhenius",
  "x_vars": [
    "Mole fraction of ethanol"
  ],
  "y_props": [
    "Viscosity, Pa*s"
  ],
  "x_vars_constrained": {
    "Temperature, K": {
      "value": 293.15,
      "tol": 0.5
    }
  },
  "max_rk_order": 5,
  "purpose": "Fit viscosity vs x(ethanol) at 293.15 K with Arrhenius mixing rule"
}
```
</details>

- **Result:** 287 chars  |  **Time:** 0.0s  |  **Started:** 06:33:30 (t+239.5s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to fit_block: missing a required argument: 'tasks'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---



### Step 6 [A · c12]: `fit_block` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2018.02.022",
  "block_number": "PROPblock_21",
  "property_hint": "viscosity",
  "property_type": "viscosity",
  "mixing_rule": "arrhenius",
  "max_rk_order": 5,
  "purpose": "Fit viscosity vs mole fraction of ethanol at each isotherm (293.15-308.15 K) using Arrhenius mixing rule to locate viscosity maximum composition and its temperature dependence",
  "tasks": [
    "fit_block"
  ]
}
```
</details>

- **Result:** 327 chars  |  **Time:** 0.0s  |  **Started:** 06:33:39 (t+248.6s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_block** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: fit_block.tasks received ['fit_block'] (list); expected <class 'str'>; tool arguments are never coerced

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---



### Step 7 [A · c13]: `fit_block`

<details><summary>Arguments</summary>

```json
{
  "doi": "10.1016/j.jct.2018.02.022",
  "block_number": "PROPblock_21",
  "property_hint": "viscosity",
  "property_type": "viscosity",
  "mixing_rule": "arrhenius",
  "max_rk_order": 5,
  "purpose": "Fit viscosity vs x(ethanol) at each isotherm (293.15-308.15 K) using Arrhenius mixing rule to find viscosity maximum composition and its temperature dependence",
  "tasks": "fit_block",
  "x_vars": [
    "mole_fraction_<ethanol>"
  ],
  "y_props": [
    "viscosity_pa_s"
  ],
  "x_vars_constrained": {
    "temperature_k": {
      "value": 303.15,
      "tol": 0.5
    }
  }
}
```
</details>

- **Result:** 889 chars  |  **Time:** 1.7s  |  **Started:** 06:33:50 (t+260.2s)

<details><summary>Result</summary>

```
**RK Fit** — GLOBlit_5201 / DOI 10.1016/j.jct.2018.02.022 / PROPblock_21 @ declared
Components: ethanol, water | Mixing rule: arrhenius
Points: 23 mixture / 100 total
Property response: BLKprop_1 / GLOBprop_4; kind=direct; equation=X = reported X; reference_sources=0; units=Pa*s -> Pa*s.

| Component | Pure value |
|-----------|-----------|
| ethanol | 0.00099196 |
| water | 0.0008385 |
Pure values: block-edges (water: direct/good, ethanol: direct/good)

BIC-selected order: 5 | R² = 0.998334 | RMSE = 0.00948398 | BIC = -195.46
Coefficients: [2.47975, -2.12, 2.38699, -3.14437, 0.855239, 1.73]

| Order | BIC | R² | RMSE |
|-------|-----|----|------|
| 0 | -64.14 | 0.005633 | 0.231681 |
| 1 | -100.42 | 0.820822 | 0.0983469 |
| 2 | -152.59 | 0.983827 | 0.0295471 |
| 3 | -192.34 | 0.997494 | 0.0116316 |
| 4 | -192.24 | 0.997803 | 0.0108895 |
| 5 | -195.46 | 0.998334 | 0.00948398 |

```
</details>

---



### Step 8 [A · c14]: `fit_multi_system` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "systems": [
    {
      "label": "T=293.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 293.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=298.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 298.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=303.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 303.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=308.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 308.15,
          "tol": 0.5
        }
      }
    }
  ]
}
```
</details>

- **Result:** 303 chars  |  **Time:** 0.0s  |  **Started:** 06:34:07 (t+276.5s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_multi_system** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to fit_multi_system: missing a required argument: 'purpose'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---



### Step 9 [A · c15]: `fit_multi_system` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "purpose": "Fit viscosity of ethanol+water at 4 isotherms to find viscosity maximum composition shift with temperature",
  "systems": [
    {
      "label": "T=293.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 293.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=298.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 298.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=303.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 303.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=308.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 308.15,
          "tol": 0.5
        }
      }
    }
  ]
}
```
</details>

- **Result:** 301 chars  |  **Time:** 0.0s  |  **Started:** 06:34:16 (t+286.1s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_multi_system** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to fit_multi_system: missing a required argument: 'tasks'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---



### Step 10 [A · c16]: `fit_multi_system` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "systems": [
    {
      "label": "T=293.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 293.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=298.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 298.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=303.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 303.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=308.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 308.15,
          "tol": 0.5
        }
      }
    }
  ],
  "purpose": "Fit viscosity of ethanol+water at each isotherm to locate viscosity maximum composition and its temperature dependence",
  "tasks": [
    "fit_data"
  ]
}
```
</details>

- **Result:** 340 chars  |  **Time:** 0.0s  |  **Started:** 06:34:42 (t+311.9s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_multi_system** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: fit_multi_system.tasks received ['fit_data'] (list); expected <class 'str'>; tool arguments are never coerced

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---



### Step 11 [A · c17]: `fit_multi_system`

<details><summary>Arguments</summary>

```json
{
  "systems": [
    {
      "label": "T=293.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 293.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=298.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 298.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=303.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 303.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=308.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "Temperature, K": {
          "value": 308.15,
          "tol": 0.5
        }
      }
    }
  ],
  "purpose": "Fit viscosity of ethanol+water at each isotherm to find viscosity maximum composition and its temperature dependence",
  "tasks": "fit_data"
}
```
</details>

- **Result:** 758 chars  |  **Time:** 0.2s  |  **Started:** 06:34:52 (t+321.6s)

<details><summary>Result</summary>

```
**Multi-system RK Fit** — 4 systems
Errors: T=293.15K: Constraint column 'Temperature, K' not found in block; T=303.15K: Constraint column 'Temperature, K' not found in block; T=298.15K: Constraint column 'Temperature, K' not found in block; T=308.15K: Constraint column 'Temperature, K' not found in block

| Label | DOI | Block | Components | Order | R² | RMSE | n pts |
|-------|-----|-------|------------|-------|----|------|-------|
| T=293.15K | — | — | — | ERROR: Constraint column 'Temperature, K' not f | | |
| T=298.15K | — | — | — | ERROR: Constraint column 'Temperature, K' not f | | |
| T=303.15K | — | — | — | ERROR: Constraint column 'Temperature, K' not f | | |
| T=308.15K | — | — | — | ERROR: Constraint column 'Temperature, K' not f | | |

```
</details>

---



### Step 12 [A · c18]: `fit_multi_system` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "systems": [
    {
      "label": "T=293.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 293.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=298.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 298.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=303.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 303.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=308.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 308.15,
          "tol": 0.5
        }
      }
    }
  ]
}
```
</details>

- **Result:** 303 chars  |  **Time:** 0.0s  |  **Started:** 06:35:01 (t+330.9s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_multi_system** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to fit_multi_system: missing a required argument: 'purpose'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---



### Step 13 [A · c19]: `fit_multi_system` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "purpose": "Fit viscosity of ethanol+water at 4 isotherms to track viscosity maximum composition shift with temperature",
  "systems": [
    {
      "label": "T=293.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 293.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=298.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 298.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=303.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 303.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=308.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 308.15,
          "tol": 0.5
        }
      }
    }
  ]
}
```
</details>

- **Result:** 301 chars  |  **Time:** 0.0s  |  **Started:** 06:35:12 (t+341.9s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_multi_system** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: invalid call to fit_multi_system: missing a required argument: 'tasks'

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---



### Step 14 [A · c20]: `fit_multi_system` 🔒 VALIDATION BLOCKED

<details><summary>Arguments</summary>

```json
{
  "systems": [
    {
      "label": "T=293.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 293.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=298.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 298.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=303.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 303.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=308.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "max_rk_order": 5,
      "x_vars_constrained": {
        "temperature_k": {
          "value": 308.15,
          "tol": 0.5
        }
      }
    }
  ],
  "purpose": "Fit viscosity of ethanol+water at each of 4 isotherms to track viscosity maximum composition shift with temperature",
  "tasks": [
    "fit_data"
  ]
}
```
</details>

- **Result:** 340 chars  |  **Time:** 0.0s  |  **Started:** 06:35:23 (t+352.4s)
- **Status:** blocked

<details><summary>Validation detail</summary>

```
**✗ fit_multi_system** — tool syntax or arguments need correction:
TOOL_ARGUMENT_REFINEMENT_REQUIRED: fit_multi_system.tasks received ['fit_data'] (list); expected <class 'str'>; tool arguments are never coerced

_No tool in this batch executed. Re-emit the complete batch with only registered tool names and exact declared JSON arguments._
```
</details>

---



### Step 15 [A · c21]: `fit_multi_system`

<details><summary>Arguments</summary>

```json
{
  "systems": [
    {
      "label": "T=293.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "x_vars_constrained": {
        "temperature_k": {
          "value": 293.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=298.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "x_vars_constrained": {
        "temperature_k": {
          "value": 298.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=303.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "x_vars_constrained": {
        "temperature_k": {
          "value": 303.15,
          "tol": 0.5
        }
      }
    },
    {
      "label": "T=308.15K",
      "doi": "10.1016/j.jct.2018.02.022",
      "block_number": "PROPblock_21",
      "property_hint": "viscosity",
      "property_type": "viscosity",
      "mixing_rule": "arrhenius",
      "x_vars_constrained": {
        "temperature_k": {
          "value": 308.15,
          "tol": 0.5
        }
      }
    }
  ],
  "purpose": "Fit viscosity of ethanol+water at each of 4 isotherms to locate viscosity maximum composition and its temperature dependence",
  "tasks": "fit_data"
}
```
</details>

- **Result:** 2,088 chars  |  **Time:** 5.7s  |  **Started:** 06:35:31 (t+360.9s)

<details><summary>Result</summary>

```
**Multi-system RK Fit** — 4 systems

| Label | DOI | Block | Components | Order | R² | RMSE | n pts |
|-------|-----|-------|------------|-------|----|------|-------|
| T=293.15K | GLOBlit_5201 / DOI 10.1016/j.jct.2018.02.022 | PROPblock_21 @ declared | ethanol, water | 5 | 0.996870 | 0.0149466 | 23 |
| T=298.15K | GLOBlit_5201 / DOI 10.1016/j.jct.2018.02.022 | PROPblock_21 @ declared | ethanol, water | 4 | 0.999334 | 0.00661284 | 23 |
| T=303.15K | GLOBlit_5201 / DOI 10.1016/j.jct.2018.02.022 | PROPblock_21 @ declared | ethanol, water | 5 | 0.998334 | 0.00948398 | 23 |
| T=308.15K | GLOBlit_5201 / DOI 10.1016/j.jct.2018.02.022 | PROPblock_21 @ declared | ethanol, water | 5 | 0.997541 | 0.0106696 | 23 |

**T=293.15K** coeffs: [2.77791, -2.36884, 2.91661, -4.2245, 0.924678, 2.75595]
Property response: BLKprop_1 / GLOBprop_4; kind=direct; equation=X = reported X; reference_sources=0; units=Pa*s -> Pa*s.
  pure values (x = mole_fraction_<ethanol>): ethanol=0.0012019, water=0.0010673
  source: block-edges (water: direct/good, ethanol: direct/good)

**T=298.15K** coeffs: [2.728, -2.49259, 2.55005, -2.44775, 1.53644]
Property response: BLKprop_1 / GLOBprop_4; kind=direct; equation=X = reported X; reference_sources=0; units=Pa*s -> Pa*s.
  pure values (x = mole_fraction_<ethanol>): ethanol=0.0010914, water=0.00089689
  source: block-edges (water: direct/good, ethanol: direct/good)

**T=303.15K** coeffs: [2.47975, -2.12, 2.38699, -3.14437, 0.855239, 1.73]
Property response: BLKprop_1 / GLOBprop_4; kind=direct; equation=X = reported X; reference_sources=0; units=Pa*s -> Pa*s.
  pure values (x = mole_fraction_<ethanol>): ethanol=0.00099196, water=0.0008385
  source: block-edges (water: direct/good, ethanol: direct/good)

**T=308.15K** coeffs: [2.33015, -1.95628, 2.03149, -2.8161, 0.891963, 1.5752]
Property response: BLKprop_1 / GLOBprop_4; kind=direct; equation=X = reported X; reference_sources=0; units=Pa*s -> Pa*s.
  pure values (x = mole_fraction_<ethanol>): ethanol=0.00090388, water=0.00075887
  source: block-edges (water: direct/good, ethanol: direct/good)

```
</details>

---



### Step 16 [A · c22]: `predict_from_rk`

<details><summary>Arguments</summary>

```json
{
  "coeffs": [
    2.77791,
    -2.36884,
    2.91661,
    -4.2245,
    0.924678,
    2.75595
  ],
  "pure_values": {
    "ethanol": 0.0012019,
    "water": 0.0010673
  },
  "property_type": "viscosity",
  "n_points": 201,
  "mixing_rule": "arrhenius",
  "purpose": "Predict viscosity curve at 293.15 K to find maximum composition",
  "tasks": "Generate fine-grained viscosity vs x(ethanol) curve at 293.15 K"
}
```
</details>

- **Result:** 213 chars  |  **Time:** 0.1s  |  **Started:** 06:35:46 (t+375.3s)

<details><summary>Result</summary>

```
**RK Prediction** (order 5, arrhenius)
Components: ethanol, water | 201 grid points
Y(x=0) = 0.0010673, Y(x=0.5) ≈ 0.00226822, Y(x=1) = 0.0012019
Y_max = 0.00291801 at x1 = 0.23
Max |excess| (ln-space) = 0.978559

```
</details>

---



### Step 17 [A · c23]: `predict_from_rk`

<details><summary>Arguments</summary>

```json
{
  "coeffs": [
    2.728,
    -2.49259,
    2.55005,
    -2.44775,
    1.53644
  ],
  "pure_values": {
    "ethanol": 0.0010914,
    "water": 0.00089689
  },
  "property_type": "viscosity",
  "n_points": 201,
  "mixing_rule": "arrhenius",
  "purpose": "Predict viscosity curve at 298.15 K to find maximum composition",
  "tasks": "predict"
}
```
</details>

- **Result:** 213 chars  |  **Time:** 0.1s  |  **Started:** 06:35:56 (t+385.9s)

<details><summary>Result</summary>

```
**RK Prediction** (order 4, arrhenius)
Components: ethanol, water | 201 grid points
Y(x=0) = 0.00089689, Y(x=0.5) ≈ 0.00195682, Y(x=1) = 0.0010914
Y_max = 0.00241411 at x1 = 0.24
Max |excess| (ln-space) = 0.94479

```
</details>

---



### Step 18 [A · c24]: `predict_from_rk`

<details><summary>Arguments</summary>

```json
{
  "coeffs": [
    2.47975,
    -2.12,
    2.38699,
    -3.14437,
    0.855239,
    1.73
  ],
  "pure_values": {
    "ethanol": 0.00099196,
    "water": 0.0008385
  },
  "property_type": "viscosity",
  "n_points": 201,
  "mixing_rule": "arrhenius",
  "purpose": "Predict viscosity curve at 303.15 K to find maximum composition",
  "tasks": "predict_from_rk"
}
```
</details>

- **Result:** 215 chars  |  **Time:** 0.3s  |  **Started:** 06:36:05 (t+394.7s)

<details><summary>Result</summary>

```
**RK Prediction** (order 5, arrhenius)
Components: ethanol, water | 201 grid points
Y(x=0) = 0.0008385, Y(x=0.5) ≈ 0.00169525, Y(x=1) = 0.00099196
Y_max = 0.00204497 at x1 = 0.245
Max |excess| (ln-space) = 0.851675

```
</details>

---



### Step 19 [A · c25]: `predict_from_rk`

<details><summary>Arguments</summary>

```json
{
  "coeffs": [
    2.33015,
    -1.95628,
    2.03149,
    -2.8161,
    0.891963,
    1.5752
  ],
  "pure_values": {
    "ethanol": 0.00090388,
    "water": 0.00075887
  },
  "property_type": "viscosity",
  "n_points": 201,
  "purpose": "Predict viscosity curve at 308.15 K to locate maximum composition",
  "tasks": "predict_from_rk"
}
```
</details>

- **Result:** 214 chars  |  **Time:** 0.1s  |  **Started:** 06:36:15 (t+405.0s)

<details><summary>Result</summary>

```
**RK Prediction** (order 5, arrhenius)
Components: ethanol, water | 201 grid points
Y(x=0) = 0.00075887, Y(x=0.5) ≈ 0.00148297, Y(x=1) = 0.00090388
Y_max = 0.0017342 at x1 = 0.25
Max |excess| (ln-space) = 0.784068

```
</details>

---

