# Analysis Run — [run id removed] (Round 1)

**Question:** At 25 °C, at what ethanol mole fraction is the viscosity of liquid ethanol + water greatest, and how does that composition shift as temperature rises?

**[run statistics removed]**

---

## Answer

## Viscosity Maximum in Ethanol + Water Mixtures: Composition and Temperature Dependence

### Data Source

All results are from DOI **10.1016/j.jct.2018.02.022** (GLOBlit_5201), block **PROPblock_21** — dynamic viscosity of liquid ethanol + water measured by concentric-cylinders viscometry at 92.3 kPa. The block contains **100 data points** spanning four isotherms (293.15–308.15 K) over the full ethanol mole-fraction range (0 to 1), with 23 mixture compositions per isotherm.

---

### At 25 °C (298.15 K): Where Is the Viscosity Greatest?

From the Redlich-Kister fit (Arrhenius mixing rule, BIC-selected order 4, R² = 0.999334, RMSE = 0.00661), the **viscosity maximum occurs at x(ethanol) ≈ 0.24**, with a predicted peak viscosity of **0.00241 Pa·s** (2.41 mPa·s).

This is roughly **2.7× the viscosity of pure water** (0.000897 Pa·s) and **2.2× that of pure ethanol** (0.001091 Pa·s) at the same temperature — a dramatic enhancement arising from strong ethanol–water hydrogen-bonding interactions that create structured, less mobile molecular clusters at intermediate compositions.

Representative inspected data points at 298.15 K confirm the maximum near x ≈ 0.25:

| x(ethanol) | Viscosity (Pa·s) |
|:----------:|:----------------:|
| 0          | 0.00089689       |
| 0.1004     | 0.0019469        |
| 0.1984     | 0.0023706        |
| **0.2499** | **0.0024286**    |
| 0.3499     | 0.0022633        |
| 0.4989     | 0.0019557        |
| 1          | 0.0010914        |

---

### How Does the Maximum Shift with Temperature?

Redlich-Kister fits (Arrhenius mixing rule) were performed independently at each of the four isotherms. The predicted viscosity-maximum composition and peak value are:

| T (K) | RK Order | R² | x(ethanol) at η_max | η_max (Pa·s) | Max ln-excess |
|:------:|:--------:|:------:|:-------------------:|:------------:|:-------------:|
| 293.15 | 5 | 0.99687 | **0.230** | 0.00292 | 0.979 |
| 298.15 | 4 | 0.99933 | **0.240** | 0.00241 | 0.945 |
| 303.15 | 5 | 0.99833 | **0.245** | 0.00204 | 0.852 |
| 308.15 | 5 | 0.99754 | **0.250** | 0.00173 | 0.784 |

**Key trends as temperature rises from 293 to 308 K:**

1. **The maximum shifts to higher ethanol mole fractions** — from x ≈ 0.23 at 293 K to x ≈ 0.25 at 308 K (a shift of about +0.02 in mole fraction over 15 K).

2. **The peak viscosity drops sharply** — from 0.00292 Pa·s at 293 K to 0.00173 Pa·s at 308 K (a ~41% decrease), consistent with the general Arrhenius-type thermal activation of molecular mobility.

3. **The excess viscosity (ln-space) diminishes** — the maximum ln-excess decreases from 0.979 to 0.784, indicating that the hydrogen-bonding network responsible for the anomalous viscosity enhancement becomes progressively disrupted at higher temperatures.

---

### Redlich-Kister Coefficients (Arrhenius Mixing Rule)

The fitted model is: ln η_mix = x₁ ln η₁ + x₂ ln η₂ + x₁ x₂ Σᵢ Aᵢ (x₁ − x₂)ⁱ, where x₁ = x(ethanol).

| T (K) | A₀ | A₁ | A₂ | A₃ | A₄ | A₅ |
|:------:|:------:|:------:|:------:|:------:|:------:|:------:|
| 293.15 | 2.778 | −2.369 | 2.917 | −4.225 | 0.925 | 2.756 |
| 298.15 | 2.728 | −2.493 | 2.550 | −2.448 | 1.536 | — |
| 303.15 | 2.480 | −2.120 | 2.387 | −3.144 | 0.855 | 1.730 |
| 308.15 | 2.330 | −1.956 | 2.031 | −2.816 | 0.892 | 1.575 |

Pure-component values used (Pa·s):

| T (K) | η(water) | η(ethanol) |
|:------:|:--------:|:----------:|
| 293.15 | 0.0010673 | 0.0012019 |
| 298.15 | 0.00089689 | 0.0010914 |
| 303.15 | 0.0008385 | 0.00099196 |
| 308.15 | 0.00075887 | 0.00090388 |

---

### Physical Interpretation

The viscosity maximum near x(ethanol) ≈ 0.23–0.25 corresponds to roughly 1 ethanol molecule per 3–4 water molecules — a stoichiometry that maximizes the formation of extended hydrogen-bonded clusters (often described as ethanol–water clathrate-like structures). As temperature increases, thermal energy progressively disrupts these clusters, which has two effects: (i) the overall viscosity drops, and (ii) the optimal cluster-forming composition shifts slightly toward higher ethanol content (from 0.23 to 0.25), suggesting that at higher temperatures a somewhat higher ethanol concentration is needed to sustain the cooperative hydrogen-bonding network that produces the viscosity anomaly.

### Core claims

- For ethanol + water mixtures at 298.15 K and 92.3 kPa, the dynamic viscosity maximum occurs at x(ethanol) ≈ 0.24 with a predicted peak viscosity of 0.00241 Pa·s, roughly 2.7× the viscosity of pure water (0.000897 Pa·s) and 2.2× that of pure ethanol (0.001091 Pa·s) at the same temperature.
- As temperature increases from 293.15 K to 308.15 K, the viscosity-maximum composition shifts to higher ethanol mole fractions, from x ≈ 0.230 to x ≈ 0.250.
- The peak viscosity drops sharply with increasing temperature, from 0.00292 Pa·s at 293.15 K to 0.00173 Pa·s at 308.15 K, consistent with Arrhenius-type thermal activation.
- The maximum ln-excess viscosity decreases from 0.979 at 293.15 K to 0.784 at 308.15 K, indicating progressive disruption of the hydrogen-bonding network responsible for the anomalous viscosity enhancement at higher temperatures.
- All results are derived from DOI 10.1016/j.jct.2018.02.022, block PROPblock_21, containing 100 data points across four isotherms (293.15–308.15 K) fitted with Redlich-Kister polynomials using an Arrhenius mixing rule (R² ≥ 0.99687 at all temperatures).

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21 |  | This block provides the dynamic viscosity of ethanol + water mixtures (100 data points, concentric-cylinders viscometry, 92.3 kPa) across four isotherms (293.15–308.15 K) and the full mole-fraction range (0–1). It is the sole data source for identifying the viscosity maximum near x(ethanol) ≈ 0.24 at 298.15 K and for characterizing how the peak composition and magnitude shift with temperature. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5201 | PROPblock_21 | GLOBprop_4 | 5 | 2.4797538236283185; -2.120004189707748; 2.386992245605703; -3.1443732454296387; 0.8552391192599589; 1.7300032296545247 | 0.998334 | 0.00948397542567419 | 23 | 303.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_5201 | PROPblock_21 | T=293.15K | 5 | 2.777909177194302; -2.3688378692354166; 2.9166124577732813; -4.224496287203014; 0.9246777491739545; 2.7559484465319213 | 0.99687 | 0.014946647676868378 | 23 | 293.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_5201 | PROPblock_21 | T=298.15K | 4 | 2.7279958938647066; -2.4925941810857495; 2.5500472215385774; -2.4477499128574456; 1.53644421556371 | 0.999334 | 0.006612838327445672 | 23 | 298.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_5201 | PROPblock_21 | T=303.15K | 5 | 2.4797538236283185; -2.120004189707748; 2.386992245605703; -3.1443732454296387; 0.8552391192599589; 1.7300032296545247 | 0.998334 | 0.00948397542567419 | 23 | 303.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_5201 | PROPblock_21 | T=308.15K | 5 | 2.33015003706876; -1.9562817730603848; 2.0314890727451007; -2.8160995147026564; 0.8919625893625028; 1.5752024920398033 | 0.997541 | 0.010669590029158437 | 23 | 308.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
