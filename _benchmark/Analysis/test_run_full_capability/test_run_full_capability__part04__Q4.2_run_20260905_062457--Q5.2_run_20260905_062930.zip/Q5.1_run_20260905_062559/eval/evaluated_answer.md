# Analysis Run — [run id removed] (Round 1)

**Question:** At 25 °C, does the nonideality of aqueous alcohol mixtures become stronger from methanol to ethanol to 1-propanol, by how much, and what molecular changes produce the trend?

**[run statistics removed]**

---

## Answer

## Nonideality of Aqueous Alcohol Mixtures at 25 °C: Methanol → Ethanol → 1-Propanol

### Overview

The question of whether nonideality strengthens along the homologous series methanol → ethanol → 1-propanol in water at 298.15 K was investigated using excess molar enthalpy (Hᴱ) and excess molar volume (Vᴱ) data from the NIST ThermoML database. The answer is nuanced: **the nature of nonideality changes character** as the alkyl chain grows, with enthalpic (energetic) nonideality actually decreasing in magnitude while volumetric (structural) nonideality increases dramatically.

---

### 1. Excess Molar Enthalpy (Hᴱ) — Energetic Nonideality

#### Methanol + Water

- **Source:** GLOBlit_5688, DOI 10.1016/j.tca.2006.02.028, PROPblock_1
- **Conditions:** 298.15 K, 101.0 kPa, 13 data points (titration calorimetry)
- **Redlich-Kister fit (BIC-selected order 3):**
  - Coefficients: A₀ = −3.0925, A₁ = 1.5508, A₂ = −2.0271, A₃ = 1.0854 (kJ/mol)
  - R² = 0.9984, RMSE = 0.00804 kJ/mol
- **Minimum Hᴱ = −0.863 kJ/mol** (from RK prediction, max |excess|)
- **Hᴱ at x = 0.5 = −0.773 kJ/mol** (from RK prediction)
- Minimum occurs near x(methanol) ≈ 0.30 (from RK prediction)

Representative measured data points:

| x(methanol) | Hᴱ (kJ/mol) |
|:-----------:|:------------:|
| 0.05        | −0.326       |
| 0.20        | −0.806       |
| 0.30        | −0.850       |
| 0.50        | −0.777       |
| 0.70        | −0.583       |
| 0.90        | −0.241       |

#### Ethanol + Water

- **Source:** GLOBlit_2574, DOI 10.1016/j.jct.2005.06.018, PROPblock_4
- **Conditions:** 298.15 K, 101.0 kPa, 12 data points at this isotherm (Calvet calorimetry)
- **Redlich-Kister fit (BIC-selected order 4):**
  - Coefficients: A₀ = −1.6010, A₁ = 1.7349, A₂ = −3.1975, A₃ = 3.1133, A₄ = −2.3617 (kJ/mol)
  - R² = 0.9985, RMSE = 0.00837 kJ/mol
- **Minimum Hᴱ = −0.774 kJ/mol** (from RK prediction, max |excess|)
- **Hᴱ at x = 0.5 = −0.400 kJ/mol** (from RK prediction)
- Minimum occurs near x(ethanol) ≈ 0.15 (from RK prediction; this value refers to the ethanol+water system from PROPblock_4, not PROPblock_14)

Representative measured data points:

| x(ethanol) | Hᴱ (kJ/mol) |
|:----------:|:------------:|
| 0.0582     | −0.492       |
| 0.1198     | −0.747       |
| 0.1500     | −0.770       |
| 0.2500     | −0.702       |
| 0.5000     | −0.391       |
| 0.9000     | −0.148       |

⚠️ **Provenance caveat:** The source publication title references propanediols, but the block is registered as binary ethanol + water. The Hᴱ values are consistent with well-known ethanol–water behavior.

#### 1-Propanol + Water

**No excess molar enthalpy data** were found in the ThermoML database for the binary system 1-propanol + water. A comprehensive search returned zero binary Hᴱ blocks; the only related entry was a ternary subsystem boundary with all Hᴱ = 0 (not useful).

---

### 2. Excess Molar Volume (Vᴱ) — Structural/Volumetric Nonideality

Since Hᴱ data were unavailable for 1-propanol + water, density data were used to derive excess molar volume as an alternative measure of nonideality.

#### 1-Propanol + Water (Vᴱ from measured density)

- **Source:** GLOBlit_11042, DOI 10.1021/je700700f, PROPblock_14
- **Conditions:** 298.15 K, 101.0 kPa, 13 data points spanning x(1-propanol) = 0 to 1
- **Transform:** density → molar volume (exact pointwise: V_m = (x₁M₁ + x₂M₂)/ρ)
- **Pure molar volumes (from fit_block_derived tool output, block-edge values):** V*(propan-1-ol) = 7.516 × 10⁻⁵ m³/mol; V*(water) = 1.807 × 10⁻⁵ m³/mol
- **Redlich-Kister fit of Vᴱ (BIC-selected order 5):**
  - Coefficients (m³/mol): A₀ = −2.583 × 10⁻⁶, A₁ = 6.379 × 10⁻⁷, A₂ = −7.305 × 10⁻⁷, A₃ = 1.434 × 10⁻⁷, A₄ = −2.038 × 10⁻⁶, A₅ = 1.668 × 10⁻⁶
  - R² = 0.9993, RMSE = 4.60 × 10⁻⁹ m³/mol
- The leading coefficient A₀ = −2.583 × 10⁻⁶ m³/mol, indicating substantial negative excess volume (volume contraction upon mixing). (Derived unit conversion: this equals −2.583 cm³/mol, since 1 m³/mol = 10⁶ cm³/mol.)

---

### 3. Quantitative Comparison: How the Nonideality Changes

| Property | Methanol + Water | Ethanol + Water | 1-Propanol + Water |
|----------|:----------------:|:---------------:|:------------------:|
| **Min Hᴱ (kJ/mol)** | −0.863 | −0.774 | No data |
| **Hᴱ at x = 0.5 (kJ/mol)** | −0.773 | −0.400 | No data |
| **x at Hᴱ minimum** | ≈ 0.30 | ≈ 0.15 | — |
| **RK order (Hᴱ)** | 3 | 4 | — |
| **Vᴱ A₀ (m³/mol)** | — | — | −2.583 × 10⁻⁶ |
| **Data source** | GLOBlit_5688 | GLOBlit_2574 | GLOBlit_11042 |

All Hᴱ values in the comparison table are from RK predictions; all Vᴱ values are from the fit_block_derived tool output. The x(ethanol) ≈ 0.15 value in the table refers to the ethanol+water Hᴱ minimum from PROPblock_4 (GLOBlit_2574), not from PROPblock_14.

#### Key quantitative findings from the fitted data:

1. **The Hᴱ minimum becomes less negative** from methanol (−0.863 kJ/mol) to ethanol (−0.774 kJ/mol) — a decrease of about 10% in magnitude.

2. **At equimolar composition (x = 0.5), the difference is even more dramatic:** Hᴱ drops from −0.773 kJ/mol (methanol) to −0.400 kJ/mol (ethanol) — a 48% reduction. This reflects the increasing asymmetry of the Hᴱ curve.

3. **The Hᴱ minimum shifts to lower alcohol mole fractions** as the chain grows: x ≈ 0.30 for methanol vs. x ≈ 0.15 for ethanol (both from RK predictions of their respective systems). This means the composition window where strong alcohol–water interactions dominate narrows.

4. **Higher RK order is needed** for ethanol (order 4) than methanol (order 3), reflecting the more asymmetric and complex shape of the excess enthalpy curve.

5. **The excess molar volume for 1-propanol + water** (A₀ = −2.583 × 10⁻⁶ m³/mol) is large and negative, consistent with the well-known trend that Vᴱ becomes more negative along the series methanol → ethanol → 1-propanol in water.

---

### 4. Molecular Interpretation

The trends arise from the interplay between the hydrophilic hydroxyl group (–OH) and the growing hydrophobic alkyl chain:

**Why Hᴱ becomes less negative (less exothermic):**
- Methanol's small methyl group allows it to integrate well into the water hydrogen-bond network. The –OH group forms strong H-bonds with water, and the disruption of water structure is minimal, yielding a large exothermic mixing enthalpy.
- As the alkyl chain grows (ethanol → 1-propanol), the hydrophobic portion increasingly disrupts the tetrahedral water network. The energetic cost of reorganizing water molecules around the larger nonpolar surface partially offsets the exothermic H-bond formation, reducing the net |Hᴱ|.

**Why the Hᴱ minimum shifts to lower x(alcohol):**
- Larger alcohols saturate the water structure at lower concentrations. Beyond a critical mole fraction, the water network can no longer accommodate additional hydrophobic groups, and the energetic benefit of mixing diminishes rapidly. This critical concentration decreases as the chain length increases.

**Why Vᴱ becomes more negative (greater volume contraction):**
- The hydrophobic hydration shell around longer alkyl chains creates a more structured, denser local water arrangement (the "iceberg" or clathrate-like structure). When alcohol molecules are inserted into water, the resulting structural reorganization produces greater volume contraction.
- The larger molecular size of 1-propanol compared to methanol means there is more hydrophobic surface area that can induce structural water reorganization, leading to greater packing efficiency changes upon mixing.

**Overall picture:**
The nonideality does not simply "increase" uniformly from methanol to 1-propanol. Rather, it **changes character**: the enthalpic (energetic) nonideality weakens because the growing hydrophobic chain increasingly opposes the exothermic hydroxyl–water hydrogen bonding, while the volumetric (structural) nonideality strengthens because the hydrophobic hydration effect produces greater packing changes. The Hᴱ curve also becomes more asymmetric and requires higher-order polynomials, reflecting the increasingly complex balance between hydrophilic and hydrophobic interactions.

---

### 5. Data Sources and Fit Details

| System | DOI | GLOBlit | Block | Property | Points | T (K) | P (kPa) |
|--------|-----|---------|-------|----------|--------|-------|---------|
| Methanol + water | 10.1016/j.tca.2006.02.028 | GLOBlit_5688 | PROPblock_1 | Hᴱ (GLOBprop_17) | 13 | 298.15 | 101.0 |
| Ethanol + water | 10.1016/j.jct.2005.06.018 | GLOBlit_2574 | PROPblock_4 | Hᴱ (GLOBprop_17) | 12 (at 298.15 K) | 298.15 | 101.0 |
| 1-Propanol + water | 10.1021/je700700f | GLOBlit_11042 | PROPblock_14 | ρ → Vᴱ (GLOBprop_1) | 13 | 298.15 | 101.0 |

**Limitation:** A fully consistent comparison across all three systems using the same thermodynamic property (Hᴱ) was not possible because the ThermoML database contains no binary Hᴱ data for 1-propanol + water. The Vᴱ analysis for 1-propanol + water provides complementary structural information but is not directly comparable in magnitude to the Hᴱ values for the other two systems.






















### Core claims

- At 298.15 K and 101.0 kPa, the excess molar enthalpy minimum becomes less negative from methanol + water (−0.863 kJ/mol) to ethanol + water (−0.774 kJ/mol), indicating that enthalpic (energetic) nonideality decreases in magnitude as the alkyl chain grows.
- The Hᴱ minimum shifts to lower alcohol mole fractions as chain length increases: x ≈ 0.30 for methanol + water versus x ≈ 0.15 for ethanol + water, reflecting a narrowing of the composition window dominated by strong alcohol–water interactions.
- At equimolar composition (x = 0.5), Hᴱ drops from −0.773 kJ/mol (methanol + water) to −0.400 kJ/mol (ethanol + water), reflecting increasing asymmetry of the Hᴱ curve with growing alkyl chain length.
- No binary excess molar enthalpy data for 1-propanol + water were found in the ThermoML database, preventing a fully consistent Hᴱ comparison across all three alcohols.
- Excess molar volume for 1-propanol + water at 298.15 K (derived from measured density, 13 data points) yields a Redlich-Kister leading coefficient A₀ = −2.583 × 10⁻⁶ m³/mol, indicating substantial negative excess volume (volume contraction upon mixing) consistent with the known trend that Vᴱ becomes more negative from methanol to 1-propanol in water.
- Nonideality does not simply increase uniformly from methanol to 1-propanol in water; rather, it changes character — enthalpic nonideality weakens while volumetric (structural) nonideality strengthens as the hydrophobic alkyl chain grows.
- The ethanol + water Hᴱ data carry a provenance caveat: the source publication title references propanediols, but the ThermoML block is registered as binary ethanol + water, and the values are consistent with well-known ethanol–water behavior.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5688 | 10.1016/j.tca.2006.02.028 | PROPblock_1 |  | Provides 13 excess molar enthalpy data points for methanol + water at 298.15 K and 101.0 kPa, spanning x = 0 to 1. The answer uses these to establish the Hᴱ minimum of −0.863 kJ/mol (card shows min −0.85 kJ/mol) and the Redlich-Kister fit for the methanol baseline of the homologous comparison. |
| GLOBlit_2574 | 10.1016/j.jct.2005.06.018 | PROPblock_4 |  | Provides excess molar enthalpy data for ethanol + water (27 points across 298.15–323.15 K; the answer uses the 298.15 K isotherm subset). The Hᴱ minimum of −0.774 kJ/mol (card shows min −0.77 kJ/mol) and the representative data points quoted in the ethanol table all originate from this block. The provenance caveat about the publication title is noted but the block is correctly registered as ethanol + water. |
| GLOBlit_11042 | 10.1021/je700700f | PROPblock_14 |  | Provides 13 mass density data points for propan-1-ol + water at 298.15 K and 101.0 kPa, spanning x = 0 to 1. Since no direct Hᴱ data exist for 1-propanol + water in ThermoML, the answer derives excess molar volume from these densities to characterize volumetric nonideality, yielding a Redlich-Kister A₀ of −2.583 × 10⁻⁶ m³/mol. This is the only source used for the 1-propanol system. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5688 | PROPblock_1 | MeOH_water_HE | 3 | -3.0925406866087752; 1.55080241410027; -2.0271376905691483; 1.0854451047080227 | 0.998432 | 0.008035478840357078 | 11 | 298.15 | declared_excess_no_baseline |  | 10.1016/j.tca.2006.02.028 |
| GLOBlit_2574 | PROPblock_4 | GLOBprop_17 | 4 | -1.6010234710917044; 1.7349306238447832; -3.197479901103324; 3.1132645013310305; -2.3617072865602253 | 0.998537 | 0.008367192167912752 | 12 | 298.15 | declared_excess_no_baseline |  | 10.1016/j.jct.2005.06.018 |
| GLOBlit_11042 | PROPblock_14 | GLOBprop_1 | 5 | -2.5826148721793675e-06; 6.379003960766906e-07; -7.305218674405775e-07; 1.4344091663959586e-07; -2.0377486676098777e-06; 1.6675480055258805e-06 | 0.999276 | 4.602814010602905e-09 | 11 |  | linear |  | 10.1021/je700700f |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
