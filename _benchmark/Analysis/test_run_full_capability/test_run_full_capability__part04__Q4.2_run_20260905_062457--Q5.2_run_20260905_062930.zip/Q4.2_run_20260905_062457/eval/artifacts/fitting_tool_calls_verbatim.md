# Registered deterministic fitting tool calls — verbatim

This archive contains only calls to the six registered fitting tools. Native tool arguments, fixed-tool results, validation failures, and exact saved agent-visible result bodies appear below. A Preview or compacted summary is labeled as such and is not a complete numeric result. The full run history is context and provenance only.
