# Analysis Run — [run id removed] (Round 1)

**Question:** What viscosity should I expect for an equimolar 1,2-dimethanol + water liquid mixture at 25 °C?

**[run statistics removed]**

---

## Answer

## Viscosity of an Equimolar 1,2-Ethanediol (Ethylene Glycol) + Water Mixture at 25 °C

> **Note:** "1,2-dimethanol" is not a standard IUPAC name. The compound you likely mean is **1,2-ethanediol** (HOCH₂CH₂OH), commonly known as **ethylene glycol**. The analysis below is for the binary system **1,2-ethanediol + water**.

### Predicted Viscosity at x(EG) = 0.50, T = 298.15 K (25 °C, user-specified)

Two independent ThermoML datasets were fitted with Redlich-Kister (RK) polynomials using the **Arrhenius mixing rule** (ln η is fitted), and both give a consistent prediction:

| Source | DOI | GLOBlit | Block | T (K) | Data pts at 298.15 K | RK Order | R² | RMSE | η at x = 0.5 (Pa·s) |
|--------|-----|---------|-------|--------|----------------------|----------|----|------|----------------------|
| Dataset 1 | 10.1016/j.jct.2018.02.022 | GLOBlit_5201 | PROPblock_24 | 298.15 | 19 | 3 | 0.999940 | 0.001320 | **0.00694** |
| Dataset 2 | 10.1021/acs.jced.6b00526 | GLOBlit_6951 | PROPblock_18 | 298.15 | 9 | 5 | 0.999925 | 0.001351 | **0.00673** |

### **Best estimate: η ≈ 0.0069 Pa·s (6.9 mPa·s) at 298.15 K for an equimolar mixture**

This is corroborated by a direct experimental data point from a third source (**GLOBlit_8106 / PROPblock_5**, DOI: 10.1021/je025610o), which reports **η = 0.00761 Pa·s at x(EG) = 0.50 and 297.05 K** — slightly higher as expected for a temperature ~1 K lower (viscosity decreases with increasing temperature).

---

### Fitting Details

**Dataset 1 — GLOBlit_5201 / PROPblock_24** (DOI: 10.1016/j.jct.2018.02.022)
- 19 data points used at T = 298.15 K (from fit tool), x(EG) = 0 to 1, P = 92.3 kPa
- Composition variable: mole fraction of 1,2-ethanediol
- Pure-component viscosities (block edges, from fit tool): η(EG) = 0.016223 Pa·s, η(water) = 0.00089689 Pa·s
- **RK coefficients (BIC-selected order 3):** [2.39674, −1.04444, 0.668173, −0.3209]
- R² = 0.999940, RMSE = 0.001320

**Dataset 2 — GLOBlit_6951 / PROPblock_18** (DOI: 10.1021/acs.jced.6b00526)
- 9 data points used at T = 298.15 K (from fit tool), x(water) = 0 to 1, P = 100.0 kPa
- Composition variable: mole fraction of water
- Pure-component viscosities (block edges, from fit tool): η(water) = 0.000843 Pa·s, η(EG) = 0.01724 Pa·s
- **RK coefficients (BIC-selected order 5):** [2.27452, 1.43846, 0.538413, −0.01859, 0.535328, 0.62332]
- R² = 0.999925, RMSE = 0.001351

---

### Chemistry Context

The ethylene glycol + water system is strongly **non-ideal** in its viscosity behavior. Both hydroxyl groups of ethylene glycol form extensive hydrogen-bonding networks with water, leading to a large positive excess viscosity (in ln-space). The maximum excess contribution (|Δln η|) is approximately **0.63** (from both fits), occurring near intermediate compositions.

At the equimolar composition, the predicted viscosity of ~6.9 mPa·s is substantially higher than pure water and lower than pure ethylene glycol (derived from fit-returned pure values: η(water) ≈ 0.90 mPa·s from Dataset 1, η(EG) ≈ 16.2–17.2 mPa·s across both datasets), reflecting the strong intermolecular interactions that make the mixture more viscous than a simple Arrhenius-ideal geometric-mean prediction would suggest.

Representative inspected data points at 298.15 K from Dataset 1 (GLOBlit_5201 / PROPblock_24, inspection INSP_2e07429c73f6):

| x(1,2-ethanediol) | η (Pa·s) |
|--------------------|----------|
| 0.0494 | 0.0012528 |
| 0.0986 | 0.0016802 |
| 0.1483 | 0.0021667 |
| 0.2072 | 0.0028109 |

---

### Output Files

Fit and excess-property data (CSV) and plots (PNG) were generated for both datasets and are available in the session output directory.

### Core claims

- The predicted dynamic viscosity of an equimolar 1,2-ethanediol (ethylene glycol) + water mixture at 298.15 K is approximately 0.0069 Pa·s (6.9 mPa·s), based on Redlich-Kister fits using the Arrhenius mixing rule applied to two independent ThermoML datasets (Dataset 1: η = 0.00694 Pa·s, R² = 0.999940; Dataset 2: η = 0.00673 Pa·s, R² = 0.999925).
- A direct experimental data point from a third source (GLOBlit_8106 / PROPblock_5) reports η = 0.00761 Pa·s at x(EG) = 0.50 and 297.05 K, which is slightly higher than the 298.15 K prediction, consistent with the expected decrease of viscosity with increasing temperature.
- The ethylene glycol + water system exhibits strongly non-ideal viscosity behavior due to extensive hydrogen bonding, with a large positive excess viscosity (maximum \|Δln η\| ≈ 0.63) near intermediate compositions.
- Pure-component viscosities derived from the fits at 298.15 K are η(water) ≈ 0.00089689 Pa·s (Dataset 1) / 0.000843 Pa·s (Dataset 2) and η(EG) ≈ 0.016223 Pa·s (Dataset 1) / 0.01724 Pa·s (Dataset 2).

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | Binary 1,2-ethanediol + water viscosity data covering mole fraction 0–1 and T = 293.15–308.15 K (includes 298.15 K). Used as Dataset 1 for the RK fit yielding η ≈ 0.00694 Pa·s at x(EG) = 0.50, 298.15 K. |
| GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18 |  | Binary 1,2-ethanediol + water viscosity data covering mole fraction 0–1 and T = 293.15–303.15 K (includes 298.15 K). Used as Dataset 2 for the RK fit yielding η ≈ 0.00673 Pa·s at x(EG) = 0.50, 298.15 K, providing independent corroboration. |
| GLOBlit_8106 | 10.1021/je025610o | PROPblock_5 |  | Binary 1,2-ethanediol + water viscosity data with x(EG) = 0.25–0.75 and T = 296.45–449.85 K. Provides a direct experimental corroboration point of η = 0.00761 Pa·s at x(EG) = 0.50 and 297.05 K, consistent with the fitted predictions at 298.15 K. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5201 | PROPblock_24 | EG_water_5201 | 3 | 2.3967401058713325; -1.0444436005853195; 0.6681733607879681; -0.3209004397507546 | 0.99994 | 0.0013198945265291695 | 19 | 298.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_6951 | PROPblock_18 | EG_water_6951 | 5 | 2.274524109519024; 1.4384635691823309; 0.5384128617275521; -0.01858996573688366; 0.53532833010802; 0.623320181010585 | 0.999925 | 0.0013505215055279614 | 9 | 298.15 | arrhenius |  | 10.1021/acs.jced.6b00526 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
