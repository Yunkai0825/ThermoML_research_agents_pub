# Reference Stats — analysis-agent

**Run started:** 2026-10-20 18:23:10
**Wall time (at last flush):** 940.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 12 | 191,113 | 399,384 | 56,379 | 590,497 | 49,208 | 411.6 | claudeopus46 |
| L1-worker | 34 | 456,837 | 341,484 | 78,649 | 798,321 | 23,480 | 528.5 | claudeopus46 |
| **TOTAL** | **46** | **647,950** | **740,868** | **135,028** | **1,388,818** | **30,191** | **940.1** | |

**Estimated tokens:** ~347,204 input + ~33,757 output = ~380,961 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 4 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 4 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 1 | 1 | 2 | 2 | 14 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 1 | 1 | 2 | 2 | 0 |
| `search_blocks` | 2 | 6 | 3 | 2 | 8 | 10 | 219 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 6 | 3 | 2 | 8 | 10 | 219 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 2 | 0 | 1 | 1 | 36 |
| `search_blocks` | 2 | 1 | 2 | 0 | 1 | 1 | 31 |
| `search_blocks` | 2 | 1 | 2 | 0 | 1 | 1 | 16 |
| `query_thermoml` | 2 | 3 | 3 | 1 | 5 | 5 | 0 |
| **TOTAL** | **20** | **24** | **17** | **7** | **28** | **32** | **535** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_3 |  | query_thermoml, resolve_compound_ids, search_blocks |
| GLOBcomp_50 |  | query_thermoml, resolve_compound_ids, search_blocks |
| GLOBcomp_151 |  | resolve_compound_ids |
| GLOBcomp_1447 |  | resolve_compound_ids |

#### Properties (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_27 |  | query_thermoml, resolve_property_ids, search_blocks |
| GLOBprop_55 |  | resolve_property_ids |
| GLOBprop_60 |  | resolve_property_ids |
| GLOBprop_69 |  | resolve_property_ids |
| GLOBprop_2 | Mole fraction | query_thermoml, search_blocks |
| GLOBprop_21 | Molality, mol/kg | query_thermoml, search_blocks |
| GLOBprop_71 | Tracer diffusion coefficient, m2/s | search_blocks |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | query_thermoml, search_blocks |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |

#### References (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_6787 |  | query_thermoml, search_blocks |
| GLOBlit_10864 |  | query_thermoml, search_blocks |
| GLOBlit_1169 |  | query_thermoml, search_blocks |
| GLOBlit_3779 |  | query_thermoml, search_blocks |
| GLOBlit_3961 |  | query_thermoml, search_blocks |
| GLOBlit_7324 |  | query_thermoml, search_blocks |
| GLOBlit_8739 |  | query_thermoml, search_blocks |
| GLOBlit_11256 |  | search_blocks |

#### Measurements (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_878 | Henry's Law constant (mole fraction scale), kPa | query_thermoml, search_blocks |
| GLOBmeas_1 | Henry's Law constant (mole fraction scale), kPa | query_thermoml, search_blocks |
| GLOBmeas_139 | Mole fraction | query_thermoml, search_blocks |
| GLOBmeas_221 | Mole fraction | query_thermoml, search_blocks |
| GLOBmeas_877 | Tracer diffusion coefficient, m2/s | search_blocks |
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | query_thermoml, search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_16 | Mole fraction | query_thermoml, search_blocks |
| GLOBmeas_171 | Vapor or sublimation pressure, kPa | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml, search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | query_thermoml, search_blocks |
| GLOBvar_3 | Pressure, kPa | query_thermoml, search_blocks |
| GLOBvar_2 | Mole fraction | query_thermoml, search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_3 | Mole fraction | query_thermoml, search_blocks |
| GLOBconstr_2 | Temperature, K | query_thermoml, search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Solvents (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_54 |  | query_thermoml, search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 4 |
| Unique Properties | 9 |
| Unique References | 8 |
| Unique Measurements | 9 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Unique Block_Types | 1 |
| Unique Solvents | 1 |
| Total DOIs | 8 |
| Unique parent blocks | 10 |
| Explicit block/subsystem targets | 10 |
| Subsystem targets | 0 |
| Target-matched data points | 648 |

---

## 3. DOI & Block References

**Unique DOIs:** 8  |  **Parent blocks:** 10  |  **Explicit targets:** 10  |  **Subsystems:** 0  |  **Target-matched datapoints:** 219

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2012.10.022 | 1 | 36 | binary | query_thermoml, search_blocks |
| 10.1016/j.jct.2012.11.030 | 1 | 7 | binary | query_thermoml, search_blocks |
| 10.1016/j.jct.2013.08.008 | 1 | 31 | binary | query_thermoml, search_blocks |
| 10.1021/acs.jced.5b00990 | 2 | 22 | binary | query_thermoml, search_blocks |
| 10.1021/acs.jced.7b00786 | 2 | 18 | binary | query_thermoml, search_blocks |
| 10.1021/je050357o | 1 | 16 | binary | query_thermoml, search_blocks |
| 10.1021/je700297c | 1 | 3 | binary | query_thermoml, search_blocks |
| 10.1021/je800433r | 1 | 86 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2012.10.022 | PROPblock_3 | declared | 36 | binary | 2 | query_thermoml, search_blocks |
| 10.1016/j.jct.2012.11.030 | PROPblock_2 | declared | 7 | binary | 2 | query_thermoml, search_blocks |
| 10.1016/j.jct.2013.08.008 | PROPblock_1 | declared | 31 | binary | 2 | query_thermoml, search_blocks |
| 10.1021/acs.jced.5b00990 | PROPblock_1 | declared | 11 | binary | — | search_blocks |
| 10.1021/acs.jced.5b00990 | PROPblock_2 | declared | 11 | binary | 2 | query_thermoml, search_blocks |
| 10.1021/acs.jced.7b00786 | PROPblock_12 | declared | 9 | binary | 2 | query_thermoml, search_blocks |
| 10.1021/acs.jced.7b00786 | PROPblock_13 | declared | 9 | binary | — | search_blocks |
| 10.1021/je050357o | PROPblock_1 | declared | 16 | binary | 2 | query_thermoml, search_blocks |
| 10.1021/je700297c | PROPblock_72 | declared | 3 | binary | 2 | query_thermoml, search_blocks |
| 10.1021/je800433r | PROPblock_1 | declared | 86 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'henry_CO2_bmimNTf… | 132 | — | — | 0.0 |
| 2 | 2 | `resolve_compound_ids` | limit=10, min_score=40, purpose=Resolve CO2 and io… | 319 | KEEP ←in 532 | 319 | 5.9 |
| 3 | 2 | `resolve_property_ids` | limit=10, min_score=40, purpose=Resolve Henry's la… | 623 | KEEP ←in 620 | 623 | 5.6 |
| 4 | 3 | `search_blocks` | compound=['GLOBcomp_3', 'GLOBcomp_50'], limit=50, … | 1,253 | KEEP ←in 3,649 | 1222 | 20.3 |
| 5 | 3 | `search_blocks` | compound=['GLOBcomp_3', 'GLOBcomp_50'], limit=50, … | 731 | DISCARD ←in 39 | 673 | 7.0 |
| 6 | 5 | `inspect_block_table` | block_number=GLOBlit_6787::PROPblock_2, purpose=Gr… | 1,614 | — | — | 0.2 |
| 7 | 5 | `inspect_block_table` | block_number=GLOBlit_10864::PROPblock_72, purpose=… | 1,197 | — | — | 0.2 |
| 8 | 3 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 22,944 | — | — | 134.6 |
| 9 | 1 | `search_blocks` | compound=['GLOBcomp_3', 'GLOBcomp_50'], limit=50, … | 916 | KEEP ←in 6,305 | 901 | 23.5 |
| 10 | 2 | `inspect_block_table` | block_number=PROPblock_3, literature=GLOBlit_1169,… | 1,409 | — | — | 0.2 |
| 11 | 2 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_3961,… | 2,342 | — | — | 0.1 |
| 12 | 2 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_8739,… | 1,665 | — | — | 0.1 |
| 13 | 3 | `inspect_block_table` | block_number=PROPblock_3, literature=GLOBlit_1169,… | 1,409 | — | — | 0.2 |
| 14 | 3 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_3961,… | 2,342 | — | — | 0.1 |
| 15 | 3 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_8739,… | 1,665 | — | — | 0.1 |
| 16 | 4 | `search_blocks` | compound=['GLOBcomp_3', 'GLOBcomp_50'], limit=50, … | 1,224 | KEEP ←in 6,305 | 1209 | 21.0 |
| 17 | 5 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_3779,… | 1,238 | — | — | 0.2 |
| 18 | 5 | `inspect_block_table` | block_number=PROPblock_12, literature=GLOBlit_7324… | 1,341 | — | — | 0.1 |
| 19 | 6 | `inspect_block_table` | block_number=PROPblock_3, literature=GLOBlit_1169,… | 1,409 | — | — | 0.1 |
| 20 | 6 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_3961,… | 2,342 | — | — | 0.1 |
| 21 | 6 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_8739,… | 1,665 | — | — | 0.1 |
| 22 | 7 | `search_blocks` | block_number=GLOBlit_1169::PROPblock_3, purpose=Re… | 1,034 | KEEP ←in 1,857 | 1034 | 10.3 |
| 23 | 7 | `search_blocks` | block_number=GLOBlit_3961::PROPblock_1, purpose=Re… | 970 | KEEP ←in 2,582 | 970 | 10.8 |
| 24 | 7 | `search_blocks` | block_number=GLOBlit_8739::PROPblock_1, purpose=Re… | 1,016 | KEEP ←in 2,016 | 1016 | 9.8 |
| 25 | 4 | `query_thermoml` | id_catalog=[{'type': 'comp', 'global_id'…, instruc… | 57,145 | — | — | 396.5 |
| | | **TOTAL (25 tools)** | | **109,945** | | **7,967** | **647.1** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 22,897 | 500 | 23,397 | 1,836 | 10.4 |
| 2 | L0-main | claudeopus46 | 22,897 | 1,214 | 24,111 | 815 | 5.8 |
| 3 | L0-main | claudeopus46 | 22,897 | 2,575 | 25,472 | 841 | 4.6 |
| 4 | L1-worker | claudeopus46 | 24,140 | 1,028 | 25,168 | 1,033 | 6.8 |
| 5 | L1-worker | claudeopus46 | 24,140 | 2,577 | 26,717 | 974 | 5.0 |
| 6 | L1-worker | claudeopus46 | 3,767 | 708 | 4,475 | 526 | 4.9 |
| 7 | L1-worker | claudeopus46 | 3,767 | 792 | 4,559 | 910 | 5.3 |
| 8 | L1-worker | claudeopus46 | 24,140 | 2,770 | 26,910 | 1,534 | 8.8 |
| 9 | L1-worker | claudeopus46 | 3,767 | 4,093 | 7,860 | 1,513 | 11.8 |
| 10 | L1-worker | claudeopus46 | 3,767 | 583 | 4,350 | 906 | 6.5 |
| 11 | L1-worker | claudeopus46 | 24,140 | 5,564 | 29,704 | 3,019 | 18.5 |
| 12 | L1-worker | claudeopus46 | 24,140 | 11,756 | 35,896 | 796 | 5.5 |
| 13 | L1-worker | claudeopus46 | 24,140 | 15,232 | 39,372 | 2,314 | 16.3 |
| 14 | L1-worker | claudeopus46 | 24,140 | 21,958 | 46,098 | 2,445 | 16.9 |
| 15 | L1-worker | claudeopus46 | 2,543 | 4,871 | 7,414 | 1,267 | 6.5 |
| 16 | L1-worker | claudeopus46 | 2,320 | 3,722 | 6,042 | 1,065 | 6.6 |
| 17 | L1-worker | claudeopus46 | 627 | 3,602 | 4,229 | 928 | 7.0 |
| 18 | L1-worker | claudeopus46 | 787 | 20,912 | 21,699 | 838 | 8.4 |
| 19 | L0-main | claudeopus46 | 22,897 | 19,639 | 42,536 | 3,302 | 22.3 |
| 20 | L1-worker | claudeopus46 | 24,140 | 2,247 | 26,387 | 874 | 7.1 |
| 21 | L1-worker | claudeopus46 | 3,767 | 6,742 | 10,509 | 1,702 | 13.9 |
| 22 | L1-worker | claudeopus46 | 24,140 | 3,703 | 27,843 | 12,695 | 70.2 |
| 23 | L1-worker | claudeopus46 | 24,140 | 5,771 | 29,911 | 1,165 | 6.7 |
| 24 | L1-worker | claudeopus46 | 24,140 | 7,660 | 31,800 | 2,399 | 17.6 |
| 25 | L1-worker | claudeopus46 | 3,767 | 6,678 | 10,445 | 1,474 | 13.0 |
| 26 | L1-worker | claudeopus46 | 24,140 | 9,518 | 33,658 | 2,006 | 13.4 |
| 27 | L1-worker | claudeopus46 | 24,140 | 12,981 | 37,121 | 1,911 | 12.8 |
| 28 | L1-worker | claudeopus46 | 24,140 | 14,934 | 39,074 | 2,701 | 18.2 |
| 29 | L1-worker | claudeopus46 | 3,767 | 2,198 | 5,965 | 1,397 | 10.1 |
| 30 | L1-worker | claudeopus46 | 3,767 | 2,923 | 6,690 | 1,270 | 10.6 |
| 31 | L1-worker | claudeopus46 | 3,767 | 2,357 | 6,124 | 1,274 | 9.5 |
| 32 | L1-worker | claudeopus46 | 24,140 | 18,727 | 42,867 | 9,494 | 64.1 |
| 33 | L1-worker | claudeopus46 | 24,140 | 35,435 | 59,575 | 6,518 | 47.5 |
| 34 | L1-worker | claudeopus46 | 24,140 | 45,833 | 69,973 | 6,139 | 42.6 |
| 35 | L1-worker | claudeopus46 | 2,543 | 8,638 | 11,181 | 1,900 | 9.6 |
| 36 | L1-worker | claudeopus46 | 2,320 | 6,270 | 8,590 | 1,720 | 11.0 |
| 37 | L1-worker | claudeopus46 | 627 | 6,150 | 6,777 | 1,495 | 11.0 |
| 38 | L1-worker | claudeopus46 | 787 | 42,551 | 43,338 | 447 | 4.8 |
| 39 | L0-main | claudeopus46 | 22,897 | 58,656 | 81,553 | 11,322 | 85.0 |
| 40 | L0-main | claudeopus46 | 22,897 | 70,378 | 93,275 | 12,941 | 98.7 |
| 41 | L0-main | claudeopus46 | 22,897 | 89,911 | 112,808 | 12,336 | 87.3 |
| 42 | L0-main | claudeopus46 | 22,897 | 109,832 | 132,729 | 7,425 | 56.5 |
| 43 | L0-main | claudeopus46 | 2,543 | 12,711 | 15,254 | 738 | 4.8 |
| 44 | L0-main | claudeopus46 | 2,320 | 12,077 | 14,397 | 1,458 | 11.6 |
| 45 | L0-main | claudeopus46 | 1,156 | 17,276 | 18,432 | 2,267 | 14.7 |
| 46 | L0-main | claudeopus46 | 1,918 | 4,615 | 6,533 | 1,098 | 9.9 |

