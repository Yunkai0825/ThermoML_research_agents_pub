# Working Memory

**ROOT:** `N:\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q6.3_run_20261020_182310`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_3 | carbon dioxide |  |
| comp | GLOBcomp_50 | 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide |  |
| prop | GLOBprop_27 | henry's law constant (mole fraction scale), kpa |  |
| lit | GLOBlit_6787 | 10.1021/acs.jced.5b00990 |  |
| lit | GLOBlit_10864 | 10.1021/je700297c |  |

### History
- [query_thermoml]
- [query_thermoml]

### Query Results
#### query
**L1_query_1** — status: success · validation: FLAGGED(3)

**Summary:**

Henry's Law constants (mole-fraction scale, kPa) for CO₂ at infinite dilution in [bmim][NTf₂] were reported in two ThermoML data blocks. Block 1 (DOI 10.1021/acs.jced.5b00990, transient thin-film method, 11 points, 293.15–323.15 K) gives H values rising from 2900 kPa at 293.15 K to 4910 kPa at 323.15 K, with uncertainties of roughly 72–122 kPa. Block 2 (DOI 10.1021/je700297c, chromatographic method, 3 points, 303–323 K) gives H values of 3340 kPa at 303 K, 4120 kPa at 313 K, and 4770 kPa at 323 K, with uncertainties of 200–290 kPa. Both datasets show H increasing with temperature, consistent with exothermic physical absorption and decreasing CO₂ solubility at higher temperatures. The two independent studies agree reasonably at overlapping temperatures (e.g., ~3460–3490 vs. 3340 kPa near 303 K; 4910 vs. 4770 kPa near 323 K). No data were found on molality or amount-concentration scales for this system.

**Answer:**

#### Henry's Law Constants of CO₂ in [bmim][NTf₂] — ThermoML Results

**Property:** Henry's Law constant (mole fraction scale) — **GLOBprop_27**, units: kPa

Two data blocks were found in the ThermoML database for the binary system carbon dioxide (GLOBcomp_3) + 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide (GLOBcomp_50), both reporting Henry's law constants at infinite dilution of CO₂ in the liquid phase.

---

##### Block 1 — GLOBlit_6787 :: PROPblock_2
- **DOI:** 10.1021/acs.jced.5b00990
- **Method:** Transient thin film
- **Data points:** 11
- **Temperature range:** 293.15–323.15 K
- **Constraint:** x(CO₂) = 0.0 (infinite dilution)

**WM_L1#1_Table#1_(Analysis_L1#1_Answer):**

| *row_id* | *T (K)* | *H (kPa)* | *±U (kPa)* |
|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「293.15」 | 「2900」 | 「71.976」 |
| WM_L1#1_Table#1_Row#2 | 「298.15」 | 「3190」 | 「78.937」 |
| WM_L1#1_Table#1_Row#3 | 「303.15」 | 「3460」 | 「85.692」 |
| WM_L1#1_Table#1_Row#4 | 「303.15」 | 「3480」 | 「86.168」 |
| WM_L1#1_Table#1_Row#5 | 「303.15」 | 「3490」 | 「86.407」 |
| WM_L1#1_Table#1_Row#6 | 「313.15」 | 「4130」 | 「102.04」 |
| WM_L1#1_Table#1_Row#7 | 「318.15」 | 「4460」 | 「110.355」 |
| WM_L1#1_Table#1_Row#8 | 「318.15」 | 「4510」 | 「111.568」 |
| WM_L1#1_Table#1_Row#9 | 「318.15」 | 「4470」 | 「110.598」 |
| WM_L1#1_Table#1_Row#10 | 「318.15」 | 「4440」 | 「109.87」 |
| WM_L1#1_Table#1_Row#11 | 「323.15」 | 「4910」 | 「121.609」 |

##### Block 2 — GLOBlit_10864 :: PROPblock_72
- **DOI:** 10.1021/je700297c
- **Method:** Chromatography
- **Data points:** 3
- **Temperature range:** 303–323 K
- **Constraint:** x(CO₂) = 0.0 (infinite dilution)

**WM_L1#1_Table#2_(Analysis_L1#1_Answer):**

| *row_id* | *T (K)* | *H (kPa)* | *±U (kPa)* |
|---|---|---|---|
| WM_L1#1_Table#2_Row#1 | 「303」 | 「3340」 | 「200」 |
| WM_L1#1_Table#2_Row#2 | 「313」 | 「4120」 | 「250」 |
| WM_L1#1_Table#2_Row#3 | 「323」 | 「4770」 | 「290」 |

---

##### Chemical Insight

The Henry's law constant for CO₂ in [bmim][NTf₂] increases with temperature across both datasets, indicating decreasing CO₂ solubility at higher temperatures — consistent with the exothermic nature of physical gas absorption in ionic liquids. In Block 1 (GLOBlit_6787 :: PROPblock_2), H rises from 2900 kPa at 293.15 K to 4910 kPa at 323.15 K. In Block 2 (GLOBlit_10864 :: PROPblock_72), H rises from 3340 kPa at 303 K to 4770 kPa at 323 K. The two independent studies show reasonable agreement at overlapping temperatures (e.g., at ~303 K: Block 1 reports 3460–3490 kPa while Block 2 reports 3340 kPa; at ~323 K: Block 1 reports 4910 kPa while Block 2 reports 4770 kPa). The uncertainties in Block 2 are notably larger than in Block 1, reflecting the different measurement techniques.

No data were found for Henry's law constant on the molality scale (GLOBprop_55) or amount concentration scale (GLOBprop_69) for this system.

**Core claims:**
- Two independent ThermoML datasets report Henry's law constants (kPa, mole fraction scale) for CO₂ at infinite dilution in [bmim][NTf₂]: Block 1 (DOI 10.1021/acs.jced.5b00990, transient thin film method) spans 293.15–323.15 K with H rising from 2900 kPa to 4910 kPa, and Block 2 (DOI 10.1021/je700297c, chromatography) spans 303–323 K with H rising from 3340 kPa to 4770 kPa.
- In both datasets the Henry's law constant increases with temperature, indicating decreasing CO₂ solubility at higher temperatures, consistent with exothermic physical gas absorption in ionic liquids.
- The two studies show reasonable agreement at overlapping temperatures: at ~303 K, Block 1 reports 3460–3490 kPa while Block 2 reports 3340 kPa; at ~323 K, Block 1 reports 4910 kPa while Block 2 reports 4770 kPa. Block 2 uncertainties are notably larger than Block 1, reflecting different measurement techniques.
- No data were found for Henry's law constant on the molality scale or amount concentration scale for this system.

**Core blocks found:**

**WM_L1#1_Blocks_(Analysis_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#3 | 「GLOBlit_6787」 | 「PROPblock_2」 | 「GLOBcomp_3, GLOBcomp_50」 | 「GLOBprop_27」 | 「Henry's law constant (mole fraction scale, kPa) of CO2 in [bmim][NTf2] at 293.15–323.15 K, 11 data points from transient thin film method.」 |
| WM_L1#1_Table#4 | 「GLOBlit_10864」 | 「PROPblock_72」 | 「GLOBcomp_3, GLOBcomp_50」 | 「GLOBprop_27」 | 「Henry's law constant (mole fraction scale, kPa) of CO2 in [bmim][NTf2] at 303–323 K, 3 data points from chromatography method.」 |

*Not stored here: 2 verbatim data_inspections table(s); 5 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(3) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 3460 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 3490 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 4910 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)


#### query
**L1_query_2** — status: success · validation: PASS

**Summary:**

Five ThermoML data blocks contain CO₂ solubility or VLE data in [bmim][NTf₂], beyond the two previously identified Henry's law constant blocks. Block 1 (GLOBlit_8739/PROPblock_1, DOI 10.1021/je050357o) reports liquid-phase CO₂ mole fractions via phase equilibration at T = 279.98–339.97 K and P = 291.8–4799.9 kPa (16 points), providing the lowest-pressure data in ThermoML for this system (x ≈ 0.09–0.12 at the lowest pressures). Block 2 (GLOBlit_1169/PROPblock_3, DOI 10.1016/j.fluid.2012.10.022) uses gravimetric measurement at T = 318.0–338.0 K and P = 12.0–19997.7 kPa (12 points), extending to ~20 MPa with mole fractions approaching ~0.76 at 318 K. Block 3 (GLOBlit_3961/PROPblock_1, DOI 10.1016/j.jct.2013.08.008) covers the widest temperature range (273.15–413.15 K) at P = 485.0–4849.0 kPa (30 points), showing inverse temperature dependence of solubility. Block 4 (GLOBlit_3779/PROPblock_2, DOI 10.1016/j.jct.2012.11.030) reports molality at a single isotherm of 323.15 K over P = 380–4080 kPa (7 points), with near-linear behavior at low pressures consistent with Henry's law. Block 5 (GLOBlit_7324/PROPblock_12, DOI 10.1021/acs.jced.7b00786) reports vapor pressure at 313.15 K as a function of x(CO₂) = 0.222–0.712 (9 points, P up to 8487 kPa). For Henry's law analysis, Block 1 is most useful due to its lowest-pressure data points, followed by Block 4; the remaining blocks have lowest measured compositions at x > 0.2 where deviations from Henry's law are expected.

**Answer:**

#### CO₂ Solubility / VLE Data in [bmim][NTf₂] — ThermoML Results

Five data blocks in ThermoML contain solubility or vapor–liquid equilibrium data for CO₂ in 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide ([bmim][NTf₂]), excluding the two Henry's law constant blocks already identified (GLOBlit_6787/PROPblock_2 and GLOBlit_10864/PROPblock_72).

---

##### Block 1: GLOBlit_8739 / PROPblock_1
**DOI:** 10.1021/je050357o  
**Property:** Mole fraction of CO₂ in liquid phase (GLOBprop_2)  
**Method:** Phase equilibration (GLOBmeas_16)  
**Conditions:** T = 279.98–339.97 K, P = 291.8–4799.9 kPa, 16 data points  
**Phases:** Liquid + Gas  

**WM_L1#2_Table#1_(Analysis_L1#2_Answer):**

| *row_id* | *T (K)* | *P (kPa)* | *x(CO₂)* | *±U* |
|---|---|---|---|---|
| WM_L1#2_Table#1_Row#1 | 「279.98」 | 「291.8」 | 「0.1151」 | 「0.0021」 |
| WM_L1#2_Table#1_Row#2 | 「279.98」 | 「719.2」 | 「0.2472」 | 「0.0021」 |
| WM_L1#2_Table#1_Row#3 | 「279.98」 | 「1458.4」 | 「0.4141」 | 「0.0021」 |
| WM_L1#2_Table#1_Row#4 | 「279.98」 | 「2059.5」 | 「0.5123」 | 「0.0021」 |
| WM_L1#2_Table#1_Row#5 | 「299.98」 | 「405.8」 | 「0.1063」 | 「0.002」 |
| WM_L1#2_Table#1_Row#6 | 「299.98」 | 「996.9」 | 「0.2309」 | 「0.002」 |
| WM_L1#2_Table#1_Row#7 | 「299.98」 | 「2063.6」 | 「0.3896」 | 「0.0021」 |
| WM_L1#2_Table#1_Row#8 | 「299.98」 | 「2962.7」 | 「0.4837」 | 「0.0021」 |
| WM_L1#2_Table#1_Row#9 | 「319.98」 | 「518.1」 | 「0.099」 | 「0.002」 |
| WM_L1#2_Table#1_Row#10 | 「319.98」 | 「1292.9」 | 「0.2153」 | 「0.002」 |
| WM_L1#2_Table#1_Row#11 | 「319.98」 | 「2699.6」 | 「0.3659」 | 「0.0021」 |
| WM_L1#2_Table#1_Row#12 | 「319.98」 | 「3903.9」 | 「0.4557」 | 「0.0021」 |
| WM_L1#2_Table#1_Row#13 | 「339.97」 | 「635.0」 | 「0.0922」 | 「0.002」 |

*(Last 3 rows at 339.97 K were truncated in the returned table.)*

**Chemistry note:** This block contains the lowest-pressure data points in ThermoML for this system. At each temperature, the lowest-pressure point (x ≈ 0.09–0.12) is closest to the Henry's law regime.

---

##### Block 2: GLOBlit_1169 / PROPblock_3
**DOI:** 10.1016/j.fluid.2012.10.022  
**Property:** Mole fraction of CO₂ in liquid phase (GLOBprop_2)  
**Method:** Gravimetric (GLOBmeas_139)  
**Conditions:** T = 318.0–338.0 K, P = 12.0–19997.7 kPa, 12 data points (RDP-compressed from 36)  

**WM_L1#2_Table#2_(Analysis_L1#2_Answer):**

| *row_id* | *T (K)* | *P (kPa)* | *x(CO₂)* | *±U* |
|---|---|---|---|---|
| WM_L1#2_Table#2_Row#1 | 「318.0」 | 「12.0」 | 「0.0」 | 「—」 |
| WM_L1#2_Table#2_Row#2 | 「318.0」 | 「2997.4」 | 「0.3888」 | 「0.0017」 |
| WM_L1#2_Table#2_Row#3 | 「318.0」 | 「4996.0」 | 「0.5262」 | 「0.0021」 |
| WM_L1#2_Table#2_Row#4 | 「318.0」 | 「7495.7」 | 「0.6304」 | 「0.0016」 |
| WM_L1#2_Table#2_Row#5 | 「318.0」 | 「9995.5」 | 「0.7003」 | 「0.0012」 |
| WM_L1#2_Table#2_Row#6 | 「318.0」 | 「12496.1」 | 「0.7348」 | 「0.001」 |
| WM_L1#2_Table#2_Row#7 | 「318.0」 | 「19996.5」 | 「0.7638」 | 「0.0008」 |
| WM_L1#2_Table#2_Row#8 | 「338.0」 | 「12.0」 | 「0.0」 | 「—」 |
| WM_L1#2_Table#2_Row#9 | 「338.0」 | 「3495.1」 | 「0.34」 | 「0.0015」 |
| WM_L1#2_Table#2_Row#10 | 「338.0」 | 「7495.7」 | 「0.5403」 | 「0.002」 |
| WM_L1#2_Table#2_Row#11 | 「338.0」 | 「12495.3」 | 「0.667」 | 「0.0014」 |
| WM_L1#2_Table#2_Row#12 | 「338.0」 | 「19997.7」 | 「0.7226」 | 「—」 |

**Chemistry note:** This block extends to very high pressures (up to ~20 MPa) and shows the characteristic saturation behavior of CO₂ in ionic liquids — mole fractions approaching ~0.76 at 318 K and 20 MPa. The two zero-composition points at 12 kPa anchor the low-pressure limit. There is a large data gap between 12 kPa and the next measured point at 2997.4 kPa (at 318 K), making this block less useful for Henry's law analysis than Block 1.

---

##### Block 3: GLOBlit_3961 / PROPblock_1
**DOI:** 10.1016/j.jct.2013.08.008  
**Property:** Mole fraction of CO₂ in liquid phase (GLOBprop_2)  
**Method:** Volumetric  
**Conditions:** T = 273.15–413.15 K, P = 485.0–4849.0 kPa, 30 data points  

Representative data (from returned table):

**WM_L1#2_Table#3_(Analysis_L1#2_Answer):**

| *row_id* | *T (K)* | *P (kPa)* | *x(CO₂)* | *±U* |
|---|---|---|---|---|
| WM_L1#2_Table#3_Row#1 | 「413.15」 | 「4849.0」 | 「0.3143」 | 「0.0012」 |
| WM_L1#2_Table#3_Row#2 | 「393.15」 | 「4819.0」 | 「0.3341」 | 「0.0013」 |
| WM_L1#2_Table#3_Row#3 | 「373.15」 | 「4774.0」 | 「0.3759」 | 「0.0016」 |
| WM_L1#2_Table#3_Row#4 | 「353.15」 | 「4716.0」 | 「0.4252」 | 「0.0018」 |
| WM_L1#2_Table#3_Row#5 | 「333.15」 | 「4635.0」 | 「0.4875」 | 「0.0021」 |
| WM_L1#2_Table#3_Row#6 | 「313.15」 | 「4513.0」 | 「0.5654」 | 「0.002」 |
| WM_L1#2_Table#3_Row#7 | 「293.15」 | 「4301.0」 | 「0.6642」 | 「0.0019」 |
| WM_L1#2_Table#3_Row#8 | 「413.15」 | 「3133.0」 | 「0.2562」 | 「0.0011」 |
| WM_L1#2_Table#3_Row#9 | 「393.15」 | 「3106.0」 | 「0.2758」 | 「0.0011」 |
| WM_L1#2_Table#3_Row#10 | 「373.15」 | 「3070.0」 | 「0.3063」 | 「0.0013」 |
| WM_L1#2_Table#3_Row#11 | 「353.15」 | 「3012.0」 | 「0.3645」 | 「0.0015」 |
| WM_L1#2_Table#3_Row#12 | 「333.15」 | 「2962.0」 | 「0.3976」 | 「0.0017」 |
| WM_L1#2_Table#3_Row#13 | 「313.15」 | 「2876.0」 | 「0.463」 | 「0.002」 |

*(Table truncated; 30 total points span 7 isotherms from 273.15 to 413.15 K.)*

**Chemistry note:** This is the widest temperature range available (273.15–413.15 K) and clearly shows the inverse temperature dependence of CO₂ solubility: at ~4800 kPa, x(CO₂) increases from 0.3143 at 413.15 K to 0.6642 at 293.15 K.

---

##### Block 4: GLOBlit_3779 / PROPblock_2
**DOI:** 10.1016/j.jct.2012.11.030  
**Property:** Molality of CO₂ (mol/kg) (GLOBprop_21)  
**Conditions:** T = 323.15 K (constrained), P = 380–4080 kPa, 7 data points  

**WM_L1#2_Table#4_(Analysis_L1#2_Answer):**

| *row_id* | *P (kPa)* | *T (K)* | *Molality (mol/kg)* | *±U* |
|---|---|---|---|---|
| WM_L1#2_Table#4_Row#1 | 「380」 | 「323.15」 | 「0.2257」 | 「0.0036」 |
| WM_L1#2_Table#4_Row#2 | 「740」 | 「323.15」 | 「0.4173」 | 「0.0068」 |
| WM_L1#2_Table#4_Row#3 | 「1730」 | 「323.15」 | 「0.8577」 | 「0.0137」 |
| WM_L1#2_Table#4_Row#4 | 「2600」 | 「323.15」 | 「1.2957」 | 「0.0212」 |
| WM_L1#2_Table#4_Row#5 | 「3170」 | 「323.15」 | 「1.6002」 | 「0.0261」 |
| WM_L1#2_Table#4_Row#6 | 「3630」 | 「323.15」 | 「1.8138」 | 「0.0296」 |
| WM_L1#2_Table#4_Row#7 | 「4080」 | 「323.15」 | 「2.0491」 | 「0.0335」 |

**Chemistry note:** Molality data at a single isotherm. The near-linear relationship at low pressures (380–740 kPa) is consistent with Henry's law behavior.

---

##### Block 5: GLOBlit_7324 / PROPblock_12
**DOI:** 10.1021/acs.jced.7b00786  
**Property:** Vapor (or sublimation) pressure (kPa) (GLOBprop_5)  
**Conditions:** T = 313.15 K (constrained), x(CO₂) = 0.222–0.712, 9 data points  

**WM_L1#2_Table#5_(Analysis_L1#2_Answer):**

| *row_id* | *x(CO₂)* | *T (K)* | *P (kPa)* | *±U* |
|---|---|---|---|---|
| WM_L1#2_Table#5_Row#1 | 「0.222」 | 「313.15」 | 「1303」 | 「34」 |
| WM_L1#2_Table#5_Row#2 | 「0.276」 | 「313.15」 | 「1712」 | 「43」 |
| WM_L1#2_Table#5_Row#3 | 「0.364」 | 「313.15」 | 「2409」 | 「64」 |
| WM_L1#2_Table#5_Row#4 | 「0.441」 | 「313.15」 | 「3151」 | 「91」 |
| WM_L1#2_Table#5_Row#5 | 「0.472」 | 「313.15」 | 「3531」 | 「148」 |
| WM_L1#2_Table#5_Row#6 | 「0.55」 | 「313.15」 | 「4832」 | 「158」 |
| WM_L1#2_Table#5_Row#7 | 「0.616」 | 「313.15」 | 「6055」 | 「170」 |
| WM_L1#2_Table#5_Row#8 | 「0.664」 | 「313.15」 | 「7364」 | 「172」 |
| WM_L1#2_Table#5_Row#9 | 「0.712」 | 「313.15」 | 「8487」 | 「138」 |

**Chemistry note:** This block reports vapor pressure as the measured property, with composition as the variable. The data extend to high pressures (up to 8487 kPa) and high CO₂ loadings (x up to 0.712). The lowest composition point (x = 0.222, P = 1303 kPa) is still at relatively high CO₂ loading, above the dilute Henry's law regime.

---

##### Summary for Henry's Law Analysis

For extracting Henry's law behavior at low pressures, the most useful block is **GLOBlit_8739 / PROPblock_1** (DOI: 10.1021/je050357o), which provides the lowest-pressure solubility data (P as low as 291.8 kPa at 279.98 K, with x(CO₂) ≈ 0.09–0.12 at the lowest pressures across four temperatures). The **GLOBlit_3779 / PROPblock_2** molality data at 323.15 K also starts at a relatively low pressure (380 kPa). The other blocks have their lowest measured compositions at higher CO₂ mole fractions (x > 0.2) where deviations from Henry's law are expected.

**Core claims:**
- Five ThermoML data blocks contain solubility or VLE data for CO₂ in [bmim][NTf₂], distinct from the two previously identified Henry's law constant blocks.
- GLOBlit_8739/PROPblock_1 (DOI: 10.1021/je050357o) provides the lowest-pressure solubility data (P as low as 291.8 kPa at 279.98 K, x(CO₂) ≈ 0.09–0.12 at the lowest pressures across four temperatures from 279.98 to 339.97 K) and is the most useful block for Henry's law analysis.
- GLOBlit_1169/PROPblock_3 (DOI: 10.1016/j.fluid.2012.10.022) extends to very high pressures (up to ~20 MPa) and shows characteristic CO₂ saturation behavior in ionic liquids, with mole fractions approaching ~0.76 at 318 K and 20 MPa, but a large data gap between 12 kPa and 2997.4 kPa limits its utility for Henry's law analysis.
- GLOBlit_3961/PROPblock_1 (DOI: 10.1016/j.jct.2013.08.008) spans the widest temperature range (273.15–413.15 K) and clearly shows inverse temperature dependence of CO₂ solubility: at ~4800 kPa, x(CO₂) increases from 0.3143 at 413.15 K to 0.6642 at 293.15 K.
- GLOBlit_3779/PROPblock_2 (DOI: 10.1016/j.jct.2012.11.030) reports molality data at 323.15 K starting at 380 kPa, with a near-linear relationship at low pressures (380–740 kPa) consistent with Henry's law behavior.
- GLOBlit_7324/PROPblock_12 (DOI: 10.1021/acs.jced.7b00786) reports vapor pressure at 313.15 K for x(CO₂) = 0.222–0.712 (P up to 8487 kPa), but the lowest composition point (x = 0.222) is above the dilute Henry's law regime.
- Blocks other than GLOBlit_8739/PROPblock_1 and GLOBlit_3779/PROPblock_2 have their lowest measured compositions at x(CO₂) > 0.2, where deviations from Henry's law are expected.

**Core blocks found:**

**WM_L1#2_Blocks_(Analysis_L1#2_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#2_Table#6 | 「GLOBlit_8739」 | 「PROPblock_1」 | 「GLOBcomp_3, GLOBcomp_50」 | 「GLOBprop_2」 | 「Mole fraction solubility of CO2 in [bmim][NTf2] at 279.98–339.97 K and 291.8–4799.9 kPa, providing the lowest-pressure VLE data for Henry's law analysis.」 |
| WM_L1#2_Table#7 | 「GLOBlit_1169」 | 「PROPblock_3」 | 「GLOBcomp_3, GLOBcomp_50」 | 「GLOBprop_2」 | 「Mole fraction solubility of CO2 in [bmim][NTf2] at 318.0–338.0 K up to ~20 MPa, showing saturation behavior at high pressures.」 |
| WM_L1#2_Table#8 | 「GLOBlit_3961」 | 「PROPblock_1」 | 「GLOBcomp_3, GLOBcomp_50」 | 「GLOBprop_2」 | 「Mole fraction solubility of CO2 in [bmim][NTf2] over the widest temperature range (273.15–413.15 K) at 485–4849 kPa.」 |
| WM_L1#2_Table#9 | 「GLOBlit_3779」 | 「PROPblock_2」 | 「GLOBcomp_3, GLOBcomp_50」 | 「GLOBprop_21」 | 「Molality of CO2 in [bmim][NTf2] at 323.15 K and 380–4080 kPa, showing near-linear Henry's law behavior at low pressures.」 |
| WM_L1#2_Table#10 | 「GLOBlit_7324」 | 「PROPblock_12」 | 「GLOBcomp_50, GLOBcomp_3」 | 「GLOBprop_5」 | 「Vapor pressure of CO2/[bmim][NTf2] system at 313.15 K as a function of CO2 mole fraction (0.222–0.712), extending to high pressures.」 |

*Not stored here: 5 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.

