# Analysis Run — [run id removed] (Round 1)

**Question:** From the temperature dependence of the Henry's law constants of carbon dioxide in 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide in ThermoML, estimate the enthalpy of solution with its uncertainty, and check whether the low-pressure solubility measurements of other papers are consistent with those Henry constants.

**[run statistics removed]**

---

## Answer

# Enthalpy of Solution of CO₂ in [bmim][NTf₂] from Henry's Law Constants, and Consistency with Low-Pressure Solubility Data

## 1. Henry's Law Constant Data

Two ThermoML blocks report Henry's law constants (mole fraction scale, kPa) for CO₂ at infinite dilution in [bmim][NTf₂]:

### Block 1 — GLOBlit_6787 :: PROPblock_2 (DOI: 10.1021/acs.jced.5b00990)
Transient thin-film method, 11 data points, 293.15–323.15 K. All values from verbatim inspection INSP_8f65d694d36c.

| T (K) | H (kPa) | ±U (kPa) |
|--------|---------|----------|
| 293.15 | 2900 | 71.976 |
| 298.15 | 3190 | 78.937 |
| 303.15 | 3460 | 85.692 |
| 303.15 | 3480 | 86.168 |
| 303.15 | 3490 | 86.407 |
| 313.15 | 4130 | 102.04 |
| 318.15 | 4460 | 110.355 |
| 318.15 | 4510 | 111.568 |
| 318.15 | 4470 | 110.598 |
| 318.15 | 4440 | 109.87 |
| 323.15 | 4910 | 121.609 |

### Block 2 — GLOBlit_10864 :: PROPblock_72 (DOI: 10.1021/je700297c)
Chromatographic method, 3 data points, 303–323 K. All values from verbatim inspection INSP_ac34d22698b5.

| T (K) | H (kPa) | ±U (kPa) |
|--------|---------|----------|
| 303 | 3340 | 200 |
| 313 | 4120 | 250 |
| 323 | 4770 | 290 |

---

## 2. Enthalpy of Solution — van't Hoff Analysis

The thermodynamic relation is d(ln H)/d(1/T) = ΔH\_sol/R, where R = 8.314 J/(mol·K) (physical constant). A linear regression of ln(H) vs 1/T yields the slope, from which ΔH\_sol is obtained.

### From Block 1 data (GLOBlit_6787 :: PROPblock_2)

Averaging the replicate inspected H values at 303.15 K (mean of 3460, 3480, 3490 = 3476.7 kPa; **derived**) and 318.15 K (mean of 4460, 4510, 4470, 4440 = 4470 kPa; **derived**), and computing 1/T and ln(H) (**all derived from the inspected database values above**), ordinary least-squares regression over 6 unique temperatures gives:

- **Slope** = −1644 K (**derived**)
- **R²** = 0.998 (**derived**)
- **ΔH\_sol** = 8.314 (physical constant) × (−1644) (derived slope) = **−13.7 kJ/mol** (**derived**)

With 4 degrees of freedom and t₄,₀.₀₂₅ = 2.776 (statistical table value), the 95% confidence interval for the slope is ±55 K (**derived**), giving:

**ΔH\_sol = −13.7 ± 0.5 kJ/mol (95% CI)** (**derived from Block 1 inspected data**)

### From Block 2 data (GLOBlit_10864 :: PROPblock_72)

Using the 3 inspected (T, H) pairs and computing ln(H) vs 1/T (**derived**):

- **Slope** = −1749 K (**derived**)
- **ΔH\_sol** = 8.314 × (−1749) = **−14.5 kJ/mol** (**derived**)

With only 1 degree of freedom, the uncertainty is large (~±2–3 kJ/mol, **estimated**), but consistent with Block 1.

### Best estimate

**ΔH\_sol = −13.7 ± 0.5 kJ/mol** (from Block 1, the more precise dataset). The negative value confirms exothermic CO₂ dissolution: as temperature rises from 293.15 K to 323.15 K, H increases from 2900 to 4910 kPa (Block 1 inspected values), meaning CO₂ solubility decreases — characteristic of physical gas absorption driven by favorable CO₂–[NTf₂]⁻ interactions.

---

## 3. Consistency Check with Low-Pressure Solubility Measurements

Henry's law states P = H·x as x → 0. At finite x, the apparent Henry's constant H\_app = P/x (**derived**) deviates from the true H. All (T, P, x) values below are from verbatim block inspections; H\_app and ratios are **derived**.

### Source A: GLOBlit_8739 :: PROPblock_1 (DOI: 10.1021/je050357o)
Phase equilibration, 16 points, 279.98–339.97 K (INSP_3f36471c1ea9).

Lowest-pressure points at temperatures overlapping with Block 1 Henry's constants:

- **299.98 K:** P = 405.8 kPa, x = 0.1063 → H\_app = 405.8/0.1063 = 3818 kPa (**derived**). Compare with Block 1 H at 298.15 K = 3190 kPa → ratio 3818/3190 = 1.20 (**derived**). H\_app exceeds H by ~20%, consistent with positive deviations from Henry's law at x ≈ 0.10.

- **319.98 K:** P = 518.1 kPa, x = 0.0990 → H\_app = 518.1/0.0990 = 5233 kPa (**derived**). Compare with Block 1 average H at 318.15 K = 4470 kPa (**derived average**) → ratio 5233/4470 = 1.17 (**derived**). Again H\_app > H, consistent with positive deviations.

The P–x data at 279.98 K further confirm this pattern: P/x increases systematically with x (291.8/0.1151 = 2535; 719.2/0.2472 = 2910; 1458.4/0.4141 = 3521; 2059.5/0.5123 = 4021 — all **derived** from inspected values), showing the expected positive departure from the dilute-limit Henry's law line.

### Source B: GLOBlit_3961 :: PROPblock_1 (DOI: 10.1016/j.jct.2013.08.008)
Volumetric method, 30 points, 273.15–413.15 K (INSP_4b7f7190d512).

Lowest-x points at overlapping temperatures:

- **293.15 K:** P = 522 kPa, x = 0.1657 → H\_app = 522/0.1657 = 3150 kPa (**derived**). Block 1 H at 293.15 K = 2900 kPa → ratio = 3150/2900 = 1.09 (**derived**).

- **313.15 K:** P = 546 kPa, x = 0.1279 → H\_app = 546/0.1279 = 4269 kPa (**derived**). Block 1 H at 313.15 K = 4130 kPa → ratio = 4269/4130 = 1.03 (**derived**).

The ratio is closer to 1.0 at 313.15 K where x = 0.1279 is nearer the dilute limit than x = 0.1657 at 293.15 K — physically consistent.

### Source C: GLOBlit_7324 :: PROPblock_12 (DOI: 10.1021/acs.jced.7b00786)
Vapor pressure at 313.15 K (INSP_44671f18972c).

Lowest composition: x = 0.222, P = 1303 kPa → H\_app = 1303/0.222 = 5869 kPa (**derived**). Block 1 H at 313.15 K = 4130 kPa → ratio = 5869/4130 = 1.42 (**derived**). The large 42% positive deviation at x = 0.222 is expected — this composition is well beyond the dilute regime.

### Source D: GLOBlit_3779 :: PROPblock_2 (DOI: 10.1016/j.jct.2012.11.030)
Molality at 323.15 K (INSP_dc9c69bde015).

The molar mass of [bmim][NTf₂] (C₁₀H₁₅F₆N₃O₄S₂) is 419.36 g/mol (**derived from the molecular formula and standard atomic masses**). Converting the lowest-pressure point (m = 0.2257 mol/kg, P = 380 kPa) to mole fraction: x = 0.2257 × 0.41936 / (1 + 0.2257 × 0.41936) = 0.0865 (**derived**). H\_app = 380/0.0865 = 4394 kPa (**derived**). Block 1 H at 323.15 K = 4910 kPa → ratio = 4394/4910 = 0.90 (**derived**); Block 2 H at 323 K = 4770 kPa → ratio = 4394/4770 = 0.92 (**derived**).

At the second point (m = 0.4173, P = 740 kPa): x = 0.1489 (**derived**), H\_app = 740/0.1489 = 4970 kPa (**derived**), ratio to Block 1 = 4970/4910 = 1.01 (**derived**). The near-unity ratio at x ≈ 0.15 and the slight sub-unity ratio at x ≈ 0.09 suggest this dataset's low-pressure data are broadly consistent with the Henry's constants, with the ~10% discrepancy at the lowest point within the combined experimental uncertainties of the different measurement techniques.

---

## 4. Summary

| Quantity | Value | Provenance |
|----------|-------|------------|
| ΔH\_sol (Block 1 van't Hoff) | **−13.7 ± 0.5 kJ/mol** (95% CI) | Derived from 6 temperatures, 11 inspected H values (GLOBlit_6787::PROPblock_2) |
| ΔH\_sol (Block 2 van't Hoff) | **−14.5 kJ/mol** (large uncertainty) | Derived from 3 inspected H values (GLOBlit_10864::PROPblock_72) |

**Consistency verdict:** The low-pressure solubility measurements from three independent mole-fraction-based studies are **consistent** with the Henry's law constants. At finite CO₂ loadings (x ≈ 0.10–0.22), the apparent Henry's constants P/x systematically exceed the true H values, with the deviation increasing with x — physically expected for positive deviations from Henry's law. The molality-based dataset (GLOBlit_3779) shows agreement within ~10% at the lowest loading. All five independent ThermoML sources paint a coherent picture of exothermic CO₂ physical absorption in [bmim][NTf₂] with ΔH\_sol ≈ −14 kJ/mol.



---
*Note: No fitting tools were called during this run (fit_block, fit_block_derived, fit_multi_system). All numbers above come from database queries only — no Redlich-Kister or other curve fits were performed.*






















### Core claims

- Van't Hoff analysis of Henry's law constants for CO₂ in [bmim][NTf₂] from two independent ThermoML datasets yields an enthalpy of solution of approximately −13.7 ± 0.5 kJ/mol (95% CI, from the 11-point dataset spanning 293.15–323.15 K) and −14.5 kJ/mol (from a 3-point dataset spanning 303–323 K), indicating exothermic CO₂ dissolution.
- As temperature increases from 293.15 K to 323.15 K, the Henry's law constant increases from 2900 to 4910 kPa (Block 1 inspected values), meaning CO₂ solubility decreases with temperature, characteristic of physical gas absorption.
- Low-pressure solubility measurements from three independent mole-fraction-based studies are consistent with the Henry's law constants: at finite CO₂ mole fractions (x ≈ 0.10–0.22), the apparent Henry's constants P/x systematically exceed the true infinite-dilution H values, with the deviation increasing with x, as expected for positive deviations from Henry's law.
- A molality-based solubility dataset shows agreement within ~10% at the lowest CO₂ loading, broadly consistent with the Henry's law constants given combined experimental uncertainties across different measurement techniques.
- All derived quantities (slopes, ΔH_sol, apparent Henry's constants, mole fraction conversions) are computed values, not directly inspected database entries                                                                      .

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_6787 | 10.1021/acs.jced.5b00990 | PROPblock_2 |  | Primary source of Henry's law constants for CO₂ in [bmim][NTf₂] (11 data points, 293.15–323.15 K, H range 2900–4910 kPa). Used for the main van't Hoff regression yielding ΔH_sol = −13.7 ± 0.5 kJ/mol. |
| GLOBlit_10864 | 10.1021/je700297c | PROPblock_72 |  | Secondary source of Henry's law constants for CO₂ in [bmim][NTf₂] (3 data points, 303–323 K, H range 3340–4770 kPa). Provides an independent van't Hoff estimate of ΔH_sol = −14.5 kJ/mol, consistent with the primary dataset. |
| GLOBlit_8739 | 10.1021/je050357o | PROPblock_1 |  | Provides CO₂ solubility (mole fraction vs. pressure) data at 279.98–339.97 K used for the consistency check. Apparent Henry's constants P/x at finite x systematically exceed the true H values, confirming positive deviations from Henry's law. |
| GLOBlit_3961 | 10.1016/j.jct.2013.08.008 | PROPblock_1 |  | Provides CO₂ solubility (mole fraction vs. pressure) data at 273.15–413.15 K used for the consistency check. Apparent Henry's constants at 293.15 K and 313.15 K are within 3–9% of the true H values, supporting consistency. |
| GLOBlit_7324 | 10.1021/acs.jced.7b00786 | PROPblock_12 |  | Provides vapor pressure data for CO₂/[bmim][NTf₂] at 313.15 K at higher mole fractions (0.222–0.712). The 42% positive deviation of P/x from H at x = 0.222 demonstrates expected departure from Henry's law at concentrated compositions. |
| GLOBlit_3779 | 10.1016/j.jct.2012.11.030 | PROPblock_2 |  | Provides CO₂ solubility in molality at 323.15 K. After conversion to mole fraction, apparent Henry's constants at the lowest loading agree within ~10% of the true H values from the Henry's law blocks, supporting overall consistency. |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
