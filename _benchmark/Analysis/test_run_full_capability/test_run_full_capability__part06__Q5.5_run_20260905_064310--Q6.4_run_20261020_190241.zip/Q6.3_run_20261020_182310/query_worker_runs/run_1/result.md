# Delegated Query L1 worker — result

**Question:** ## Purpose
Find Henry's law constants of carbon dioxide (CO2) in 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide ([bmim][NTf2]) in ThermoML

## Instruction
Search for blocks containing Henry's law constant data for the system carbon dioxide + 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide. The ionic liquid may also be called [bmim][Tf2N], [C4mim][NTf2], or BMIM-NTf2. Look for property types related to Henry's law constant. Return DOIs, block numbers, temperature ranges, and property IDs.

## ID Catalog (from working memory)
[]

**Iterations:** 7  |  **Elapsed:** 118.1s  |  **Tools:** 6  |  **Timed out:** False

---

## Answer

## Henry's Law Constants of CO₂ in [bmim][NTf₂] — ThermoML Results

**Property:** Henry's Law constant (mole fraction scale) — **GLOBprop_27**, units: kPa

Two data blocks were found in the ThermoML database for the binary system carbon dioxide (GLOBcomp_3) + 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide (GLOBcomp_50), both reporting Henry's law constants at infinite dilution of CO₂ in the liquid phase.

---

### Block 1 — GLOBlit_6787 :: PROPblock_2
- **DOI:** 10.1021/acs.jced.5b00990
- **Method:** Transient thin film
- **Data points:** 11
- **Temperature range:** 293.15–323.15 K
- **Constraint:** x(CO₂) = 0.0 (infinite dilution)

| T (K)   | H (kPa) | ±U (kPa) |
|---------|---------|-----------|
| 293.15  | 2900    | 71.976    |
| 298.15  | 3190    | 78.937    |
| 303.15  | 3460    | 85.692    |
| 303.15  | 3480    | 86.168    |
| 303.15  | 3490    | 86.407    |
| 313.15  | 4130    | 102.04    |
| 318.15  | 4460    | 110.355   |
| 318.15  | 4510    | 111.568   |
| 318.15  | 4470    | 110.598   |
| 318.15  | 4440    | 109.87    |
| 323.15  | 4910    | 121.609   |

### Block 2 — GLOBlit_10864 :: PROPblock_72
- **DOI:** 10.1021/je700297c
- **Method:** Chromatography
- **Data points:** 3
- **Temperature range:** 303–323 K
- **Constraint:** x(CO₂) = 0.0 (infinite dilution)

| T (K) | H (kPa) | ±U (kPa) |
|--------|---------|-----------|
| 303    | 3340    | 200       |
| 313    | 4120    | 250       |
| 323    | 4770    | 290       |

---

### Chemical Insight

The Henry's law constant for CO₂ in [bmim][NTf₂] increases with temperature across both datasets, indicating decreasing CO₂ solubility at higher temperatures — consistent with the exothermic nature of physical gas absorption in ionic liquids. In Block 1 (GLOBlit_6787 :: PROPblock_2), H rises from 2900 kPa at 293.15 K to 4910 kPa at 323.15 K. In Block 2 (GLOBlit_10864 :: PROPblock_72), H rises from 3340 kPa at 303 K to 4770 kPa at 323 K. The two independent studies show reasonable agreement at overlapping temperatures (e.g., at ~303 K: Block 1 reports 3460–3490 kPa while Block 2 reports 3340 kPa; at ~323 K: Block 1 reports 4910 kPa while Block 2 reports 4770 kPa). The uncertainties in Block 2 are notably larger than in Block 1, reflecting the different measurement techniques.

No data were found for Henry's law constant on the molality scale (GLOBprop_55) or amount concentration scale (GLOBprop_69) for this system.

---
[UNGROUNDED DATA FLAGS] The following quoted values could not be verified against any verbatim data inspection in this run and must be treated as UNVERIFIED:
- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 3460 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
  fix (required — this IS a database value, under a different block): `re-anchor 3460 to GLOBlit_6787::PROPblock_2 — no new tool call needed`
- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 3490 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
  fix (required — this IS a database value, under a different block): `re-anchor 3490 to GLOBlit_6787::PROPblock_2 — no new tool call needed`
- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 4910 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
  fix (required — this IS a database value, under a different block): `re-anchor 4910 to GLOBlit_6787::PROPblock_2 — no new tool call needed`
Inspected so far: PROPblock_2, PROPblock_72

### Summary

Henry's Law constants (mole-fraction scale, kPa) for CO₂ at infinite dilution in [bmim][NTf₂] were reported in two ThermoML data blocks. Block 1 (DOI 10.1021/acs.jced.5b00990, transient thin-film method, 11 points, 293.15–323.15 K) gives H values rising from 2900 kPa at 293.15 K to 4910 kPa at 323.15 K, with uncertainties of roughly 72–122 kPa. Block 2 (DOI 10.1021/je700297c, chromatographic method, 3 points, 303–323 K) gives H values of 3340 kPa at 303 K, 4120 kPa at 313 K, and 4770 kPa at 323 K, with uncertainties of 200–290 kPa. Both datasets show H increasing with temperature, consistent with exothermic physical absorption and decreasing CO₂ solubility at higher temperatures. The two independent studies agree reasonably at overlapping temperatures (e.g., ~3460–3490 vs. 3340 kPa near 303 K; 4910 vs. 4770 kPa near 323 K). No data were found on molality or amount-concentration scales for this system.

### Core claims

- Two independent ThermoML datasets report Henry's law constants (kPa, mole fraction scale) for CO₂ at infinite dilution in [bmim][NTf₂]: Block 1 (DOI 10.1021/acs.jced.5b00990, transient thin film method) spans 293.15–323.15 K with H rising from 2900 kPa to 4910 kPa, and Block 2 (DOI 10.1021/je700297c, chromatography) spans 303–323 K with H rising from 3340 kPa to 4770 kPa.
- In both datasets the Henry's law constant increases with temperature, indicating decreasing CO₂ solubility at higher temperatures, consistent with exothermic physical gas absorption in ionic liquids.
- The two studies show reasonable agreement at overlapping temperatures: at ~303 K, Block 1 reports 3460–3490 kPa while Block 2 reports 3340 kPa; at ~323 K, Block 1 reports 4910 kPa while Block 2 reports 4770 kPa. Block 2 uncertainties are notably larger than Block 1, reflecting different measurement techniques.
- No data were found for Henry's law constant on the molality scale or amount concentration scale for this system.

**Status:** success

---

## Core ID Updates (deterministic ledger)

Deterministic identifier updates; rendered by the browser.

```json
[
  {
    "action": "add",
    "core_GLOB_id": "GLOBcomp_3",
    "registry_id": "carbon_dioxide",
    "name": "carbon dioxide"
  },
  {
    "action": "add",
    "core_GLOB_id": "GLOBcomp_50",
    "registry_id": "1-butyl-3-methylimidazolium_bis(trifluoromethylsulfonyl)imide",
    "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide"
  },
  {
    "action": "add",
    "core_GLOB_id": "GLOBprop_27",
    "registry_id": "henrys_law_constant_mole_fraction_scale_kpa_{DOIcomp_id}",
    "name": "Henry's Law constant (mole fraction scale), kPa"
  },
  {
    "action": "add",
    "core_GLOB_id": "GLOBlit_6787",
    "registry_id": "2016-fri-kok-0",
    "name": "10.1021/acs.jced.5b00990"
  },
  {
    "action": "add",
    "core_GLOB_id": "GLOBlit_10864",
    "registry_id": "2007-zha-zha-4",
    "name": "10.1021/je700297c"
  }
]
```

---

## Core Blocks Found (deterministic ledger)

Database-hydrated core block records; rendered by the browser.

```json
[
  {
    "lit_num_id": "GLOBlit_6787",
    "block_number": "PROPblock_2",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_3",
      "GLOBcomp_50"
    ],
    "prop_num_ids": [
      "GLOBprop_27"
    ],
    "description": "Henry's law constant (mole fraction scale, kPa) of CO2 in [bmim][NTf2] at 293.15–323.15 K, 11 data points from transient thin film method.",
    "doi": "10.1021/acs.jced.5b00990",
    "lit_id": "2016-fri-kok-0",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 11,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_2_1"
      },
      {
        "org_num": "DOIcomp_5",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_5_1"
      }
    ],
    "solvents": [],
    "constraints": [
      {
        "BLKconstr_id": "BLKconstr_1",
        "constr_num_id": "GLOBconstr_3",
        "constr_id": "mole_fraction_DOIcomp_2",
        "name": "Mole fraction",
        "type": "eComponentComposition",
        "value": 0.0,
        "digits": 1,
        "component_org_num": "DOIcomp_2",
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      }
    ],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_1",
        "var_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Temperature, K",
          "min": 293.15,
          "max": 323.15,
          "n_unique": 6
        },
        "range_min": 293.15,
        "range_max": 323.15
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_27",
        "prop_ID": "henrys_law_constant_mole_fraction_scale_kpa_DOIcomp_2",
        "name": "Henry's Law constant (mole fraction scale), kPa",
        "group": "CompositionAtPhaseEquilibrium",
        "component_org_num": "DOIcomp_2",
        "meas_num_id": "GLOBmeas_878",
        "meas_ID": "transient_this_film_method",
        "method_standard": null,
        "method_custom": "transient this film method",
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Henry's Law constant (mole fraction scale), kPa",
          "min": 2900.0,
          "max": 4910.0,
          "mean": 3949.090909,
          "std": 662.637979,
          "n": 11
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": 2900.0,
        "range_max": 4910.0
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKconstr_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_2_1"
      },
      {
        "org_num": "DOIcomp_5",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_5_1"
      }
    ],
    "parent_n_datapoints": 11,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  },
  {
    "lit_num_id": "GLOBlit_10864",
    "block_number": "PROPblock_72",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_3",
      "GLOBcomp_50"
    ],
    "prop_num_ids": [
      "GLOBprop_27"
    ],
    "description": "Henry's law constant (mole fraction scale, kPa) of CO2 in [bmim][NTf2] at 303–323 K, 3 data points from chromatography method.",
    "doi": "10.1021/je700297c",
    "lit_id": "2007-zha-zha-4",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 3,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_24",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_24_1"
      },
      {
        "org_num": "DOIcomp_9",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_9_1"
      }
    ],
    "solvents": [],
    "constraints": [
      {
        "BLKconstr_id": "BLKconstr_1",
        "constr_num_id": "GLOBconstr_3",
        "constr_id": "mole_fraction_DOIcomp_24",
        "name": "Mole fraction",
        "type": "eComponentComposition",
        "value": 0.0,
        "digits": 1,
        "component_org_num": "DOIcomp_24",
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      }
    ],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_1",
        "var_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Temperature, K",
          "min": 303.0,
          "max": 323.0,
          "n_unique": 3
        },
        "range_min": 303.0,
        "range_max": 323.0
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_27",
        "prop_ID": "henrys_law_constant_mole_fraction_scale_kpa_DOIcomp_24",
        "name": "Henry's Law constant (mole fraction scale), kPa",
        "group": "CompositionAtPhaseEquilibrium",
        "component_org_num": "DOIcomp_24",
        "meas_num_id": "GLOBmeas_1",
        "meas_ID": "chromatography",
        "method_standard": "Chromatography",
        "method_custom": null,
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Henry's Law constant (mole fraction scale), kPa",
          "min": 3340.0,
          "max": 4770.0,
          "mean": 4076.666667,
          "std": 715.984171,
          "n": 3
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": 3340.0,
        "range_max": 4770.0
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKconstr_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_24",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_24_1"
      },
      {
        "org_num": "DOIcomp_9",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_9_1"
      }
    ],
    "parent_n_datapoints": 3,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  }
]
```

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1021/acs.jced.5b00990",
    "block_number": "PROPblock_2",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "mole_fraction_<carbon dioxide>",
      "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>",
      "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "293.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "2900",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "71.976"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "298.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "3190",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "78.937"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "303.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "3460",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "85.692"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "303.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "3480",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "86.168"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "303.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "3490",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "86.407"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "313.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "4130",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "102.04"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "318.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "4460",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "110.355"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "318.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "4510",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "111.568"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "318.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "4470",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "110.598"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "318.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "4440",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "109.87"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "323.15",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "4910",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "121.609"
      }
    ],
    "inspection_id": "INSP_8f65d694d36c",
    "lit_num_id": "GLOBlit_6787"
  },
  {
    "doi": "10.1021/je700297c",
    "block_number": "PROPblock_72",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "mole_fraction_<carbon dioxide>",
      "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>",
      "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "303",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "3340",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "200"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "313",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "4120",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "250"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "323",
        "mole_fraction_<carbon dioxide>": "0.0",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>": "4770",
        "henrys_law_constant_mole_fraction_scale_kpa_<carbon dioxide>_U": "290"
      }
    ],
    "inspection_id": "INSP_ac34d22698b5",
    "lit_num_id": "GLOBlit_10864"
  }
]
```
