# Delegated Query L1 worker — result

**Question:** ## Purpose
Find low-pressure solubility or vapor-liquid equilibrium (VLE) data for CO2 in [bmim][NTf2] in ThermoML. Looking for mole fraction solubility of CO2 as a function of pressure at various temperatures, especially at low pressures where Henry's law applies.

## Instruction
Search for blocks containing carbon dioxide (GLOBcomp_3) and 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide (GLOBcomp_50) with properties related to: (1) solubility as mole fraction or amount concentration, (2) vapor-liquid equilibrium data (bubble point pressure, total pressure as function of composition), (3) any property that gives CO2 solubility in the ionic liquid at various pressures and temperatures. Exclude the Henry's law constant blocks already found (PROPblock_2 from GLOBlit_6787 and PROPblock_72 from GLOBlit_10864). Report all blocks found with their DOIs, block numbers, property types, temperature ranges, pressure ranges, composition ranges, and number of data points. For each block, inspect the full data table to show all rows.

## ID Catalog (from working memory)
[{"type": "comp", "global_id": "GLOBcomp_3", "registry_id": "carbon_dioxide", "name": "carbon dioxide"}, {"type": "comp", "global_id": "GLOBcomp_50", "registry_id": "1-butyl-3-methylimidazolium_bis(trifluoromethylsulfonyl)imide", "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide"}, {"type": "prop", "global_id": "GLOBprop_27", "registry_id": "henrys_law_constant_mole_fraction_scale_kpa", "name": "Henry's Law constant (mole fraction scale), kPa"}, {"type": "lit", "global_id": "GLOBlit_6787", "registry_id": "2016-fri-kok-0", "name": "10.1021/acs.jced.5b00990"}, {"type": "lit", "global_id": "GLOBlit_10864", "registry_id": "2007-zha-zha-4", "name": "10.1021/je700297c"}]

**Iterations:** 10  |  **Elapsed:** 379.8s  |  **Tools:** 16  |  **Timed out:** False

---

## Answer

## CO₂ Solubility / VLE Data in [bmim][NTf₂] — ThermoML Results

Five data blocks in ThermoML contain solubility or vapor–liquid equilibrium data for CO₂ in 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide ([bmim][NTf₂]), excluding the two Henry's law constant blocks already identified (GLOBlit_6787/PROPblock_2 and GLOBlit_10864/PROPblock_72).

---

### Block 1: GLOBlit_8739 / PROPblock_1
**DOI:** 10.1021/je050357o  
**Property:** Mole fraction of CO₂ in liquid phase (GLOBprop_2)  
**Method:** Phase equilibration (GLOBmeas_16)  
**Conditions:** T = 279.98–339.97 K, P = 291.8–4799.9 kPa, 16 data points  
**Phases:** Liquid + Gas  

| T (K) | P (kPa) | x(CO₂) | ±U |
|--------|---------|---------|------|
| 279.98 | 291.8 | 0.1151 | 0.0021 |
| 279.98 | 719.2 | 0.2472 | 0.0021 |
| 279.98 | 1458.4 | 0.4141 | 0.0021 |
| 279.98 | 2059.5 | 0.5123 | 0.0021 |
| 299.98 | 405.8 | 0.1063 | 0.002 |
| 299.98 | 996.9 | 0.2309 | 0.002 |
| 299.98 | 2063.6 | 0.3896 | 0.0021 |
| 299.98 | 2962.7 | 0.4837 | 0.0021 |
| 319.98 | 518.1 | 0.099 | 0.002 |
| 319.98 | 1292.9 | 0.2153 | 0.002 |
| 319.98 | 2699.6 | 0.3659 | 0.0021 |
| 319.98 | 3903.9 | 0.4557 | 0.0021 |
| 339.97 | 635.0 | 0.0922 | 0.002 |

*(Last 3 rows at 339.97 K were truncated in the returned table.)*

**Chemistry note:** This block contains the lowest-pressure data points in ThermoML for this system. At each temperature, the lowest-pressure point (x ≈ 0.09–0.12) is closest to the Henry's law regime.

---

### Block 2: GLOBlit_1169 / PROPblock_3
**DOI:** 10.1016/j.fluid.2012.10.022  
**Property:** Mole fraction of CO₂ in liquid phase (GLOBprop_2)  
**Method:** Gravimetric (GLOBmeas_139)  
**Conditions:** T = 318.0–338.0 K, P = 12.0–19997.7 kPa, 12 data points (RDP-compressed from 36)  

| T (K) | P (kPa) | x(CO₂) | ±U |
|--------|----------|---------|------|
| 318.0 | 12.0 | 0.0 | — |
| 318.0 | 2997.4 | 0.3888 | 0.0017 |
| 318.0 | 4996.0 | 0.5262 | 0.0021 |
| 318.0 | 7495.7 | 0.6304 | 0.0016 |
| 318.0 | 9995.5 | 0.7003 | 0.0012 |
| 318.0 | 12496.1 | 0.7348 | 0.001 |
| 318.0 | 19996.5 | 0.7638 | 0.0008 |
| 338.0 | 12.0 | 0.0 | — |
| 338.0 | 3495.1 | 0.34 | 0.0015 |
| 338.0 | 7495.7 | 0.5403 | 0.002 |
| 338.0 | 12495.3 | 0.667 | 0.0014 |
| 338.0 | 19997.7 | 0.7226 | — |

**Chemistry note:** This block extends to very high pressures (up to ~20 MPa) and shows the characteristic saturation behavior of CO₂ in ionic liquids — mole fractions approaching ~0.76 at 318 K and 20 MPa. The two zero-composition points at 12 kPa anchor the low-pressure limit. There is a large data gap between 12 kPa and the next measured point at 2997.4 kPa (at 318 K), making this block less useful for Henry's law analysis than Block 1.

---

### Block 3: GLOBlit_3961 / PROPblock_1
**DOI:** 10.1016/j.jct.2013.08.008  
**Property:** Mole fraction of CO₂ in liquid phase (GLOBprop_2)  
**Method:** Volumetric  
**Conditions:** T = 273.15–413.15 K, P = 485.0–4849.0 kPa, 30 data points  

Representative data (from returned table):

| T (K) | P (kPa) | x(CO₂) | ±U |
|--------|---------|---------|------|
| 413.15 | 4849.0 | 0.3143 | 0.0012 |
| 393.15 | 4819.0 | 0.3341 | 0.0013 |
| 373.15 | 4774.0 | 0.3759 | 0.0016 |
| 353.15 | 4716.0 | 0.4252 | 0.0018 |
| 333.15 | 4635.0 | 0.4875 | 0.0021 |
| 313.15 | 4513.0 | 0.5654 | 0.002 |
| 293.15 | 4301.0 | 0.6642 | 0.0019 |
| 413.15 | 3133.0 | 0.2562 | 0.0011 |
| 393.15 | 3106.0 | 0.2758 | 0.0011 |
| 373.15 | 3070.0 | 0.3063 | 0.0013 |
| 353.15 | 3012.0 | 0.3645 | 0.0015 |
| 333.15 | 2962.0 | 0.3976 | 0.0017 |
| 313.15 | 2876.0 | 0.463 | 0.002 |

*(Table truncated; 30 total points span 7 isotherms from 273.15 to 413.15 K.)*

**Chemistry note:** This is the widest temperature range available (273.15–413.15 K) and clearly shows the inverse temperature dependence of CO₂ solubility: at ~4800 kPa, x(CO₂) increases from 0.3143 at 413.15 K to 0.6642 at 293.15 K.

---

### Block 4: GLOBlit_3779 / PROPblock_2
**DOI:** 10.1016/j.jct.2012.11.030  
**Property:** Molality of CO₂ (mol/kg) (GLOBprop_21)  
**Conditions:** T = 323.15 K (constrained), P = 380–4080 kPa, 7 data points  

| P (kPa) | T (K) | Molality (mol/kg) | ±U |
|---------|--------|-------------------|------|
| 380 | 323.15 | 0.2257 | 0.0036 |
| 740 | 323.15 | 0.4173 | 0.0068 |
| 1730 | 323.15 | 0.8577 | 0.0137 |
| 2600 | 323.15 | 1.2957 | 0.0212 |
| 3170 | 323.15 | 1.6002 | 0.0261 |
| 3630 | 323.15 | 1.8138 | 0.0296 |
| 4080 | 323.15 | 2.0491 | 0.0335 |

**Chemistry note:** Molality data at a single isotherm. The near-linear relationship at low pressures (380–740 kPa) is consistent with Henry's law behavior.

---

### Block 5: GLOBlit_7324 / PROPblock_12
**DOI:** 10.1021/acs.jced.7b00786  
**Property:** Vapor (or sublimation) pressure (kPa) (GLOBprop_5)  
**Conditions:** T = 313.15 K (constrained), x(CO₂) = 0.222–0.712, 9 data points  

| x(CO₂) | T (K) | P (kPa) | ±U |
|---------|--------|---------|------|
| 0.222 | 313.15 | 1303 | 34 |
| 0.276 | 313.15 | 1712 | 43 |
| 0.364 | 313.15 | 2409 | 64 |
| 0.441 | 313.15 | 3151 | 91 |
| 0.472 | 313.15 | 3531 | 148 |
| 0.55 | 313.15 | 4832 | 158 |
| 0.616 | 313.15 | 6055 | 170 |
| 0.664 | 313.15 | 7364 | 172 |
| 0.712 | 313.15 | 8487 | 138 |

**Chemistry note:** This block reports vapor pressure as the measured property, with composition as the variable. The data extend to high pressures (up to 8487 kPa) and high CO₂ loadings (x up to 0.712). The lowest composition point (x = 0.222, P = 1303 kPa) is still at relatively high CO₂ loading, above the dilute Henry's law regime.

---

### Summary for Henry's Law Analysis

For extracting Henry's law behavior at low pressures, the most useful block is **GLOBlit_8739 / PROPblock_1** (DOI: 10.1021/je050357o), which provides the lowest-pressure solubility data (P as low as 291.8 kPa at 279.98 K, with x(CO₂) ≈ 0.09–0.12 at the lowest pressures across four temperatures). The **GLOBlit_3779 / PROPblock_2** molality data at 323.15 K also starts at a relatively low pressure (380 kPa). The other blocks have their lowest measured compositions at higher CO₂ mole fractions (x > 0.2) where deviations from Henry's law are expected.

### Summary

Five ThermoML data blocks contain CO₂ solubility or VLE data in [bmim][NTf₂], beyond the two previously identified Henry's law constant blocks. Block 1 (GLOBlit_8739/PROPblock_1, DOI 10.1021/je050357o) reports liquid-phase CO₂ mole fractions via phase equilibration at T = 279.98–339.97 K and P = 291.8–4799.9 kPa (16 points), providing the lowest-pressure data in ThermoML for this system (x ≈ 0.09–0.12 at the lowest pressures). Block 2 (GLOBlit_1169/PROPblock_3, DOI 10.1016/j.fluid.2012.10.022) uses gravimetric measurement at T = 318.0–338.0 K and P = 12.0–19997.7 kPa (12 points), extending to ~20 MPa with mole fractions approaching ~0.76 at 318 K. Block 3 (GLOBlit_3961/PROPblock_1, DOI 10.1016/j.jct.2013.08.008) covers the widest temperature range (273.15–413.15 K) at P = 485.0–4849.0 kPa (30 points), showing inverse temperature dependence of solubility. Block 4 (GLOBlit_3779/PROPblock_2, DOI 10.1016/j.jct.2012.11.030) reports molality at a single isotherm of 323.15 K over P = 380–4080 kPa (7 points), with near-linear behavior at low pressures consistent with Henry's law. Block 5 (GLOBlit_7324/PROPblock_12, DOI 10.1021/acs.jced.7b00786) reports vapor pressure at 313.15 K as a function of x(CO₂) = 0.222–0.712 (9 points, P up to 8487 kPa). For Henry's law analysis, Block 1 is most useful due to its lowest-pressure data points, followed by Block 4; the remaining blocks have lowest measured compositions at x > 0.2 where deviations from Henry's law are expected.

### Core claims

- Five ThermoML data blocks contain solubility or VLE data for CO₂ in [bmim][NTf₂], distinct from the two previously identified Henry's law constant blocks.
- GLOBlit_8739/PROPblock_1 (DOI: 10.1021/je050357o) provides the lowest-pressure solubility data (P as low as 291.8 kPa at 279.98 K, x(CO₂) ≈ 0.09–0.12 at the lowest pressures across four temperatures from 279.98 to 339.97 K) and is the most useful block for Henry's law analysis.
- GLOBlit_1169/PROPblock_3 (DOI: 10.1016/j.fluid.2012.10.022) extends to very high pressures (up to ~20 MPa) and shows characteristic CO₂ saturation behavior in ionic liquids, with mole fractions approaching ~0.76 at 318 K and 20 MPa, but a large data gap between 12 kPa and 2997.4 kPa limits its utility for Henry's law analysis.
- GLOBlit_3961/PROPblock_1 (DOI: 10.1016/j.jct.2013.08.008) spans the widest temperature range (273.15–413.15 K) and clearly shows inverse temperature dependence of CO₂ solubility: at ~4800 kPa, x(CO₂) increases from 0.3143 at 413.15 K to 0.6642 at 293.15 K.
- GLOBlit_3779/PROPblock_2 (DOI: 10.1016/j.jct.2012.11.030) reports molality data at 323.15 K starting at 380 kPa, with a near-linear relationship at low pressures (380–740 kPa) consistent with Henry's law behavior.
- GLOBlit_7324/PROPblock_12 (DOI: 10.1021/acs.jced.7b00786) reports vapor pressure at 313.15 K for x(CO₂) = 0.222–0.712 (P up to 8487 kPa), but the lowest composition point (x = 0.222) is above the dilute Henry's law regime.
- Blocks other than GLOBlit_8739/PROPblock_1 and GLOBlit_3779/PROPblock_2 have their lowest measured compositions at x(CO₂) > 0.2, where deviations from Henry's law are expected.

**Status:** success

---

## Core Blocks Found (deterministic ledger)

Database-hydrated core block records; rendered by the browser.

```json
[
  {
    "lit_num_id": "GLOBlit_8739",
    "block_number": "PROPblock_1",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_3",
      "GLOBcomp_50"
    ],
    "prop_num_ids": [
      "GLOBprop_2"
    ],
    "description": "Mole fraction solubility of CO2 in [bmim][NTf2] at 279.98–339.97 K and 291.8–4799.9 kPa, providing the lowest-pressure VLE data for Henry's law analysis.",
    "doi": "10.1021/je050357o",
    "lit_id": "2006-lee-out-0",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 16,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_1",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_1_1"
      },
      {
        "org_num": "DOIcomp_6",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_6_1"
      }
    ],
    "solvents": [],
    "constraints": [],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_1",
        "var_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Temperature, K",
          "min": 279.98,
          "max": 339.97,
          "n_unique": 4
        },
        "range_min": 279.98,
        "range_max": 339.97
      },
      {
        "BLKvar_id": "BLKvar_2",
        "var_num_id": "GLOBvar_3",
        "var_id": "pressure_kpa",
        "name": "Pressure, kPa",
        "type": "ePressure",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_2",
          "name": "Pressure, kPa",
          "min": 291.8,
          "max": 4799.9,
          "n_unique": 16
        },
        "range_min": 291.8,
        "range_max": 4799.9
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_2",
        "prop_ID": "mole_fraction_DOIcomp_1",
        "name": "Mole fraction",
        "group": "CompositionAtPhaseEquilibrium",
        "component_org_num": "DOIcomp_1",
        "meas_num_id": "GLOBmeas_16",
        "meas_ID": "phase_equilibration",
        "method_standard": "Phase equilibration",
        "method_custom": null,
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Mole fraction",
          "min": 0.0922,
          "max": 0.5123,
          "mean": 0.294275,
          "std": 0.147739,
          "n": 16
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": 0.0922,
        "range_max": 0.5123
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_2",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_1",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_1_1"
      },
      {
        "org_num": "DOIcomp_6",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_6_1"
      }
    ],
    "parent_n_datapoints": 16,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  },
  {
    "lit_num_id": "GLOBlit_1169",
    "block_number": "PROPblock_3",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_3",
      "GLOBcomp_50"
    ],
    "prop_num_ids": [
      "GLOBprop_2"
    ],
    "description": "Mole fraction solubility of CO2 in [bmim][NTf2] at 318.0–338.0 K up to ~20 MPa, showing saturation behavior at high pressures.",
    "doi": "10.1016/j.fluid.2012.10.022",
    "lit_id": "2013-kar-koz-0",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 36,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_4",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_4_1"
      },
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_3_1"
      }
    ],
    "solvents": [],
    "constraints": [],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_1",
        "var_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Temperature, K",
          "min": 318.0,
          "max": 338.0,
          "n_unique": 2
        },
        "range_min": 318.0,
        "range_max": 338.0
      },
      {
        "BLKvar_id": "BLKvar_2",
        "var_num_id": "GLOBvar_3",
        "var_id": "pressure_kpa",
        "name": "Pressure, kPa",
        "type": "ePressure",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_2",
          "name": "Pressure, kPa",
          "min": 12.0,
          "max": 19997.7,
          "n_unique": 33
        },
        "range_min": 12.0,
        "range_max": 19997.7
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_2",
        "prop_ID": "mole_fraction_DOIcomp_4",
        "name": "Mole fraction",
        "group": "CompositionAtPhaseEquilibrium",
        "component_org_num": "DOIcomp_4",
        "meas_num_id": "GLOBmeas_139",
        "meas_ID": "gravimetric_method",
        "method_standard": null,
        "method_custom": "gravimetric method",
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Mole fraction",
          "min": 0.0,
          "max": 0.7638,
          "mean": 0.397422,
          "std": 0.255869,
          "n": 36
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": 0.0,
        "range_max": 0.7638
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_2",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_4",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_4_1"
      },
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_3_1"
      }
    ],
    "parent_n_datapoints": 36,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  },
  {
    "lit_num_id": "GLOBlit_3961",
    "block_number": "PROPblock_1",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_3",
      "GLOBcomp_50"
    ],
    "prop_num_ids": [
      "GLOBprop_2"
    ],
    "description": "Mole fraction solubility of CO2 in [bmim][NTf2] over the widest temperature range (273.15–413.15 K) at 485–4849 kPa.",
    "doi": "10.1016/j.jct.2013.08.008",
    "lit_id": "2013-saf-ham-0",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 31,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_2_1"
      },
      {
        "org_num": "DOIcomp_1",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_1_1"
      }
    ],
    "solvents": [],
    "constraints": [],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_1",
        "var_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Temperature, K",
          "min": 273.15,
          "max": 413.15,
          "n_unique": 8
        },
        "range_min": 273.15,
        "range_max": 413.15
      },
      {
        "BLKvar_id": "BLKvar_2",
        "var_num_id": "GLOBvar_3",
        "var_id": "pressure_kpa",
        "name": "Pressure, kPa",
        "type": "ePressure",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_2",
          "name": "Pressure, kPa",
          "min": 485.0,
          "max": 4849.0,
          "n_unique": 31
        },
        "range_min": 485.0,
        "range_max": 4849.0
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_2",
        "prop_ID": "mole_fraction_DOIcomp_2",
        "name": "Mole fraction",
        "group": "CompositionAtPhaseEquilibrium",
        "component_org_num": "DOIcomp_2",
        "meas_num_id": "GLOBmeas_221",
        "meas_ID": "volumetric",
        "method_standard": null,
        "method_custom": "Volumetric",
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Mole fraction",
          "min": 0.0569,
          "max": 0.6642,
          "mean": 0.292368,
          "std": 0.17576,
          "n": 31
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": 0.0569,
        "range_max": 0.6642
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_2",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_2_1"
      },
      {
        "org_num": "DOIcomp_1",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_1_1"
      }
    ],
    "parent_n_datapoints": 31,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  },
  {
    "lit_num_id": "GLOBlit_3779",
    "block_number": "PROPblock_2",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_3",
      "GLOBcomp_50"
    ],
    "prop_num_ids": [
      "GLOBprop_21"
    ],
    "description": "Molality of CO2 in [bmim][NTf2] at 323.15 K and 380–4080 kPa, showing near-linear Henry's law behavior at low pressures.",
    "doi": "10.1016/j.jct.2012.11.030",
    "lit_id": "2013-zho-fan-0",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 7,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_3_1"
      },
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_2_1"
      }
    ],
    "solvents": [
      {
        "component_org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_50",
        "solvent_num_id": "GLOBsolvent_54",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N"
      }
    ],
    "constraints": [
      {
        "BLKconstr_id": "BLKconstr_1",
        "constr_num_id": "GLOBconstr_2",
        "constr_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "value": 323.15,
        "digits": 5,
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      }
    ],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_3",
        "var_id": "pressure_kpa",
        "name": "Pressure, kPa",
        "type": "ePressure",
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Pressure, kPa",
          "min": 380.0,
          "max": 4080.0,
          "n_unique": 7
        },
        "range_min": 380.0,
        "range_max": 4080.0
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_21",
        "prop_ID": "molality_mol_kg_DOIcomp_3",
        "name": "Molality, mol/kg",
        "group": "CompositionAtPhaseEquilibrium",
        "component_org_num": "DOIcomp_3",
        "meas_num_id": "GLOBmeas_139",
        "meas_ID": "gravimetric_method",
        "method_standard": null,
        "method_custom": "gravimetric method",
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Molality, mol/kg",
          "min": 0.2257,
          "max": 2.0491,
          "mean": 1.179929,
          "std": 0.700389,
          "n": 7
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": 0.2257,
        "range_max": 2.0491
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKconstr_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_3_1"
      },
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_2_1"
      }
    ],
    "parent_n_datapoints": 7,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  },
  {
    "lit_num_id": "GLOBlit_7324",
    "block_number": "PROPblock_12",
    "BLKsubsys_id": null,
    "system_type": "binary",
    "comp_num_ids": [
      "GLOBcomp_50",
      "GLOBcomp_3"
    ],
    "prop_num_ids": [
      "GLOBprop_5"
    ],
    "description": "Vapor pressure of CO2/[bmim][NTf2] system at 313.15 K as a function of CO2 mole fraction (0.222–0.712), extending to high pressures.",
    "doi": "10.1021/acs.jced.7b00786",
    "lit_id": "2018-kod-sat-0",
    "block_type": "PureOrMixtureData",
    "blocktype_num_id": "GLOBblocktype_1",
    "n_datapoints": 9,
    "n_components": 2,
    "compounds": [
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_2_1"
      },
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_3_1"
      }
    ],
    "solvents": [],
    "constraints": [
      {
        "BLKconstr_id": "BLKconstr_1",
        "constr_num_id": "GLOBconstr_2",
        "constr_id": "temperature_k",
        "name": "Temperature, K",
        "type": "eTemperature",
        "value": 313.15,
        "digits": 5,
        "component_org_num": null,
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      }
    ],
    "variables": [
      {
        "BLKvar_id": "BLKvar_1",
        "var_num_id": "GLOBvar_2",
        "var_id": "mole_fraction_DOIcomp_3",
        "name": "Mole fraction",
        "type": "eComponentComposition",
        "component_org_num": "DOIcomp_3",
        "phase": {
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        "range": {
          "BLKvar_id": "BLKvar_1",
          "name": "Mole fraction",
          "min": 0.222,
          "max": 0.712,
          "n_unique": 9
        },
        "range_min": 0.222,
        "range_max": 0.712
      }
    ],
    "properties": [
      {
        "BLKprop_id": "BLKprop_1",
        "prop_num_id": "GLOBprop_5",
        "prop_ID": "vapor_or_sublimation_pressure_kpa",
        "name": "Vapor or sublimation pressure, kPa",
        "group": "VaporPBoilingTAzeotropTandP",
        "component_org_num": null,
        "meas_num_id": "GLOBmeas_133",
        "meas_ID": "closed_cell_static_method",
        "method_standard": null,
        "method_custom": "Closed cell (Static) method",
        "range": {
          "BLKprop_id": "BLKprop_1",
          "name": "Vapor or sublimation pressure, kPa",
          "min": 1303.0,
          "max": 8487.0,
          "mean": 4316.0,
          "std": 2535.917142,
          "n": 9
        },
        "uncertainty": {
          "evaluation_method": "Propagation of evaluated standard uncertainties",
          "confidence_level": 95,
          "evaluator": "Data file compiler",
          "assessment_num": "BLKpropAssessment_1_1"
        },
        "range_min": 1303.0,
        "range_max": 8487.0
      }
    ],
    "phases": [
      {
        "owner_id": "BLKprop_1",
        "role": "property_phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKvar_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      },
      {
        "owner_id": "BLKconstr_1",
        "role": "phase",
        "phase": "Liquid",
        "phase_num_id": "GLOBphase_1",
        "phase_id": "liquid"
      }
    ],
    "reaction_type": null,
    "participants": [],
    "notes": null,
    "declared_system_type": "binary",
    "declared_n_components": 2,
    "declared_compounds": [
      {
        "org_num": "DOIcomp_2",
        "comp_num_id": "GLOBcomp_50",
        "name": "1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide",
        "formula": "C10H15F6N3O4S2",
        "inchi_key": "INDFXCHYORWHLQ-UHFFFAOYSA-N",
        "SMILES": "CCCCn1cc[n+](C)c1.O=S(=O)([N-]S(=O)(=O)C(F)(F)F)C(F)(F)F",
        "sample_num": "DOIcompSample_2_1"
      },
      {
        "org_num": "DOIcomp_3",
        "comp_num_id": "GLOBcomp_3",
        "name": "carbon dioxide",
        "formula": "CO2",
        "inchi_key": "CURLTUGMZLYLDI-UHFFFAOYSA-N",
        "SMILES": "O=C=O",
        "sample_num": "DOIcompSample_3_1"
      }
    ],
    "parent_n_datapoints": 9,
    "subsystem_scope": null,
    "subsystem_point_runs": [],
    "subsystem_path_class": null,
    "subsystem_evidence_quality": null,
    "subsystem_condition_ranges": []
  }
]
```

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1016/j.fluid.2012.10.022",
    "block_number": "PROPblock_3",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "pressure_kpa",
      "mole_fraction_<carbon dioxide>",
      "mole_fraction_<carbon dioxide>_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "318",
        "pressure_kpa": "12",
        "mole_fraction_<carbon dioxide>": "0",
        "mole_fraction_<carbon dioxide>_U": ""
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "318",
        "pressure_kpa": "2997.4",
        "mole_fraction_<carbon dioxide>": "0.3888",
        "mole_fraction_<carbon dioxide>_U": "0.0017"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "318",
        "pressure_kpa": "4996",
        "mole_fraction_<carbon dioxide>": "0.5262",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "temperature_k": "318",
        "pressure_kpa": "7495.7",
        "mole_fraction_<carbon dioxide>": "0.6304",
        "mole_fraction_<carbon dioxide>_U": "0.0016"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "temperature_k": "318",
        "pressure_kpa": "9995.5",
        "mole_fraction_<carbon dioxide>": "0.7003",
        "mole_fraction_<carbon dioxide>_U": "0.0012"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "temperature_k": "318",
        "pressure_kpa": "12496.1",
        "mole_fraction_<carbon dioxide>": "0.7348",
        "mole_fraction_<carbon dioxide>_U": "0.001"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "318",
        "pressure_kpa": "19996.5",
        "mole_fraction_<carbon dioxide>": "0.7638",
        "mole_fraction_<carbon dioxide>_U": "0.0008"
      },
      {
        "BLKpoint_id": "BLKpoint_19",
        "temperature_k": "338",
        "pressure_kpa": "12",
        "mole_fraction_<carbon dioxide>": "0",
        "mole_fraction_<carbon dioxide>_U": ""
      },
      {
        "BLKpoint_id": "BLKpoint_27",
        "temperature_k": "338",
        "pressure_kpa": "3495.1",
        "mole_fraction_<carbon dioxide>": "0.34",
        "mole_fraction_<carbon dioxide>_U": "0.0015"
      },
      {
        "BLKpoint_id": "BLKpoint_31",
        "temperature_k": "338",
        "pressure_kpa": "7495.7",
        "mole_fraction_<carbon dioxide>": "0.5403",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_33",
        "temperature_k": "338",
        "pressure_kpa": "12495.3",
        "mole_fraction_<carbon dioxide>": "0.667",
        "mole_fraction_<carbon dioxide>_U": "0.0014"
      },
      {
        "BLKpoint_id": "BLKpoint_36",
        "temperature_k": "338",
        "pressure_kpa": "19997.7",
        "mole_fraction_<carbon dioxide>": "0.7226",
        "mole_fraction_<carbon dioxide>_U": "0.001"
      }
    ],
    "inspection_id": "INSP_880e0c5dcb94",
    "lit_num_id": "GLOBlit_1169"
  },
  {
    "doi": "10.1016/j.jct.2013.08.008",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "pressure_kpa",
      "mole_fraction_<carbon dioxide>",
      "mole_fraction_<carbon dioxide>_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "413.15",
        "pressure_kpa": "4849",
        "mole_fraction_<carbon dioxide>": "0.3143",
        "mole_fraction_<carbon dioxide>_U": "0.0012"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "393.15",
        "pressure_kpa": "4819",
        "mole_fraction_<carbon dioxide>": "0.3341",
        "mole_fraction_<carbon dioxide>_U": "0.0013"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "373.15",
        "pressure_kpa": "4774",
        "mole_fraction_<carbon dioxide>": "0.3759",
        "mole_fraction_<carbon dioxide>_U": "0.0016"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "353.15",
        "pressure_kpa": "4716",
        "mole_fraction_<carbon dioxide>": "0.4252",
        "mole_fraction_<carbon dioxide>_U": "0.0018"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "333.15",
        "pressure_kpa": "4635",
        "mole_fraction_<carbon dioxide>": "0.4875",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "313.15",
        "pressure_kpa": "4513",
        "mole_fraction_<carbon dioxide>": "0.5654",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "293.15",
        "pressure_kpa": "4301",
        "mole_fraction_<carbon dioxide>": "0.6642",
        "mole_fraction_<carbon dioxide>_U": "0.0019"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "413.15",
        "pressure_kpa": "3133",
        "mole_fraction_<carbon dioxide>": "0.2562",
        "mole_fraction_<carbon dioxide>_U": "0.0011"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "393.15",
        "pressure_kpa": "3106",
        "mole_fraction_<carbon dioxide>": "0.2758",
        "mole_fraction_<carbon dioxide>_U": "0.0011"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "373.15",
        "pressure_kpa": "3070",
        "mole_fraction_<carbon dioxide>": "0.3063",
        "mole_fraction_<carbon dioxide>_U": "0.0013"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "353.15",
        "pressure_kpa": "3012",
        "mole_fraction_<carbon dioxide>": "0.3645",
        "mole_fraction_<carbon dioxide>_U": "0.0015"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "333.15",
        "pressure_kpa": "2962",
        "mole_fraction_<carbon dioxide>": "0.3976",
        "mole_fraction_<carbon dioxide>_U": "0.0017"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "temperature_k": "313.15",
        "pressure_kpa": "2876",
        "mole_fraction_<carbon dioxide>": "0.463",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "temperature_k": "293.15",
        "pressure_kpa": "2742",
        "mole_fraction_<carbon dioxide>": "0.5491",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "temperature_k": "273.15",
        "pressure_kpa": "2500",
        "mole_fraction_<carbon dioxide>": "0.6607",
        "mole_fraction_<carbon dioxide>_U": "0.0022"
      },
      {
        "BLKpoint_id": "BLKpoint_17",
        "temperature_k": "393.15",
        "pressure_kpa": "1260",
        "mole_fraction_<carbon dioxide>": "0.1318",
        "mole_fraction_<carbon dioxide>_U": "0.0007"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "373.15",
        "pressure_kpa": "1243",
        "mole_fraction_<carbon dioxide>": "0.1505",
        "mole_fraction_<carbon dioxide>_U": "0.0007"
      },
      {
        "BLKpoint_id": "BLKpoint_19",
        "temperature_k": "353.15",
        "pressure_kpa": "1223",
        "mole_fraction_<carbon dioxide>": "0.1727",
        "mole_fraction_<carbon dioxide>_U": "0.0008"
      },
      {
        "BLKpoint_id": "BLKpoint_20",
        "temperature_k": "333.15",
        "pressure_kpa": "1196",
        "mole_fraction_<carbon dioxide>": "0.2052",
        "mole_fraction_<carbon dioxide>_U": "0.0009"
      },
      {
        "BLKpoint_id": "BLKpoint_21",
        "temperature_k": "313.15",
        "pressure_kpa": "1160",
        "mole_fraction_<carbon dioxide>": "0.2489",
        "mole_fraction_<carbon dioxide>_U": "0.0011"
      },
      {
        "BLKpoint_id": "BLKpoint_22",
        "temperature_k": "293.15",
        "pressure_kpa": "1108",
        "mole_fraction_<carbon dioxide>": "0.3101",
        "mole_fraction_<carbon dioxide>_U": "0.0015"
      },
      {
        "BLKpoint_id": "BLKpoint_23",
        "temperature_k": "273.15",
        "pressure_kpa": "1022",
        "mole_fraction_<carbon dioxide>": "0.4006",
        "mole_fraction_<carbon dioxide>_U": "0.0017"
      },
      {
        "BLKpoint_id": "BLKpoint_24",
        "temperature_k": "413.15",
        "pressure_kpa": "599",
        "mole_fraction_<carbon dioxide>": "0.0569",
        "mole_fraction_<carbon dioxide>_U": "0.0006"
      },
      {
        "BLKpoint_id": "BLKpoint_25",
        "temperature_k": "393.15",
        "pressure_kpa": "594",
        "mole_fraction_<carbon dioxide>": "0.0601",
        "mole_fraction_<carbon dioxide>_U": "0.0006"
      },
      {
        "BLKpoint_id": "BLKpoint_26",
        "temperature_k": "373.15",
        "pressure_kpa": "587",
        "mole_fraction_<carbon dioxide>": "0.0674",
        "mole_fraction_<carbon dioxide>_U": "0.0006"
      },
      {
        "BLKpoint_id": "BLKpoint_27",
        "temperature_k": "353.15",
        "pressure_kpa": "576",
        "mole_fraction_<carbon dioxide>": "0.0832",
        "mole_fraction_<carbon dioxide>_U": "0.0007"
      },
      {
        "BLKpoint_id": "BLKpoint_28",
        "temperature_k": "333.15",
        "pressure_kpa": "564",
        "mole_fraction_<carbon dioxide>": "0.0998",
        "mole_fraction_<carbon dioxide>_U": "0.0007"
      },
      {
        "BLKpoint_id": "BLKpoint_29",
        "temperature_k": "313.15",
        "pressure_kpa": "546",
        "mole_fraction_<carbon dioxide>": "0.1279",
        "mole_fraction_<carbon dioxide>_U": "0.0008"
      },
      {
        "BLKpoint_id": "BLKpoint_30",
        "temperature_k": "293.15",
        "pressure_kpa": "522",
        "mole_fraction_<carbon dioxide>": "0.1657",
        "mole_fraction_<carbon dioxide>_U": "0.0009"
      },
      {
        "BLKpoint_id": "BLKpoint_31",
        "temperature_k": "273.15",
        "pressure_kpa": "485",
        "mole_fraction_<carbon dioxide>": "0.223",
        "mole_fraction_<carbon dioxide>_U": "0.0011"
      }
    ],
    "inspection_id": "INSP_4b7f7190d512",
    "lit_num_id": "GLOBlit_3961"
  },
  {
    "doi": "10.1021/je050357o",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "pressure_kpa",
      "mole_fraction_<carbon dioxide>",
      "mole_fraction_<carbon dioxide>_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "279.98",
        "pressure_kpa": "291.8",
        "mole_fraction_<carbon dioxide>": "0.1151",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "279.98",
        "pressure_kpa": "719.2",
        "mole_fraction_<carbon dioxide>": "0.2472",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "279.98",
        "pressure_kpa": "1458.4",
        "mole_fraction_<carbon dioxide>": "0.4141",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "279.98",
        "pressure_kpa": "2059.5",
        "mole_fraction_<carbon dioxide>": "0.5123",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "299.98",
        "pressure_kpa": "405.8",
        "mole_fraction_<carbon dioxide>": "0.1063",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "299.98",
        "pressure_kpa": "996.9",
        "mole_fraction_<carbon dioxide>": "0.2309",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "299.98",
        "pressure_kpa": "2063.6",
        "mole_fraction_<carbon dioxide>": "0.3896",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "299.98",
        "pressure_kpa": "2962.7",
        "mole_fraction_<carbon dioxide>": "0.4837",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "319.98",
        "pressure_kpa": "518.1",
        "mole_fraction_<carbon dioxide>": "0.099",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "319.98",
        "pressure_kpa": "1292.9",
        "mole_fraction_<carbon dioxide>": "0.2153",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "319.98",
        "pressure_kpa": "2699.6",
        "mole_fraction_<carbon dioxide>": "0.3659",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "319.98",
        "pressure_kpa": "3903.9",
        "mole_fraction_<carbon dioxide>": "0.4557",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "temperature_k": "339.97",
        "pressure_kpa": "635",
        "mole_fraction_<carbon dioxide>": "0.0922",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_14",
        "temperature_k": "339.97",
        "pressure_kpa": "1585.9",
        "mole_fraction_<carbon dioxide>": "0.202",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "temperature_k": "339.97",
        "pressure_kpa": "3322.4",
        "mole_fraction_<carbon dioxide>": "0.3459",
        "mole_fraction_<carbon dioxide>_U": "0.002"
      },
      {
        "BLKpoint_id": "BLKpoint_16",
        "temperature_k": "339.97",
        "pressure_kpa": "4799.9",
        "mole_fraction_<carbon dioxide>": "0.4332",
        "mole_fraction_<carbon dioxide>_U": "0.0021"
      }
    ],
    "inspection_id": "INSP_3f36471c1ea9",
    "lit_num_id": "GLOBlit_8739"
  },
  {
    "doi": "10.1016/j.jct.2012.11.030",
    "block_number": "PROPblock_2",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "pressure_kpa",
      "temperature_k",
      "molality_mol_kg_<carbon dioxide>",
      "molality_mol_kg_<carbon dioxide>_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "pressure_kpa": "380",
        "temperature_k": "323.15",
        "molality_mol_kg_<carbon dioxide>": "0.2257",
        "molality_mol_kg_<carbon dioxide>_U": "0.0036"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "pressure_kpa": "740",
        "temperature_k": "323.15",
        "molality_mol_kg_<carbon dioxide>": "0.4173",
        "molality_mol_kg_<carbon dioxide>_U": "0.0068"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "pressure_kpa": "1730",
        "temperature_k": "323.15",
        "molality_mol_kg_<carbon dioxide>": "0.8577",
        "molality_mol_kg_<carbon dioxide>_U": "0.0137"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "pressure_kpa": "2600",
        "temperature_k": "323.15",
        "molality_mol_kg_<carbon dioxide>": "1.2957",
        "molality_mol_kg_<carbon dioxide>_U": "0.0212"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "pressure_kpa": "3170",
        "temperature_k": "323.15",
        "molality_mol_kg_<carbon dioxide>": "1.6002",
        "molality_mol_kg_<carbon dioxide>_U": "0.0261"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "pressure_kpa": "3630",
        "temperature_k": "323.15",
        "molality_mol_kg_<carbon dioxide>": "1.8138",
        "molality_mol_kg_<carbon dioxide>_U": "0.0296"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "pressure_kpa": "4080",
        "temperature_k": "323.15",
        "molality_mol_kg_<carbon dioxide>": "2.0491",
        "molality_mol_kg_<carbon dioxide>_U": "0.0335"
      }
    ],
    "inspection_id": "INSP_dc9c69bde015",
    "lit_num_id": "GLOBlit_3779"
  },
  {
    "doi": "10.1021/acs.jced.7b00786",
    "block_number": "PROPblock_12",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "mole_fraction_<carbon dioxide>",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "mole_fraction_<carbon dioxide>": "0.222",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "1303",
        "vapor_or_sublimation_pressure_kpa_U": "34"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "mole_fraction_<carbon dioxide>": "0.276",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "1712",
        "vapor_or_sublimation_pressure_kpa_U": "43"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "mole_fraction_<carbon dioxide>": "0.364",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "2409",
        "vapor_or_sublimation_pressure_kpa_U": "64"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "mole_fraction_<carbon dioxide>": "0.441",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "3151",
        "vapor_or_sublimation_pressure_kpa_U": "91"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "mole_fraction_<carbon dioxide>": "0.472",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "3531",
        "vapor_or_sublimation_pressure_kpa_U": "148"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "mole_fraction_<carbon dioxide>": "0.55",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "4832",
        "vapor_or_sublimation_pressure_kpa_U": "158"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "mole_fraction_<carbon dioxide>": "0.616",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "6055",
        "vapor_or_sublimation_pressure_kpa_U": "170"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "mole_fraction_<carbon dioxide>": "0.664",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "7364",
        "vapor_or_sublimation_pressure_kpa_U": "172"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "mole_fraction_<carbon dioxide>": "0.712",
        "temperature_k": "313.15",
        "vapor_or_sublimation_pressure_kpa": "8487",
        "vapor_or_sublimation_pressure_kpa_U": "138"
      }
    ],
    "inspection_id": "INSP_44671f18972c",
    "lit_num_id": "GLOBlit_7324"
  }
]
```
