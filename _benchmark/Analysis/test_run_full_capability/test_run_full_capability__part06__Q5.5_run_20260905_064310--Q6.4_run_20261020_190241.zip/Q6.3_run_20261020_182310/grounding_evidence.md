# Data grounding evidence

- generated: 2026-10-20T18:38:14
- gate verdict: 122 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | GLOBlit_8739 | yes | INSP_4b7f7190d512, INSP_3f36471c1ea9 | 16 |
| PROPblock_12 | GLOBlit_7324 | yes | INSP_44671f18972c | 9 |
| PROPblock_2 | GLOBlit_6787 | yes | INSP_8f65d694d36c, INSP_dc9c69bde015 | 11 |
| PROPblock_3 | GLOBlit_1169 | yes | INSP_880e0c5dcb94 | 36 |
| PROPblock_72 | GLOBlit_10864 | yes | INSP_ac34d22698b5 | 3 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 293.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 323.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 293.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 2900 | GLOBlit_6787::PROPblock_2 | verified | — |
| 71.976 | GLOBlit_6787::PROPblock_2 | verified | — |
| 298.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3190 | GLOBlit_6787::PROPblock_2 | verified | — |
| 78.937 | GLOBlit_6787::PROPblock_2 | verified | — |
| 303.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3460 | GLOBlit_6787::PROPblock_2 | verified | — |
| 85.692 | GLOBlit_6787::PROPblock_2 | verified | — |
| 303.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3480 | GLOBlit_6787::PROPblock_2 | verified | — |
| 86.168 | GLOBlit_6787::PROPblock_2 | verified | — |
| 303.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3490 | GLOBlit_6787::PROPblock_2 | verified | — |
| 86.407 | GLOBlit_6787::PROPblock_2 | verified | — |
| 313.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4130 | GLOBlit_6787::PROPblock_2 | verified | — |
| 102.04 | GLOBlit_6787::PROPblock_2 | verified | — |
| 318.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4460 | GLOBlit_6787::PROPblock_2 | verified | — |
| 110.355 | GLOBlit_6787::PROPblock_2 | verified | — |
| 318.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4510 | GLOBlit_6787::PROPblock_2 | verified | — |
| 111.568 | GLOBlit_6787::PROPblock_2 | verified | — |
| 318.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4470 | GLOBlit_6787::PROPblock_2 | verified | — |
| 110.598 | GLOBlit_6787::PROPblock_2 | verified | — |
| 318.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4440 | GLOBlit_6787::PROPblock_2 | verified | — |
| 109.87 | GLOBlit_6787::PROPblock_2 | verified | — |
| 323.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4910 | GLOBlit_6787::PROPblock_2 | verified | — |
| 121.609 | GLOBlit_6787::PROPblock_2 | verified | — |
| 303 | GLOBlit_10864::PROPblock_72 | verified | — |
| 323 | GLOBlit_10864::PROPblock_72 | verified | — |
| 303 | GLOBlit_10864::PROPblock_72 | verified | — |
| 3340 | GLOBlit_10864::PROPblock_72 | verified | — |
| 200 | GLOBlit_10864::PROPblock_72 | verified | — |
| 313 | GLOBlit_10864::PROPblock_72 | verified | — |
| 4120 | GLOBlit_10864::PROPblock_72 | verified | — |
| 250 | GLOBlit_10864::PROPblock_72 | verified | — |
| 323 | GLOBlit_10864::PROPblock_72 | verified | — |
| 4770 | GLOBlit_10864::PROPblock_72 | verified | — |
| 290 | GLOBlit_10864::PROPblock_72 | verified | — |
| 8.314 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 303.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3460 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3480 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3490 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3476.7 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 318.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4460 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4510 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4470 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4440 | GLOBlit_6787::PROPblock_2 | verified | — |
| 4470 | GLOBlit_6787::PROPblock_2 | verified | — |
| -1644 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| -13.7 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 2.776 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 55 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| -13.7 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 0.5 | GLOBlit_6787::PROPblock_2 | ambiguous | 3 sources |
| -1749 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 8.314 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| -1749 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| -14.5 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| -13.7 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 0.5 | GLOBlit_10864::PROPblock_72 | ambiguous | 3 sources |
| 293.15 | GLOBlit_10864::PROPblock_72 | ambiguous | 2 sources |
| 323.15 | GLOBlit_10864::PROPblock_72 | verified | — |
| 2900 | GLOBlit_10864::PROPblock_72 | misattributed | PROPblock_2 |
| 4910 | GLOBlit_10864::PROPblock_72 | misattributed | PROPblock_2 |
| 16 | GLOBlit_8739::PROPblock_1 | verified | — |
| 279.98 | GLOBlit_8739::PROPblock_1 | verified | — |
| 339.97 | GLOBlit_8739::PROPblock_1 | verified | — |
| 299.98 | GLOBlit_8739::PROPblock_1 | verified | — |
| 405.8 | GLOBlit_8739::PROPblock_1 | verified | — |
| 0.1063 | GLOBlit_8739::PROPblock_1 | verified | — |
| 405.8 | GLOBlit_8739::PROPblock_1 | verified | — |
| 3818 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 298.15 | GLOBlit_8739::PROPblock_1 | misattributed | PROPblock_2 |
| 3190 | GLOBlit_8739::PROPblock_1 | misattributed | PROPblock_2 |
| 3818 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 1.20 | GLOBlit_8739::PROPblock_1 | verified | — |
| 0.10 | GLOBlit_8739::PROPblock_1 | verified | — |
| 319.98 | GLOBlit_8739::PROPblock_1 | verified | — |
| 518.1 | GLOBlit_8739::PROPblock_1 | verified | — |
| 0.0990 | GLOBlit_8739::PROPblock_1 | verified | — |
| 518.1 | GLOBlit_8739::PROPblock_1 | verified | — |
| 5233 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 318.15 | GLOBlit_8739::PROPblock_1 | misattributed | PROPblock_2 |
| 4470 | GLOBlit_8739::PROPblock_1 | misattributed | PROPblock_2 |
| 5233 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 1.17 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 279.98 | GLOBlit_8739::PROPblock_1 | verified | — |
| 291.8 | GLOBlit_8739::PROPblock_1 | verified | — |
| 2535 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 719.2 | GLOBlit_8739::PROPblock_1 | verified | — |
| 2910 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 1458.4 | GLOBlit_8739::PROPblock_1 | verified | — |
| 3521 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 2059.5 | GLOBlit_8739::PROPblock_1 | verified | — |
| 4021 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 30 | GLOBlit_3961::PROPblock_1 | verified | — |
| 273.15 | GLOBlit_3961::PROPblock_1 | verified | — |
| 413.15 | GLOBlit_3961::PROPblock_1 | verified | — |
| 293.15 | GLOBlit_3961::PROPblock_1 | verified | — |
| 522 | GLOBlit_3961::PROPblock_1 | verified | — |
| 0.1657 | GLOBlit_3961::PROPblock_1 | verified | — |
| 522 | GLOBlit_3961::PROPblock_1 | verified | — |
| 3150 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 293.15 | GLOBlit_3961::PROPblock_1 | verified | — |
| 2900 | GLOBlit_3961::PROPblock_1 | misattributed | PROPblock_2 |
| 3150 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 1.09 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 313.15 | GLOBlit_3961::PROPblock_1 | verified | — |
| 546 | GLOBlit_3961::PROPblock_1 | verified | — |
| 0.1279 | GLOBlit_3961::PROPblock_1 | verified | — |
| 546 | GLOBlit_3961::PROPblock_1 | verified | — |
| 4269 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 313.15 | GLOBlit_3961::PROPblock_1 | verified | — |
| 4130 | GLOBlit_3961::PROPblock_1 | misattributed | PROPblock_2 |
| 4269 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 1.03 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 1.0 | GLOBlit_3961::PROPblock_1 | verified | — |
| 313.15 | GLOBlit_3961::PROPblock_1 | verified | — |
| 0.1279 | GLOBlit_3961::PROPblock_1 | verified | — |
| 0.1657 | GLOBlit_3961::PROPblock_1 | verified | — |
| 293.15 | GLOBlit_3961::PROPblock_1 | verified | — |
| 313.15 | GLOBlit_7324::PROPblock_12 | verified | — |
| 0.222 | GLOBlit_7324::PROPblock_12 | verified | — |
| 1303 | GLOBlit_7324::PROPblock_12 | verified | — |
| 1303 | GLOBlit_7324::PROPblock_12 | verified | — |
| 5869 | GLOBlit_7324::PROPblock_12 | ungrounded | — |
| 313.15 | GLOBlit_7324::PROPblock_12 | verified | — |
| 4130 | GLOBlit_7324::PROPblock_12 | misattributed | PROPblock_2 |
| 5869 | GLOBlit_7324::PROPblock_12 | ungrounded | — |
| 1.42 | GLOBlit_7324::PROPblock_12 | ungrounded | — |
| 0.222 | GLOBlit_7324::PROPblock_12 | verified | — |
| 323.15 | GLOBlit_3779::PROPblock_2 | verified | — |
| 419.36 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.2257 | GLOBlit_3779::PROPblock_2 | verified | — |
| 380 | GLOBlit_3779::PROPblock_2 | verified | — |
| 0.2257 | GLOBlit_3779::PROPblock_2 | verified | — |
| 0.41936 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.2257 | GLOBlit_3779::PROPblock_2 | verified | — |
| 0.41936 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.0865 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 380 | GLOBlit_3779::PROPblock_2 | verified | — |
| 4394 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 323.15 | GLOBlit_3779::PROPblock_2 | verified | — |
| 4910 | GLOBlit_3779::PROPblock_2 | verified | — |
| 4394 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.90 | GLOBlit_3779::PROPblock_2 | ambiguous | 2 sources |
| 323 | GLOBlit_3779::PROPblock_2 | verified | — |
| 4770 | GLOBlit_3779::PROPblock_2 | misattributed | PROPblock_72 |
| 4394 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.92 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.4173 | GLOBlit_3779::PROPblock_2 | verified | — |
| 740 | GLOBlit_3779::PROPblock_2 | verified | — |
| 0.1489 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 740 | GLOBlit_3779::PROPblock_2 | verified | — |
| 4970 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 4970 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 1.01 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.15 | GLOBlit_3779::PROPblock_2 | ambiguous | 2 sources |
| 0.09 | GLOBlit_3779::PROPblock_2 | verified | — |
| -13.7 | GLOBlit_6787::PROPblock_2 + GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 0.5 | GLOBlit_6787::PROPblock_2 + GLOBlit_10864::PROPblock_72 | ambiguous | 3 sources |
| -14.5 | GLOBlit_6787::PROPblock_2 + GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 0.10 | GLOBlit_10864::PROPblock_72 | ambiguous | 3 sources |
| 0.22 | GLOBlit_10864::PROPblock_72 | ambiguous | 2 sources |
| -14 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 8.314 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 3476.7 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 303.15 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3460 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3480 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3490 | GLOBlit_6787::PROPblock_2 | verified | — |
| 3476.7 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| -1644 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 8.314 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| -13.7 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 8.314 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| -1644 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 2.776 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 55 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| -13.7 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 55 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| 0.5 | GLOBlit_6787::PROPblock_2 | ambiguous | 3 sources |
| 55 | GLOBlit_6787::PROPblock_2 | ungrounded | — |
| -1749 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 8.314 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| -14.5 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| -13.7 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 0.5 | GLOBlit_10864::PROPblock_72 | ambiguous | 3 sources |
| 293.15 | GLOBlit_10864::PROPblock_72 | ambiguous | 2 sources |
| 2900 | GLOBlit_10864::PROPblock_72 | misattributed | PROPblock_2 |
| 4910 | GLOBlit_10864::PROPblock_72 | misattributed | PROPblock_2 |
| 0.10 | GLOBlit_10864::PROPblock_72 | ambiguous | 3 sources |
| 0.22 | GLOBlit_10864::PROPblock_72 | ambiguous | 2 sources |
| -14 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 3818 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 298.15 | GLOBlit_8739::PROPblock_1 | misattributed | PROPblock_2 |
| 3190 | GLOBlit_8739::PROPblock_1 | misattributed | PROPblock_2 |
| 5233 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 318.15 | GLOBlit_8739::PROPblock_1 | misattributed | PROPblock_2 |
| 4470 | GLOBlit_8739::PROPblock_1 | misattributed | PROPblock_2 |
| 1.17 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 2535 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 2910 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 3521 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 4021 | GLOBlit_8739::PROPblock_1 | ungrounded | — |
| 3150 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 2900 | GLOBlit_3961::PROPblock_1 | misattributed | PROPblock_2 |
| 1.09 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 4269 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 4130 | GLOBlit_3961::PROPblock_1 | misattributed | PROPblock_2 |
| 1.03 | GLOBlit_3961::PROPblock_1 | ungrounded | — |
| 5869 | GLOBlit_7324::PROPblock_12 | ungrounded | — |
| 4130 | GLOBlit_7324::PROPblock_12 | misattributed | PROPblock_2 |
| 1.42 | GLOBlit_7324::PROPblock_12 | ungrounded | — |
| 419.36 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.41936 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.0865 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 4394 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.90 | GLOBlit_3779::PROPblock_2 | ambiguous | 2 sources |
| 4770 | GLOBlit_3779::PROPblock_2 | misattributed | PROPblock_72 |
| 0.92 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.1489 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 4970 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 1.01 | GLOBlit_3779::PROPblock_2 | ungrounded | — |
| 0.15 | GLOBlit_3779::PROPblock_2 | ambiguous | 2 sources |
| -13.7 | GLOBlit_10864::PROPblock_72 | ungrounded | — |
| 0.5 | GLOBlit_10864::PROPblock_72 | ambiguous | 3 sources |
| -14.5 | GLOBlit_10864::PROPblock_72 | ungrounded | — |

## Violations

- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: 8.314 (near '…modynamic relation is d(ln H)/d(1/T) = ΔH\_sol/R, where R = …') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 3476.7 (near '…inspected H values at 303.15 K (mean of 3460, 3480, 3490 = 3…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: -1644 (near '…(**derived**) - **ΔH\_sol** = 8.314 (physical constant) × (-…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: -13.7 (near '…* = 8.314 (physical constant) × (-1644) (derived slope) = **…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 2.776 (near '…l** (**derived**)  With 4 degrees of freedom and t₄,₀.₀₂₅ = …') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 55 (near '…table value), the 95% confidence interval for the slope is ±…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: -13.7 (near '…for the slope is ±55 K (**derived**), giving:  **ΔH\_sol = -…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **AMBIGUOUS_VALUE** GLOBlit_6787::PROPblock_2: 0.5 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -1749 (near '…rs and computing ln(H) vs 1/T (**derived**):  - **Slope** = …') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: 8.314 (near '…ed**):  - **Slope** = -1749 K (**derived**) - **ΔH\_sol** = …') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -1749 (near '…**Slope** = -1749 K (**derived**) - **ΔH\_sol** = 8.314 × (-…') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -14.5 (near '…= -1749 K (**derived**) - **ΔH\_sol** = 8.314 × (-1749) = **…') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -13.7 (near '…ut consistent with Block 1.  ### Best estimate  **ΔH\_sol = …') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **AMBIGUOUS_VALUE** GLOBlit_10864::PROPblock_72: 0.5 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** GLOBlit_10864::PROPblock_72: 293.15 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 2900 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 4910 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 3818 (near '…98 K:** P = 405.8 kPa, x = 0.1063 → H\_app = 405.8/0.1063 = …') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **MISATTRIBUTED_VALUE** GLOBlit_8739::PROPblock_1: 298.15 does not belong to GLOBlit_8739::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_8739::PROPblock_1: 3190 does not belong to GLOBlit_8739::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 3818 (near '…d**). Compare with Block 1 H at 298.15 K = 3190 kPa → ratio …') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 5233 (near '…98 K:** P = 518.1 kPa, x = 0.0990 → H\_app = 518.1/0.0990 = …') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **MISATTRIBUTED_VALUE** GLOBlit_8739::PROPblock_1: 318.15 does not belong to GLOBlit_8739::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_8739::PROPblock_1: 4470 does not belong to GLOBlit_8739::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 5233 (near '…rage H at 318.15 K = 4470 kPa (**derived average**) → ratio …') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 1.17 (near '…8.15 K = 4470 kPa (**derived average**) → ratio 5233/4470 = …') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 2535 (near '…attern: P/x increases systematically with x (291.8/0.1151 = …') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 2910 (near '…systematically with x (291.8/0.1151 = 2535; 719.2/0.2472 = 2…') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 3521 (near '…(291.8/0.1151 = 2535; 719.2/0.2472 = 2910; 1458.4/0.4141 = 3…') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 4021 (near '…719.2/0.2472 = 2910; 1458.4/0.4141 = 3521; 2059.5/0.5123 = 4…') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 3150 (near '…293.15 K:** P = 522 kPa, x = 0.1657 → H\_app = 522/0.1657 = …') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **MISATTRIBUTED_VALUE** GLOBlit_3961::PROPblock_1: 2900 does not belong to GLOBlit_3961::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 3150 (near '…a (**derived**). Block 1 H at 293.15 K = 2900 kPa → ratio = …') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 1.09 (near '…**). Block 1 H at 293.15 K = 2900 kPa → ratio = 3150/2900 = …') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 4269 (near '…313.15 K:** P = 546 kPa, x = 0.1279 → H\_app = 546/0.1279 = …') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **MISATTRIBUTED_VALUE** GLOBlit_3961::PROPblock_1: 4130 does not belong to GLOBlit_3961::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 4269 (near '…a (**derived**). Block 1 H at 313.15 K = 4130 kPa → ratio = …') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 1.03 (near '…**). Block 1 H at 313.15 K = 4130 kPa → ratio = 4269/4130 = …') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_7324::PROPblock_12: 5869 (near '…omposition: x = 0.222, P = 1303 kPa → H\_app = 1303/0.222 = …') matches no inspected row/stat, database table, or other source of GLOBlit_7324::PROPblock_12
- **MISATTRIBUTED_VALUE** GLOBlit_7324::PROPblock_12: 4130 does not belong to GLOBlit_7324::PROPblock_12; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_7324::PROPblock_12: 5869 (near '…a (**derived**). Block 1 H at 313.15 K = 4130 kPa → ratio = …') matches no inspected row/stat, database table, or other source of GLOBlit_7324::PROPblock_12
- **UNGROUNDED_LITERAL** GLOBlit_7324::PROPblock_12: 1.42 (near '…**). Block 1 H at 313.15 K = 4130 kPa → ratio = 5869/4130 = …') matches no inspected row/stat, database table, or other source of GLOBlit_7324::PROPblock_12
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 419.36 (near '…K ( ).  The molar mass of [bmim][NTf₂] (C₁₀H₁₅F₆N₃O₄S₂) is 4…') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 0.41936 (near '…0.2257 mol/kg, P = 380 kPa) to mole fraction: x = 0.2257 × 0…') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 0.41936 (near '…kPa) to mole fraction: x = 0.2257 × 0.41936 / (1 + 0.2257 × …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 0.0865 (near '…e fraction: x = 0.2257 × 0.41936 / (1 + 0.2257 × 0.41936) = …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 4394 (near '…57 × 0.41936) = 0.0865 (**derived**). H\_app = 380/0.0865 = …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 4394 (near '…a (**derived**). Block 1 H at 323.15 K = 4910 kPa → ratio = …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **AMBIGUOUS_VALUE** GLOBlit_3779::PROPblock_2: 0.90 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** GLOBlit_3779::PROPblock_2: 4770 does not belong to GLOBlit_3779::PROPblock_2; it matches only GLOBlit_10864::PROPblock_72 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 4394 (near '…0.90 (**derived**); Block 2 H at 323 K = 4770 kPa → ratio = …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 0.92 (near '…ved**); Block 2 H at 323 K = 4770 kPa → ratio = 4394/4770 = …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 0.1489 (near '…ved**).  At the second point (m = 0.4173, P = 740 kPa): x = …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 4970 (near '…= 740 kPa): x = 0.1489 (**derived**), H\_app = 740/0.1489 = …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 4970 (near '…p = 740/0.1489 = 4970 kPa (**derived**), ratio to Block 1 = …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 1.01 (near '…89 = 4970 kPa (**derived**), ratio to Block 1 = 4970/4910 = …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **AMBIGUOUS_VALUE** GLOBlit_3779::PROPblock_2: 0.15 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2 + GLOBlit_10864::PROPblock_72: -13.7 (near '…--|-------|------------| | ΔH\_sol (Block 1 van't Hoff) | **…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2 + GLOBlit_10864::PROPblock_72
- **AMBIGUOUS_VALUE** GLOBlit_6787::PROPblock_2 + GLOBlit_10864::PROPblock_72: 0.5 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2 + GLOBlit_10864::PROPblock_72: -14.5 (near '…pected H values ( :: ) | | ΔH\_sol (Block 2 van't Hoff) | **…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2 + GLOBlit_10864::PROPblock_72
- **AMBIGUOUS_VALUE** GLOBlit_10864::PROPblock_72: 0.10 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** GLOBlit_10864::PROPblock_72: 0.22 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -14 (near '…rmic CO₂ physical absorption in [bmim][NTf₂] with ΔH\_sol ≈ …') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: 8.314 (near '…:: : 8.314 (near '…modynamic relation is d(ln H)/d…') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 3476.7 (near '…:: : 3476.7 (near '…inspected H values at 303.15 K…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 3476.7 (near '…onstant_mole_fraction_scale_kpa_<carbon dioxide>", "value": …') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: -1644 (near '…:: : -1644 (near '…(**derived**) - **ΔH\_sol** = 8…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 8.314 (near '…:: : -1644 (near '…(**derived**) - **ΔH\_sol** = 8.314 (phys…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: -13.7 (near '…:: : -13.7 (near '…* = 8.314 (physical constant) ×…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 8.314 (near '…:: : -13.7 (near '…* = 8.314 (physical constant) × (-1644) (…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: -1644 (near '…:: : -13.7 (near '…* = 8.314 (physical constant) × (-1644) (…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 2.776 (near '…:: : 2.776 (near '…l** (**derived**)  With 4 degre…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 55 (near '…:: : 55 (near '…table value), the 95% confidenc…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: -13.7 (near '…:: : -13.7 (near '…for the slope is ±55 K (**deriv…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 55 (near '…:: : -13.7 (near '…for the slope is ±55 K (**derived**), giv…') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **AMBIGUOUS_VALUE** GLOBlit_6787::PROPblock_2: 0.5 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** GLOBlit_6787::PROPblock_2: 55 (near '…reference, keep it and label its provenance instead - … and …') matches no inspected row/stat, database table, or other source of GLOBlit_6787::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -1749 (near '…:: : -1749, 8.314, -14.5, -13.7, 0.5, 293.15, 2900…') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: 8.314 (near '…:: : -1749, 8.314, -14.5, -13.7, 0.5, 293.15, 2900, 4910,…') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -14.5 (near '…:: : -1749, 8.314, -14.5, -13.7, 0.5, 293.15, 2900, 4910, 0.…') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -13.7 (near '…:: : -1749, 8.314, -14.5, -13.7, 0.5, 293.15, 2900, 4910, 0.…') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **AMBIGUOUS_VALUE** GLOBlit_10864::PROPblock_72: 0.5 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** GLOBlit_10864::PROPblock_72: 293.15 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 2900 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_10864::PROPblock_72: 4910 does not belong to GLOBlit_10864::PROPblock_72; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **AMBIGUOUS_VALUE** GLOBlit_10864::PROPblock_72: 0.10 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **AMBIGUOUS_VALUE** GLOBlit_10864::PROPblock_72: 0.22 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -14 (near '…, 8.314, -14.5, -13.7, 0.5, 293.15, 2900, 4910, 0.10, 0.22, …') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 3818 (near '…:: : 3818, 298.15, 3190, 5233, 318.15, 4470, 1.17…') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **MISATTRIBUTED_VALUE** GLOBlit_8739::PROPblock_1: 298.15 does not belong to GLOBlit_8739::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_8739::PROPblock_1: 3190 does not belong to GLOBlit_8739::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 5233 (near '…:: : 3818, 298.15, 3190, 5233, 318.15, 4470, 1.17, 2535, 291…') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **MISATTRIBUTED_VALUE** GLOBlit_8739::PROPblock_1: 318.15 does not belong to GLOBlit_8739::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **MISATTRIBUTED_VALUE** GLOBlit_8739::PROPblock_1: 4470 does not belong to GLOBlit_8739::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 1.17 (near '…:: : 3818, 298.15, 3190, 5233, 318.15, 4470, 1.17, 2535, 291…') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 2535 (near '…:: : 3818, 298.15, 3190, 5233, 318.15, 4470, 1.17, 2535, 291…') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 2910 (near '…:: : 3818, 298.15, 3190, 5233, 318.15, 4470, 1.17, 2535, 291…') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 3521 (near '…: 3818, 298.15, 3190, 5233, 318.15, 4470, 1.17, 2535, 2910, …') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_8739::PROPblock_1: 4021 (near '…, 298.15, 3190, 5233, 318.15, 4470, 1.17, 2535, 2910, 3521, …') matches no inspected row/stat, database table, or other source of GLOBlit_8739::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 3150 (near '…:: : 3150, 2900, 1.09, 4269, 4130, 1.03;…') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **MISATTRIBUTED_VALUE** GLOBlit_3961::PROPblock_1: 2900 does not belong to GLOBlit_3961::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 1.09 (near '…:: : 3150, 2900, 1.09, 4269, 4130, 1.03;…') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 4269 (near '…:: : 3150, 2900, 1.09, 4269, 4130, 1.03;…') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **MISATTRIBUTED_VALUE** GLOBlit_3961::PROPblock_1: 4130 does not belong to GLOBlit_3961::PROPblock_1; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_3961::PROPblock_1: 1.03 (near '…:: : 3150, 2900, 1.09, 4269, 4130, 1.03;…') matches no inspected row/stat, database table, or other source of GLOBlit_3961::PROPblock_1
- **UNGROUNDED_LITERAL** GLOBlit_7324::PROPblock_12: 5869 (near '…:: : 5869, 4130, 1.42;…') matches no inspected row/stat, database table, or other source of GLOBlit_7324::PROPblock_12
- **MISATTRIBUTED_VALUE** GLOBlit_7324::PROPblock_12: 4130 does not belong to GLOBlit_7324::PROPblock_12; it matches only GLOBlit_6787::PROPblock_2 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_7324::PROPblock_12: 1.42 (near '…:: : 5869, 4130, 1.42;…') matches no inspected row/stat, database table, or other source of GLOBlit_7324::PROPblock_12
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 419.36 (near '…:: : 419.36, 0.41936, 0.0865, 4394, 0.90, 4770, 0.9…') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 0.41936 (near '…:: : 419.36, 0.41936, 0.0865, 4394, 0.90, 4770, 0.92, 0.1489…') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 0.0865 (near '…:: : 419.36, 0.41936, 0.0865, 4394, 0.90, 4770, 0.92, 0.1489…') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 4394 (near '…:: : 419.36, 0.41936, 0.0865, 4394, 0.90, 4770, 0.92, 0.1489…') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **AMBIGUOUS_VALUE** GLOBlit_3779::PROPblock_2: 0.90 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** GLOBlit_3779::PROPblock_2: 4770 does not belong to GLOBlit_3779::PROPblock_2; it matches only GLOBlit_10864::PROPblock_72 (inspected this run)
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 0.92 (near '…:: : 419.36, 0.41936, 0.0865, 4394, 0.90, 4770, 0.92, 0.1489…') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 0.1489 (near '…:: : 419.36, 0.41936, 0.0865, 4394, 0.90, 4770, 0.92, 0.1489…') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 4970 (near '…: 419.36, 0.41936, 0.0865, 4394, 0.90, 4770, 0.92, 0.1489, 4…') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **UNGROUNDED_LITERAL** GLOBlit_3779::PROPblock_2: 1.01 (near '….36, 0.41936, 0.0865, 4394, 0.90, 4770, 0.92, 0.1489, 4970, …') matches no inspected row/stat, database table, or other source of GLOBlit_3779::PROPblock_2
- **AMBIGUOUS_VALUE** GLOBlit_3779::PROPblock_2: 0.15 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -13.7 (near '…:: : -13.7, 0.5, -14.5 Inspected so far:…') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72
- **AMBIGUOUS_VALUE** GLOBlit_10864::PROPblock_72: 0.5 matches 3 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** GLOBlit_10864::PROPblock_72: -14.5 (near '…:: : -13.7, 0.5, -14.5 Inspected so far:…') matches no inspected row/stat, database table, or other source of GLOBlit_10864::PROPblock_72

## Inspections (verbatim)

### INSP_8f65d694d36c — GLOBlit_6787::PROPblock_2 (complete, 11 rows shown)

_structured envelope entry (no markdown)_

### INSP_ac34d22698b5 — GLOBlit_10864::PROPblock_72 (complete, 3 rows shown)

_structured envelope entry (no markdown)_

### INSP_880e0c5dcb94 — GLOBlit_1169::PROPblock_3 (rdp, 12 rows shown)

_structured envelope entry (no markdown)_

### INSP_4b7f7190d512 — GLOBlit_3961::PROPblock_1 (rdp, 30 rows shown)

_structured envelope entry (no markdown)_

### INSP_3f36471c1ea9 — GLOBlit_8739::PROPblock_1 (rdp, 16 rows shown)

_structured envelope entry (no markdown)_

### INSP_dc9c69bde015 — GLOBlit_3779::PROPblock_2 (complete, 7 rows shown)

_structured envelope entry (no markdown)_

### INSP_44671f18972c — GLOBlit_7324::PROPblock_12 (complete, 9 rows shown)

_structured envelope entry (no markdown)_
