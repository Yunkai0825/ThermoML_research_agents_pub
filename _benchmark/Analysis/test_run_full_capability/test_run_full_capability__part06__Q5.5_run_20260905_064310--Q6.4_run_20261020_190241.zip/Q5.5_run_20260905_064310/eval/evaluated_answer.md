# Analysis Run — [run id removed] (Round 1)

**Question:** What viscosity should I expect for an equimolar DMF + ethylene glycol + water liquid mixture at 25 °C? If it has not been measured directly, give the most defensible estimate, explain the chemical and mathematical basis of every inferred contribution, and identify the measurements supporting it.

**[run statistics removed]**

---

## Answer

## Estimated Viscosity of Equimolar DMF + Ethylene Glycol + Water at 25 °C

### Bottom Line

**η ≈ 0.00368 Pa·s (3.68 mPa·s)** at 298.15 K and ambient pressure. *(This value is computed — not a database datum — derived from the Muggianu/Arrhenius calculation detailed below.)*

This is an estimate — the equimolar ternary composition (x_DMF = x_EG = x_water = 1/3) was not measured directly. The estimate is built from three binary Redlich-Kister fits using the Arrhenius (logarithmic) mixing rule, combined via the Muggianu symmetric extension to ternary systems, and cross-validated against nearby ternary measurements.

---

### 1. Why the Equimolar Point Was Not Measured

The only ternary viscosity block in the ThermoML database for this system is DOI 10.1021/je060113j (GLOBlit_8892, PROPblock_38). Its 11 data points at 298.15 K follow a dilution path from the DMF + EG binary (x_water = 0, x_EG = 0.5408) toward pure water — they do **not** pass through the equimolar point (1/3, 1/3, 1/3). The two nearest measured ternary compositions bracket the target:

| x(water) | x(EG) | x(DMF) | η (Pa·s) |
|-----------|--------|--------|-----------|
| 0.2929 | 0.3824 | 1 − 0.2929 − 0.3824 = 0.3247 *(computed by subtraction)* | 0.0035692 |
| 0.4825 | 0.2799 | 1 − 0.4825 − 0.2799 = 0.2376 *(computed by subtraction)* | 0.0037485 |

The equimolar point lies between these measured compositions, so the computed estimate of 0.00368 Pa·s *(derived below)* is physically consistent with the bracketing data.

---

### 2. Mathematical Framework

**Arrhenius mixing rule.** For viscosity, the natural mixing variable is ln η. The ideal (Arrhenius) baseline for a ternary mixture is:

> ln η_ideal = x₁·ln η₁\* + x₂·ln η₂\* + x₃·ln η₃\*

The excess departure is modelled by Redlich-Kister (RK) polynomials fitted to each binary pair. For a ternary system, the **Muggianu symmetric extension** combines the three binary excess functions:

> Δln η_excess = Σ_{i<j} xᵢ·xⱼ · Σₖ Aₖ^(ij) · (xᵢ − xⱼ)^k

At the equimolar point (x₁ = x₂ = x₃ = 1/3), every (xᵢ − xⱼ) = 0, so **only the A₀ coefficient of each binary pair survives**:

> Δln η_excess = (1/9) · [A₀^(DMF,water) + A₀^(EG,water) + A₀^(DMF,EG)]

---

### 3. Pure-Component Viscosities at 298.15 K

All ln η\* values below are computed as the natural logarithm of the corresponding measured viscosity.

| Component | η\* (Pa·s) | ln η\* *(computed)* | Source |
|-----------|-----------|---------------------|--------|
| DMF | 0.0008045 | −7.125 | GLOBlit_9900 / PROPblock_3, block-edge (x_water = 0) |
| Water | 0.0008903 | −7.024 | GLOBlit_9900 / PROPblock_3, block-edge (x_water = 1) |
| 1,2-Ethanediol (EG) | 0.016223 | −4.121 | GLOBlit_5201 / PROPblock_24, block-edge (x_EG = 1) |

**Ideal Arrhenius baseline at equimolar** *(computed from the ln values above)*:

> ln η_ideal = (1/3)(−7.125 − 4.121 − 7.024) = −6.090 *(computed)*

> η_ideal = exp(−6.090) = 0.00227 Pa·s *(computed)*

---

### 4. Binary Redlich-Kister Fits (Arrhenius Mixing Rule)

#### 4a. DMF + Water

- **Source:** DOI 10.1021/je300608v (GLOBlit_9900), PROPblock_3
- **Data:** 12 points at 298.15 K, 101.0 kPa, mole fraction of water
- **BIC-selected order:** 5
- **R² = 0.999973**, RMSE = 0.001523 (ln-space)
- **RK coefficients (ln-space):** A₀ = 3.14029, A₁ = 3.88544, A₂ = 1.91579, A₃ = −0.00569, A₄ = 0.04179, A₅ = 0.39089
- **A₀ = 3.140** (the only coefficient needed at equimolar)

This binary shows a pronounced viscosity maximum near x_water ≈ 0.7 (η_max ≈ 0.00248 Pa·s from the RK prediction tool), reflecting strong DMF–water hydrogen bonding where the C=O of DMF acts as a hydrogen-bond acceptor for water.

#### 4b. Ethylene Glycol + Water

- **Source:** DOI 10.1016/j.jct.2018.02.022 (GLOBlit_5201), PROPblock_24
- **Data:** 19 points at 298.15 K, 92.3 kPa, mole fraction of EG
- **BIC-selected order:** 3
- **R² = 0.999940**, RMSE = 0.001320 (ln-space)
- **RK coefficients (ln-space):** A₀ = 2.39674, A₁ = −1.04444, A₂ = 0.66817, A₃ = −0.32090
- **A₀ = 2.397**

EG–water mixtures show a monotonic increase in viscosity with EG content (pure EG at 0.016223 Pa·s vs pure water at 0.00089689 Pa·s — both from PROPblock_24 block-edges), driven by the extensive hydrogen-bonding network of EG's two hydroxyl groups.

#### 4c. DMF + Ethylene Glycol

- **Source:** DOI 10.1021/je060113j (GLOBlit_8892), PROPblock_25
- **Data:** Only **1 composition** at 298.15 K: x_EG = 0.5408, η = 0.0030647 Pa·s
- **Extraction of A₀** *(all intermediate values below are computed from the inspected pure-component and mixture data)*: With only one data point, only A₀ can be determined. Using pure values η_EG = 0.016223 Pa·s and η_DMF = 0.0008045 Pa·s:

  > ln η_ideal = 0.5408·ln(0.016223) + (1 − 0.5408)·ln(0.0008045) = −5.500 *(computed)*

  > ln η_measured = ln(0.0030647) = −5.788 *(computed)*

  > Δln η = −5.788 − (−5.500) = −0.288 *(computed)*

  > A₀ = Δln η / (0.5408 × 0.4592) = −0.288 / 0.2483 = **−1.159** *(computed)*

The **negative** A₀ means the DMF–EG interaction produces a viscosity *lower* than the Arrhenius ideal — the mixture is less structured than the geometric-mean prediction. This makes chemical sense: DMF is an aprotic solvent that disrupts EG's intramolecular hydrogen-bonding network without forming comparably strong new associations.

**Limitation:** This A₀ is extracted from a single data point near x = 0.5, so it is the least certain of the three binary contributions. However, the composition (0.5408) is close to equimolar, which is exactly where A₀ dominates, making the extraction relatively robust for this purpose.

---

### 5. Ternary Estimate via Muggianu Extension

At x_DMF = x_EG = x_water = 1/3 *(all values below are computed from the fit results and pure-component data above)*:

| Contribution | Value |
|-------------|-------|
| ln η_ideal | −6.090 *(computed)* |
| (1/9) × A₀^(DMF,water) = (1/9) × 3.140 | +0.349 *(computed)* |
| (1/9) × A₀^(EG,water) = (1/9) × 2.397 | +0.266 *(computed)* |
| (1/9) × A₀^(DMF,EG) = (1/9) × (−1.159) | −0.129 *(computed)* |
| **Total Δln η_excess** | **+0.487** *(computed)* |
| **ln η_ternary** | **−5.604** *(computed)* |
| **η_ternary = exp(−5.604)** | **≈ 0.00368 Pa·s** *(computed)* |

The positive net excess (+0.487 in ln-space) means the ternary mixture is more viscous than the Arrhenius ideal (0.00227 Pa·s), driven primarily by the strong DMF–water and EG–water hydrogen-bonding interactions that outweigh the weakening DMF–EG interaction.

---

### 6. Cross-Validation

The computed estimate of 0.00368 Pa·s falls squarely between the two nearest measured ternary points from PROPblock_38 (0.0035692 and 0.0037485 Pa·s), providing confidence in the prediction despite the limited DMF–EG binary data.

---

### 7. Uncertainty and Caveats

1. **DMF–EG binary:** Only one composition point was available (x_EG = 0.5408). Higher-order RK terms (A₁, A₂, …) could not be determined. If the DMF–EG excess is strongly asymmetric, the A₀-only approximation introduces error — but at the equimolar ternary point, only A₀ matters regardless.

2. **No ternary interaction term:** The Muggianu extension assumes no independent ternary contribution. In strongly hydrogen-bonding systems like this one, a ternary correction term C₁₂₃·x₁·x₂·x₃ could be non-negligible. The good agreement with bracketing measurements suggests this term is small.

3. **Pressure differences:** The EG–water fit used data at 92.3 kPa (GLOBlit_5201), while DMF–water was at 101.0 kPa (GLOBlit_9900) and the ternary data at 101.0 kPa (GLOBlit_8892). Liquid viscosity is nearly pressure-independent at these low pressures, so this discrepancy is negligible.

---

### 8. Summary of Measurement Sources

| Binary Pair | DOI | Block | Points at 298.15 K | RK Order | R² | A₀ |
|-------------|-----|-------|---------------------|----------|-----|-----|
| DMF + Water | 10.1021/je300608v (GLOBlit_9900) | PROPblock_3 | 12 | 5 | 0.999973 | 3.140 |
| EG + Water | 10.1016/j.jct.2018.02.022 (GLOBlit_5201) | PROPblock_24 | 19 | 3 | 0.999940 | 2.397 |
| DMF + EG | 10.1021/je060113j (GLOBlit_8892) | PROPblock_25 | 1 | 0 (A₀ only) | — | −1.159 *(computed)* |
| Ternary (validation) | 10.1021/je060113j (GLOBlit_8892) | PROPblock_38 | 11 | — | — | — |






















### Core claims

- The equimolar ternary composition (x_DMF = x_EG = x_water = 1/3) was not directly measured; the viscosity estimate of ≈ 0.00368 Pa·s (3.68 mPa·s) at 298.15 K and ambient pressure is computed, not a database datum.
- The estimate uses the Muggianu symmetric extension of binary Redlich-Kister fits under an Arrhenius (logarithmic) mixing rule, combining three binary excess contributions at the equimolar point where only each binary's A₀ coefficient survives.
- Binary Redlich-Kister A₀ coefficients (ln-space) are: DMF + Water A₀ = 3.140 (12 data points, R² = 0.999973), EG + Water A₀ = 2.397 (19 data points, R² = 0.999940), and DMF + EG A₀ = −1.159 (extracted from a single composition point at x_EG = 0.5408).
- The DMF–EG binary A₀ is the least certain contribution because it is derived from only one data point; higher-order Redlich-Kister terms could not be determined, though at the equimolar ternary point only A₀ matters.
- The positive net excess in ln η (+0.487) indicates the ternary mixture is more viscous than the Arrhenius ideal (0.00227 Pa·s), driven by strong DMF–water and EG–water hydrogen-bonding interactions that outweigh the weakening DMF–EG interaction.
- The computed estimate of 0.00368 Pa·s falls between the two nearest measured ternary viscosities from PROPblock_38 (0.0035692 Pa·s and 0.0037485 Pa·s), providing cross-validation support.
- No independent ternary interaction term was included in the model; in strongly hydrogen-bonding systems such a term could be non-negligible, but agreement with bracketing measurements suggests it is small.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_9900 | 10.1021/je300608v | PROPblock_3 |  | Provides DMF + water binary viscosity data (12 points at 298.15 K across the full mole fraction range) used to fit the Redlich-Kister polynomial yielding A₀ = 3.140, and supplies the pure-component viscosities for DMF (0.0008045 Pa·s) and water (0.0008903 Pa·s) as block-edge values. |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | Provides EG + water binary viscosity data (19 points at 298.15 K across the full mole fraction range) used to fit the Redlich-Kister polynomial yielding A₀ = 2.397, and supplies the pure-component viscosity for EG (0.016223 Pa·s) as a block-edge value. |
| GLOBlit_8892 | 10.1021/je060113j | PROPblock_25 |  | Provides the single DMF + EG binary viscosity data point at 298.15 K (x_EG = 0.5408, η = 0.0030647 Pa·s) from which the A₀ = −1.159 coefficient was extracted for the Muggianu ternary extension. |
| GLOBlit_8892 | 10.1021/je060113j | PROPblock_38 |  | Provides ternary DMF + EG + water viscosity measurements at 298.15 K used for cross-validation; the two nearest measured compositions bracket the equimolar estimate (0.0035692 and 0.0037485 Pa·s), confirming the computed value of 0.00368 Pa·s is physically consistent. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_9900 | PROPblock_3 | DMF_water | 5 | 3.1402922316632518; 3.8854391654848013; 1.915786421193988; -0.005692912831677055; 0.04178949155707623; 0.39089340704625575 | 0.999973 | 0.0015230866140327202 | 12 | 298.15 | arrhenius |  | 10.1021/je300608v |
| GLOBlit_5201 | PROPblock_24 | EG_water | 3 | 2.3967401058713325; -1.0444436005853195; 0.6681733607879681; -0.3209004397507546 | 0.99994 | 0.0013198945265291695 | 19 | 298.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
