# Analysis Run — [run id removed] (Round 1)

**Question:** I need a Redlich–Kister density correlation for liquid ethanol + water at 350 K. Can the available measurements support that temperature directly? If not, what is the nearest defensible temperature and why should the 350 K prediction be withheld?

**[run statistics removed]**

---

## Answer

## Redlich–Kister Density Correlation for Ethanol + Water: 350 K Assessment

### Can the Available Measurements Support 350 K Directly?

**No.** A thorough search of the NIST ThermoML database found **no** binary ethanol + water mass-density block with measurements at 350 K (user-requested target, not a database value) at atmospheric pressure. The best atmospheric-pressure source is:

- **GLOBlit_220 :: PROPblock_2** (DOI: 10.1016/j.fluid.2004.11.019)
  - 47 composition points per isotherm at P = 100 kPa (from fit results)
  - Three isotherms: **298.15 K, 323.15 K, and 348.15 K**
  - Ethanol mole fraction range: 0.003–1.0 (full composition range)
  - Density range at 100 kPa: 739.4–995.3 kg/m³

Other inspected blocks were either methanol + water (GLOBlit_1742, GLOBlit_2432), dilute/high-pressure only (GLOBlit_1483 :: PROPblock_1: x(ethanol) ≤ 0.0946, P = 2450–40140 kPa), or covered lower temperatures (GLOBlit_5201 :: PROPblock_19 at 293.15–308.15 K; GLOBlit_2825 :: PROPblock_12 at 293.15–303.15 K).

### Nearest Defensible Temperature: 348.15 K

The closest measured isotherm is **348.15 K** — only ~2 K below the user target of 350 K (computed difference: 350 − 348.15 = 1.85; both 350 and 1.85 are derived/user values, not database entries). A Redlich–Kister fit at this temperature is fully grounded in experimental data.

### Why the 350 K Prediction Should Be Withheld

1. **No measured data exist at 350 K** (user target, not a database value). Interpolating between the 348.15 K and 323.15 K isotherms (a 25 K gap in the wrong direction) or extrapolating ~2 K (computed difference) beyond the dataset boundary would require a temperature-dependent model that is not constrained by any data between or beyond these isotherms.

2. **Non-linear temperature dependence of the RK coefficients.** The leading RK coefficient A₀ evolves from −120.557 (298.15 K) → −147.182 (323.15 K) → −167.860 (348.15 K), showing that the excess density function changes shape significantly with temperature. The higher-order coefficients also shift non-monotonically (e.g., A₁ goes from +18.568 → +39.606 → +50.452). A simple linear extrapolation of these coefficients to 350 K would be an unvalidated assumption.

3. **Ethanol–water is a strongly non-ideal system.** The hydrogen-bonding network reorganization that drives the large negative excess volumes in this system is highly temperature-sensitive. Near 348 K, ethanol approaches its normal boiling point (~351 K; general chemistry reference value, not from this database), making even small temperature extrapolations unreliable without additional data.

### Redlich–Kister Fit Results at 348.15 K (Recommended)

| Parameter | Value |
|-----------|-------|
| **Source** | GLOBlit_220 :: PROPblock_2 (DOI: 10.1016/j.fluid.2004.11.019) |
| **Temperature** | 348.15 K |
| **Pressure** | 100 kPa |
| **Data points** | 47 |
| **BIC-selected RK order** | 5 |
| **R²** | 0.998607 |
| **RMSE** | 0.491 kg/m³ |
| **ρ*(ethanol)** | 739.4 kg/m³ (block edge) |
| **ρ*(water)** | 969.467 kg/m³ (block edge) |

**RK coefficients** (density deviation from linear mixing rule, kg/m³):

| Coefficient | Value |
|-------------|-------|
| A₀ | −167.860 |
| A₁ | +50.452 |
| A₂ | −18.395 |
| A₃ | +43.193 |
| A₄ | +76.872 |
| A₅ | −109.654 |

The correlation is:

ρ(x₁) = x₁·ρ₁* + (1−x₁)·ρ₂* + x₁(1−x₁) Σₖ Aₖ (2x₁−1)ᵏ

where x₁ = mole fraction of ethanol, ρ₁* = 739.4 kg/m³ (ethanol), ρ₂* = 969.467 kg/m³ (water).

### Companion Fits at Lower Temperatures (for Context)

| Isotherm | RK Order | R² | RMSE (kg/m³) | A₀ | A₁ | A₂ | A₃ | A₄ | A₅ | ρ*(EtOH) | ρ*(H₂O) |
|----------|----------|----|--------------|------|------|------|------|------|------|----------|----------|
| 298.15 K | 3 | 0.997283 | 0.475 | −120.557 | +18.568 | +43.919 | −31.351 | — | — | 785.7 | 992.083 |
| 323.15 K | 5 | 0.998545 | 0.434 | −147.182 | +39.606 | +7.018 | −0.818 | +43.210 | −57.743 | 763.7 | 983.050 |
| 348.15 K | 5 | 0.998607 | 0.491 | −167.860 | +50.452 | −18.395 | +43.193 | +76.872 | −109.654 | 739.4 | 969.467 |

### Chemistry Insight

The large negative A₀ values (−120.557 to −167.860 kg/m³) reflect the well-known volume contraction in ethanol–water mixtures caused by the interstitial accommodation of ethanol molecules within the water hydrogen-bond network. The magnitude of A₀ increases with temperature, consistent with the greater thermal disruption of the pure-component structures making the mixing-induced restructuring relatively more pronounced. The increasing RK order needed at higher temperatures (order 3 at 298.15 K vs. order 5 at 323.15 and 348.15 K) indicates that the composition dependence of the excess density becomes more asymmetric as temperature rises — physically reflecting the growing disparity between the thermal expansion coefficients of the two components.

### Output Files

Fit data, excess-property CSVs, and diagnostic plots were generated for all three isotherms and are available in the session output directory.






















### Core claims

- No binary ethanol + water mass-density data at 350 K and atmospheric pressure were found in the NIST ThermoML database; the nearest measured isotherm is 348.15 K (from GLOBlit_220 :: PROPblock_2, DOI: 10.1016/j.fluid.2004.11.019), so a density prediction at 350 K is withheld as ungrounded.
- A BIC-selected order-5 Redlich–Kister fit at 348.15 K and 100 kPa using 47 composition points yields R² = 0.998607, RMSE = 0.491 kg/m³, pure-component densities ρ*(ethanol) = 739.4 kg/m³ and ρ*(water) = 969.467 kg/m³, and coefficients A₀ = −167.860, A₁ = +50.452, A₂ = −18.395, A₃ = +43.193, A₄ = +76.872, A₅ = −109.654 kg/m³.
- The large negative leading coefficient A₀ (ranging from −120.557 at 298.15 K to −167.860 at 348.15 K) reflects the well-known volume contraction in ethanol–water mixtures; its magnitude increases with temperature.
- The RK coefficients evolve non-linearly with temperature and the required BIC-optimal order increases from 3 (at 298.15 K) to 5 (at 323.15 K and 348.15 K), indicating that simple extrapolation of the fit to 350 K would be an unvalidated assumption.
                                                                                                                               the primary 348.15 K fit parameters are internally consistent.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 |  | Primary data source for the Redlich–Kister fit. Provides ethanol + water mass density at 298.15–348.15 K across the full mole-fraction range (0.003–1.0) including the 348.15 K isotherm used for the recommended correlation. The answer quotes density range 739.4–995.3 kg/m³ and 47 atmospheric-pressure composition points per isotherm, consistent with the card's 810 total datapoints spanning multiple pressures and three temperatures. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_220 | PROPblock_2 | EtOH-Water_298K | 3 | -120.55681029600882; 18.567625256466393; 43.91912836453406; -31.35056319853136 | 0.997283 | 0.47476545853553287 | 47 | 298.15 | linear |  | 10.1016/j.fluid.2004.11.019 |
| GLOBlit_220 | PROPblock_2 | EtOH-Water_323K | 5 | -147.18152932779074; 39.60569255822063; 7.01749645443866; -0.8181485634897987; 43.21001311217272; -57.74322843339459 | 0.998545 | 0.4343815607863475 | 47 | 323.15 | linear |  | 10.1016/j.fluid.2004.11.019 |
| GLOBlit_220 | PROPblock_2 | EtOH-Water_348K | 5 | -167.86002395954665; 50.451481788374586; -18.395033167878626; 43.192935535925116; 76.87234713346206; -109.65389601054669 | 0.998607 | 0.4911460748640253 | 47 | 348.15 | linear |  | 10.1016/j.fluid.2004.11.019 |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
