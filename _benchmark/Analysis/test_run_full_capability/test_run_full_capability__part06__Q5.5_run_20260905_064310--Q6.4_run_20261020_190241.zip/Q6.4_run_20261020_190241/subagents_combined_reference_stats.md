# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 6 | 40,762 | 119,649 | 16,587 | 160,411 | 26,735 | 109.4 | claudeopus46 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| L1-worker | 34 | 436,464 | 429,003 | 116,413 | 865,467 | 25,454 | 751.3 | claudeopus46 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| **TOTAL** | **40** | **477,226** | **548,652** | **133,000** | **1,025,878** | **52,189** | **860.7** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `search_blocks` | 1 | 1 | 1 | 1 | 20 | 20 | 111 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `search_system_registry` | 1 | 1 | 1 | 1 | 20 | 20 | 111 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `search_blocks` | 1 | 1 | 1 | 1 | 20 | 20 | 111 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `block_search_adv` | 1 | 0 | 0 | 0 | 8 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `search_blocks` | 1 | 1 | 1 | 0 | 8 | 10 | 334 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `search_system_registry` | 1 | 1 | 1 | 0 | 8 | 10 | 334 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 80 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 75 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| `search_blocks` | 1 | 1 | 1 | 0 | 1 | 1 | 4 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| **TOTAL** | **10** | **8** | **8** | **3** | **87** | **83** | **1,160** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_230 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_273 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_328 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_331 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_490 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_497 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_567 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_619 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_635 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_973 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_1218 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_1229 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_2577 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_2697 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_8199 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_8712 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_9995 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_11195 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_11496 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_11877 |  | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_8678 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_8810 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_6949 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_6449 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_1600 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_6709 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_882 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBlit_8876 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_52 | diisopropyl ether | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBcomp_139 |  | block_search_adv, resolve_compound_ids, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_146 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_155 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_164 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_161 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_5 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_76 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_159 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_135 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_23 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_73 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBmeas_386 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| GLOBphase_2 |  | block_search_adv, search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBblocktype_2 |  | block_search_adv, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique References | 28 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Unique Compounds | 2 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Unique Properties | 1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Unique Measurements | 12 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Unique Phases | 2 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Unique Variables | 1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Unique Constraints | 1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Unique Block_Types | 1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Unique parent blocks | 30 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Explicit block/subsystem targets | 30 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Subsystem targets | 0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| Target-matched data points | 1,160 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| **TOTAL** | **1,268** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.fluid.2004.12.007 | 1 | 2 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2005.05.024 | 1 | 2 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2005.11.014 | 1 | 4 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2005.11.017 | 1 | 3 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2007.02.026 | 1 | 1 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2007.03.017 | 1 | 9 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2007.09.014 | 1 | 2 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2008.03.015 | 1 | 16 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2008.06.006 | 1 | 11 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2010.09.006 | 1 | 4 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2011.06.001 | 1 | 3 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2013.01.020 | 1 | 3 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2013.02.005 | 1 | 17 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2014.11.026 | 1 | 13 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.jct.2005.07.004 | 1 | 3 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.jct.2006.05.007 | 1 | 9 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.tca.2018.07.026 | 1 | 12 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/acs.jced.5b00752 | 2 | 36 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/acs.jced.6b00523 | 2 | 108 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je030238d | 1 | 1 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je050216m | 1 | 75 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je0502896 | 1 | 3 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je050502y | 1 | 80 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je060088h | 1 | 6 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je300994y | 1 | 18 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je800298n | 1 | 1 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je900042q | 1 | 1 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je900977e | 1 | 2 | unary | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | ---: | --- | --- |
| 10.1016/j.fluid.2004.12.007 | PROPblock_6 | declared | 2 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2005.05.024 | PROPblock_4 | declared | 2 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2005.11.014 | PROPblock_1 | declared | 4 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2005.11.017 | PROPblock_1 | declared | 3 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2007.02.026 | PROPblock_15 | declared | 1 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2007.03.017 | PROPblock_1 | declared | 9 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2007.09.014 | PROPblock_3 | declared | 2 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2008.03.015 | PROPblock_3 | declared | 16 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2008.06.006 | PROPblock_8 | declared | 11 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2010.09.006 | PROPblock_1 | declared | 4 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2011.06.001 | PROPblock_4 | declared | 3 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2013.01.020 | PROPblock_6 | declared | 3 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2013.02.005 | PROPblock_10 | declared | 17 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.fluid.2014.11.026 | PROPblock_5 | declared | 13 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.jct.2005.07.004 | PROPblock_1 | declared | 3 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.jct.2006.05.007 | PROPblock_1 | declared | 9 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1016/j.tca.2018.07.026 | PROPblock_7 | declared | 12 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/acs.jced.5b00752 | PROPblock_1 | declared | 12 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/acs.jced.5b00752 | PROPblock_2 | declared | 24 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/acs.jced.6b00523 | PROPblock_1 | declared | 102 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/acs.jced.6b00523 | PROPblock_2 | declared | 6 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je030238d | PROPblock_9 | declared | 1 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je050216m | PROPblock_1 | declared | 75 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je0502896 | PROPblock_1 | declared | 3 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je050502y | PROPblock_1 | declared | 80 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je060088h | PROPblock_18 | declared | 6 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je300994y | PROPblock_3 | declared | 18 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je800298n | PROPblock_3 | declared | 1 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je900042q | PROPblock_3 | declared | 1 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10.1021/je900977e | PROPblock_3 | declared | 2 | unary | 1 | search_blocks, search_system_registry | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |


## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `search_blocks` | compound=GLOBcomp_52, limit=50, property=GLOBprop_… | 1,036 | KEEP ←in 10,002 | 1022 | 20.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 2 | 2 | `search_system_registry` | compound=GLOBcomp_52, limit=50, property=GLOBprop_… | 671 | DISCARD ←in 3,091 | 604 | 17.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 3 | 3 | `resolve_compound_ids` | purpose=Confirm naphthalene global co…, queries=['… | 371 | KEEP ←in 239 | 371 | 5.9 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 4 | 3 | `search_blocks` | compound=GLOBcomp_52, limit=50, property=GLOBprop_… | 1,118 | KEEP ←in 10,002 | 1118 | 19.8 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 5 | 4 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_139 AS nap…, explanat… | 1,118 | KEEP ←in 6,093 | 1118 | 19.4 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 6 | 6 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_8678,… | 1,853 | — | — | 0.1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 7 | 6 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_8810,… | 1,305 | — | — | 0.1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 8 | 6 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_6949,… | 1,538 | — | — | 0.1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 9 | 7 | `inspect_block_table` | block_number=PROPblock_7, literature=GLOBlit_6449,… | 1,259 | — | — | 0.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10 | 7 | `inspect_block_table` | block_number=PROPblock_5, literature=GLOBlit_1600,… | 1,277 | — | — | 0.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 11 | 7 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_6709,… | 1,304 | — | — | 0.2 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 12 | 7 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_6949,… | 999 | — | — | 0.1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 13 | 7 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_6709,… | 1,193 | — | — | 0.1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 14 | 1 | `L1_query` | context=Previous queries confirmed na…, id_catalog… | 61,122 | — | — | 320.8 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 15 | 1 | `search_blocks` | compound=GLOBcomp_139, limit=50, property=GLOBprop… | 1,163 | KEEP ←in 5,346 | 1148 | 19.2 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 16 | 2 | `inspect_block_table` | block_number=PROPblock_1, literature=GLOBlit_882, … | 812 | — | — | 0.1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 17 | 2 | `inspect_block_table` | block_number=PROPblock_2, literature=GLOBlit_6709,… | 1,193 | — | — | 0.1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 18 | 3 | `search_system_registry` | compound=GLOBcomp_139, limit=20, property=GLOBprop… | 1,189 | KEEP ←in 6,225 | 1189 | 19.8 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 19 | 4 | `search_blocks` | compound=GLOBcomp_139, limit=10, literature=GLOBli… | 649 | KEEP ←in 1,632 | 634 | 7.5 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 20 | 4 | `search_blocks` | compound=GLOBcomp_139, limit=10, literature=GLOBli… | 492 | KEEP ←in 2,012 | 477 | 6.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 21 | 4 | `search_blocks` | compound=GLOBcomp_139, limit=10, literature=GLOBli… | 801 | KEEP ←in 1,259 | 787 | 10.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 22 | 2 | `L1_query` | context=8 blocks already found. Need …, id_catalog… | 23,267 | — | — | 445.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| **TOTAL** | **89** |  |  | **105,730** |  | **8,468** | **914.6** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 11,581 | 1,398 | 12,979 | 1,598 | 8.6 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 2 | L1-worker | claudeopus46 | 24,140 | 1,507 | 25,647 | 762 | 6.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 3 | L1-worker | claudeopus46 | 3,767 | 10,426 | 14,193 | 1,523 | 13.5 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 4 | L1-worker | claudeopus46 | 24,140 | 3,026 | 27,166 | 991 | 7.8 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 5 | L1-worker | claudeopus46 | 3,767 | 3,562 | 7,329 | 1,247 | 10.2 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 6 | L1-worker | claudeopus46 | 24,140 | 4,242 | 28,382 | 1,269 | 8.6 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 7 | L1-worker | claudeopus46 | 3,767 | 382 | 4,149 | 641 | 5.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 8 | L1-worker | claudeopus46 | 3,767 | 10,379 | 14,146 | 1,392 | 12.8 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 9 | L1-worker | claudeopus46 | 24,140 | 6,433 | 30,573 | 1,702 | 12.5 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 10 | L1-worker | claudeopus46 | 3,767 | 6,280 | 10,047 | 1,389 | 11.5 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 11 | L1-worker | claudeopus46 | 24,140 | 8,166 | 32,306 | 7,415 | 46.4 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 12 | L1-worker | claudeopus46 | 24,140 | 18,232 | 42,372 | 13,775 | 66.0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 13 | L1-worker | claudeopus46 | 24,140 | 20,040 | 44,180 | 1,725 | 8.6 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 14 | L1-worker | claudeopus46 | 24,140 | 22,862 | 47,002 | 4,571 | 35.1 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 15 | L1-worker | claudeopus46 | 24,140 | 30,217 | 54,357 | 3,153 | 21.0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 16 | L1-worker | claudeopus46 | 2,320 | 3,944 | 6,264 | 1,156 | 8.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 17 | L1-worker | claudeopus46 | 627 | 3,824 | 4,451 | 1,426 | 10.9 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 18 | L1-worker | claudeopus46 | 2,543 | 5,572 | 8,115 | 2,641 | 11.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 19 | L1-worker | claudeopus46 | 787 | 40,955 | 41,742 | 808 | 9.2 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 20 | L0-main | claudeopus46 | 11,581 | 34,449 | 46,030 | 3,424 | 26.0 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 21 | L1-worker | claudeopus46 | 24,140 | 10,288 | 34,428 | 851 | 6.6 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 22 | L1-worker | claudeopus46 | 3,767 | 5,755 | 9,522 | 1,464 | 12.9 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 23 | L1-worker | claudeopus46 | 24,140 | 11,984 | 36,124 | 14,559 | 88.4 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 24 | L1-worker | claudeopus46 | 24,140 | 14,837 | 38,977 | 14,144 | 86.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 25 | L1-worker | claudeopus46 | 3,767 | 6,651 | 10,418 | 1,483 | 12.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 26 | L1-worker | claudeopus46 | 24,140 | 16,780 | 40,920 | 14,301 | 76.4 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 27 | L1-worker | claudeopus46 | 3,767 | 2,043 | 5,810 | 957 | 7.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 28 | L1-worker | claudeopus46 | 3,767 | 2,423 | 6,190 | 680 | 6.5 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 29 | L1-worker | claudeopus46 | 3,767 | 1,671 | 5,438 | 1,440 | 10.5 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 30 | L1-worker | claudeopus46 | 24,140 | 20,053 | 44,193 | 5,701 | 37.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 31 | L1-worker | claudeopus46 | 24,140 | 32,734 | 56,874 | 4,308 | 29.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 32 | L1-worker | claudeopus46 | 24,140 | 43,894 | 68,034 | 4,738 | 32.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 33 | L1-worker | claudeopus46 | 2,543 | 11,469 | 14,012 | 870 | 6.4 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 34 | L1-worker | claudeopus46 | 2,320 | 9,569 | 11,889 | 1,073 | 9.9 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 35 | L1-worker | claudeopus46 | 627 | 9,449 | 10,076 | 1,663 | 15.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 36 | L1-worker | claudeopus46 | 787 | 29,354 | 30,141 | 595 | 5.9 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 37 | L0-main | claudeopus46 | 11,581 | 64,797 | 76,378 | 5,362 | 38.4 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 38 | L0-main | claudeopus46 | 2,320 | 3,860 | 6,180 | 1,205 | 7.4 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 39 | L0-main | claudeopus46 | 2,543 | 5,090 | 7,633 | 1,767 | 11.3 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
| 40 | L0-main | claudeopus46 | 1,156 | 10,055 | 11,211 | 3,231 | 17.7 | List all DOIs and block numbers for naphthalene (GLOBcomp_52 (query_runs/run_1) |
