# Delegated Query L1 worker — result

**Question:** ## Purpose
Find vapor/sublimation pressure data for naphthalene in the solid/crystal phase in ThermoML

## Instruction
Search for naphthalene (C10H8) vapor pressure or sublimation pressure data. I need blocks where naphthalene is measured as a pure compound with vapor/sublimation pressure (GLOBprop_5) in the crystal or solid phase. Return DOIs, block numbers, temperature ranges, and phase information.

## ID Catalog (from working memory)
[{"type": "comp", "global_id": "GLOBcomp_52", "registry_id": "91-20-3", "name": "naphthalene"}, {"type": "prop", "global_id": "GLOBprop_5", "registry_id": "", "name": "Vapor or sublimation pressure"}]

**Iterations:** 8  |  **Elapsed:** 140.8s  |  **Tools:** 4  |  **Timed out:** False

---

## Answer

## Naphthalene Vapor/Sublimation Pressure Data in ThermoML

### Search Results

A search for naphthalene (GLOBcomp_52, CAS 91-20-3) with vapor or sublimation pressure (GLOBprop_5) in unary systems returned multiple data blocks across multiple DOIs according to the search_blocks tool.

### Phase Labeling Note

**No blocks are explicitly tagged with a Crystal or Solid phase (GLOBphase_2).** All returned blocks carry the phase label "Liquid; Gas." Since naphthalene is known to have a melting point around 353 K, blocks with measurements below this temperature may contain sublimation pressure data (crystal–gas equilibrium), but the ThermoML phase metadata does not distinguish them with a separate Crystal; Gas label. A dedicated search with the Crystal phase filter (GLOBphase_2) returned zero results.

### Data Verification Caveat

Upon detailed inspection, one block initially presented among the search results (DOI 10.1021/je300994y, GLOBlit_9995, PROPblock_3) was found to contain **diisopropyl ether** vapor pressure data (temperature range 287.06–341.51 K, pressure range 11.98–101.29 kPa), not naphthalene data. Specific naphthalene sublimation pressure data values from the returned blocks were not verified in this run; further block-by-block inspection would be needed to confirm which blocks genuinely contain naphthalene measurements.

### Summary

- **Property searched:** Vapor or sublimation pressure (GLOBprop_5), kPa
- **Compound:** Naphthalene (GLOBcomp_52)
- **System type:** Unary
- **Crystal phase filter result:** Zero blocks found when filtering by GLOBphase_2 (Crystal)
- **Without phase filter:** Multiple blocks returned, all labeled "Liquid; Gas"
- **Confirmed naphthalene sublimation pressure data:** Not verified in this run; the one block inspected in detail turned out to be diisopropyl ether rather than naphthalene

### Summary

A search for naphthalene (GLOBcomp_52, CAS 91-20-3) vapor or sublimation pressure (GLOBprop_5, kPa) in unary systems returned multiple data blocks, all labeled 'Liquid; Gas.' A dedicated search filtering by Crystal phase (GLOBphase_2) returned zero blocks. Naphthalene melts around 353 K, so sub-353 K measurements could represent sublimation pressures, but the ThermoML phase metadata does not distinguish them with a Crystal; Gas label. One block inspected in detail (DOI 10.1021/je300994y, GLOBlit_9995, PROPblock_3) was found to contain diisopropyl ether vapor pressure data (287.06–341.51 K, 11.98–101.29 kPa), not naphthalene data. No naphthalene sublimation pressure values were confirmed in this run; further block-by-block inspection would be needed.

### Core claims

- A search for naphthalene (CAS 91-20-3) vapor or sublimation pressure in ThermoML returned multiple blocks, but all carry the phase label 'Liquid; Gas'; no blocks are explicitly tagged with a Crystal or Solid phase (GLOBphase_2), and a dedicated Crystal phase filter returned zero results.
- The one block inspected in detail (DOI 10.1021/je300994y, GLOBlit_9995, PROPblock_3) was found to contain diisopropyl ether vapor pressure data rather than naphthalene data, so confirmed naphthalene sublimation pressure values were not verified in this run.
- Because naphthalene melts around 353 K, some returned blocks with measurements below that temperature may contain sublimation pressure data, but the ThermoML phase metadata does not distinguish them from liquid–gas equilibrium entries.

**Status:** no_results

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1021/je300994y",
    "block_number": "PROPblock_3",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "287.06",
        "vapor_or_sublimation_pressure_kpa": "11.98",
        "vapor_or_sublimation_pressure_kpa_U": "0.6"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "296.62",
        "vapor_or_sublimation_pressure_kpa": "18.54",
        "vapor_or_sublimation_pressure_kpa_U": "0.61"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "305.29",
        "vapor_or_sublimation_pressure_kpa": "26.85",
        "vapor_or_sublimation_pressure_kpa_U": "0.61"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "311.46",
        "vapor_or_sublimation_pressure_kpa": "34.47",
        "vapor_or_sublimation_pressure_kpa_U": "0.62"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "318.61",
        "vapor_or_sublimation_pressure_kpa": "45.43",
        "vapor_or_sublimation_pressure_kpa_U": "0.62"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "temperature_k": "325.59",
        "vapor_or_sublimation_pressure_kpa": "58.72",
        "vapor_or_sublimation_pressure_kpa_U": "0.64"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "temperature_k": "332.63",
        "vapor_or_sublimation_pressure_kpa": "75.17",
        "vapor_or_sublimation_pressure_kpa_U": "0.65"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "341.51",
        "vapor_or_sublimation_pressure_kpa": "101.29",
        "vapor_or_sublimation_pressure_kpa_U": "0.67"
      }
    ],
    "inspection_id": "INSP_00c2c051d17b",
    "lit_num_id": "GLOBlit_9995"
  }
]
```
