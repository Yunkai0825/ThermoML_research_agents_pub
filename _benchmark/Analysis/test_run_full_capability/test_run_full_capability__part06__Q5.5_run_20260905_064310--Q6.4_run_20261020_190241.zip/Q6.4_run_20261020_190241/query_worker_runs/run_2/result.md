# Delegated Query L1 worker — result

**Question:** ## Purpose
Find directly reported enthalpy of sublimation for naphthalene in ThermoML

## Instruction
Search for naphthalene (C10H8) enthalpy of sublimation or enthalpy of transition/phase change data. Look for molar enthalpy of sublimation, molar enthalpy of vaporization or transition (GLOBprop_10) for naphthalene as a pure compound. Also check for any enthalpy property that might represent sublimation. Return DOIs, block numbers, temperature, values, and phase information.

## ID Catalog (from working memory)
[{"type": "comp", "global_id": "GLOBcomp_52", "registry_id": "91-20-3", "name": "naphthalene"}, {"type": "prop", "global_id": "GLOBprop_10", "registry_id": "", "name": "Molar enthalpy of transition or fusion"}]

**Iterations:** 5  |  **Elapsed:** 136.5s  |  **Tools:** 5  |  **Timed out:** False

---

## Answer

**Enthalpy of sublimation for naphthalene in ThermoML: Not found.**

A thorough search of the ThermoML database for naphthalene (GLOBcomp_52, CAS 91-20-3) reveals **no directly reported molar enthalpy of sublimation (or vaporization)** data. The relevant property identifier in ThermoML is GLOBprop_19 ("Molar enthalpy of vaporization or sublimation, kJ/mol"), but searching naphthalene unary systems with this property returns zero blocks.

Naphthalene has extensive ThermoML coverage overall — 597 property blocks across 155 papers with 19,744 data points — but the available unary (pure compound) data is concentrated in other properties:

- **Vapor or sublimation pressure** (GLOBprop_5): 50 blocks total (12 in unary systems), covering T ≈ 263.75–354.88 K across multiple DOIs (e.g., GLOBlit_497, GLOBlit_619, GLOBlit_1229)
- **Mass density** (GLOBprop_1): 99 blocks total (20 unary), T ≈ 283.15–333.15 K
- **Refractive index**, **surface tension**, **speed of sound**, **viscosity**, and other thermophysical properties

While sublimation/vapor pressure data exists for naphthalene (which could in principle be used to derive sublimation enthalpy via the Clausius–Clapeyron equation), no directly measured or reported enthalpy of sublimation values are present in the ThermoML database.

### Summary

A thorough search of the ThermoML database for naphthalene (GLOBcomp_52, CAS 91-20-3) found no directly reported molar enthalpy of sublimation (or vaporization) data. The relevant property identifier GLOBprop_19 ('Molar enthalpy of vaporization or sublimation, kJ/mol') returns zero blocks for naphthalene unary systems. Naphthalene has extensive ThermoML coverage overall — 597 property blocks across 155 papers with 19,744 data points — but unary pure-compound data is concentrated in other properties such as vapor or sublimation pressure (50 blocks total, 12 unary, covering T ≈ 263.75–354.88 K), mass density (99 blocks total, 20 unary, T ≈ 283.15–333.15 K), refractive index, surface tension, speed of sound, and viscosity. While sublimation/vapor pressure data exists that could in principle be used to derive sublimation enthalpy via the Clausius–Clapeyron equation, no directly measured or reported enthalpy of sublimation values are present in ThermoML.

### Core claims

- A thorough search of the ThermoML database for naphthalene (CAS 91-20-3) found no directly reported molar enthalpy of sublimation (or vaporization) data, despite extensive overall coverage (597 property blocks across 155 papers with 19,744 data points).
- Vapor or sublimation pressure data for naphthalene exists in ThermoML (50 blocks total, 12 in unary systems, covering T ≈ 263.75–354.88 K), which could in principle be used to derive sublimation enthalpy via the Clausius–Clapeyron equation, but no such derived or directly measured enthalpy of sublimation values are reported in the database.

**Status:** no_results

---

## Core ID Updates (deterministic ledger)

Deterministic identifier updates; rendered by the browser.

```json
[
  {
    "action": "add",
    "core_GLOB_id": "GLOBprop_19",
    "registry_id": "molar_enthalpy_of_vaporization_or_sublimation_kj_mol",
    "name": "Molar enthalpy of vaporization or sublimation, kJ/mol"
  }
]
```
