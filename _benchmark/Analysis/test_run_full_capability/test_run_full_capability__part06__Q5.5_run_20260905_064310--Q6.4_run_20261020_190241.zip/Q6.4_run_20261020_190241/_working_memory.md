# Working Memory

**ROOT:** `N:\_Code_Maintenance\_outputs_user\Benchmark\ThermoML\Analysis\test_run_r1_1_20261020\Q6.4_run_20261020_190241`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| prop | GLOBprop_19 | molar enthalpy of vaporization or sublimation, kj/mol |  |

### History
- [query_thermoml]
- [query_thermoml]
- [run_query_agent]

### Query Results
#### query
**L1_query_1** — status: no_results · validation: PASS

**Summary:**

A search for naphthalene (GLOBcomp_52, CAS 91-20-3) vapor or sublimation pressure (GLOBprop_5, kPa) in unary systems returned multiple data blocks, all labeled 'Liquid; Gas.' A dedicated search filtering by Crystal phase (GLOBphase_2) returned zero blocks. Naphthalene melts around 353 K, so sub-353 K measurements could represent sublimation pressures, but the ThermoML phase metadata does not distinguish them with a Crystal; Gas label. One block inspected in detail (DOI 10.1021/je300994y, GLOBlit_9995, PROPblock_3) was found to contain diisopropyl ether vapor pressure data (287.06–341.51 K, 11.98–101.29 kPa), not naphthalene data. No naphthalene sublimation pressure values were confirmed in this run; further block-by-block inspection would be needed.

**Answer:**

#### Naphthalene Vapor/Sublimation Pressure Data in ThermoML

##### Search Results

A search for naphthalene (GLOBcomp_52, CAS 91-20-3) with vapor or sublimation pressure (GLOBprop_5) in unary systems returned multiple data blocks across multiple DOIs according to the search_blocks tool.

##### Phase Labeling Note

**No blocks are explicitly tagged with a Crystal or Solid phase (GLOBphase_2).** All returned blocks carry the phase label "Liquid; Gas." Since naphthalene is known to have a melting point around 353 K, blocks with measurements below this temperature may contain sublimation pressure data (crystal–gas equilibrium), but the ThermoML phase metadata does not distinguish them with a separate Crystal; Gas label. A dedicated search with the Crystal phase filter (GLOBphase_2) returned zero results.

##### Data Verification Caveat

Upon detailed inspection, one block initially presented among the search results (DOI 10.1021/je300994y, GLOBlit_9995, PROPblock_3) was found to contain **diisopropyl ether** vapor pressure data (temperature range 287.06–341.51 K, pressure range 11.98–101.29 kPa), not naphthalene data. Specific naphthalene sublimation pressure data values from the returned blocks were not verified in this run; further block-by-block inspection would be needed to confirm which blocks genuinely contain naphthalene measurements.

##### Summary

- **Property searched:** Vapor or sublimation pressure (GLOBprop_5), kPa
- **Compound:** Naphthalene (GLOBcomp_52)
- **System type:** Unary
- **Crystal phase filter result:** Zero blocks found when filtering by GLOBphase_2 (Crystal)
- **Without phase filter:** Multiple blocks returned, all labeled "Liquid; Gas"
- **Confirmed naphthalene sublimation pressure data:** Not verified in this run; the one block inspected in detail turned out to be diisopropyl ether rather than naphthalene

**Core claims:**
- A search for naphthalene (CAS 91-20-3) vapor or sublimation pressure in ThermoML returned multiple blocks, but all carry the phase label 'Liquid; Gas'; no blocks are explicitly tagged with a Crystal or Solid phase (GLOBphase_2), and a dedicated Crystal phase filter returned zero results.
- The one block inspected in detail (DOI 10.1021/je300994y, GLOBlit_9995, PROPblock_3) was found to contain diisopropyl ether vapor pressure data rather than naphthalene data, so confirmed naphthalene sublimation pressure values were not verified in this run.
- Because naphthalene melts around 353 K, some returned blocks with measurements below that temperature may contain sublimation pressure data, but the ThermoML phase metadata does not distinguish them from liquid–gas equilibrium entries.

*Not stored here: 1 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.


#### query
**L1_query_2** — status: no_results · validation: PASS

**Summary:**

A thorough search of the ThermoML database for naphthalene (GLOBcomp_52, CAS 91-20-3) found no directly reported molar enthalpy of sublimation (or vaporization) data. The relevant property identifier GLOBprop_19 ('Molar enthalpy of vaporization or sublimation, kJ/mol') returns zero blocks for naphthalene unary systems. Naphthalene has extensive ThermoML coverage overall — 597 property blocks across 155 papers with 19,744 data points — but unary pure-compound data is concentrated in other properties such as vapor or sublimation pressure (50 blocks total, 12 unary, covering T ≈ 263.75–354.88 K), mass density (99 blocks total, 20 unary, T ≈ 283.15–333.15 K), refractive index, surface tension, speed of sound, and viscosity. While sublimation/vapor pressure data exists that could in principle be used to derive sublimation enthalpy via the Clausius–Clapeyron equation, no directly measured or reported enthalpy of sublimation values are present in ThermoML.

**Answer:**

**Enthalpy of sublimation for naphthalene in ThermoML: Not found.**

A thorough search of the ThermoML database for naphthalene (GLOBcomp_52, CAS 91-20-3) reveals **no directly reported molar enthalpy of sublimation (or vaporization)** data. The relevant property identifier in ThermoML is GLOBprop_19 ("Molar enthalpy of vaporization or sublimation, kJ/mol"), but searching naphthalene unary systems with this property returns zero blocks.

Naphthalene has extensive ThermoML coverage overall — 597 property blocks across 155 papers with 19,744 data points — but the available unary (pure compound) data is concentrated in other properties:

- **Vapor or sublimation pressure** (GLOBprop_5): 50 blocks total (12 in unary systems), covering T ≈ 263.75–354.88 K across multiple DOIs (e.g., GLOBlit_497, GLOBlit_619, GLOBlit_1229)
- **Mass density** (GLOBprop_1): 99 blocks total (20 unary), T ≈ 283.15–333.15 K
- **Refractive index**, **surface tension**, **speed of sound**, **viscosity**, and other thermophysical properties

While sublimation/vapor pressure data exists for naphthalene (which could in principle be used to derive sublimation enthalpy via the Clausius–Clapeyron equation), no directly measured or reported enthalpy of sublimation values are present in the ThermoML database.

**Core claims:**
- A thorough search of the ThermoML database for naphthalene (CAS 91-20-3) found no directly reported molar enthalpy of sublimation (or vaporization) data, despite extensive overall coverage (597 property blocks across 155 papers with 19,744 data points).
- Vapor or sublimation pressure data for naphthalene exists in ThermoML (50 blocks total, 12 in unary systems, covering T ≈ 263.75–354.88 K), which could in principle be used to derive sublimation enthalpy via the Clausius–Clapeyron equation, but no such derived or directly measured enthalpy of sublimation values are reported in the database.

*Not stored here: 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** PASS — no unresolved ungrounded values.

