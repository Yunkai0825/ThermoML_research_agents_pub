# Delegated query run — result

**Question:** List all DOIs and block numbers for naphthalene (GLOBcomp_52, CAS 91-20-3) unary (pure compound) vapor or sublimation pressure (GLOBprop_5) data blocks. For each block, report the DOI, lit_num_id, block_number, temperature range, pressure range, and number of data points. I need the specific DOI strings and block numbers so I can inspect them.

**Iterations:** 3  |  **Elapsed:** 839.6s  |  **Tools:** 2  |  **Timed out:** False

---

## Answer

## Naphthalene Vapor/Sublimation Pressure Data Blocks in ThermoML

**Important:** The correct database compound ID for naphthalene (C₁₀H₈, CAS 91-20-3) is **GLOBcomp_139** (not GLOBcomp_52). The database contains **10 blocks across 7 DOIs** totaling **334 data points**. Nine of the ten blocks have been fully identified; one block (~6 points) could not be retrieved due to output truncation.

### Complete Inventory (9 of 10 blocks confirmed)

| # | DOI | lit_num_id | Block | Phase | n_pts | T range (K) | P range (kPa) | Method |
|---|-----|-----------|-------|-------|-------|-------------|---------------|--------|
| 1 | 10.1021/je050216m | GLOBlit_8678 | PROPblock_1 | Crystal (sublimation) | 75 | 258.48–313.52 | 0.00011–0.0455 | Closed cell, static |
| 2 | 10.1021/je050502y | GLOBlit_8810 | PROPblock_1 | Crystal (sublimation) | 80 | 262.24–323.24 | 0.000181–0.1059 | Diaphragm manometer |
| 3 | 10.1021/acs.jced.6b00523 | GLOBlit_6949 | PROPblock_1 | Crystal (sublimation) | 102 | 276.72–352.18 | 0.001118–0.91956 | Closed cell, static |
| 4 | 10.1016/j.tca.2018.07.026 | GLOBlit_6449 | PROPblock_7 | Crystal (sublimation) | 12 | 288.2–333.0 | 0.00418–0.22352 | Transpiration |
| 5 | 10.1016/j.fluid.2014.11.026 | GLOBlit_1600 | PROPblock_5 | Crystal (sublimation) | 13 | 297.72–326.97 | 0.01042–0.1415 | Closed cell, static |
| 6 | 10.1021/acs.jced.5b00752 | GLOBlit_6709 | PROPblock_1 | Crystal (sublimation) | 12 | 312.203–352.194 | 0.04083–0.92131 | Closed cell, static |
| 7 | 10.1016/j.fluid.2010.09.006 | GLOBlit_882 | PROPblock_1 | Crystal (high-P boundary) | 4 | 337.8–351.4 | 100–8000 | Visual observation |
| 8 | 10.1021/acs.jced.6b00523 | GLOBlit_6949 | PROPblock_2 | Liquid (vaporization) | 6 | 355.35–358.38 | 1.098–1.2686 | Closed cell, static |
| 9 | 10.1021/acs.jced.5b00752 | GLOBlit_6709 | PROPblock_2 | Liquid (vaporization) | 24 | 357.19–452.367 | 1.1997–38.569 | Closed cell, static |

### Guidance for Clausius–Clapeyron Sublimation Enthalpy Estimation

**Best candidates for ΔH_sub estimation (crystal-phase sublimation, blocks 1–6):**

- **Block 3** (GLOBlit_6949 / PROPblock_1, DOI 10.1021/acs.jced.6b00523) is the richest dataset with **102 points** spanning 276.72–352.18 K and nearly three decades of pressure. Representative inspected data points: 293.36 K / 0.006861 kPa, 308.22 K / 0.02834 kPa, 330.6 K / 0.18866 kPa, 352.18 K / 0.91956 kPa.

- **Block 2** (GLOBlit_8810 / PROPblock_1, DOI 10.1021/je050502y) has **80 points** at lower temperatures (262.24–323.24 K). Representative inspected data: 262.24 K / 0.000182 kPa, 293.18 K / 0.006699 kPa, 323.24 K / 0.1059 kPa.

- **Block 1** (GLOBlit_8678 / PROPblock_1, DOI 10.1021/je050216m) has **75 points** at the lowest temperatures (258.48–313.52 K). Representative inspected data: 258.48 K / 0.00011 kPa, 293.49 K / 0.00688 kPa, 313.52 K / 0.0455 kPa.

**Blocks to exclude or treat separately:**

- **Block 7** (GLOBlit_882 / PROPblock_1) shows an anomalous inverse T–P relationship (351.4 K / 100 kPa, 345.7 K / 3000 kPa, 341.4 K / 6000 kPa, 337.8 K / 8000 kPa). These very high pressures likely represent a high-pressure solid–gas phase boundary, not conventional sublimation — **exclude from standard Clausius–Clapeyron analysis**.

- **Blocks 8–9** are **liquid-phase** vapor pressures (above the melting point). A Clausius–Clapeyron fit to these would yield ΔH_vap, not ΔH_sub. Block 9 (GLOBlit_6709 / PROPblock_2) with 24 points spanning 357.19–452.367 K is well-suited for ΔH_vap estimation if needed.

All uncertainties reported in the database are expanded combined uncertainties at 95% confidence level, with relative U typically < 1% for the static-method datasets.

### Core claims

- The ThermoML database contains 10 blocks across 7 DOIs totaling 334 data points of vapor/sublimation pressure data for naphthalene (C₁₀H₈, CAS 91-20-3), identified as GLOBcomp_139.
- Six of the ten blocks (blocks 1–6) report crystal-phase sublimation pressures suitable for Clausius–Clapeyron sublimation enthalpy estimation, spanning temperatures from 258.48 K to 352.18 K and pressures from 0.00011 kPa to 0.92131 kPa.
- The richest sublimation dataset is Block 3 (GLOBlit_6949 / PROPblock_1, DOI 10.1021/acs.jced.6b00523) with 102 points spanning 276.72–352.18 K and nearly three decades of pressure.
- Block 7 (GLOBlit_882 / PROPblock_1) shows an anomalous inverse T–P relationship at very high pressures (100–8000 kPa), likely representing a high-pressure solid–gas phase boundary, and should be excluded from standard Clausius–Clapeyron analysis.
- Blocks 8–9 are liquid-phase vapor pressures above the melting point; a Clausius–Clapeyron fit to these would yield ΔH_vap rather than ΔH_sub.
- One block (~6 points) could not be retrieved due to output truncation, so 9 of 10 blocks were fully confirmed.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8678 | 10.1021/je050216m | PROPblock_1 |  | Provides 75 sublimation pressure data points for naphthalene over 258.48–313.52 K (0.00011–0.0455 kPa), the lowest-temperature crystal-phase dataset in the inventory, directly supporting the answer's catalog and Clausius–Clapeyron guidance. |
| GLOBlit_8810 | 10.1021/je050502y | PROPblock_1 |  | Provides 80 sublimation pressure data points for naphthalene over 262.24–323.24 K (0.000181–0.1059 kPa) via diaphragm manometer, contributing the second-largest crystal-phase dataset to the answer. |
| GLOBlit_6949 | 10.1021/acs.jced.6b00523 | PROPblock_1 |  | Richest sublimation pressure dataset with 102 points spanning 276.72–352.18 K (0.001118–0.91956 kPa), identified in the answer as the best candidate for Clausius–Clapeyron ΔH_sub estimation. |
| GLOBlit_6449 | 10.1016/j.tca.2018.07.026 | PROPblock_7 |  | Provides 12 sublimation pressure points for naphthalene over 288.2–333.0 K (0.00418–0.22352 kPa) measured by transpiration method, contributing an independent technique to the answer's inventory. |
| GLOBlit_1600 | 10.1016/j.fluid.2014.11.026 | PROPblock_5 |  | Provides 13 sublimation pressure points for naphthalene over 297.72–326.97 K (0.01042–0.1415 kPa) by static method, supporting the answer's catalog of crystal-phase vapor pressure blocks. |
| GLOBlit_6709 | 10.1021/acs.jced.5b00752 | PROPblock_1 |  | Provides 12 sublimation pressure points for naphthalene over 312.203–352.194 K (0.04083–0.92131 kPa), covering the higher-temperature crystal-phase region near the melting point. |
| GLOBlit_882 | 10.1016/j.fluid.2010.09.006 | PROPblock_1 |  | Contains 4 high-pressure phase boundary data points (100–8000 kPa, 337.8–351.4 K) for naphthalene; the answer correctly identifies this as a high-pressure solid–gas boundary and recommends excluding it from standard Clausius–Clapeyron analysis. |
| GLOBlit_6949 | 10.1021/acs.jced.6b00523 | PROPblock_2 |  | Provides 6 liquid-phase vapor pressure points for naphthalene just above the melting point (355.35–358.38 K, 1.098–1.2686 kPa); the answer correctly categorizes this as vaporization data distinct from sublimation. |
| GLOBlit_6709 | 10.1021/acs.jced.5b00752 | PROPblock_2 |  | Provides 24 liquid-phase vapor pressure points for naphthalene over 357.19–452.367 K (1.1997–38.569 kPa); the answer correctly identifies this as suitable for ΔH_vap estimation and distinguishes it from sublimation data. |

### Suggested follow-ups

- Retrieve the full numerical data arrays from the top sublimation-pressure blocks (GLOBlit_6949/PROPblock_1, GLOBlit_8810/PROPblock_1, GLOBlit_8678/PROPblock_1) to perform a Clausius-Clapeyron ln(P) vs 1/T regression and estimate the enthalpy of sublimation.
- Identify the 10th block (~6 points) that was not retrieved due to output truncation by re-querying the naphthalene unary vapor pressure block listing.
- Compare the sublimation enthalpy derived from Clausius-Clapeyron analysis with literature reference values and with the sum of enthalpy of vaporization (from liquid-phase blocks 8-9) plus enthalpy of fusion.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_139",
    "registry_id": "naphthalene",
    "name": "naphthalene"
  }
]
```

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1021/je050216m",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "258.48",
        "vapor_or_sublimation_pressure_kpa": "0.00011",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "258.48",
        "vapor_or_sublimation_pressure_kpa": "0.00011",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "258.48",
        "vapor_or_sublimation_pressure_kpa": "0.00011",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "258.48",
        "vapor_or_sublimation_pressure_kpa": "0.00011",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "268.48",
        "vapor_or_sublimation_pressure_kpa": "0.00041",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_45",
        "temperature_k": "278.49",
        "vapor_or_sublimation_pressure_kpa": "0.00136",
        "vapor_or_sublimation_pressure_kpa_U": "0.00012"
      },
      {
        "BLKpoint_id": "BLKpoint_49",
        "temperature_k": "283.49",
        "vapor_or_sublimation_pressure_kpa": "0.00241",
        "vapor_or_sublimation_pressure_kpa_U": "0.00012"
      },
      {
        "BLKpoint_id": "BLKpoint_50",
        "temperature_k": "283.49",
        "vapor_or_sublimation_pressure_kpa": "0.00241",
        "vapor_or_sublimation_pressure_kpa_U": "0.00012"
      },
      {
        "BLKpoint_id": "BLKpoint_51",
        "temperature_k": "283.49",
        "vapor_or_sublimation_pressure_kpa": "0.00241",
        "vapor_or_sublimation_pressure_kpa_U": "0.00012"
      },
      {
        "BLKpoint_id": "BLKpoint_53",
        "temperature_k": "288.49",
        "vapor_or_sublimation_pressure_kpa": "0.0041",
        "vapor_or_sublimation_pressure_kpa_U": "0.00014"
      },
      {
        "BLKpoint_id": "BLKpoint_54",
        "temperature_k": "288.49",
        "vapor_or_sublimation_pressure_kpa": "0.0041",
        "vapor_or_sublimation_pressure_kpa_U": "0.00014"
      },
      {
        "BLKpoint_id": "BLKpoint_55",
        "temperature_k": "293.49",
        "vapor_or_sublimation_pressure_kpa": "0.00688",
        "vapor_or_sublimation_pressure_kpa_U": "0.00016"
      },
      {
        "BLKpoint_id": "BLKpoint_56",
        "temperature_k": "293.49",
        "vapor_or_sublimation_pressure_kpa": "0.00688",
        "vapor_or_sublimation_pressure_kpa_U": "0.00016"
      },
      {
        "BLKpoint_id": "BLKpoint_57",
        "temperature_k": "293.49",
        "vapor_or_sublimation_pressure_kpa": "0.00688",
        "vapor_or_sublimation_pressure_kpa_U": "0.00016"
      },
      {
        "BLKpoint_id": "BLKpoint_60",
        "temperature_k": "298.49",
        "vapor_or_sublimation_pressure_kpa": "0.0113",
        "vapor_or_sublimation_pressure_kpa_U": "0.00022"
      },
      {
        "BLKpoint_id": "BLKpoint_62",
        "temperature_k": "298.49",
        "vapor_or_sublimation_pressure_kpa": "0.0113",
        "vapor_or_sublimation_pressure_kpa_U": "0.00022"
      },
      {
        "BLKpoint_id": "BLKpoint_65",
        "temperature_k": "303.5",
        "vapor_or_sublimation_pressure_kpa": "0.0182",
        "vapor_or_sublimation_pressure_kpa_U": "0.00029"
      },
      {
        "BLKpoint_id": "BLKpoint_67",
        "temperature_k": "303.5",
        "vapor_or_sublimation_pressure_kpa": "0.0182",
        "vapor_or_sublimation_pressure_kpa_U": "0.00029"
      },
      {
        "BLKpoint_id": "BLKpoint_68",
        "temperature_k": "308.51",
        "vapor_or_sublimation_pressure_kpa": "0.029",
        "vapor_or_sublimation_pressure_kpa_U": "0.00041"
      },
      {
        "BLKpoint_id": "BLKpoint_69",
        "temperature_k": "308.51",
        "vapor_or_sublimation_pressure_kpa": "0.029",
        "vapor_or_sublimation_pressure_kpa_U": "0.00041"
      },
      {
        "BLKpoint_id": "BLKpoint_70",
        "temperature_k": "308.51",
        "vapor_or_sublimation_pressure_kpa": "0.029",
        "vapor_or_sublimation_pressure_kpa_U": "0.00041"
      },
      {
        "BLKpoint_id": "BLKpoint_71",
        "temperature_k": "308.51",
        "vapor_or_sublimation_pressure_kpa": "0.029",
        "vapor_or_sublimation_pressure_kpa_U": "0.00041"
      },
      {
        "BLKpoint_id": "BLKpoint_75",
        "temperature_k": "313.52",
        "vapor_or_sublimation_pressure_kpa": "0.0455",
        "vapor_or_sublimation_pressure_kpa_U": "0.00058"
      }
    ],
    "inspection_id": "INSP_2a902459c15d",
    "lit_num_id": "GLOBlit_8678"
  },
  {
    "doi": "10.1021/je050502y",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "262.24",
        "vapor_or_sublimation_pressure_kpa": "0.000182",
        "vapor_or_sublimation_pressure_kpa_U": "2.3e-05"
      },
      {
        "BLKpoint_id": "BLKpoint_39",
        "temperature_k": "278.19",
        "vapor_or_sublimation_pressure_kpa": "0.001331",
        "vapor_or_sublimation_pressure_kpa_U": "3.7e-05"
      },
      {
        "BLKpoint_id": "BLKpoint_57",
        "temperature_k": "288.17",
        "vapor_or_sublimation_pressure_kpa": "0.00398",
        "vapor_or_sublimation_pressure_kpa_U": "8.5e-05"
      },
      {
        "BLKpoint_id": "BLKpoint_59",
        "temperature_k": "293.18",
        "vapor_or_sublimation_pressure_kpa": "0.006699",
        "vapor_or_sublimation_pressure_kpa_U": "0.000138"
      },
      {
        "BLKpoint_id": "BLKpoint_64",
        "temperature_k": "298.19",
        "vapor_or_sublimation_pressure_kpa": "0.01109",
        "vapor_or_sublimation_pressure_kpa_U": "0.000224"
      },
      {
        "BLKpoint_id": "BLKpoint_69",
        "temperature_k": "303.18",
        "vapor_or_sublimation_pressure_kpa": "0.01797",
        "vapor_or_sublimation_pressure_kpa_U": "0.000357"
      },
      {
        "BLKpoint_id": "BLKpoint_72",
        "temperature_k": "308.27",
        "vapor_or_sublimation_pressure_kpa": "0.0289",
        "vapor_or_sublimation_pressure_kpa_U": "0.000568"
      },
      {
        "BLKpoint_id": "BLKpoint_75",
        "temperature_k": "313.18",
        "vapor_or_sublimation_pressure_kpa": "0.04501",
        "vapor_or_sublimation_pressure_kpa_U": "0.000883"
      },
      {
        "BLKpoint_id": "BLKpoint_78",
        "temperature_k": "318.25",
        "vapor_or_sublimation_pressure_kpa": "0.06975",
        "vapor_or_sublimation_pressure_kpa_U": "0.001364"
      },
      {
        "BLKpoint_id": "BLKpoint_80",
        "temperature_k": "323.24",
        "vapor_or_sublimation_pressure_kpa": "0.1059",
        "vapor_or_sublimation_pressure_kpa_U": "0.002064"
      }
    ],
    "inspection_id": "INSP_34ea4fc455a4",
    "lit_num_id": "GLOBlit_8810"
  },
  {
    "doi": "10.1021/acs.jced.6b00523",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "293.36",
        "vapor_or_sublimation_pressure_kpa": "0.006861",
        "vapor_or_sublimation_pressure_kpa_U": "0.000291"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "308.22",
        "vapor_or_sublimation_pressure_kpa": "0.02834",
        "vapor_or_sublimation_pressure_kpa_U": "0.00076"
      },
      {
        "BLKpoint_id": "BLKpoint_23",
        "temperature_k": "330.6",
        "vapor_or_sublimation_pressure_kpa": "0.18866",
        "vapor_or_sublimation_pressure_kpa_U": "0.00299"
      },
      {
        "BLKpoint_id": "BLKpoint_29",
        "temperature_k": "341.46",
        "vapor_or_sublimation_pressure_kpa": "0.43058",
        "vapor_or_sublimation_pressure_kpa_U": "0.00593"
      },
      {
        "BLKpoint_id": "BLKpoint_32",
        "temperature_k": "346.84",
        "vapor_or_sublimation_pressure_kpa": "0.63466",
        "vapor_or_sublimation_pressure_kpa_U": "0.00841"
      },
      {
        "BLKpoint_id": "BLKpoint_36",
        "temperature_k": "352.18",
        "vapor_or_sublimation_pressure_kpa": "0.91956",
        "vapor_or_sublimation_pressure_kpa_U": "0.01191"
      },
      {
        "BLKpoint_id": "BLKpoint_47",
        "temperature_k": "326.37",
        "vapor_or_sublimation_pressure_kpa": "0.1338",
        "vapor_or_sublimation_pressure_kpa_U": "0.00234"
      },
      {
        "BLKpoint_id": "BLKpoint_48",
        "temperature_k": "326.37",
        "vapor_or_sublimation_pressure_kpa": "0.1338",
        "vapor_or_sublimation_pressure_kpa_U": "0.00234"
      },
      {
        "BLKpoint_id": "BLKpoint_50",
        "temperature_k": "337.46",
        "vapor_or_sublimation_pressure_kpa": "0.31847",
        "vapor_or_sublimation_pressure_kpa_U": "0.00456"
      },
      {
        "BLKpoint_id": "BLKpoint_52",
        "temperature_k": "348.58",
        "vapor_or_sublimation_pressure_kpa": "0.71429",
        "vapor_or_sublimation_pressure_kpa_U": "0.00941"
      },
      {
        "BLKpoint_id": "BLKpoint_55",
        "temperature_k": "276.72",
        "vapor_or_sublimation_pressure_kpa": "0.001118",
        "vapor_or_sublimation_pressure_kpa_U": "0.000119"
      },
      {
        "BLKpoint_id": "BLKpoint_75",
        "temperature_k": "294.96",
        "vapor_or_sublimation_pressure_kpa": "0.007922",
        "vapor_or_sublimation_pressure_kpa_U": "0.000327"
      },
      {
        "BLKpoint_id": "BLKpoint_88",
        "temperature_k": "317.19",
        "vapor_or_sublimation_pressure_kpa": "0.06259",
        "vapor_or_sublimation_pressure_kpa_U": "0.00135"
      },
      {
        "BLKpoint_id": "BLKpoint_97",
        "temperature_k": "335.27",
        "vapor_or_sublimation_pressure_kpa": "0.27226",
        "vapor_or_sublimation_pressure_kpa_U": "0.00399"
      },
      {
        "BLKpoint_id": "BLKpoint_102",
        "temperature_k": "339.09",
        "vapor_or_sublimation_pressure_kpa": "0.36276",
        "vapor_or_sublimation_pressure_kpa_U": "0.0051"
      }
    ],
    "inspection_id": "INSP_39c4917c80c8",
    "lit_num_id": "GLOBlit_6949"
  },
  {
    "doi": "10.1016/j.tca.2018.07.026",
    "block_number": "PROPblock_7",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "288.2",
        "vapor_or_sublimation_pressure_kpa": "0.00418",
        "vapor_or_sublimation_pressure_kpa_U": "0.00021"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "290.7",
        "vapor_or_sublimation_pressure_kpa": "0.00548",
        "vapor_or_sublimation_pressure_kpa_U": "0.00028"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "293.2",
        "vapor_or_sublimation_pressure_kpa": "0.00698",
        "vapor_or_sublimation_pressure_kpa_U": "0.00035"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "298.2",
        "vapor_or_sublimation_pressure_kpa": "0.01114",
        "vapor_or_sublimation_pressure_kpa_U": "0.00054"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "303.2",
        "vapor_or_sublimation_pressure_kpa": "0.01811",
        "vapor_or_sublimation_pressure_kpa_U": "0.00088"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "308",
        "vapor_or_sublimation_pressure_kpa": "0.02903",
        "vapor_or_sublimation_pressure_kpa_U": "0.00138"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "313.1",
        "vapor_or_sublimation_pressure_kpa": "0.04408",
        "vapor_or_sublimation_pressure_kpa_U": "0.00206"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "318.2",
        "vapor_or_sublimation_pressure_kpa": "0.0671",
        "vapor_or_sublimation_pressure_kpa_U": "0.00314"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "323.1",
        "vapor_or_sublimation_pressure_kpa": "0.102",
        "vapor_or_sublimation_pressure_kpa_U": "0.00476"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "328.1",
        "vapor_or_sublimation_pressure_kpa": "0.1538",
        "vapor_or_sublimation_pressure_kpa_U": "0.00705"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "330.5",
        "vapor_or_sublimation_pressure_kpa": "0.18668",
        "vapor_or_sublimation_pressure_kpa_U": "0.00858"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "333",
        "vapor_or_sublimation_pressure_kpa": "0.22352",
        "vapor_or_sublimation_pressure_kpa_U": "0.01013"
      }
    ],
    "inspection_id": "INSP_d57a49c4afe9",
    "lit_num_id": "GLOBlit_6449"
  },
  {
    "doi": "10.1016/j.fluid.2014.11.026",
    "block_number": "PROPblock_5",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "297.72",
        "vapor_or_sublimation_pressure_kpa": "0.01042",
        "vapor_or_sublimation_pressure_kpa_U": "0.00045"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "302.47",
        "vapor_or_sublimation_pressure_kpa": "0.01651",
        "vapor_or_sublimation_pressure_kpa_U": "0.0006"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "307.27",
        "vapor_or_sublimation_pressure_kpa": "0.02598",
        "vapor_or_sublimation_pressure_kpa_U": "0.00078"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "312.35",
        "vapor_or_sublimation_pressure_kpa": "0.04107",
        "vapor_or_sublimation_pressure_kpa_U": "0.00107"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "314.78",
        "vapor_or_sublimation_pressure_kpa": "0.05102",
        "vapor_or_sublimation_pressure_kpa_U": "0.00126"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "317.21",
        "vapor_or_sublimation_pressure_kpa": "0.06281",
        "vapor_or_sublimation_pressure_kpa_U": "0.00148"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "319.66",
        "vapor_or_sublimation_pressure_kpa": "0.0774",
        "vapor_or_sublimation_pressure_kpa_U": "0.00176"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "322.08",
        "vapor_or_sublimation_pressure_kpa": "0.0949",
        "vapor_or_sublimation_pressure_kpa_U": "0.00209"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "324.51",
        "vapor_or_sublimation_pressure_kpa": "0.1161",
        "vapor_or_sublimation_pressure_kpa_U": "0.0025"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "temperature_k": "326.97",
        "vapor_or_sublimation_pressure_kpa": "0.1415",
        "vapor_or_sublimation_pressure_kpa_U": "0.0027"
      }
    ],
    "inspection_id": "INSP_ae9904ad9a25",
    "lit_num_id": "GLOBlit_1600"
  },
  {
    "doi": "10.1021/acs.jced.5b00752",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "312.203",
        "vapor_or_sublimation_pressure_kpa": "0.04084",
        "vapor_or_sublimation_pressure_kpa_U": "0.00113"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "312.205",
        "vapor_or_sublimation_pressure_kpa": "0.04083",
        "vapor_or_sublimation_pressure_kpa_U": "0.00113"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "317.21",
        "vapor_or_sublimation_pressure_kpa": "0.06326",
        "vapor_or_sublimation_pressure_kpa_U": "0.00149"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "322.21",
        "vapor_or_sublimation_pressure_kpa": "0.09622",
        "vapor_or_sublimation_pressure_kpa_U": "0.00202"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "327.211",
        "vapor_or_sublimation_pressure_kpa": "0.14465",
        "vapor_or_sublimation_pressure_kpa_U": "0.0025"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "332.21",
        "vapor_or_sublimation_pressure_kpa": "0.21532",
        "vapor_or_sublimation_pressure_kpa_U": "0.00324"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "337.206",
        "vapor_or_sublimation_pressure_kpa": "0.31504",
        "vapor_or_sublimation_pressure_kpa_U": "0.0043"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "337.207",
        "vapor_or_sublimation_pressure_kpa": "0.31543",
        "vapor_or_sublimation_pressure_kpa_U": "0.00431"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "342.185",
        "vapor_or_sublimation_pressure_kpa": "0.45565",
        "vapor_or_sublimation_pressure_kpa_U": "0.0058"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "347.186",
        "vapor_or_sublimation_pressure_kpa": "0.65104",
        "vapor_or_sublimation_pressure_kpa_U": "0.00791"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "347.187",
        "vapor_or_sublimation_pressure_kpa": "0.65096",
        "vapor_or_sublimation_pressure_kpa_U": "0.00791"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "352.194",
        "vapor_or_sublimation_pressure_kpa": "0.92131",
        "vapor_or_sublimation_pressure_kpa_U": "0.01078"
      }
    ],
    "inspection_id": "INSP_0f47f726d28e",
    "lit_num_id": "GLOBlit_6709"
  },
  {
    "doi": "10.1021/acs.jced.6b00523",
    "block_number": "PROPblock_2",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "355.35",
        "vapor_or_sublimation_pressure_kpa": "1.098",
        "vapor_or_sublimation_pressure_kpa_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "355.35",
        "vapor_or_sublimation_pressure_kpa": "1.0981",
        "vapor_or_sublimation_pressure_kpa_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "355.35",
        "vapor_or_sublimation_pressure_kpa": "1.0982",
        "vapor_or_sublimation_pressure_kpa_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "358.34",
        "vapor_or_sublimation_pressure_kpa": "1.2662",
        "vapor_or_sublimation_pressure_kpa_U": "0.0161"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "358.36",
        "vapor_or_sublimation_pressure_kpa": "1.267",
        "vapor_or_sublimation_pressure_kpa_U": "0.0162"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "358.38",
        "vapor_or_sublimation_pressure_kpa": "1.2686",
        "vapor_or_sublimation_pressure_kpa_U": "0.0162"
      }
    ],
    "inspection_id": "INSP_292837b5aea1",
    "lit_num_id": "GLOBlit_6949"
  },
  {
    "doi": "10.1021/acs.jced.5b00752",
    "block_number": "PROPblock_2",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "357.19",
        "vapor_or_sublimation_pressure_kpa": "1.2003",
        "vapor_or_sublimation_pressure_kpa_U": "0.0138"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "387.232",
        "vapor_or_sublimation_pressure_kpa": "4.4749",
        "vapor_or_sublimation_pressure_kpa_U": "0.0384"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "402.368",
        "vapor_or_sublimation_pressure_kpa": "7.9615",
        "vapor_or_sublimation_pressure_kpa_U": "0.0665"
      },
      {
        "BLKpoint_id": "BLKpoint_20",
        "temperature_k": "412.397",
        "vapor_or_sublimation_pressure_kpa": "11.329",
        "vapor_or_sublimation_pressure_kpa_U": "0.094"
      },
      {
        "BLKpoint_id": "BLKpoint_21",
        "temperature_k": "422.548",
        "vapor_or_sublimation_pressure_kpa": "15.876",
        "vapor_or_sublimation_pressure_kpa_U": "0.131"
      },
      {
        "BLKpoint_id": "BLKpoint_22",
        "temperature_k": "432.579",
        "vapor_or_sublimation_pressure_kpa": "21.747",
        "vapor_or_sublimation_pressure_kpa_U": "0.179"
      },
      {
        "BLKpoint_id": "BLKpoint_23",
        "temperature_k": "442.461",
        "vapor_or_sublimation_pressure_kpa": "29.184",
        "vapor_or_sublimation_pressure_kpa_U": "0.239"
      },
      {
        "BLKpoint_id": "BLKpoint_24",
        "temperature_k": "452.367",
        "vapor_or_sublimation_pressure_kpa": "38.569",
        "vapor_or_sublimation_pressure_kpa_U": "0.315"
      }
    ],
    "inspection_id": "INSP_3ab4f2fcfdf2",
    "lit_num_id": "GLOBlit_6709"
  },
  {
    "doi": "10.1016/j.fluid.2010.09.006",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "351.4",
        "vapor_or_sublimation_pressure_kpa": "100",
        "vapor_or_sublimation_pressure_kpa_U": ""
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "345.7",
        "vapor_or_sublimation_pressure_kpa": "3000",
        "vapor_or_sublimation_pressure_kpa_U": ""
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "341.4",
        "vapor_or_sublimation_pressure_kpa": "6000",
        "vapor_or_sublimation_pressure_kpa_U": ""
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "337.8",
        "vapor_or_sublimation_pressure_kpa": "8000",
        "vapor_or_sublimation_pressure_kpa_U": ""
      }
    ],
    "inspection_id": "INSP_ea2ef03f33fe",
    "lit_num_id": "GLOBlit_882"
  }
]
```
