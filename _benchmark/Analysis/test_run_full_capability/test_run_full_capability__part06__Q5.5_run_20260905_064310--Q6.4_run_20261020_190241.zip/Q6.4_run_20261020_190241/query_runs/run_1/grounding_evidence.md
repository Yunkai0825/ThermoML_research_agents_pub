# Data grounding evidence

- generated: 2026-10-20T19:23:47
- gate verdict: 3 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | GLOBlit_8678 | yes | INSP_2a902459c15d, INSP_34ea4fc455a4, INSP_39c4917c80c8, INSP_0f47f726d28e, INSP_ea2ef03f33fe | 75 |
| PROPblock_2 | GLOBlit_6949 | yes | INSP_292837b5aea1, INSP_3ab4f2fcfdf2 | 6 |
| PROPblock_5 | GLOBlit_1600 | yes | INSP_ae9904ad9a25 | 13 |
| PROPblock_7 | GLOBlit_6449 | yes | INSP_d57a49c4afe9 | 12 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 75 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | ungrounded | — |
| 258.48 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 313.52 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.00011 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.0455 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 80 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 262.24 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 323.24 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.000181 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.1059 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 102 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 276.72 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 352.18 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.001118 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.91956 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 288.2 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 333.0 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.00418 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.22352 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 13 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 297.72 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 326.97 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.01042 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.1415 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 312.203 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 352.194 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.04083 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 0.92131 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 337.8 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 351.4 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 100 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 8000 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 355.35 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 358.38 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 1.098 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 1.2686 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 24 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 357.19 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 452.367 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 1.1997 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 38.569 | PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2 | verified | — |
| 102 | PROPblock_1 | misattributed | PROPblock_7 |
| 276.72 | PROPblock_1 | verified | — |
| 352.18 | PROPblock_1 | verified | — |
| 293.36 | PROPblock_1 | verified | — |
| 0.006861 | PROPblock_1 | verified | — |
| 308.22 | PROPblock_1 | verified | — |
| 0.02834 | PROPblock_1 | verified | — |
| 330.6 | PROPblock_1 | verified | — |
| 0.18866 | PROPblock_1 | verified | — |
| 352.18 | PROPblock_1 | verified | — |
| 0.91956 | PROPblock_1 | verified | — |
| 80 | PROPblock_1 | verified | — |
| 262.24 | PROPblock_1 | verified | — |
| 323.24 | PROPblock_1 | verified | — |
| 262.24 | PROPblock_1 | verified | — |
| 0.000182 | PROPblock_1 | verified | — |
| 293.18 | PROPblock_1 | verified | — |
| 0.006699 | PROPblock_1 | verified | — |
| 323.24 | PROPblock_1 | verified | — |
| 0.1059 | PROPblock_1 | verified | — |
| 75 | PROPblock_1 | ungrounded | — |
| 258.48 | PROPblock_1 | verified | — |
| 313.52 | PROPblock_1 | verified | — |
| 258.48 | PROPblock_1 | verified | — |
| 0.00011 | PROPblock_1 | verified | — |
| 293.49 | PROPblock_1 | verified | — |
| 0.00688 | PROPblock_1 | verified | — |
| 313.52 | PROPblock_1 | verified | — |
| 0.0455 | PROPblock_1 | verified | — |
| 351.4 | PROPblock_1 | verified | — |
| 100 | PROPblock_1 | verified | — |
| 345.7 | PROPblock_1 | verified | — |
| 3000 | PROPblock_1 | verified | — |
| 341.4 | PROPblock_1 | verified | — |
| 6000 | PROPblock_1 | verified | — |
| 337.8 | PROPblock_1 | verified | — |
| 8000 | PROPblock_1 | verified | — |
| 24 | PROPblock_2 | verified | — |
| 357.19 | PROPblock_2 | verified | — |
| 452.367 | PROPblock_2 | verified | — |

## Violations

- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2: 75 (near '…-------|--------| | 1 |   |   |   | Crystal (sublimation) | …') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2
- **MISATTRIBUTED_VALUE** PROPblock_1: 102 does not belong to PROPblock_1; it matches only GLOBlit_6449::PROPblock_7 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_1: 75 (near '…, DOI  ) has **75 points** at the lowest temperatures (25…') matches no inspected row/stat, database table, or other source of PROPblock_1

## Inspections (verbatim)

### INSP_2a902459c15d — GLOBlit_8678::PROPblock_1 (rdp, 23 rows shown)

_structured envelope entry (no markdown)_

### INSP_34ea4fc455a4 — GLOBlit_8810::PROPblock_1 (rdp, 10 rows shown)

_structured envelope entry (no markdown)_

### INSP_39c4917c80c8 — GLOBlit_6949::PROPblock_1 (rdp, 15 rows shown)

_structured envelope entry (no markdown)_

### INSP_d57a49c4afe9 — GLOBlit_6449::PROPblock_7 (complete, 12 rows shown)

_structured envelope entry (no markdown)_

### INSP_ae9904ad9a25 — GLOBlit_1600::PROPblock_5 (rdp, 10 rows shown)

_structured envelope entry (no markdown)_

### INSP_0f47f726d28e — GLOBlit_6709::PROPblock_1 (complete, 12 rows shown)

_structured envelope entry (no markdown)_

### INSP_292837b5aea1 — GLOBlit_6949::PROPblock_2 (complete, 6 rows shown)

_structured envelope entry (no markdown)_

### INSP_3ab4f2fcfdf2 — GLOBlit_6709::PROPblock_2 (rdp, 8 rows shown)

_structured envelope entry (no markdown)_

### INSP_ea2ef03f33fe — GLOBlit_882::PROPblock_1 (complete, 4 rows shown)

_structured envelope entry (no markdown)_
