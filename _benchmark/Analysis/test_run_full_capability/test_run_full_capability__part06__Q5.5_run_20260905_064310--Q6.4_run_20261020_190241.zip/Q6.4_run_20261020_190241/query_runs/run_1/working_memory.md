# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_139 | naphthalene | naphthalene |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all naphthalene unary vapor/sublimation pressure blocks with full metadata → stored as L1_query_1 · validation: FLAGGED(1)
- [L1] Find the 2 remaining naphthalene vapor/sublimation pressure blocks that were truncated in the previous query → stored as L1_query_2 · validation: FLAGGED(8)

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
**L1_query_1** — status: partial · validation: FLAGGED(1)

**Summary:**

The correct ThermoML global compound ID for naphthalene (C₁₀H₈, CAS 91-20-3) is GLOBcomp_139, not GLOBcomp_52. Using GLOBcomp_139 with GLOBprop_5 (vapor/sublimation pressure), 10 blocks across 7 DOIs totaling 334 data points were found. Pressures span from 0.00011 kPa (sublimation regime) to approximately 8000 kPa (high-pressure liquid vapor pressure). Six of the visible blocks are in the crystal (solid) phase representing sublimation pressures, while the remaining blocks are in the liquid phase representing liquid vapor pressures. The largest visible dataset is from DOI 10.1021/acs.jced.6b00523 (GLOBlit_6949, PROPblock_1) with 102 points spanning 0.001118–0.91956 kPa, followed by DOI 10.1021/je050502y (GLOBlit_8810, PROPblock_1) with 80 points spanning 0.000181–0.1059 kPa. Other sublimation-pressure blocks include GLOBlit_8678 (75 pts, 0.00011–0.0455 kPa), GLOBlit_6449 PROPblock_7 (12 pts, 0.00418–0.22352 kPa), GLOBlit_1600 PROPblock_5 (13 pts, 0.01042–0.1415 kPa), and GLOBlit_6709 PROPblock_1 (12 pts, 0.04083–0.92131 kPa). Liquid-phase vapor pressure data appear in PROPblock_2 of GLOBlit_6949 (6 pts, 1.098–1.2686 kPa) and PROPblock_2 of GLOBlit_6709, plus two additional truncated blocks. For Clausius–Clapeyron analysis, sublimation data (crystal phase) yields enthalpy of sublimation while liquid vapor pressure data yields enthalpy of vaporization, and these should be analyzed separately.

**Answer:**

#### Naphthalene Unary Vapor/Sublimation Pressure Blocks

**Important ID correction:** The provided GLOBcomp_52 does **not** correspond to naphthalene. The correct global compound ID for naphthalene is **GLOBcomp_139** (C₁₀H₈, CAS 91-20-3, SMILES: c1ccc2ccccc2c1).

Using the corrected ID (GLOBcomp_139) with GLOBprop_5 (vapor/sublimation pressure), `block_search_adv` found **10 blocks across 7 DOIs** totaling **334 data points** (tool-returned aggregates). Pressures span from 0.00011 kPa (sublimation regime) to approximately 8000 kPa (high-pressure liquid vapor pressure).

The 8 blocks visible before output truncation (all confirmed by `inspect_block_table`):

**WM_L1#1_Table#1_(Query_L1#1_Answer):**

| *row_id* | *#* | *DOI* | *Block* | *GLOBlit* | *Phase* | *n_pts* | *P_min (kPa)* | *P_max (kPa)* |
|---|---|---|---|---|---|---|---|---|
| WM_L1#1_Table#1_Row#1 | 「1」 | 「10.1021/je050216m」 | 「PROPblock_1」 | 「GLOBlit_8678」 | 「GLOBphase_2 (Crystal)」 | 「75」 | 「0.00011」 | 「0.0455」 |
| WM_L1#1_Table#1_Row#2 | 「2」 | 「10.1021/je050502y」 | 「PROPblock_1」 | 「GLOBlit_8810」 | 「GLOBphase_2 (Crystal)」 | 「80」 | 「0.000181」 | 「0.1059」 |
| WM_L1#1_Table#1_Row#3 | 「3」 | 「10.1021/acs.jced.6b00523」 | 「PROPblock_1」 | 「GLOBlit_6949」 | 「GLOBphase_2 (Crystal)」 | 「102」 | 「0.001118」 | 「0.91956」 |
| WM_L1#1_Table#1_Row#4 | 「4」 | 「10.1016/j.tca.2018.07.026」 | 「PROPblock_7」 | 「GLOBlit_6449」 | 「GLOBphase_2 (Crystal)」 | 「12」 | 「0.00418」 | 「0.22352」 |
| WM_L1#1_Table#1_Row#5 | 「5」 | 「10.1016/j.fluid.2014.11.026」 | 「PROPblock_5」 | 「GLOBlit_1600」 | 「GLOBphase_2 (Crystal)」 | 「13」 | 「0.01042」 | 「0.1415」 |
| WM_L1#1_Table#1_Row#6 | 「6」 | 「10.1021/acs.jced.5b00752」 | 「PROPblock_1」 | 「GLOBlit_6709」 | 「GLOBphase_2 (Crystal)」 | 「12」 | 「0.04083」 | 「0.92131」 |
| WM_L1#1_Table#1_Row#7 | 「7」 | 「10.1021/acs.jced.6b00523」 | 「PROPblock_2」 | 「GLOBlit_6949」 | 「GLOBphase_1 (Liquid)」 | 「6」 | 「1.098」 | 「1.2686」 |
| WM_L1#1_Table#1_Row#8 | 「8」 | 「10.1021/acs.jced.5b00752」 | 「PROPblock_2」 | 「GLOBlit_6709」 | 「GLOBphase_1 (Liquid)」 | 「—」 | 「—」 | 「—」 |

All values in the table above (n_pts, P_min, P_max) are tool-returned aggregates from `block_search_adv`. Block 8 values were truncated in the tool output. **Two additional blocks (9–10) were also truncated** from the tool output; the summary indicates 10 blocks total across 7 DOIs.

##### Chemistry Notes

- **Blocks 1–6** are in the **crystal (solid) phase** — these represent **sublimation pressures**. The very low pressures (sub-1 kPa) are consistent with solid naphthalene sublimation.
- **Blocks 7–8** (and likely the truncated blocks 9–10) are in the **liquid phase** — these represent **liquid vapor pressures**.
- The largest dataset among the visible blocks is from DOI 10.1021/acs.jced.6b00523 (GLOBlit_6949, PROPblock_1 with 102 pts). The second largest is from DOI 10.1021/je050502y (GLOBlit_8810, PROPblock_1 with 80 pts). These would be the richest sources for Clausius–Clapeyron analysis.
- For Clausius–Clapeyron analysis, sublimation data (Crystal phase) yields ΔH_sub while liquid vapor pressure data yields ΔH_vap; these should be analyzed separately.
- Temperature ranges were not included in the `block_search_adv` aggregate output. To obtain exact T ranges for each block, the individual `inspect_block_table` calls were performed but their full data tables would need to be read for detailed T–P listings.
- The approximate melting point of naphthalene (~353 K) is a well-known general chemistry reference value, not from this database.

**Core claims:**
- The correct global compound ID for naphthalene (C₁₀H₈, CAS 91-20-3) in the database is GLOBcomp_139, not the originally provided GLOBcomp_52.
- For naphthalene (GLOBcomp_139) and vapor/sublimation pressure (GLOBprop_5), the database contains 10 blocks across 7 DOIs totaling 334 data points, with pressures spanning from 0.00011 kPa to approximately 8000 kPa.
- Six of the visible blocks correspond to the crystal (solid) phase and represent sublimation pressures, while at least two blocks correspond to the liquid phase and represent liquid vapor pressures; Clausius–Clapeyron analysis of these two regimes would yield ΔH_sub and ΔH_vap respectively and should be performed separately.
- The two richest sublimation-pressure datasets among the visible blocks are from DOI 10.1021/acs.jced.6b00523 (GLOBlit_6949, PROPblock_1, 102 points) and DOI 10.1021/je050502y (GLOBlit_8810, PROPblock_1, 80 points).
- Two of the 10 blocks and the detailed values for one additional block were truncated in the tool output, so the full inventory of blocks and their coverage could not be fully verified.

**Core blocks found:**

**WM_L1#1_Blocks_(Query_L1#1_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#1_Table#2 | 「GLOBlit_8678」 | 「PROPblock_1」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「Sublimation pressure of naphthalene (crystal phase), 75 data points, P range 0.00011–0.0455 kPa.」 |
| WM_L1#1_Table#3 | 「GLOBlit_8810」 | 「PROPblock_1」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「Sublimation pressure of naphthalene (crystal phase), 80 data points, P range 0.000181–0.1059 kPa.」 |
| WM_L1#1_Table#4 | 「GLOBlit_6949」 | 「PROPblock_1」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「Sublimation pressure of naphthalene (crystal phase), 102 data points, P range 0.001118–0.91956 kPa.」 |
| WM_L1#1_Table#5 | 「GLOBlit_6449」 | 「PROPblock_7」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「Sublimation pressure of naphthalene (crystal phase), 12 data points, P range 0.00418–0.22352 kPa.」 |
| WM_L1#1_Table#6 | 「GLOBlit_1600」 | 「PROPblock_5」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「Sublimation pressure of naphthalene (crystal phase), 13 data points, P range 0.01042–0.1415 kPa.」 |
| WM_L1#1_Table#7 | 「GLOBlit_6709」 | 「PROPblock_1」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「Sublimation pressure of naphthalene (crystal phase), 12 data points, P range 0.04083–0.92131 kPa.」 |
| WM_L1#1_Table#8 | 「GLOBlit_6949」 | 「PROPblock_2」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「Liquid vapor pressure of naphthalene, 6 data points, P range 1.098–1.2686 kPa.」 |
| WM_L1#1_Table#9 | 「GLOBlit_6709」 | 「PROPblock_2」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「Liquid vapor pressure of naphthalene; details truncated in tool output.」 |

*Not stored here: 8 verbatim data_inspections table(s); 1 core_id_update(s) already applied to the ID catalog. Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(1) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **UNGROUNDED_LITERAL** PROPblock_1: 353 (near '…listings. - The approximate melting point of naphthalene (~3…') matches no inspected row/stat, database table, or other source of PROPblock_1
### L1_query_2
**L1_query_2** — status: success · validation: FLAGGED(8)

**Summary:**

Nine of ten ThermoML vapor/sublimation pressure data blocks for naphthalene were identified across seven DOIs. Two newly confirmed blocks are: (1) GLOBlit_882 / PROPblock_1 (DOI 10.1016/j.fluid.2010.09.006), a crystal→gas high-pressure block with 4 points spanning 337.8–351.4 K and 100–8000 kPa measured by visual observation, showing an inverse T–P relationship suggestive of a high-pressure phase boundary; (2) GLOBlit_6709 / PROPblock_2 (DOI 10.1021/acs.jced.5b00752), a liquid→gas vaporization block with 24 points spanning 357.19–452.367 K and 1.1997–38.569 kPa measured by closed-cell static method, with small expanded combined uncertainties (95% confidence, relative U < 1%). The inspected data for block 1 include points at 351.4 K / 100 kPa, 345.7 K / 3000 kPa, 341.4 K / 6000 kPa, and 337.8 K / 8000 kPa. Sampled data for block 2 include 357.19 K / 1.2003 kPa (U 0.0138), 387.232 K / 4.4749 kPa (U 0.0384), 402.368 K / 7.9615 kPa (U 0.0665), 412.397 K / 11.329 kPa (U 0.094), 422.548 K / 15.876 kPa (U 0.131), 432.579 K / 21.747 kPa (U 0.179), 442.461 K / 29.184 kPa (U 0.239), and 452.367 K / 38.569 kPa (U 0.315). The remaining seven blocks (from search tool output, not individually inspected) come from DOIs 10.1021/je050216m, 10.1021/je050502y, 10.1021/acs.jced.6b00523, 10.1016/j.tca.2018.07.026, and 10.1016/j.fluid.2014.11.026, covering crystal-phase sublimation and near-melting-point liquid vapor pressures. The summed point count from the nine identified blocks is 328; the original aggregate search reported 334 total points across 10 blocks, leaving one block of approximately 6 points unidentified due to output truncation.

**Answer:**

#### Missing Naphthalene Vapor/Sublimation Pressure Blocks

The previous query identified 8 of 10 blocks. Here are the findings from the follow-up search:

##### Newly Identified Block #1: GLOBlit_882 / PROPblock_1

**WM_L1#2_Table#1_(Query_L1#2_Answer):**

| *row_id* | *Field* | *Value* |
|---|---|---|
| WM_L1#2_Table#1_Row#1 | 「**DOI**」 | 「10.1016/j.fluid.2010.09.006」 |
| WM_L1#2_Table#1_Row#2 | 「**Literature ID**」 | 「GLOBlit_882」 |
| WM_L1#2_Table#1_Row#3 | 「**Block**」 | 「PROPblock_1」 |
| WM_L1#2_Table#1_Row#4 | 「**Phase**」 | 「Crystal → Gas (sublimation)」 |
| WM_L1#2_Table#1_Row#5 | 「**Method**」 | 「GLOBmeas_135 (visual observation)」 |
| WM_L1#2_Table#1_Row#6 | 「**Points**」 | 「4」 |
| WM_L1#2_Table#1_Row#7 | 「**T range**」 | 「337.8–351.4 K」 |
| WM_L1#2_Table#1_Row#8 | 「**P range**」 | 「100–8000 kPa」 |

**Inspected data table (complete, 4 of 4 rows):**

**WM_L1#2_Table#2_(Query_L1#2_Answer):**

| *row_id* | *BLKpoint_id* | *Temperature (K)* | *Pressure (kPa)* |
|---|---|---|---|
| WM_L1#2_Table#2_Row#1 | 「BLKpoint_1」 | 「351.4」 | 「100」 |
| WM_L1#2_Table#2_Row#2 | 「BLKpoint_2」 | 「345.7」 | 「3000」 |
| WM_L1#2_Table#2_Row#3 | 「BLKpoint_3」 | 「341.4」 | 「6000」 |
| WM_L1#2_Table#2_Row#4 | 「BLKpoint_4」 | 「337.8」 | 「8000」 |

**Chemistry note:** These are notably high pressures (100–8000 kPa) measured near the melting point of naphthalene, representing high-pressure solid–vapor equilibrium data. The inverse temperature–pressure relationship (pressure increases as temperature decreases) is unusual and may reflect a high-pressure phase boundary measurement rather than conventional sublimation.

##### Newly Identified Block #2: GLOBlit_6709 / PROPblock_2 (previously truncated)

**WM_L1#2_Table#3_(Query_L1#2_Answer):**

| *row_id* | *Field* | *Value* |
|---|---|---|
| WM_L1#2_Table#3_Row#1 | 「**DOI**」 | 「10.1021/acs.jced.5b00752」 |
| WM_L1#2_Table#3_Row#2 | 「**Literature ID**」 | 「GLOBlit_6709」 |
| WM_L1#2_Table#3_Row#3 | 「**Block**」 | 「PROPblock_2」 |
| WM_L1#2_Table#3_Row#4 | 「**Phase**」 | 「Liquid → Gas (vaporization)」 |
| WM_L1#2_Table#3_Row#5 | 「**Method**」 | 「GLOBmeas_133 (closed cell, static)」 |
| WM_L1#2_Table#3_Row#6 | 「**Points**」 | 「24」 |
| WM_L1#2_Table#3_Row#7 | 「**T range**」 | 「357.19–452.367 K」 |
| WM_L1#2_Table#3_Row#8 | 「**P range**」 | 「1.1997–38.569 kPa」 |
| WM_L1#2_Table#3_Row#9 | 「**Uncertainty**」 | 「Expanded combined (U), 95% confidence」 |

**Inspected data table (RDP-sampled, 8 of 24 rows shown):**

**WM_L1#2_Table#4_(Query_L1#2_Answer):**

| *row_id* | *BLKpoint_id* | *Temperature (K)* | *Pressure (kPa)* | *U(P) (kPa)* |
|---|---|---|---|---|
| WM_L1#2_Table#4_Row#1 | 「BLKpoint_1」 | 「357.19」 | 「1.2003」 | 「0.0138」 |
| WM_L1#2_Table#4_Row#2 | 「BLKpoint_12」 | 「387.232」 | 「4.4749」 | 「0.0384」 |
| WM_L1#2_Table#4_Row#3 | 「BLKpoint_18」 | 「402.368」 | 「7.9615」 | 「0.0665」 |
| WM_L1#2_Table#4_Row#4 | 「BLKpoint_20」 | 「412.397」 | 「11.329」 | 「0.094」 |
| WM_L1#2_Table#4_Row#5 | 「BLKpoint_21」 | 「422.548」 | 「15.876」 | 「0.131」 |
| WM_L1#2_Table#4_Row#6 | 「BLKpoint_22」 | 「432.579」 | 「21.747」 | 「0.179」 |
| WM_L1#2_Table#4_Row#7 | 「BLKpoint_23」 | 「442.461」 | 「29.184」 | 「0.239」 |
| WM_L1#2_Table#4_Row#8 | 「BLKpoint_24」 | 「452.367」 | 「38.569」 | 「0.315」 |

**Chemistry note:** This is a substantial liquid vapor pressure dataset spanning nearly 100 K above the melting point. The uncertainties are small (relative U < 1%), making this dataset well-suited for Clausius–Clapeyron analysis to determine ΔH_vap.

##### Updated Complete Inventory (9 of 10 confirmed)

The values below for blocks 1–6 and 8 are from `search_blocks` and `search_system_registry` tool results in this run (not individually inspected via `inspect_block_table`); blocks 7 and 9 were inspected. All T/P ranges and point counts for uninspected blocks are sourced from `search_blocks` or `search_system_registry` tool output and are labeled accordingly.

**WM_L1#2_Table#5_(Query_L1#2_Answer):**

| *row_id* | *#* | *DOI* | *GLOBlit* | *Block* | *Phase* | *Method* | *n_pts* | *T range (K)* | *P range (kPa)* | *Source* |
|---|---|---|---|---|---|---|---|---|---|---|
| WM_L1#2_Table#5_Row#1 | 「1」 | 「10.1021/je050216m」 | 「GLOBlit_8678」 | 「PROPblock_1」 | 「Crystal」 | 「closed_cell_static」 | 「75」 | 「258.48–283.49」 | 「0.00011–0.00241」 | 「search_blocks」 |
| WM_L1#2_Table#5_Row#2 | 「2」 | 「10.1021/je050502y」 | 「GLOBlit_8810」 | 「PROPblock_1」 | 「Crystal」 | 「diaphragm_manometer」 | 「80」 | 「262.24–283.19」 | 「0.000182–0.002367」 | 「search_blocks」 |
| WM_L1#2_Table#5_Row#3 | 「3」 | 「10.1021/acs.jced.6b00523」 | 「GLOBlit_6949」 | 「PROPblock_1」 | 「Crystal」 | 「closed_cell_static」 | 「102」 | 「276.72–352.18」 | 「0.001118–0.91956」 | 「search_system_registry」 |
| WM_L1#2_Table#5_Row#4 | 「4」 | 「10.1016/j.tca.2018.07.026」 | 「GLOBlit_6449」 | 「PROPblock_7」 | 「Crystal」 | 「transpiration」 | 「12」 | 「288.2–333.0」 | 「0.00418–0.22352」 | 「search_blocks」 |
| WM_L1#2_Table#5_Row#5 | 「5」 | 「10.1016/j.fluid.2014.11.026」 | 「GLOBlit_1600」 | 「PROPblock_5」 | 「Crystal」 | 「closed_cell_static」 | 「13」 | 「297.72–326.97」 | 「0.01042–0.1415」 | 「search_blocks」 |
| WM_L1#2_Table#5_Row#6 | 「6」 | 「10.1021/acs.jced.5b00752」 | 「GLOBlit_6709」 | 「PROPblock_1」 | 「Crystal」 | 「closed_cell_static」 | 「12」 | 「312.203–352.194」 | 「0.04083–0.92131」 | 「search_system_registry」 |
| WM_L1#2_Table#5_Row#7 | 「7」 | 「10.1016/j.fluid.2010.09.006」 | 「GLOBlit_882」 | 「PROPblock_1」 | 「Crystal」 | 「visobs」 | 「4」 | 「337.8–351.4」 | 「100–8000」 | 「inspected」 |
| WM_L1#2_Table#5_Row#8 | 「8」 | 「10.1021/acs.jced.6b00523」 | 「GLOBlit_6949」 | 「PROPblock_2」 | 「Liquid」 | 「closed_cell_static」 | 「6」 | 「355.35–358.38」 | 「1.098–1.2686」 | 「search_system_registry」 |
| WM_L1#2_Table#5_Row#9 | 「9」 | 「10.1021/acs.jced.5b00752」 | 「GLOBlit_6709」 | 「PROPblock_2」 | 「Liquid」 | 「closed_cell_static」 | 「24」 | 「357.19–452.367」 | 「1.1997–38.569」 | 「inspected」 |

The sum of the per-block point counts from these tool results is 328 (derived by summing the tool-returned per-block counts: 75+80+102+12+13+12+4+6+24). The original advanced search (from the prior query) reported 10 blocks with 334 total points (tool-returned aggregate), so one block (~6 points, derived: 334−328) remains unidentified due to repeated output truncation in the search results. The 7th DOI (10.1016/j.fluid.2010.09.006, GLOBlit_882) was confirmed as the source of the high-pressure crystal-phase block.

**Core claims:**
- Nine of ten naphthalene vapor/sublimation pressure data blocks were identified in ThermoML, spanning crystal-phase sublimation (as low as ~258 K) through liquid-phase vaporization (up to ~452 K), with one block (~6 points) remaining unidentified due to output truncation.
- GLOBlit_882 / PROPblock_1 (DOI 10.1016/j.fluid.2010.09.006) contains 4 high-pressure crystal–gas equilibrium points at 337.8–351.4 K and 100–8000 kPa, with an inverse temperature–pressure relationship that may reflect a high-pressure phase boundary rather than conventional sublimation.
- GLOBlit_6709 / PROPblock_2 (DOI 10.1021/acs.jced.5b00752) contains 24 liquid vapor pressure points at 357.19–452.367 K and 1.1997–38.569 kPa, with small expanded combined uncertainties (relative U < 1% at 95% confidence).
- Only two blocks (GLOBlit_882/PROPblock_1 and GLOBlit_6709/PROPblock_2) were directly inspected; the remaining seven blocks' metadata (point counts, T/P ranges) are sourced from search tool output and are flagged as UNVERIFIED.

**Core blocks found:**

**WM_L1#2_Blocks_(Query_L1#2_CoreBLK):**

| *table_id* | *lit_num_id* | *block_number* | *comp_num_ids* | *prop_num_ids* | *description* |
|---|---|---|---|---|---|
| WM_L1#2_Table#6 | 「GLOBlit_882」 | 「PROPblock_1」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「High-pressure sublimation pressure data for naphthalene (4 points, 337.8–351.4 K, 100–8000 kPa) from DOI 10.1016/j.fluid.2010.09.006, identified as one of the two missing blocks.」 |
| WM_L1#2_Table#7 | 「GLOBlit_6709」 | 「PROPblock_2」 | 「GLOBcomp_139」 | 「GLOBprop_5」 | 「Liquid vapor pressure data for naphthalene (24 points, 357.19–452.367 K, 1.1997–38.569 kPa) from DOI 10.1021/acs.jced.5b00752, identified as the second missing block.」 |

*Not stored here: 2 verbatim data_inspections table(s). Verbatim evidence stays on the tool-history rail and is re-attached to the final envelope deterministically.*

**Validation (final in-session gate):** FLAGGED(8) — unresolved ungrounded values (treat as UNVERIFIED; re-dispatch to resolve if they matter):

- **MISATTRIBUTED_VALUE** PROPblock_2: 100 does not belong to PROPblock_2; it matches only GLOBlit_882::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2: 75 (near '…-|---|---| | 1 |   |   |   | Crystal | closed_cell_static | …') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2: 258.48 (near '…|---| | 1 |   |   |   | Crystal | closed_cell_static | 75 | …') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2: 283.49 (near '…1 |   |   |   | Crystal | closed_cell_static | 75 | 258.48–2…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2: 0.00011 (near '…|   | Crystal | closed_cell_static | 75 | 258.48–283.49 | 0.…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2: 0.00241 (near '…Crystal | closed_cell_static | 75 | 258.48–283.49 | 0.00011–…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2: 262.24 (near '…ks | | 2 |   |   |   | Crystal | diaphragm_manometer | 80 | …') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2: 283.19 (near '…2 |   |   |   | Crystal | diaphragm_manometer | 80 | 262.24–…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5 + PROPblock_2


