# Reference Stats — analysis-agent

**Run started:** 2026-10-20 19:02:41
**Wall time (at last flush):** 1,493.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 14 | 235,289 | 215,787 | 58,039 | 451,076 | 32,219 | 333.5 | claudeopus46 |
| L1-worker | 29 | 356,510 | 139,241 | 37,462 | 495,751 | 17,094 | 260.7 | claudeopus46 |
| **TOTAL** | **43** | **591,799** | **355,028** | **95,501** | **946,827** | **22,019** | **594.2** | |

**Estimated tokens:** ~236,706 input + ~23,875 output = ~260,581 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 1 | 20 | 20 | 111 |
| `inspect_block_table` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 1 | 1 | 0 |
| `resolve_property_ids` | 0 | 10 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 9 | 2 | 3 | 24 | 50 | 477 |
| `search_system_summary` | 11 | 0 | 0 | 0 | 155 | 597 | 19,744 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agent` | 0 | 0 | 0 | 0 | 7 | 9 | 0 |
| **TOTAL** | **13** | **20** | **3** | **4** | **207** | **677** | **20,332** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Phases (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_2 |  | resolve_ids |
| GLOBphase_1 |  | resolve_ids, search_blocks |
| GLOBphase_17 |  | resolve_ids |
| GLOBphase_27 |  | resolve_ids |

#### References (52 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_230 |  | search_blocks |
| GLOBlit_273 |  | search_blocks |
| GLOBlit_328 |  | search_blocks |
| GLOBlit_331 |  | search_blocks |
| GLOBlit_490 |  | search_blocks |
| GLOBlit_497 |  | search_blocks |
| GLOBlit_567 |  | search_blocks |
| GLOBlit_619 |  | search_blocks |
| GLOBlit_635 |  | search_blocks, search_system_summary |
| GLOBlit_973 |  | search_blocks, search_system_summary |
| GLOBlit_1218 |  | search_blocks, search_system_summary |
| GLOBlit_1229 |  | search_blocks |
| GLOBlit_2577 |  | search_blocks |
| GLOBlit_2697 |  | search_blocks |
| GLOBlit_8199 |  | search_blocks |
| GLOBlit_8712 |  | search_blocks |
| GLOBlit_9995 |  | query_thermoml, search_blocks |
| GLOBlit_11195 |  | search_blocks |
| GLOBlit_11496 |  | search_blocks |
| GLOBlit_11877 |  | search_blocks |
| GLOBlit_54 |  | search_blocks |
| GLOBlit_97 |  | search_blocks, search_system_summary |
| GLOBlit_418 |  | search_blocks |
| GLOBlit_623 |  | search_blocks |
| GLOBlit_642 |  | search_blocks, search_system_summary |
| GLOBlit_678 |  | search_blocks |
| GLOBlit_1013 |  | search_blocks |
| GLOBlit_1553 |  | search_blocks, search_system_summary |
| GLOBlit_1671 |  | search_blocks |
| GLOBlit_1748 |  | search_blocks |
| GLOBlit_1879 |  | search_blocks |
| GLOBlit_2070 |  | search_blocks, search_system_summary |
| GLOBlit_4850 |  | search_system_summary |
| GLOBlit_5304 |  | search_system_summary |
| GLOBlit_9305 |  | search_system_summary |
| GLOBlit_2187 |  | search_system_summary |
| GLOBlit_5052 |  | search_system_summary |
| GLOBlit_7260 |  | search_system_summary |
| GLOBlit_8744 |  | search_system_summary |
| GLOBlit_8578 |  | search_system_summary |
| GLOBlit_4812 |  | search_system_summary |
| GLOBlit_11529 |  | search_system_summary |
| GLOBlit_10944 |  | search_system_summary |
| GLOBlit_5664 |  | search_system_summary |
| GLOBlit_3763 |  | search_system_summary |
| GLOBlit_8678 |  | run_query_agent |
| GLOBlit_8810 |  | run_query_agent |
| GLOBlit_6949 |  | run_query_agent |
| GLOBlit_6449 |  | run_query_agent |
| GLOBlit_1600 |  | run_query_agent |
| GLOBlit_6709 |  | run_query_agent |
| GLOBlit_882 |  | run_query_agent |

#### Compounds (11 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_52 | diisopropyl ether | search_blocks, search_system_summary |
| GLOBcomp_1 | water | search_system_summary |
| GLOBcomp_6 | propan-2-ol | search_system_summary |
| GLOBcomp_37 | 2,2,4-trimethylpentane | search_system_summary |
| GLOBcomp_2 | ethanol | search_system_summary |
| GLOBcomp_5 | propan-1-ol | search_system_summary |
| GLOBcomp_4 | methanol | search_system_summary |
| GLOBcomp_14 | benzene | search_system_summary |
| GLOBcomp_149 | anthracene | search_system_summary |
| GLOBcomp_11 | heptane | search_system_summary |
| GLOBcomp_13 | cyclohexane | search_system_summary |

#### Properties (19 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBprop_19 |  | resolve_property_ids |
| GLOBprop_15 |  | resolve_property_ids |
| GLOBprop_36 |  | resolve_property_ids |
| GLOBprop_46 |  | resolve_property_ids |
| GLOBprop_22 |  | resolve_property_ids |
| GLOBprop_10 |  | resolve_property_ids |
| GLOBprop_110 |  | resolve_property_ids |
| GLOBprop_86 |  | resolve_property_ids |
| GLOBprop_75 |  | resolve_property_ids |
| GLOBprop_90 |  | resolve_property_ids |
| GLOBprop_40 | Kinematic viscosity, m2/s | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |
| GLOBprop_26 | Normal boiling temperature, K | search_blocks |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBprop_14 | Boiling temperature at pressure P, K | search_blocks |
| GLOBprop_8 | Speed of sound, m/s | search_blocks |

#### Measurements (20 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_146 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_155 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_164 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_161 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_5 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_76 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_159 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_4 | Kinematic viscosity, m2/s | search_blocks |
| GLOBmeas_143 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_153 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_203 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_19 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_36 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_391 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_20 | Speed of sound, m/s | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_4 | Frequency, MHz | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Phases | 4 |
| Unique References | 52 |
| Unique Compounds | 11 |
| Unique Properties | 19 |
| Unique Measurements | 20 |
| Unique Variables | 2 |
| Unique Constraints | 3 |
| Total DOIs | 39 |
| Unique parent blocks | 67 |
| Explicit block/subsystem targets | 67 |
| Subsystem targets | 0 |
| Target-matched data points | 588 |

---

## 3. DOI & Block References

**Unique DOIs:** 39  |  **Parent blocks:** 67  |  **Explicit targets:** 67  |  **Subsystems:** 0  |  **Target-matched datapoints:** 515

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-007-0346-0 | 1 | 3 | unary | search_blocks |
| 10.1007/s10765-010-0737-5 | 2 | 14 | unary | search_blocks |
| 10.1016/j.fluid.2004.12.007 | 2 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2005.05.024 | 2 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2005.11.014 | 1 | 4 | unary | search_blocks |
| 10.1016/j.fluid.2005.11.017 | 1 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2006.08.004 | 3 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2007.02.026 | 3 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2007.03.017 | 1 | 9 | unary | search_blocks |
| 10.1016/j.fluid.2007.09.014 | 3 | 4 | unary | search_blocks |
| 10.1016/j.fluid.2008.03.015 | 1 | 16 | unary | search_blocks |
| 10.1016/j.fluid.2008.04.010 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2008.06.006 | 4 | 14 | unary | search_blocks |
| 10.1016/j.fluid.2008.06.019 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2008.11.014 | 2 | 2 | unary | search_blocks |
| 10.1016/j.fluid.2010.09.006 | 1 | 0 | — | run_query_agent |
| 10.1016/j.fluid.2011.06.001 | 1 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2011.09.014 | 3 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2013.01.020 | 3 | 5 | unary | search_blocks |
| 10.1016/j.fluid.2013.02.005 | 5 | 23 | unary | search_blocks |
| 10.1016/j.fluid.2014.09.014 | 2 | 2 | unary | search_blocks |
| 10.1016/j.fluid.2014.11.026 | 1 | 0 | — | run_query_agent |
| 10.1016/j.fluid.2015.03.040 | 3 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2015.07.023 | 2 | 2 | unary | search_blocks |
| 10.1016/j.fluid.2016.02.009 | 1 | 154 | unary | search_blocks |
| 10.1016/j.fluid.2017.06.024 | 2 | 199 | unary | search_blocks |
| 10.1016/j.jct.2005.07.004 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2006.05.007 | 1 | 9 | unary | search_blocks |
| 10.1016/j.tca.2018.07.026 | 1 | 0 | — | run_query_agent |
| 10.1021/acs.jced.5b00752 | 2 | 0 | — | run_query_agent |
| 10.1021/acs.jced.6b00523 | 2 | 0 | — | run_query_agent |
| 10.1021/je030238d | 1 | 1 | unary | search_blocks |
| 10.1021/je050216m | 1 | 0 | — | run_query_agent |
| 10.1021/je0502896 | 1 | 3 | unary | search_blocks |
| 10.1021/je050502y | 1 | 0 | — | run_query_agent |
| 10.1021/je300994y | 1 | 18 | unary | query_thermoml, search_blocks |
| 10.1021/je800298n | 1 | 1 | unary | search_blocks |
| 10.1021/je900042q | 1 | 1 | unary | search_blocks |
| 10.1021/je900977e | 1 | 2 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-007-0346-0 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1007/s10765-010-0737-5 | PROPblock_7 | declared | 7 | unary | — | search_blocks |
| 10.1007/s10765-010-0737-5 | PROPblock_8 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.fluid.2004.12.007 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2004.12.007 | PROPblock_6 | declared | 2 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.05.024 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.05.024 | PROPblock_4 | declared | 2 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.11.014 | PROPblock_1 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.11.017 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.08.004 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.08.004 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.08.004 | PROPblock_9 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.02.026 | PROPblock_13 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.02.026 | PROPblock_14 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.02.026 | PROPblock_15 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.03.017 | PROPblock_1 | declared | 9 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.09.014 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.09.014 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.09.014 | PROPblock_3 | declared | 2 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.03.015 | PROPblock_3 | declared | 16 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.04.010 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.06.006 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.06.006 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.06.006 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.06.006 | PROPblock_8 | declared | 11 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.06.019 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.11.014 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2008.11.014 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2010.09.006 | PROPblock_1 | declared | 0 | — | — | run_query_agent |
| 10.1016/j.fluid.2011.06.001 | PROPblock_4 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2011.09.014 | PROPblock_13 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2011.09.014 | PROPblock_14 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2011.09.014 | PROPblock_15 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2013.01.020 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2013.01.020 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2013.01.020 | PROPblock_6 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2013.02.005 | PROPblock_10 | declared | 17 | unary | — | search_blocks |
| 10.1016/j.fluid.2013.02.005 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2013.02.005 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2013.02.005 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2013.02.005 | PROPblock_9 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2014.09.014 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2014.09.014 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2014.11.026 | PROPblock_5 | declared | 0 | — | — | run_query_agent |
| 10.1016/j.fluid.2015.03.040 | PROPblock_28 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2015.03.040 | PROPblock_29 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2015.03.040 | PROPblock_30 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2015.07.023 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2015.07.023 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2016.02.009 | PROPblock_6 | declared | 154 | unary | — | search_blocks |
| 10.1016/j.fluid.2017.06.024 | PROPblock_1 | declared | 40 | unary | — | search_blocks |
| 10.1016/j.fluid.2017.06.024 | PROPblock_2 | declared | 159 | unary | — | search_blocks |
| 10.1016/j.jct.2005.07.004 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.05.007 | PROPblock_1 | declared | 9 | unary | — | search_blocks |
| 10.1016/j.tca.2018.07.026 | PROPblock_7 | declared | 0 | — | — | run_query_agent |
| 10.1021/acs.jced.5b00752 | PROPblock_1 | declared | 0 | — | — | run_query_agent |
| 10.1021/acs.jced.5b00752 | PROPblock_2 | declared | 0 | — | — | run_query_agent |
| 10.1021/acs.jced.6b00523 | PROPblock_1 | declared | 0 | — | — | run_query_agent |
| 10.1021/acs.jced.6b00523 | PROPblock_2 | declared | 0 | — | — | run_query_agent |
| 10.1021/je030238d | PROPblock_9 | declared | 1 | unary | — | search_blocks |
| 10.1021/je050216m | PROPblock_1 | declared | 0 | — | — | run_query_agent |
| 10.1021/je0502896 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1021/je050502y | PROPblock_1 | declared | 0 | — | — | run_query_agent |
| 10.1021/je300994y | PROPblock_3 | declared | 18 | unary | — | query_thermoml, search_blocks |
| 10.1021/je800298n | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1021/je900042q | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1021/je900977e | PROPblock_3 | declared | 2 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (post tool-pipeline, pre context-compaction)

| # | Iter | Tool | Args | Result (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'vapor_pressure', … | 150 | — | — | 0.1 |
| 2 | 2 | `resolve_ids` | entity_type=phase, limit=10, min_score=50, purpose… | 213 | KEEP ←in 382 | 213 | 4.3 |
| 3 | 3 | `search_blocks` | compound=GLOBcomp_52, limit=50, phase=GLOBphase_2,… | 795 | DISCARD ←in 39 | 737 | 19.9 |
| 4 | 4 | `search_blocks` | compound=GLOBcomp_52, limit=50, property=GLOBprop_… | 549 | KEEP ←in 10,002 | 549 | 23.2 |
| 5 | 6 | `inspect_block_table` | block_number=PROPblock_3, literature=GLOBlit_9995,… | 1,143 | — | — | 0.2 |
| 6 | 3 | `query_thermoml` | id_catalog=[{'type': 'comp', 'global_id'…, instruc… | 5,735 | — | — | 150.8 |
| 7 | 2 | `resolve_property_ids` | limit=10, min_score=40, purpose=Find property IDs … | 447 | KEEP ←in 1,205 | 447 | 14.4 |
| 8 | 2 | `search_blocks` | compound=GLOBcomp_52, limit=50, property=GLOBprop_… | 774 | DISCARD ←in 39 | 716 | 16.9 |
| 9 | 3 | `search_blocks` | compound=GLOBcomp_52, limit=50, property=GLOBprop_… | 921 | DISCARD ←in 39 | 863 | 17.8 |
| 10 | 4 | `search_blocks` | compound=GLOBcomp_52, limit=50, purpose=Find all a… | 1,042 | KEEP ←in 26,652 | 951 | 21.8 |
| 11 | 4 | `search_system_summary` | compound=GLOBcomp_52, purpose=Get summary of all n… | 1,437 | KEEP ←in 1,557 | 1437 | 16.5 |
| 12 | 3 | `query_thermoml` | id_catalog=[{'type': 'comp', 'global_id'…, instruc… | 3,384 | — | — | 145.8 |
| 13 | 4 | `query_thermoml` | id_catalog=[{'type': 'comp', 'global_id'…, instruc… | 135 | — | — | 0.0 |
| 14 | 5 | `query_thermoml` | id_catalog=[{'type': 'comp', 'global_id'…, instruc… | 135 | — | — | 0.0 |
| 15 | 7 | `run_query_agent` | context=Previous queries confirmed na…, purpose=Fi… | 63,335 | — | — | 869.3 |
| | | **TOTAL (15 tools)** | | **80,195** | | **5,913** | **1301.0** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 22,897 | 414 | 23,311 | 2,074 | 14.0 |
| 2 | L0-main | claudeopus46 | 22,897 | 1,136 | 24,033 | 16,449 | 61.4 |
| 3 | L0-main | claudeopus46 | 22,897 | 5,120 | 28,017 | 1,787 | 9.7 |
| 4 | L1-worker | claudeopus46 | 24,140 | 1,109 | 25,249 | 727 | 5.9 |
| 5 | L1-worker | claudeopus46 | 24,140 | 2,137 | 26,277 | 597 | 5.3 |
| 6 | L1-worker | claudeopus46 | 3,767 | 529 | 4,296 | 397 | 4.0 |
| 7 | L1-worker | claudeopus46 | 24,140 | 1,974 | 26,114 | 772 | 5.7 |
| 8 | L1-worker | claudeopus46 | 3,767 | 502 | 4,269 | 1,630 | 12.0 |
| 9 | L1-worker | claudeopus46 | 24,140 | 3,327 | 27,467 | 829 | 5.7 |
| 10 | L1-worker | claudeopus46 | 3,767 | 10,393 | 14,160 | 2,053 | 15.5 |
| 11 | L1-worker | claudeopus46 | 24,140 | 4,416 | 28,556 | 3,364 | 19.5 |
| 12 | L1-worker | claudeopus46 | 24,140 | 10,341 | 34,481 | 885 | 6.6 |
| 13 | L1-worker | claudeopus46 | 24,140 | 11,964 | 36,104 | 3,938 | 25.7 |
| 14 | L1-worker | claudeopus46 | 24,140 | 18,578 | 42,718 | 3,526 | 18.5 |
| 15 | L1-worker | claudeopus46 | 2,543 | 3,233 | 5,776 | 92 | 1.9 |
| 16 | L1-worker | claudeopus46 | 2,320 | 2,003 | 4,323 | 841 | 4.4 |
| 17 | L1-worker | claudeopus46 | 627 | 1,883 | 2,510 | 786 | 4.5 |
| 18 | L1-worker | claudeopus46 | 787 | 5,474 | 6,261 | 654 | 5.2 |
| 19 | L1-worker | claudeopus46 | 24,140 | 1,194 | 25,334 | 1,448 | 9.3 |
| 20 | L1-worker | claudeopus46 | 24,140 | 2,785 | 26,925 | 1,110 | 5.5 |
| 21 | L1-worker | claudeopus46 | 3,767 | 1,400 | 5,167 | 820 | 14.3 |
| 22 | L1-worker | claudeopus46 | 3,767 | 455 | 4,222 | 1,148 | 9.7 |
| 23 | L1-worker | claudeopus46 | 24,140 | 3,309 | 27,449 | 912 | 10.2 |
| 24 | L1-worker | claudeopus46 | 3,767 | 467 | 4,234 | 1,475 | 10.0 |
| 25 | L1-worker | claudeopus46 | 24,140 | 4,781 | 28,921 | 1,050 | 7.0 |
| 26 | L1-worker | claudeopus46 | 3,767 | 27,002 | 30,769 | 1,693 | 14.2 |
| 27 | L1-worker | claudeopus46 | 3,767 | 1,978 | 5,745 | 1,690 | 8.9 |
| 28 | L1-worker | claudeopus46 | 24,140 | 7,914 | 32,054 | 2,800 | 16.4 |
| 29 | L1-worker | claudeopus46 | 2,543 | 2,757 | 5,300 | 166 | 2.2 |
| 30 | L1-worker | claudeopus46 | 2,320 | 1,442 | 3,762 | 618 | 3.8 |
| 31 | L1-worker | claudeopus46 | 627 | 1,322 | 1,949 | 977 | 4.3 |
| 32 | L1-worker | claudeopus46 | 787 | 4,572 | 5,359 | 464 | 4.5 |
| 33 | L0-main | claudeopus46 | 22,897 | 9,976 | 32,873 | 2,039 | 14.3 |
| 34 | L0-main | claudeopus46 | 22,897 | 10,889 | 33,786 | 1,474 | 11.0 |
| 35 | L0-main | claudeopus46 | 22,897 | 11,630 | 34,527 | 1,361 | 9.9 |
| 36 | L0-main | claudeopus46 | 22,897 | 12,450 | 35,347 | 1,242 | 8.2 |
| 37 | L0-main | claudeopus46 | 22,897 | 32,744 | 55,641 | 10,512 | 72.4 |
| 38 | L0-main | claudeopus46 | 22,864 | 41,781 | 64,645 | 7,230 | 48.8 |
| 39 | L0-main | claudeopus46 | 22,864 | 47,198 | 70,062 | 6,239 | 42.6 |
| 40 | L0-main | claudeopus46 | 2,543 | 11,784 | 14,327 | 1,096 | 7.5 |
| 41 | L0-main | claudeopus46 | 2,320 | 11,236 | 13,556 | 1,482 | 11.5 |
| 42 | L0-main | claudeopus46 | 366 | 1,959 | 2,325 | 1,406 | 4.3 |
| 43 | L0-main | claudeopus46 | 1,156 | 17,470 | 18,626 | 3,648 | 17.9 |

