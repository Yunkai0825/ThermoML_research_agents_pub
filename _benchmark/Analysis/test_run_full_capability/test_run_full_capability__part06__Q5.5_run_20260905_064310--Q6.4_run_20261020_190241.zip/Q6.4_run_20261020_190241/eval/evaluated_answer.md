# Analysis Run — [run id removed] (Round 1)

**Question:** Estimate the enthalpy of sublimation of naphthalene at 298.15 K from the crystal vapour-pressure data in ThermoML, with an uncertainty; compare it with any directly reported enthalpy of sublimation, and say which data sets you excluded and why.

**[run statistics removed]**

---

## Answer

## Enthalpy of Sublimation of Naphthalene at 298.15 K — Estimated from ThermoML Crystal Vapor-Pressure Data

### 1. Data Sources

A thorough search of the ThermoML database identified **10 vapor/sublimation pressure blocks** for naphthalene (C₁₀H₈, CAS 91-20-3, GLOBcomp_139) across 7 DOIs. Of these, **6 blocks** contain crystal-phase (sublimation) data suitable for Clausius–Clapeyron analysis:

| # | DOI | lit_num_id | Block | n_pts | T range (K) | P range (kPa) | Method |
|---|-----|-----------|-------|------:|-------------|---------------|--------|
| 1 | 10.1021/je050216m | GLOBlit_8678 | PROPblock_1 | 75 | 258.48–313.52 | 0.00011–0.0455 | Static (closed cell) |
| 2 | 10.1021/je050502y | GLOBlit_8810 | PROPblock_1 | 80 | 262.24–323.24 | 0.000182–0.1059 | Diaphragm manometer |
| 3 | 10.1021/acs.jced.6b00523 | GLOBlit_6949 | PROPblock_1 | 102 | 276.72–352.18 | 0.001118–0.91956 | Static (closed cell) |
| 4 | 10.1016/j.tca.2018.07.026 | GLOBlit_6449 | PROPblock_7 | 12 | 288.2–333.0 | 0.00418–0.22352 | Transpiration |
| 5 | 10.1016/j.fluid.2014.11.026 | GLOBlit_1600 | PROPblock_5 | 13 | 297.72–326.97 | 0.01042–0.1415 | Static (closed cell) |
| 6 | 10.1021/acs.jced.5b00752 | GLOBlit_6709 | PROPblock_1 | 12 | 312.20–352.19 | 0.04083–0.92131 | Static (closed cell) |

**Total: 294 crystal-phase sublimation pressure data points** (sum of the six block counts above; this total is derived by addition, not a single database field).

### 2. Method: Clausius–Clapeyron Two-Point Estimates

The enthalpy of sublimation was estimated using the integrated Clausius–Clapeyron equation applied to pairs of inspected data points bracketing 298.15 K (or spanning the widest available range for blocks not covering 298 K):

$$\Delta H_{\text{sub}} = -R \cdot \frac{\ln(P_2/P_1)}{(1/T_2 - 1/T_1)}$$

where R = 8.314 J/(mol·K) is the universal gas constant (a physical constant, not a database value).

Each data pair below is quoted verbatim from the tool-returned block inspections. The ΔH_sub values are **derived by arithmetic** from those inspected data points using the equation above.

| # | DOI (lit_num_id, Block) | Data pair (T₁, P₁) → (T₂, P₂) | ΔH_sub (kJ/mol) |
|---|------------------------|-------------------------------|:----------------:|
| 1 | 10.1021/je050216m (GLOBlit_8678, PROPblock_1) | (293.49 K, 0.00688 kPa) → (303.50 K, 0.0182 kPa) | **72.0** |
| 2 | 10.1021/je050502y (GLOBlit_8810, PROPblock_1) | (293.18 K, 0.006699 kPa) → (303.18 K, 0.01797 kPa) | **72.9** |
| 3 | 10.1021/acs.jced.6b00523 (GLOBlit_6949, PROPblock_1) | (293.36 K, 0.006861 kPa) → (308.22 K, 0.02834 kPa) | **71.7** |
| 4 | 10.1016/j.tca.2018.07.026 (GLOBlit_6449, PROPblock_7) | (293.2 K, 0.00698 kPa) → (303.2 K, 0.01811 kPa) | **70.5** |
| 5 | 10.1016/j.fluid.2014.11.026 (GLOBlit_1600, PROPblock_5) | (297.72 K, 0.01042 kPa) → (307.27 K, 0.02598 kPa) | **72.9** |
| 6 | 10.1021/acs.jced.5b00752 (GLOBlit_6709, PROPblock_1) | (312.203 K, 0.04084 kPa) → (352.194 K, 0.92131 kPa) | **71.2** |

All ΔH_sub values in the rightmost column are **derived quantities** computed from the inspected data pairs using the Clausius–Clapeyron equation; they are not directly read from the database.

### 3. Result

**Mean ΔH_sub(298.15 K) = 71.9 ± 0.9 kJ/mol** (1σ standard deviation across 6 independent datasets; range 70.5–72.9 kJ/mol).

The value 298.15 K is the standard reference temperature at which the estimate is targeted (a thermodynamic convention, not a database datum). The mean and standard deviation are derived by arithmetic from the six ΔH_sub estimates above.

This is a two-point Clausius–Clapeyron estimate assuming ΔH_sub is approximately constant over the ~10 K intervals used. A full ln(P) vs 1/T linear regression over all points in each block would yield a more precise value with a formal standard error, but the consistency across six independent laboratories and three measurement techniques (static, diaphragm manometer, transpiration) gives confidence in the result.

The estimate is consistent with the widely accepted literature value of ~72.6 kJ/mol reported in the NIST Chemistry WebBook (an external reference source, not from ThermoML data in this session).

### 4. Comparison with Directly Reported Enthalpy of Sublimation

A thorough search of ThermoML for naphthalene with enthalpy of sublimation/vaporization properties returned **zero blocks**. Despite naphthalene having extensive ThermoML coverage, **no directly measured or reported enthalpy of sublimation is present in the database**. Therefore, no direct comparison within ThermoML is possible.

### 5. Excluded Data Sets and Reasons

| Block | DOI | lit_num_id | Reason for Exclusion |
|-------|-----|-----------|---------------------|
| PROPblock_1 | 10.1016/j.fluid.2010.09.006 | GLOBlit_882 | **High-pressure solid–gas phase boundary.** Only 4 data points at 100–8000 kPa with an anomalous inverse T–P relationship (pressure increases as temperature decreases: 351.4 K / 100 kPa → 337.8 K / 8000 kPa). These represent the high-pressure crystal–fluid equilibrium boundary, not conventional low-pressure sublimation. Clausius–Clapeyron analysis is inapplicable. |
| PROPblock_2 | 10.1021/acs.jced.6b00523 | GLOBlit_6949 | **Liquid-phase vapor pressure (vaporization, not sublimation).** 6 data points at 355.35–358.38 K (above the melting point), pressures 1.098–1.269 kPa. A Clausius–Clapeyron fit would yield ΔH_vap, not ΔH_sub. |
| PROPblock_2 | 10.1021/acs.jced.5b00752 | GLOBlit_6709 | **Liquid-phase vapor pressure (vaporization, not sublimation).** 24 data points at 357.19–452.37 K, pressures 1.20–38.57 kPa. Same reason as above. |

Additionally, the query agent noted one further block (~6 points) that could not be fully retrieved due to output truncation; its identity was not confirmed and it was therefore not used.

### 6. Chemistry Insight

Naphthalene is a classic sublimation standard — its well-characterized crystal vapor pressure makes it a primary calibrant for vapor-pressure measurement techniques. The six independent ThermoML datasets span three different experimental methods and show excellent mutual consistency (spread < 2.5 kJ/mol), confirming the reliability of the sublimation enthalpy near 72 kJ/mol at 298 K. The sublimation enthalpy reflects the energy needed to break the herringbone-packed crystal lattice (intermolecular π–π and C–H···π interactions) and transfer the molecule to the gas phase.

### 7. Limitations

- The ΔH_sub values reported here are **two-point Clausius–Clapeyron estimates** (derived quantities), not results of a full weighted linear regression. A proper ln(P) vs 1/T fit over all data points in each block — with weighting by reported uncertainties — would provide formal fit uncertainties and potentially more accurate values.
- No Redlich–Kister or other curve-fitting tools were applied in this analysis, as the available fitting tools are designed for binary mixture composition-dependent properties, not pure-component vapor pressure vs. temperature data.
- The ΔH_sub is assumed approximately constant over the temperature intervals used; in reality, the heat capacity difference between crystal and gas phases introduces a weak temperature dependence.






















### Core claims

- Six independent ThermoML crystal-phase sublimation pressure datasets for naphthalene (totaling 294 data points from 7 DOIs, spanning three measurement techniques) were used to estimate the enthalpy of sublimation via two-point Clausius–Clapeyron analysis.
- The mean estimated enthalpy of sublimation of naphthalene at 298.15 K is 71.9 ± 0.9 kJ/mol (1σ), with individual dataset estimates ranging from 70.5 to 72.9 kJ/mol.
- No directly measured or reported enthalpy of sublimation for naphthalene was found in the ThermoML database; all ΔH_sub values reported are derived quantities computed from inspected vapor-pressure data pairs using the Clausius–Clapeyron equation.
- The reported ΔH_sub values are two-point Clausius–Clapeyron estimates assuming approximately constant enthalpy over ~10 K intervals, not results of full weighted linear regressions, and therefore lack formal fit uncertainties.
- Three vapor-pressure blocks were excluded: one high-pressure solid–gas phase boundary dataset where Clausius–Clapeyron analysis is inapplicable, and two liquid-phase vapor pressure datasets (above the melting point) that would yield ΔH_vap rather than ΔH_sub.


### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8678 | 10.1021/je050216m | PROPblock_1 |  | Provides 75 sublimation pressure data points for naphthalene over 258.48–313.52 K, bracketing 298.15 K. A Clausius–Clapeyron two-point estimate from this block yields ΔH_sub ≈ 72.0 kJ/mol, contributing to the six-dataset mean. |
| GLOBlit_8810 | 10.1021/je050502y | PROPblock_1 |  | Provides 80 sublimation pressure data points for naphthalene over 262.24–323.24 K via diaphragm manometer. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 72.9 kJ/mol, contributing an independent measurement technique to the mean. |
| GLOBlit_6949 | 10.1021/acs.jced.6b00523 | PROPblock_1 |  | Provides 102 sublimation pressure data points for naphthalene over 276.72–352.18 K. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 71.7 kJ/mol, contributing the largest single dataset to the analysis. |
| GLOBlit_6449 | 10.1016/j.tca.2018.07.026 | PROPblock_7 |  | Provides 12 sublimation pressure data points for naphthalene over 288.2–333.0 K via transpiration method. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 70.5 kJ/mol, adding an independent experimental technique. |
| GLOBlit_1600 | 10.1016/j.fluid.2014.11.026 | PROPblock_5 |  | Provides 13 sublimation pressure data points for naphthalene over 297.72–326.97 K. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 72.9 kJ/mol, with the lowest temperature closest to 298.15 K among all blocks. |
| GLOBlit_6709 | 10.1021/acs.jced.5b00752 | PROPblock_1 |  | Provides 12 sublimation pressure data points for naphthalene over 312.20–352.19 K. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 71.2 kJ/mol; although above 298 K, it contributes to the consistency check across datasets. |
| GLOBlit_882 | 10.1016/j.fluid.2010.09.006 | PROPblock_1 |  | This block was correctly identified and explicitly excluded from the Clausius–Clapeyron analysis because it contains high-pressure (100–8000 kPa) solid–fluid equilibrium data, not conventional low-pressure sublimation. It is documented in the answer as an excluded dataset. |
| GLOBlit_6949 | 10.1021/acs.jced.6b00523 | PROPblock_2 |  | This block was correctly identified and explicitly excluded from the analysis because it contains liquid-phase vapor pressure data (355–358 K, above the melting point). It is documented in the answer as an excluded dataset. |
| GLOBlit_6709 | 10.1021/acs.jced.5b00752 | PROPblock_2 |  | This block was correctly identified and explicitly excluded from the analysis because it contains liquid-phase vapor pressure data (357–452 K, above the melting point). It is documented in the answer as an excluded dataset. |

---

<!-- END OF REVIEW COPY. Any later sections of the source file are outside the review scope and are not shown. -->
