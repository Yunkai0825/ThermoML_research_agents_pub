# Analysis Run — 20261020_192735 (Round 1)

**Question:** Estimate the enthalpy of sublimation of naphthalene at 298.15 K from the crystal vapour-pressure data in ThermoML, with an uncertainty; compare it with any directly reported enthalpy of sublimation, and say which data sets you excluded and why.

**Time:** 1459.7s | **Iterations:** 30 | **Tools:** 7

---

## Answer

## Enthalpy of Sublimation of Naphthalene at 298.15 K — Estimated from ThermoML Crystal Vapor-Pressure Data

### 1. Data Sources

A thorough search of the ThermoML database identified **10 vapor/sublimation pressure blocks** for naphthalene (C₁₀H₈, CAS 91-20-3, GLOBcomp_139) across 7 DOIs. Of these, **6 blocks** contain crystal-phase (sublimation) data suitable for Clausius–Clapeyron analysis:

| # | DOI | lit_num_id | Block | n_pts | T range (K) | P range (kPa) | Method |
|---|-----|-----------|-------|------:|-------------|---------------|--------|
| 1 | 10.1021/je050216m | GLOBlit_8678 | PROPblock_1 | 75 | 258.48–313.52 | 0.00011–0.0455 | Static (closed cell) |
| 2 | 10.1021/je050502y | GLOBlit_8810 | PROPblock_1 | 80 | 262.24–323.24 | 0.000182–0.1059 | Diaphragm manometer |
| 3 | 10.1021/acs.jced.6b00523 | GLOBlit_6949 | PROPblock_1 | 102 | 276.72–352.18 | 0.001118–0.91956 | Static (closed cell) |
| 4 | 10.1016/j.tca.2018.07.026 | GLOBlit_6449 | PROPblock_7 | 12 | 288.2–333.0 | 0.00418–0.22352 | Transpiration |
| 5 | 10.1016/j.fluid.2014.11.026 | GLOBlit_1600 | PROPblock_5 | 13 | 297.72–326.97 | 0.01042–0.1415 | Static (closed cell) |
| 6 | 10.1021/acs.jced.5b00752 | GLOBlit_6709 | PROPblock_1 | 12 | 312.20–352.19 | 0.04083–0.92131 | Static (closed cell) |

**Total: 294 crystal-phase sublimation pressure data points** (sum of the six block counts above; this total is derived by addition, not a single database field).

### 2. Method: Clausius–Clapeyron Two-Point Estimates

The enthalpy of sublimation was estimated using the integrated Clausius–Clapeyron equation applied to pairs of inspected data points bracketing 298.15 K (or spanning the widest available range for blocks not covering 298 K):

$$\Delta H_{\text{sub}} = -R \cdot \frac{\ln(P_2/P_1)}{(1/T_2 - 1/T_1)}$$

where R = 8.314 J/(mol·K) is the universal gas constant (a physical constant, not a database value).

Each data pair below is quoted verbatim from the tool-returned block inspections. The ΔH_sub values are **derived by arithmetic** from those inspected data points using the equation above.

| # | DOI (lit_num_id, Block) | Data pair (T₁, P₁) → (T₂, P₂) | ΔH_sub (kJ/mol) |
|---|------------------------|-------------------------------|:----------------:|
| 1 | 10.1021/je050216m (GLOBlit_8678, PROPblock_1) | (293.49 K, 0.00688 kPa) → (303.50 K, 0.0182 kPa) | **72.0** |
| 2 | 10.1021/je050502y (GLOBlit_8810, PROPblock_1) | (293.18 K, 0.006699 kPa) → (303.18 K, 0.01797 kPa) | **72.9** |
| 3 | 10.1021/acs.jced.6b00523 (GLOBlit_6949, PROPblock_1) | (293.36 K, 0.006861 kPa) → (308.22 K, 0.02834 kPa) | **71.7** |
| 4 | 10.1016/j.tca.2018.07.026 (GLOBlit_6449, PROPblock_7) | (293.2 K, 0.00698 kPa) → (303.2 K, 0.01811 kPa) | **70.5** |
| 5 | 10.1016/j.fluid.2014.11.026 (GLOBlit_1600, PROPblock_5) | (297.72 K, 0.01042 kPa) → (307.27 K, 0.02598 kPa) | **72.9** |
| 6 | 10.1021/acs.jced.5b00752 (GLOBlit_6709, PROPblock_1) | (312.203 K, 0.04084 kPa) → (352.194 K, 0.92131 kPa) | **71.2** |

All ΔH_sub values in the rightmost column are **derived quantities** computed from the inspected data pairs using the Clausius–Clapeyron equation; they are not directly read from the database.

### 3. Result

**Mean ΔH_sub(298.15 K) = 71.9 ± 0.9 kJ/mol** (1σ standard deviation across 6 independent datasets; range 70.5–72.9 kJ/mol).

The value 298.15 K is the standard reference temperature at which the estimate is targeted (a thermodynamic convention, not a database datum). The mean and standard deviation are derived by arithmetic from the six ΔH_sub estimates above.

This is a two-point Clausius–Clapeyron estimate assuming ΔH_sub is approximately constant over the ~10 K intervals used. A full ln(P) vs 1/T linear regression over all points in each block would yield a more precise value with a formal standard error, but the consistency across six independent laboratories and three measurement techniques (static, diaphragm manometer, transpiration) gives confidence in the result.

The estimate is consistent with the widely accepted literature value of ~72.6 kJ/mol reported in the NIST Chemistry WebBook (an external reference source, not from ThermoML data in this session).

### 4. Comparison with Directly Reported Enthalpy of Sublimation

A thorough search of ThermoML for naphthalene with enthalpy of sublimation/vaporization properties returned **zero blocks**. Despite naphthalene having extensive ThermoML coverage, **no directly measured or reported enthalpy of sublimation is present in the database**. Therefore, no direct comparison within ThermoML is possible.

### 5. Excluded Data Sets and Reasons

| Block | DOI | lit_num_id | Reason for Exclusion |
|-------|-----|-----------|---------------------|
| PROPblock_1 | 10.1016/j.fluid.2010.09.006 | GLOBlit_882 | **High-pressure solid–gas phase boundary.** Only 4 data points at 100–8000 kPa with an anomalous inverse T–P relationship (pressure increases as temperature decreases: 351.4 K / 100 kPa → 337.8 K / 8000 kPa). These represent the high-pressure crystal–fluid equilibrium boundary, not conventional low-pressure sublimation. Clausius–Clapeyron analysis is inapplicable. |
| PROPblock_2 | 10.1021/acs.jced.6b00523 | GLOBlit_6949 | **Liquid-phase vapor pressure (vaporization, not sublimation).** 6 data points at 355.35–358.38 K (above the melting point), pressures 1.098–1.269 kPa. A Clausius–Clapeyron fit would yield ΔH_vap, not ΔH_sub. |
| PROPblock_2 | 10.1021/acs.jced.5b00752 | GLOBlit_6709 | **Liquid-phase vapor pressure (vaporization, not sublimation).** 24 data points at 357.19–452.37 K, pressures 1.20–38.57 kPa. Same reason as above. |

Additionally, the query agent noted one further block (~6 points) that could not be fully retrieved due to output truncation; its identity was not confirmed and it was therefore not used.

### 6. Chemistry Insight

Naphthalene is a classic sublimation standard — its well-characterized crystal vapor pressure makes it a primary calibrant for vapor-pressure measurement techniques. The six independent ThermoML datasets span three different experimental methods and show excellent mutual consistency (spread < 2.5 kJ/mol), confirming the reliability of the sublimation enthalpy near 72 kJ/mol at 298 K. The sublimation enthalpy reflects the energy needed to break the herringbone-packed crystal lattice (intermolecular π–π and C–H···π interactions) and transfer the molecule to the gas phase.

### 7. Limitations

- The ΔH_sub values reported here are **two-point Clausius–Clapeyron estimates** (derived quantities), not results of a full weighted linear regression. A proper ln(P) vs 1/T fit over all data points in each block — with weighting by reported uncertainties — would provide formal fit uncertainties and potentially more accurate values.
- No Redlich–Kister or other curve-fitting tools were applied in this analysis, as the available fitting tools are designed for binary mixture composition-dependent properties, not pure-component vapor pressure vs. temperature data.
- The ΔH_sub is assumed approximately constant over the temperature intervals used; in reality, the heat capacity difference between crystal and gas phases introduces a weak temperature dependence.

---
[UNGROUNDED DATA FLAGS] The following quoted values could not be verified against any verbatim data inspection in this run and must be treated as UNVERIFIED:
- **MISATTRIBUTED_VALUE** PROPblock_1 + PROPblock_7 + PROPblock_5: 75 does not belong to PROPblock_1 + PROPblock_7 + PROPblock_5; it matches only GLOBlit_9995::PROPblock_3 (inspected this run)
  fix (required — this IS a database value, under a different block): `re-anchor 75 to GLOBlit_9995::PROPblock_3 — no new tool call needed`
- **MISATTRIBUTED_VALUE** PROPblock_5: 294 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
  fix (required — this IS a database value, under a different block): `re-anchor 294 to GLOBlit_8678::PROPblock_1 — no new tool call needed`
- **UNGROUNDED_LITERAL** PROPblock_5: 298.15 (near '…uation applied to pairs of inspected data points bracketing …') matches no inspected row/stat, database table, or other source of PROPblock_5
  fix (ONLY if this is meant to be a database datum): `inspect_block_table(block_number="PROPblock_5", literature="<GLOBlit_N or DOI>", nearest={"column": "temperature_k", "value": 298.15})` — if it is a value you computed or an external reference, keep it and label its provenance instead
- **UNGROUNDED_LITERAL** PROPblock_5: 8.314 (near '…-R \cdot \frac{\ln(P_2/P_1)}{(1/T_2 - 1/T_1)}$$  where R = 8…') matches no inspected row/stat, database table, or other source of PROPblock_5
  fix (ONLY if this is meant to be a database datum): `inspect_block_table(block_number="PROPblock_5", literature="<GLOBlit_N or DOI>")` — if it is a value you computed or an external reference, keep it and label its provenance instead
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 72.0 (near '…,  ) | (293.49 K, 0.00688 kPa) → (303.50 K, 0.0182 kPa) | **…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
  fix (ONLY if this is meant to be a database datum): `inspect_block_table(block_number="PROPblock_1", literature="<GLOBlit_N or DOI>")` — if it is a value you computed or an external reference, keep it and label its provenance instead
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 72.9 (near '…) | (293.18 K, 0.006699 kPa) → (303.18 K, 0.01797 kPa) | **7…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
  fix (ONLY if this is meant to be a database datum): `inspect_block_table(block_number="PROPblock_1", literature="<GLOBlit_N or DOI>")` — if it is a value you computed or an external reference, keep it and label its provenance instead
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 71.7 (near '…) | (293.36 K, 0.006861 kPa) → (308.22 K, 0.02834 kPa) | **7…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
  fix (ONLY if this is meant to be a database datum): `inspect_block_table(block_number="PROPblock_1", literature="<GLOBlit_N or DOI>")` — if it is a value you computed or an external reference, keep it and label its provenance instead
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 70.5 (near '…,  ) | (293.2 K, 0.00698 kPa) → (303.2 K, 0.01811 kPa) | **7…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
  fix (ONLY if this is meant to be a database datum): `inspect_block_table(block_number="PROPblock_1", literature="<GLOBlit_N or DOI>")` — if it is a value you computed or an external reference, keep it and label its provenance instead
- … and 12 more of the same kinds — PROPblock_1 + PROPblock_7 + PROPblock_5: 72.9, 71.2; PROPblock_5: 298.15, 71.9, 0.9, 70.5, 72.9, 72.6; PROPblock_2: 2.5, 72, 298
Inspected so far: PROPblock_1, PROPblock_2, PROPblock_3, PROPblock_5, PROPblock_7

### Core claims

- Six independent ThermoML crystal-phase sublimation pressure datasets for naphthalene (totaling 294 data points from 7 DOIs, spanning three measurement techniques) were used to estimate the enthalpy of sublimation via two-point Clausius–Clapeyron analysis.
- The mean estimated enthalpy of sublimation of naphthalene at 298.15 K is 71.9 ± 0.9 kJ/mol (1σ), with individual dataset estimates ranging from 70.5 to 72.9 kJ/mol.
- No directly measured or reported enthalpy of sublimation for naphthalene was found in the ThermoML database; all ΔH_sub values reported are derived quantities computed from inspected vapor-pressure data pairs using the Clausius–Clapeyron equation.
- The reported ΔH_sub values are two-point Clausius–Clapeyron estimates assuming approximately constant enthalpy over ~10 K intervals, not results of full weighted linear regressions, and therefore lack formal fit uncertainties.
- Three vapor-pressure blocks were excluded: one high-pressure solid–gas phase boundary dataset where Clausius–Clapeyron analysis is inapplicable, and two liquid-phase vapor pressure datasets (above the melting point) that would yield ΔH_vap rather than ΔH_sub.
- Several quoted values (including the computed ΔH_sub estimates, the mean, standard deviation, and some data-point counts) carry unresolved UNVERIFIED or MISATTRIBUTED flags regarding their provenance within the database.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8678 | 10.1021/je050216m | PROPblock_1 |  | Provides 75 sublimation pressure data points for naphthalene over 258.48–313.52 K, bracketing 298.15 K. A Clausius–Clapeyron two-point estimate from this block yields ΔH_sub ≈ 72.0 kJ/mol, contributing to the six-dataset mean. |
| GLOBlit_8810 | 10.1021/je050502y | PROPblock_1 |  | Provides 80 sublimation pressure data points for naphthalene over 262.24–323.24 K via diaphragm manometer. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 72.9 kJ/mol, contributing an independent measurement technique to the mean. |
| GLOBlit_6949 | 10.1021/acs.jced.6b00523 | PROPblock_1 |  | Provides 102 sublimation pressure data points for naphthalene over 276.72–352.18 K. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 71.7 kJ/mol, contributing the largest single dataset to the analysis. |
| GLOBlit_6449 | 10.1016/j.tca.2018.07.026 | PROPblock_7 |  | Provides 12 sublimation pressure data points for naphthalene over 288.2–333.0 K via transpiration method. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 70.5 kJ/mol, adding an independent experimental technique. |
| GLOBlit_1600 | 10.1016/j.fluid.2014.11.026 | PROPblock_5 |  | Provides 13 sublimation pressure data points for naphthalene over 297.72–326.97 K. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 72.9 kJ/mol, with the lowest temperature closest to 298.15 K among all blocks. |
| GLOBlit_6709 | 10.1021/acs.jced.5b00752 | PROPblock_1 |  | Provides 12 sublimation pressure data points for naphthalene over 312.20–352.19 K. A Clausius–Clapeyron estimate yields ΔH_sub ≈ 71.2 kJ/mol; although above 298 K, it contributes to the consistency check across datasets. |
| GLOBlit_882 | 10.1016/j.fluid.2010.09.006 | PROPblock_1 |  | This block was correctly identified and explicitly excluded from the Clausius–Clapeyron analysis because it contains high-pressure (100–8000 kPa) solid–fluid equilibrium data, not conventional low-pressure sublimation. It is documented in the answer as an excluded dataset. |
| GLOBlit_6949 | 10.1021/acs.jced.6b00523 | PROPblock_2 |  | This block was correctly identified and explicitly excluded from the analysis because it contains liquid-phase vapor pressure data (355–358 K, above the melting point). It is documented in the answer as an excluded dataset. |
| GLOBlit_6709 | 10.1021/acs.jced.5b00752 | PROPblock_2 |  | This block was correctly identified and explicitly excluded from the analysis because it contains liquid-phase vapor pressure data (357–452 K, above the melting point). It is documented in the answer as an excluded dataset. |

---

## Data Inspections (deterministic evidence ledger)

Hardcoded envelope merge — not agent-authored; rendered by the browser.

```json
[
  {
    "doi": "10.1021/je300994y",
    "block_number": "PROPblock_3",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "287.06",
        "vapor_or_sublimation_pressure_kpa": "11.98",
        "vapor_or_sublimation_pressure_kpa_U": "0.6"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "296.62",
        "vapor_or_sublimation_pressure_kpa": "18.54",
        "vapor_or_sublimation_pressure_kpa_U": "0.61"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "305.29",
        "vapor_or_sublimation_pressure_kpa": "26.85",
        "vapor_or_sublimation_pressure_kpa_U": "0.61"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "311.46",
        "vapor_or_sublimation_pressure_kpa": "34.47",
        "vapor_or_sublimation_pressure_kpa_U": "0.62"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "318.61",
        "vapor_or_sublimation_pressure_kpa": "45.43",
        "vapor_or_sublimation_pressure_kpa_U": "0.62"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "temperature_k": "325.59",
        "vapor_or_sublimation_pressure_kpa": "58.72",
        "vapor_or_sublimation_pressure_kpa_U": "0.64"
      },
      {
        "BLKpoint_id": "BLKpoint_15",
        "temperature_k": "332.63",
        "vapor_or_sublimation_pressure_kpa": "75.17",
        "vapor_or_sublimation_pressure_kpa_U": "0.65"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "341.51",
        "vapor_or_sublimation_pressure_kpa": "101.29",
        "vapor_or_sublimation_pressure_kpa_U": "0.67"
      }
    ],
    "inspection_id": "INSP_00c2c051d17b",
    "lit_num_id": "GLOBlit_9995"
  },
  {
    "doi": "10.1021/je050216m",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "258.48",
        "vapor_or_sublimation_pressure_kpa": "0.00011",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "258.48",
        "vapor_or_sublimation_pressure_kpa": "0.00011",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "258.48",
        "vapor_or_sublimation_pressure_kpa": "0.00011",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "258.48",
        "vapor_or_sublimation_pressure_kpa": "0.00011",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "268.48",
        "vapor_or_sublimation_pressure_kpa": "0.00041",
        "vapor_or_sublimation_pressure_kpa_U": "0.0001"
      },
      {
        "BLKpoint_id": "BLKpoint_45",
        "temperature_k": "278.49",
        "vapor_or_sublimation_pressure_kpa": "0.00136",
        "vapor_or_sublimation_pressure_kpa_U": "0.00012"
      },
      {
        "BLKpoint_id": "BLKpoint_49",
        "temperature_k": "283.49",
        "vapor_or_sublimation_pressure_kpa": "0.00241",
        "vapor_or_sublimation_pressure_kpa_U": "0.00012"
      },
      {
        "BLKpoint_id": "BLKpoint_50",
        "temperature_k": "283.49",
        "vapor_or_sublimation_pressure_kpa": "0.00241",
        "vapor_or_sublimation_pressure_kpa_U": "0.00012"
      },
      {
        "BLKpoint_id": "BLKpoint_51",
        "temperature_k": "283.49",
        "vapor_or_sublimation_pressure_kpa": "0.00241",
        "vapor_or_sublimation_pressure_kpa_U": "0.00012"
      },
      {
        "BLKpoint_id": "BLKpoint_53",
        "temperature_k": "288.49",
        "vapor_or_sublimation_pressure_kpa": "0.0041",
        "vapor_or_sublimation_pressure_kpa_U": "0.00014"
      },
      {
        "BLKpoint_id": "BLKpoint_54",
        "temperature_k": "288.49",
        "vapor_or_sublimation_pressure_kpa": "0.0041",
        "vapor_or_sublimation_pressure_kpa_U": "0.00014"
      },
      {
        "BLKpoint_id": "BLKpoint_55",
        "temperature_k": "293.49",
        "vapor_or_sublimation_pressure_kpa": "0.00688",
        "vapor_or_sublimation_pressure_kpa_U": "0.00016"
      },
      {
        "BLKpoint_id": "BLKpoint_56",
        "temperature_k": "293.49",
        "vapor_or_sublimation_pressure_kpa": "0.00688",
        "vapor_or_sublimation_pressure_kpa_U": "0.00016"
      },
      {
        "BLKpoint_id": "BLKpoint_57",
        "temperature_k": "293.49",
        "vapor_or_sublimation_pressure_kpa": "0.00688",
        "vapor_or_sublimation_pressure_kpa_U": "0.00016"
      },
      {
        "BLKpoint_id": "BLKpoint_60",
        "temperature_k": "298.49",
        "vapor_or_sublimation_pressure_kpa": "0.0113",
        "vapor_or_sublimation_pressure_kpa_U": "0.00022"
      },
      {
        "BLKpoint_id": "BLKpoint_62",
        "temperature_k": "298.49",
        "vapor_or_sublimation_pressure_kpa": "0.0113",
        "vapor_or_sublimation_pressure_kpa_U": "0.00022"
      },
      {
        "BLKpoint_id": "BLKpoint_65",
        "temperature_k": "303.5",
        "vapor_or_sublimation_pressure_kpa": "0.0182",
        "vapor_or_sublimation_pressure_kpa_U": "0.00029"
      },
      {
        "BLKpoint_id": "BLKpoint_67",
        "temperature_k": "303.5",
        "vapor_or_sublimation_pressure_kpa": "0.0182",
        "vapor_or_sublimation_pressure_kpa_U": "0.00029"
      },
      {
        "BLKpoint_id": "BLKpoint_68",
        "temperature_k": "308.51",
        "vapor_or_sublimation_pressure_kpa": "0.029",
        "vapor_or_sublimation_pressure_kpa_U": "0.00041"
      },
      {
        "BLKpoint_id": "BLKpoint_69",
        "temperature_k": "308.51",
        "vapor_or_sublimation_pressure_kpa": "0.029",
        "vapor_or_sublimation_pressure_kpa_U": "0.00041"
      },
      {
        "BLKpoint_id": "BLKpoint_70",
        "temperature_k": "308.51",
        "vapor_or_sublimation_pressure_kpa": "0.029",
        "vapor_or_sublimation_pressure_kpa_U": "0.00041"
      },
      {
        "BLKpoint_id": "BLKpoint_71",
        "temperature_k": "308.51",
        "vapor_or_sublimation_pressure_kpa": "0.029",
        "vapor_or_sublimation_pressure_kpa_U": "0.00041"
      },
      {
        "BLKpoint_id": "BLKpoint_75",
        "temperature_k": "313.52",
        "vapor_or_sublimation_pressure_kpa": "0.0455",
        "vapor_or_sublimation_pressure_kpa_U": "0.00058"
      }
    ],
    "inspection_id": "INSP_2a902459c15d",
    "lit_num_id": "GLOBlit_8678"
  },
  {
    "doi": "10.1021/je050502y",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "262.24",
        "vapor_or_sublimation_pressure_kpa": "0.000182",
        "vapor_or_sublimation_pressure_kpa_U": "2.3e-05"
      },
      {
        "BLKpoint_id": "BLKpoint_39",
        "temperature_k": "278.19",
        "vapor_or_sublimation_pressure_kpa": "0.001331",
        "vapor_or_sublimation_pressure_kpa_U": "3.7e-05"
      },
      {
        "BLKpoint_id": "BLKpoint_57",
        "temperature_k": "288.17",
        "vapor_or_sublimation_pressure_kpa": "0.00398",
        "vapor_or_sublimation_pressure_kpa_U": "8.5e-05"
      },
      {
        "BLKpoint_id": "BLKpoint_59",
        "temperature_k": "293.18",
        "vapor_or_sublimation_pressure_kpa": "0.006699",
        "vapor_or_sublimation_pressure_kpa_U": "0.000138"
      },
      {
        "BLKpoint_id": "BLKpoint_64",
        "temperature_k": "298.19",
        "vapor_or_sublimation_pressure_kpa": "0.01109",
        "vapor_or_sublimation_pressure_kpa_U": "0.000224"
      },
      {
        "BLKpoint_id": "BLKpoint_69",
        "temperature_k": "303.18",
        "vapor_or_sublimation_pressure_kpa": "0.01797",
        "vapor_or_sublimation_pressure_kpa_U": "0.000357"
      },
      {
        "BLKpoint_id": "BLKpoint_72",
        "temperature_k": "308.27",
        "vapor_or_sublimation_pressure_kpa": "0.0289",
        "vapor_or_sublimation_pressure_kpa_U": "0.000568"
      },
      {
        "BLKpoint_id": "BLKpoint_75",
        "temperature_k": "313.18",
        "vapor_or_sublimation_pressure_kpa": "0.04501",
        "vapor_or_sublimation_pressure_kpa_U": "0.000883"
      },
      {
        "BLKpoint_id": "BLKpoint_78",
        "temperature_k": "318.25",
        "vapor_or_sublimation_pressure_kpa": "0.06975",
        "vapor_or_sublimation_pressure_kpa_U": "0.001364"
      },
      {
        "BLKpoint_id": "BLKpoint_80",
        "temperature_k": "323.24",
        "vapor_or_sublimation_pressure_kpa": "0.1059",
        "vapor_or_sublimation_pressure_kpa_U": "0.002064"
      }
    ],
    "inspection_id": "INSP_34ea4fc455a4",
    "lit_num_id": "GLOBlit_8810"
  },
  {
    "doi": "10.1021/acs.jced.6b00523",
    "block_number": "PROPblock_1",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "293.36",
        "vapor_or_sublimation_pressure_kpa": "0.006861",
        "vapor_or_sublimation_pressure_kpa_U": "0.000291"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "308.22",
        "vapor_or_sublimation_pressure_kpa": "0.02834",
        "vapor_or_sublimation_pressure_kpa_U": "0.00076"
      },
      {
        "BLKpoint_id": "BLKpoint_23",
        "temperature_k": "330.6",
        "vapor_or_sublimation_pressure_kpa": "0.18866",
        "vapor_or_sublimation_pressure_kpa_U": "0.00299"
      },
      {
        "BLKpoint_id": "BLKpoint_29",
        "temperature_k": "341.46",
        "vapor_or_sublimation_pressure_kpa": "0.43058",
        "vapor_or_sublimation_pressure_kpa_U": "0.00593"
      },
      {
        "BLKpoint_id": "BLKpoint_32",
        "temperature_k": "346.84",
        "vapor_or_sublimation_pressure_kpa": "0.63466",
        "vapor_or_sublimation_pressure_kpa_U": "0.00841"
      },
      {
        "BLKpoint_id": "BLKpoint_36",
        "temperature_k": "352.18",
        "vapor_or_sublimation_pressure_kpa": "0.91956",
        "vapor_or_sublimation_pressure_kpa_U": "0.01191"
      },
      {
        "BLKpoint_id": "BLKpoint_47",
        "temperature_k": "326.37",
        "vapor_or_sublimation_pressure_kpa": "0.1338",
        "vapor_or_sublimation_pressure_kpa_U": "0.00234"
      },
      {
        "BLKpoint_id": "BLKpoint_48",
        "temperature_k": "326.37",
        "vapor_or_sublimation_pressure_kpa": "0.1338",
        "vapor_or_sublimation_pressure_kpa_U": "0.00234"
      },
      {
        "BLKpoint_id": "BLKpoint_50",
        "temperature_k": "337.46",
        "vapor_or_sublimation_pressure_kpa": "0.31847",
        "vapor_or_sublimation_pressure_kpa_U": "0.00456"
      },
      {
        "BLKpoint_id": "BLKpoint_52",
        "temperature_k": "348.58",
        "vapor_or_sublimation_pressure_kpa": "0.71429",
        "vapor_or_sublimation_pressure_kpa_U": "0.00941"
      },
      {
        "BLKpoint_id": "BLKpoint_55",
        "temperature_k": "276.72",
        "vapor_or_sublimation_pressure_kpa": "0.001118",
        "vapor_or_sublimation_pressure_kpa_U": "0.000119"
      },
      {
        "BLKpoint_id": "BLKpoint_75",
        "temperature_k": "294.96",
        "vapor_or_sublimation_pressure_kpa": "0.007922",
        "vapor_or_sublimation_pressure_kpa_U": "0.000327"
      },
      {
        "BLKpoint_id": "BLKpoint_88",
        "temperature_k": "317.19",
        "vapor_or_sublimation_pressure_kpa": "0.06259",
        "vapor_or_sublimation_pressure_kpa_U": "0.00135"
      },
      {
        "BLKpoint_id": "BLKpoint_97",
        "temperature_k": "335.27",
        "vapor_or_sublimation_pressure_kpa": "0.27226",
        "vapor_or_sublimation_pressure_kpa_U": "0.00399"
      },
      {
        "BLKpoint_id": "BLKpoint_102",
        "temperature_k": "339.09",
        "vapor_or_sublimation_pressure_kpa": "0.36276",
        "vapor_or_sublimation_pressure_kpa_U": "0.0051"
      }
    ],
    "inspection_id": "INSP_39c4917c80c8",
    "lit_num_id": "GLOBlit_6949"
  },
  {
    "doi": "10.1016/j.tca.2018.07.026",
    "block_number": "PROPblock_7",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "288.2",
        "vapor_or_sublimation_pressure_kpa": "0.00418",
        "vapor_or_sublimation_pressure_kpa_U": "0.00021"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "290.7",
        "vapor_or_sublimation_pressure_kpa": "0.00548",
        "vapor_or_sublimation_pressure_kpa_U": "0.00028"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "293.2",
        "vapor_or_sublimation_pressure_kpa": "0.00698",
        "vapor_or_sublimation_pressure_kpa_U": "0.00035"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "298.2",
        "vapor_or_sublimation_pressure_kpa": "0.01114",
        "vapor_or_sublimation_pressure_kpa_U": "0.00054"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "303.2",
        "vapor_or_sublimation_pressure_kpa": "0.01811",
        "vapor_or_sublimation_pressure_kpa_U": "0.00088"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "308",
        "vapor_or_sublimation_pressure_kpa": "0.02903",
        "vapor_or_sublimation_pressure_kpa_U": "0.00138"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "313.1",
        "vapor_or_sublimation_pressure_kpa": "0.04408",
        "vapor_or_sublimation_pressure_kpa_U": "0.00206"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "318.2",
        "vapor_or_sublimation_pressure_kpa": "0.0671",
        "vapor_or_sublimation_pressure_kpa_U": "0.00314"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "323.1",
        "vapor_or_sublimation_pressure_kpa": "0.102",
        "vapor_or_sublimation_pressure_kpa_U": "0.00476"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "328.1",
        "vapor_or_sublimation_pressure_kpa": "0.1538",
        "vapor_or_sublimation_pressure_kpa_U": "0.00705"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "330.5",
        "vapor_or_sublimation_pressure_kpa": "0.18668",
        "vapor_or_sublimation_pressure_kpa_U": "0.00858"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "333",
        "vapor_or_sublimation_pressure_kpa": "0.22352",
        "vapor_or_sublimation_pressure_kpa_U": "0.01013"
      }
    ],
    "inspection_id": "INSP_d57a49c4afe9",
    "lit_num_id": "GLOBlit_6449"
  },
  {
    "doi": "10.1016/j.fluid.2014.11.026",
    "block_number": "PROPblock_5",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "297.72",
        "vapor_or_sublimation_pressure_kpa": "0.01042",
        "vapor_or_sublimation_pressure_kpa_U": "0.00045"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "302.47",
        "vapor_or_sublimation_pressure_kpa": "0.01651",
        "vapor_or_sublimation_pressure_kpa_U": "0.0006"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "307.27",
        "vapor_or_sublimation_pressure_kpa": "0.02598",
        "vapor_or_sublimation_pressure_kpa_U": "0.00078"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "312.35",
        "vapor_or_sublimation_pressure_kpa": "0.04107",
        "vapor_or_sublimation_pressure_kpa_U": "0.00107"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "314.78",
        "vapor_or_sublimation_pressure_kpa": "0.05102",
        "vapor_or_sublimation_pressure_kpa_U": "0.00126"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "317.21",
        "vapor_or_sublimation_pressure_kpa": "0.06281",
        "vapor_or_sublimation_pressure_kpa_U": "0.00148"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "319.66",
        "vapor_or_sublimation_pressure_kpa": "0.0774",
        "vapor_or_sublimation_pressure_kpa_U": "0.00176"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "322.08",
        "vapor_or_sublimation_pressure_kpa": "0.0949",
        "vapor_or_sublimation_pressure_kpa_U": "0.00209"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "324.51",
        "vapor_or_sublimation_pressure_kpa": "0.1161",
        "vapor_or_sublimation_pressure_kpa_U": "0.0025"
      },
      {
        "BLKpoint_id": "BLKpoint_13",
        "temperature_k": "326.97",
        "vapor_or_sublimation_pressure_kpa": "0.1415",
        "vapor_or_sublimation_pressure_kpa_U": "0.0027"
      }
    ],
    "inspection_id": "INSP_ae9904ad9a25",
    "lit_num_id": "GLOBlit_1600"
  },
  {
    "doi": "10.1021/acs.jced.5b00752",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "312.203",
        "vapor_or_sublimation_pressure_kpa": "0.04084",
        "vapor_or_sublimation_pressure_kpa_U": "0.00113"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "312.205",
        "vapor_or_sublimation_pressure_kpa": "0.04083",
        "vapor_or_sublimation_pressure_kpa_U": "0.00113"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "317.21",
        "vapor_or_sublimation_pressure_kpa": "0.06326",
        "vapor_or_sublimation_pressure_kpa_U": "0.00149"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "322.21",
        "vapor_or_sublimation_pressure_kpa": "0.09622",
        "vapor_or_sublimation_pressure_kpa_U": "0.00202"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "327.211",
        "vapor_or_sublimation_pressure_kpa": "0.14465",
        "vapor_or_sublimation_pressure_kpa_U": "0.0025"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "332.21",
        "vapor_or_sublimation_pressure_kpa": "0.21532",
        "vapor_or_sublimation_pressure_kpa_U": "0.00324"
      },
      {
        "BLKpoint_id": "BLKpoint_7",
        "temperature_k": "337.206",
        "vapor_or_sublimation_pressure_kpa": "0.31504",
        "vapor_or_sublimation_pressure_kpa_U": "0.0043"
      },
      {
        "BLKpoint_id": "BLKpoint_8",
        "temperature_k": "337.207",
        "vapor_or_sublimation_pressure_kpa": "0.31543",
        "vapor_or_sublimation_pressure_kpa_U": "0.00431"
      },
      {
        "BLKpoint_id": "BLKpoint_9",
        "temperature_k": "342.185",
        "vapor_or_sublimation_pressure_kpa": "0.45565",
        "vapor_or_sublimation_pressure_kpa_U": "0.0058"
      },
      {
        "BLKpoint_id": "BLKpoint_10",
        "temperature_k": "347.186",
        "vapor_or_sublimation_pressure_kpa": "0.65104",
        "vapor_or_sublimation_pressure_kpa_U": "0.00791"
      },
      {
        "BLKpoint_id": "BLKpoint_11",
        "temperature_k": "347.187",
        "vapor_or_sublimation_pressure_kpa": "0.65096",
        "vapor_or_sublimation_pressure_kpa_U": "0.00791"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "352.194",
        "vapor_or_sublimation_pressure_kpa": "0.92131",
        "vapor_or_sublimation_pressure_kpa_U": "0.01078"
      }
    ],
    "inspection_id": "INSP_0f47f726d28e",
    "lit_num_id": "GLOBlit_6709"
  },
  {
    "doi": "10.1021/acs.jced.6b00523",
    "block_number": "PROPblock_2",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "355.35",
        "vapor_or_sublimation_pressure_kpa": "1.098",
        "vapor_or_sublimation_pressure_kpa_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "355.35",
        "vapor_or_sublimation_pressure_kpa": "1.0981",
        "vapor_or_sublimation_pressure_kpa_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "355.35",
        "vapor_or_sublimation_pressure_kpa": "1.0982",
        "vapor_or_sublimation_pressure_kpa_U": "0.0141"
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "358.34",
        "vapor_or_sublimation_pressure_kpa": "1.2662",
        "vapor_or_sublimation_pressure_kpa_U": "0.0161"
      },
      {
        "BLKpoint_id": "BLKpoint_5",
        "temperature_k": "358.36",
        "vapor_or_sublimation_pressure_kpa": "1.267",
        "vapor_or_sublimation_pressure_kpa_U": "0.0162"
      },
      {
        "BLKpoint_id": "BLKpoint_6",
        "temperature_k": "358.38",
        "vapor_or_sublimation_pressure_kpa": "1.2686",
        "vapor_or_sublimation_pressure_kpa_U": "0.0162"
      }
    ],
    "inspection_id": "INSP_292837b5aea1",
    "lit_num_id": "GLOBlit_6949"
  },
  {
    "doi": "10.1021/acs.jced.5b00752",
    "block_number": "PROPblock_2",
    "table_mode": "rdp",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "357.19",
        "vapor_or_sublimation_pressure_kpa": "1.2003",
        "vapor_or_sublimation_pressure_kpa_U": "0.0138"
      },
      {
        "BLKpoint_id": "BLKpoint_12",
        "temperature_k": "387.232",
        "vapor_or_sublimation_pressure_kpa": "4.4749",
        "vapor_or_sublimation_pressure_kpa_U": "0.0384"
      },
      {
        "BLKpoint_id": "BLKpoint_18",
        "temperature_k": "402.368",
        "vapor_or_sublimation_pressure_kpa": "7.9615",
        "vapor_or_sublimation_pressure_kpa_U": "0.0665"
      },
      {
        "BLKpoint_id": "BLKpoint_20",
        "temperature_k": "412.397",
        "vapor_or_sublimation_pressure_kpa": "11.329",
        "vapor_or_sublimation_pressure_kpa_U": "0.094"
      },
      {
        "BLKpoint_id": "BLKpoint_21",
        "temperature_k": "422.548",
        "vapor_or_sublimation_pressure_kpa": "15.876",
        "vapor_or_sublimation_pressure_kpa_U": "0.131"
      },
      {
        "BLKpoint_id": "BLKpoint_22",
        "temperature_k": "432.579",
        "vapor_or_sublimation_pressure_kpa": "21.747",
        "vapor_or_sublimation_pressure_kpa_U": "0.179"
      },
      {
        "BLKpoint_id": "BLKpoint_23",
        "temperature_k": "442.461",
        "vapor_or_sublimation_pressure_kpa": "29.184",
        "vapor_or_sublimation_pressure_kpa_U": "0.239"
      },
      {
        "BLKpoint_id": "BLKpoint_24",
        "temperature_k": "452.367",
        "vapor_or_sublimation_pressure_kpa": "38.569",
        "vapor_or_sublimation_pressure_kpa_U": "0.315"
      }
    ],
    "inspection_id": "INSP_3ab4f2fcfdf2",
    "lit_num_id": "GLOBlit_6709"
  },
  {
    "doi": "10.1016/j.fluid.2010.09.006",
    "block_number": "PROPblock_1",
    "table_mode": "complete",
    "columns": [
      "BLKpoint_id",
      "temperature_k",
      "vapor_or_sublimation_pressure_kpa",
      "vapor_or_sublimation_pressure_kpa_U"
    ],
    "rows_shown": [
      {
        "BLKpoint_id": "BLKpoint_1",
        "temperature_k": "351.4",
        "vapor_or_sublimation_pressure_kpa": "100",
        "vapor_or_sublimation_pressure_kpa_U": ""
      },
      {
        "BLKpoint_id": "BLKpoint_2",
        "temperature_k": "345.7",
        "vapor_or_sublimation_pressure_kpa": "3000",
        "vapor_or_sublimation_pressure_kpa_U": ""
      },
      {
        "BLKpoint_id": "BLKpoint_3",
        "temperature_k": "341.4",
        "vapor_or_sublimation_pressure_kpa": "6000",
        "vapor_or_sublimation_pressure_kpa_U": ""
      },
      {
        "BLKpoint_id": "BLKpoint_4",
        "temperature_k": "337.8",
        "vapor_or_sublimation_pressure_kpa": "8000",
        "vapor_or_sublimation_pressure_kpa_U": ""
      }
    ],
    "inspection_id": "INSP_ea2ef03f33fe",
    "lit_num_id": "GLOBlit_882"
  }
]
```