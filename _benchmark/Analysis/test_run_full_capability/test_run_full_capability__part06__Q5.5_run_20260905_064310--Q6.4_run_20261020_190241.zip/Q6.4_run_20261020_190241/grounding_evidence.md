# Data grounding evidence

- generated: 2026-10-20T19:27:01
- gate verdict: 56 violation(s)

## Cited blocks

| block | lit_num_id | inspected | inspections | db rows |
|---|---|---|---|---|
| PROPblock_1 | GLOBlit_8678 | yes | INSP_2a902459c15d, INSP_34ea4fc455a4, INSP_39c4917c80c8, INSP_0f47f726d28e, INSP_ea2ef03f33fe | 75 |
| PROPblock_2 | GLOBlit_6949 | yes | INSP_292837b5aea1, INSP_3ab4f2fcfdf2 | 6 |
| PROPblock_3 | GLOBlit_9995 | yes | INSP_00c2c051d17b | 18 |
| PROPblock_5 | GLOBlit_1600 | yes | INSP_ae9904ad9a25 | 13 |
| PROPblock_7 | GLOBlit_6449 | yes | INSP_d57a49c4afe9 | 12 |

## Literal verdicts

| token | region | verdict | source |
|---|---|---|---|
| 75 | PROPblock_1 + PROPblock_7 + PROPblock_5 | misattributed | PROPblock_3 |
| 258.48 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 313.52 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00011 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0455 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 80 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 262.24 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 323.24 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.000182 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.1059 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 102 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 276.72 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 352.18 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.001118 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.91956 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 288.2 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 333.0 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00418 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.22352 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 13 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 297.72 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 326.97 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.01042 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.1415 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 312.20 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 352.19 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04083 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.92131 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 294 | PROPblock_5 | misattributed | PROPblock_1 |
| 298.15 | PROPblock_5 | ungrounded | — |
| 298 | PROPblock_5 | verified | — |
| 8.314 | PROPblock_5 | ungrounded | — |
| 293.49 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00688 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 303.50 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.0182 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 72.0 | PROPblock_1 + PROPblock_7 + PROPblock_5 | ungrounded | — |
| 293.18 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.006699 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 303.18 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.01797 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 72.9 | PROPblock_1 + PROPblock_7 + PROPblock_5 | ungrounded | — |
| 293.36 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.006861 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 308.22 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.02834 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 71.7 | PROPblock_1 + PROPblock_7 + PROPblock_5 | ungrounded | — |
| 293.2 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.00698 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 303.2 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.01811 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 70.5 | PROPblock_1 + PROPblock_7 + PROPblock_5 | ungrounded | — |
| 297.72 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.01042 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 307.27 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.02598 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 72.9 | PROPblock_1 + PROPblock_7 + PROPblock_5 | ungrounded | — |
| 312.203 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.04084 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 352.194 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 0.92131 | PROPblock_1 + PROPblock_7 + PROPblock_5 | verified | — |
| 71.2 | PROPblock_1 + PROPblock_7 + PROPblock_5 | ungrounded | — |
| 298.15 | PROPblock_5 | ungrounded | — |
| 71.9 | PROPblock_5 | ungrounded | — |
| 0.9 | PROPblock_5 | uninspected_value | PROPblock_5 |
| 70.5 | PROPblock_5 | ungrounded | — |
| 72.9 | PROPblock_5 | ungrounded | — |
| 298.15 | PROPblock_5 | ungrounded | — |
| 72.6 | PROPblock_5 | ungrounded | — |
| 100 | PROPblock_1 + PROPblock_2 | verified | — |
| 8000 | PROPblock_1 + PROPblock_2 | verified | — |
| 351.4 | PROPblock_1 + PROPblock_2 | verified | — |
| 100 | PROPblock_1 + PROPblock_2 | verified | — |
| 337.8 | PROPblock_1 + PROPblock_2 | verified | — |
| 8000 | PROPblock_1 + PROPblock_2 | verified | — |
| 355.35 | PROPblock_1 + PROPblock_2 | verified | — |
| 358.38 | PROPblock_1 + PROPblock_2 | verified | — |
| 1.098 | PROPblock_1 + PROPblock_2 | verified | — |
| 1.269 | PROPblock_1 + PROPblock_2 | verified | — |
| 24 | PROPblock_1 + PROPblock_2 | verified | — |
| 357.19 | PROPblock_1 + PROPblock_2 | verified | — |
| 452.37 | PROPblock_1 + PROPblock_2 | verified | — |
| 1.20 | PROPblock_1 + PROPblock_2 | verified | — |
| 38.57 | PROPblock_1 + PROPblock_2 | verified | — |
| 2.5 | PROPblock_2 | ambiguous | 2 sources |
| 72 | PROPblock_2 | ungrounded | — |
| 298 | PROPblock_2 | ambiguous | 4 sources |
| 75 | PROPblock_5 | misattributed | PROPblock_3 |
| 75 | GLOBlit_9995::PROPblock_3 | verified | — |
| 294 | PROPblock_5 | misattributed | PROPblock_1 |
| 294 | GLOBlit_8678::PROPblock_1 | verified | — |
| 298.15 | PROPblock_5 | ungrounded | — |
| 298.15 | PROPblock_5 | ungrounded | — |
| 8.314 | PROPblock_5 | ungrounded | — |
| 72.0 | PROPblock_5 | ungrounded | — |
| 293.49 | PROPblock_5 | misattributed | PROPblock_1 |
| 0.00688 | PROPblock_5 | misattributed | PROPblock_1 |
| 303.50 | PROPblock_5 | misattributed | PROPblock_1 |
| 0.0182 | PROPblock_5 | misattributed | PROPblock_1 |
| 72.9 | PROPblock_5 | ungrounded | — |
| 293.18 | PROPblock_5 | misattributed | PROPblock_1 |
| 0.006699 | PROPblock_5 | misattributed | PROPblock_1 |
| 303.18 | PROPblock_5 | misattributed | PROPblock_1 |
| 0.01797 | PROPblock_5 | misattributed | PROPblock_1 |
| 71.7 | PROPblock_5 | ungrounded | — |
| 293.36 | PROPblock_5 | misattributed | PROPblock_1 |
| 0.006861 | PROPblock_5 | misattributed | PROPblock_1 |
| 308.22 | PROPblock_5 | misattributed | PROPblock_1 |
| 0.02834 | PROPblock_5 | misattributed | PROPblock_1 |
| 70.5 | PROPblock_5 | ungrounded | — |
| 293.2 | PROPblock_5 | ambiguous | 2 sources |
| 0.00698 | PROPblock_5 | misattributed | PROPblock_7 |
| 303.2 | PROPblock_5 | ambiguous | 2 sources |
| 0.01811 | PROPblock_5 | misattributed | PROPblock_7 |
| 72.9 | PROPblock_5 | ungrounded | — |
| 71.2 | PROPblock_5 | ungrounded | — |
| 298.15 | PROPblock_5 | ungrounded | — |
| 71.9 | PROPblock_5 | ungrounded | — |
| 0.9 | PROPblock_5 | uninspected_value | PROPblock_5 |
| 70.5 | PROPblock_5 | ungrounded | — |
| 72.9 | PROPblock_5 | ungrounded | — |
| 72.6 | PROPblock_5 | ungrounded | — |
| 2.5 | PROPblock_2 | ambiguous | 2 sources |
| 72 | PROPblock_2 | ungrounded | — |
| 298 | PROPblock_2 | ambiguous | 4 sources |

## Violations

- **MISATTRIBUTED_VALUE** PROPblock_1 + PROPblock_7 + PROPblock_5: 75 does not belong to PROPblock_1 + PROPblock_7 + PROPblock_5; it matches only GLOBlit_9995::PROPblock_3 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 294 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 298.15 (near '…uation applied to pairs of inspected data points bracketing …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 8.314 (near '…-R \cdot \frac{\ln(P_2/P_1)}{(1/T_2 - 1/T_1)}$$  where R = 8…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 72.0 (near '…,  ) | (293.49 K, 0.00688 kPa) → (303.50 K, 0.0182 kPa) | **…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 72.9 (near '…) | (293.18 K, 0.006699 kPa) → (303.18 K, 0.01797 kPa) | **7…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 71.7 (near '…) | (293.36 K, 0.006861 kPa) → (308.22 K, 0.02834 kPa) | **7…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 70.5 (near '…,  ) | (293.2 K, 0.00698 kPa) → (303.2 K, 0.01811 kPa) | **7…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 72.9 (near '…) | (297.72 K, 0.01042 kPa) → (307.27 K, 0.02598 kPa) | **72…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_1 + PROPblock_7 + PROPblock_5: 71.2 (near '…) | (312.203 K, 0.04084 kPa) → (352.194 K, 0.92131 kPa) | **…') matches no inspected row/stat, database table, or other source of PROPblock_1 + PROPblock_7 + PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 298.15 (near '…ectly read from the database.  ### 3. Result  **Mean ΔH_sub(…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 71.9 (near '…rom the database.  ### 3. Result  **Mean ΔH_sub(298.15 K) = …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNINSPECTED_VALUE** PROPblock_5: 0.9 exists in PROPblock_5's database table but was never shown in an inspection of this run
- **UNGROUNDED_LITERAL** PROPblock_5: 70.5 (near '…(1σ standard deviation across 6 independent datasets; range …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 72.9 (near '…tandard deviation across 6 independent datasets; range 70.5–…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 298.15 (near '…6 independent datasets; range 70.5–72.9 kJ/mol).  The value …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 72.6 (near '…is consistent with the widely accepted literature value of ~…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **AMBIGUOUS_VALUE** PROPblock_2: 2.5 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** PROPblock_2: 72 (near '…confirming the reliability of the sublimation enthalpy near …') matches no inspected row/stat, database table, or other source of PROPblock_2
- **AMBIGUOUS_VALUE** PROPblock_2: 298 matches 4 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 75 does not belong to PROPblock_5; it matches only GLOBlit_9995::PROPblock_3 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 294 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 298.15 (near '…: 298.15 (near '…uation applied to pairs of insp…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 298.15 (near '…it_N or DOI>", nearest={"column": "temperature_k", "value": …') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 8.314 (near '…: 8.314 (near '…-R \cdot \frac{\ln(P_2/P_1)}{(1…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 72.0 (near '…: 72.0 (near '…,  ) | (293.49 K, 0.00688 kPa)…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 293.49 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.00688 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 303.50 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.0182 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 72.9 (near '…: 72.9 (near '…) | (293.18 K, 0.006699 kPa) →…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 293.18 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.006699 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 303.18 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.01797 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 71.7 (near '…: 71.7 (near '…) | (293.36 K, 0.006861 kPa) →…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **MISATTRIBUTED_VALUE** PROPblock_5: 293.36 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.006861 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 308.22 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.02834 does not belong to PROPblock_5; it matches only GLOBlit_8678::PROPblock_1 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 70.5 (near '…: 70.5 (near '…,  ) | (293.2 K, 0.00698 kPa) →…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **AMBIGUOUS_VALUE** PROPblock_5: 293.2 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.00698 does not belong to PROPblock_5; it matches only GLOBlit_6449::PROPblock_7 (inspected this run)
- **AMBIGUOUS_VALUE** PROPblock_5: 303.2 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **MISATTRIBUTED_VALUE** PROPblock_5: 0.01811 does not belong to PROPblock_5; it matches only GLOBlit_6449::PROPblock_7 (inspected this run)
- **UNGROUNDED_LITERAL** PROPblock_5: 72.9 (near '…: 72.9, 71.2;…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 71.2 (near '…: 72.9, 71.2;…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 298.15 (near '…: 298.15, 71.9, 0.9, 70.5, 72.9, 72.6;…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 71.9 (near '…: 298.15, 71.9, 0.9, 70.5, 72.9, 72.6;…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNINSPECTED_VALUE** PROPblock_5: 0.9 exists in PROPblock_5's database table but was never shown in an inspection of this run
- **UNGROUNDED_LITERAL** PROPblock_5: 70.5 (near '…: 298.15, 71.9, 0.9, 70.5, 72.9, 72.6;…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 72.9 (near '…: 298.15, 71.9, 0.9, 70.5, 72.9, 72.6;…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **UNGROUNDED_LITERAL** PROPblock_5: 72.6 (near '…: 298.15, 71.9, 0.9, 70.5, 72.9, 72.6;…') matches no inspected row/stat, database table, or other source of PROPblock_5
- **AMBIGUOUS_VALUE** PROPblock_2: 2.5 matches 2 different sources — ambiguous; re-quote it from an inspection of the block you mean
- **UNGROUNDED_LITERAL** PROPblock_2: 72 (near '…: 2.5, 72, 298 Inspected so far:…') matches no inspected row/stat, database table, or other source of PROPblock_2
- **AMBIGUOUS_VALUE** PROPblock_2: 298 matches 4 different sources — ambiguous; re-quote it from an inspection of the block you mean

## Inspections (verbatim)

### INSP_00c2c051d17b — GLOBlit_9995::PROPblock_3 (rdp, 8 rows shown)

_structured envelope entry (no markdown)_

### INSP_2a902459c15d — GLOBlit_8678::PROPblock_1 (rdp, 23 rows shown)

_structured envelope entry (no markdown)_

### INSP_34ea4fc455a4 — GLOBlit_8810::PROPblock_1 (rdp, 10 rows shown)

_structured envelope entry (no markdown)_

### INSP_39c4917c80c8 — GLOBlit_6949::PROPblock_1 (rdp, 15 rows shown)

_structured envelope entry (no markdown)_

### INSP_d57a49c4afe9 — GLOBlit_6449::PROPblock_7 (complete, 12 rows shown)

_structured envelope entry (no markdown)_

### INSP_ae9904ad9a25 — GLOBlit_1600::PROPblock_5 (rdp, 10 rows shown)

_structured envelope entry (no markdown)_

### INSP_0f47f726d28e — GLOBlit_6709::PROPblock_1 (complete, 12 rows shown)

_structured envelope entry (no markdown)_

### INSP_292837b5aea1 — GLOBlit_6949::PROPblock_2 (complete, 6 rows shown)

_structured envelope entry (no markdown)_

### INSP_3ab4f2fcfdf2 — GLOBlit_6709::PROPblock_2 (rdp, 8 rows shown)

_structured envelope entry (no markdown)_

### INSP_ea2ef03f33fe — GLOBlit_882::PROPblock_1 (complete, 4 rows shown)

_structured envelope entry (no markdown)_
